# filevault -- Dateiversionierung

Inhaltsadressierter Tresor (Ordner): `objekte/<sha256>` je unterschiedlichem
Inhalt, `index.json` mit den Versionen je logischem Namen.

- **V1** Gleicher Inhalt = gleiches Objekt; erneutes Ablegen ohne Aenderung
  erzeugt keine neue Version.
- **V2** Versionen sind unveraenderlich; `entfernen()` nimmt nur den Namen,
  `aufraeumen()` loescht unbenutzte Objekte.
- **V3** `abrufen(name, version)` liefert byteidentisch; ohne Nummer die neueste.
- **V4** `snapshot(name, {dateien})` friert einen Satz (Name -> Version) ein --
  genau das koppelt ein Lauf an seine Befehle: "Rechnung Oktober" liefert
  spaeter dieselben Quellen, auch wenn es laengst Neuere gibt.
- **V5** `zusammenfuehren(anderer)` vereinigt Objekte und Versionen (nach Zeit
  einsortiert, Nummern neu vergeben, Snapshots bleiben auf ihren Hashes) --
  der Abgleich zwischen Geraeten.

Beispiel (pdfgen-Quelle und Kundenliste als Satz an einen Lauf koppeln):

    Vault v; v.oeffnen("~/.xbm/vault", "laptop");
    v.ablegen("pdfgen/bewerbung.txt", inhalt, jetzt, "Anrede geaendert");
    v.snapshot("Rechnung Oktober", {"pdfgen/bewerbung.txt", "kunden.json"});
    v.ausSnapshot("Rechnung Oktober", "pdfgen/bewerbung.txt", inhalt);   // spaeter

    cmake -B build -S . && cmake --build build && ctest --test-dir build

