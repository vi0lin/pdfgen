#pragma once
// ===========================================================================
// filevault -- DATEIVERSIONIERUNG, inhaltsadressiert, header-only.
//
// Ein Tresor (Vault) ist ein Ordner:
//   objekte/<sha256>        der Inhalt, einmal je unterschiedlichem Inhalt
//   index.json              je logischem Namen die Liste seiner Versionen
//
// Begriffe
//   Name      logischer Dateiname im Tresor, z.B. "pdfgen/bewerbung.txt"
//   Version   laufende Nummer je Name (1, 2, 3 ...) mit Hash, Zeit, Geraet,
//             Kommentar -- und optionalem Bezug: welche Version eines anderen
//             Namens gleichzeitig galt (damit ein Job seine Quellen als
//             Satz festhalten kann: "Rechnung Oktober" = bewerbung.txt v7 +
//             kunden.json v3)
//   Snapshot  ein benannter Satz von (Name, Version) -- genau das, was ein
//             Lauf an seine Befehle koppelt (R: "Dateiversionen an Befehle
//             koppeln")
//
// Regeln
//   V1  Gleicher Inhalt = gleiches Objekt; erneutes Ablegen ohne Aenderung
//       erzeugt KEINE neue Version (liefert die bestehende).
//   V2  Versionen sind unveraenderlich; loeschen entfernt nur den Namen aus
//       dem Index, die Objekte bleiben (bis aufraeumen()).
//   V3  abrufen(name, version) liefert den Inhalt byteidentisch; ohne
//       Version die neueste.
//   V4  Ein Snapshot ist eine feste Zuordnung; er liefert spaeter dieselben
//       Inhalte, auch wenn die Namen laengst neuere Versionen haben.
//   V5  Zwei Tresore lassen sich zusammenfuehren (Objekte: Vereinigung;
//       Index: je Name Versionen nach Hash vereinigt, Nummern neu vergeben
//       nach Zeit) -- das ist der Abgleich zwischen Geraeten.
// ===========================================================================
#include "sha256.h"
#include <nlohmann/json.hpp>
#include <algorithm>
#include <cstdio>
#include <fstream>
#include <map>
#include <string>
#include <sys/stat.h>
#include <vector>
#if defined(_WIN32)
  #include <direct.h>
  #define FV_MKDIR(p) _mkdir(p)
#else
  #define FV_MKDIR(p) mkdir(p, 0755)
#endif

namespace filevault {
using json = nlohmann::json;
using Zeit = std::int64_t;

struct Version {
    int         nummer = 0;
    std::string hash;
    Zeit        zeit = 0;
    std::string geraet;
    std::string kommentar;
    std::size_t groesse = 0;
};

struct Vault {
    std::string ordner;
    std::string geraet = "lokal";
    std::map<std::string, std::vector<Version>> index;          // Name -> Versionen
    std::map<std::string, std::map<std::string, int>> snapshots; // Snapshot -> (Name -> Version)

    static bool dateiLesen(const std::string& p, std::string& aus) { std::ifstream f(p, std::ios::binary); if (!f) return false; aus.assign((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>()); return true; }
    static bool dateiSchreiben(const std::string& p, const std::string& inhalt) { std::ofstream f(p + ".neu", std::ios::binary); if (!f) return false; f << inhalt; f.close(); std::remove(p.c_str()); return std::rename((p + ".neu").c_str(), p.c_str()) == 0; }
    static bool existiert(const std::string& p) { struct stat st; return stat(p.c_str(), &st) == 0; }
    std::string objektPfad(const std::string& hash) const { return ordner + "/objekte/" + hash; }

    // Ordner samt Eltern anlegen (mkdir -p)
    static void ordnerAnlegen(const std::string& p) {
        for (std::size_t i = 1; i <= p.size(); ++i)
            if (i == p.size() || p[i] == '/' || p[i] == '\\') { std::string t = p.substr(0, i); if (!t.empty() && !existiert(t)) FV_MKDIR(t.c_str()); }
    }
    bool oeffnen(const std::string& pfad, const std::string& geraetName = "lokal") {
        ordner = pfad; geraet = geraetName;
        ordnerAnlegen(ordner + "/objekte");
        std::string t; if (dateiLesen(ordner + "/index.json", t)) { json j = json::parse(t, nullptr, false); if (j.is_object()) ausJson(j); }
        return existiert(ordner + "/objekte");
    }
    bool speichern() const { return dateiSchreiben(ordner + "/index.json", zuJson().dump(1)); }

    // V1: Inhalt ablegen -> Version (bestehende, wenn unveraendert)
    Version ablegen(const std::string& name, const std::string& inhalt, Zeit jetzt, const std::string& kommentar = "") {
        const std::string h = Sha256Hex(inhalt);
        std::vector<Version>& vs = index[name];
        if (!vs.empty() && vs.back().hash == h) return vs.back();
        if (!existiert(objektPfad(h))) dateiSchreiben(objektPfad(h), inhalt);
        Version v; v.nummer = vs.empty() ? 1 : vs.back().nummer + 1; v.hash = h; v.zeit = jetzt; v.geraet = geraet; v.kommentar = kommentar; v.groesse = inhalt.size();
        vs.push_back(v); return v;
    }
    Version ablegenDatei(const std::string& name, const std::string& dateiPfad, Zeit jetzt, const std::string& kommentar = "") {
        std::string inhalt; if (!dateiLesen(dateiPfad, inhalt)) return Version{}; return ablegen(name, inhalt, jetzt, kommentar);
    }
    const std::vector<Version>* versionen(const std::string& name) const { auto it = index.find(name); return it == index.end() ? nullptr : &it->second; }
    const Version* version(const std::string& name, int nummer = 0) const {
        const std::vector<Version>* vs = versionen(name); if (!vs || vs->empty()) return nullptr;
        if (nummer <= 0) return &vs->back();
        for (const Version& v : *vs) if (v.nummer == nummer) return &v;
        return nullptr;
    }
    // V3: Inhalt abrufen
    bool abrufen(const std::string& name, std::string& aus, int nummer = 0) const {
        const Version* v = version(name, nummer); if (!v) return false;
        return dateiLesen(objektPfad(v->hash), aus);
    }
    bool abrufenNachDatei(const std::string& name, const std::string& dateiPfad, int nummer = 0) const {
        std::string i; if (!abrufen(name, i, nummer)) return false; return dateiSchreiben(dateiPfad, i);
    }
    // V2: Namen entfernen (Objekte bleiben)
    bool entfernen(const std::string& name) { return index.erase(name) > 0; }
    // V4: Snapshot = fester Satz (Name -> Version); ohne Angabe: die neuesten
    bool snapshot(const std::string& snapName, const std::vector<std::string>& namen) {
        std::map<std::string, int> s;
        for (const std::string& n : namen) { const Version* v = version(n); if (!v) return false; s[n] = v->nummer; }
        snapshots[snapName] = s; return true;
    }
    bool ausSnapshot(const std::string& snapName, const std::string& name, std::string& aus) const {
        auto it = snapshots.find(snapName); if (it == snapshots.end()) return false;
        auto v = it->second.find(name); if (v == it->second.end()) return false;
        return abrufen(name, aus, v->second);
    }
    // V5: Zusammenfuehren mit einem anderen Tresor (dessen Objekte kopieren)
    int zusammenfuehren(const Vault& fremd) {
        int neu = 0;
        for (auto& kv : fremd.index) {
            std::vector<Version>& mein = index[kv.first];
            for (const Version& fv : kv.second) {
                bool da = false; for (const Version& mv : mein) if (mv.hash == fv.hash) { da = true; break; }
                if (da) continue;
                std::string inhalt; if (!fremd.dateiLesen(fremd.objektPfad(fv.hash), inhalt)) continue;
                if (!existiert(objektPfad(fv.hash))) dateiSchreiben(objektPfad(fv.hash), inhalt);
                Version v = fv; mein.push_back(v); ++neu;
            }
            std::sort(mein.begin(), mein.end(), [](const Version& a, const Version& b) { return a.zeit != b.zeit ? a.zeit < b.zeit : a.geraet < b.geraet; });
            for (std::size_t i = 0; i < mein.size(); ++i) mein[i].nummer = (int)i + 1;    // Nummern neu nach Zeit
        }
        for (auto& kv : fremd.snapshots) if (!snapshots.count(kv.first)) snapshots[kv.first] = kv.second;
        return neu;
    }
    // Objekte loeschen, auf die keine Version mehr zeigt
    int aufraeumen() {
        std::map<std::string, bool> gebraucht; for (auto& kv : index) for (const Version& v : kv.second) gebraucht[v.hash] = true;
        int weg = 0;
        for (auto& kv : alleObjekte()) if (!gebraucht.count(kv)) { std::remove(objektPfad(kv).c_str()); ++weg; }
        return weg;
    }
    std::vector<std::string> alleObjekte() const;   // plattformabhaengig, unten

    json zuJson() const {
        json j; j["format"] = "filevault"; j["version"] = 1; json idx = json::object();
        for (auto& kv : index) { json vs = json::array(); for (const Version& v : kv.second) { json o; o["nummer"] = v.nummer; o["hash"] = v.hash; o["zeit"] = v.zeit; o["geraet"] = v.geraet; o["kommentar"] = v.kommentar; o["groesse"] = v.groesse; vs.push_back(o); } idx[kv.first] = vs; }
        j["index"] = idx; j["snapshots"] = snapshots; return j;
    }
    void ausJson(const json& j) {
        index.clear(); snapshots.clear();
        // Festes Objekt: begin() und end() auf zwei Temporaeren von j.value()
        // waeren zwei verschiedene Container -- undefiniertes Verhalten.
        const json idx = j.value("index", json::object());
        for (auto it = idx.begin(); it != idx.end(); ++it) {
            std::vector<Version> vs; for (auto& o : it.value()) { Version v; v.nummer = o.value("nummer", 0); v.hash = o.value("hash", ""); v.zeit = o.value("zeit", (Zeit)0); v.geraet = o.value("geraet", ""); v.kommentar = o.value("kommentar", ""); v.groesse = o.value("groesse", (std::size_t)0); vs.push_back(v); }
            index[it.key()] = vs; }
        if (j.contains("snapshots")) for (auto it = j["snapshots"].begin(); it != j["snapshots"].end(); ++it) { std::map<std::string, int> s; for (auto v = it.value().begin(); v != it.value().end(); ++v) s[v.key()] = v.value().get<int>(); snapshots[it.key()] = s; }
    }
};
} // namespace filevault

#if defined(_WIN32)
  #include <windows.h>
  inline std::vector<std::string> filevault::Vault::alleObjekte() const {
      std::vector<std::string> v; WIN32_FIND_DATAA fd; HANDLE h = FindFirstFileA((ordner + "/objekte/*").c_str(), &fd);
      if (h == INVALID_HANDLE_VALUE) return v;
      do { std::string n = fd.cFileName; if (n != "." && n != "..") v.push_back(n); } while (FindNextFileA(h, &fd)); FindClose(h); return v; }
#else
  #include <dirent.h>
  inline std::vector<std::string> filevault::Vault::alleObjekte() const {
      std::vector<std::string> v; DIR* d = opendir((ordner + "/objekte").c_str()); if (!d) return v;
      while (dirent* e = readdir(d)) { std::string n = e->d_name; if (n != "." && n != "..") v.push_back(n); } closedir(d); return v; }
#endif
