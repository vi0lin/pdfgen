#include "filevault.h"
#include <cstdio>
using namespace filevault;
static int fehler = 0;
#define PRUEF(bed, text) do { bool ok = (bed); printf("  %s %s\n", ok ? "OK " : "FEHLER", text); if (!ok) fehler++; } while (0)
static void wegraeumen(const std::string& d) { std::string c = "rm -rf '" + d + "'"; (void)!system(c.c_str()); }

int main() {
    const std::string D = "/tmp/fvtest"; wegraeumen(D);
    Vault v; PRUEF(v.oeffnen(D + "/a", "laptop"), "Tresor angelegt");
    printf("--- V1/V2/V3: Versionen ---\n");
    Version v1 = v.ablegen("pdfgen/bewerbung.txt", "Sehr geehrte Damen und Herren,\n", 1000, "erste Fassung");
    Version v1b = v.ablegen("pdfgen/bewerbung.txt", "Sehr geehrte Damen und Herren,\n", 1001);
    PRUEF(v1.nummer == 1 && v1b.nummer == 1 && v1b.hash == v1.hash, "V1: gleicher Inhalt erneut -> keine neue Version");
    Version v2 = v.ablegen("pdfgen/bewerbung.txt", "Sehr geehrte Frau Muster,\n", 2000, "Anrede geaendert");
    Version k1 = v.ablegen("kunden.json", "[{\"name\":\"Muster\"}]", 1500);
    PRUEF(v2.nummer == 2 && v.versionen("pdfgen/bewerbung.txt")->size() == 2 && v.version("pdfgen/bewerbung.txt")->kommentar == "Anrede geaendert", "zweite Version mit Kommentar, neueste ist v2");
    std::string i; PRUEF(v.abrufen("pdfgen/bewerbung.txt", i, 1) && i == "Sehr geehrte Damen und Herren,\n", "V3: alte Version byteidentisch abrufbar");
    PRUEF(v.abrufen("pdfgen/bewerbung.txt", i) && i == "Sehr geehrte Frau Muster,\n", "ohne Nummer: die neueste");
    PRUEF(v.alleObjekte().size() == 3, "drei unterschiedliche Inhalte = drei Objekte");
    printf("--- V4: Snapshot (Dateiversionen an einen Lauf koppeln) ---\n");
    PRUEF(v.snapshot("Rechnung Oktober", { "pdfgen/bewerbung.txt", "kunden.json" }), "Snapshot aus den neuesten Versionen");
    v.ablegen("pdfgen/bewerbung.txt", "Sehr geehrte Frau Muster,\nneuer Absatz\n", 3000, "Absatz ergaenzt");
    v.ablegen("kunden.json", "[{\"name\":\"Muster\"},{\"name\":\"Neu\"}]", 3100);
    PRUEF(v.ausSnapshot("Rechnung Oktober", "pdfgen/bewerbung.txt", i) && i == "Sehr geehrte Frau Muster,\n", "Snapshot liefert die damalige Fassung, obwohl es Neuere gibt");
    PRUEF(v.ausSnapshot("Rechnung Oktober", "kunden.json", i) && i.find("Neu") == std::string::npos, "auch die zweite Datei des Satzes bleibt auf dem alten Stand");
    printf("--- Persistenz ---\n");
    PRUEF(v.speichern(), "Index gespeichert");
    Vault w; w.oeffnen(D + "/a", "laptop");
    PRUEF(w.versionen("pdfgen/bewerbung.txt")->size() == 3 && w.snapshots.count("Rechnung Oktober") && w.abrufen("kunden.json", i, 1) && i == "[{\"name\":\"Muster\"}]", "wieder geoeffnet: Versionen, Snapshots, Inhalte da");
    printf("--- V5: Zusammenfuehren (Abgleich zwischen Geraeten) ---\n");
    Vault h; h.oeffnen(D + "/b", "handy");
    h.ablegen("pdfgen/bewerbung.txt", "Sehr geehrte Damen und Herren,\n", 1000);          // dieselbe v1 wie der Laptop
    h.ablegen("pdfgen/bewerbung.txt", "Handy-Fassung\n", 2500, "unterwegs geaendert");   // zwischen v2 und v3 des Laptops
    h.ablegen("fotos/liste.txt", "IMG_1.jpg\nIMG_2.jpg\n", 2600);
    int neu = w.zusammenfuehren(h);
    PRUEF(neu == 2, "zwei neue Versionen uebernommen (gemeinsame v1 nicht doppelt)");
    const std::vector<Version>* vs = w.versionen("pdfgen/bewerbung.txt");
    PRUEF(vs->size() == 4 && (*vs)[2].kommentar == "unterwegs geaendert" && (*vs)[3].nummer == 4, "Handy-Fassung nach Zeit einsortiert, Nummern neu vergeben (1..4)");
    PRUEF(w.abrufen("fotos/liste.txt", i) && i == "IMG_1.jpg\nIMG_2.jpg\n" && w.abrufen("pdfgen/bewerbung.txt", i, 3) && i == "Handy-Fassung\n", "Objekte kopiert, Inhalte abrufbar");
    PRUEF(w.ausSnapshot("Rechnung Oktober", "pdfgen/bewerbung.txt", i) && i == "Sehr geehrte Frau Muster,\n", "Snapshot zeigt nach dem Zusammenfuehren noch auf denselben Inhalt (Nummern verschoben, Hash nicht)");
    printf("--- Aufraeumen ---\n");
    w.entfernen("fotos/liste.txt"); int weg = w.aufraeumen();
    PRUEF(weg == 1 && !w.abrufen("fotos/liste.txt", i), "Name entfernt, unbenutztes Objekt geloescht");
    wegraeumen(D);
    printf("\n%s\n", fehler ? "### FEHLER ###" : "ALLE PRUEFUNGEN BESTANDEN");
    return fehler;
}
