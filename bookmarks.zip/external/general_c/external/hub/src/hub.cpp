// ===========================================================================
// hub -- der Server: Sammelpunkt fuer Abgleich, Anwesenheit und Rueckfall.
//
//   hub [-p PORT] [-s GEHEIMNIS] [-d DATEI] [-n NAME] [-z ZEITZONE_STD] [-i SEK]
//
// Was er tut (alles ueber den Nachrichtenrahmen J/j von netlink):
//   "anfrage"/"delta"/"bestaetigung"   timeline-Abgleich (sync.h) -- Aenderungen
//                                       eines Clients gehen an alle anderen, auch
//                                       wenn die sich nie direkt sehen
//   "aktion"                            eine actionkit-Aktion hier ausfuehren
//                                       (Fernausfuehrer der Clients)
//   "wer"                               Antwort: welche Geraete gerade angemeldet
//                                       sind, mit letztem Kontakt
//   "ping"                              Antwort "pong" mit Serverzeit
// Rueckfall: der Planer laeuft auch hier. Ist ein Aktions-Vorkommen faellig
// und hat es kein Client innerhalb der Frist gestartet (Startvermerk fehlt
// beim naechsten Abgleich), startet der hub es selbst -- lokal.
// Speichert timeline.json regelmaessig und beim Beenden.
// ===========================================================================
#include "xbm_cmdchan.h"
#include "fernausfuehrer.h"
#include "planer.h"
#include "sync.h"
#include <chrono>
#include <csignal>
#include <cstdio>
#include <fstream>
#include <thread>
using json = nlohmann::json;

static volatile std::sig_atomic_t g_ende = 0;
static void signal_ende(int) { g_ende = 1; }

int main(int argc, char** argv) {
    std::uint16_t port = 4711; std::string geheimnis = "geheim", datei = "hub-timeline.json", name = "hub"; timeline::Zeit tz = 0; int intervall = 30;
    timeline::Zeit rueckfallFrist = 120;   // so lange darf ein Client Zeit haben, ein Vorkommen zu starten
    for (int i = 1; i < argc; ++i) { std::string a = argv[i]; auto w = [&]{ return std::string(i + 1 < argc ? argv[++i] : ""); };
        if (a == "-p") port = (std::uint16_t)atoi(w().c_str()); else if (a == "-s") geheimnis = w(); else if (a == "-d") datei = w();
        else if (a == "-n") name = w(); else if (a == "-z") tz = (timeline::Zeit)(atof(w().c_str()) * 3600); else if (a == "-i") intervall = atoi(w().c_str());
        else if (a == "-f") rueckfallFrist = atoi(w().c_str());
        else { fprintf(stderr, "hub: unbekannte Option %s\n", a.c_str()); return 2; } }

    timeline::Speicher s; s.geraet = name;
    { std::ifstream f(datei); if (f) { json j = json::parse(f, nullptr, false); std::string err; if (j.is_discarded() || !timeline::laden(s, j, &err)) { fprintf(stderr, "hub: %s: %s\n", datei.c_str(), err.c_str()); return 1; } s.geraet = name; } }
    auto speichern = [&]{ std::ofstream f(datei + ".neu"); f << timeline::speichern(s).dump(1); f.close(); std::remove(datei.c_str()); std::rename((datei + ".neu").c_str(), datei.c_str()); };

    std::map<std::string, timeline::Partner> partner;
    std::map<std::string, timeline::Zeit> zuletztGesehen;
    auto jetzt = []{ return (timeline::Zeit)std::time(nullptr); };

    // Rueckfall-Planer: startet nur, was laenger als die Frist unbeansprucht ist
    netlink::Fernausfuehrer fa; fa.lokalerName = name;
    jobflow::Planer planer; planer.speicher = &s; planer.tz = tz; planer.ausfuehrer = &fa.ausfuehrer;
    planer.toleranzSek = rueckfallFrist; planer.zuletztGeprueft = jetzt() - rueckfallFrist;
    planer.onLaufStart = [&](const jobflow::Lauf& l) { printf("[%s] Rueckfall: starte '%s' (Vorkommen %lld)\n", name.c_str(), l.queue.name.c_str(), (long long)l.vorkommen); fflush(stdout); };

    XbmCmdServer srv;
    srv.onNachricht = [&](const std::string& text, const std::string& adresse) -> std::string {
        json ein = json::parse(text, nullptr, false); if (!ein.is_object()) return "";
        const std::string typ = ein.value("typ", ""), von = ein.value("von", adresse);
        zuletztGesehen[von] = jetzt();
        if (typ == "anfrage" || typ == "delta" || typ == "bestaetigung") {
            timeline::Partner& p = partner[von]; p.geraet = von;
            json aus = timeline::verarbeiten(s, ein, p);
            return aus.is_null() ? std::string() : aus.dump();
        }
        if (typ == "aktion") return netlink::serverHaken(text, adresse);
        if (typ == "wer") { json aus; aus["typ"] = "wer"; json l = json::array();
            for (auto& kv : zuletztGesehen) { json g; g["geraet"] = kv.first; g["vorSek"] = jetzt() - kv.second; l.push_back(g); }
            aus["geraete"] = l; aus["server"] = name; return aus.dump(); }
        if (typ == "ping") { json aus; aus["typ"] = "pong"; aus["zeit"] = jetzt(); aus["server"] = name; return aus.dump(); }
        return "";
    };
    if (!srv.Start(port, geheimnis)) { fprintf(stderr, "hub: Port %u belegt\n", port); return 1; }
    printf("[%s] laeuft auf Port %u, Datei %s, %zu Events\n", name.c_str(), srv.Port(), datei.c_str(), s.events.size()); fflush(stdout);
    std::signal(SIGINT, signal_ende); std::signal(SIGTERM, signal_ende);

    timeline::Zeit letzteSicherung = jetzt(); std::uint64_t letzterSeq = s.seq;
    while (!g_ende) {
        srv.Poll();
        const timeline::Zeit t = jetzt();
        // Rueckfall-Planer: einmal je Sekunde reicht
        static timeline::Zeit letzterTakt = 0;
        if (t != letzterTakt) { letzterTakt = t; planer.schritt(t); for (auto& l : planer.laeufe) fa.abholen(l.queue, t); }
        if (t - letzteSicherung >= intervall && s.seq != letzterSeq) { speichern(); letzteSicherung = t; letzterSeq = s.seq; }
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
    speichern(); srv.Stop();
    printf("[%s] beendet, gespeichert\n", name.c_str());
    return 0;
}
