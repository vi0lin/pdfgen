// hubclient -- schickt EIN JSON-Paket (stdin) an den hub und gibt die Antwort aus.
//   hubclient HOST PORT GEHEIMNIS < paket.json
// Fuer Scripts und Tests; die App benutzt die Verbindung direkt (netlink).
#include "xbm_cmdchan.h"
#include <chrono>
#include <cstdio>
#include <iostream>
#include <thread>
int main(int argc, char** argv) {
    if (argc < 4) { fprintf(stderr, "hubclient HOST PORT GEHEIMNIS < paket.json\n"); return 2; }
    std::string paket((std::istreambuf_iterator<char>(std::cin)), std::istreambuf_iterator<char>());
    XbmCmdClient cl; if (!cl.Connect(argv[1], (std::uint16_t)atoi(argv[2]), argv[3])) { fprintf(stderr, "keine Verbindung\n"); return 1; }
    for (int i = 0; i < 200 && cl.GetStatus() != XbmCmdStatus::Bereit; ++i) { cl.Poll(); std::this_thread::sleep_for(std::chrono::milliseconds(10)); }
    if (cl.GetStatus() != XbmCmdStatus::Bereit) { fprintf(stderr, "Anmeldung fehlgeschlagen\n"); return 1; }
    std::string antwort; bool da = false;
    cl.Nachricht(paket, [&](const std::string& a) { antwort = a; da = true; });
    for (int i = 0; i < 500 && !da; ++i) { cl.Poll(); std::this_thread::sleep_for(std::chrono::milliseconds(10)); }
    if (!da) { fprintf(stderr, "keine Antwort\n"); return 1; }
    printf("%s\n", antwort.c_str()); cl.Disconnect(); return 0;
}
