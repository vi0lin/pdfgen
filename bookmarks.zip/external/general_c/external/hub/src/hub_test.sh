#!/bin/bash
# Ende-zu-Ende: hub + zwei Clients (timeline-CLI), Abgleich NUR ueber den Server.
HUB=$1; HC=$2; TL=$3; PORT=$((20000 + RANDOM % 10000)); D=/tmp/hubtest; rm -rf $D; mkdir -p $D
fehler=0; pruef(){ if [ "$1" = "$2" ]; then echo "  OK  $3"; else echo "  FEHLER $3 (ist: '$1', soll: '$2')"; fehler=$((fehler+1)); fi; }
$HUB -p $PORT -s pw -d $D/hub.json -n hub -z 2 -i 1 -f 2 > $D/hub.log 2>&1 & HUBPID=$!
sleep 0.5; grep -q "laeuft auf Port" $D/hub.log; pruef "$?" "0" "hub laeuft"
A="$TL -d $D/a.json -z 2 -g laptop"; B="$TL -d $D/b.json -z 2 -g handy"
# Laptop legt an und schickt sein Delta an den hub; Bestaetigung anwenden
$A neu "Zahnarzt" 2026-10-05T09:00 60 >/dev/null; $A neu "Standup" 2026-10-06T09:00 15 >/dev/null
$A sync-delta hub | $HC 127.0.0.1 $PORT pw > $D/p1.json; $A sync-anwenden hub < $D/p1.json >/dev/null
typ=$(python3 -c "import json;print(json.load(open('$D/p1.json'))['typ'])"); pruef "$typ" "bestaetigung" "hub bestaetigt das Delta des Laptops"
# Handy fragt den hub -- ohne den Laptop je zu sehen
$B sync-anfrage hub | $HC 127.0.0.1 $PORT pw > $D/p2.json; $B sync-anwenden hub < $D/p2.json | $HC 127.0.0.1 $PORT pw >/dev/null
n=$($B liste 2026-10-05 2026-10-07 | wc -l); pruef "$n" "2" "Handy hat beide Events vom hub"
# Handy aendert -> hub -> Laptop
sleep 1; $B aendern 1 titel "Zahnarzt (Handy)" >/dev/null
$B sync-delta hub | $HC 127.0.0.1 $PORT pw > $D/p3.json; $B sync-anwenden hub < $D/p3.json >/dev/null
$A sync-anfrage hub | $HC 127.0.0.1 $PORT pw > $D/p4.json; $A sync-anwenden hub < $D/p4.json | $HC 127.0.0.1 $PORT pw >/dev/null
t=$($A zeige 1 | head -1 | grep -c "(Handy)"); pruef "$t" "1" "Aenderung des Handys kommt ueber den hub beim Laptop an"
# Anwesenheit
w=$(echo '{"typ":"wer","von":"tablet"}' | $HC 127.0.0.1 $PORT pw | python3 -c "import json,sys;d=json.load(sys.stdin);print(','.join(sorted(g['geraet'] for g in d['geraete'])))"); pruef "$w" "handy,laptop,tablet" "'wer' listet alle gesehenen Geraete"
p=$(echo '{"typ":"ping"}' | $HC 127.0.0.1 $PORT pw | python3 -c "import json,sys;print(json.load(sys.stdin)['typ'])"); pruef "$p" "pong" "ping/pong"
# Rueckfall: Aktions-Event, das in 3 s faellig ist; kein Client startet es -> hub tut es (Frist 2 s)
faellig=$(date -d "+3 seconds" +%s)
id=$($A neu "Rueckfallprobe" $faellig); $A aendern $id aktion Gibtsnicht >/dev/null
$A sync-delta hub | $HC 127.0.0.1 $PORT pw > $D/p5.json; $A sync-anwenden hub < $D/p5.json >/dev/null
sleep 7; grep -q "Rueckfall: starte 'Rueckfallprobe'" $D/hub.log; pruef "$?" "0" "hub startet die unbeanspruchte Aktion nach der Frist selbst"
# Startvermerk des hub kommt beim Laptop an
$A sync-anfrage hub | $HC 127.0.0.1 $PORT pw > $D/p6.json; $A sync-anwenden hub < $D/p6.json >/dev/null
g=$(python3 -c "import json;print(len(json.load(open('$D/a.json'))['journal']['gestartet']))"); pruef "$g" "1" "Startvermerk des hub beim Laptop angekommen (kein Doppelstart)"
# Beenden + Persistenz
kill -INT $HUBPID; wait $HUBPID 2>/dev/null; e=$(python3 -c "import json;print(len(json.load(open('$D/hub.json'))['events']))"); pruef "$e" "3" "hub hat beim Beenden gespeichert (3 Events)"
echo; [ $fehler = 0 ] && echo "ALLE PRUEFUNGEN BESTANDEN" || { echo "### $fehler FEHLER ###"; exit 1; }
