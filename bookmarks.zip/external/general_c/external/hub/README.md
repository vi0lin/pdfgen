# hub -- der Server

Sammelpunkt fuer Abgleich, Anwesenheit und Rueckfall. Laeuft auf einem VPS
im Internet oder im eigenen Netz; die Clients sprechen ihn ueber netlink
(TCP, Geheimnis) mit dem Nachrichtenrahmen an.

    hub [-p PORT] [-s GEHEIMNIS] [-d DATEI] [-n NAME] [-z ZEITZONE_STD] [-i SICHERN_SEK] [-f RUECKFALL_SEK]

- **Abgleich**: `anfrage` / `delta` / `bestaetigung` (timeline/sync.h). Was ein
  Client schickt, geht an alle anderen -- auch wenn die sich nie sehen; wer
  offline war, holt beim naechsten Kontakt alles nach.
- **Anwesenheit**: `wer` liefert alle Geraete mit letztem Kontakt; `ping`/`pong`.
- **Aktionen**: `aktion` fuehrt eine actionkit-Aktion auf dem hub aus
  (Fernausfuehrer der Clients, Ziel "hub").
- **Rueckfall**: ist ein Aktions-Vorkommen faellig und hat es nach der Frist
  (-f, Vorgabe 120 s) kein Client gestartet, startet der hub es selbst und
  vermerkt das -- der Vermerk erreicht alle Clients, kein Doppelstart.
- Speichert die Datei regelmaessig und beim Beenden (SIGINT/SIGTERM).

`hubclient HOST PORT GEHEIMNIS < paket.json` schickt ein Paket und gibt die
Antwort aus -- fuer Scripts und den Ende-zu-Ende-Test (`src/hub_test.sh`).

    cmake -B build -S . && cmake --build build && ctest --test-dir build
    # braucht netlink, timeline, jobflow, actionkit als Geschwisterordner
    # oder als bereits eingebundene Ziele des Elternprojekts

Neustart bei Absturz: als systemd-Dienst mit `Restart=always` betreiben.

