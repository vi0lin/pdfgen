#pragma once
// ===========================================================================
// actionkit/scriptaktion.h -- ein Script (Bash, Python, alles Ausfuehrbare)
// als Aktion registrieren.
//
// VERTRAG mit dem Script:
//   stdin   ein JSON-Objekt mit den Eingaengen         {"quelle":"r.txt"}
//   stdout  ein JSON-Objekt mit den Ausgaengen          {"pdfPfad":"r.pdf"}
//           (oder leer / kein JSON: dann {"stdout": "<Text>"})
//   exit 0 = ok; sonst Fehler, stderr wird zur Fehlermeldung.
//
// Beschreibung: das Script kann mit --beschreibung aufgerufen werden und
// seine Parameter als JSON liefern (Format wie Aktion::beschreibung());
// sonst gilt: ein Eingang "eingabe" (json) und ein Ausgang "ausgabe" (json).
//
// Nur POSIX (popen); Windows folgt ueber netlink (dort laeuft der Befehl
// ohnehin auf dem Zielhost).
// ===========================================================================
#include "actionkit.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>

namespace actionkit {

inline std::string tempDateiName(const char* stamm) {
    const char* t = std::getenv("TMPDIR"); std::string d = t ? t : "/tmp";
    return d + "/" + stamm + "." + std::to_string((long long)std::rand());
}

// Befehl mit stdin-Text ausfuehren; liefert Exitcode, fuellt stdout/stderr.
inline int ausfuehren(const std::string& befehl, const std::string& stdinText, std::string& out, std::string& err) {
    const std::string fin = tempDateiName("ak-in"), ferr = tempDateiName("ak-err");
    { std::ofstream f(fin); f << stdinText; }
    const std::string cmd = "(" + befehl + ") < '" + fin + "' 2> '" + ferr + "'";
    FILE* p = popen(cmd.c_str(), "r");
    if (!p) { err = "popen fehlgeschlagen"; return -1; }
    char buf[4096]; size_t n; out.clear();
    while ((n = fread(buf, 1, sizeof buf, p)) > 0) out.append(buf, n);
    int rc = pclose(p);
    { std::ifstream f(ferr); err.assign((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>()); }
    std::remove(fin.c_str()); std::remove(ferr.c_str());
    return WIFEXITED(rc) ? WEXITSTATUS(rc) : -1;
}

// Script als Aktion registrieren. <befehl> ist die Kommandozeile (z.B.
// "bash scripts/pdf.sh" oder "python3 tools/x.py").
inline bool scriptRegistrieren(const std::string& name, const std::string& befehl, const std::string& hilfe = "") {
    Aktion a; a.name = name; a.hilfe = hilfe;
    // Parameter aus --beschreibung, sonst Standard
    std::string out, err;
    if (ausfuehren(befehl + " --beschreibung", "", out, err) == 0) {
        json b = json::parse(out, nullptr, false);
        if (b.is_object() && b.contains("parameter"))
            for (auto& p : b["parameter"]) {
                Parameter x; x.name = p.value("name", ""); x.typ = p.value("typ", "json"); x.hilfe = p.value("hilfe", "");
                x.eingang = p.value("richtung", "ein") == "ein"; x.pflicht = p.value("pflicht", true);
                if (p.contains("vorgabe")) x.vorgabe = p["vorgabe"];
                if (!x.name.empty()) a.parameter.push_back(x);
            }
        if (a.hilfe.empty()) a.hilfe = b.value("hilfe", "");
    }
    if (a.parameter.empty()) {
        a.parameter.push_back(einVorgabe<json>("eingabe", json::object()).p);
        a.parameter.push_back(aus<json>("ausgabe").p);
    }
    a.rumpf = [befehl](const json& ein) {
        Ergebnis r; std::string out, err;
        int rc = ausfuehren(befehl, ein.dump(), out, err);
        if (rc != 0) { r.fehler = err.empty() ? ("Exit " + std::to_string(rc)) : err; return r; }
        json j = json::parse(out, nullptr, false);
        r.ausgaben = j.is_object() ? j : json{{"stdout", out}};
        r.ok = true; return r;
    };
    Aktionen::registrieren(a);
    return true;
}

} // namespace actionkit
