#include "actionkit.h"
#include <cstdio>
using namespace actionkit;
static int fehler = 0;
#define PRUEF(bed, text) do { bool ok = (bed); printf("  %s %s\n", ok ? "OK " : "FEHLER", text); if (!ok) fehler++; } while (0)

// ---- Beispielaktionen, so wie sie in bookmarks stehen wuerden ----
AKTION(GeneratePDF, "Erzeugt eine PDF aus der Quelle und listet die Empfaenger",
       EIN_H(std::string, quelle, "pdfgen-Quelldatei"), EIN(std::vector<std::string>, emails),
       EIN_VORGABE(bool, senden, false), EIN_VORGABE(int, kopien, 1),
       AUS(std::string, pdfPfad), AUS(int, anzahl)) {
    HOLE(std::string, quelle); HOLE(std::vector<std::string>, emails); HOLE(bool, senden); HOLE(int, kopien);
    if (quelle.empty()) { fehler = "Quelle ist leer"; return false; }
    SETZE(pdfPfad, quelle + ".pdf");
    SETZE(anzahl, (int)emails.size() * kopien + (senden ? 100 : 0));
    return true;
}
AKTION(Addiere, "Summe zweier Zahlen", EIN(double, a), EIN(double, b), AUS(double, summe)) {
    HOLE(double, a); HOLE(double, b); SETZE(summe, a + b); return true;
}

#ifndef _WIN32
static int scriptTests();
#endif
int main() {
    printf("--- Registry und Beschreibung ---\n");
    PRUEF(Aktionen::alle().size() == 2 && Aktionen::finde("GeneratePDF") && Aktionen::finde("Addiere"), "beide Aktionen registriert");
    json k = Aktionen::katalog();
    PRUEF(k.size() == 2 && k[1]["parameter"].size() == 6 && k[1]["parameter"][2]["pflicht"] == false && k[1]["parameter"][2]["vorgabe"] == false,
          "Katalog beschreibt Parameter mit Typ, Pflicht und Vorgabe (fuer UI/Node-Editor)");
    PRUEF(k[1]["parameter"][0]["hilfe"] == "pdfgen-Quelldatei" && k[1]["parameter"][4]["richtung"] == "aus", "Hilfetext und Richtung im Katalog");

    printf("--- JSON-Aufruf ---\n");
    const Aktion* g = Aktionen::finde("GeneratePDF");
    Ergebnis e = g->aufrufen(json{{"quelle","bewerbung.txt"},{"emails",{"a@x","b@x"}}});
    PRUEF(e.ok && e.ausgaben["pdfPfad"] == "bewerbung.txt.pdf" && e.ausgaben["anzahl"] == 2, "Pflichteingaenge reichen, Vorgaben ergaenzt (senden=false, kopien=1)");
    e = g->aufrufen(json{{"quelle","b.txt"},{"emails",json::array()},{"senden",true},{"kopien",3}});
    PRUEF(e.ok && e.ausgaben["anzahl"] == 100, "eigene Werte statt Vorgaben");
    e = g->aufrufen(json{{"emails",json::array()}});
    PRUEF(!e.ok && e.fehler.find("quelle") != std::string::npos, ("Pflichteingang fehlt -> klarer Fehler: " + e.fehler).c_str());
    e = g->aufrufen(json{{"quelle",5},{"emails",json::array()}});
    PRUEF(!e.ok && e.fehler.find("Typ") != std::string::npos, ("falscher Typ -> klarer Fehler: " + e.fehler).c_str());
    e = g->aufrufen(json{{"quelle","x"},{"emails",json::array()},{"farbe","rot"}});
    PRUEF(!e.ok && e.fehler.find("unbekannter Eingang") != std::string::npos, "unbekannter Eingang wird abgewiesen (Tippfehler faellt sofort auf)");
    e = g->aufrufen(json{{"quelle",""},{"emails",json::array()}});
    PRUEF(!e.ok && e.fehler == "Quelle ist leer", "Rumpf meldet eigenen Fehler");

    printf("--- CLI-Aufruf ---\n");
    e = ausArgv({"GeneratePDF", "quelle=r.txt", "emails=a@x,b@x,c@x", "senden=ja", "kopien=2"});
    PRUEF(e.ok && e.ausgaben["anzahl"] == 106 && e.ausgaben["pdfPfad"] == "r.txt.pdf", "name=wert-Argumente nach Typ gedeutet (Liste, bool, int)");
    e = ausArgv({"Addiere", "a=1.5", "b=2"});
    PRUEF(e.ok && e.ausgaben["summe"] == 3.5, "double aus der Kommandozeile");
    e = ausArgv({"Gibtsnicht"});
    PRUEF(!e.ok && e.fehler.find("unbekannte Aktion") != std::string::npos, "unbekannte Aktion");
    e = ausArgv({"Addiere", "a=1", "c=2"});
    PRUEF(!e.ok && e.fehler.find("unbekannter Eingang") != std::string::npos, "unbekannter Eingang auf der Kommandozeile");

    printf("--- Verkettung: Ausgang -> Eingang (Vorstufe Nodes) ---\n");
    Ergebnis e1 = ausArgv({"Addiere", "a=2", "b=3"});
    Ergebnis e2 = Aktionen::finde("Addiere")->aufrufen(json{{"a", e1.ausgaben["summe"]},{"b", 10}});
    PRUEF(e2.ok && e2.ausgaben["summe"] == 15, "Ausgabe einer Aktion als Eingabe der naechsten");

#ifndef _WIN32
    scriptTests();
#endif
    printf("\n%s\n", fehler ? "### FEHLER ###" : "ALLE PRUEFUNGEN BESTANDEN");
    return fehler;
}
// ---- Scripts als Aktionen (nur POSIX) ----
#ifndef _WIN32
#include "scriptaktion.h"
static int scriptTests() {
    printf("--- Scripts als Aktionen ---\n");
    // Bash-Script mit --beschreibung
    const std::string sk = tempDateiName("skript") + ".sh";
    { std::ofstream f(sk); f <<
        "#!/bin/bash\n"
        "if [ \"$1\" = --beschreibung ]; then echo '{\"hilfe\":\"verdoppelt\",\"parameter\":[{\"name\":\"zahl\",\"typ\":\"int\"},{\"name\":\"doppelt\",\"typ\":\"int\",\"richtung\":\"aus\"}]}'; exit 0; fi\n"
        "z=$(python3 -c 'import json,sys;print(json.load(sys.stdin)[\"zahl\"])')\n"
        "[ \"$z\" -lt 0 ] && { echo 'negativ nicht erlaubt' >&2; exit 2; }\n"
        "echo \"{\\\"doppelt\\\": $((z*2))}\"\n"; }
    scriptRegistrieren("Verdoppeln", "bash " + sk);
    const Aktion* v = Aktionen::finde("Verdoppeln");
    PRUEF(v && v->parameter.size() == 2 && v->parameter[0].typ == "int" && v->hilfe == "verdoppelt", "Script beschreibt sich selbst (--beschreibung)");
    Ergebnis e = ausArgv({"Verdoppeln", "zahl=21"});
    PRUEF(e.ok && e.ausgaben["doppelt"] == 42, "Bash-Script: Eingang per stdin-JSON, Ausgang per stdout-JSON");
    e = ausArgv({"Verdoppeln", "zahl=-1"});
    PRUEF(!e.ok && e.fehler.find("negativ") != std::string::npos, "Exit != 0 -> stderr wird zur Fehlermeldung");
    e = ausArgv({"Verdoppeln", "zahl=x"});
    PRUEF(!e.ok && e.fehler.find("keine Zahl") != std::string::npos, "unlesbare Zahl auf der Kommandozeile -> Fehler statt Absturz");
    // Script ohne --beschreibung: Standardparameter
    scriptRegistrieren("Echo", "cat");
    e = Aktionen::finde("Echo")->aufrufen(json{{"eingabe", json{{"a",1}}}});
    PRUEF(e.ok && e.ausgaben["eingabe"]["a"] == 1, "Script ohne Beschreibung: eingabe/ausgabe als json, stdout-JSON wird durchgereicht");
    std::remove(sk.c_str());
    return 0;
}
#endif
