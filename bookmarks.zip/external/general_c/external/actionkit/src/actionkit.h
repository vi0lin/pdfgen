#pragma once
// ===========================================================================
// actionkit -- AKTIONEN AUS FUNKTIONSKOEPFEN.
//
// Eine Aktion ist eine Funktion mit benannten, typisierten Ein- und
// Ausgaengen. Registriert wird sie mit einer Zeile:
//
//   AKTION(GeneratePDF, "Erzeugt eine PDF und versendet sie",
//          EIN(std::vector<std::string>, namen), EIN(std::vector<std::string>, emails),
//          AUS(std::string, pdfPfad))
//   {  // Funktionsrumpf: Eingaenge sind Variablen, Ausgaenge Referenzen
//      pdfPfad = "...";  return true;
//   }
//
// Danach ist sie ueberall gleich erreichbar:
//   - Registry:  Aktionen::alle(), Aktionen::finde("GeneratePDF")   -- fuer UI/Nodes
//   - JSON:      aktion.aufrufen({"namen":[...],"emails":[...]})   -> {"pdfPfad":"..."}
//   - CLI:       ausArgv({"GeneratePDF","namen=a,b","emails=x@y"}) -> JSON-Ausgabe
//   - Beschreibung: jede Aktion beschreibt ihre Parameter (Name, Typ, Pflicht,
//     Vorgabe, Hilfetext) -- daraus kann eine UI Felder bauen (Checkbox fuer
//     bool, Zahlenfeld fuer int/double, Auswahl fuer enum-artige Listen).
//
// Typen: bool, int, double, std::string, std::vector<std::string>, json.
// Ein Eingang ist Pflicht, wenn keine Vorgabe angegeben ist (EIN_VORGABE).
// Scripts (Bash, Python ...) werden mit ScriptAktion registriert: Eingaenge
// gehen als JSON auf stdin, Ausgaenge kommen als JSON von stdout.
// ===========================================================================
#include <nlohmann/json.hpp>
#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace actionkit {
using json = nlohmann::json;

// ---- Typbeschreibung ---------------------------------------------------
template <class T> struct TypName;
template <> struct TypName<bool>        { static const char* wert() { return "bool"; } };
template <> struct TypName<int>         { static const char* wert() { return "int"; } };
template <> struct TypName<double>      { static const char* wert() { return "double"; } };
template <> struct TypName<std::string> { static const char* wert() { return "string"; } };
template <> struct TypName<std::vector<std::string>> { static const char* wert() { return "string[]"; } };
template <> struct TypName<json>        { static const char* wert() { return "json"; } };

struct Parameter {
    std::string name, typ, hilfe;
    bool        eingang = true;        // false = Ausgang
    bool        pflicht = true;        // nur Eingang
    json        vorgabe;               // nur Eingang, wenn !pflicht
};

// ---- Ergebnis eines Aufrufs ---------------------------------------------
struct Ergebnis {
    bool        ok = false;
    std::string fehler;                // leer, wenn ok
    json        ausgaben = json::object();
};

// ---- Aktion ---------------------------------------------------------------
struct Aktion {
    std::string name, hilfe;
    std::vector<Parameter> parameter;
    // Rohaufruf: eingaenge (geprueft und mit Vorgaben ergaenzt) -> Ergebnis
    std::function<Ergebnis(const json& eingaenge)> rumpf;

    const Parameter* finde(const std::string& n) const {
        for (const Parameter& p : parameter) if (p.name == n) return &p;
        return nullptr;
    }
    // Eingaenge pruefen: Pflicht vorhanden, Typ passend, Vorgaben ergaenzen.
    bool pruefen(json& ein, std::string& fehler) const {
        if (!ein.is_object()) { fehler = "Eingaenge muessen ein JSON-Objekt sein"; return false; }
        for (const Parameter& p : parameter) {
            if (!p.eingang) continue;
            if (!ein.contains(p.name)) {
                if (p.pflicht) { fehler = "Eingang '" + p.name + "' fehlt"; return false; }
                ein[p.name] = p.vorgabe; continue;
            }
            const json& w = ein[p.name];
            bool passt = (p.typ == "bool" && w.is_boolean()) || (p.typ == "int" && w.is_number_integer())
                      || (p.typ == "double" && w.is_number()) || (p.typ == "string" && w.is_string())
                      || (p.typ == "string[]" && w.is_array()) || (p.typ == "json");
            if (!passt) { fehler = "Eingang '" + p.name + "' hat Typ " + w.type_name() + ", erwartet " + p.typ; return false; }
        }
        for (auto it = ein.begin(); it != ein.end(); ++it)
            if (!finde(it.key())) { fehler = "unbekannter Eingang '" + it.key() + "'"; return false; }
        return true;
    }
    Ergebnis aufrufen(json ein) const {
        Ergebnis e; if (!pruefen(ein, e.fehler)) return e;
        return rumpf(ein);
    }
    json beschreibung() const {
        json j; j["name"] = name; j["hilfe"] = hilfe; json ps = json::array();
        for (const Parameter& p : parameter) {
            json o; o["name"] = p.name; o["typ"] = p.typ; o["richtung"] = p.eingang ? "ein" : "aus";
            if (p.eingang) { o["pflicht"] = p.pflicht; if (!p.pflicht) o["vorgabe"] = p.vorgabe; }
            if (!p.hilfe.empty()) o["hilfe"] = p.hilfe;
            ps.push_back(o);
        }
        j["parameter"] = ps; return j;
    }
};

// ---- Registry --------------------------------------------------------------
struct Aktionen {
    static std::map<std::string, Aktion>& tabelle() { static std::map<std::string, Aktion> t; return t; }
    static void registrieren(const Aktion& a) { tabelle()[a.name] = a; }
    static const Aktion* finde(const std::string& n) { auto it = tabelle().find(n); return it == tabelle().end() ? nullptr : &it->second; }
    static std::vector<std::string> alle() { std::vector<std::string> v; for (auto& kv : tabelle()) v.push_back(kv.first); return v; }
    static json katalog() { json j = json::array(); for (auto& kv : tabelle()) j.push_back(kv.second.beschreibung()); return j; }
};
struct Registrator { Registrator(const Aktion& a) { Aktionen::registrieren(a); } };

// ---- Wert aus/nach JSON je Typ ----------------------------------------------
template <class T> inline T ausJson(const json& j) { return j.get<T>(); }
template <class T> inline json nachJson(const T& t) { return json(t); }

// ---- Parameterdeklaration fuer das Makro -------------------------------------
struct PDecl { Parameter p; };
template <class T> inline PDecl ein(const char* name, const char* hilfe = "") {
    PDecl d; d.p.name = name; d.p.typ = TypName<T>::wert(); d.p.hilfe = hilfe; d.p.eingang = true; d.p.pflicht = true; return d; }
template <class T> inline PDecl einVorgabe(const char* name, const T& vorgabe, const char* hilfe = "") {
    PDecl d = ein<T>(name, hilfe); d.p.pflicht = false; d.p.vorgabe = nachJson(vorgabe); return d; }
template <class T> inline PDecl aus(const char* name, const char* hilfe = "") {
    PDecl d; d.p.name = name; d.p.typ = TypName<T>::wert(); d.p.hilfe = hilfe; d.p.eingang = false; return d; }

// ---- CLI: "name=wert" Argumente -> Eingaenge -------------------------------------
// Typ entscheidet die Deutung: bool (ja/nein/true/false/1/0), int, double,
// string, string[] (kommagetrennt), json (roher JSON-Text).
inline bool argvNachEingaenge(const Aktion& a, const std::vector<std::string>& args, json& ein, std::string& fehler) {
    ein = json::object();
    for (const std::string& s : args) {
        auto gl = s.find('='); if (gl == std::string::npos) { fehler = "erwartet name=wert: " + s; return false; }
        const std::string n = s.substr(0, gl), w = s.substr(gl + 1);
        const Parameter* p = a.finde(n);
        if (!p || !p->eingang) { fehler = "unbekannter Eingang '" + n + "'"; return false; }
        if (p->typ == "bool") ein[n] = (w == "ja" || w == "true" || w == "1" || w == "yes");
        else if (p->typ == "int" || p->typ == "double") {
            try { if (p->typ == "int") ein[n] = std::stoi(w); else ein[n] = std::stod(w); }
            catch (...) { fehler = "Eingang '" + n + "': keine Zahl: " + w; return false; }
        }
        else if (p->typ == "string") ein[n] = w;
        else if (p->typ == "string[]") {
            json arr = json::array(); std::string t;
            for (char c : w) { if (c == ',') { arr.push_back(t); t.clear(); } else t += c; }
            if (!w.empty()) arr.push_back(t);
            ein[n] = arr;
        }
        else { json j = json::parse(w, nullptr, false); if (j.is_discarded()) { fehler = "Eingang '" + n + "': kein JSON"; return false; } ein[n] = j; }
    }
    return true;
}
// Vollstaendiger CLI-Aufruf: args[0] = Aktionsname, Rest name=wert.
inline Ergebnis ausArgv(const std::vector<std::string>& args) {
    Ergebnis e;
    if (args.empty()) { e.fehler = "Aktionsname fehlt"; return e; }
    const Aktion* a = Aktionen::finde(args[0]);
    if (!a) { e.fehler = "unbekannte Aktion '" + args[0] + "'"; return e; }
    json ein; std::vector<std::string> rest(args.begin() + 1, args.end());
    if (!argvNachEingaenge(*a, rest, ein, e.fehler)) return e;
    return a->aufrufen(ein);
}

} // namespace actionkit

// ---- Makros -------------------------------------------------------------------
// AKTION(Name, "Hilfe", EIN(T, n)..., AUS(T, n)...) { Rumpf; return true; }
// Im Rumpf: jeder Eingang ist eine lokale Variable seines Typs, jeder Ausgang
// eine Referenz; "return false" mit gesetztem `fehler` meldet einen Fehler.
#define EIN(T, n)            ::actionkit::ein<T>(#n)
#define EIN_H(T, n, h)       ::actionkit::ein<T>(#n, h)
#define EIN_VORGABE(T, n, v) ::actionkit::einVorgabe<T>(#n, v)
#define AUS(T, n)            ::actionkit::aus<T>(#n)
#define AUS_H(T, n, h)       ::actionkit::aus<T>(#n, h)

// Rumpf-Signatur: bool Name_rumpf(const json& ein, json& aus, std::string& fehler)
// Zugriff im Rumpf ueber HOLE(T, n) / SETZE(n, wert).
#define HOLE(T, n)     const T n = ::actionkit::ausJson<T>(ein.at(#n))
#define SETZE(n, w)    aus[#n] = ::actionkit::nachJson(w)

#define AKTION(Name, Hilfe, ...)                                                                   \
    static bool Name##_rumpf(const ::actionkit::json& ein, ::actionkit::json& aus, std::string& fehler); \
    static ::actionkit::Aktion Name##_bauen() {                                                     \
        ::actionkit::Aktion a; a.name = #Name; a.hilfe = Hilfe;                                     \
        for (const ::actionkit::PDecl& d : { __VA_ARGS__ }) a.parameter.push_back(d.p);             \
        a.rumpf = [](const ::actionkit::json& e) { ::actionkit::Ergebnis r; std::string f;           \
            r.ok = Name##_rumpf(e, r.ausgaben, f); r.fehler = r.ok ? "" : (f.empty() ? "Aktion meldet Fehler" : f); return r; }; \
        return a; }                                                                                 \
    static ::actionkit::Registrator Name##_reg(Name##_bauen());                                     \
    static bool Name##_rumpf([[maybe_unused]] const ::actionkit::json& ein, [[maybe_unused]] ::actionkit::json& aus, [[maybe_unused]] std::string& fehler)

#define AKTION_UNBENUTZT(x) (void)(x)
