# actionkit -- Aktionen aus Funktionskoepfen

Eine normale C++-Funktion wird mit einer Zeile zur Aktion mit typisierten,
benannten Ein- und Ausgaengen:

    AKTION(GeneratePDF, "Erzeugt eine PDF und versendet sie",
           EIN(std::string, quelle), EIN(std::vector<std::string>, emails),
           EIN_VORGABE(bool, senden, false), AUS(std::string, pdfPfad)) {
        HOLE(std::string, quelle); HOLE(std::vector<std::string>, emails);
        SETZE(pdfPfad, quelle + ".pdf");
        return true;                       // oder: fehler = "..."; return false;
    }

Danach ist sie ueberall gleich erreichbar:

- **Registry** `Aktionen::alle()`, `Aktionen::katalog()` -- beschreibt jede Aktion
  mit Parametern (Name, Typ, Pflicht, Vorgabe, Hilfe); daraus baut eine UI ihre
  Felder (Checkbox, Zahl, Text, Liste) und der Node-Editor seine Ports.
- **JSON** `aktion.aufrufen({...})` -> `{"pdfPfad": ...}` -- so ruft eine
  timeline-Aktion (`Aktion::befehl` + `parameter`) sie auf.
- **CLI** `ausArgv({"GeneratePDF","quelle=r.txt","emails=a@x,b@x"})` -- jede
  Aktion ist automatisch ein Befehl.
- **Verkettung**: Ausgaenge einer Aktion sind Eingaenge der naechsten (Vorstufe
  fuer jobflow und den Node-Editor).

Eingaenge werden geprueft (Pflicht, Typ, unbekannte Namen) -- ein Tippfehler
scheitert sofort mit klarer Meldung statt still zu wirken.
Typen: bool, int, double, string, string[], json.

Was NICHT alle Funktionen sein sollten: Aktionen sind Funktionen mit klaren
Ein- und Ausgaengen; UI-Funktionen und alles mit verstecktem Zustand nicht.

    cmake -B build -S . && cmake --build build && ctest --test-dir build


