#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINE 1024
#define MAX_OUTPUT 4096

// Structure to hold parser state
typedef struct {
    int in_list;
    int list_level;
    int in_code_block;
    char* output;
    size_t output_size;
    size_t output_pos;
} ParserState;

// Initialize parser state
void init_parser(ParserState* state) {
    state->in_list = 0;
    state->list_level = 0;
    state->in_code_block = 0;
    state->output_size = MAX_OUTPUT;
    state->output = (char*)malloc(state->output_size);
    state->output[0] = '\0';
    state->output_pos = 0;
}

// Append string to output buffer
void append_output(ParserState* state, const char* str) {
    size_t len = strlen(str);
    if (state->output_pos + len + 1 >= state->output_size) {
        state->output_size *= 2;
        state->output = (char*)realloc(state->output, state->output_size);
    }
    strcpy(state->output + state->output_pos, str);
    state->output_pos += len;
}

// Trim whitespace from start and end of string
char* trim(char* str) {
    char* end;
    while (isspace((unsigned char)*str)) str++;
    if (*str == 0) return str;
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end)) end--;
    end[1] = '\0';
    return str;
}

// Check if line is a heading
int is_heading(const char* line, int* level) {
    int count = 0;
    while (line[count] == '#') count++;
    if (count > 0 && count <= 6 && isspace(line[count])) {
        *level = count;
        return 1;
    }
    return 0;
}

// Check if line is a list item
int is_list_item(const char* line, int* level) {
    int indent = 0;
    while (line[indent] == ' ' || line[indent] == '\t') indent++;
    if (line[indent] == '*' || line[indent] == '-' || isdigit(line[indent])) {
        *level = indent / 2 + 1;
        return 1;
    }
    return 0;
}

// Process inline formatting (bold and italic)
void process_inline(ParserState* state, const char* text) {
    char buffer[MAX_LINE];
    size_t i = 0, j = 0;
    int in_bold = 0, in_italic = 0;

    while (text[i]) {
        if (text[i] == '*' && text[i+1] == '*') {
            append_output(state, in_bold ? "</strong>" : "<strong>");
            in_bold = !in_bold;
            i += 2;
        } else if (text[i] == '*' && !in_italic) {
            append_output(state, in_italic ? "</em>" : "<em>");
            in_italic = !in_italic;
            i++;
        } else if (text[i] == '`') {
            append_output(state, "<code>");
            i++;
            while (text[i] && text[i] != '`') {
                buffer[j++] = text[i++];
            }
            buffer[j] = '\0';
            append_output(state, buffer);
            append_output(state, "</code>");
            i++;
            j = 0;
        } else {
            buffer[j++] = text[i++];
            if (text[i] == '\0') {
                buffer[j] = '\0';
                append_output(state, buffer);
                j = 0;
            }
        }
    }
}

// Process a single line of Markdown
void process_line(ParserState* state, char* line) {
    char* trimmed = trim(line);
    if (strlen(trimmed) == 0) {
        if (!state->in_code_block && !state->in_list) {
            append_output(state, "<p></p>\n");
        }
        return;
    }

    // Handle code blocks
    if (strncmp(trimmed, "```", 3) == 0) {
        state->in_code_block = !state->in_code_block;
        append_output(state, state->in_code_block ? "<pre><code>" : "</code></pre>\n");
        return;
    }

    if (state->in_code_block) {
        append_output(state, trimmed);
        append_output(state, "\n");
        return;
    }

    // Handle headings
    int level;
    if (is_heading(trimmed, &level)) {
        char tag[4];
        sprintf(tag, "h%d", level);
        append_output(state, "<");
        append_output(state, tag);
        append_output(state, ">");
        process_inline(state, trimmed + level + 1);
        append_output(state, "</");
        append_output(state, tag);
        append_output(state, ">\n");
        return;
    }

    // Handle list items
    int list_level;
    if (is_list_item(trimmed, &list_level)) {
        while (state->list_level < list_level) {
            append_output(state, "<ul>\n");
            state->list_level++;
        }
        while (state->list_level > list_level) {
            append_output(state, "</ul>\n");
            state->list_level--;
        }
        if (!state->in_list) {
            append_output(state, "<ul>\n");
            state->in_list = 1;
            state->list_level = list_level;
        }
        append_output(state, "<li>");
        process_inline(state, trimmed + (list_level * 2));
        append_output(state, "</li>\n");
        return;
    }

    // Close any open lists
    if (state->in_list) {
        while (state->list_level > 0) {
            append_output(state, "</ul>\n");
            state->list_level--;
        }
        state->in_list = 0;
    }

    // Handle paragraphs
    append_output(state, "<p>");
    process_inline(state, trimmed);
    append_output(state, "</p>\n");
}


//"<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/github-markdown-css/5.8.1/github-markdown.min.css\">\n"
int main() {
    ParserState state;
    init_parser(&state);

    // Output HTML header with github-markdown-css styling
    append_output(&state,
        "<!DOCTYPE html>\n"
        "<html lang=\"en\">\n"
        "<head>\n"
        "<meta charset=\"UTF-8\">\n"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
        "<style>\n"
        ".markdown-body {\n"
        "    box-sizing: border-box;\n"
        "    min-width: 200px;\n"
        "    max-width: 980px;\n"
        "    margin: 0 auto;\n"
        "    padding: 45px;\n"
        "}\n"
        "@media (max-width: 767px) {\n"
        "    .markdown-body {\n"
        "        padding: 15px;\n"
        "    }\n"
        "}\n"
        "</style>\n"
        "</head>\n"
        "<body>\n"
        "<article class=\"markdown-body\">\n"
    );

    // Process input
    char line[MAX_LINE];
    while (fgets(line, MAX_LINE, stdin)) {
        line[strcspn(line, "\n")] = '\0';
        process_line(&state, line);
    }

    // Close any open lists
    if (state.in_list) {
        while (state.list_level > 0) {
            append_output(&state, "</ul>\n");
            state.list_level--;
        }
    }

    // Close code block if open
    if (state.in_code_block) {
        append_output(&state, "</code></pre>\n");
    }

    // Output HTML footer
    append_output(&state, "</article>\n</body>\n</html>\n");

    // Print output
    printf("%s", state.output);

    // Cleanup
    free(state.output);
    return 0;
}
