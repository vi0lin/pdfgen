# Drafts for Vim File Opening
OpenFileFZF()
OpenFileCommandLine()

SetProject()

, e OpenFileCommandline project
. e OpenFileFZF         project

, g OpenFileCommandLine /
. g OpenFileFZF         /

, p 
. p 

c-p   fzf GetProject()
c-g   fzf /
p project GetProject()
g global  /

c standard libs
c all you need to know
look on g for information sheets

# C or Rust?
## Milestone 1:
vulkan, gameengine, shaderprogramming, porting (mac, linux, windows, android)
## Milestone 2:
android app
ios     app
windows app
linux   app
## Milestone 3:
Build them via vim command, on a remote machine

# Fix Vim
Autocommands
I Think I Can Delete The Tests.vim
Fix Ctrl-P <leader>e <leader>p <localleader>e <localleader>p
work folder up
First Time Got Visual Selection Right, I never gathered a non blockwise selection.
~~Fix <C-S> Save Executes whole file.~~
wget -o https://github.com/vi0lin/vim-advantages/install.vim | vim -c 
wget -o https://bit.ly | vim -c 
fix cd behaviour and mapping - i had no good idea until now
git custom commit message
multiline editing <leader>me
InsertFunction (StepBack, NormalCommand { AppendBefore If Comments Follow
~~learned about closure~~

# Thoughts On C
compile curl
compile ssh
use libraries in c is it a pain?
list of all standard libraries
how to link, how to compile
shader
portable c (android ios windows linux)

# Thoughts On Bash
sh/folder and script files

SearchOpenFile As A Good Example Source

# Consider Having Good Habits
## Where To Investigate
mathematics
games


# Blender
## Stylized Shader
To achieve stylized shiny edges in Blender, use the Layer Weight node with a Color Ramp to control the edge falloff, a Mix Shader node with an Emission node for the glow, and a Glare node in the Compositor to add the bloom effect to the rendered output. Alternatively, you can create glowing edges using Blender's Grease Pencil with its Line Art modifier and effects for a simpler outlined look. 
Method 1: Stylized Glowing Edges (Node-Based)
This method creates a glow effect using shader nodes and the compositor. 

    Set up the Nodes:
        In the Shader Editor, add a Layer Weight node and a Color Ramp node.
        Add a Mix Shader node and an Emission node.
        Connect the Facing output of the Layer Weight node to the Factor input of the Mix Shader node.
        Connect the Emission node to one of the shader inputs of the Mix Shader.
        Connect the Color Ramp node between the Layer Weight and the Mix Shader's Fac input, or connect it to the Emission node's Color input.
    Adjust the Glow:
        In the Color Ramp, set the color to your desired glow color and adjust the sliders to create a smooth edge falloff.
        In the Emission node, increase the Strength to control the intensity of the glow.
    Add Bloom to the Render:
        Go to the Compositing workspace and enable "Use Nodes".
        Add a Glare node to the node tree and set its type to "Bloom".
        Connect the output of the render layer to the input of the Glare node, and then to the final output. 

Method 2: Grease Pencil Outlines
This method uses Grease Pencil for a quick, stylized outline with glow. 

    Add Grease Pencil Object:
        Go to Add > Grease Pencil > Blank to add a new Grease Pencil object to your scene.
    Enable Line Art:
        In the Modifier Properties, add a Line Art modifier to the Grease Pencil object.
        Adjust the modifier settings, such as Crease Angle, to get the desired edge detection.
    Add Material and Glow:
        Go to the Material Properties and set a base color for your object.
        In the Fill or Stroke panel, add a glow effect. Change the mode to "Color" for a more vibrant effect.
    Compositing for Visibility:
        If the glow isn't visible, go to the Compositing workspace, enable "Use Nodes," and add a Glare node set to "Bloom". 


curl quick install curl
file actions - sort - uniq - filter \<a href and so forth in file and as commands and quick accessible
term actions f5 f6 f7 f8 hjkl
build actions f9 f10 f11 f12
other actions f1 f2 f3 f4 - unconsidered
Finish LineUp
Git Per Working Directory (Push)
Git Submodules
Git Push For Each branch

redo the "copy" function on function Open(...)
make wbtg copy, and maybe (not) also open the same file

Ctrl+T
g Ctrl-]
:tag foo
:tselect
Ctrl-W }
Ctrl-W z
set tags=./tags,tags;$HOME " Search for 'tags' file in current dir and up

find in files (in opened files)
find in files (in all)

tags help me with tags
tags from opened files

Github Fine Grained Token For All Repos
githup.com/settings/personal-access-tokens
vi0lin
codekowski@gmail.com
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

SSH HJKL
(Variant: Remote File As FD)
(Variant: Establish SSH, instructions with termsend)
(CI CD Approach, to easily setup buildinstructions per project)

(vertical) split on multiple files (modes: visual, normal, if multiple paths were found)

Refactor Functions. Make Them Better Integrated on :%g/input/FunctionName
Make them accessibile via :command FunctionName

Faster Rebuild Window Layout
example: <leader>eV
or (keep good naming on Command.vim): prefix#RebuildVimEditing()
to call so   :DashboardVimFiles()
hs Mrtn.vim
hs Mrtn.vim
wincmd h TERM()
termsend()

# BigStep
better file traversal (emacs style)
make copen better
or popups
or AsyncRun
or remove AsyncRun

Fix CtrlP
Add adjusting path [buffer tab global] with comma
ctrl p                :Find in Buffer
ctrl shift p          :Find in Tab
ctrl alt p            :Find in Global
<leader>ctrl p        :Folder in Buffer
<leader>ctrl shift p  :Folder in Tab
<leader>ctrl alt p    :Folder in Global
<f3>                  :Find In System Files [/] or Find In homedir [/home/user/]
ctrl <f3>             :Find In Files in Buffer
ctrl shift <f3>       :Find In Files in Tab
ctrl alt <f3>         :Find In Files in Global

<f4> Git Integration

<F2>

<F1>
" Document It Well!

// <leader><leader>ctrl       :Folder in Buffer
// <leader><leader>ctrl shift :Folder in Tab
// <leader><leader>ctrl alt   :Folder in Global

Aug. 23 13:00
Follow Bloopers
summerSumsum
tcfreer

Todos
# Clean Up Bashrc
List of macros
List of commands
https://github.com/seanbaxter/shaders

Unix uses 0xA for a newline character. Windows uses a combination of two characters: 0xD 0xA. 0xD is the carriage return character. ^M happens to be the way vim displays 0xD (0x0D = 13, M is the 13th letter in the English alphabet).

Winning doesn't happen on match day.
It happens on lonely days - when you're tired
overlooked, and still show up anyway.
Discipline wins that motivation can't.

