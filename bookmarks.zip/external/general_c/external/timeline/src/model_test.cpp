#include "model.h"
#include <cstdio>
#include <string>
using namespace timeline;
static int fehler = 0;
#define PRUEF(bed, text) do { bool ok = (bed); printf("  %s %s\n", ok ? "OK " : "FEHLER", text); if (!ok) fehler++; } while (0)

// Hilfen: Zeitzone +2 h (MESZ), Uhrzeit an einem Datum
static const Zeit TZ = 2 * 3600;
static Zeit um(int y, int m, int d, int h, int mi = 0) { return ausLokal({ tageSeitEpoche(y, m, d), h * 3600 + mi * 60 }, TZ); }
static std::string datum(Zeit t) { Lokal l = lokal(t, TZ); Datum d = datumAusTagen(l.tage);
    char b[40]; snprintf(b, sizeof b, "%02d.%02d.%04d %02d:%02d", d.tag, d.monat, d.jahr, (int)(l.sekundenImTag / 3600), (int)(l.sekundenImTag % 3600 / 60)); return b; }
static std::string liste(const std::vector<Vorkommen>& v) { std::string s; for (auto& x : v) s += datum(x.start) + " "; return s; }

int main() {
    const Zeit jetzt = um(2026, 9, 28, 12);
    Speicher s; s.geraet = "laptop";

    printf("--- Kalenderrechnung ---\n");
    PRUEF(wochentag(tageSeitEpoche(2026, 9, 28)) == 0, "28.09.2026 ist ein Montag");
    PRUEF(datum(um(2026, 2, 28, 9)) == "28.02.2026 09:00", "Rueckrechnung Datum/Uhrzeit");

    printf("--- Wiederholung ---\n");
    Event& w = s.anlegen(jetzt); w.titel = "Standup"; w.start = um(2026, 9, 28, 9); w.durMin = 15;
    w.regel.takt = Takt::Woechentlich; w.regel.wochentage = 0b0000101;   // Mo + Mi
    auto v = vorkommen(s, um(2026, 9, 28, 0), um(2026, 10, 12, 0), TZ);
    PRUEF(v.size() == 4, ("Mo+Mi, zwei Wochen -> 4 Vorkommen: " + liste(v)).c_str());
    PRUEF(v.size() == 4 && datum(v[1].start) == "30.09.2026 09:00", "zweites Vorkommen am Mittwoch 09:00");
    w.regel.jede = 2;                                                    // jede zweite Woche
    v = vorkommen(s, um(2026, 9, 28, 0), um(2026, 10, 26, 0), TZ);
    PRUEF(v.size() == 4, ("jede 2. Woche Mo+Mi, vier Wochen -> 4: " + liste(v)).c_str());
    w.regel.jede = 1; w.regel.anzahl = 3;
    v = vorkommen(s, um(2026, 9, 1, 0), um(2027, 1, 1, 0), TZ);
    PRUEF(v.size() == 3, "Anzahl 3 begrenzt die Serie");
    w.regel.anzahl = 0; w.regel.bis = um(2026, 10, 5, 23, 59);
    v = vorkommen(s, um(2026, 9, 1, 0), um(2027, 1, 1, 0), TZ);
    PRUEF(v.size() == 3, "'Bis 05.10.' -> Mo 28.9., Mi 30.9., Mo 5.10.");

    Event& m = s.anlegen(jetzt); m.titel = "Miete"; m.start = um(2026, 1, 31, 8); m.regel.takt = Takt::Monatlich;
    v.clear(); vorkommenSammeln(s, m, um(2026, 1, 1, 0), um(2026, 5, 1, 0), TZ, v);
    PRUEF(v.size() == 4 && datum(v[1].start) == "28.02.2026 08:00" && datum(v[2].start) == "31.03.2026 08:00",
          ("Monatlich am 31.: Februar auf den 28. geklemmt, Maerz wieder 31.: " + liste(v)).c_str());

    printf("--- R3: nur diesen / ab hier / jedes n-te ab hier ---\n");
    Event& t = s.anlegen(jetzt); t.titel = "Training"; t.start = um(2026, 10, 1, 18); t.regel.takt = Takt::Taeglich;
    auto fenster = [&](Zeit a, Zeit b) { std::vector<Vorkommen> o; for (auto& kv : s.events) vorkommenSammeln(s, kv.second, a, b, TZ, o);
        std::sort(o.begin(), o.end(), [](auto& x, auto& y){ return x.start < y.start; }); return o; };
    nurDiesenLoeschen(s, t, um(2026, 10, 3, 18), jetzt);
    Event& e4 = nurDiesen(s, t, um(2026, 10, 4, 18), jetzt); e4.start = um(2026, 10, 4, 20); e4.titel = "Training (spaeter)";
    v = fenster(um(2026, 10, 1, 0), um(2026, 10, 6, 0));
    std::string t3; for (auto& x : v) if (s.finde(x.event)->titel.wert.find("Training") != std::string::npos) t3 += datum(x.start) + " ";
    PRUEF(t3 == "01.10.2026 18:00 02.10.2026 18:00 04.10.2026 20:00 05.10.2026 18:00 ",
          ("3.10. faellt aus, 4.10. verschoben auf 20:00: " + t3).c_str());
    Event& t2 = abHier(s, *s.finde(t.id), um(2026, 10, 6, 18), jetzt, 2);   // ab 6.10. jeden 2. Tag
    t2.titel = "Training (jeden 2. Tag)";
    v = fenster(um(2026, 10, 5, 0), um(2026, 10, 12, 0));
    std::string t4; for (auto& x : v) if (s.finde(x.event)->titel.wert.find("Training") != std::string::npos)
        t4 += datum(x.start).substr(0, 5) + (s.finde(x.event)->titel.wert.find("jeden") != std::string::npos ? "N " : "A ");
    PRUEF(t4 == "05.10A 06.10N 08.10N 10.10N ", ("alte Serie (A) endet 5.10., neue (N) jeden 2. Tag ab 6.10.: " + t4).c_str());

    printf("--- R1/R2: Vorlagen mit Rueckfall ---\n");
    Event& vl = s.anlegen(jetzt); vl.istVorlage = true; vl.titel = "Reinigung"; vl.notizen = "Fotos anhaengen"; vl.erinnernMin = 30;
    Aktion ak; ak.befehl = "pdfgen"; ak.parameter = "{\"quelle\":\"reinigung.txt\"}"; ak.ziel = Zielwahl::IrgendeinOnline; ak.bevorzugt = "windows"; vl.aktion = ak;
    Event& r1 = s.anlegen(jetzt); r1.vorlage = vl.id; r1.start = um(2026, 10, 2, 7); r1.art = Art::Aktion;
    Event& r2 = s.anlegen(jetzt); r2.vorlage = vl.id; r2.start = um(2026, 10, 9, 7); r2.titel = "Reinigung Kunde B"; r2.art = Art::Aktion;
    PRUEF(wTitel(s, r1) == "Reinigung" && wNotizen(s, r1) == "Fotos anhaengen" && wErinnern(s, r1) == 30, "r1 uebernimmt alle Vorlagenwerte");
    PRUEF(wTitel(s, r2) == "Reinigung Kunde B" && wNotizen(s, r2) == "Fotos anhaengen", "r2: eigener Titel, Notiz aus Vorlage");
    r2.titel.loeschen();
    PRUEF(wTitel(s, r2) == "Reinigung", "Wert leeren -> Rueckfall auf Vorlage (wie Placeholder)");
    r2.titel = std::string("");
    PRUEF(wTitel(s, r2) == "" && r2.titel.gesetzt, "ausdruecklich LEER gesetzt bleibt leer (kein Rueckfall)");
    int n = vorlageAufloesen(s, vl.id, jetzt);
    PRUEF(n == 2 && s.finde(vl.id)->geloescht, "Vorlage loeschen: aufgeloest in 2 Instanzen, Vorlage ist Grabstein");
    PRUEF(r1.titel.gesetzt && r1.titel.wert == "Reinigung" && r1.aktion.gesetzt && r1.aktion.wert.befehl == "pdfgen" && r1.vorlage == 0,
          "r1 hat die Werte jetzt SELBST -- nichts verloren (R2)");

    printf("--- R4: Sub-Events mit Versatz ---\n");
    Event& g = s.anlegen(jetzt); g.titel = "Monatsabschluss"; g.start = um(2026, 11, 1, 9); g.regel.takt = Takt::Monatlich;
    Event& sub1 = s.anlegen(jetzt); sub1.art = Art::Benachrichtigung; sub1.versatz = -3600; sub1.titel = "Erinnerung";
    Event& sub2 = s.anlegen(jetzt); sub2.art = Art::Aktion; sub2.versatz = 30 * 60; sub2.titel = "Rechnung mailen";
    PRUEF(s.zuordnen(g.id, sub1.id, jetzt) && s.zuordnen(g.id, sub2.id, jetzt), "zuordnen() haengt beide Kinder ein");
    v = vorkommen(s, um(2026, 12, 1, 0), um(2026, 12, 2, 0), TZ);
    std::string dez; for (auto& x : v) if (x.serie == g.id) dez += datum(x.start).substr(11) + ":" + wTitel(s, *s.finde(x.event)) + " ";
    PRUEF(dez == "08:00:Erinnerung 09:00:Monatsabschluss 09:30:Rechnung mailen ",
          ("im Dezember: Erinnerung 08:00, Haupt 09:00, Aktion 09:30: " + dez).c_str());
    g.start = um(2026, 11, 1, 14);                                        // Elternteil verschoben
    v = vorkommen(s, um(2026, 12, 1, 0), um(2026, 12, 2, 0), TZ);
    std::string dez2; for (auto& x : v) if (x.serie == g.id) dez2 += datum(x.start).substr(11) + " ";
    PRUEF(dez2 == "13:00 14:00 14:30 ", ("Elternteil verschoben -> Kinder folgen: " + dez2).c_str());
    PRUEF(wTitel(s, sub1) == "Erinnerung" && wNotizen(s, sub1) == wNotizen(s, g), "Sub-Event faellt bei Notizen auf Elternteil zurueck");

    printf("--- R7: Beziehung, beliebig tief ---\n");
    Event& sub2b = s.anlegen(jetzt); sub2b.art = Art::Benachrichtigung; sub2b.versatz = -10 * 60; sub2b.titel = "gleich Rechnung";
    Event& sub2c = s.anlegen(jetzt); sub2c.art = Art::Aktion; sub2c.versatz = 5 * 60; sub2c.titel = "Beleg archivieren";
    Event& sub2c1 = s.anlegen(jetzt); sub2c1.art = Art::Normal; sub2c1.versatz = 60; sub2c1.titel = "Ebene 3";
    PRUEF(s.zuordnen(sub2.id, sub2b.id, jetzt) && s.zuordnen(sub2.id, sub2c.id, jetzt) && s.zuordnen(sub2c.id, sub2c1.id, jetzt),
          "Kind unter Kind unter Kind (Aktion -> Benachrichtigung/Aktion -> Normal)");
    v = vorkommen(s, um(2026, 12, 1, 0), um(2026, 12, 2, 0), TZ);
    std::string tief; for (auto& x : v) if (x.serie == g.id) tief += datum(x.start).substr(11) + ":" + wTitel(s, *s.finde(x.event)) + " ";
    PRUEF(tief == "13:00:Erinnerung 14:00:Monatsabschluss 14:20:gleich Rechnung 14:30:Rechnung mailen 14:35:Beleg archivieren 14:36:Ebene 3 ",
          ("Versaetze summieren sich ueber die Ebenen (14:30 -10 = 14:20, +5 = 14:35, +1 = 14:36): " + tief).c_str());
    PRUEF(!s.zuordnen(sub2c1.id, g.id, jetzt), "Zyklus (Wurzel unter Ebene 3) wird abgewiesen");
    PRUEF(!s.zuordnen(sub2.id, sub2.id, jetzt), "Event unter sich selbst wird abgewiesen");
    PRUEF(s.zuordnen(sub2.id, sub2c.id, jetzt, 0) && s.finde(sub2.id)->kinder[0] == sub2c.id, "Reihenfolge: an Position 0 einhaengen");
    auto vp7 = verpasst(s, um(2026, 12, 1, 0), um(2026, 12, 1, 23), TZ, std::set<Gestartet>{});
    int aktTief = 0; for (auto& x : vp7) if (x.event == sub2c.id) aktTief++;
    PRUEF(aktTief == 1, "verpasste Aktion in Ebene 2 (unter einer Aktion) wird gefunden");
    Event& d = nurDiesen(s, *s.finde(g.id), um(2026, 12, 1, 14), jetzt); d.titel = "Abschluss (diesmal spaeter)"; d.start = um(2026, 12, 1, 16);
    v = vorkommen(s, um(2026, 12, 1, 0), um(2026, 12, 2, 0), TZ);
    std::string nd; for (auto& x : v) if (x.serie == g.id) nd += datum(x.start).substr(11) + " ";
    PRUEF(nd == "15:00 16:00 16:20 16:30 16:35 16:36 ", ("'nur diesen' verschoben -> Kinder folgen dem abgeloesten Vorkommen: " + nd).c_str());
    PRUEF(s.loesen(sub2c.id, jetzt) && s.finde(sub2c.id)->eltern == 0 && s.finde(sub2.id)->kinder.size() == 1, "loesen() macht das Kind zum Wurzel-Event");
    s.loeschen(g.id, jetzt);
    PRUEF(s.finde(sub2b.id)->geloescht && s.finde(sub1.id)->geloescht && !s.finde(sub2c.id)->geloescht,
          "loeschen() wirkt auf den ganzen Teilbaum, nicht auf den geloesten Ast");

    printf("--- R3+R7: 'ab hier' / 'nur diesen' an UNTER-Events ---\n");
    Event& gr = s.anlegen(jetzt); gr.titel = "Gruppe"; gr.start = um(2026, 3, 1, 10); gr.regel.takt = Takt::Monatlich;
    Event& er = s.anlegen(jetzt); er.art = Art::Benachrichtigung; er.versatz = -3600; er.titel = "Erinnerung"; s.zuordnen(gr.id, er.id, jetzt);
    Event& er2 = s.anlegen(jetzt); er2.art = Art::Aktion; er2.versatz = -600; er2.titel = "Vorbereiten"; s.zuordnen(er.id, er2.id, jetzt);
    auto zeiten = [&](Zeit a, Zeit b, Id serie1, Id serie2) { std::string o;
        for (auto& x : vorkommen(s, a, b, TZ)) { if (x.serie == serie1 || x.serie == serie2) o += datum(x.start).substr(0, 5) + datum(x.start).substr(10) + " "; }
        return o; };
    // ab Juni: Erinnerung 2 h vorher statt 1 h -- nur ab dort
    Event* erNeu = kindAbHier(s, er.id, um(2026, 6, 1, 10), jetzt);
    PRUEF(erNeu && erNeu->id != er.id && erNeu->titel.wert == "Erinnerung", "kindAbHier liefert die Kopie des Kindes in der neuen Serie");
    erNeu->versatz = -7200;
    Id grNeu = s.finde(erNeu->id)->eltern;
    PRUEF(zeiten(um(2026, 5, 1, 0), um(2026, 5, 2, 0), gr.id, grNeu) == "01.05 08:50 01.05 09:00 01.05 10:00 ",
          ("Mai (alte Serie): Erinnerung 09:00 wie bisher: " + zeiten(um(2026, 5, 1, 0), um(2026, 5, 2, 0), gr.id, grNeu)).c_str());
    PRUEF(zeiten(um(2026, 6, 1, 0), um(2026, 6, 2, 0), gr.id, grNeu) == "01.06 07:50 01.06 08:00 01.06 10:00 ",
          ("Juni (neue Serie): Erinnerung 08:00, Enkel folgt mit: " + zeiten(um(2026, 6, 1, 0), um(2026, 6, 2, 0), gr.id, grNeu)).c_str());
    // nur im August: Erinnerung entfaellt, Vorbereiten bleibt (an der Gruppe selbst)
    Event* erAug = kindNurDiesen(s, erNeu->id, um(2026, 8, 1, 10), jetzt);
    PRUEF(erAug && erAug->id != erNeu->id, "kindNurDiesen liefert die Kopie im abgeloesten Vorkommen");
    erAug->versatz = -1800;
    PRUEF(zeiten(um(2026, 8, 1, 0), um(2026, 8, 2, 0), gr.id, grNeu) == "01.08 09:20 01.08 09:30 01.08 10:00 ",
          ("August: nur dort 30 min vorher (Enkel folgt): " + zeiten(um(2026, 8, 1, 0), um(2026, 8, 2, 0), gr.id, grNeu)).c_str());
    PRUEF(zeiten(um(2026, 9, 1, 0), um(2026, 9, 2, 0), gr.id, grNeu) == "01.09 07:50 01.09 08:00 01.09 10:00 ",
          ("September wieder wie die neue Serie: " + zeiten(um(2026, 9, 1, 0), um(2026, 9, 2, 0), gr.id, grNeu)).c_str());

    printf("--- R5: Abgleich ---\n");
    Speicher handy = s; handy.geraet = "handy";
    Event* hw = handy.finde(w.id); hw->titel = "Standup (vom Handy)"; handy.geaendert(*hw, jetzt + 10);
    Event* lw = s.finde(w.id); lw->titel = "Standup (vom Laptop)"; s.geaendert(*lw, jetzt + 5);
    handy.loeschen(m.id, jetzt + 20);
    Event& neu = handy.anlegen(jetzt + 30); neu.titel = "nur auf dem Handy";
    AbgleichErgebnis erg = zusammenfuehren(s, handy);
    PRUEF(s.finde(w.id)->titel.wert == "Standup (vom Handy)", "spaetere Aenderung gewinnt (Handy +10 s > Laptop +5 s)");
    PRUEF(s.finde(m.id)->geloescht, "Loeschung vom Handy kommt als Grabstein an");
    PRUEF(s.finde(neu.id) && erg.neu == 1, "neues Event vom Handy uebernommen");
    Speicher a, b; a.geraet = "a"; b.geraet = "b";
    Event& ea = a.anlegen(100); ea.titel = "von a"; Event eb = ea; eb.titel = "von b"; eb.stempel = {100, "b"}; b.events[eb.id] = eb;
    zusammenfuehren(a, b);
    PRUEF(a.finde(ea.id)->titel.wert == "von b", "Gleichstand der Zeit: groesserer Geraetename gewinnt -- deterministisch auf beiden Seiten");

    printf("--- R6: verpasste Aktionen ---\n");
    Event& g2 = s.anlegen(jetzt); g2.titel = "Monatsabschluss"; g2.start = um(2026, 11, 1, 14); g2.regel.takt = Takt::Monatlich;
    Event& sub2r = s.anlegen(jetzt); sub2r.art = Art::Aktion; sub2r.versatz = 30 * 60; sub2r.titel = "Rechnung mailen"; s.zuordnen(g2.id, sub2r.id, jetzt);
    std::set<Gestartet> gestartet;
    auto nurG2 = [&](std::vector<Vorkommen> in) { std::vector<Vorkommen> o; for (auto& x : in) if (x.serie == g2.id) o.push_back(x); return o; };
    auto vp = nurG2(verpasst(s, um(2026, 12, 1, 0), um(2026, 12, 1, 23), TZ, gestartet));
    std::string vpl; for (auto& x : vp) vpl += datum(x.start).substr(11) + ":" + wTitel(s, *s.finde(x.event)) + " ";
    PRUEF(vpl == "14:30:Rechnung mailen ", ("nach Offline-Tag: die Aktion 14:30 ist verpasst (Erinnerung/Normal nicht): " + vpl).c_str());
    if (!vp.empty()) gestartet.insert({ sub2r.id, vp[0].start });
    PRUEF(nurG2(verpasst(s, um(2026, 12, 1, 0), um(2026, 12, 1, 23), TZ, gestartet)).empty(), "als gestartet vermerkt -> nicht mehr verpasst");
    sub2r.aktion = Aktion{}; sub2r.aktion.wert.nachstartenWennVerpasst = false;
    gestartet.clear();
    PRUEF(nurG2(verpasst(s, um(2026, 12, 1, 0), um(2026, 12, 1, 23), TZ, gestartet)).empty(), "'nachstarten wenn verpasst' aus -> wird nicht gemeldet");

    printf("\n%s\n", fehler ? "### FEHLER ###" : "ALLE PRUEFUNGEN BESTANDEN");
    return fehler;
}
