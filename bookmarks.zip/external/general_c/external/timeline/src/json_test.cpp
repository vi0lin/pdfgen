#include "json.h"
#include <cstdio>
using namespace timeline;
static int fehler = 0;
#define PRUEF(bed, text) do { bool ok = (bed); printf("  %s %s\n", ok ? "OK " : "FEHLER", text); if (!ok) fehler++; } while (0)
static const Zeit TZ = 2 * 3600;
static Zeit um(int y, int m, int d, int h, int mi = 0) { return ausLokal({ tageSeitEpoche(y, m, d), h * 3600 + mi * 60 }, TZ); }

int main() {
    const Zeit jetzt = um(2026, 9, 30, 12);
    printf("--- Rundreise speichern/laden ---\n");
    Speicher s; s.geraet = "laptop";
    Event& vl = s.anlegen(jetzt); vl.istVorlage = true; vl.titel = "Reinigung"; vl.erinnernMin = 30;
    Aktion ak; ak.befehl = "pdfgen"; ak.parameter = "{\"quelle\":\"r.txt\"}"; ak.ziel = Zielwahl::IrgendeinOnline; ak.hosts = {"windows","buildserver"}; vl.aktion = ak;
    Event& g = s.anlegen(jetzt); g.vorlage = vl.id; g.start = um(2026, 10, 1, 9); g.regel.takt = Takt::Woechentlich; g.regel.wochentage = 0b0000101; g.regel.jede = 2;
    g.notizen = std::string("");                       // ausdruecklich leer
    g.zusatz = "{\"memos\":[{\"audio\":\"m1.wav\",\"transkript\":\"hallo\"}]}";
    Event& k = s.anlegen(jetzt); k.art = Art::Benachrichtigung; k.versatz = -900; k.titel = "gleich"; s.zuordnen(g.id, k.id, jetzt);
    nurDiesenLoeschen(s, g, um(2026, 10, 15, 9), jetzt);
    g.zusatzTermine.push_back(um(2026, 12, 24, 9));
    json j = speichern(s);
    Speicher s2; std::string err;
    PRUEF(laden(s2, j, &err), ("laden: " + err).c_str());
    PRUEF(s2.events.size() == s.events.size() && s2.naechsteId == s.naechsteId && s2.geraet == "laptop", "gleiche Anzahl, naechsteId, Geraet");
    const Event* g2 = s2.finde(g.id);
    PRUEF(g2 && g2->vorlage == vl.id && g2->regel.takt == Takt::Woechentlich && g2->regel.wochentage == 0b0000101 && g2->regel.jede == 2, "Vorlage und Regel erhalten");
    PRUEF(g2 && !g2->titel.gesetzt && g2->notizen.gesetzt && g2->notizen.wert.empty(), "Rueckfall (titel fehlt) vs. ausdruecklich leer (notizen) unterschieden");
    PRUEF(g2 && g2->kinder.size() == 1 && s2.finde(k.id)->eltern == g.id && s2.finde(k.id)->versatz == -900, "Beziehung und Versatz erhalten");
    PRUEF(g2 && g2->ausnahmen.size() == 1 && g2->ausnahmen[0].geloescht && g2->zusatzTermine.size() == 1, "Ausnahme und Zusatztermin erhalten");
    PRUEF(json::parse(g2->zusatz)["memos"][0]["audio"] == "m1.wav", "zusatz (Memos) unveraendert durchgereicht");
    const Event* vl2 = s2.finde(vl.id);
    PRUEF(vl2 && vl2->aktion.gesetzt && vl2->aktion.wert.hosts.size() == 2 && vl2->aktion.wert.ziel == Zielwahl::IrgendeinOnline, "Aktion mit Hosts erhalten");
    PRUEF(speichern(s2) == j, "zweite Rundreise ergibt byteidentisches JSON");
    PRUEF(wTitel(s2, *g2) == "Reinigung" && wErinnern(s2, *g2) == 30, "Rueckfall auf Vorlage wirkt nach dem Laden");
    auto v = vorkommen(s2, um(2026, 10, 1, 0), um(2026, 10, 31, 0), TZ);
    PRUEF(v.size() == 8, "geladene Serie liefert dieselben Vorkommen (4 Termine + 4 Benachrichtigungen, 15.10. faellt aus)");

    printf("--- Migration aus calendar.json (Version 2) ---\n");
    json alt; alt["version"] = 2;
    json e1; e1["id"] = 101; e1["start"] = um(2026, 5, 4, 8); e1["durMin"] = 60; e1["title"] = "Zahnarzt"; e1["notes"] = "Karte mitnehmen";
    e1["color"] = 0; e1["allDay"] = false; e1["remindMin"] = 15; e1["remindOn"] = true; e1["wdh"] = 0; e1["wdhJede"] = 1; e1["wdhBis"] = 0;
    e1["created"] = um(2026, 4, 1, 10); e1["modified"] = um(2026, 4, 2, 10); e1["source"] = "";
    e1["memos"] = json::array({ json{{"audio","m_101.wav"},{"transkript","Termin"},{"aufgenommen",um(2026,4,1,10)},{"dauerMs",3000}} });
    json a1; a1["id"] = 5001; a1["art"] = 0; a1["start"] = um(2026, 5, 4, 7, 45); a1["durMin"] = 0; a1["ton"] = ""; a1["text"] = "Los!"; a1["ziel"] = ""; a1["aktiv"] = true; a1["getan"] = false; a1["statisch"] = false;
    json a2; a2["id"] = 5002; a2["art"] = 4; a2["start"] = um(2026, 5, 4, 9); a2["durMin"] = 0; a2["ton"] = ""; a2["text"] = ""; a2["ziel"] = "praxis@example.org"; a2["aktiv"] = true; a2["getan"] = false; a2["statisch"] = true;
    e1["actions"] = json::array({ a1, a2 });
    json e2; e2["id"] = 102; e2["start"] = um(2026, 1, 5, 9); e2["durMin"] = 30; e2["title"] = "Standup"; e2["notes"] = ""; e2["color"] = 0xff336699;
    e2["allDay"] = false; e2["remindMin"] = -1; e2["remindOn"] = false; e2["wdh"] = 2; e2["wdhJede"] = 1; e2["wdhBis"] = um(2026, 12, 31, 23); e2["created"] = 0; e2["modified"] = 0;
    e2["actions"] = json::array();
    alt["entries"] = json::array({ e1, e2 });
    Speicher m; m.geraet = "handy";
    MigrationErgebnis me = migrierenAusCalendarJson(alt, m, TZ);
    PRUEF(me.events == 2 && me.kinder == 2, "2 Eintraege, 2 Aktionen -> Kinder");
    const Event* z = m.finde(101);
    PRUEF(z && z->titel.wert == "Zahnarzt" && z->notizen.wert == "Karte mitnehmen" && z->erinnernMin.gesetzt && z->erinnernMin.wert == 15 && !z->farbe.gesetzt, "Felder abgebildet (Farbe 0 = Rueckfall)");
    PRUEF(z && z->kinder.size() == 2 && m.finde(5001)->art == Art::Benachrichtigung && m.finde(5001)->versatz == -900 && m.finde(5001)->titel.wert == "Los!", "Alarm -> Benachrichtigung, Versatz -15 min");
    const Event* mail = m.finde(5002);
    PRUEF(mail && mail->art == Art::Aktion && mail->aktion.gesetzt && mail->aktion.wert.befehl == "mail" && json::parse(mail->aktion.wert.parameter)["ziel"] == "praxis@example.org", "Mail -> Aktion 'mail' mit Ziel in den Parametern");
    PRUEF(json::parse(z->zusatz)["memos"][0]["audio"] == "m_101.wav", "Memos verlustfrei in zusatz");
    const Event* st = m.finde(102);
    PRUEF(st && st->regel.takt == Takt::Woechentlich && st->regel.wochentage == 0b0011111 && st->regel.bis == um(2026, 12, 31, 23) && st->farbe.gesetzt, "Wochentags -> Mo-Fr, Bis und Farbe uebernommen");
    auto sv = vorkommen(m, um(2026, 1, 5, 0), um(2026, 1, 12, 0), TZ);
    int standups = 0; for (auto& x : sv) if (x.event == 102) standups++;
    PRUEF(standups == 5, "migrierte 'Wochentags'-Serie: 5 Vorkommen Mo-Fr");
    PRUEF(m.naechsteId > 5002, "naechsteId liegt ueber allen uebernommenen Ids");
    Speicher m2; PRUEF(laden(m2, speichern(m), nullptr) && m2.events.size() == 4, "migrierter Speicher ueberlebt die Rundreise");

    printf("--- Robustheit ---\n");
    json neu = j; neu["version"] = 99; Speicher s3;
    PRUEF(!laden(s3, neu, &err) && err.find("neuer") != std::string::npos, ("neuere Version wird abgelehnt: " + err).c_str());
    PRUEF(!laden(s3, json::object(), &err), "fremdes JSON wird abgelehnt");
    Speicher s4; json j4 = j; j4["events"][0].erase("titel"); PRUEF(laden(s4, j4, nullptr), "fehlende Felder sind Rueckfall, kein Fehler");

    printf("\n%s\n", fehler ? "### FEHLER ###" : "ALLE PRUEFUNGEN BESTANDEN");
    return fehler;
}
