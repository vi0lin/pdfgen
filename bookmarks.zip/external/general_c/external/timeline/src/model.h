#pragma once
// ===========================================================================
// timeline/model.h -- DATENMODELL DES SCHEDULERS (UI-frei, header-only).
//
// Das ist der Kern, aus dem spaeter external/timeline wird. Er kennt keine
// Oberflaeche, kein Netz und keine Dateien -- nur Begriffe und Regeln:
//
//   Event        ein Eintrag; kann Kind eines anderen sein (Sub-Event) und
//                eine Vorlage als Quelle fuer Rueckfallwerte haben
//   Regel        Wiederholung: taeglich / woechentlich (Wochentage) /
//                monatlich / jaehrlich, jede n-te, bis / Anzahl
//   Ausnahme     "nur diesen": eine Instanz geloescht oder durch ein
//                abgeloestes Event ersetzt
//   Vorkommen    eine konkrete Instanz einer Serie in einem Zeitfenster,
//                mit WIRKSAMEN Werten (Event -> Vorlage -> Elternteil)
//   Aktion       was ein Aktions-Event beim Eintreten tut: Befehl,
//                Parameter, Zielhosts, Ablaufart in der Queue
//   Stempel      wer wann geaendert hat -- Grundlage fuer den Abgleich
//
// ZEIT: Unix-UTC-Sekunden. Kalenderrechnung (Wochentag, Monat) laeuft in
// einer festen Zeitzone, die der Aufrufer als Versatz in Sekunden angibt
// -- deterministisch, testbar, ohne Systemabhaengigkeit.
//
// GRUNDREGELN (jede ist unten in Tests festgehalten):
//  R1  Ein Feld ist entweder GESETZT oder faellt auf die Vorlage zurueck;
//      ein Sub-Event faellt zusaetzlich auf sein Elternteil zurueck.
//  R2  Eine Vorlage zu loeschen loest sie in ihren Instanzen AUF: die
//      Rueckfallwerte werden zu gesetzten Werten. Nichts geht verloren.
//  R3  "nur diesen" aendert genau ein Vorkommen (Ausnahme + abgeloestes
//      Event); "ab hier" teilt die Serie (neue Serie ab dort, alte endet
//      davor); "jedes n-te ab hier" ist "ab hier" mit neuem Intervall.
//  R4  Ein Sub-Event liegt IMMER relativ zum Elternteil (Versatz); es
//      folgt jeder Verschiebung und jedem Vorkommen des Elternteils.
//  R5  Abgleich: Letzter-schreibt-gewinnt je Event nach (modified,
//      geraet); Loeschungen sind Grabsteine und gewinnen bei Gleichstand.
//  R6  Verpasst ist ein Aktions-Vorkommen, dessen Zeit im Fenster
//      (zuletztGeprueft, jetzt] lag und das nicht als gestartet vermerkt
//      ist -- unabhaengig davon, warum es niemand gestartet hat.
//  R7  BEZIEHUNG: Jedes Event kann beliebig viele Kinder haben, jedes Kind
//      wieder Kinder -- ohne Tiefengrenze, unabhaengig von der Art
//      (Normal, Benachrichtigung, Aktion). Die Beziehung steht explizit
//      und GEORDNET am Elternteil (kinder) und als Rueckverweis am Kind
//      (eltern); zuordnen()/loesen() halten beide Seiten gleich. Zyklen
//      werden abgewiesen. Versaetze summieren sich ueber die Ebenen.
// ===========================================================================
#include <algorithm>
#include <cstdint>
#include <functional>
#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace timeline {

using Id   = std::uint64_t;
using Zeit = std::int64_t;                 // Unix-UTC-Sekunden

// ---------------------------------------------------------------------------
// Kalenderrechnung (Howard Hinnant, gemeinfrei), fuer Regeln in Zeitzone.
// ---------------------------------------------------------------------------
struct Datum { int jahr, monat, tag; };    // buergerlich, monat 1..12
inline std::int64_t tageSeitEpoche(int y, unsigned m, unsigned d) {
    y -= m <= 2;
    const std::int64_t era = (y >= 0 ? y : y - 399) / 400;
    const unsigned yoe = (unsigned)(y - era * 400);
    const unsigned doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
    const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + (std::int64_t)doe - 719468;
}
inline Datum datumAusTagen(std::int64_t z) {
    z += 719468;
    const std::int64_t era = (z >= 0 ? z : z - 146096) / 146097;
    const unsigned doe = (unsigned)(z - era * 146097);
    const unsigned yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    const int y = (int)yoe + (int)era * 400;
    const unsigned doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    const unsigned mp = (5 * doy + 2) / 153;
    const unsigned d = doy - (153 * mp + 2) / 5 + 1;
    const unsigned m = mp + (mp < 10 ? 3 : -9);
    return { y + (m <= 2), (int)m, (int)d };
}
inline int tageImMonat(int y, int m) {
    static const int t[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    if (m == 2 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)) return 29;
    return t[m - 1];
}
// Wochentag 0 = Montag ... 6 = Sonntag
inline int wochentag(std::int64_t tage) { return (int)(((tage % 7) + 10) % 7); }

// Zerlegung einer Zeit in Zeitzone <tz> (Versatz in Sekunden).
struct Lokal { std::int64_t tage; Zeit sekundenImTag; };
inline Lokal lokal(Zeit t, Zeit tz) {
    Zeit l = t + tz;
    std::int64_t tage = l >= 0 ? l / 86400 : (l - 86399) / 86400;
    return { tage, l - tage * 86400 };
}
inline Zeit ausLokal(Lokal l, Zeit tz) { return l.tage * 86400 + l.sekundenImTag - tz; }

// ---------------------------------------------------------------------------
// Optionaler Wert: gesetzt ODER Rueckfall (R1)
// ---------------------------------------------------------------------------
template <class T> struct Opt {
    bool gesetzt = false;
    T    wert{};
    Opt() = default;
    Opt(const T& w) : gesetzt(true), wert(w) {}
    // Zuweisung aus allem, was sich T zuweisen laesst (z.B. "Text" -> string).
    template <class U> Opt& operator=(const U& w) { gesetzt = true; wert = w; return *this; }
    void loeschen() { gesetzt = false; wert = T{}; }
};

// ---------------------------------------------------------------------------
// Stempel fuer den Abgleich (R5)
// ---------------------------------------------------------------------------
struct Stempel {
    Zeit        modified = 0;
    std::string geraet;                    // wer zuletzt geschrieben hat
    // "Neuer" im Sinne von R5: spaeter, bei Gleichstand groesserer Geraetename.
    bool neuerAls(const Stempel& o) const {
        if (modified != o.modified) return modified > o.modified;
        return geraet > o.geraet;
    }
};

// ---------------------------------------------------------------------------
// Wiederholung
// ---------------------------------------------------------------------------
enum class Takt : std::uint8_t { Nie, Taeglich, Woechentlich, Monatlich, Jaehrlich };

struct Regel {
    Takt          takt     = Takt::Nie;
    std::int32_t  jede     = 1;            // jede n-te Einheit
    std::uint8_t  wochentage = 0;          // Bit 0 = Mo ... Bit 6 = So (Woechentlich)
    Zeit          bis      = 0;            // 0 = ohne Ende (letzter Start <= bis)
    std::int32_t  anzahl   = 0;            // 0 = unbegrenzt
    bool aktiv() const { return takt != Takt::Nie; }
};

// Ausnahme fuer ein einzelnes Vorkommen einer Serie (R3, "nur diesen")
struct Ausnahme {
    Zeit start = 0;                        // urspruenglicher Start des Vorkommens
    bool geloescht = false;                // true: faellt aus
    Id   ersetztDurch = 0;                 // abgeloestes Event (eigene Werte)
};

// ---------------------------------------------------------------------------
// Aktion (Aktions-Event)
// ---------------------------------------------------------------------------
enum class Ablauf : std::uint8_t { Parallel, WartenAuf, Prozedural };
enum class Zielwahl : std::uint8_t { Lokal, Bestimmte, IrgendeinOnline, AlleAusgewaehlten };

struct Aktion {
    std::string befehl;                    // z.B. "publish_release.sh ..." oder Aktionsname
    std::string parameter;                 // JSON-Text mit Eingaben
    Ablauf      ablauf = Ablauf::Prozedural;
    Zielwahl    ziel   = Zielwahl::Lokal;
    std::vector<std::string> hosts;        // bei Bestimmte/AlleAusgewaehlten
    std::string bevorzugt;                 // bei IrgendeinOnline: dieser zuerst
    bool nachstartenWennVerpasst = true;
    Zeit        genauigkeitNs = 0;         // 0 = Sekunde reicht; sonst Wunsch
};

enum class Art : std::uint8_t { Normal, Benachrichtigung, Aktion };

// ---------------------------------------------------------------------------
// Event
// ---------------------------------------------------------------------------
struct Event {
    Id     id = 0;
    Id     eltern  = 0;                    // Sub-Event: Kind von
    Id     vorlage = 0;                    // Rueckfallwerte aus dieser Vorlage
    Id     abgeloestVon = 0;               // "nur diesen": ersetzt ein Vorkommen dieser Serie
    std::vector<Id> kinder;                // R7: Sub-Events in Anzeigereihenfolge
    bool   istVorlage = false;             // erscheint in "navi 1", nie im Kalender
    bool   geloescht  = false;             // Grabstein (R5)
    Stempel stempel;
    Zeit    created = 0;

    Art    art = Art::Normal;
    // ZEIT: Wurzel-Event absolut; Sub-Event als VERSATZ zum Elternteil (R4).
    Zeit   start   = 0;
    Zeit   versatz = 0;                    // nur Sub-Event: Sekunden nach Elternstart
    std::int32_t durMin = 30;
    bool   allDay = false;

    // Felder mit Rueckfall (R1)
    Opt<std::string>   titel;
    Opt<std::string>   notizen;
    Opt<std::uint32_t> farbe;
    Opt<std::int32_t>  erinnernMin;        // Minuten vorher
    Opt<Aktion>        aktion;

    Regel  regel;
    std::vector<Ausnahme> ausnahmen;
    std::vector<Zeit>     zusatzTermine;   // "mit mehreren Daten": weitere Starts

    std::string quelle;                    // Herkunft (z.B. Wordlist-Ereignis)
    std::string ordner;                    // freie Gruppierung in der Vorlagenliste
    std::string zusatz;                    // undurchsichtiger JSON-Text fuer Daten der
                                           // UI-Schicht (Sprachmemos, Anhaenge) --
                                           // das Modell reicht ihn nur durch
};

// Vermerk "dieses Vorkommen wurde gestartet" (R6) -- wird mit abgeglichen,
// damit kein zweiter Client dieselbe Aktion nachstartet.
struct Gestartet { Id event; Zeit start; bool operator<(const Gestartet& o) const {
    return event != o.event ? event < o.event : start < o.start; } };

// ---------------------------------------------------------------------------
// Speicher
// ---------------------------------------------------------------------------
struct Speicher {
    std::map<Id, Event> events;
    std::string geraet = "lokal";
    Id naechsteId = 1;

    // JOURNAL fuer den Abgleich: jede Aenderung bekommt eine laufende,
    // rein lokale Nummer. Ein Partner merkt sich je Geraet die letzte
    // Nummer, die er gesehen hat, und bekommt beim naechsten Kontakt alles
    // darueber -- unabhaengig von Uhren (die entscheiden nur den Konflikt,
    // R5). Die Nummern werden NICHT in die Datei geschrieben; nach einem
    // Neustart fragen Partner einfach "seit 0" und erhalten alles, was
    // R5 dann ohnehin richtig einsortiert.
    std::uint64_t seq = 0;
    std::map<Id, std::uint64_t> eventSeq;
    std::set<Gestartet> gestartet;
    std::map<Gestartet, std::uint64_t> gestartetSeq;
    // HERKUNFT: von welchem Partner ein Eintrag zuletzt UEBERNOMMEN wurde
    // (leer = eigene Aenderung). An diesen Partner geht er nicht zurueck
    // -- sonst schickte jeder jedem alles wieder zu (Echo, endlos).
    std::map<Id, std::string> eventHerkunft;
    std::map<Gestartet, std::string> gestartetHerkunft;
    void notiere(Id id, const std::string& von = "") { eventSeq[id] = ++seq; eventHerkunft[id] = von; }
    void vermerkeGestartet(Gestartet g, const std::string& von = "") {
        gestartet.insert(g); gestartetSeq[g] = ++seq; gestartetHerkunft[g] = von; }

    Id neueId() { while (events.count(naechsteId)) ++naechsteId; return naechsteId++; }
    Event* finde(Id id) { auto it = events.find(id); return it == events.end() ? nullptr : &it->second; }
    const Event* finde(Id id) const { auto it = events.find(id); return it == events.end() ? nullptr : &it->second; }

    Event& anlegen(Zeit jetzt) {
        Event e; e.id = neueId(); e.created = jetzt;
        e.stempel = { jetzt, geraet };
        notiere(e.id);
        return events[e.id] = e;
    }
    void geaendert(Event& e, Zeit jetzt) { e.stempel = { jetzt, geraet }; notiere(e.id); }
    // R7: Loeschen wirkt auf den ganzen Teilbaum.
    void loeschen(Id id, Zeit jetzt, int tiefe = 0) {
        Event* e = finde(id);
        if (!e || tiefe > 64) return;
        e->geloescht = true; geaendert(*e, jetzt);
        for (Id k : std::vector<Id>(e->kinder)) loeschen(k, jetzt, tiefe + 1);
    }
    // Ist <moeglich> ein Vorfahr von <e> (oder e selbst)? -- Zyklenschutz
    bool istVorfahr(Id moeglich, Id e) const {
        for (int i = 0; e && i < 64; ++i) { if (e == moeglich) return true; const Event* x = finde(e); e = x ? x->eltern : 0; }
        return false;
    }
    // R7: Kind unter Elternteil einhaengen (an Position pos, -1 = hinten).
    // Zieht das Kind ggf. aus seinem bisherigen Elternteil heraus.
    bool zuordnen(Id eltern, Id kind, Zeit jetzt, int pos = -1) {
        Event* p = finde(eltern); Event* k = finde(kind);
        if (!p || !k || eltern == kind || istVorfahr(kind, eltern)) return false;
        if (k->eltern && k->eltern != eltern) loesen(kind, jetzt);
        auto& l = p->kinder;
        l.erase(std::remove(l.begin(), l.end(), kind), l.end());
        if (pos < 0 || pos >= (int)l.size()) l.push_back(kind); else l.insert(l.begin() + pos, kind);
        k->eltern = eltern;
        geaendert(*p, jetzt); geaendert(*k, jetzt);
        return true;
    }
    // Kind aus seinem Elternteil loesen -- es wird zum Wurzel-Event mit
    // absoluter Zeit (aus dem letzten bekannten Versatz wird nichts
    // geraten: start bleibt, wie er ist).
    bool loesen(Id kind, Zeit jetzt) {
        Event* k = finde(kind);
        if (!k || !k->eltern) return false;
        if (Event* p = finde(k->eltern)) {
            auto& l = p->kinder; l.erase(std::remove(l.begin(), l.end(), kind), l.end());
            geaendert(*p, jetzt);
        }
        k->eltern = 0; geaendert(*k, jetzt);
        return true;
    }
    std::vector<const Event*> kinder(Id eltern) const {
        std::vector<const Event*> out;
        const Event* p = finde(eltern);
        if (p) for (Id id : p->kinder) { const Event* k = finde(id); if (k && !k->geloescht) out.push_back(k); }
        // Rueckverweise ohne Listeneintrag (aeltere Daten) hinten anhaengen
        for (auto& kv : events)
            if (kv.second.eltern == eltern && !kv.second.geloescht
                && (!p || std::find(p->kinder.begin(), p->kinder.end(), kv.first) == p->kinder.end()))
                out.push_back(&kv.second);
        return out;
    }
};

// ---------------------------------------------------------------------------
// R1: wirksame Werte -- Event, sonst Vorlage, sonst Elternteil (rekursiv)
// ---------------------------------------------------------------------------
template <class T, class F>
inline T wirksam(const Speicher& s, const Event& e, F feld, const T& sonst, int tiefe = 0) {
    const Opt<T>& o = feld(e);
    if (o.gesetzt) return o.wert;
    if (tiefe > 8) return sonst;
    if (const Event* v = s.finde(e.vorlage)) {
        const Opt<T>& ov = feld(*v);
        if (ov.gesetzt) return ov.wert;
        if (v->vorlage) return wirksam<T>(s, *v, feld, sonst, tiefe + 1);
    }
    if (const Event* p = s.finde(e.eltern)) return wirksam<T>(s, *p, feld, sonst, tiefe + 1);
    return sonst;
}
inline std::string wTitel(const Speicher& s, const Event& e) {
    return wirksam<std::string>(s, e, [](const Event& x) -> const Opt<std::string>& { return x.titel; }, "");
}
inline std::string wNotizen(const Speicher& s, const Event& e) {
    return wirksam<std::string>(s, e, [](const Event& x) -> const Opt<std::string>& { return x.notizen; }, "");
}
inline Opt<Aktion> wAktion(const Speicher& s, const Event& e, int tiefe = 0) {
    // Aktion mit Rueckfall (R1): eigene, sonst Vorlage, sonst Elternteil --
    // entschieden nach GESETZT, nicht nach Inhalt (auch eine Aktion ohne
    // Befehl traegt Schalter wie "nachstarten wenn verpasst").
    if (e.aktion.gesetzt) return e.aktion;
    if (tiefe > 8) return Opt<Aktion>();
    if (const Event* v = s.finde(e.vorlage)) { Opt<Aktion> a = wAktion(s, *v, tiefe + 1); if (a.gesetzt) return a; }
    if (const Event* p = s.finde(e.eltern))  { Opt<Aktion> a = wAktion(s, *p, tiefe + 1); if (a.gesetzt) return a; }
    return Opt<Aktion>();
}
inline std::int32_t wErinnern(const Speicher& s, const Event& e) {
    return wirksam<std::int32_t>(s, e, [](const Event& x) -> const Opt<std::int32_t>& { return x.erinnernMin; }, -1);
}

// R2: Vorlage aufloesen -- Rueckfallwerte werden zu gesetzten Werten.
inline int vorlageAufloesen(Speicher& s, Id vorlageId, Zeit jetzt) {
    int n = 0;
    for (auto& kv : s.events) {
        Event& e = kv.second;
        if (e.vorlage != vorlageId || e.geloescht) continue;
        if (!e.titel.gesetzt)       e.titel       = wTitel(s, e);
        if (!e.notizen.gesetzt)     e.notizen     = wNotizen(s, e);
        if (!e.erinnernMin.gesetzt) e.erinnernMin = wErinnern(s, e);
        if (!e.farbe.gesetzt) e.farbe = wirksam<std::uint32_t>(s, e,
            [](const Event& x) -> const Opt<std::uint32_t>& { return x.farbe; }, 0u);
        if (!e.aktion.gesetzt) { Opt<Aktion> a = wAktion(s, e); if (a.gesetzt) e.aktion = a.wert; }
        e.vorlage = 0;
        s.geaendert(e, jetzt);
        ++n;
    }
    s.loeschen(vorlageId, jetzt);
    return n;
}

// ---------------------------------------------------------------------------
// Vorkommen einer Serie im Fenster [von, bis)  (R3, R4)
// ---------------------------------------------------------------------------
struct Vorkommen {
    Id   event = 0;                        // Serien-Event (oder abgeloestes Event)
    Id   serie = 0;                        // die Serie, zu der es gehoert
    Zeit start = 0, ende = 0;
    Zeit ursprungStart = 0;                // Start laut Regel (Schluessel fuer Ausnahmen)
    int  index = 0;                        // 0-basierte Nummer in der Serie
};

// Naechster Start nach <t> gemaess Regel; t selbst zaehlt, wenn er passt.
inline bool naechsterStart(const Regel& r, Zeit erster, Zeit ab, Zeit tz, Zeit& aus) {
    if (!r.aktiv()) { if (erster >= ab) { aus = erster; return true; } return false; }
    const int jede = r.jede < 1 ? 1 : r.jede;
    const Lokal l0 = lokal(erster, tz);
    switch (r.takt) {
        case Takt::Taeglich: {
            std::int64_t t = l0.tage;
            if (ab > erster) { std::int64_t d = (lokal(ab, tz).tage - l0.tage); t = l0.tage + ((d + jede - 1) / jede) * jede; }
            while (true) { aus = ausLokal({t, l0.sekundenImTag}, tz); if (aus >= ab) return true; t += jede; }
        }
        case Takt::Woechentlich: {
            std::uint8_t maske = r.wochentage ? r.wochentage : (std::uint8_t)(1u << wochentag(l0.tage));
            std::int64_t wocheStart = l0.tage - wochentag(l0.tage);   // Montag der ersten Woche
            std::int64_t t = std::max(l0.tage, lokal(ab, tz).tage - 7);
            if (t < l0.tage) t = l0.tage;
            for (int i = 0; i < 366 * 4; ++i, ++t) {
                if (!(maske & (1u << wochentag(t)))) continue;
                if (((t - wochentag(t)) - wocheStart) / 7 % jede != 0) continue;
                aus = ausLokal({t, l0.sekundenImTag}, tz);
                if (aus >= ab && aus >= erster) return true;
            }
            return false;
        }
        case Takt::Monatlich: case Takt::Jaehrlich: {
            const Datum d0 = datumAusTagen(l0.tage);
            for (int k = 0; k < 1200; ++k) {
                int m = d0.monat - 1, y = d0.jahr;
                if (r.takt == Takt::Monatlich) { m += k * jede; y += m / 12; m %= 12; }
                else y += k * jede;
                int tag = std::min(d0.tag, tageImMonat(y, m + 1));
                aus = ausLokal({tageSeitEpoche(y, (unsigned)(m + 1), (unsigned)tag), l0.sekundenImTag}, tz);
                if (aus >= ab) return true;
            }
            return false;
        }
        default: return false;
    }
}

inline void vorkommenSammeln(const Speicher& s, const Event& e, Zeit von, Zeit bis, Zeit tz,
                             std::vector<Vorkommen>& out, int maxN = 10000) {
    // Abgeloeste Events werden NUR ueber die Ausnahme ihrer Serie
    // aufgezaehlt -- sonst erschienen sie doppelt.
    if (e.geloescht || e.istVorlage || e.eltern || e.abgeloestVon) return;
    auto dauer = [&](const Event& x) -> Zeit { return x.allDay ? 86400 : (Zeit)x.durMin * 60; };
    auto emit = [&](Zeit start, int index) {
        const Ausnahme* aus = nullptr;
        for (const Ausnahme& a : e.ausnahmen) if (a.start == start) { aus = &a; break; }
        if (aus && aus->geloescht) return;
        if (aus && aus->ersetztDurch) {
            if (const Event* r = s.finde(aus->ersetztDurch)) {
                if (r->geloescht) return;
                if (r->start + dauer(*r) > von && r->start < bis)
                    out.push_back({ r->id, e.id, r->start, r->start + dauer(*r), start, index });
            }
            return;
        }
        if (start + dauer(e) > von && start < bis)
            out.push_back({ e.id, e.id, start, start + dauer(e), start, index });
    };
    // Serie
    Zeit t = 0; int index = 0; int n = 0;
    Zeit ab = e.start;
    while (n < maxN && naechsterStart(e.regel, e.start, ab, tz, t)) {
        if (e.regel.bis && t > e.regel.bis) break;
        if (e.regel.anzahl && index >= e.regel.anzahl) break;
        if (t >= bis) break;
        emit(t, index);
        ++index; ++n; ab = t + 1;
        if (!e.regel.aktiv()) break;
    }
    // "mit mehreren Daten"
    for (Zeit z : e.zusatzTermine) { emit(z, index++); }
}

// Alle Vorkommen aller Wurzel-Events im Fenster, chronologisch; Sub-Events
// erscheinen mit Versatz unter jedem Vorkommen ihres Elternteils (R4).
inline std::vector<Vorkommen> vorkommen(const Speicher& s, Zeit von, Zeit bis, Zeit tz,
                                        bool mitKindern = true) {
    std::vector<Vorkommen> out;
    for (auto& kv : s.events) vorkommenSammeln(s, kv.second, von, bis, tz, out);
    if (mitKindern) {
        // R7: rekursiv -- Kinder von Kindern, Versatz relativ zum jeweiligen
        // Elternvorkommen. Ein Kind ausserhalb des Fensters wird trotzdem
        // durchlaufen, denn SEINE Kinder koennen im Fenster liegen.
        std::vector<Vorkommen> kinder;
        std::function<void(Id, Zeit, Id, int, int)> absteigen =
            [&](Id elternId, Zeit elternStart, Id serie, int index, int tiefe) {
                if (tiefe > 64) return;
                for (const Event* k : s.kinder(elternId)) {
                    const Zeit ks = elternStart + k->versatz;
                    const Zeit ke = ks + (k->allDay ? 86400 : (Zeit)k->durMin * 60);
                    if (ke > von && ks < bis) kinder.push_back({ k->id, serie, ks, ke, ks, index });
                    absteigen(k->id, ks, serie, index, tiefe + 1);
                }
            };
        for (const Vorkommen& v : out) {
            // Ein abgeloestes Vorkommen (nur diesen) hat seit nurDiesen()
            // EIGENE Kopien der Kinder -- also einfach seine eigenen.
            absteigen(v.event, v.start, v.serie, v.index, 0);
        }
        out.insert(out.end(), kinder.begin(), kinder.end());
    }
    std::sort(out.begin(), out.end(), [](const Vorkommen& a, const Vorkommen& b) {
        return a.start != b.start ? a.start < b.start : a.event < b.event; });
    return out;
}

// ---------------------------------------------------------------------------
// R3/R7: Aenderungen an Serien -- auch an Unter-Events
// ---------------------------------------------------------------------------
// Teilbaum kopieren: alle Kinder von <quelle> als neue Events unter <ziel>,
// rekursiv, Versaetze bleiben. Liefert die Zuordnung alt -> neu.
inline void teilbaumKopieren(Speicher& s, Id quelle, Id ziel, Zeit jetzt,
                             std::map<Id, Id>& altNeu, int tiefe = 0) {
    const Event* q = s.finde(quelle); Event* z = s.finde(ziel);
    if (!q || !z || tiefe > 64) return;
    std::vector<Id> kinder = q->kinder;
    for (Id kid : kinder) {
        const Event* k = s.finde(kid); if (!k || k->geloescht) continue;
        Event kk = *k; kk.id = s.neueId(); kk.eltern = ziel; kk.kinder.clear();
        kk.created = jetzt; kk.stempel = { jetzt, s.geraet };
        s.events[kk.id] = kk;
        s.finde(ziel)->kinder.push_back(kk.id);
        altNeu[kid] = kk.id;
        teilbaumKopieren(s, kid, kk.id, jetzt, altNeu, tiefe + 1);
    }
}
// "nur diesen": Vorkommen <ursprungStart> durch ein eigenes Event ersetzen.
inline Event& nurDiesen(Speicher& s, Event& serie, Zeit ursprungStart, Zeit jetzt) {
    Event& r = s.anlegen(jetzt);
    r.start = ursprungStart; r.durMin = serie.durMin; r.allDay = serie.allDay;
    r.art = serie.art; r.vorlage = serie.vorlage;
    r.titel = serie.titel; r.notizen = serie.notizen; r.farbe = serie.farbe;
    r.erinnernMin = serie.erinnernMin; r.aktion = serie.aktion;
    r.regel = Regel{};
    r.abgeloestVon = serie.id;
    Id rid = r.id;
    serie.ausnahmen.push_back({ ursprungStart, false, rid });
    s.geaendert(serie, jetzt);
    // EIGENE Kinder (R7): Aenderungen an ihnen treffen nur dieses Vorkommen.
    std::map<Id, Id> altNeu;
    teilbaumKopieren(s, serie.id, rid, jetzt, altNeu);
    return *s.finde(rid);
}
// "nur diesen" an einem UNTER-Event: liefert die Kopie des Kindes im
// abgeloesten Vorkommen <ursprungStart> seiner Wurzelserie -- die darf
// dann frei geaendert werden (Versatz, Titel, Aktion ...).
inline Event* kindNurDiesen(Speicher& s, Id kind, Zeit ursprungStart, Zeit jetzt) {
    // Wurzel und Pfad bestimmen
    std::vector<Id> pfad; Id cur = kind;
    for (int i = 0; cur && i < 64; ++i) { pfad.push_back(cur); const Event* e = s.finde(cur); if (!e) return nullptr; cur = e->eltern; }
    Id wurzel = pfad.back();
    Event* w = s.finde(wurzel); if (!w) return nullptr;
    // Vorkommen schon abgeloest? Dann dort weiter, sonst abloesen.
    Id abgeloest = 0;
    for (const Ausnahme& a : w->ausnahmen) if (a.start == ursprungStart && a.ersetztDurch) abgeloest = a.ersetztDurch;
    if (!abgeloest) abgeloest = nurDiesen(s, *w, ursprungStart, jetzt).id;
    // Pfad in der Kopie nachlaufen: gleiche Position in der Kinderliste
    Id hier = abgeloest;
    for (int i = (int)pfad.size() - 2; i >= 0; --i) {
        const Event* orig = s.finde(pfad[i + 1]); const Event* kop = s.finde(hier);
        if (!orig || !kop) return nullptr;
        auto it = std::find(orig->kinder.begin(), orig->kinder.end(), pfad[i]);
        if (it == orig->kinder.end()) return nullptr;
        size_t pos = (size_t)(it - orig->kinder.begin());
        if (pos >= kop->kinder.size()) return nullptr;
        hier = kop->kinder[pos];
    }
    return s.finde(hier);
}
inline Event& abHier(Speicher& s, Event& serie, Zeit ursprungStart, Zeit jetzt, int neuesIntervall = 0);
// "ab hier" an einem UNTER-Event: teilt die Wurzelserie bei <ursprungStart>
// und liefert die Kopie des Kindes in der NEUEN Serie. Aenderungen daran
// gelten ab dort; die alte Serie behaelt das alte Kind.
inline Event* kindAbHier(Speicher& s, Id kind, Zeit ursprungStart, Zeit jetzt, int neuesIntervall = 0) {
    std::vector<Id> pfad; Id cur = kind;
    for (int i = 0; cur && i < 64; ++i) { pfad.push_back(cur); const Event* e = s.finde(cur); if (!e) return nullptr; cur = e->eltern; }
    Event* w = s.finde(pfad.back()); if (!w) return nullptr;
    Event& n = abHier(s, *w, ursprungStart, jetzt, neuesIntervall);
    Id hier = n.id;
    for (int i = (int)pfad.size() - 2; i >= 0; --i) {
        const Event* orig = s.finde(pfad[i + 1]); const Event* kop = s.finde(hier);
        if (!orig || !kop) return nullptr;
        auto it = std::find(orig->kinder.begin(), orig->kinder.end(), pfad[i]);
        if (it == orig->kinder.end()) return nullptr;
        size_t pos = (size_t)(it - orig->kinder.begin());
        if (pos >= kop->kinder.size()) return nullptr;
        hier = kop->kinder[pos];
    }
    return s.finde(hier);
}
inline void nurDiesenLoeschen(Speicher& s, Event& serie, Zeit ursprungStart, Zeit jetzt) {
    serie.ausnahmen.push_back({ ursprungStart, true, 0 });
    s.geaendert(serie, jetzt);
}
// "ab hier": alte Serie endet vor <ursprungStart>, neue beginnt dort.
// neuesIntervall > 0: "jedes n-te ab hier".
inline Event& abHier(Speicher& s, Event& serie, Zeit ursprungStart, Zeit jetzt, int neuesIntervall) {
    const Id sid = serie.id;
    Event& n = s.anlegen(jetzt);
    const Id nid = n.id;
    n = serie; n.id = nid; n.created = jetzt; n.stempel = { jetzt, s.geraet };
    n.start = ursprungStart; n.ausnahmen.clear(); n.kinder.clear();
    if (neuesIntervall > 0) n.regel.jede = neuesIntervall;
    // Ausnahmen der alten Serie, die in die neue fallen, mitnehmen
    for (const Ausnahme& a : serie.ausnahmen) if (a.start >= ursprungStart) n.ausnahmen.push_back(a);
    serie.ausnahmen.erase(std::remove_if(serie.ausnahmen.begin(), serie.ausnahmen.end(),
        [&](const Ausnahme& a) { return a.start >= ursprungStart; }), serie.ausnahmen.end());
    serie.regel.bis = ursprungStart - 1;
    if (serie.regel.anzahl) serie.regel.anzahl = 0;
    s.geaendert(serie, jetzt);
    // Kinder der alten Serie gelten auch fuer die neue: der ganze Teilbaum
    // wird KOPIERT (Versaetze bleiben), damit beide Serien unabhaengig sind.
    { std::map<Id, Id> altNeu; teilbaumKopieren(s, sid, nid, jetzt, altNeu); }
    return *s.finde(nid);
}

// ---------------------------------------------------------------------------
// R5: Abgleich zweier Speicher (Letzter-schreibt-gewinnt je Event)
// ---------------------------------------------------------------------------
struct AbgleichErgebnis { int uebernommen = 0, behalten = 0, neu = 0; };
inline AbgleichErgebnis zusammenfuehren(Speicher& mein, const Speicher& fremd) {
    AbgleichErgebnis erg;
    for (auto& kv : fremd.events) {
        const Event& f = kv.second;
        Event* m = mein.finde(f.id);
        if (!m) { mein.events[f.id] = f; mein.notiere(f.id, fremd.geraet); ++erg.neu; if (f.id >= mein.naechsteId) mein.naechsteId = f.id + 1; continue; }
        const bool fremdNeuer = f.stempel.neuerAls(m->stempel);
        const bool gleichstand = !fremdNeuer && !m->stempel.neuerAls(f.stempel);
        if (fremdNeuer || (gleichstand && f.geloescht && !m->geloescht)) { *m = f; mein.notiere(f.id, fremd.geraet); ++erg.uebernommen; }
        else ++erg.behalten;
    }
    for (const Gestartet& g : fremd.gestartet)
        if (!mein.gestartet.count(g)) mein.vermerkeGestartet(g, fremd.geraet);
    return erg;
}

// ---------------------------------------------------------------------------
// R6: verpasste Aktions-Vorkommen
// ---------------------------------------------------------------------------
// toleranzSek: bis zu so viele Sekunden nach dem Start gilt ein Vorkommen als
// PUENKTLICH und wird auch dann geliefert, wenn "nachstarten wenn verpasst"
// aus ist. [Vorher wurde so eine Aktion IMMER weggelassen -- auch wenn sie
//  genau jetzt faellig war; der Schalter meint aber nur Verspaetung.]
inline std::vector<Vorkommen> verpasst(const Speicher& s, Zeit zuletztGeprueft, Zeit jetzt, Zeit tz,
                                       const std::set<Gestartet>& gestartet, Zeit toleranzSek = 0) {
    std::vector<Vorkommen> out;
    for (const Vorkommen& v : vorkommen(s, zuletztGeprueft + 1, jetzt + 1, tz)) {
        const Event* e = s.finde(v.event);
        if (!e) continue;
        // AKTIONS-EVENT: an der ART erkannt; der Befehl selbst darf per
        // R1 aus Vorlage oder Elternteil kommen.
        const Opt<Aktion> a = wAktion(s, *e);
        if (e->art != Art::Aktion && !a.gesetzt) continue;
        if (v.start > jetzt || v.start <= zuletztGeprueft) continue;
        if (a.gesetzt && !a.wert.nachstartenWennVerpasst && jetzt - v.start > toleranzSek) continue;   // verspaetet -> nicht
        if (gestartet.count({ v.event, v.start })) continue;
        out.push_back(v);
    }
    return out;
}

} // namespace timeline
