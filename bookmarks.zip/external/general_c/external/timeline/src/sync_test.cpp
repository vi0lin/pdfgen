#include "sync.h"
#include <cstdio>
using namespace timeline;
static int fehler = 0;
#define PRUEF(bed, text) do { bool ok = (bed); printf("  %s %s\n", ok ? "OK " : "FEHLER", text); if (!ok) fehler++; } while (0)
static const Zeit TZ = 2 * 3600;
static Zeit um(int y, int m, int d, int h, int mi = 0) { return ausLokal({ tageSeitEpoche(y, m, d), h * 3600 + mi * 60 }, TZ); }

// Ein Teilnehmer mit seiner Sicht auf jeden Partner
struct Teilnehmer { Speicher s; std::map<std::string, Partner> partner; bool online = true;
    Partner& p(const std::string& g) { Partner& x = partner[g]; x.geraet = g; return x; } };
// Kanal: a fragt b, b antwortet, a bestaetigt -- und umgekehrt. Nur wenn beide online.
static void kontakt(Teilnehmer& a, Teilnehmer& b) {
    if (!a.online || !b.online) return;
    for (int runde = 0; runde < 2; ++runde) {
        Teilnehmer& x = runde ? b : a; Teilnehmer& y = runde ? a : b;
        json fr = anfrage(x.s, x.p(y.s.geraet));
        json de = verarbeiten(y.s, fr, y.p(x.s.geraet));             // y liefert Delta
        json be = verarbeiten(x.s, de, x.p(y.s.geraet));             // x wendet an, bestaetigt
        verarbeiten(y.s, be, y.p(x.s.geraet));                       // y merkt sich den Stand
    }
}
static std::string dump(const Speicher& s) { json j = speichern(s); j.erase("geraet"); j.erase("naechsteId"); j.erase("journal"); return j.dump(); }

int main() {
    const Zeit t0 = um(2026, 10, 1, 8);
    Teilnehmer laptop, handy, server; laptop.s.geraet = "laptop"; handy.s.geraet = "handy"; server.s.geraet = "server";

    printf("--- Erster Kontakt und Echtzeit ---\n");
    Event& a = laptop.s.anlegen(t0); a.titel = "Zahnarzt"; a.start = um(2026, 10, 5, 9);
    Event& b = laptop.s.anlegen(t0); b.titel = "Standup"; b.start = um(2026, 10, 6, 9); b.regel.takt = Takt::Taeglich;
    PRUEF(ausstehend(laptop.s, laptop.p("handy")) == 2, "zwei Aenderungen stehen fuer das Handy aus");
    kontakt(laptop, handy);
    PRUEF(handy.s.events.size() == 2 && handy.s.finde(a.id)->titel.wert == "Zahnarzt", "Handy hat beide Events nach dem ersten Kontakt");
    PRUEF(ausstehend(laptop.s, laptop.p("handy")) == 0 && ausstehend(handy.s, handy.p("laptop")) == 0, "nichts mehr ausstehend -- in beide Richtungen");
    Event* la = laptop.s.finde(a.id); la->notizen = "Karte mitnehmen"; laptop.s.geaendert(*la, t0 + 60);
    PRUEF(ausstehend(laptop.s, laptop.p("handy")) == 1, "eine Aenderung -> genau ein Eintrag ausstehend (Echtzeit-Push)");
    json d = delta(laptop.s, laptop.p("handy"));
    PRUEF(d["events"].size() == 1, "das Delta enthaelt nur das geaenderte Event, nicht alles");
    kontakt(laptop, handy);
    PRUEF(handy.s.finde(a.id)->notizen.wert == "Karte mitnehmen", "Notiz auf dem Handy angekommen");

    printf("--- Gleichzeitige Bearbeitung (R5 ueber das Netz) ---\n");
    Event* ha = handy.s.finde(a.id); ha->titel = "Zahnarzt (Handy)"; handy.s.geaendert(*ha, t0 + 200);
    la = laptop.s.finde(a.id); la->titel = "Zahnarzt (Laptop)"; laptop.s.geaendert(*la, t0 + 100);
    Event* hb = handy.s.finde(b.id); hb->durMin = 45; handy.s.geaendert(*hb, t0 + 150);
    kontakt(laptop, handy);
    PRUEF(laptop.s.finde(a.id)->titel.wert == "Zahnarzt (Handy)" && handy.s.finde(a.id)->titel.wert == "Zahnarzt (Handy)", "spaetere Aenderung (Handy) gewinnt auf BEIDEN Seiten");
    PRUEF(laptop.s.finde(b.id)->durMin == 45, "unabhaengige Aenderung des Handys kommt beim Laptop an");
    PRUEF(dump(laptop.s) == dump(handy.s), "beide Speicher sind danach identisch");

    printf("--- Ueber den Server, transitiv, mit Offline-Phase ---\n");
    handy.online = false;                                          // Handy ist weg
    Event& c = laptop.s.anlegen(t0 + 300); c.titel = "nur ueber den Server"; c.start = um(2026, 10, 7, 12);
    laptop.s.loeschen(b.id, t0 + 310);                             // Standup geloescht
    Event* lc = laptop.s.finde(c.id); Event& ak = laptop.s.anlegen(t0 + 320); ak.art = Art::Aktion; ak.versatz = 0; ak.titel = "Rechnung";
    Aktion akt; akt.befehl = "pdfgen"; ak.aktion = akt; laptop.s.zuordnen(lc->id, ak.id, t0 + 320);
    kontakt(laptop, server);
    PRUEF(server.s.events.size() == 4 && server.s.finde(b.id)->geloescht, "Server hat alles, inklusive Grabstein");
    laptop.s.vermerkeGestartet({ ak.id, um(2026, 10, 7, 12) });      // Laptop hat die Aktion ausgefuehrt
    kontakt(laptop, server);
    laptop.online = false;                                         // jetzt ist der Laptop weg
    handy.online = true;                                           // ... und das Handy kommt zurueck
    kontakt(handy, server);
    PRUEF(handy.s.finde(c.id) && handy.s.finde(c.id)->titel.wert == "nur ueber den Server", "Handy bekommt das Laptop-Event vom Server, ohne den Laptop je zu sehen");
    PRUEF(handy.s.finde(b.id)->geloescht, "Loeschung kommt transitiv an");
    PRUEF(handy.s.finde(ak.id) && handy.s.finde(ak.id)->eltern == c.id && handy.s.finde(c.id)->kinder.size() == 1, "Beziehung (Kind unter Event) kommt transitiv an");
    auto vp = verpasst(handy.s, um(2026, 10, 7, 0), um(2026, 10, 8, 0), TZ, handy.s.gestartet);
    PRUEF(vp.empty(), "Startvermerk kam mit: das Handy startet die Aktion NICHT noch einmal");
    Event* hc = handy.s.finde(c.id); hc->notizen = "vom Handy ergaenzt"; handy.s.geaendert(*hc, t0 + 400);
    kontakt(handy, server);
    laptop.online = true; kontakt(laptop, server);
    PRUEF(laptop.s.finde(c.id)->notizen.wert == "vom Handy ergaenzt", "Rueckweg Handy -> Server -> Laptop");
    kontakt(handy, server); kontakt(laptop, server);
    PRUEF(dump(laptop.s) == dump(handy.s) && dump(handy.s) == dump(server.s), "alle drei Speicher konvergieren");

    printf("--- Robustheit ---\n");
    json d2 = delta(server.s, 0, "handy");
    std::string vorher = dump(handy.s);
    Partner ps = handy.p("server"); deltaAnwenden(handy.s, d2, ps); deltaAnwenden(handy.s, d2, ps);
    PRUEF(dump(handy.s) == vorher, "dasselbe Delta zweimal anwenden aendert nichts (idempotent)");
    Teilnehmer neu; neu.s.geraet = "tablet";
    kontakt(neu, server);
    PRUEF(dump(neu.s) == dump(server.s), "ein neues Geraet holt sich alles mit 'seit 0'");
    Speicher nachNeustart; nachNeustart.geraet = "laptop"; laden(nachNeustart, speichern(laptop.s));
    PRUEF(nachNeustart.seq == laptop.s.seq && ausstehend(nachNeustart, laptop.p("server")) == 0 && ausstehend(nachNeustart, Partner{"tablet", 0, 0}) > 0,
          "nach Neustart: Journal aus der Datei -> dem Server nichts erneut, einem neuen Partner alles");

    printf("\n%s\n", fehler ? "### FEHLER ###" : "ALLE PRUEFUNGEN BESTANDEN");
    return fehler;
}
