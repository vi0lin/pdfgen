#pragma once
// ===========================================================================
// timeline/json.h -- Laden/Speichern des Modells und Migration.
//
// DATEIFORMAT "timeline", Version 1:
//   { "format": "timeline", "version": 1, "geraet": "...", "naechsteId": n,
//     "events": [ {...}, ... ] }
// Ein Event schreibt nur GESETZTE Opt-Felder; ein fehlendes Feld heisst
// "Rueckfall" (R1), ein vorhandenes leeres heisst "ausdruecklich leer".
//
// MIGRATION aus dem heutigen calendar.json (Version 2 der App) -- siehe
// migrierenAusCalendarJson(): verlustfrei, Memos und unbekannte Teile
// landen im Feld Event::zusatz und werden unveraendert weitergereicht.
// ===========================================================================
#include "model.h"
#include <nlohmann/json.hpp>

namespace timeline {

using json = nlohmann::json;
constexpr int kFormatVersion = 1;

// ---- Aktion -------------------------------------------------------------
inline json aktionZuJson(const Aktion& a) {
    json o;
    o["befehl"] = a.befehl; o["parameter"] = a.parameter;
    o["ablauf"] = (int)a.ablauf; o["ziel"] = (int)a.ziel;
    o["hosts"] = a.hosts; o["bevorzugt"] = a.bevorzugt;
    o["nachstarten"] = a.nachstartenWennVerpasst; o["genauigkeitNs"] = a.genauigkeitNs;
    return o;
}
inline Aktion aktionAusJson(const json& o) {
    Aktion a;
    a.befehl = o.value("befehl", ""); a.parameter = o.value("parameter", "");
    a.ablauf = (Ablauf)o.value("ablauf", (int)Ablauf::Prozedural);
    a.ziel = (Zielwahl)o.value("ziel", (int)Zielwahl::Lokal);
    if (o.contains("hosts") && o["hosts"].is_array()) for (auto& h : o["hosts"]) a.hosts.push_back(h.get<std::string>());
    a.bevorzugt = o.value("bevorzugt", "");
    a.nachstartenWennVerpasst = o.value("nachstarten", true);
    a.genauigkeitNs = o.value("genauigkeitNs", (Zeit)0);
    return a;
}

// ---- Event ---------------------------------------------------------------
inline json eventZuJson(const Event& e) {
    json o;
    o["id"] = e.id;
    if (e.eltern)       o["eltern"] = e.eltern;
    if (e.vorlage)      o["vorlage"] = e.vorlage;
    if (e.abgeloestVon) o["abgeloestVon"] = e.abgeloestVon;
    if (e.istVorlage)   o["istVorlage"] = true;
    if (e.geloescht)    o["geloescht"] = true;
    o["modified"] = e.stempel.modified; o["geraet"] = e.stempel.geraet; o["created"] = e.created;
    o["art"] = (int)e.art;
    o["start"] = e.start; if (e.eltern) o["versatz"] = e.versatz;
    o["durMin"] = e.durMin; if (e.allDay) o["allDay"] = true;
    if (e.titel.gesetzt)       o["titel"] = e.titel.wert;
    if (e.notizen.gesetzt)     o["notizen"] = e.notizen.wert;
    if (e.farbe.gesetzt)       o["farbe"] = e.farbe.wert;
    if (e.erinnernMin.gesetzt) o["erinnernMin"] = e.erinnernMin.wert;
    if (e.aktion.gesetzt)      o["aktion"] = aktionZuJson(e.aktion.wert);
    if (e.regel.aktiv()) {
        json r; r["takt"] = (int)e.regel.takt; r["jede"] = e.regel.jede;
        r["wochentage"] = e.regel.wochentage; r["bis"] = e.regel.bis; r["anzahl"] = e.regel.anzahl;
        o["regel"] = r;
    }
    if (!e.ausnahmen.empty()) {
        json a = json::array();
        for (const Ausnahme& x : e.ausnahmen) {
            json xo; xo["start"] = x.start;
            if (x.geloescht)    xo["geloescht"] = true;
            if (x.ersetztDurch) xo["ersetztDurch"] = x.ersetztDurch;
            a.push_back(xo);
        }
        o["ausnahmen"] = a;
    }
    if (!e.zusatzTermine.empty()) o["zusatzTermine"] = e.zusatzTermine;
    if (!e.kinder.empty())        o["kinder"] = e.kinder;
    if (!e.quelle.empty())        o["quelle"] = e.quelle;
    if (!e.ordner.empty())        o["ordner"] = e.ordner;
    if (!e.zusatz.empty()) {
        // als JSON einbetten, wenn es gueltiges JSON ist; sonst als Text
        json z = json::parse(e.zusatz, nullptr, false);
        o["zusatz"] = z.is_discarded() ? json(e.zusatz) : z;
    }
    return o;
}
inline Event eventAusJson(const json& o) {
    Event e;
    e.id = o.value("id", (Id)0);
    e.eltern = o.value("eltern", (Id)0); e.vorlage = o.value("vorlage", (Id)0);
    e.abgeloestVon = o.value("abgeloestVon", (Id)0);
    e.istVorlage = o.value("istVorlage", false); e.geloescht = o.value("geloescht", false);
    e.stempel.modified = o.value("modified", (Zeit)0); e.stempel.geraet = o.value("geraet", "");
    e.created = o.value("created", (Zeit)0);
    e.art = (Art)o.value("art", (int)Art::Normal);
    e.start = o.value("start", (Zeit)0); e.versatz = o.value("versatz", (Zeit)0);
    e.durMin = o.value("durMin", 30); e.allDay = o.value("allDay", false);
    if (o.contains("titel"))       e.titel = o["titel"].get<std::string>();
    if (o.contains("notizen"))     e.notizen = o["notizen"].get<std::string>();
    if (o.contains("farbe"))       e.farbe = o["farbe"].get<std::uint32_t>();
    if (o.contains("erinnernMin")) e.erinnernMin = o["erinnernMin"].get<std::int32_t>();
    if (o.contains("aktion"))      e.aktion = aktionAusJson(o["aktion"]);
    if (o.contains("regel")) { const json& r = o["regel"];
        e.regel.takt = (Takt)r.value("takt", 0); e.regel.jede = r.value("jede", 1);
        e.regel.wochentage = (std::uint8_t)r.value("wochentage", 0); e.regel.bis = r.value("bis", (Zeit)0);
        e.regel.anzahl = r.value("anzahl", 0); }
    if (o.contains("ausnahmen")) for (auto& xo : o["ausnahmen"])
        e.ausnahmen.push_back({ xo.value("start", (Zeit)0), xo.value("geloescht", false), xo.value("ersetztDurch", (Id)0) });
    if (o.contains("zusatzTermine")) for (auto& t : o["zusatzTermine"]) e.zusatzTermine.push_back(t.get<Zeit>());
    if (o.contains("kinder")) for (auto& k : o["kinder"]) e.kinder.push_back(k.get<Id>());
    e.quelle = o.value("quelle", ""); e.ordner = o.value("ordner", "");
    if (o.contains("zusatz")) e.zusatz = o["zusatz"].is_string() ? o["zusatz"].get<std::string>() : o["zusatz"].dump();
    return e;
}

// ---- Speicher ------------------------------------------------------------
inline json speichern(const Speicher& s) {
    json j; j["format"] = "timeline"; j["version"] = kFormatVersion;
    j["geraet"] = s.geraet; j["naechsteId"] = s.naechsteId;
    json arr = json::array();
    for (auto& kv : s.events) arr.push_back(eventZuJson(kv.second));
    j["events"] = arr;
    // JOURNAL (rein lokal, aber persistent): sonst waere nach jedem Neustart
    // -- bei der Kommandozeile ist das jeder Aufruf -- "alles seit 0" leer.
    json jn; jn["seq"] = s.seq;
    json je = json::array();
    for (auto& kv : s.eventSeq) { json x; x["id"] = kv.first; x["seq"] = kv.second;
        auto h = s.eventHerkunft.find(kv.first); if (h != s.eventHerkunft.end() && !h->second.empty()) x["von"] = h->second; je.push_back(x); }
    jn["events"] = je;
    json jg = json::array();
    for (auto& kv : s.gestartetSeq) { json x; x["event"] = kv.first.event; x["start"] = kv.first.start; x["seq"] = kv.second;
        auto h = s.gestartetHerkunft.find(kv.first); if (h != s.gestartetHerkunft.end() && !h->second.empty()) x["von"] = h->second; jg.push_back(x); }
    jn["gestartet"] = jg;
    j["journal"] = jn;
    return j;
}
inline bool laden(Speicher& s, const json& j, std::string* fehler = nullptr) {
    if (!j.is_object() || j.value("format", "") != "timeline") { if (fehler) *fehler = "kein timeline-Format"; return false; }
    const int v = j.value("version", 0);
    if (v > kFormatVersion) { if (fehler) *fehler = "Datei ist neuer (Version " + std::to_string(v) + ") als dieses Programm"; return false; }
    s.events.clear();
    s.geraet = j.value("geraet", s.geraet);
    s.naechsteId = j.value("naechsteId", (Id)1);
    for (auto& o : j.value("events", json::array())) { Event e = eventAusJson(o); if (e.id) s.events[e.id] = e; }
    for (auto& kv : s.events) if (kv.first >= s.naechsteId) s.naechsteId = kv.first + 1;
    s.seq = 0; s.eventSeq.clear(); s.eventHerkunft.clear(); s.gestartet.clear(); s.gestartetSeq.clear(); s.gestartetHerkunft.clear();
    if (j.contains("journal")) {
        const json& jn = j["journal"]; s.seq = jn.value("seq", (std::uint64_t)0);
        for (auto& x : jn.value("events", json::array())) { Id id = x.value("id", (Id)0); s.eventSeq[id] = x.value("seq", (std::uint64_t)0);
            if (x.contains("von")) s.eventHerkunft[id] = x["von"].get<std::string>(); }
        for (auto& x : jn.value("gestartet", json::array())) { Gestartet g{ x.value("event", (Id)0), x.value("start", (Zeit)0) };
            s.gestartet.insert(g); s.gestartetSeq[g] = x.value("seq", (std::uint64_t)0);
            if (x.contains("von")) s.gestartetHerkunft[g] = x["von"].get<std::string>(); }
    } else {
        // Datei ohne Journal (Migration, Fremddatei): jedes Event zaehlt als
        // eigene Aenderung -- Partner bekommen beim ersten Kontakt alles.
        for (auto& kv : s.events) s.notiere(kv.first);
    }
    return true;
}

// ---- Migration aus calendar.json (App-Version 2) --------------------------
// Abbildung (siehe README): CalEntry -> Event; CalAction -> Kind-Event
// (Alarm/Ton -> Benachrichtigung, sonst Aktion) mit Versatz = a.start -
// e.start. wdh: 0 Nie, 1 Taeglich, 2 Wochentags (Mo-Fr), 3 Woechentlich,
// 4 Monatlich, 5 Jaehrlich. Memos und Audio landen in Event::zusatz.
struct MigrationErgebnis { int events = 0, kinder = 0; };
inline MigrationErgebnis migrierenAusCalendarJson(const json& alt, Speicher& s, Zeit tz) {
    MigrationErgebnis erg;
    for (const json& o : alt.value("entries", json::array())) {
        Event e;
        e.id = o.value("id", (Id)0); if (!e.id) e.id = s.neueId();
        e.start = o.value("start", (Zeit)0); e.durMin = o.value("durMin", 30); e.allDay = o.value("allDay", false);
        e.titel = o.value("title", std::string()); e.notizen = o.value("notes", std::string());
        std::uint32_t farbe = o.value("color", (std::uint32_t)0); if (farbe) e.farbe = farbe;
        const int remindMin = o.value("remindMin", -1);
        if (o.value("remindOn", remindMin >= 0) && remindMin >= 0) e.erinnernMin = remindMin;
        e.created = o.value("created", (Zeit)0);
        e.stempel = { o.value("modified", e.created), s.geraet };
        e.quelle = o.value("source", "");
        switch (o.value("wdh", 0)) {
            case 1: e.regel.takt = Takt::Taeglich; break;
            case 2: e.regel.takt = Takt::Woechentlich; e.regel.wochentage = 0b0011111; break;
            case 3: e.regel.takt = Takt::Woechentlich; e.regel.wochentage = (std::uint8_t)(1u << wochentag(lokal(e.start, tz).tage)); break;
            case 4: e.regel.takt = Takt::Monatlich; break;
            case 5: e.regel.takt = Takt::Jaehrlich; break;
            default: break;
        }
        e.regel.jede = o.value("wdhJede", 1); e.regel.bis = o.value("wdhBis", (Zeit)0);
        // Memos/Audio unveraendert durchreichen
        json z;
        if (o.contains("memos")) z["memos"] = o["memos"];
        if (o.contains("audio") && !o["audio"].get<std::string>().empty()) z["audio"] = o["audio"];
        if (!z.empty()) e.zusatz = z.dump();
        s.events[e.id] = e; ++erg.events;
        if (e.id >= s.naechsteId) s.naechsteId = e.id + 1;
        // Aktionen -> Kinder
        for (const json& ao : o.value("actions", json::array())) {
            Event k; k.id = ao.value("id", (Id)0); if (!k.id || s.events.count(k.id)) k.id = s.neueId();
            const int art = ao.value("art", 0);
            k.art = (art <= 1) ? Art::Benachrichtigung : Art::Aktion;    // 0 Alarm, 1 Ton
            k.versatz = ao.value("start", e.start) - e.start;
            k.durMin = ao.value("durMin", 0);
            const std::string text = ao.value("text", ""); if (!text.empty()) k.titel = text;
            if (k.art == Art::Aktion) {
                Aktion a; static const char* namen[] = { "alarm", "ton", "audio", "pdf", "mail", "befehl" };
                a.befehl = (art >= 0 && art <= 5) ? namen[art] : "befehl";
                json p; p["ziel"] = ao.value("ziel", ""); p["ton"] = ao.value("ton", "");
                p["aktiv"] = ao.value("aktiv", true); p["getan"] = ao.value("getan", false); p["statisch"] = ao.value("statisch", false);
                a.parameter = p.dump(); k.aktion = a;
            } else {
                json p; p["ton"] = ao.value("ton", ""); p["aktiv"] = ao.value("aktiv", true); p["getan"] = ao.value("getan", false);
                k.zusatz = p.dump();
            }
            k.created = e.created; k.stempel = e.stempel;
            s.events[k.id] = k; if (k.id >= s.naechsteId) s.naechsteId = k.id + 1;
            s.zuordnen(e.id, k.id, e.stempel.modified);
            ++erg.kinder;
        }
    }
    return erg;
}

} // namespace timeline
