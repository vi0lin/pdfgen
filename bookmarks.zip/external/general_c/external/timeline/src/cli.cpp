// ===========================================================================
// timeline -- Kommandozeile fuer den Scheduler.
//
//   timeline [-d DATEI] [-z ZEITZONE_STD] [-g GERAET] BEFEHL ...
//
//   liste [VON] [BIS]            Vorkommen im Fenster (Vorgabe: naechste 7 Tage)
//   zeige ID                     ein Event mit wirksamen Werten
//   neu TITEL ZEIT [DAUER_MIN]   neues Event, ZEIT = JJJJ-MM-TT[THH:MM]
//   aendern ID FELD WERT         FELD: titel notizen start dauer erinnern
//                                      takt(nie|taeglich|woechentlich|monatlich|jaehrlich)
//                                      jede bis wochentage(z.B. mo,mi,fr) aktion
//   leeren ID FELD               Feld auf Rueckfall (Vorlage) zuruecksetzen
//   loeschen ID                  Event samt Kindern (Grabstein)
//   kind ELTERN_ID TITEL VERSATZ_MIN [art]   art: normal|erinnerung|aktion
//   nurdiesen ID ZEIT            Vorkommen abloesen, liefert neue ID
//   abhier ID ZEIT [JEDE]        Serie teilen, liefert neue ID
//   vorlage TITEL                neue Vorlage
//   verpasst SEIT                verpasste Aktionen seit ZEIT (Exit 3, wenn welche)
//   gestartet ID ZEIT            Vorkommen als gestartet vermerken
//   migrieren CALENDAR_JSON      calendar.json (App v2) einlesen
//   sync-anfrage PARTNER         Anfrage-Paket ausgeben  (fuer den Transport)
//   sync-delta   PARTNER SEIT    Delta-Paket ausgeben
//   sync-anwenden PARTNER        Paket von stdin anwenden, Antwort ausgeben
//   starten ID ZEIT [--immer]    Vorkommen JETZT ausfuehren (Befehl der Aktion
//                                als Shell-Befehl, Parameter-JSON auf stdin)
//                                und als gestartet vermerken; ohne --immer
//                                nur, wenn es noch nicht vermerkt ist
//   cron [TAGE] [--client NAME]  crontab-Zeilen fuer die Aktions-Vorkommen
//                                der naechsten TAGE (Vorgabe 7): Rueckfall
//                                fuer reines Linux -- jede Zeile laeuft nur,
//                                wenn kein Prozess NAME (Vorgabe
//                                x_bookmark_manager) laeuft
//
// Exit 0 = ok, 1 = Fehler, 2 = Bedienfehler, 3 = verpasste Aktionen.
// ===========================================================================
#include "sync.h"
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#if !defined(_WIN32)
#include <unistd.h>
#else
#include <direct.h>
#define getcwd _getcwd
#endif
using namespace timeline;

static Zeit g_tz = 0;
static std::string g_datei = "timeline.json";
static std::string g_geraet = "cli";

static bool zeitLesen(const std::string& s, Zeit& aus) {
    int y, m, d, h = 0, mi = 0;
    if (sscanf(s.c_str(), "%d-%d-%dT%d:%d", &y, &m, &d, &h, &mi) >= 3 || sscanf(s.c_str(), "%d-%d-%d", &y, &m, &d) == 3) {
        aus = ausLokal({ tageSeitEpoche(y, (unsigned)m, (unsigned)d), (Zeit)h * 3600 + (Zeit)mi * 60 }, g_tz); return true; }
    char* e = nullptr; long long v = strtoll(s.c_str(), &e, 10);
    if (e && *e == 0 && v > 100000000) { aus = v; return true; }     // Unix-Sekunden
    return false;
}
static std::string zeitText(Zeit t) {
    Lokal l = lokal(t, g_tz); Datum d = datumAusTagen(l.tage);
    char b[32]; snprintf(b, sizeof b, "%04d-%02d-%02dT%02d:%02d", d.jahr, d.monat, d.tag, (int)(l.sekundenImTag / 3600), (int)(l.sekundenImTag % 3600 / 60));
    return b;
}
static bool laden(Speicher& s) {
    std::ifstream f(g_datei); if (!f) return true;              // noch keine Datei: leer
    json j = json::parse(f, nullptr, false);
    if (j.is_discarded()) { fprintf(stderr, "timeline: %s ist kein gueltiges JSON\n", g_datei.c_str()); return false; }
    std::string err; if (!timeline::laden(s, j, &err)) { fprintf(stderr, "timeline: %s: %s\n", g_datei.c_str(), err.c_str()); return false; }
    s.geraet = g_geraet; return true;
}
static bool speichernDatei(const Speicher& s) {
    std::ofstream f(g_datei + ".neu"); if (!f) { fprintf(stderr, "timeline: kann %s nicht schreiben\n", g_datei.c_str()); return false; }
    f << speichern(s).dump(1); f.close();
    std::remove(g_datei.c_str()); return std::rename((g_datei + ".neu").c_str(), g_datei.c_str()) == 0;
}
static Zeit jetzt() { return (Zeit)std::time(nullptr); }
static int bedienfehler(const char* was) { fprintf(stderr, "timeline: %s\n", was); return 2; }
static std::uint8_t wochentageLesen(const std::string& s) {
    static const char* n[] = { "mo","di","mi","do","fr","sa","so" }; std::uint8_t m = 0;
    std::stringstream ss(s); std::string t; while (std::getline(ss, t, ',')) for (int i = 0; i < 7; ++i) if (t == n[i]) m |= (std::uint8_t)(1u << i);
    return m;
}
static void eventZeigen(const Speicher& s, const Event& e) {
    printf("%llu  %s  %d min  %s%s%s\n", (unsigned long long)e.id, e.eltern ? ("+" + std::to_string(e.versatz / 60) + " min").c_str() : zeitText(e.start).c_str(),
           e.durMin, wTitel(s, e).c_str(), e.istVorlage ? "  [Vorlage]" : "", e.geloescht ? "  [geloescht]" : "");
    if (!wNotizen(s, e).empty()) printf("    Notizen: %s\n", wNotizen(s, e).c_str());
    if (wErinnern(s, e) >= 0) printf("    Erinnern: %d min vorher\n", wErinnern(s, e));
    if (e.regel.aktiv()) printf("    Wiederholung: takt=%d jede=%d wochentage=%02x bis=%s\n", (int)e.regel.takt, e.regel.jede, e.regel.wochentage, e.regel.bis ? zeitText(e.regel.bis).c_str() : "-");
    if (e.vorlage) printf("    Vorlage: %llu\n", (unsigned long long)e.vorlage);
    Opt<Aktion> a = wAktion(s, e); if (a.gesetzt) printf("    Aktion: %s %s\n", a.wert.befehl.c_str(), a.wert.parameter.c_str());
    for (const Event* k : s.kinder(e.id)) printf("    Kind: %llu  %+lld min  %s\n", (unsigned long long)k->id, (long long)k->versatz / 60, wTitel(s, *k).c_str());
}

int main(int argc, char** argv) {
    std::vector<std::string> a;
    for (int i = 1; i < argc; ++i) {
        std::string x = argv[i];
        if (x == "-d" && i + 1 < argc) g_datei = argv[++i];
        else if (x == "-z" && i + 1 < argc) g_tz = (Zeit)(atof(argv[++i]) * 3600);
        else if (x == "-g" && i + 1 < argc) g_geraet = argv[++i];
        else a.push_back(x);
    }
    if (a.empty()) return bedienfehler("Befehl fehlt (liste|zeige|neu|aendern|leeren|loeschen|kind|nurdiesen|abhier|vorlage|verpasst|gestartet|migrieren|sync-*)");
    const std::string b = a[0];
    Speicher s; s.geraet = g_geraet;
    if (!laden(s)) return 1;
    const Zeit t = jetzt();
    auto id = [&](size_t i) -> Event* { if (i >= a.size()) return nullptr; return s.finde((Id)strtoull(a[i].c_str(), nullptr, 10)); };

    if (b == "liste") {
        Zeit von = t, bis = t + 7 * 86400;
        if (a.size() > 1 && !zeitLesen(a[1], von)) return bedienfehler("VON unlesbar");
        if (a.size() > 2 && !zeitLesen(a[2], bis)) return bedienfehler("BIS unlesbar");
        for (const Vorkommen& v : vorkommen(s, von, bis, g_tz)) {
            const Event* e = s.finde(v.event); if (!e) continue;
            printf("%s  %-6s %llu  %s%s\n", zeitText(v.start).c_str(), e->art == Art::Aktion ? "AKTION" : e->art == Art::Benachrichtigung ? "ERINN." : "",
                   (unsigned long long)e->id, wTitel(s, *e).c_str(), e->abgeloestVon ? " (nur diesen)" : "");
        }
        return 0;
    }
    if (b == "zeige") { Event* e = id(1); if (!e) return bedienfehler("ID unbekannt"); eventZeigen(s, *e); return 0; }
    if (b == "neu" || b == "vorlage") {
        if (a.size() < 2) return bedienfehler("TITEL fehlt");
        Event& e = s.anlegen(t); e.titel = a[1];
        if (b == "vorlage") e.istVorlage = true;
        else { if (a.size() < 3 || !zeitLesen(a[2], e.start)) return bedienfehler("ZEIT fehlt/unlesbar (JJJJ-MM-TTTHH:MM)"); if (a.size() > 3) e.durMin = atoi(a[3].c_str()); }
        printf("%llu\n", (unsigned long long)e.id); return speichernDatei(s) ? 0 : 1;
    }
    if (b == "aendern" || b == "leeren") {
        Event* e = id(1); if (!e) return bedienfehler("ID unbekannt");
        if (a.size() < 3) return bedienfehler("FELD fehlt");
        const std::string f = a[2]; const std::string w = a.size() > 3 ? a[3] : "";
        if (b == "leeren") {
            if (f == "titel") e->titel.loeschen(); else if (f == "notizen") e->notizen.loeschen();
            else if (f == "erinnern") e->erinnernMin.loeschen(); else if (f == "aktion") e->aktion.loeschen(); else if (f == "farbe") e->farbe.loeschen();
            else return bedienfehler("FELD fuer leeren: titel|notizen|erinnern|aktion|farbe");
        } else {
            if (a.size() < 4 && f != "notizen") return bedienfehler("WERT fehlt");
            if (f == "titel") e->titel = w; else if (f == "notizen") e->notizen = w;
            else if (f == "start") { if (!zeitLesen(w, e->start)) return bedienfehler("ZEIT unlesbar"); }
            else if (f == "dauer") e->durMin = atoi(w.c_str());
            else if (f == "erinnern") e->erinnernMin = atoi(w.c_str());
            else if (f == "jede") e->regel.jede = atoi(w.c_str());
            else if (f == "bis") { if (!zeitLesen(w, e->regel.bis)) return bedienfehler("ZEIT unlesbar"); }
            else if (f == "wochentage") e->regel.wochentage = wochentageLesen(w);
            else if (f == "takt") { static const char* n[] = { "nie","taeglich","woechentlich","monatlich","jaehrlich" }; bool ok = false;
                for (int i = 0; i < 5; ++i) { if (w == n[i]) { e->regel.takt = (Takt)i; ok = true; } }
                if (!ok) return bedienfehler("TAKT: nie|taeglich|woechentlich|monatlich|jaehrlich"); }
            else if (f == "aktion") { Aktion ak; ak.befehl = w; if (a.size() > 4) ak.parameter = a[4]; e->aktion = ak; e->art = Art::Aktion; }
            else if (f == "versatz") e->versatz = (Zeit)atoi(w.c_str()) * 60;
            else return bedienfehler("FELD unbekannt");
        }
        s.geaendert(*e, t); return speichernDatei(s) ? 0 : 1;
    }
    if (b == "loeschen") { Event* e = id(1); if (!e) return bedienfehler("ID unbekannt"); s.loeschen(e->id, t); return speichernDatei(s) ? 0 : 1; }
    if (b == "kind") {
        Event* p = id(1); if (!p || a.size() < 4) return bedienfehler("kind ELTERN_ID TITEL VERSATZ_MIN [normal|erinnerung|aktion]");
        Event& k = s.anlegen(t); k.titel = a[2]; k.versatz = (Zeit)atoi(a[3].c_str()) * 60; k.durMin = 0;
        if (a.size() > 4) k.art = a[4] == "aktion" ? Art::Aktion : a[4] == "erinnerung" ? Art::Benachrichtigung : Art::Normal;
        if (!s.zuordnen(p->id, k.id, t)) return bedienfehler("zuordnen abgewiesen (Zyklus?)");
        printf("%llu\n", (unsigned long long)k.id); return speichernDatei(s) ? 0 : 1;
    }
    if (b == "nurdiesen" || b == "abhier") {
        Event* e = id(1); Zeit z; if (!e || a.size() < 3 || !zeitLesen(a[2], z)) return bedienfehler("ID ZEIT");
        Event* n = nullptr;
        if (b == "nurdiesen") n = e->eltern ? kindNurDiesen(s, e->id, z, t) : &nurDiesen(s, *e, z, t);
        else n = e->eltern ? kindAbHier(s, e->id, z, t, a.size() > 3 ? atoi(a[3].c_str()) : 0) : &abHier(s, *e, z, t, a.size() > 3 ? atoi(a[3].c_str()) : 0);
        if (!n) return 1;
        printf("%llu\n", (unsigned long long)n->id); return speichernDatei(s) ? 0 : 1;
    }
    if (b == "verpasst") {
        Zeit seit; if (a.size() < 2 || !zeitLesen(a[1], seit)) return bedienfehler("SEIT fehlt");
        auto v = verpasst(s, seit, t, g_tz, s.gestartet);
        for (const Vorkommen& x : v) { const Event* e = s.finde(x.event); Opt<Aktion> ak = e ? wAktion(s, *e) : Opt<Aktion>();
            printf("%s  %llu  %s  %s %s\n", zeitText(x.start).c_str(), (unsigned long long)x.event, e ? wTitel(s, *e).c_str() : "?", ak.gesetzt ? ak.wert.befehl.c_str() : "", ak.gesetzt ? ak.wert.parameter.c_str() : ""); }
        return v.empty() ? 0 : 3;
    }
    if (b == "gestartet") { Event* e = id(1); Zeit z; if (!e || a.size() < 3 || !zeitLesen(a[2], z)) return bedienfehler("ID ZEIT");
        s.vermerkeGestartet({ e->id, z }); return speichernDatei(s) ? 0 : 1; }
    if (b == "migrieren") {
        if (a.size() < 2) return bedienfehler("CALENDAR_JSON fehlt");
        std::ifstream f(a[1]); if (!f) return bedienfehler("Datei nicht lesbar");
        json j = json::parse(f, nullptr, false); if (j.is_discarded()) return bedienfehler("kein JSON");
        MigrationErgebnis me = migrierenAusCalendarJson(j, s, g_tz);
        printf("%d Events, %d Kinder uebernommen\n", me.events, me.kinder); return speichernDatei(s) ? 0 : 1;
    }
    if (b == "sync-anfrage" || b == "sync-delta" || b == "sync-anwenden") {
        if (a.size() < 2) return bedienfehler("PARTNER fehlt");
        Partner p; p.geraet = a[1];
        // Partnerstand liegt neben der Datei: <datei>.partner.<name>
        const std::string pdatei = g_datei + ".partner." + p.geraet;
        { std::ifstream pf(pdatei); json pj = pf ? json::parse(pf, nullptr, false) : json();
          if (pj.is_object()) { p.vonMirBestaetigt = pj.value("vonMirBestaetigt", 0ull); p.vonIhmGesehen = pj.value("vonIhmGesehen", 0ull); } }
        json aus;
        if (b == "sync-anfrage") aus = anfrage(s, p);
        else if (b == "sync-delta") { std::uint64_t seit = a.size() > 2 ? strtoull(a[2].c_str(), nullptr, 10) : p.vonMirBestaetigt; aus = delta(s, seit, p.geraet); }
        else { json ein = json::parse(std::cin, nullptr, false); if (ein.is_discarded()) return bedienfehler("stdin: kein JSON-Paket");
               aus = verarbeiten(s, ein, p); if (!speichernDatei(s)) return 1; }
        { std::ofstream pf(pdatei); json pj; pj["vonMirBestaetigt"] = p.vonMirBestaetigt; pj["vonIhmGesehen"] = p.vonIhmGesehen; pf << pj.dump(); }
        if (!aus.is_null()) printf("%s\n", aus.dump().c_str());
        return 0;
    }
    if (b == "starten") {
        Event* e = id(1); Zeit z; if (!e || a.size() < 3 || !zeitLesen(a[2], z)) return bedienfehler("starten ID ZEIT [--immer]");
        const bool immer = a.size() > 3 && a[3] == "--immer";
        if (!immer && s.gestartet.count({ e->id, z })) { printf("schon gestartet -- nichts zu tun\n"); return 0; }
        Opt<Aktion> ak = wAktion(s, *e);
        if (!ak.gesetzt || ak.wert.befehl.empty()) return bedienfehler("Event hat keine Aktion");
        // Vermerk ZUERST (und speichern), damit ein zweiter Aufruf -- etwa von
        // cron und einem gleichzeitig startenden Client -- nicht doppelt laeuft.
        s.vermerkeGestartet({ e->id, z }); if (!speichernDatei(s)) return 1;
        const std::string pdatei = g_datei + ".param." + std::to_string(e->id);
        { std::ofstream pf(pdatei); pf << (ak.wert.parameter.empty() ? "{}" : ak.wert.parameter); }
        const std::string cmd = "(" + ak.wert.befehl + ") < '" + pdatei + "'";
        fflush(stdout); int rc = std::system(cmd.c_str()); std::remove(pdatei.c_str());
        printf("%s: Exit %d\n", ak.wert.befehl.c_str(), rc); return rc == 0 ? 0 : 1;
    }
    if (b == "cron") {
        int tage = a.size() > 1 && a[1][0] != '-' ? atoi(a[1].c_str()) : 7; std::string client = "x_bookmark_manager";
        for (size_t i = 1; i + 1 < a.size(); ++i) if (a[i] == "--client") client = a[i + 1];
        // absoluter Pfad zu Programm und Datei, damit cron sie findet
        char selbst[4096] = {0};
#if !defined(_WIN32)
        ssize_t n = readlink("/proc/self/exe", selbst, sizeof selbst - 1); if (n <= 0) strcpy(selbst, "timeline");
#else
        strcpy(selbst, "timeline");
#endif
        std::string datei = g_datei; if (datei[0] != '/') { char cwd[4096]; if (getcwd(cwd, sizeof cwd)) datei = std::string(cwd) + "/" + g_datei; }
        printf("# timeline -- Rueckfall ohne Client: erzeugt %s fuer %d Tage\n", zeitText(t).c_str(), tage);
        printf("# Einspielen: timeline cron | crontab -   (ersetzt die crontab!)\n");
        int zeilen = 0;
        for (const Vorkommen& v : vorkommen(s, t, t + (Zeit)tage * 86400, g_tz)) {
            const Event* e = s.finde(v.event); if (!e || e->art != Art::Aktion) continue;
            Opt<Aktion> ak = wAktion(s, *e); if (!ak.gesetzt || ak.wert.befehl.empty()) continue;
            if (s.gestartet.count({ v.event, v.start })) continue;
            Lokal l = lokal(v.start, g_tz); Datum d = datumAusTagen(l.tage);
            printf("%d %d %d %d * pgrep -x %s >/dev/null || %s -d '%s' -z %g starten %llu %lld  # %s\n",
                   (int)(l.sekundenImTag % 3600 / 60), (int)(l.sekundenImTag / 3600), d.tag, d.monat, client.c_str(), selbst, datei.c_str(),
                   g_tz / 3600.0, (unsigned long long)v.event, (long long)v.start, wTitel(s, *e).c_str());
            ++zeilen;
        }
        printf("# %d Eintraege\n", zeilen); return 0;
    }
    return bedienfehler("unbekannter Befehl");
}
