#pragma once
// ===========================================================================
// timeline/sync.h -- ABGLEICH zwischen Clients und Server, netzfrei.
//
// Erzeugt und verarbeitet JSON-Pakete; der Transport (netlink: TCP im LAN,
// der Hub im Internet) reicht sie nur durch. Jeder Teilnehmer ist ein
// Partner -- der Server ist keiner besonderen Art, er ist nur immer da.
//
// ABLAUF je Partner P (Zustand: Partner):
//   1. Kontakt:   ich sende  anfrage(P)          "gib mir alles seit Nummer x"
//   2. P antwortet delta(P)                       Events + Startvermerke ab x
//   3. ich wende  deltaAnwenden() an (R5) und sende bestaetigung(P)
//   4. P merkt sich per bestaetigungAnwenden(), was ich habe.
//   Danach ECHTZEIT: nach jeder lokalen Aenderung ist ausstehend(P) > 0,
//   und delta(P) enthaelt genau das Neue. Faellt P aus, laeuft beim
//   naechsten Kontakt Schritt 1 -- nichts geht verloren, nichts doppelt
//   (Anwenden ist idempotent).
//
// TRANSITIV ueber den Server: was A dem Server schickt, landet im Journal
// des Servers (zusammenfuehren notiert es) und geht von dort an C -- auch
// wenn A und C sich nie sehen. Umgekehrt genauso; Konflikte loest R5 auf
// jeder Maschine gleich, daher konvergieren alle.
// ===========================================================================
#include "json.h"

namespace timeline {

struct Partner {
    std::string   geraet;                  // Name des Partners
    std::uint64_t vonMirBestaetigt = 0;    // hoechste MEINE Nummer, die er hat
    std::uint64_t vonIhmGesehen    = 0;    // hoechste SEINE Nummer, die ich habe
};

// Was ich Partner P noch schulde (Events + Vermerke ueber seiner Bestaetigung).
inline bool vonIhm(const std::map<Id, std::string>& h, Id id, const std::string& p) {
    auto it = h.find(id); return it != h.end() && it->second == p; }
inline bool vonIhm(const std::map<Gestartet, std::string>& h, Gestartet g, const std::string& p) {
    auto it = h.find(g); return it != h.end() && it->second == p; }
inline std::size_t ausstehend(const Speicher& s, const Partner& p) {
    std::size_t n = 0;
    for (auto& kv : s.eventSeq)     if (kv.second > p.vonMirBestaetigt && !vonIhm(s.eventHerkunft, kv.first, p.geraet)) ++n;
    for (auto& kv : s.gestartetSeq) if (kv.second > p.vonMirBestaetigt && !vonIhm(s.gestartetHerkunft, kv.first, p.geraet)) ++n;
    return n;
}

inline json anfrage(const Speicher& s, const Partner& p) {
    json j; j["typ"] = "anfrage"; j["von"] = s.geraet; j["seit"] = p.vonIhmGesehen; return j;
}

// Delta ab Nummer <seit>; fuer Partner P ist seit = p.vonMirBestaetigt.
// <fuer> = Empfaenger: was von ihm selbst kam, bekommt er nicht zurueck.
inline json delta(const Speicher& s, std::uint64_t seit, const std::string& fuer) {
    json j; j["typ"] = "delta"; j["von"] = s.geraet; j["seit"] = seit; j["bis"] = s.seq;
    json ev = json::array();
    for (auto& kv : s.eventSeq) if (kv.second > seit && !vonIhm(s.eventHerkunft, kv.first, fuer))
        if (const Event* e = s.finde(kv.first)) ev.push_back(eventZuJson(*e));
    j["events"] = ev;
    json ge = json::array();
    for (auto& kv : s.gestartetSeq) if (kv.second > seit && !vonIhm(s.gestartetHerkunft, kv.first, fuer)) {
        json g; g["event"] = kv.first.event; g["start"] = kv.first.start; ge.push_back(g); }
    j["gestartet"] = ge;
    return j;
}
inline json delta(const Speicher& s, const Partner& p) { return delta(s, p.vonMirBestaetigt, p.geraet); }

// Eingehendes Delta anwenden (R5). Idempotent. Aktualisiert p.vonIhmGesehen.
inline AbgleichErgebnis deltaAnwenden(Speicher& s, const json& j, Partner& p) {
    AbgleichErgebnis erg;
    if (j.value("typ", "") != "delta") return erg;
    Speicher fremd; fremd.geraet = j.value("von", "");
    for (auto& o : j.value("events", json::array())) { Event e = eventAusJson(o); if (e.id) fremd.events[e.id] = e; }
    for (auto& g : j.value("gestartet", json::array())) fremd.gestartet.insert({ g.value("event", (Id)0), g.value("start", (Zeit)0) });
    erg = zusammenfuehren(s, fremd);
    const std::uint64_t bis = j.value("bis", (std::uint64_t)0);
    if (bis > p.vonIhmGesehen) p.vonIhmGesehen = bis;
    return erg;
}

inline json bestaetigung(const Speicher& s, const Partner& p) {
    json j; j["typ"] = "bestaetigung"; j["von"] = s.geraet; j["bis"] = p.vonIhmGesehen; return j;
}
inline void bestaetigungAnwenden(const json& j, Partner& p) {
    if (j.value("typ", "") != "bestaetigung") return;
    const std::uint64_t bis = j.value("bis", (std::uint64_t)0);
    if (bis > p.vonMirBestaetigt) p.vonMirBestaetigt = bis;
}

// Einzelnes eingehendes Paket beliebigen Typs verarbeiten; liefert die
// Antwort, die zurueckzuschicken ist (oder null). Das ist der eine
// Einstiegspunkt, den der Transport aufruft.
inline json verarbeiten(Speicher& s, const json& paket, Partner& p) {
    const std::string typ = paket.value("typ", "");
    if (typ == "anfrage")       return delta(s, paket.value("seit", (std::uint64_t)0), paket.value("von", ""));
    if (typ == "delta")         { deltaAnwenden(s, paket, p); return bestaetigung(s, p); }
    if (typ == "bestaetigung")  { bestaetigungAnwenden(paket, p); return json(); }
    return json();
}

} // namespace timeline
