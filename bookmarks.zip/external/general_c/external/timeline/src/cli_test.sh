#!/bin/bash
# Prueft die Kommandozeile Ende-zu-Ende: zwei Geraete, Datei-basierter Abgleich.
T=${1:-./timeline}; rm -rf /tmp/tl && mkdir -p /tmp/tl
fehler=0; pruef(){ if [ "$1" = "$2" ]; then echo "  OK  $3"; else echo "  FEHLER $3 (ist: '$1', soll: '$2')"; fehler=$((fehler+1)); fi; }
A="$T -d /tmp/tl/a.json -z 2 -g laptop"; B="$T -d /tmp/tl/b.json -z 2 -g handy"
id1=$($A neu "Zahnarzt" 2026-10-05T09:00 60);            pruef "$id1" "1" "neu liefert Id 1"
id2=$($A neu "Standup" 2026-10-05T09:00 15);              $A aendern $id2 takt woechentlich >/dev/null; $A aendern $id2 wochentage mo,mi,fr >/dev/null
k=$($A kind $id2 "gleich Standup" -15 erinnerung);        pruef "$k" "3" "kind liefert Id 3"
n=$($A liste 2026-10-05 2026-10-12 | wc -l);               pruef "$n" "7" "Liste: Zahnarzt + 3 Standups + 3 Erinnerungen = 7 Zeilen"
z=$($A liste 2026-10-05 2026-10-12 | grep ERINN | head -1 | cut -c1-16); pruef "$z" "2026-10-05T08:45" "Erinnerung 15 min vor dem Standup (Mo 5.10.)"
$A nurdiesen $id2 2026-10-09T09:00 >/dev/null;            $A aendern 4 start 2026-10-09T11:00 >/dev/null
z=$($A liste 2026-10-09 2026-10-10 | grep -v ERINN | cut -c1-16); pruef "$z" "2026-10-09T11:00" "'nur diesen' am Freitag auf 11:00"
$A aendern $id1 leer 2>/dev/null; rc=$?;                   pruef "$rc" "2" "falsches Feld -> Bedienfehler (Exit 2)"
v=$($A vorlage "Reinigung");                              $A aendern $v aktion pdfgen '{"quelle":"r.txt"}' >/dev/null; $A aendern $v erinnern 30 >/dev/null
r=$($A neu "Reinigung Kunde" 2026-10-07T07:00);           $A aendern $r notizen "" >/dev/null
# Vorlage per JSON zuweisen ist (noch) kein CLI-Befehl -> ueber zeige pruefen wir nur die Vorlage selbst
z=$($A zeige $v | grep -c "Aktion: pdfgen");              pruef "$z" "1" "Vorlage traegt die Aktion"
# ---- Abgleich ueber Dateien: laptop -> handy -> laptop ----
$B sync-anfrage laptop > /tmp/tl/p1.json;  $A sync-anwenden handy < /tmp/tl/p1.json > /tmp/tl/p2.json
$B sync-anwenden laptop < /tmp/tl/p2.json > /tmp/tl/p3.json; $A sync-anwenden handy < /tmp/tl/p3.json >/dev/null
n=$($B liste 2026-10-05 2026-10-12 | wc -l);               pruef "$n" "7" "Handy hat nach dem Abgleich dieselben 7 Vorkommen"
sleep 1; $B aendern $id1 titel "Zahnarzt (vom Handy)" >/dev/null     # eine Sekunde spaeter -> R5 entscheidet nach Zeit
$A sync-anfrage handy > /tmp/tl/q1.json; $B sync-anwenden laptop < /tmp/tl/q1.json > /tmp/tl/q2.json
sz=$(python3 -c "import json;print(len(json.load(open('/tmp/tl/q2.json'))['events']))"); pruef "$sz" "1" "Delta vom Handy enthaelt genau die eine Aenderung"
$A sync-anwenden handy < /tmp/tl/q2.json >/dev/null
z=$($A zeige $id1 | head -1 | grep -c "vom Handy");       pruef "$z" "1" "Aenderung des Handys auf dem Laptop angekommen"
$A aendern $r aktion pdfgen >/dev/null
$A verpasst 2026-10-01 >/dev/null; rc=$?;                  pruef "$rc" "$([ $(date +%s) -gt $(date -d 2026-10-07T07:00+02:00 +%s) ] && echo 3 || echo 0)" "verpasst: Exit 3 nur, wenn der Termin schon vorbei ist"
# ---- Rueckfall: starten + cron ----
C="$T -d /tmp/tl/c.json -z 2 -g server"
e=$($C neu "Sicherung" 2099-01-02T03:04); $C aendern $e aktion "python3 -c 'import json,sys;d=json.load(sys.stdin);print(\"ziel=\"+d[\"ziel\"])'" '{"ziel":"/mnt/nas"}' >/dev/null
bald=$(TZ=Etc/GMT-2 date -d "+1 hour" +%Y-%m-%dT%H:%M); h=$(TZ=Etc/GMT-2 date -d "+1 hour" +%-H); mi=$(TZ=Etc/GMT-2 date -d "+1 hour" +%-M)   # alles in der Zeitzone des Programms (-z 2)
f=$($C neu "Foto-Upload" $bald); $C aendern $f takt taeglich >/dev/null; $C aendern $f aktion "true" >/dev/null
n=$($C cron 3 --client meinclient | grep -c "^[0-9]"); pruef "$n" "3" "cron: taeglich, 3 Tage -> 3 Zeilen"
z=$($C cron 3 | grep "^[0-9]" | head -1); pruef "$(echo "$z" | cut -d' ' -f1-2)" "$mi $h" "cron: Minute und Stunde in der lokalen Zeit (-z 2)"
echo "$z" | grep -q "pgrep -x x_bookmark_manager >/dev/null ||"; pruef "$?" "0" "cron: Zeile laeuft nur, wenn kein Client laeuft"
echo "$z" | grep -q "starten $f "; pruef "$?" "0" "cron: Zeile ruft 'starten' mit der Event-Id"
o=$($C starten $e 2099-01-02T03:04 | head -1); pruef "$o" "ziel=/mnt/nas" "starten: Befehl laeuft mit Parameter-JSON auf stdin"
o=$($C starten $e 2099-01-02T03:04); pruef "$o" "schon gestartet -- nichts zu tun" "starten: zweiter Aufruf tut nichts (Vermerk)"
$C starten $f $bald >/dev/null; n=$($C cron 3 | grep -c "^[0-9]"); pruef "$n" "2" "cron laesst das gestartete Vorkommen weg (3 -> 2)"
$C aendern $e aktion "exit 7" >/dev/null; $C starten $e 2099-01-03T03:04 >/dev/null; rc=$?; pruef "$rc" "1" "starten: Befehl mit Exit != 0 -> Exit 1"
echo; [ $fehler = 0 ] && echo "ALLE PRUEFUNGEN BESTANDEN" || { echo "### $fehler FEHLER ###"; exit 1; }
