# timeline -- Datenmodell des Schedulers

Header-only, UI-frei, ohne Netz und Dateien. `model.h` ist der Kern des
kuenftigen Projekts `external/timeline`; `model_test.cpp` haelt jede Regel
in einer Pruefung fest (42 Pruefungen, Linux und Windows).

    g++ -std=gnu++17 -Isrc -o model_test src/model_test.cpp && ./model_test

## Regeln (R1-R6)

- **R1 Rueckfall:** Ein Feld ist gesetzt oder faellt zurueck: Event -> Vorlage
  -> Elternteil. Ein ausdruecklich LEER gesetztes Feld bleibt leer (kein
  Rueckfall); "loeschen()" stellt den Rueckfall wieder her.
- **R2 Vorlage loeschen** loest sie in ihren Instanzen auf: Rueckfallwerte
  werden zu eigenen Werten. Nichts geht verloren.
- **R3 Serien aendern:** "nur diesen" = Ausnahme + abgeloestes Event (mit
  eigenen Kopien aller Kinder); "ab hier" = Serie teilen (alte endet davor,
  neue beginnt dort, Teilbaum kopiert); "jedes n-te ab hier" = "ab hier"
  mit neuem Intervall. Dasselbe an UNTER-Events: `kindAbHier()` und
  `kindNurDiesen()` liefern die Kopie des Kindes in der neuen Serie bzw. im
  abgeloesten Vorkommen -- Aenderungen daran gelten ab dort bzw. nur dort.
- **R4 Sub-Events** liegen immer als Versatz zum Elternteil und folgen jedem
  Vorkommen und jeder Verschiebung.
- **R5 Abgleich:** Letzter-schreibt-gewinnt je Event nach (modified, geraet);
  Loeschungen sind Grabsteine und gewinnen bei Gleichstand. Beide Seiten
  kommen ohne Absprache zum selben Ergebnis.
- **R6 Verpasst:** ein Aktions-Vorkommen im Fenster (zuletztGeprueft, jetzt],
  das nicht als gestartet vermerkt ist -- sofern "nachstarten wenn verpasst".
- **R7 Beziehung:** Jedes Event kann beliebig viele Kinder haben, jedes Kind
  wieder Kinder, ohne Tiefengrenze und unabhaengig von der Art. Die
  Beziehung steht explizit und geordnet am Elternteil (`kinder`) und als
  Rueckverweis am Kind (`eltern`); `zuordnen()`/`loesen()` halten beide
  Seiten gleich, Zyklen werden abgewiesen, Versaetze summieren sich ueber
  die Ebenen, Loeschen wirkt auf den Teilbaum.

## Abbildung des heutigen CalEntry (ui_calendar.h)

| CalEntry                 | timeline::Event                         |
|--------------------------|-----------------------------------------|
| id, start, durMin, allDay| gleich                                  |
| title, notes             | titel, notizen (Opt, gesetzt)           |
| color                    | farbe (Opt)                             |
| remindOn/remindMin       | erinnernMin (Opt; <0 = aus)             |
| actions                  | aktion (Opt<Aktion>) bzw. Sub-Events Art::Aktion |
| wdh/wdhJede/wdhBis       | regel.takt/jede/bis                     |
| created/modified         | created, stempel.modified (+ geraet)    |
| memos, audio             | bleiben in der UI-Schicht (Anhaenge)    |
| source                   | quelle                                  |

Neu gegenueber CalEntry: eltern/kinder/versatz (Sub-Events, beliebig tief), vorlage/istVorlage,
abgeloestVon + ausnahmen (nur diesen), zusatzTermine, regel.wochentage/anzahl,
Aktion mit Zielhosts/Ablaufart, Grabsteine fuer den Abgleich.

## json.h -- Laden, Speichern, Migration (23 Pruefungen)

    g++ -std=gnu++17 -Isrc -o json_test src/json_test.cpp && ./json_test

- Format "timeline" Version 1; nur GESETZTE Opt-Felder werden geschrieben
  (fehlend = Rueckfall, vorhanden leer = ausdruecklich leer).
- Zweite Rundreise ergibt byteidentisches JSON; neuere Versionen werden
  mit klarer Meldung abgelehnt.
- `migrierenAusCalendarJson()`: calendar.json (App-Version 2) -> Modell.
  CalAction wird zum Kind-Event (Alarm/Ton -> Benachrichtigung, sonst
  Aktion mit "alarm|ton|audio|pdf|mail|befehl" und den alten Feldern als
  JSON-Parameter). Memos/Audio landen unveraendert in `Event::zusatz`.
  "Wochentags" wird zu Woechentlich Mo-Fr, "Woechentlich" zum Wochentag
  des Starts.

Beim ersten Start der neuen Fassung: calendar.json lesen -> migrieren ->
als timeline.json schreiben -> calendar.json als calendar.json.v2 behalten.
Das Journal (siehe sync.h) wird mitgespeichert, getrennt von den Events.

## sync.h -- Abgleich zwischen Clients und Server (19 Pruefungen)

    g++ -std=gnu++17 -Isrc -o sync_test src/sync_test.cpp && ./sync_test

Netzfrei: erzeugt und verarbeitet JSON-Pakete (anfrage, delta,
bestaetigung); netlink/der Hub transportieren sie nur. Ein Einstiegspunkt
fuer den Transport: `verarbeiten(speicher, paket, partner)` liefert die
Antwort. Grundlage ist das Journal im Speicher (laufende lokale Nummern je
Aenderung, mit Herkunft, damit nichts an den Absender zurueckgeht).
Getestet: erster Kontakt, Echtzeit-Delta mit genau der einen Aenderung,
gleichzeitige Bearbeitung (R5 konvergiert), transitiv ueber den Server mit
Offline-Phase, Grabsteine und Startvermerke, Idempotenz, neues Geraet,
Neustart.

## Kommandozeile `timeline` (cli.cpp, Ende-zu-Ende-Test cli_test.sh)

    timeline [-d DATEI] [-z ZEITZONE_STD] [-g GERAET] BEFEHL ...
    liste | zeige | neu | aendern | leeren | loeschen | kind | nurdiesen |
    abhier | vorlage | verpasst | gestartet | migrieren | sync-anfrage |
    sync-delta | sync-anwenden | starten | cron

Beispiele:
    timeline -z 2 neu "Standup" 2026-10-05T09:00 15        -> Id
    timeline -z 2 aendern 2 takt woechentlich; timeline -z 2 aendern 2 wochentage mo,mi,fr
    timeline -z 2 kind 2 "gleich Standup" -15 erinnerung
    timeline -z 2 nurdiesen 2 2026-10-09T09:00               -> Id des abgeloesten Vorkommens
    timeline -z 2 verpasst 2026-10-01                        -> Exit 3, wenn Aktionen verpasst sind
    timeline migrieren calendar.json

Abgleich ueber beliebigen Transport (hier Dateien):
    handy:  timeline sync-anfrage laptop  > p1.json
    laptop: timeline sync-anwenden handy  < p1.json > p2.json
    handy:  timeline sync-anwenden laptop < p2.json > p3.json
    laptop: timeline sync-anwenden handy  < p3.json
Der Partnerstand liegt neben der Datei (<datei>.partner.<name>).

Rueckfall auf reinem Linux (kein Client, kein hub):
    timeline cron 7 | crontab -          # Aktions-Vorkommen der naechsten 7 Tage
Jede Zeile: `pgrep -x x_bookmark_manager >/dev/null || timeline ... starten ID ZEIT`
-- laeuft also nur, wenn kein Client laeuft. `starten` fuehrt den Befehl der
Aktion als Shell-Befehl aus (Parameter-JSON auf stdin), vermerkt das
Vorkommen VOR dem Start (kein Doppelstart mit einem gleichzeitig startenden
Client) und tut beim zweiten Aufruf nichts. Ein Client, der wieder startet,
sollte die crontab neu erzeugen (`timeline cron 7 | crontab -`), damit sie
aktuell bleibt.

## Bauen als Projekt / Submodul (CMakeLists.txt)

    cmake -B build -S . && cmake --build build && ctest --test-dir build
    # in bookmarks: add_subdirectory(external/timeline);
    #               target_link_libraries(x_bookmark_manager PRIVATE timeline::timeline)

## Naechste Schritte (in dieser Reihenfolge)
4. UI in bookmarks auf das Modell umstellen (Editor fuer Regel, Ausnahmen,
   Vorlagen in "navi 1", Sub-Events unter dem gewaehlten Event).
5. Auslagerung als Submodul external/timeline.

