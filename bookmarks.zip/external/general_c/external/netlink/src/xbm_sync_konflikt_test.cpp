#include "xbm_cmdchan.h"
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <thread>
namespace fs = std::filesystem;
static void schreib(const std::string& p, const std::string& t, std::int64_t mt=0) {
    fs::create_directories(fs::path(p).parent_path());
    { std::ofstream f(p, std::ios::binary); f << t; }
    if (mt) { std::error_code ec;
        fs::last_write_time(p, fs::file_time_type(std::chrono::seconds(mt)), ec); }
}
static std::string lies(const std::string& p){ std::ifstream f(p,std::ios::binary);
    return std::string((std::istreambuf_iterator<char>(f)),std::istreambuf_iterator<char>()); }

int main(){
    int fehler=0;
    fs::remove_all("/tmp/kA"); fs::remove_all("/tmp/kB");
    // Gleiche mtime, VERSCHIEDENER Inhalt -> Konflikt
    schreib("/tmp/kA/streit.txt", "Fassung A ist laenger\n", 1700000000);
    schreib("/tmp/kB/streit.txt", "Fassung B\n",             1700000000);
    // Klar neuer auf B -> soll gewinnen
    schreib("/tmp/kA/neuer.txt", "alt\n",  1700000000);
    schreib("/tmp/kB/neuer.txt", "neu\n",  1700009999);

    XbmCmdServer srv; srv.Start(0,"g"); srv.SetSyncDir("/tmp/kB");
    XbmCmdClient cli; cli.Connect("127.0.0.1", srv.Port(), "g");
    for(int i=0;i<200 && cli.GetStatus()!=XbmCmdStatus::Bereit;i++){ srv.Poll();cli.Poll();
        std::this_thread::sleep_for(std::chrono::milliseconds(2)); }
    bool fertig=false; XbmSyncErgebnis erg;
    cli.StartSync("/tmp/kA",[&](const XbmSyncErgebnis& e){erg=e;fertig=true;});
    for(int i=0;i<3000 && !fertig;i++){ srv.Poll();cli.Poll();
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); }

    std::printf("  konflikte=%d\n", erg.konflikte);
    for(auto&m:erg.meldungen) std::printf("    %s\n", m.c_str());
    bool kopie = fs::exists("/tmp/kA/streit.txt.konflikt");
    std::printf("  Konfliktkopie angelegt: %s\n", kopie?"ja":"### NEIN ###");
    if(!kopie) fehler++;
    if(kopie) std::printf("    darin steht: %s", lies("/tmp/kA/streit.txt.konflikt").c_str());
    std::printf("  neuer.txt auf A: %s", lies("/tmp/kA/neuer.txt").c_str());
    if (lies("/tmp/kA/neuer.txt") != "neu\n") { std::printf("  ### erwartet neu ###\n"); fehler++; }
    std::printf(fehler?"  ### %d FEHLER ###\n":"  bestanden\n", fehler);
    return fehler?1:0;
}
