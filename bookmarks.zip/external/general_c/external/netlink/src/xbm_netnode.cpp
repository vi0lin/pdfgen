// ---------------------------------------------------------------------------
// xbm_netnode.cpp
// ---------------------------------------------------------------------------
#include "xbm_netnode.h"

#include <algorithm>
#include <chrono>
#include <filesystem>
#include <sstream>

namespace fs = std::filesystem;

namespace {
std::int64_t jetztMs() {
    return (std::int64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

// Wie sieht der Ordner gerade aus? Nur Groesse und Zeit -- das genuegt,
// um eine Aenderung zu erkennen, und kostet kein Lesen der Inhalte.
// [Ein Hash ueber alle Dateien waere genauer, wuerde bei data/ mit
//  Bildern und PDFs aber jedes Mal den ganzen Ordner lesen. Bei einem
//  Blick alle drei Sekunden ist das der falsche Preis.]
std::string ordnerAbdruck(const std::string& wurzel) {
    if (wurzel.empty()) return "";
    std::error_code ec;
    if (!fs::exists(wurzel, ec)) return "";
    std::vector<std::string> teile;
    for (auto it = fs::recursive_directory_iterator(
                       wurzel, fs::directory_options::skip_permission_denied, ec);
         it != fs::recursive_directory_iterator(); it.increment(ec)) {
        if (ec) { ec.clear(); continue; }
        if (!it->is_regular_file(ec)) continue;
        auto rel = fs::relative(it->path(), wurzel, ec).generic_string();
        if (rel.empty() || rel[0] == '.' ||
            rel.find("/.") != std::string::npos) continue;
        auto gr = (std::uint64_t)fs::file_size(it->path(), ec);
        auto tp = fs::last_write_time(it->path(), ec);
        auto sek = (std::int64_t)std::chrono::duration_cast<std::chrono::seconds>(
                       tp.time_since_epoch()).count();
        teile.push_back(rel + ":" + std::to_string(gr) + ":" + std::to_string(sek));
    }
    std::sort(teile.begin(), teile.end());
    std::ostringstream os;
    for (auto& t : teile) os << t << '\n';
    return os.str();
}
} // namespace

struct XbmNetNode::Impl {
    XbmNetConfig cfg;
    std::string fehler;
    bool laeuft = false;

    XbmDiscovery disc;
    XbmCmdServer srv;

    struct Auftrag {
        bool istSync = false; std::string befehl;
        // Nachricht (Rahmen J/j) -- text gesetzt = Nachrichtenauftrag
        std::string nachricht; std::function<void(const std::string&)> onAntwort;
        bool istNachricht() const { return !nachricht.empty(); }
    };
    struct Verbindung {
        std::unique_ptr<XbmCmdClient> cli;
        std::deque<Auftrag> warteschlange;
        // fuer StatusOn()
        std::int64_t startMs = 0;
        int  letzterCode = 0;
        bool hatteBefehl = false;
        std::string befehl;
    };
    std::map<std::string, Verbindung> verb;     // peerId -> Verbindung
    std::map<std::string, XbmNetPeer> peers;

    // Jobs -- jeder mit eigener Verbindung.
    struct JobIntern {
        Job daten;
        std::unique_ptr<XbmCmdClient> cli;
        bool gestartet = false;
    };
    std::vector<std::unique_ptr<JobIntern>> jobs;
    int naechsteJobId = 1;

    // Scripts je Geraet: Namen + Zeitpunkt der letzten Abfrage.
    struct ScriptsCache { std::vector<std::string> namen; std::int64_t abgefragtMs = 0; bool laeuft = false; };
    std::map<std::string, ScriptsCache> scripts;

    std::deque<Zeile> protokoll;
    Stats stats;

    bool autoSync = false;
    std::string letzterAbdruck;
    std::int64_t naechsterBlick = 0;

    void melde(const std::string& peer, const std::string& text, bool f = false) {
        protokoll.push_back({peer, text, f});
        // [Ohne Begrenzung waechst der Puffer bei einem langen Bau ins
        //  Unermessliche -- die Oberflaeche zeigt ohnehin nur das Ende.]
        while (protokoll.size() > 2000) protokoll.pop_front();
    }

    // Verbindung zu einem Gegenpart herstellen oder liefern.
    XbmCmdClient* holeVerbindung(const std::string& id) {
        auto pit = peers.find(id);
        if (pit == peers.end()) return nullptr;
        auto& v = verb[id];
        if (!v.cli) v.cli = std::make_unique<XbmCmdClient>();
        auto st = v.cli->GetStatus();
        if (st == XbmCmdStatus::Getrennt || st == XbmCmdStatus::FehlerNetz) {
            if (!v.cli->Connect(pit->second.ip, pit->second.cmdPort, cfg.geheimnis)) {
                return nullptr;
            }
        }
        return v.cli.get();
    }
};

XbmNetNode::XbmNetNode() : p_(new Impl) {}
XbmNetNode::~XbmNetNode() { Stop(); }
bool XbmNetNode::Running() const { return p_->laeuft; }
const char* XbmNetNode::LastError() const { return p_->fehler.c_str(); }
const std::deque<XbmNetNode::Zeile>& XbmNetNode::Protokoll() const { return p_->protokoll; }
void XbmNetNode::ProtokollLeeren() { p_->protokoll.clear(); }
bool XbmNetNode::AutoSync() const { return p_->autoSync; }
std::string XbmNetNode::SelfId() const { return p_->disc.SelfId(); }

bool XbmNetNode::Start(const XbmNetConfig& cfg) {
    Stop();
    if (cfg.geheimnis.empty()) {
        // [Der Befehlskanal fuehrt aus, was ueber das Netz kommt. Ohne
        //  Geheimnis waere das eine Fernsteuerung fuer jeden im WLAN.]
        p_->fehler = "Geheimnis fehlt -- ohne startet das Netzwerk nicht";
        return false;
    }
    p_->cfg = cfg;
    XbmNet_Init();

    if (!p_->srv.Start(cfg.cmdPort, cfg.geheimnis)) {
        p_->fehler = std::string("Befehlskanal: ") + p_->srv.LastError();
        return false;
    }
    if (!cfg.syncDir.empty()) {
        std::error_code ec;
        fs::create_directories(cfg.syncDir, ec);
        p_->srv.SetSyncDir(cfg.syncDir);
    }
    if (!cfg.scriptsDir.empty()) {
        std::error_code ec;
        fs::create_directories(cfg.scriptsDir, ec);
        p_->srv.SetScriptsDir(cfg.scriptsDir);
    }
    p_->srv.onLog = [this](const std::string& z) { p_->melde("hier", z); };

    // DIESES GERAET ALS EINTRAG IN DER LISTE. [Ueber die Rueckschleife
    //  zum eigenen Server -- damit laufen lokale Befehle und Scripts
    //  ueber genau dieselbe Mechanik wie entfernte: gleicher Status,
    //  gleicher Abbruch, gleiche Scriptliste. Kein Sonderweg.]
    {
        auto& me = p_->peers[SelbstId()];
        me.id = SelbstId();
        me.name = cfg.name + " (lokal)";
        me.ip = "127.0.0.1";
        me.cmdPort = p_->srv.Port();
        me.lastSeenMs = jetztMs();
    }

    XbmDiscoveryConfig dc;
    dc.port    = cfg.discPort;
    dc.appId   = "xbm";
    dc.name    = cfg.name;
    // WICHTIG: der Befehlsport reist in der Ankuendigung mit.
    // [Sonst wuesste die Gegenseite zwar, DASS es uns gibt, aber nicht,
    //  wohin sie einen Befehl schicken soll.]
    dc.dataPort = 0;
    if (!p_->disc.Start(dc)) {
        p_->fehler = "Entdeckung liess sich nicht starten (Broadcast erlaubt?)";
        p_->srv.Stop();
        return false;
    }
    p_->disc.SetPayload("cmd=" + std::to_string(p_->srv.Port()));

    p_->laeuft = true;
    p_->melde("hier", "Netzwerk gestartet, Befehlsport " +
                      std::to_string(p_->srv.Port()));
    return true;
}

void XbmNetNode::Stop() {
    if (!p_) return;
    p_->verb.clear();
    p_->disc.Stop();
    p_->srv.Stop();
    p_->peers.clear();
    p_->laeuft = false;
}

std::vector<XbmNetPeer> XbmNetNode::Peers() const {
    std::vector<XbmNetPeer> aus;
    aus.reserve(p_->peers.size());
    for (auto& kv : p_->peers) aus.push_back(kv.second);
    std::sort(aus.begin(), aus.end(),
              [](const XbmNetPeer& a, const XbmNetPeer& b) { return a.name < b.name; });
    return aus;
}

void XbmNetNode::SetAusgewaehlt(const std::string& id, bool an) {
    auto it = p_->peers.find(id);
    if (it != p_->peers.end()) it->second.ausgewaehlt = an;
}

void XbmNetNode::SetAutoSync(bool an) {
    p_->autoSync = an;
    if (an) {
        // Beim Einschalten den jetzigen Stand merken -- sonst wuerde
        // sofort ein voller Abgleich losgehen.
        p_->letzterAbdruck = ordnerAbdruck(p_->cfg.syncDir);
        p_->naechsterBlick = jetztMs() + p_->cfg.autoSyncMs;
        p_->melde("hier", "automatischer Abgleich ein");
    } else {
        p_->melde("hier", "automatischer Abgleich aus");
    }
}

void XbmNetNode::AbgleichJetzt() {
    // Einfach den naechsten Blick auf JETZT vorziehen -- Poll() macht
    // beim naechsten Aufruf (das ist normalerweise noch im selben
    // Frame oder dem naechsten) den Rest: Fingerabdruck vergleichen,
    // bei Aenderung an die angehakten Gegenstellen abgleichen. Kein
    // eigener Sonderweg noetig, nur die Wartezeit entfaellt.
    p_->naechsterBlick = jetztMs();
}

void XbmNetNode::Poll() {
    if (!p_->laeuft) return;

    // --- Entdeckung ---
    p_->disc.Poll();
    auto gefunden = p_->disc.Peers();
    std::map<std::string, bool> gesehen;
    for (auto& d : gefunden) {
        gesehen[d.id] = true;
        auto& e = p_->peers[d.id];
        bool neu = e.id.empty();
        e.id = d.id;
        e.name = d.name;
        e.ip = d.endpoint.ip;
        // LAEUFT DER GEGENPART AUF DERSELBEN MASCHINE?
        // [Dann ueber die Rueckschleife verbinden. Zwei Instanzen auf
        //  einem Rechner sind beim Ausprobieren der Normalfall -- und
        //  ueber die eigene aeussere Adresse zu gehen, funktioniert je
        //  nach Netzwerkeinrichtung nicht.]
        for (auto& eigen : XbmNet_LocalAddresses())
            if (eigen == e.ip) { e.ip = "127.0.0.1"; break; }
        e.lastSeenMs = d.lastSeenMs;
        // Befehlsport aus der Ankuendigung lesen.
        auto pos = d.payload.find("cmd=");
        if (pos != std::string::npos)
            e.cmdPort = (std::uint16_t)std::strtoul(d.payload.c_str() + pos + 4,
                                                    nullptr, 10);
        if (e.cmdPort == 0) e.cmdPort = p_->cfg.cmdPort;
        if (neu) {
            p_->melde(e.name, "gefunden auf " + e.ip + ":" +
                              std::to_string(e.cmdPort));
            if (onJoin) onJoin(e);
        }
    }
    // Verschwundene entfernen.
    for (auto it = p_->peers.begin(); it != p_->peers.end();) {
        if (it->first == SelbstId()) { it->second.lastSeenMs = jetztMs(); ++it; continue; }
        if (!gesehen.count(it->first)) {
            p_->melde(it->second.name, "nicht mehr erreichbar");
            if (onLeave) onLeave(it->second);
            p_->verb.erase(it->first);
            it = p_->peers.erase(it);
        } else {
            ++it;
        }
    }

    // --- Befehlsserver ---
    p_->srv.Poll();

    // --- offene Verbindungen und ihre Warteschlangen ---
    for (auto& kv : p_->verb) {
        auto& v = kv.second;
        if (!v.cli) continue;
        auto pit = p_->peers.find(kv.first);
        if (pit == p_->peers.end()) continue;

        // Verbindung herstellen, wenn noetig und etwas ansteht.
        auto st = v.cli->GetStatus();
        if (!v.warteschlange.empty() &&
            (st == XbmCmdStatus::Getrennt || st == XbmCmdStatus::FehlerNetz)) {
            if (!v.cli->Connect(pit->second.ip, pit->second.cmdPort,
                                p_->cfg.geheimnis)) {
                p_->melde(pit->second.name, "nicht erreichbar", true);
                v.warteschlange.clear();
            }
        }
        v.cli->Poll();
        st = v.cli->GetStatus();
        pit->second.status = st;

        if (st == XbmCmdStatus::FehlerGeheimnis) {
            if (!v.warteschlange.empty()) {
                p_->melde(pit->second.name, "Geheimnis stimmt nicht", true);
                v.warteschlange.clear();
            }
            continue;
        }
        // Abschicken, sobald bereit und nichts anderes laeuft.
        if (st == XbmCmdStatus::Bereit && !v.warteschlange.empty() &&
            !v.cli->Busy() && !v.cli->SyncBusy()) {
            auto a = v.warteschlange.front();
            v.warteschlange.pop_front();
            const std::string name = pit->second.name;
            if (a.istNachricht()) {
                // Antwort kommt asynchron ueber den Rueckruf; mehrere duerfen
                // offen sein (cmdchan haelt die Rueckrufe in Reihenfolge).
                v.cli->Nachricht(a.nachricht, std::move(a.onAntwort));
            } else if (a.istSync) {
                p_->stats.syncLaeufe++;
                v.cli->StartSync(p_->cfg.syncDir,
                    [this, name](const XbmSyncErgebnis& e) {
                        p_->stats.dateienHer += (std::uint64_t)e.geholt;
                        p_->stats.dateienHin += (std::uint64_t)e.geschickt;
                        p_->melde(name, "Abgleich: " + std::to_string(e.geholt) +
                                        " geholt, " + std::to_string(e.geschickt) +
                                        " geschickt, " + std::to_string(e.gleich) +
                                        " gleich, " + std::to_string(e.konflikte) +
                                        " Konflikte", e.konflikte > 0);
                        for (auto& m : e.meldungen) p_->melde(name, m, true);
                    });
            } else {
                p_->stats.befehle++;
                p_->melde(name, "$ " + a.befehl);
                v.startMs = jetztMs();
                v.befehl  = a.befehl;
                v.hatteBefehl = true;
                const std::string peerKey = kv.first;
                v.cli->Run(a.befehl,
                    [this, name](const std::string& z, bool f) {
                        std::string t = z;
                        while (!t.empty() && (t.back()=='\n' || t.back()=='\r'))
                            t.pop_back();
                        p_->melde(name, t, f);
                    },
                    [this, name, peerKey](int code) {
                        // Ueber die Kennung nachschlagen statt einen rohen
                        // Zeiger zu halten -- falls die Verbindung inzwischen
                        // entfernt wurde, passiert so nichts Schlimmes.
                        auto vit = p_->verb.find(peerKey);
                        if (vit != p_->verb.end()) vit->second.letzterCode = code;
                        // Abbruch erkennbar machen -- 143/137/130 sind keine
                        // gewoehnlichen Fehler, sondern unser eigener Stopp.
                        const bool abbruch = (code == 143 || code == 137 || code == 130);
                        p_->melde(name, abbruch
                                  ? "ABGEBROCHEN (" + std::to_string(code) + ")"
                                  : "beendet mit " + std::to_string(code),
                                  code != 0);
                    });
            }
        }
    }

    // --- Jobs: verbinden, starten, abholen ---
    for (auto& jp : p_->jobs) {
        auto& j = *jp;
        if (j.daten.status == JobStatus::Fertig || j.daten.status == JobStatus::Fehler
            || j.daten.status == JobStatus::Abgebrochen) continue;
        auto pit = p_->peers.find(j.daten.peerId);
        if (pit == p_->peers.end()) {
            j.daten.status = JobStatus::Fehler; j.daten.code = -1; j.daten.endeMs = jetztMs();
            j.daten.ausgabe.push_back("Geraet nicht mehr erreichbar");
            continue;
        }
        if (!j.cli) j.cli = std::make_unique<XbmCmdClient>();
        auto st = j.cli->GetStatus();
        if (st == XbmCmdStatus::Getrennt || st == XbmCmdStatus::FehlerNetz) {
            if (j.daten.status == JobStatus::Verbindet && st == XbmCmdStatus::FehlerNetz) {
                j.daten.status = JobStatus::Fehler; j.daten.code = -1; j.daten.endeMs = jetztMs();
                j.daten.ausgabe.push_back("nicht erreichbar");
                continue;
            }
            j.daten.status = JobStatus::Verbindet;
            if (!j.cli->Connect(pit->second.ip, pit->second.cmdPort, p_->cfg.geheimnis)) {
                j.daten.status = JobStatus::Fehler; j.daten.code = -1; j.daten.endeMs = jetztMs();
                j.daten.ausgabe.push_back(std::string("Verbindung: ") + j.cli->LastError());
                continue;
            }
        }
        j.cli->Poll();
        st = j.cli->GetStatus();
        if (st == XbmCmdStatus::FehlerGeheimnis) {
            j.daten.status = JobStatus::Fehler; j.daten.code = -1; j.daten.endeMs = jetztMs();
            j.daten.ausgabe.push_back("Geheimnis stimmt nicht");
            continue;
        }
        if (st == XbmCmdStatus::Bereit && !j.gestartet) {
            j.gestartet = true;
            j.daten.status = JobStatus::Laeuft;
            j.daten.startMs = jetztMs();
            const int id = j.daten.id;
            const std::string name = pit->second.name;
            p_->stats.befehle++;
            p_->melde(name, (j.daten.istScript ? "> " : "$ ") + j.daten.anzeige);
            auto onAus = [this, id, name](const std::string& z, bool f) {
                std::string t = z;
                while (!t.empty() && (t.back()=='\n' || t.back()=='\r')) t.pop_back();
                p_->melde(name, t, f);
                for (auto& q : p_->jobs) if (q->daten.id == id) {
                    q->daten.ausgabe.push_back(t);
                    if (q->daten.ausgabe.size() > 200) q->daten.ausgabe.erase(q->daten.ausgabe.begin());
                }
            };
            auto onEnde = [this, id, name](int code) {
                for (auto& q : p_->jobs) if (q->daten.id == id) {
                    q->daten.code = code; q->daten.endeMs = jetztMs();
                    const bool abbruch = (code == 143 || code == 137 || code == 130);
                    q->daten.status = abbruch ? JobStatus::Abgebrochen
                                    : (code == 0 ? JobStatus::Fertig : JobStatus::Fehler);
                    p_->melde(name, abbruch ? "ABGEBROCHEN (" + std::to_string(code) + ")"
                                            : "beendet mit " + std::to_string(code), code != 0);
                }
            };
            if (j.daten.istScript) j.cli->RunScript(j.daten.anzeige, onAus, onEnde);
            else                   j.cli->Run(j.daten.anzeige, onAus, onEnde);
        }
    }

    // --- Scripts je Geraet: ueber die Sync-/Standardverbindung abfragen ---
    // [Nur wenn diese Verbindung gerade frei und bereit ist; alle 30 s
    //  auffrischen. Fuer die Abfrage wird keine eigene Verbindung
    //  aufgemacht -- der Rueckruf kommt ueber dieselbe Leitung.]
    for (auto& kv : p_->peers) {
        auto& sc = p_->scripts[kv.first];
        if (sc.laeuft) continue;
        if (jetztMs() - sc.abgefragtMs < 30000) continue;
        auto& v = p_->verb[kv.first];
        if (!v.cli) v.cli = std::make_unique<XbmCmdClient>();
        auto st = v.cli->GetStatus();
        if (st == XbmCmdStatus::Getrennt || st == XbmCmdStatus::FehlerNetz) {
            if (!v.cli->Connect(kv.second.ip, kv.second.cmdPort, p_->cfg.geheimnis)) { sc.abgefragtMs = jetztMs(); continue; }
            v.cli->Poll(); st = v.cli->GetStatus();
        }
        if (st != XbmCmdStatus::Bereit || v.cli->Busy() || v.cli->SyncBusy()) continue;
        sc.laeuft = true; sc.abgefragtMs = jetztMs();
        const std::string pid = kv.first;
        v.cli->ListeScripts([this, pid](const std::vector<std::string>& namen) {
            auto& c = p_->scripts[pid];
            c.namen = namen; c.laeuft = false; c.abgefragtMs = jetztMs();
        });
    }

    // --- automatischer Abgleich ---
    if (p_->autoSync && !p_->cfg.syncDir.empty() && jetztMs() >= p_->naechsterBlick) {
        p_->naechsterBlick = jetztMs() + p_->cfg.autoSyncMs;
        auto jetzt = ordnerAbdruck(p_->cfg.syncDir);
        if (jetzt != p_->letzterAbdruck) {
            p_->letzterAbdruck = jetzt;
            // [Nur zu den ANGEHAKTEN. Alles an alle zu schicken waere
            //  bequem, aber genau die Art von Ueberraschung, die man bei
            //  Dateien nicht will.]
            int n = SyncSelected(true);
            if (n > 0) p_->melde("hier", "Aenderung erkannt -- abgeglichen mit " +
                                         std::to_string(n) + " Gegenstellen");
        }
    }
}

// Einen Auftrag VORMERKEN. Abgeschickt wird er in Poll(), sobald die
// Verbindung bereit ist.
// [Vorher wurde hier in einer Schleife auf die Anmeldung gewartet --
//  und dabei nur der Client aufgerufen. Die Anmeldung braucht aber
//  beide Seiten: der Server muss die Zufallszahl schicken. In einem
//  Prozess lief die Schleife deshalb ins Leere, und selbst zwischen
//  zwei Rechnern ist ein frisch gefundener Gegenpart beim Knopfdruck
//  meist noch nicht fertig angemeldet.]
bool XbmNetNode::RunOn(const std::string& peerId, const std::string& befehl) {
    if (!p_->peers.count(peerId)) return false;
    auto& v = p_->verb[peerId];
    if (!v.cli) v.cli = std::make_unique<XbmCmdClient>();
    { Impl::Auftrag a; a.befehl = befehl; v.warteschlange.push_back(std::move(a)); }
    return true;
}

int XbmNetNode::RunOnSelected(const std::string& befehl) {
    int n = 0;
    for (auto& kv : p_->peers)
        if (kv.second.ausgewaehlt && RunOn(kv.first, befehl)) n++;
    return n;
}

bool XbmNetNode::BusyOn(const std::string& peerId) const {
    auto it = p_->verb.find(peerId);
    if (it == p_->verb.end()) return false;
    if (!it->second.warteschlange.empty()) return true;
    return it->second.cli && (it->second.cli->Busy() || it->second.cli->SyncBusy());
}

bool XbmNetNode::AbortOn(const std::string& peerId) {
    auto it = p_->verb.find(peerId);
    if (it == p_->verb.end()) return false;
    auto& v = it->second;
    // Noch nicht gestartete Befehle aus der Warteschlange nehmen -- sonst
    // liefe nach dem Abbruch gleich der naechste los.
    std::deque<Impl::Auftrag> rest;
    for (auto& a : v.warteschlange) if (a.istSync) rest.push_back(a);
    v.warteschlange.swap(rest);
    if (v.cli && v.cli->Busy()) {
        p_->melde(peerId, "Abbruch angefordert ...", true);
        return v.cli->Abbrechen();
    }
    return false;
}

int XbmNetNode::AbortSelected() {
    int n = 0;
    for (auto& kv : p_->peers)
        if (kv.second.ausgewaehlt && AbortOn(kv.first)) n++;
    return n;
}

XbmNetNode::BefehlStatus XbmNetNode::StatusOn(const std::string& peerId) const {
    BefehlStatus st;
    auto it = p_->verb.find(peerId);
    if (it == p_->verb.end()) return st;
    const auto& v = it->second;
    st.hatteBefehl = v.hatteBefehl;
    st.letzterCode = v.letzterCode;
    st.befehl      = v.befehl;
    st.laeuft      = v.cli && v.cli->Busy();
    if (st.laeuft && v.startMs > 0)
        st.laufzeitSek = (double)(jetztMs() - v.startMs) / 1000.0;
    return st;
}

bool XbmNetNode::SyncTo(const std::string& peerId)   { return SyncFrom(peerId); }

// NACHRICHT AN EINEN PEER (Rahmen J/j) ueber dessen Verbindung; sie wird bei
// Bedarf aufgebaut. Fuer Schichten oberhalb von netlink -- etwa den
// Scheduler-Abgleich --, die ihr eigenes Paketformat mitbringen.
bool XbmNetNode::NachrichtAn(const std::string& peerId, const std::string& text,
                             std::function<void(const std::string&)> onAntwort) {
    if (!p_->peers.count(peerId) || text.empty()) return false;
    auto& v = p_->verb[peerId];
    if (!v.cli) v.cli = std::make_unique<XbmCmdClient>();
    Impl::Auftrag a; a.nachricht = text; a.onAntwort = std::move(onAntwort);
    v.warteschlange.push_back(std::move(a));
    return true;
}
void XbmNetNode::SetNachrichtenHaken(std::function<std::string(const std::string&, const std::string&)> haken) {
    p_->srv.onNachricht = std::move(haken);
}
bool XbmNetNode::PeerBereit(const std::string& peerId) const {
    auto it = p_->verb.find(peerId);
    return it != p_->verb.end() && it->second.cli && it->second.cli->GetStatus() == XbmCmdStatus::Bereit;
}

bool XbmNetNode::SyncFrom(const std::string& peerId) {
    if (p_->cfg.syncDir.empty()) {
        p_->melde(peerId, "kein Abgleichordner eingestellt", true);
        return false;
    }
    if (!p_->peers.count(peerId)) return false;
    auto& v = p_->verb[peerId];
    if (!v.cli) v.cli = std::make_unique<XbmCmdClient>();
    // Nicht zweimal dasselbe vormerken.
    for (auto& a : v.warteschlange) if (a.istSync) return true;
    { Impl::Auftrag a; a.istSync = true; v.warteschlange.push_back(std::move(a)); }
    return true;
}

int XbmNetNode::SyncSelected(bool hin) {
    (void)hin;   // Ein Durchgang gleicht ohnehin BEIDE Richtungen ab.
    int n = 0;
    for (auto& kv : p_->peers)
        if (kv.second.ausgewaehlt && SyncFrom(kv.first)) n++;
    return n;
}

XbmNetNode::Stats XbmNetNode::GetStats() const {
    Stats s = p_->stats;
    s.peers = p_->peers.size();
    s.verbunden = 0;
    for (auto& kv : p_->verb)
        if (kv.second.cli && kv.second.cli->GetStatus() == XbmCmdStatus::Bereit)
            s.verbunden++;
    return s;
}

// ---------------------------------------------------------------------------
// JOBS / SCRIPTS / FREIGABEN
// ---------------------------------------------------------------------------
const char* XbmNetNode::JobStatusText(JobStatus s) {
    switch (s) {
        case JobStatus::Wartet:      return "wartet";
        case JobStatus::Verbindet:   return "verbindet";
        case JobStatus::Laeuft:      return "laeuft";
        case JobStatus::Fertig:      return "ok";
        case JobStatus::Fehler:      return "Fehler";
        case JobStatus::Abgebrochen: return "abgebrochen";
    }
    return "?";
}

int XbmNetNode::JobStarten(const std::string& peerId, const std::string& was, bool istScript) {
    auto pit = p_->peers.find(peerId);
    if (pit == p_->peers.end() || was.empty()) return 0;
    auto j = std::make_unique<Impl::JobIntern>();
    j->daten.id = p_->naechsteJobId++;
    j->daten.peerId = peerId; j->daten.peerName = pit->second.name;
    j->daten.anzeige = was; j->daten.istScript = istScript;
    j->daten.status = JobStatus::Wartet;
    const int id = j->daten.id;
    p_->jobs.push_back(std::move(j));
    return id;
}

int XbmNetNode::ScriptAufAngehakten(const std::string& scriptName) {
    int n = 0;
    for (auto& kv : p_->peers)
        if (kv.second.ausgewaehlt && JobStarten(kv.first, scriptName, true)) n++;
    return n;
}

std::vector<XbmNetNode::Job> XbmNetNode::Jobs() const {
    std::vector<Job> out;
    for (auto& j : p_->jobs) out.push_back(j->daten);
    return out;
}

bool XbmNetNode::JobAbbrechen(int jobId) {
    for (auto& j : p_->jobs) if (j->daten.id == jobId) {
        if (j->daten.status == JobStatus::Wartet || j->daten.status == JobStatus::Verbindet) {
            j->daten.status = JobStatus::Abgebrochen; j->daten.endeMs = jetztMs();
            if (j->cli) j->cli->Disconnect();
            return true;
        }
        if (j->daten.status == JobStatus::Laeuft && j->cli) return j->cli->Abbrechen();
        return false;
    }
    return false;
}

void XbmNetNode::JobsAufraeumen() {
    for (auto it = p_->jobs.begin(); it != p_->jobs.end();) {
        auto s = (*it)->daten.status;
        if (s == JobStatus::Fertig || s == JobStatus::Fehler || s == JobStatus::Abgebrochen)
            it = p_->jobs.erase(it);
        else ++it;
    }
}

std::vector<std::string> XbmNetNode::ScriptsVon(const std::string& peerId) const {
    auto it = p_->scripts.find(peerId);
    return it == p_->scripts.end() ? std::vector<std::string>{} : it->second.namen;
}
void XbmNetNode::ScriptsAuffrischen(const std::string& peerId) {
    auto& sc = p_->scripts[peerId]; sc.abgefragtMs = 0; sc.laeuft = false;
}

void XbmNetNode::SetBefehleErlauben(bool an)  { p_->srv.befehleErlauben  = an; }
void XbmNetNode::SetScriptsFreigeben(bool an) { p_->srv.scriptsFreigeben = an; }
bool XbmNetNode::BefehleErlauben() const      { return p_->srv.befehleErlauben.load(); }
bool XbmNetNode::ScriptsFreigeben() const     { return p_->srv.scriptsFreigeben.load(); }

std::int64_t XbmNetNode_JetztMs() { return jetztMs(); }
