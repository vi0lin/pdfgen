// ---------------------------------------------------------------------------
// xbm_net_udp.cpp -- siehe xbm_net_udp.h.
// ---------------------------------------------------------------------------
#include "xbm_net_udp.h"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <map>
#include <mutex>
#include <random>

#if defined(_WIN32)
    #ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
    #endif
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #include <iphlpapi.h>
    using socklen_t_ = int;
    #define XBM_CLOSESOCK closesocket
    #define XBM_LASTERR   WSAGetLastError()
    #define XBM_WOULDBLOCK WSAEWOULDBLOCK
#else
    #include <arpa/inet.h>
    #include <errno.h>
    #include <fcntl.h>
    #include <ifaddrs.h>
    #include <net/if.h>
    #include <netinet/in.h>
    #include <sys/socket.h>
    #include <unistd.h>
    using socklen_t_ = socklen_t;
    #define XBM_CLOSESOCK ::close
    #define XBM_LASTERR   errno
    #define XBM_WOULDBLOCK EWOULDBLOCK
#endif

namespace {

std::int64_t NowMs() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

bool g_netUp = false;

// ---------------------------------------------------------------------------
// Paketformat der Entdeckung. Bewusst Text und bewusst winzig -- es geht um
// wenige Bytes je Sekunde, und beim Fehlersuchen kann man mit tcpdump
// unmittelbar lesen, was passiert. Fuer den spaeteren Spielzustand nimmst du
// natuerlich etwas Binaeres; DAFUER ist dieses Modul nur der Transport.
//
//   XBMD<v>|<appId>|<id>|<name>|<appVersion>|<dataPort>|<seq>|<tMs>|<payload>
// ---------------------------------------------------------------------------
constexpr char kMagic[] = "XBMD1";

std::vector<std::string> Split(const std::string& s, char sep, int maxParts) {
    std::vector<std::string> out;
    std::size_t pos = 0;
    while (out.size() + 1 < (std::size_t)maxParts) {
        const std::size_t p = s.find(sep, pos);
        if (p == std::string::npos) break;
        out.push_back(s.substr(pos, p - pos));
        pos = p + 1;
    }
    out.push_back(s.substr(pos));
    return out;
}

std::string MakeId() {
    // Zufaellig statt aus Hostname/MAC: mehrere Instanzen auf EINEM Rechner
    // muessen unterscheidbar bleiben (genau der Fall beim Testen).
    static const char* hex = "0123456789abcdef";
    std::random_device rd;
    std::mt19937 gen(rd() ^ (unsigned)NowMs());
    std::uniform_int_distribution<int> d(0, 15);
    std::string s(16, '0');
    for (char& c : s) c = hex[d(gen)];
    return s;
}

}  // namespace

// ---------------------------------------------------------------------------
bool XbmNet_Init() {
    if (g_netUp) return true;
#if defined(_WIN32)
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) return false;
#endif
    g_netUp = true;
    return true;
}

void XbmNet_Shutdown() {
    if (!g_netUp) return;
#if defined(_WIN32)
    WSACleanup();
#endif
    g_netUp = false;
}

// ---------------------------------------------------------------------------
XbmUdpSocket::XbmUdpSocket() { XbmNet_Init(); }
XbmUdpSocket::~XbmUdpSocket() { Close(); }

bool XbmUdpSocket::Open(std::uint16_t port, bool broadcast, bool reuse) {
    Close();
    XbmNet_Init();
    fd_ = (int)::socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (fd_ < 0) { err_ = "socket() fehlgeschlagen"; return false; }

    if (reuse) {
        int on = 1;
        ::setsockopt(fd_, SOL_SOCKET, SO_REUSEADDR, (const char*)&on, sizeof(on));
#if defined(SO_REUSEPORT) && !defined(_WIN32)
        // Ohne SO_REUSEPORT bekommt bei mehreren Prozessen auf demselben
        // Port nur EINER die Broadcasts -- unter Linux waere die zweite
        // Instanz beim Testen taub.
        ::setsockopt(fd_, SOL_SOCKET, SO_REUSEPORT, (const char*)&on, sizeof(on));
#endif
    }
    if (broadcast) {
        int on = 1;
        if (::setsockopt(fd_, SOL_SOCKET, SO_BROADCAST,
                         (const char*)&on, sizeof(on)) != 0) {
            err_ = "SO_BROADCAST abgelehnt";
        }
    }

    sockaddr_in a{};
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_ANY);
    a.sin_port = htons(port);
    if (::bind(fd_, (sockaddr*)&a, sizeof(a)) != 0) {
        char b[128];
        std::snprintf(b, sizeof(b), "bind(port=%u) fehlgeschlagen, Fehler %d",
                      (unsigned)port, XBM_LASTERR);
        err_ = b;
        Close();
        return false;
    }

    // Tatsaechlichen Port ermitteln (bei port==0 vergibt das System einen).
    sockaddr_in got{};
    socklen_t_ gl = sizeof(got);
    if (::getsockname(fd_, (sockaddr*)&got, &gl) == 0)
        port_ = ntohs(got.sin_port);
    else
        port_ = port;

    // NICHT BLOCKIEREND -- sonst haelt ein Receive() den Renderframe an.
#if defined(_WIN32)
    u_long nb = 1;
    ioctlsocket(fd_, FIONBIO, &nb);
#else
    const int fl = ::fcntl(fd_, F_GETFL, 0);
    ::fcntl(fd_, F_SETFL, fl | O_NONBLOCK);
#endif
    err_.clear();
    return true;
}

void XbmUdpSocket::Close() {
    if (fd_ >= 0) { XBM_CLOSESOCK(fd_); fd_ = -1; }
    port_ = 0;
}

bool XbmUdpSocket::IsOpen() const { return fd_ >= 0; }
std::uint16_t XbmUdpSocket::LocalPort() const { return port_; }
const char* XbmUdpSocket::LastError() const { return err_.c_str(); }

bool XbmUdpSocket::Send(const XbmEndpoint& to, const void* data, std::size_t len) {
    if (fd_ < 0) return false;
    sockaddr_in a{};
    a.sin_family = AF_INET;
    a.sin_port = htons(to.port);
    if (::inet_pton(AF_INET, to.ip.c_str(), &a.sin_addr) != 1) return false;
    const auto n = ::sendto(fd_, (const char*)data, (int)len, 0,
                            (sockaddr*)&a, sizeof(a));
    return n >= 0 && (std::size_t)n == len;
}

bool XbmUdpSocket::SendBroadcast(std::uint16_t port, const void* data,
                                 std::size_t len) {
    if (fd_ < 0) return false;
    // AN JEDE SUBNETZ-BROADCAST UND ZUSAETZLICH AN 255.255.255.255.
    // [Nur die zweite zu benutzen war der Fehler: viele WLAN-Router
    //  leiten sie nicht an ihre Clients weiter. Die gerichteten
    //  Adressen kommen an; die allgemeine bleibt als Rueckfall fuer
    //  Netze ohne Maske (Hotspot, manche VPNs).]
    bool eine = false;
    std::vector<std::string> ziele = XbmNet_BroadcastAddresses();
    ziele.push_back("255.255.255.255");
    for (auto& z : ziele) {
        sockaddr_in a{};
        a.sin_family = AF_INET;
        a.sin_port = htons(port);
        if (inet_pton(AF_INET, z.c_str(), &a.sin_addr) != 1) continue;
        const auto n = ::sendto(fd_, (const char*)data, (int)len, 0,
                                (sockaddr*)&a, sizeof(a));
        if (n >= 0 && (std::size_t)n == len) eine = true;
    }
    return eine;
}

bool XbmUdpSocket::Receive(std::vector<std::uint8_t>& out, XbmEndpoint& from) {
    if (fd_ < 0) return false;
    std::uint8_t buf[2048];
    sockaddr_in a{};
    socklen_t_ al = sizeof(a);
    const auto n = ::recvfrom(fd_, (char*)buf, sizeof(buf), 0, (sockaddr*)&a, &al);
    if (n <= 0) return false;
    char ip[64] = {0};
    ::inet_ntop(AF_INET, &a.sin_addr, ip, sizeof(ip));
    from.ip = ip;
    from.port = ntohs(a.sin_port);
    out.assign(buf, buf + n);
    return true;
}

// ---------------------------------------------------------------------------
std::vector<std::string> XbmNet_LocalAddresses() {
    std::vector<std::string> out;
    XbmNet_Init();
#if defined(_WIN32)
    char host[256];
    if (gethostname(host, sizeof(host)) != 0) return out;
    addrinfo hints{}, *res = nullptr;
    hints.ai_family = AF_INET;
    if (getaddrinfo(host, nullptr, &hints, &res) == 0) {
        for (addrinfo* p = res; p; p = p->ai_next) {
            char ip[64] = {0};
            sockaddr_in* s = (sockaddr_in*)p->ai_addr;
            inet_ntop(AF_INET, &s->sin_addr, ip, sizeof(ip));
            if (std::strncmp(ip, "127.", 4) != 0) out.push_back(ip);
        }
        freeaddrinfo(res);
    }
#else
    ifaddrs* ifs = nullptr;
    if (::getifaddrs(&ifs) != 0) return out;
    for (ifaddrs* p = ifs; p; p = p->ifa_next) {
        if (!p->ifa_addr || p->ifa_addr->sa_family != AF_INET) continue;
        if (!(p->ifa_flags & IFF_UP)) continue;
        if (p->ifa_flags & IFF_LOOPBACK) continue;
        char ip[64] = {0};
        ::inet_ntop(AF_INET, &((sockaddr_in*)p->ifa_addr)->sin_addr, ip, sizeof(ip));
        out.push_back(ip);
    }
    ::freeifaddrs(ifs);
#endif
    std::sort(out.begin(), out.end());
    out.erase(std::unique(out.begin(), out.end()), out.end());
    return out;
}


// ---------------------------------------------------------------------------
// SUBNETZ-BROADCAST-ADRESSEN ALLER SCHNITTSTELLEN
//
// [255.255.255.255 leiten viele WLAN-Router NICHT an ihre Clients weiter;
//  die gerichtete Broadcast des Subnetzes (z.B. 192.168.1.255) kommt
//  dagegen zuverlaessig an. Genau das erklaerte den Befund "Windows
//  findet Android, Android findet Windows nicht": Android sendete, der
//  Router trug es zum Kabel -- Windows sendete an 255.255.255.255, und
//  der Router liess es nicht ins WLAN.]
// ---------------------------------------------------------------------------
std::vector<std::string> XbmNet_BroadcastAddresses() {
    std::vector<std::string> out;
    XbmNet_Init();
#if defined(_WIN32)
    // GetAdaptersAddresses liefert Adresse und Praefixlaenge je Adapter.
    ULONG groesse = 0;
    GetAdaptersAddresses(AF_INET, GAA_FLAG_INCLUDE_PREFIX, nullptr, nullptr, &groesse);
    std::vector<unsigned char> puffer(groesse ? groesse : 1);
    auto* adr = (IP_ADAPTER_ADDRESSES*)puffer.data();
    if (groesse && GetAdaptersAddresses(AF_INET, GAA_FLAG_INCLUDE_PREFIX,
                                        nullptr, adr, &groesse) == NO_ERROR) {
        for (auto* a = adr; a; a = a->Next) {
            if (a->OperStatus != IfOperStatusUp) continue;
            if (a->IfType == IF_TYPE_SOFTWARE_LOOPBACK) continue;
            for (auto* u = a->FirstUnicastAddress; u; u = u->Next) {
                if (u->Address.lpSockaddr->sa_family != AF_INET) continue;
                auto ip = ((sockaddr_in*)u->Address.lpSockaddr)->sin_addr.s_addr;
                unsigned pl = u->OnLinkPrefixLength;
                if (pl == 0 || pl > 31) continue;
                std::uint32_t maske = htonl(pl == 0 ? 0 : (0xFFFFFFFFu << (32 - pl)));
                in_addr b; b.s_addr = ip | ~maske;
                char txt[64] = {0};
                inet_ntop(AF_INET, &b, txt, sizeof(txt));
                out.push_back(txt);
            }
        }
    }
#else
    ifaddrs* ifs = nullptr;
    if (::getifaddrs(&ifs) != 0) return out;
    for (ifaddrs* p = ifs; p; p = p->ifa_next) {
        if (!p->ifa_addr || p->ifa_addr->sa_family != AF_INET) continue;
        if (!(p->ifa_flags & IFF_UP)) continue;
        if (p->ifa_flags & IFF_LOOPBACK) continue;
        // ifa_broadaddr ist bei Broadcast-faehigen Schnittstellen gesetzt;
        // sonst aus Adresse und Maske rechnen.
        in_addr b{};
        if ((p->ifa_flags & IFF_BROADCAST) && p->ifa_broadaddr) {
            b = ((sockaddr_in*)p->ifa_broadaddr)->sin_addr;
        } else if (p->ifa_netmask) {
            b.s_addr = ((sockaddr_in*)p->ifa_addr)->sin_addr.s_addr
                     | ~((sockaddr_in*)p->ifa_netmask)->sin_addr.s_addr;
        } else continue;
        char txt[64] = {0};
        ::inet_ntop(AF_INET, &b, txt, sizeof(txt));
        out.push_back(txt);
    }
    ::freeifaddrs(ifs);
#endif
    std::sort(out.begin(), out.end());
    out.erase(std::unique(out.begin(), out.end()), out.end());
    return out;
}

// ---------------------------------------------------------------------------
struct XbmDiscovery::Impl {
    XbmDiscoveryConfig cfg;
    XbmUdpSocket disc;              // Broadcast-Port (Entdeckung)
    XbmUdpSocket data;              // eigener Port (Nutzdaten)
    std::string id;
    std::string payload;
    std::int64_t lastAnnounce = 0;
    std::uint64_t seq = 0;
    bool running = false;

    mutable std::mutex mtx;
    std::map<std::string, XbmPeer> peers;
    std::map<std::string, std::uint64_t> lastSeq;
    Stats stats;
    std::vector<std::string> localIps;
};

XbmDiscovery::~XbmDiscovery() { Stop(); }

bool XbmDiscovery::Start(const XbmDiscoveryConfig& cfg) {
    Stop();
    p_ = new Impl();
    p_->cfg = cfg;
    p_->id  = MakeId();
    p_->localIps = XbmNet_LocalAddresses();

    if (!p_->data.Open(cfg.dataPort, false, true)) {
        std::fprintf(stderr, "[udp] Datenport: %s\n", p_->data.LastError());
        delete p_; p_ = nullptr;
        return false;
    }
    if (!p_->disc.Open(cfg.port, /*broadcast=*/true, /*reuse=*/true)) {
        std::fprintf(stderr, "[udp] Entdeckungsport: %s\n", p_->disc.LastError());
        delete p_; p_ = nullptr;
        return false;
    }
    p_->running = true;
    std::fprintf(stderr, "[udp] Entdeckung laeuft: id=%s Daten-Port=%u "
                         "Broadcast-Port=%u\n",
                 p_->id.c_str(), (unsigned)p_->data.LocalPort(),
                 (unsigned)p_->disc.LocalPort());
    return true;
}

void XbmDiscovery::Stop() {
    if (!p_) return;
    p_->running = false;
    delete p_;
    p_ = nullptr;
}

bool XbmDiscovery::Running() const { return p_ && p_->running; }

void XbmDiscovery::SetPayload(const std::string& s) {
    if (!p_) return;
    std::lock_guard<std::mutex> lk(p_->mtx);
    p_->payload = s;
}

std::string XbmDiscovery::SelfId() const { return p_ ? p_->id : std::string(); }

XbmEndpoint XbmDiscovery::SelfEndpoint() const {
    XbmEndpoint e;
    if (!p_) return e;
    e.ip = p_->localIps.empty() ? "127.0.0.1" : p_->localIps.front();
    e.port = p_->data.LocalPort();
    return e;
}

void XbmDiscovery::Poll() {
    if (!p_ || !p_->running) return;
    const std::int64_t now = NowMs();

    // ---- ankuendigen ----
    if (now - p_->lastAnnounce >= p_->cfg.announceMs) {
        p_->lastAnnounce = now;
        std::string pl;
        { std::lock_guard<std::mutex> lk(p_->mtx); pl = p_->payload; }
        char head[320];
        std::snprintf(head, sizeof(head), "%s|%s|%s|%s|%u|%u|%llu|%lld|",
                      kMagic, p_->cfg.appId.c_str(), p_->id.c_str(),
                      p_->cfg.name.c_str(), (unsigned)p_->cfg.appVersion,
                      (unsigned)p_->data.LocalPort(),
                      (unsigned long long)(p_->seq++), (long long)now);
        const std::string msg = std::string(head) + pl;
        if (p_->disc.SendBroadcast(p_->cfg.port, msg.data(), msg.size())) {
            std::lock_guard<std::mutex> lk(p_->mtx);
            p_->stats.sent++;
        }
    }

    // ---- empfangen ----
    std::vector<std::uint8_t> buf;
    XbmEndpoint from;
    while (p_->disc.Receive(buf, from)) {
        std::lock_guard<std::mutex> lk(p_->mtx);
        p_->stats.received++;
        const std::string s((const char*)buf.data(), buf.size());
        const auto f = Split(s, '|', 9);
        if (f.size() < 9 || f[0] != kMagic || f[1] != p_->cfg.appId) {
            p_->stats.dropped++;      // fremdes Programm oder Muell
            continue;
        }
        const std::string pid = f[2];
        if (pid == p_->id) continue;  // eigener Broadcast kommt zurueck

        const std::uint64_t seq = std::strtoull(f[6].c_str(), nullptr, 10);
        auto ls = p_->lastSeq.find(pid);
        if (ls != p_->lastSeq.end() && seq <= ls->second) {
            // Aelter als das zuletzt Gesehene: verspaetet oder doppelt.
            // Verwerfen ist bei UDP der Normalfall, kein Fehler.
            p_->stats.outOfOrder++;
            continue;
        }
        p_->lastSeq[pid] = seq;

        const bool isNew = (p_->peers.find(pid) == p_->peers.end());
        XbmPeer& pe = p_->peers[pid];
        pe.id = pid;
        pe.name = f[3];
        pe.appVersion = (std::uint32_t)std::strtoul(f[4].c_str(), nullptr, 10);
        pe.endpoint.ip = from.ip;
        pe.endpoint.port = (std::uint16_t)std::strtoul(f[5].c_str(), nullptr, 10);
        pe.payload = f[8];
        pe.lastSeenMs = now;
        p_->stats.peers = p_->peers.size();
        if (isNew && onJoin) {
            XbmPeer copy = pe;
            // Rueckruf AUSSERHALB des Schlosses waere sauberer; hier ist er
            // kurz und der Aufrufer haelt kein Schloss -- bewusst einfach.
            onJoin(copy);
        }
    }

    // ---- abgelaufene Peers entfernen ----
    {
        std::vector<XbmPeer> gone;
        {
            std::lock_guard<std::mutex> lk(p_->mtx);
            for (auto it = p_->peers.begin(); it != p_->peers.end(); ) {
                if (now - it->second.lastSeenMs > p_->cfg.timeoutMs) {
                    gone.push_back(it->second);
                    p_->lastSeq.erase(it->first);
                    it = p_->peers.erase(it);
                } else {
                    ++it;
                }
            }
            p_->stats.peers = p_->peers.size();
        }
        if (onLeave) for (const auto& g : gone) onLeave(g);
    }
}

std::vector<XbmPeer> XbmDiscovery::Peers() const {
    std::vector<XbmPeer> out;
    if (!p_) return out;
    std::lock_guard<std::mutex> lk(p_->mtx);
    out.reserve(p_->peers.size());
    for (const auto& kv : p_->peers) out.push_back(kv.second);
    return out;
}

bool XbmDiscovery::SendTo(const XbmPeer& peer, const void* d, std::size_t n) {
    if (!p_) return false;
    return p_->data.Send(peer.endpoint, d, n);
}

void XbmDiscovery::SendAll(const void* d, std::size_t n) {
    for (const auto& pe : Peers()) SendTo(pe, d, n);
}

bool XbmDiscovery::ReceiveData(std::vector<std::uint8_t>& out, XbmEndpoint& from) {
    if (!p_) return false;
    return p_->data.Receive(out, from);
}

XbmDiscovery::Stats XbmDiscovery::GetStats() const {
    if (!p_) return Stats{};
    std::lock_guard<std::mutex> lk(p_->mtx);
    return p_->stats;
}
