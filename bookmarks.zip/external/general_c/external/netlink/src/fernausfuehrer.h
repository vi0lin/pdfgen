#pragma once
// ===========================================================================
// netlink/fernausfuehrer.h -- jobflow::Ausfuehrer ueber netlink.
//
// Ein Job wird je nach Ziel ausgefuehrt:
//   Lokal            actionkit auf dieser Maschine (synchron, Ergebnis sofort)
//   Bestimmte        auf dem ersten Host der Liste, zu dem eine Verbindung steht
//   IrgendeinOnline  auf dem bevorzugten Host, sonst irgendeinem verbundenen,
//                    sonst lokal
//   Alle             auf allen gelisteten verbundenen Hosts; fertig, wenn alle
//                    gemeldet haben; Fehler, wenn einer scheitert
// Steht kein passender Host, liefert starten() false -- jobflow laesst den
// Job wartend und bietet ihn beim naechsten Takt erneut an.
//
// Nachricht (Rahmen J): {"typ":"aktion","name":..., "eingaenge":{...}}
// Antwort   (Rahmen j): {"typ":"ergebnis","ok":bool,"ausgaben":{...},"fehler":"..."}
// Serverseite: serverHaken() beantwortet solche Nachrichten aus dem
// actionkit-Katalog dieser Maschine -- und reicht alles andere an einen
// weiteren Haken (z.B. den Scheduler-Abgleich) durch.
//
// Ergebnisse kommen asynchron (Client-Poll). abholen() reicht sie an die
// Queue weiter -- im selben Takt, in dem der Aufrufer auch schritt() ruft.
// ===========================================================================
#include "xbm_cmdchan.h"
#include "jobflow.h"
#include "actionkit.h"
#include <map>
#include <memory>

namespace netlink {
using jobflow::json;

// ---- Serverseite: eingehende Aktionen ausfuehren ----------------------------
inline std::string serverHaken(const std::string& text, const std::string& von,
                               std::function<std::string(const std::string&, const std::string&)> sonst = nullptr) {
    json ein = json::parse(text, nullptr, false);
    if (!ein.is_object() || ein.value("typ", "") != "aktion") return sonst ? sonst(text, von) : std::string();
    json aus; aus["typ"] = "ergebnis";
    const actionkit::Aktion* a = actionkit::Aktionen::finde(ein.value("name", ""));
    if (!a) { aus["ok"] = false; aus["fehler"] = "Aktion '" + ein.value("name", "") + "' gibt es auf diesem Host nicht"; return aus.dump(); }
    actionkit::Ergebnis e = a->aufrufen(ein.value("eingaenge", json::object()));
    aus["ok"] = e.ok; aus["ausgaben"] = e.ausgaben; aus["fehler"] = e.fehler;
    return aus.dump();
}

// ---- Clientseite: der Ausfuehrer ------------------------------------------------
struct Fernausfuehrer {
    // verbundene Hosts nach Name (Client muss Bereit sein)
    std::map<std::string, XbmCmdClient*> hosts;
    std::string lokalerName = "lokal";

    struct Offen { jobflow::Id job; int erwartet = 0; int erhalten = 0; bool ok = true; json ausgaben = json::object(); std::string fehler; };
    std::vector<Offen> offen;          // laufende Fernjobs
    struct Fertig { jobflow::Id job; bool ok; json ausgaben; std::string fehler; };
    std::vector<Fertig> fertig;        // eingetroffene Ergebnisse (auch lokale)

    jobflow::Ausfuehrer ausfuehrer;
    Fernausfuehrer() {
        ausfuehrer.starten = [this](jobflow::Job& j, const json& ein, std::string& laeuftAuf) { return starten(j, ein, laeuftAuf); };
        ausfuehrer.abbrechen = [](jobflow::Job&) {};    // Fernabbruch: 'K'-Rahmen, spaeter
    }

    bool bereit(const std::string& h) const { auto it = hosts.find(h); return it != hosts.end() && it->second && it->second->GetStatus() == XbmCmdStatus::Bereit; }

    std::vector<std::string> zieleFuer(const jobflow::Job& j) const {
        using jobflow::Zielwahl;
        std::vector<std::string> z;
        switch (j.ziel.wahl) {
            case Zielwahl::Lokal: z.push_back(lokalerName); break;
            case Zielwahl::Bestimmte: for (auto& h : j.ziel.hosts) if (h == lokalerName || bereit(h)) { z.push_back(h); break; } break;
            case Zielwahl::IrgendeinOnline:
                if (!j.ziel.bevorzugt.empty() && (j.ziel.bevorzugt == lokalerName || bereit(j.ziel.bevorzugt))) z.push_back(j.ziel.bevorzugt);
                else { for (auto& kv : hosts) if (bereit(kv.first)) { z.push_back(kv.first); break; } if (z.empty()) z.push_back(lokalerName); }
                break;
            case Zielwahl::Alle: for (auto& h : j.ziel.hosts) if (h == lokalerName || bereit(h)) z.push_back(h); break;
        }
        return z;
    }

    bool starten(jobflow::Job& j, const json& ein, std::string& laeuftAuf) {
        std::vector<std::string> ziele = zieleFuer(j);
        if (ziele.empty()) return false;                                  // kein Host: spaeter wieder
        laeuftAuf.clear(); for (auto& z : ziele) laeuftAuf += (laeuftAuf.empty() ? "" : ",") + z;
        Offen o; o.job = j.id; o.erwartet = (int)ziele.size();
        for (const std::string& z : ziele) {
            if (z == lokalerName) {
                const actionkit::Aktion* a = actionkit::Aktionen::finde(j.aktion);
                actionkit::Ergebnis e; if (a) e = a->aufrufen(ein); else e.fehler = "Aktion '" + j.aktion + "' unbekannt";
                eintragen(o, e.ok, e.ausgaben, e.fehler);
            } else {
                json n; n["typ"] = "aktion"; n["name"] = j.aktion; n["eingaenge"] = ein;
                jobflow::Id jid = j.id;
                if (!hosts[z]->Nachricht(n.dump(), [this, jid](const std::string& antwort) {
                        json r = json::parse(antwort, nullptr, false);
                        for (Offen& x : offen) if (x.job == jid) { eintragen(x, r.value("ok", false), r.value("ausgaben", json::object()), r.value("fehler", "keine Antwort")); return; }
                    })) eintragen(o, false, json::object(), "Senden an '" + z + "' fehlgeschlagen");
            }
        }
        if (o.erhalten >= o.erwartet) fertig.push_back({ o.job, o.ok, o.ausgaben, o.fehler });   // alles lokal/sofort
        else offen.push_back(o);
        return true;
    }
    void eintragen(Offen& o, bool ok, const json& aus, const std::string& fehler) {
        ++o.erhalten; if (!ok) { o.ok = false; if (!o.fehler.empty()) o.fehler += "; "; o.fehler += fehler; }
        if (aus.is_object()) for (auto it = aus.begin(); it != aus.end(); ++it) o.ausgaben[it.key()] = it.value();   // bei "Alle": letzter gewinnt je Ausgang
        if (o.erhalten >= o.erwartet) { fertig.push_back({ o.job, o.ok, o.ausgaben, o.fehler }); }
    }
    // Ergebnisse an die Queue weiterreichen (nach dem Poll der Clients).
    int abholen(jobflow::Queue& q, jobflow::Zeit jetzt) {
        int n = 0;
        for (const Fertig& f : fertig) { q.fertig(f.job, f.ok, f.ausgaben, f.fehler, jetzt); ++n; }
        fertig.clear();
        offen.erase(std::remove_if(offen.begin(), offen.end(), [](const Offen& o) { return o.erhalten >= o.erwartet; }), offen.end());
        return n;
    }
};

} // namespace netlink
