#include "xbm_netnode.h"
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <thread>
namespace fs = std::filesystem;

static void schreib(const std::string& p, const std::string& t) {
    fs::create_directories(fs::path(p).parent_path());
    std::ofstream f(p, std::ios::binary); f << t;
}
static void pump(XbmNetNode& a, XbmNetNode& b, int ms) {
    auto bis = std::chrono::steady_clock::now() + std::chrono::milliseconds(ms);
    while (std::chrono::steady_clock::now() < bis) {
        a.Poll(); b.Poll();
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
}

int main() {
    int fehler = 0;
    fs::remove_all("/tmp/nA"); fs::remove_all("/tmp/nB");
    schreib("/tmp/nA/notiz.txt", "von A\n");
    schreib("/tmp/nA/scripts/hallo.sh", "echo hallo\n");
    schreib("/tmp/nB/andere.txt", "von B\n");

    XbmNetConfig ca; ca.name="LaptopA"; ca.geheimnis="g1";
    ca.syncDir="/tmp/nA"; ca.cmdPort=0; ca.discPort=47399;
    XbmNetConfig cb; cb.name="HandyB";  cb.geheimnis="g1";
    cb.syncDir="/tmp/nB"; cb.cmdPort=0; cb.discPort=47399;

    XbmNetNode A, B;
    if (!A.Start(ca)) { std::printf("A: %s\n", A.LastError()); return 1; }
    if (!B.Start(cb)) { std::printf("B: %s\n", B.LastError()); return 1; }
    std::printf("  beide gestartet\n");

    // 1. Finden sie sich?
    pump(A, B, 3000);
    auto pa = A.Peers(); auto pb = B.Peers();
    std::printf("  A sieht %zu, B sieht %zu\n", pa.size(), pb.size());
    if (pa.empty() || pb.empty()) {
        std::printf("  ### keine Entdeckung -- Broadcast blockiert? ###\n");
        return 1;
    }
    for (auto& p : pa) std::printf("    A -> %s (%s:%u)\n",
                                   p.name.c_str(), p.ip.c_str(), (unsigned)p.cmdPort);

    // 2. Befehl auf B ausfuehren, von A aus
    A.SetAusgewaehlt(pa[0].id, true);
    A.RunOn(pa[0].id, "echo BEFEHL-LIEF; pwd");
    pump(A, B, 1500);
    bool lief = false;
    for (auto& z : A.Protokoll()) if (z.text.find("BEFEHL-LIEF") != std::string::npos) lief = true;
    std::printf("  Befehl auf B ausgefuehrt: %s\n", lief ? "ja" : "### NEIN ###");
    if (!lief) fehler++;

    // 3. Dateiabgleich
    A.SyncFrom(pa[0].id);
    pump(A, B, 2500);
    struct { const char* p; const char* w; } pruef[] = {
        {"/tmp/nA/andere.txt",       "B -> A"},
        {"/tmp/nB/notiz.txt",        "A -> B"},
        {"/tmp/nB/scripts/hallo.sh", "A -> B (Unterordner)"},
    };
    for (auto& x : pruef) {
        bool da = fs::exists(x.p);
        std::printf("  %-28s %-22s %s\n", x.p, x.w, da ? "da" : "### FEHLT ###");
        if (!da) fehler++;
    }

    // 4. Automatischer Abgleich
    A.SetAutoSync(true);
    pump(A, B, 500);
    schreib("/tmp/nA/spaeter.txt", "erst jetzt angelegt\n");
    pump(A, B, 6000);
    bool spaet = fs::exists("/tmp/nB/spaeter.txt");
    std::printf("  neue Datei automatisch verteilt: %s\n", spaet ? "ja" : "### NEIN ###");
    if (!spaet) fehler++;

    auto s = A.GetStats();
    std::printf("  A: %zu Peers, %zu verbunden, %llu Befehle, %llu Abgleiche\n",
                s.peers, s.verbunden, (unsigned long long)s.befehle,
                (unsigned long long)s.syncLaeufe);
    std::printf(fehler ? "  ### %d FEHLER ###\n" : "  alles bestanden\n", fehler);
    return fehler ? 1 : 0;
}
