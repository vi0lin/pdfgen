#pragma once
// ---------------------------------------------------------------------------
// xbm_net_udp.h -- UDP fuer Synchronisation zwischen Clients im selben Netz.
//
// Zwei Dinge, sauber getrennt:
//
//   1. ENTDECKUNG (XbmDiscovery): jeder Client ruft periodisch per Broadcast
//      "hier bin ich" und fuehrt eine Liste der anderen. Damit erscheinen
//      Mitspieler im selben WLAN von selbst -- ohne Server, ohne dass jemand
//      eine IP eintippt.
//
//   2. TRANSPORT (XbmUdpSocket): rohe Datagramme an einen bekannten Peer.
//      Darauf setzt spaeter der Spielzustand auf.
//
// WARUM UDP UND NICHT TCP -- und was das kostet:
// UDP liefert Datagramme unzuverlaessig, unsortiert und moeglicherweise
// doppelt. Fuer Spielzustand ist genau das richtig: ein veralteter
// Positionswert ist wertlos, TCP wuerde ihn aber erneut senden und dabei
// alles Nachfolgende aufhalten (Head-of-Line-Blocking). Man bezahlt es
// damit, dass Reihenfolge und Vollstaendigkeit SELBST hergestellt werden
// muessen, wo sie gebraucht werden. Deshalb traegt jedes Paket hier eine
// laufende Nummer und einen Zeitstempel: verspaetete Pakete lassen sich
// verwerfen und Verluste zaehlen (XbmUdpStats).
//
// WAS DIESES MODUL BEWUSST NICHT TUT: keine Verschluesselung, keine
// Authentifizierung, keine erneute Zustellung, keine Fragmentierung. Wer
// Pakete groesser als die MTU schickt, verliert sie -- 1200 Byte Nutzlast
// sind die verlaessliche Obergrenze im Internet, im LAN geht mehr.
// ---------------------------------------------------------------------------
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

// --- Adresse ---------------------------------------------------------------
struct XbmEndpoint {
    std::string ip;                 // "192.168.1.42"
    std::uint16_t port = 0;
    bool operator==(const XbmEndpoint& o) const {
        return port == o.port && ip == o.ip;
    }
    std::string str() const { return ip + ":" + std::to_string(port); }
};

// --- Rohe Steckdose --------------------------------------------------------
class XbmUdpSocket {
public:
    XbmUdpSocket();
    ~XbmUdpSocket();
    XbmUdpSocket(const XbmUdpSocket&) = delete;
    XbmUdpSocket& operator=(const XbmUdpSocket&) = delete;

    // port 0 = beliebiger freier Port (dann sagt LocalPort(), welcher).
    // broadcast = SO_BROADCAST setzen (fuer die Entdeckung noetig).
    // reuse     = SO_REUSEADDR, damit mehrere Instanzen auf einem Rechner
    //             denselben Entdeckungsport belegen duerfen.
    bool Open(std::uint16_t port, bool broadcast = false, bool reuse = true);
    void Close();
    bool IsOpen() const;
    std::uint16_t LocalPort() const;

    bool Send(const XbmEndpoint& to, const void* data, std::size_t len);
    bool SendBroadcast(std::uint16_t port, const void* data, std::size_t len);
    // Nicht blockierend: liefert false, wenn gerade nichts anliegt.
    bool Receive(std::vector<std::uint8_t>& out, XbmEndpoint& from);

    const char* LastError() const;

private:
    int fd_ = -1;
    std::uint16_t port_ = 0;
    std::string err_;
};

// --- Entdeckung ------------------------------------------------------------
struct XbmPeer {
    std::string   id;               // stabile Kennung des Clients
    std::string   name;             // Anzeigename
    XbmEndpoint   endpoint;         // wohin man ihm schreibt
    std::int64_t  lastSeenMs = 0;   // monoton, fuer die Verfallszeit
    std::uint32_t appVersion = 0;
    std::string   payload;          // frei: Spielstand, Rolle, was du willst
    bool self = false;
};

struct XbmDiscoveryConfig {
    std::uint16_t port        = 47317;  // Entdeckungsport (Broadcast)
    std::uint16_t dataPort    = 0;      // 0 = automatisch waehlen
    std::string   appId       = "xbm";  // Fremde Programme aussperren
    std::string   name        = "Client";
    std::uint32_t appVersion  = 1;
    int  announceMs           = 1000;   // wie oft "hier bin ich"
    int  timeoutMs            = 4000;   // ab wann gilt ein Peer als weg
};

class XbmDiscovery {
public:
    bool Start(const XbmDiscoveryConfig& cfg);
    void Stop();
    bool Running() const;

    // Einmal pro Frame aufrufen: sendet faellige Ankuendigungen, liest
    // eingegangene und raeumt abgelaufene Peers weg. Kostet nichts, wenn
    // nichts anliegt.
    void Poll();

    // Was andere ueber uns erfahren sollen (wird mitgesendet).
    void SetPayload(const std::string& s);

    std::vector<XbmPeer> Peers() const;     // ohne uns selbst
    std::string SelfId() const;
    XbmEndpoint SelfEndpoint() const;

    // Rueckrufe (im Poll-Thread, also im UI-Thread, wenn du dort pollst).
    std::function<void(const XbmPeer&)> onJoin;
    std::function<void(const XbmPeer&)> onLeave;

    // Nutzdaten an einen Peer bzw. an alle bekannten.
    bool SendTo(const XbmPeer& p, const void* data, std::size_t len);
    void SendAll(const void* data, std::size_t len);
    // Eingegangene Nutzdaten abholen (nicht die Entdeckungspakete).
    bool ReceiveData(std::vector<std::uint8_t>& out, XbmEndpoint& from);

    struct Stats {
        std::uint64_t sent = 0, received = 0;
        std::uint64_t dropped = 0;      // verworfen: fremde App / kaputt
        std::uint64_t outOfOrder = 0;   // verspaetet eingetroffen
        std::size_t   peers = 0;
    };
    Stats GetStats() const;

private:
    struct Impl;
    Impl* p_ = nullptr;
public:
    ~XbmDiscovery();
};

// Eigene IPv4-Adressen dieses Rechners (ohne Loopback). Nuetzlich fuer die
// Anzeige und um eigene Broadcasts zu erkennen.
std::vector<std::string> XbmNet_LocalAddresses();
// Subnetz-Broadcast-Adressen aller aktiven Schnittstellen (z.B.
// 192.168.1.255). [255.255.255.255 leiten viele WLAN-Router nicht an ihre
// Clients weiter -- diese hier kommen an.]
std::vector<std::string> XbmNet_BroadcastAddresses();
// Einmalig beim Programmstart (Windows: WSAStartup). Mehrfach harmlos.
bool XbmNet_Init();
void XbmNet_Shutdown();
