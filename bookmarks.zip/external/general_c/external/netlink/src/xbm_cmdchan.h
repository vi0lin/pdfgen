#pragma once
// ---------------------------------------------------------------------------
// xbm_cmdchan.h -- Befehlskanal ueber eine STEHENDE TCP-Verbindung.
//
// WOZU
// Ein  build.sh @windows --exec "..."  kostet heute rund eine Sekunde
// allein fuer den Verbindungsaufbau (ssh-Handschlag, Passwort oder
// Schluessel, Shell-Start). Ueber eine bereits offene Verbindung sind es
// Millisekunden. Genau das macht dieses Modul: ein Client haelt die
// Verbindung, schickt Befehle hinueber und bekommt die Ausgabe
// zeilenweise zurueck -- waehrend der Befehl noch laeuft.
//
// WARUM TCP UND NICHT UDP
// Fuer Beruehrungsdaten ist UDP richtig (xbm_net_udp.h begruendet das).
// Fuer Befehle ist es falsch: eine verlorene Zeile Ausgabe ist nicht
// egal, und die Reihenfolge auch nicht. TCP liefert beides. Die
// Entdeckung bleibt bei UDP -- man braucht sie nur, um die Adresse zu
// finden; danach uebernimmt TCP.
//
// SICHERHEIT -- BITTE LESEN
// Dieses Modul fuehrt Befehle aus, die ueber das Netz kommen. Ein
// offener Port ohne Schutz ist eine Fernsteuerung fuer jeden im selben
// WLAN. Deshalb:
//   * Ein GEHEIMNIS ist Pflicht (Start schlaegt ohne fehl). Es wird
//     nicht im Klartext uebertragen, sondern als Antwort auf eine
//     Zufallszahl des Servers (Challenge-Response) -- so nuetzt einem
//     Mithoerer die Aufzeichnung nichts.
//   * Standardmaessig wird nur an private Adressbereiche geantwortet
//     (10.*, 172.16-31.*, 192.168.*, 127.*). Wer das aendert, sollte
//     wissen warum.
//   * Es gibt KEINE Verschluesselung. Der Inhalt der Befehle und ihre
//     Ausgabe sind im LAN mitlesbar. Fuer ein Heimnetz ist das eine
//     vertretbare Entscheidung -- ueber das Internet waere es keine.
//
// BENUTZUNG
//   Auf der Maschine, die Befehle ausfuehren soll:
//       XbmCmdServer srv;
//       srv.Start(47318, "mein-geheimnis");
//       ... jeden Frame:  srv.Poll();
//
//   Auf der Maschine, die sie absetzt:
//       XbmCmdClient cli;
//       cli.Connect("192.168.1.42", 47318, "mein-geheimnis");
//       cli.Run("cd /home/user/bookmarks && ./build.sh deb@local",
//               [](const std::string& zeile, bool fehlerkanal) { ... },
//               [](int code) { ... });
//       ... jeden Frame:  cli.Poll();
// ---------------------------------------------------------------------------
#include <atomic>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

// Ergebnis eines Verbindungsversuchs -- getrennt, damit die Oberflaeche
// dem Benutzer sagen kann, WAS schiefging.
enum class XbmCmdStatus {
    Getrennt,
    Verbinde,
    Bereit,
    FehlerNetz,        // Gegenstelle nicht erreichbar
    FehlerGeheimnis    // Gegenstelle erreichbar, Geheimnis stimmt nicht
};

const char* XbmCmdStatusText(XbmCmdStatus s);

// --- Dateiabgleich ---------------------------------------------------------
// [Ueber DIESELBE Verbindung wie die Befehle. Eine zweite waere ein
//  zweiter Handschlag, ein zweites Geheimnis und ein zweiter Zustand,
//  der schieflaufen kann -- ohne jeden Gewinn.]
struct XbmSyncEintrag {
    std::string  pfad;              // relativ zum Abgleichordner
    std::uint64_t groesse = 0;
    std::int64_t  mtime   = 0;      // Sekunden seit 1970
};

struct XbmSyncErgebnis {
    int geholt = 0;                 // von der Gegenseite bezogen
    int geschickt = 0;              // zur Gegenseite gebracht
    int gleich = 0;                 // beidseitig identisch
    int konflikte = 0;              // beide geaendert -- Kopie angelegt
    std::vector<std::string> meldungen;
};

// --- Server: fuehrt Befehle aus --------------------------------------------
class XbmCmdServer {
public:
    XbmCmdServer();
    ~XbmCmdServer();
    XbmCmdServer(const XbmCmdServer&) = delete;
    XbmCmdServer& operator=(const XbmCmdServer&) = delete;

    // geheimnis darf nicht leer sein -- sonst schlaegt Start fehl.
    bool Start(std::uint16_t port, const std::string& geheimnis);
    void Stop();
    bool Running() const;
    std::uint16_t Port() const;

    // Einmal je Frame. Nimmt Verbindungen an, liest Befehle, schickt
    // Ausgabe zurueck. Blockiert nie.
    void Poll();

    // Wenn gesetzt, entscheidet dieser Rueckruf, ob ein Befehl laufen
    // darf. [Damit kann die Oberflaeche nachfragen, statt blind alles
    //  auszufuehren -- oder eine eigene Liste erlaubter Befehle fuehren.]
    std::function<bool(const std::string& befehl, const std::string& von)> darfLaufen;
    // NACHRICHTENHAKEN: Antwort auf einen 'J'-Rahmen (JSON-Text) der
    // angemeldeten Gegenseite (<von> = Adresse; den Geraetenamen tragen
    // Pakete selbst, z.B. das Feld "von" des Scheduler-Abgleichs). Schichten oberhalb von netlink
    // (Scheduler-Abgleich) haengen sich hier ein.
    std::function<std::string(const std::string& text, const std::string& von)> onNachricht;

    // Ordner, der abgeglichen werden darf. Leer = Abgleich abgeschaltet.
    // [Bewusst EIN Ordner und nicht das Heimatverzeichnis: was hier
    //  steht, kann die Gegenseite lesen UND ueberschreiben. Der Schaden
    //  bei einem Fehler bleibt damit begrenzt und ueberschaubar.]
    void SetSyncDir(const std::string& absoluterPfad);

    // SCRIPTS: Ordner mit .cmd-Dateien (je eine Befehlszeile), die andere
    // Geraete AUFLISTEN und HIER ausfuehren lassen duerfen. Der Inhalt
    // verlaesst dieses Geraet nie -- die Gegenseite sieht nur Namen.
    void SetScriptsDir(const std::string& absoluterPfad);
    // ZWEI FREIGABEN, getrennt schaltbar:
    //   befehleErlauben  -- beliebige Befehle von aussen ('R')
    //   scriptsFreigeben -- Scripts auflisten/ausfuehren ('L'/'S')
    // Beide aus = dieses Geraet fuehrt gar nichts fuer andere aus (der
    // Abgleich bleibt davon unberuehrt).
    std::atomic<bool> befehleErlauben{true};
    std::atomic<bool> scriptsFreigeben{true};

    // Nur zur Anzeige.
    std::function<void(const std::string& zeile)> onLog;

    struct Stats {
        std::uint64_t verbindungen = 0;
        std::uint64_t befehle      = 0;
        std::uint64_t abgewiesen   = 0;   // falsches Geheimnis
        std::size_t   offen        = 0;
    };
    Stats GetStats() const;

    const char* LastError() const;

private:
    struct Impl;
    Impl* p_ = nullptr;
};

// --- Client: setzt Befehle ab ----------------------------------------------
class XbmCmdClient {
public:
    XbmCmdClient();
    ~XbmCmdClient();
    XbmCmdClient(const XbmCmdClient&) = delete;
    XbmCmdClient& operator=(const XbmCmdClient&) = delete;

    // Baut die Verbindung auf und haelt sie. Nicht blockierend: der
    // Zustand ist ueber GetStatus() abfragbar.
    bool Connect(const std::string& ip, std::uint16_t port,
                 const std::string& geheimnis);
    void Disconnect();
    // Heisst GetStatus, nicht Status.
    // [X11/Xlib.h definiert  #define Status int . Wo X11 hereinkommt
    //  (Linux-Desktop ueber GLFW), wird "Status()" zu "int()" -- und der
    //  Compiler meldet "expected unqualified-id". Auf Windows und Android
    //  faellt das nie auf. Deshalb ein Name, den kein Systemheader
    //  besetzt.]
    XbmCmdStatus GetStatus() const;

    // Einmal je Frame.
    void Poll();

    // Befehl absetzen. onAusgabe wird je Zeile gerufen, WAEHREND der
    // Befehl laeuft; onEnde einmal mit dem Rueckgabewert.
    // Liefert false, wenn gerade keine Verbindung steht.
    bool Run(const std::string& befehl,
             std::function<void(const std::string& zeile, bool fehlerkanal)> onAusgabe,
             std::function<void(int code)> onEnde);

    bool Busy() const;              // laeuft gerade ein Befehl?
    // Scripts der Gegenseite auflisten (Namen ohne Inhalt). Antwort kommt
    // ueber den Rueckruf; leer, wenn die Gegenseite nichts freigibt.
    bool ListeScripts(std::function<void(const std::vector<std::string>&)> onListe);
    // Nachricht (JSON-Text) an den Server; onAntwort bekommt den 'j'-Rahmen.
    bool Nachricht(const std::string& text, std::function<void(const std::string& antwort)> onAntwort);
    // Ein Script DER GEGENSEITE dort ausfuehren -- nach Name, wie Run().
    bool RunScript(const std::string& name,
                   std::function<void(const std::string& zeile, bool fehlerkanal)> onAusgabe,
                   std::function<void(int code)> onEnde);
    // Laufenden Befehl auf der Gegenseite beenden. [SIGTERM an die ganze
    //  Prozessgruppe; nach 5 s SIGKILL, falls er sich straeubt. Windows:
    //  TerminateProcess. Die Ausgabe laeuft bis zum Ende weiter, dann
    //  meldet onEnde den Rueckgabewert -- 128+Signal, also 143 (TERM)
    //  oder 137 (KILL); auf Windows 130. So ist im Protokoll erkennbar,
    //  dass es ein Abbruch war und kein regulaeres Ende.]
    bool Abbrechen();

    // Gleicht <lokalerOrdner> mit dem Abgleichordner der Gegenseite ab.
    // Beide Richtungen: Fehlendes wird geholt, Neueres geschickt.
    // Das Ergebnis kommt ueber onFertig, wenn alles durch ist.
    bool StartSync(const std::string& lokalerOrdner,
                   std::function<void(const XbmSyncErgebnis&)> onFertig);
    bool SyncBusy() const;
    const char* LastError() const;

private:
    struct Impl;
    Impl* p_ = nullptr;
};
