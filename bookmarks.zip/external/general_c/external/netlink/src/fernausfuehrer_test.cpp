// Jobs lokal und auf einem "anderen Host" (echter TCP-Server im selben
// Prozess) -- Ziele Lokal, Bestimmte, IrgendeinOnline, Alle; Ausgaben
// wandern zwischen den Hosts.
#include "fernausfuehrer.h"
#include <chrono>
#include <cstdio>
#include <thread>
using namespace jobflow;
static int fehler = 0;
#define PRUEF(bed, text) do { bool ok = (bed); printf("  %s %s\n", ok ? "OK " : "FEHLER", text); if (!ok) fehler++; } while (0)

AKTION(Add, "", EIN(int, a), EIN(int, b), AUS(int, summe)) { HOLE(int, a); HOLE(int, b); SETZE(summe, a + b); return true; }
AKTION(Hostname, "", AUS(std::string, host)) { SETZE(host, std::string("buildserver")); return true; }   // "laeuft nur dort"
AKTION(Kaputt, "", EIN(int, x), AUS(int, y)) { HOLE(int, x); (void)x; fehler = "kaputt auf " + std::string("buildserver"); return false; }

int main() {
    XbmCmdServer srv; srv.onNachricht = [](const std::string& t, const std::string& von) { return netlink::serverHaken(t, von); };
    PRUEF(srv.Start(0, "geheim"), "Server (steht fuer 'buildserver') gestartet");
    XbmCmdClient cl; PRUEF(cl.Connect("127.0.0.1", srv.Port(), "geheim"), "verbunden");
    auto pump = [&](int ms) { for (int i = 0; i < ms / 5; ++i) { srv.Poll(); cl.Poll(); std::this_thread::sleep_for(std::chrono::milliseconds(5)); } };
    pump(300); PRUEF(cl.GetStatus() == XbmCmdStatus::Bereit, "angemeldet");

    netlink::Fernausfuehrer fa; fa.lokalerName = "laptop"; fa.hosts["buildserver"] = &cl;
    Queue q; q.ausfuehrer = &fa.ausfuehrer;
    Job& lok = q.anlegen("lokal 1+2", "Add"); lok.eingaenge = { {"a",1,0,""}, {"b",2,0,""} };
    Job& fern = q.anlegen("fern +10", "Add"); fern.eingaenge = { {"a", json(), lok.id, "summe"}, {"b",10,0,""} }; fern.ziel.wahl = Zielwahl::Bestimmte; fern.ziel.hosts = {"buildserver"};
    Job& irgendwo = q.anlegen("irgendwo", "Hostname"); irgendwo.ziel.wahl = Zielwahl::IrgendeinOnline; irgendwo.ziel.bevorzugt = "buildserver"; irgendwo.ablauf = Ablauf::Parallel;
    Job& alle = q.anlegen("alle", "Add"); alle.eingaenge = { {"a",5,0,""}, {"b",5,0,""} }; alle.ziel.wahl = Zielwahl::Alle; alle.ziel.hosts = {"laptop","buildserver"}; alle.ablauf = Ablauf::Parallel;
    Job& weg = q.anlegen("nicht da", "Add"); weg.eingaenge = { {"a",1,0,""}, {"b",1,0,""} }; weg.ziel.wahl = Zielwahl::Bestimmte; weg.ziel.hosts = {"windows"}; weg.ablauf = Ablauf::Parallel;
    Job& kaputt = q.anlegen("kaputt fern", "Kaputt"); kaputt.eingaenge = { {"x",1,0,""} }; kaputt.ziel.wahl = Zielwahl::Bestimmte; kaputt.ziel.hosts = {"buildserver"}; kaputt.ablauf = Ablauf::Parallel;
    q.starten(0);
    for (int t = 1; t < 12; ++t) { q.schritt(t); pump(60); fa.abholen(q, t); }
    PRUEF(q.finde(lok.id)->status == Status::Fertig && q.finde(lok.id)->laeuftAuf == "laptop", "lokaler Job lief auf dem Laptop");
    PRUEF(q.finde(fern.id)->status == Status::Fertig && q.finde(fern.id)->laeuftAuf == "buildserver" && q.finde(fern.id)->ausgaben["summe"] == 13,
          "Job auf 'buildserver' bekam die lokale Ausgabe als Eingabe: 3+10 = 13 ueber TCP");
    PRUEF(q.finde(irgendwo.id)->status == Status::Fertig && q.finde(irgendwo.id)->ausgaben["host"] == "buildserver", "IrgendeinOnline mit Bevorzugung -> buildserver");
    PRUEF(q.finde(alle.id)->status == Status::Fertig && q.finde(alle.id)->laeuftAuf == "laptop,buildserver", "Alle: lief auf beiden, fertig als beide gemeldet hatten");
    PRUEF(q.finde(weg.id)->status == Status::Wartet, "Ziel 'windows' nicht verbunden: Job bleibt wartend (kein Fehler, spaeter wieder)");
    PRUEF(q.finde(kaputt.id)->status == Status::Fehler && q.finde(kaputt.id)->fehler.find("kaputt auf buildserver") != std::string::npos, "Fehler vom fernen Host kommt mit Text an");
    Queue q2; q2.ausfuehrer = &fa.ausfuehrer; Job& u = q2.anlegen("unbekannt", "Gibtsnicht"); u.ziel.wahl = Zielwahl::Bestimmte; u.ziel.hosts = {"buildserver"};
    q2.starten(0); for (int t = 1; t < 5; ++t) { q2.schritt(t); pump(60); fa.abholen(q2, t); }
    PRUEF(q2.finde(u.id)->status == Status::Fehler && q2.finde(u.id)->fehler.find("gibt es auf diesem Host nicht") != std::string::npos, "unbekannte Aktion auf dem fernen Host -> klarer Fehler");
    cl.Disconnect(); srv.Stop();
    printf("\n%s\n", fehler ? "### FEHLER ###" : "ALLE PRUEFUNGEN BESTANDEN");
    return fehler;
}
