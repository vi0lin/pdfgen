#include "xbm_cmdchan.h"
#include <chrono>
#include <cstdio>
#include <string>
#include <thread>

static void pump(XbmCmdServer& s, XbmCmdClient& c, int ms) {
    auto bis = std::chrono::steady_clock::now() + std::chrono::milliseconds(ms);
    while (std::chrono::steady_clock::now() < bis) {
        s.Poll(); c.Poll();
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
}

int main() {
    int fehler = 0;
    XbmCmdServer srv;
    srv.onLog = [](const std::string& z){ std::printf("  [server] %s\n", z.c_str()); };

    // 1. Ohne Geheimnis darf er nicht starten
    if (srv.Start(0, "")) { std::printf("  ### startet ohne Geheimnis ###\n"); fehler++; }
    else std::printf("  ohne Geheimnis: abgelehnt (%s)\n", srv.LastError());

    if (!srv.Start(0, "geheim123")) { std::printf("  ### Start fehlgeschlagen ###\n"); return 1; }
    std::printf("  Server laeuft auf Port %u\n", (unsigned)srv.Port());

    // 2. Falsches Geheimnis
    {
        XbmCmdClient c;
        c.Connect("127.0.0.1", srv.Port(), "FALSCH");
        pump(srv, c, 300);
        std::printf("  falsches Geheimnis -> %s\n", XbmCmdStatusText(c.GetStatus()));
        if (c.GetStatus() != XbmCmdStatus::FehlerGeheimnis) fehler++;
    }

    // 3. Richtiges Geheimnis, Befehl ausfuehren
    XbmCmdClient cli;
    if (!cli.Connect("127.0.0.1", srv.Port(), "geheim123")) {
        std::printf("  ### Verbindung fehlgeschlagen ###\n"); return 1;
    }
    pump(srv, cli, 300);
    std::printf("  richtiges Geheimnis -> %s\n", XbmCmdStatusText(cli.GetStatus()));
    if (cli.GetStatus() != XbmCmdStatus::Bereit) { fehler++; return 1; }

    std::string gesammelt; int endcode = -999;
    cli.Run("echo hallo; echo zweite; exit 3",
            [&](const std::string& z, bool){ gesammelt += z; },
            [&](int c){ endcode = c; });
    pump(srv, cli, 800);
    std::printf("  Ausgabe: %s", gesammelt.c_str());
    std::printf("  Rueckgabewert: %d\n", endcode);
    if (gesammelt.find("hallo") == std::string::npos) fehler++;
    if (gesammelt.find("zweite") == std::string::npos) fehler++;
    if (endcode != 3) { std::printf("  ### erwartet 3 ###\n"); fehler++; }

    // 4. Zweiter Befehl ueber DIESELBE Verbindung -- und wie schnell?
    auto t0 = std::chrono::steady_clock::now();
    gesammelt.clear(); endcode = -999;
    cli.Run("echo zweiter-befehl",
            [&](const std::string& z, bool){ gesammelt += z; },
            [&](int c){ endcode = c; });
    while (endcode == -999) { srv.Poll(); cli.Poll();
        std::this_thread::sleep_for(std::chrono::milliseconds(1)); }
    auto ms = std::chrono::duration_cast<std::chrono::microseconds>(
                  std::chrono::steady_clock::now() - t0).count() / 1000.0;
    std::printf("  zweiter Befehl: \"%s\"  in %.1f ms\n",
                gesammelt.substr(0, gesammelt.size()?gesammelt.size()-1:0).c_str(), ms);

    // 5. Grosse Ausgabe -- kommt sie vollstaendig an?
    gesammelt.clear(); endcode = -999;
    cli.Run("seq 1 5000",
            [&](const std::string& z, bool){ gesammelt += z; },
            [&](int c){ endcode = c; });
    pump(srv, cli, 3000);
    long zeilen = 0; for (char ch : gesammelt) if (ch=='\n') zeilen++;
    std::printf("  grosse Ausgabe: %ld Zeilen (erwartet 5000)\n", zeilen);
    if (zeilen != 5000) fehler++;

    auto st = srv.GetStats();
    std::printf("  Server: %llu Verbindungen, %llu Befehle, %llu abgewiesen\n",
                (unsigned long long)st.verbindungen, (unsigned long long)st.befehle,
                (unsigned long long)st.abgewiesen);
    std::printf(fehler ? "  ### %d FEHLER ###\n" : "  alles bestanden\n", fehler);
    return fehler ? 1 : 0;
}
