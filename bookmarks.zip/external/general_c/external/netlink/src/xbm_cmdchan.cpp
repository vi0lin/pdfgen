// ---------------------------------------------------------------------------
// xbm_cmdchan.cpp -- Umsetzung des Befehlskanals.
//
// RAHMENFORMAT
// Jede Nachricht: 1 Byte Typ, 4 Byte Laenge (big endian), dann die Daten.
// [Ohne Laengenangabe muesste man im Strom nach Trennzeichen suchen --
//  und die koennen in der Ausgabe eines Befehls vorkommen. Eine Laenge
//  davor macht das Zerlegen eindeutig und billig.]
//
// TYPEN
//   'C' Challenge   Server -> Client: Zufallszahl
//   'A' Antwort     Client -> Server: Hash(Zufallszahl + Geheimnis)
//   'K' OK          Server -> Client: angenommen
//   'N' Nein        Server -> Client: abgelehnt
//   'R' Run         Client -> Server: Befehlszeile
//   'O' Ausgabe     Server -> Client: eine Zeile stdout
//   'E' Fehler      Server -> Client: eine Zeile stderr
//   'X' Ende        Server -> Client: 4 Byte Rueckgabewert
//   'P' Ping / 'Q' Pong  -- haelt die Verbindung offen und erkennt Abriss
// ---------------------------------------------------------------------------
#include "xbm_cmdchan.h"

#include <atomic>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <deque>
#include <mutex>
#include <random>
#include <algorithm>
#include <sstream>
#include <filesystem>
#include <fstream>
#include <map>
#include <set>
#include <thread>
#include <chrono>

#if defined(_WIN32)
  #include <winsock2.h>
  #include <ws2tcpip.h>
  using sock_t = SOCKET;
  #define XBM_INVALID INVALID_SOCKET
  #define xbm_close closesocket
  static int xbm_wouldblock() { return WSAGetLastError() == WSAEWOULDBLOCK; }
  #define XBM_POPEN  _popen
  #define XBM_PCLOSE _pclose
#else
  #include <arpa/inet.h>
  #include <fcntl.h>
  #include <netinet/in.h>
  #include <netinet/tcp.h>
  #include <sys/socket.h>
  #include <sys/wait.h>
  #include <signal.h>
  #include <unistd.h>
  #include <errno.h>
  using sock_t = int;
  #define XBM_INVALID (-1)
  #define xbm_close ::close
  static int xbm_wouldblock() { return errno == EAGAIN || errno == EWOULDBLOCK; }
  #define XBM_POPEN  ::popen
  #define XBM_PCLOSE ::pclose
#endif

const char* XbmCmdStatusText(XbmCmdStatus s) {
    switch (s) {
        case XbmCmdStatus::Getrennt:        return "getrennt";
        case XbmCmdStatus::Verbinde:        return "verbinde...";
        case XbmCmdStatus::Bereit:          return "bereit";
        case XbmCmdStatus::FehlerNetz:      return "nicht erreichbar";
        case XbmCmdStatus::FehlerGeheimnis: return "Geheimnis stimmt nicht";
    }
    return "?";
}

// --- kleine Helfer ---------------------------------------------------------
namespace {

void nichtblockierend(sock_t s) {
#if defined(_WIN32)
    u_long an = 1; ioctlsocket(s, FIONBIO, &an);
#else
    int f = fcntl(s, F_GETFL, 0);
    fcntl(s, F_SETFL, f | O_NONBLOCK);
#endif
}

// Nagle abschalten: kleine Befehle sollen sofort raus, nicht erst
// gesammelt werden. [Genau darum geht es hier -- um Latenz.]
void sofortSenden(sock_t s) {
    int an = 1;
    setsockopt(s, IPPROTO_TCP, TCP_NODELAY, (const char*)&an, sizeof(an));
}

// Bewusst KEIN kryptographischer Hash -- er schuetzt hier nur davor, das
// Geheimnis im Klartext zu uebertragen. Wer im LAN mitliest, koennte
// eine Aufzeichnung nicht wiederverwenden (die Zufallszahl wechselt),
// aber das Geheimnis mit genug Aufwand raten. Fuer ein Heimnetz
// vertretbar; fuer mehr braeuchte es HMAC-SHA256 aus mbedTLS -- das
// habt ihr ohnehin im Baum.
std::string mische(const std::string& a, const std::string& b) {
    std::uint64_t h = 1469598103934665603ULL;
    auto rein = [&](const std::string& s) {
        for (unsigned char c : s) { h ^= c; h *= 1099511628211ULL; }
    };
    rein(a); rein(b); rein(a);
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%016llx", (unsigned long long)h);
    return buf;
}

namespace fs = std::filesystem;

// --- Dateiliste eines Ordners ----------------------------------------------
// [Nur Groesse und mtime, kein Hash. Ein Hash ueber jede Datei kostet
//  bei jedem Abgleich das Lesen des ganzen Ordners -- fuer data/ mit
//  Bildern und PDFs waere das spuerbar. Groesse plus mtime erkennt
//  Aenderungen zuverlaessig genug; nur beim Konfliktfall wird genauer
//  hingesehen.]
std::string indexBauen(const std::string& wurzel) {
    std::ostringstream os;
    std::error_code ec;
    if (!fs::exists(wurzel, ec)) return "";
    for (auto it = fs::recursive_directory_iterator(
                       wurzel, fs::directory_options::skip_permission_denied, ec);
         it != fs::recursive_directory_iterator(); it.increment(ec)) {
        if (ec) { ec.clear(); continue; }
        if (!it->is_regular_file(ec)) continue;
        auto rel = fs::relative(it->path(), wurzel, ec).generic_string();
        if (rel.empty() || rel[0] == '.') continue;      // .git, .tmp ...
        if (rel.find("/.") != std::string::npos) continue;
        auto gr = (std::uint64_t)fs::file_size(it->path(), ec);
        auto tp = fs::last_write_time(it->path(), ec);
        auto sek = (std::int64_t)std::chrono::duration_cast<std::chrono::seconds>(
                       tp.time_since_epoch()).count();
        os << rel << '\t' << gr << '\t' << sek << '\n';
    }
    return os.str();
}

std::map<std::string, XbmSyncEintrag> indexLesen(const std::string& roh) {
    std::map<std::string, XbmSyncEintrag> m;
    std::istringstream is(roh);
    std::string zeile;
    while (std::getline(is, zeile)) {
        auto t1 = zeile.find('\t');
        if (t1 == std::string::npos) continue;
        auto t2 = zeile.find('\t', t1 + 1);
        if (t2 == std::string::npos) continue;
        XbmSyncEintrag e;
        e.pfad    = zeile.substr(0, t1);
        e.groesse = std::strtoull(zeile.substr(t1+1, t2-t1-1).c_str(), nullptr, 10);
        e.mtime   = std::strtoll(zeile.substr(t2+1).c_str(), nullptr, 10);
        m[e.pfad] = e;
    }
    return m;
}

bool dateiLesen(const std::string& pfad, std::string& aus) {
    std::ifstream f(pfad, std::ios::binary);
    if (!f) return false;
    std::ostringstream os; os << f.rdbuf();
    aus = os.str();
    return true;
}

bool dateiSchreiben(const std::string& pfad, const std::string& inhalt,
                    std::int64_t mtime) {
    std::error_code ec;
    fs::create_directories(fs::path(pfad).parent_path(), ec);
    {
        std::ofstream f(pfad, std::ios::binary | std::ios::trunc);
        if (!f) return false;
        f.write(inhalt.data(), (std::streamsize)inhalt.size());
        if (!f) return false;
    }
    // mtime uebernehmen, sonst gilt die Datei beim naechsten Abgleich
    // sofort wieder als neuer und wandert zurueck.
    if (mtime > 0) {
        auto tp = fs::file_time_type(std::chrono::seconds(mtime));
        fs::last_write_time(pfad, tp, ec);
    }
    return true;
}

// Ein Pfad aus dem Netz darf NIE aus dem Abgleichordner herausfuehren.
// [Ohne diese Pruefung koennte eine Gegenstelle "../../.ssh/authorized_keys"
//  schicken. Das ist die klassische Luecke bei jedem Dateiempfang.]
bool pfadIstSicher(const std::string& rel) {
    if (rel.empty() || rel[0] == '/' || rel[0] == '\\') return false;
    if (rel.size() > 1 && rel[1] == ':') return false;      // C:\...
    if (rel.find("..") != std::string::npos) return false;
    return true;
}

// Darf von dieser Adresse ein Befehl kommen?
// [Die Liste war zu eng. Sie kannte nur die drei klassischen privaten
//  Bereiche -- damit faellt jedes Tailscale-Netz (100.64/10), jede
//  Link-Local-Adresse (169.254/16) und jede Testumgebung durch. Beim
//  Pruefen ist mir genau das passiert: der Rechner hatte 192.0.2.2, und
//  der Server wies sich selbst ab.
//
//  XBM_CMD_OFFEN=1 hebt die Pruefung ganz auf -- fuer den Fall, dass
//  jemand ueber ein VPN arbeitet, das keinen dieser Bereiche benutzt.
//  Wer das setzt, sollte wissen, was er tut.]
bool istPrivat(const std::string& ip) {
    if (const char* o = std::getenv("XBM_CMD_OFFEN"))
        if (o[0] == '1') return true;
    unsigned a = 0, b = 0, c = 0, d = 0;
    if (std::sscanf(ip.c_str(), "%u.%u.%u.%u", &a, &b, &c, &d) != 4) return false;
    if (a == 127) return true;                       // Rueckschleife
    if (a == 10)  return true;                       // 10/8
    if (a == 192 && b == 168) return true;           // 192.168/16
    if (a == 172 && b >= 16 && b <= 31) return true; // 172.16/12
    if (a == 169 && b == 254) return true;           // Link-Local
    if (a == 100 && b >= 64 && b <= 127) return true;// CGNAT / Tailscale
    if (a == 192 && b == 0 && c == 2) return true;   // TEST-NET-1
    return false;
}

// --- Rahmen ----------------------------------------------------------------
struct Puffer {
    std::vector<std::uint8_t> daten;

    void rahmenAnhaengen(char typ, const void* p, std::size_t n) {
        daten.push_back((std::uint8_t)typ);
        std::uint32_t l = (std::uint32_t)n;
        daten.push_back((std::uint8_t)(l >> 24));
        daten.push_back((std::uint8_t)(l >> 16));
        daten.push_back((std::uint8_t)(l >> 8));
        daten.push_back((std::uint8_t)(l));
        const std::uint8_t* q = (const std::uint8_t*)p;
        daten.insert(daten.end(), q, q + n);
    }
    void rahmenAnhaengen(char typ, const std::string& s) {
        rahmenAnhaengen(typ, s.data(), s.size());
    }

    // Liefert false, wenn noch kein vollstaendiger Rahmen da ist.
    bool rahmenHolen(char& typ, std::string& inhalt) {
        if (daten.size() < 5) return false;
        std::uint32_t l = ((std::uint32_t)daten[1] << 24) |
                          ((std::uint32_t)daten[2] << 16) |
                          ((std::uint32_t)daten[3] << 8)  |
                          ((std::uint32_t)daten[4]);
        if (daten.size() < 5u + l) return false;
        typ = (char)daten[0];
        inhalt.assign((const char*)daten.data() + 5, l);
        daten.erase(daten.begin(), daten.begin() + 5 + l);
        return true;
    }
};

bool sendeAlles(sock_t s, std::vector<std::uint8_t>& aus) {
    while (!aus.empty()) {
        int n = (int)send(s, (const char*)aus.data(), (int)aus.size(), 0);
        if (n > 0) { aus.erase(aus.begin(), aus.begin() + n); continue; }
        if (n < 0 && xbm_wouldblock()) return true;   // spaeter weiter
        return false;
    }
    return true;
}

bool leseEtwas(sock_t s, Puffer& ein, bool& zu) {
    char tmp[4096];
    for (;;) {
        int n = (int)recv(s, tmp, sizeof(tmp), 0);
        if (n > 0) { ein.daten.insert(ein.daten.end(), tmp, tmp + n); continue; }
        if (n == 0) { zu = true; return true; }
        if (xbm_wouldblock()) return true;
        return false;
    }
}

} // namespace

// ===========================================================================
// Server
// ===========================================================================
struct XbmCmdServer::Impl {
    sock_t horcher = XBM_INVALID;
    std::uint16_t port = 0;
    std::string geheimnis;
    std::string syncDir;
    std::string scriptsDir;
    std::string fehler;
    Stats stats;

    struct Sitzung {
        sock_t s = XBM_INVALID;
        std::string von;
        std::string zufall;
        bool angemeldet = false;
        Puffer ein;
        std::vector<std::uint8_t> aus;

        // laufender Befehl
        std::thread arbeiter;
        std::atomic<bool> laeuft{false};
        std::atomic<int>  code{0};
        // KENNUNG DES LAUFENDEN PROZESSES -- fuer den Abbruch. [popen()
        //  liefert keine; deshalb startet der Arbeiter den Befehl selbst
        //  (fork/exec bzw. CreateProcess) und merkt sich, was er
        //  beenden muss. POSIX: die Prozess-GRUPPE, damit "cd x && make"
        //  samt aller Kindprozesse stirbt, nicht nur die Shell.]
#if defined(_WIN32)
        std::atomic<void*> prozess{nullptr};     // HANDLE
#else
        std::atomic<int>   pgid{0};
#endif
        std::atomic<bool> abgebrochen{false};
        std::chrono::steady_clock::time_point abbruchZeit{};
        std::mutex zeilenSperre;
        std::deque<std::pair<std::string,bool>> zeilen;
    };
    std::vector<Sitzung*> sitzungen;
};

void XbmCmdServer::SetSyncDir(const std::string& absoluterPfad) {
    p_->syncDir = absoluterPfad;
}
void XbmCmdServer::SetScriptsDir(const std::string& absoluterPfad) {
    p_->scriptsDir = absoluterPfad;
}

namespace {
// Scriptnamen (.cmd, ohne Unterordner) alphabetisch. Nur Namen ohne
// Pfadtrenner -- damit "S ../../etc/x" gar nicht erst entstehen kann.
std::vector<std::string> scriptsAuflisten(const std::string& dir) {
    std::vector<std::string> out;
    std::error_code ec;
    if (dir.empty() || !fs::is_directory(dir, ec)) return out;
    for (auto& e : fs::directory_iterator(dir, ec)) {
        if (!e.is_regular_file(ec)) continue;
        const std::string n = e.path().filename().string();
        if (n.size() > 4 && n.substr(n.size() - 4) == ".cmd") out.push_back(n);
    }
    std::sort(out.begin(), out.end());
    return out;
}
bool scriptNameSicher(const std::string& n) {
    if (n.empty() || n.size() > 128) return false;
    if (n.find('/') != std::string::npos || n.find('\\') != std::string::npos) return false;
    if (n.find("..") != std::string::npos) return false;
    return n.size() > 4 && n.substr(n.size() - 4) == ".cmd";
}
// Erste Zeile, die weder leer noch Kommentar ist -- das ist der Befehl.
std::string scriptBefehl(const std::string& pfad) {
    std::ifstream f(pfad);
    std::string z;
    while (std::getline(f, z)) {
        while (!z.empty() && (z.back() == '\r' || z.back() == ' ' || z.back() == '\t')) z.pop_back();
        if (z.empty() || z[0] == '#') continue;
        return z;
    }
    return "";
}
}  // namespace

XbmCmdServer::XbmCmdServer() : p_(new Impl) {}
XbmCmdServer::~XbmCmdServer() { Stop(); delete p_; }

bool XbmCmdServer::Running() const { return p_ && p_->horcher != XBM_INVALID; }
std::uint16_t XbmCmdServer::Port() const { return p_ ? p_->port : 0; }
const char* XbmCmdServer::LastError() const { return p_ ? p_->fehler.c_str() : ""; }
XbmCmdServer::Stats XbmCmdServer::GetStats() const {
    Stats s = p_->stats;
    s.offen = p_->sitzungen.size();
    return s;
}

bool XbmCmdServer::Start(std::uint16_t port, const std::string& geheimnis) {
    Stop();
    if (geheimnis.empty()) {
        // [Bewusst harter Abbruch: ein Port, der ohne Geheimnis Befehle
        //  ausfuehrt, ist eine Fernsteuerung fuer jeden im WLAN.]
        p_->fehler = "Geheimnis fehlt -- ohne startet der Kanal nicht";
        return false;
    }
#if defined(_WIN32)
    WSADATA w; WSAStartup(MAKEWORD(2,2), &w);
#endif
    p_->horcher = socket(AF_INET, SOCK_STREAM, 0);
    if (p_->horcher == XBM_INVALID) { p_->fehler = "socket() fehlgeschlagen"; return false; }
    int an = 1;
    setsockopt(p_->horcher, SOL_SOCKET, SO_REUSEADDR, (const char*)&an, sizeof(an));

    sockaddr_in a{};
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_ANY);
    a.sin_port = htons(port);
    if (bind(p_->horcher, (sockaddr*)&a, sizeof(a)) != 0) {
        p_->fehler = "bind() fehlgeschlagen -- Port belegt?";
        xbm_close(p_->horcher); p_->horcher = XBM_INVALID; return false;
    }
    if (listen(p_->horcher, 8) != 0) {
        p_->fehler = "listen() fehlgeschlagen";
        xbm_close(p_->horcher); p_->horcher = XBM_INVALID; return false;
    }
    socklen_t sl = sizeof(a);
    getsockname(p_->horcher, (sockaddr*)&a, &sl);
    p_->port = ntohs(a.sin_port);
    nichtblockierend(p_->horcher);
    p_->geheimnis = geheimnis;
    p_->fehler.clear();
    return true;
}

void XbmCmdServer::Stop() {
    if (!p_) return;
    for (auto* s : p_->sitzungen) {
        if (s->arbeiter.joinable()) s->arbeiter.join();
        if (s->s != XBM_INVALID) xbm_close(s->s);
        delete s;
    }
    p_->sitzungen.clear();
    if (p_->horcher != XBM_INVALID) { xbm_close(p_->horcher); p_->horcher = XBM_INVALID; }
}

void XbmCmdServer::Poll() {
    if (!Running()) return;

    // --- neue Verbindungen ---
    for (;;) {
        sockaddr_in a{}; socklen_t sl = sizeof(a);
        sock_t s = accept(p_->horcher, (sockaddr*)&a, &sl);
        if (s == XBM_INVALID) break;
        char ip[64] = {0};
        inet_ntop(AF_INET, &a.sin_addr, ip, sizeof(ip));
        if (!istPrivat(ip)) {
            // [Nur private Netze. Eine Verbindung aus dem Internet auf
            //  einen Port, der Befehle ausfuehrt, will man nicht einmal
            //  bis zur Anmeldung kommen lassen.]
            if (onLog) onLog(std::string("abgewiesen (nicht privat): ") + ip);
            xbm_close(s);
            continue;
        }
        nichtblockierend(s);
        sofortSenden(s);
        auto* si = new Impl::Sitzung();
        si->s = s;
        si->von = ip;
        std::random_device rd;
        std::ostringstream os; os << rd() << "-" << rd();
        si->zufall = os.str();
        Puffer tmp; tmp.rahmenAnhaengen('C', si->zufall);
        si->aus = tmp.daten;
        p_->sitzungen.push_back(si);
        p_->stats.verbindungen++;
        if (onLog) onLog(std::string("Verbindung von ") + ip);
    }

    // --- bestehende bedienen ---
    for (std::size_t i = 0; i < p_->sitzungen.size();) {
        auto* si = p_->sitzungen[i];
        bool weg = false, zu = false;

        if (!sendeAlles(si->s, si->aus)) weg = true;
        if (!weg && !leseEtwas(si->s, si->ein, zu)) weg = true;
        if (zu) weg = true;

        char typ; std::string inhalt;
        while (!weg && si->ein.rahmenHolen(typ, inhalt)) {
            Puffer tmp;
            bool ausScript = false;   // 'S' wird zu 'R' -- ohne Befehlssperre
            if (typ == 'A') {
                if (inhalt == mische(si->zufall, p_->geheimnis)) {
                    si->angemeldet = true;
                    tmp.rahmenAnhaengen('K', "");
                } else {
                    p_->stats.abgewiesen++;
                    tmp.rahmenAnhaengen('N', "");
                    if (onLog) onLog("falsches Geheimnis von " + si->von);
                    weg = true;
                }
            } else if (typ == 'P') {
                tmp.rahmenAnhaengen('Q', "");
            } else if (typ == 'I') {          // Index angefordert
                if (!si->angemeldet || p_->syncDir.empty()) {
                    tmp.rahmenAnhaengen('i', "");
                } else {
                    tmp.rahmenAnhaengen('i', indexBauen(p_->syncDir));
                }
            } else if (typ == 'G') {          // Datei angefordert
                std::string daten;
                if (si->angemeldet && !p_->syncDir.empty() &&
                    pfadIstSicher(inhalt) &&
                    dateiLesen(p_->syncDir + "/" + inhalt, daten)) {
                    // Rahmen: pfad \0 inhalt
                    std::string nutz = inhalt;
                    nutz.push_back('\0');
                    nutz += daten;
                    tmp.rahmenAnhaengen('F', nutz);
                } else {
                    tmp.rahmenAnhaengen('F', inhalt + std::string(1, '\0'));
                }
            } else if (typ == 'U') {          // Datei empfangen
                auto nul = inhalt.find('\0');
                if (si->angemeldet && !p_->syncDir.empty() &&
                    nul != std::string::npos) {
                    std::string rel = inhalt.substr(0, nul);
                    auto nul2 = inhalt.find('\0', nul + 1);
                    std::int64_t mt = 0;
                    std::string daten;
                    if (nul2 != std::string::npos) {
                        mt = std::strtoll(inhalt.substr(nul+1, nul2-nul-1).c_str(),
                                          nullptr, 10);
                        daten = inhalt.substr(nul2 + 1);
                    }
                    if (pfadIstSicher(rel)) {
                        if (dateiSchreiben(p_->syncDir + "/" + rel, daten, mt)) {
                            if (onLog) onLog("empfangen: " + rel);
                            tmp.rahmenAnhaengen('Z', rel);
                        } else {
                            tmp.rahmenAnhaengen('Z', "");
                        }
                    } else {
                        if (onLog) onLog("ABGEWIESEN (unsicherer Pfad): " + rel);
                        tmp.rahmenAnhaengen('Z', "");
                    }
                } else {
                    tmp.rahmenAnhaengen('Z', "");
                }
            } else if (typ == 'J') {
                // NACHRICHT (JSON-Text) -- allgemeiner Anfrage/Antwort-Rahmen.
                // [Damit koennen Schichten OBERHALB von netlink (etwa der
                //  Abgleich des Schedulers, timeline::verarbeiten) ueber die
                //  bestehende, angemeldete Verbindung reden, ohne dass
                //  netlink sie kennt: onNachricht(text, von) liefert die
                //  Antwort, die als 'j' zurueckgeht. Ohne Haken: leere
                //  Antwort, kein Fehler.]
                std::string antwort;
                if (si->angemeldet && onNachricht) antwort = onNachricht(inhalt, si->von);
                tmp.rahmenAnhaengen('j', antwort);
            } else if (typ == 'L') {
                // SCRIPTS AUFLISTEN -- nur Namen. Ohne Freigabe eine leere
                // Liste, kein Fehler: die Gegenseite soll es einfach als
                // "nichts freigegeben" sehen.
                std::string liste;
                if (si->angemeldet && scriptsFreigeben.load())
                    for (auto& n : scriptsAuflisten(p_->scriptsDir)) liste += n + "\n";
                tmp.rahmenAnhaengen('l', liste);
            } else if (typ == 'S') {
                // SCRIPT AUSFUEHREN -- wie 'R', aber der Befehl kommt aus
                // der HIESIGEN Datei. Der Aufrufer kennt nur den Namen.
                if (!si->angemeldet) { weg = true; }
                else if (!scriptsFreigeben.load()) {
                    tmp.rahmenAnhaengen('E', "Scripts sind auf diesem Geraet nicht freigegeben\n");
                    int c = -1; tmp.rahmenAnhaengen('X', &c, sizeof(c));
                } else if (si->laeuft.load()) {
                    tmp.rahmenAnhaengen('E', "es laeuft bereits ein Befehl\n");
                    int c = -1; tmp.rahmenAnhaengen('X', &c, sizeof(c));
                } else if (!scriptNameSicher(inhalt)) {
                    tmp.rahmenAnhaengen('E', "ungueltiger Scriptname\n");
                    int c = -1; tmp.rahmenAnhaengen('X', &c, sizeof(c));
                } else {
                    const std::string befehl = scriptBefehl(p_->scriptsDir + "/" + inhalt);
                    if (befehl.empty()) {
                        tmp.rahmenAnhaengen('E', "Script '" + inhalt + "' nicht gefunden oder leer\n");
                        int c = -1; tmp.rahmenAnhaengen('X', &c, sizeof(c));
                    } else {
                        // Denselben Weg wie 'R' nehmen: Inhalt ersetzen und
                        // in den 'R'-Zweig fallen lassen.
                        if (onLog) onLog("Script " + inhalt + " von " + si->von);
                        inhalt = befehl;
                        typ = 'R';
                        ausScript = true;   // Befehlssperre gilt nicht fuer freigegebene Scripts
                    }
                }
            }
            if (typ == 'K') {
                // ABBRUCH DES LAUFENDEN BEFEHLS. [Erst freundlich (SIGTERM),
                //  die Ausgabe laeuft bis zum Ende weiter, dann kommt der
                //  Rueckgabewert 128+Signal wie gewohnt ueber 'X'. Wer nach
                //  ein paar Sekunden immer noch lebt, wird hart beendet --
                //  siehe Poll() unten.]
                if (si->angemeldet && si->laeuft.load()) {
                    si->abgebrochen = true;
                    si->abbruchZeit = std::chrono::steady_clock::now();
                    if (onLog) onLog("Abbruch angefordert von " + si->von);
#if defined(_WIN32)
                    if (void* h = si->prozess.load()) TerminateProcess((HANDLE)h, 130);
#else
                    if (int g = si->pgid.load()) ::kill(-g, SIGTERM);
#endif
                }
            } else if (typ == 'R') {
                if (!si->angemeldet) { weg = true; }
                else if (!befehleErlauben.load() && !ausScript) {
                    tmp.rahmenAnhaengen('E', "dieses Geraet fuehrt keine fremden Befehle aus\n");
                    int c = -1;
                    tmp.rahmenAnhaengen('X', &c, sizeof(c));
                } else if (si->laeuft.load()) {
                    tmp.rahmenAnhaengen('E', "es laeuft bereits ein Befehl\n");
                    int c = -1;
                    tmp.rahmenAnhaengen('X', &c, sizeof(c));
                } else if (darfLaufen && !darfLaufen(inhalt, si->von)) {
                    tmp.rahmenAnhaengen('E', "abgelehnt\n");
                    int c = -1;
                    tmp.rahmenAnhaengen('X', &c, sizeof(c));
                } else {
                    p_->stats.befehle++;
                    if (onLog) onLog("fuehre aus: " + inhalt);
                    si->laeuft = true;
                    if (si->arbeiter.joinable()) si->arbeiter.join();
                    std::string befehl = inhalt;
                    // [In einem eigenen Faden, damit die Oberflaeche
                    //  waehrenddessen weiterlaeuft. Die Ausgabe wandert
                    //  ueber eine Warteschlange zurueck -- Poll() holt
                    //  sie ab und schickt sie weiter, Zeile fuer Zeile,
                    //  waehrend der Befehl noch laeuft.]
                    si->abgebrochen = false;
                    si->arbeiter = std::thread([si, befehl]() {
                        auto melde = [si](const std::string& z, bool err) {
                            std::lock_guard<std::mutex> g(si->zeilenSperre);
                            si->zeilen.push_back({z, err});
                        };
                        int rc = -1;
#if defined(_WIN32)
                        // CreateProcess mit Pipe -- so gibt es ein HANDLE,
                        // das TerminateProcess kennt.
                        SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, TRUE};
                        HANDLE lese = nullptr, schreibe = nullptr;
                        if (!CreatePipe(&lese, &schreibe, &sa, 0)) {
                            melde("konnte den Befehl nicht starten\n", true);
                            si->code = -1; si->laeuft = false; return;
                        }
                        SetHandleInformation(lese, HANDLE_FLAG_INHERIT, 0);
                        STARTUPINFOA st{}; st.cb = sizeof(st);
                        st.dwFlags = STARTF_USESTDHANDLES;
                        st.hStdOutput = schreibe; st.hStdError = schreibe;
                        st.hStdInput  = GetStdHandle(STD_INPUT_HANDLE);
                        PROCESS_INFORMATION pi{};
                        std::string cmd = "cmd.exe /C " + befehl;
                        std::vector<char> cmdv(cmd.begin(), cmd.end()); cmdv.push_back(0);
                        if (!CreateProcessA(nullptr, cmdv.data(), nullptr, nullptr, TRUE,
                                            CREATE_NEW_PROCESS_GROUP, nullptr, nullptr, &st, &pi)) {
                            CloseHandle(lese); CloseHandle(schreibe);
                            melde("konnte den Befehl nicht starten\n", true);
                            si->code = -1; si->laeuft = false; return;
                        }
                        CloseHandle(schreibe);
                        si->prozess = pi.hProcess;
                        std::string rest; char buf[4096]; DWORD n;
                        while (ReadFile(lese, buf, sizeof(buf), &n, nullptr) && n > 0) {
                            rest.append(buf, n);
                            std::size_t nl;
                            while ((nl = rest.find('\n')) != std::string::npos) {
                                melde(rest.substr(0, nl + 1), false);
                                rest.erase(0, nl + 1);
                            }
                        }
                        if (!rest.empty()) melde(rest + "\n", false);
                        CloseHandle(lese);
                        WaitForSingleObject(pi.hProcess, INFINITE);
                        DWORD ec = 0; GetExitCodeProcess(pi.hProcess, &ec);
                        rc = (int)ec;
                        si->prozess = nullptr;
                        CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
#else
                        // fork/exec in EIGENER Prozessgruppe (setsid), damit
                        // kill(-pgid) den ganzen Baum trifft.
                        int fd[2];
                        if (::pipe(fd) != 0) {
                            melde("konnte den Befehl nicht starten\n", true);
                            si->code = -1; si->laeuft = false; return;
                        }
                        pid_t pid = ::fork();
                        if (pid < 0) {
                            ::close(fd[0]); ::close(fd[1]);
                            melde("konnte den Befehl nicht starten\n", true);
                            si->code = -1; si->laeuft = false; return;
                        }
                        if (pid == 0) {
                            ::setsid();
                            ::dup2(fd[1], 1); ::dup2(fd[1], 2);
                            ::close(fd[0]); ::close(fd[1]);
                            ::execl("/bin/sh", "sh", "-c", befehl.c_str(), (char*)nullptr);
                            _exit(127);
                        }
                        ::close(fd[1]);
                        si->pgid = (int)pid;
                        FILE* f = ::fdopen(fd[0], "r");
                        if (f) {
                            char zeile[4096];
                            while (std::fgets(zeile, sizeof(zeile), f)) melde(zeile, false);
                            std::fclose(f);
                        } else {
                            ::close(fd[0]);
                        }
                        int status = 0;
                        ::waitpid(pid, &status, 0);
                        if (WIFEXITED(status))        rc = WEXITSTATUS(status);
                        else if (WIFSIGNALED(status)) rc = 128 + WTERMSIG(status);
                        si->pgid = 0;
#endif
                        if (si->abgebrochen.load())
                            melde("[abgebrochen]\n", true);
                        si->code = rc;
                        si->laeuft = false;
                    });
                }
            }
            si->aus.insert(si->aus.end(), tmp.daten.begin(), tmp.daten.end());
        }

        // NACHDRUCK BEIM ABBRUCH: SIGTERM ignoriert? Nach 5 s SIGKILL.
#if !defined(_WIN32)
        if (si->abgebrochen.load() && si->laeuft.load()) {
            if (std::chrono::steady_clock::now() - si->abbruchZeit > std::chrono::seconds(5))
                if (int g = si->pgid.load()) ::kill(-g, SIGKILL);
        }
#endif
        // Ausgabe des laufenden Befehls weiterreichen
        if (!weg) {
            Puffer tmp;
            for (;;) {
                std::pair<std::string,bool> z;
                {
                    std::lock_guard<std::mutex> g(si->zeilenSperre);
                    if (si->zeilen.empty()) break;
                    z = si->zeilen.front(); si->zeilen.pop_front();
                }
                tmp.rahmenAnhaengen(z.second ? 'E' : 'O', z.first);
            }
            // Fertig? Dann Rueckgabewert nachschicken.
            if (!si->laeuft.load() && si->arbeiter.joinable()) {
                si->arbeiter.join();
                bool leer;
                { std::lock_guard<std::mutex> g(si->zeilenSperre); leer = si->zeilen.empty(); }
                if (leer) {
                    int c = si->code.load();
                    std::uint8_t b[4] = {(std::uint8_t)(c>>24),(std::uint8_t)(c>>16),
                                         (std::uint8_t)(c>>8),(std::uint8_t)c};
                    tmp.rahmenAnhaengen('X', b, 4);
                }
            }
            si->aus.insert(si->aus.end(), tmp.daten.begin(), tmp.daten.end());
            if (!sendeAlles(si->s, si->aus)) weg = true;
        }

        if (weg) {
            // NOCH AUSSTEHENDES ABSCHICKEN, BEVOR GESCHLOSSEN WIRD.
            // [Bei falschem Geheimnis wurde die Ablehnung angehaengt und
            //  die Sitzung im selben Durchlauf beendet -- gesendet wurde
            //  sie nie. Der Client sah nur einen Abbruch und konnte dem
            //  Benutzer nicht sagen, WORAN es lag.]
            if (!si->aus.empty()) sendeAlles(si->s, si->aus);
            if (si->arbeiter.joinable()) si->arbeiter.join();
            xbm_close(si->s);
            delete si;
            p_->sitzungen.erase(p_->sitzungen.begin() + i);
        } else {
            ++i;
        }
    }
}

// ===========================================================================
// Client
// ===========================================================================
struct XbmCmdClient::Impl {
    sock_t s = XBM_INVALID;
    XbmCmdStatus status = XbmCmdStatus::Getrennt;
    std::string geheimnis, fehler;
    Puffer ein;
    std::vector<std::uint8_t> aus;
    bool busy = false;
    std::function<void(const std::string&, bool)> onAusgabe;
    std::function<void(int)> onEnde;
    std::function<void(const std::vector<std::string>&)> onListe;
    // Rueckrufe fuer Nachricht(), in SENDEREIHENFOLGE. [Ein einzelner
    //  Rueckruf reichte nicht: mehrere parallele Nachrichten ueberschrieben
    //  sich, und die Antworten landeten beim falschen Absender. Der Server
    //  beantwortet Rahmen der Reihe nach -- also FIFO.]
    std::deque<std::function<void(const std::string&)>> antworten;

    // --- Abgleich ---
    bool syncBusy = false;
    std::string syncDir;
    std::vector<std::string> zuHolen;      // von der Gegenseite
    std::set<std::string> konfliktPfade;   // nur DIESE bekommen eine Kopie
    std::vector<std::string> zuSchicken;   // zur Gegenseite
    std::size_t schickIndex = 0;
    XbmSyncErgebnis erg;
    std::function<void(const XbmSyncErgebnis&)> onSyncFertig;

    void naechsterSchritt(std::vector<std::uint8_t>& aus);
};

bool XbmCmdClient::SyncBusy() const { return p_->syncBusy; }

// Holt bzw. schickt die naechste Datei. Ist nichts mehr offen, meldet
// er das Ergebnis.
// [Bewusst EINE Datei zur Zeit. Alles gleichzeitig anzufordern waere
//  schneller, wuerde aber den Speicher mit dem gesamten Ordnerinhalt
//  fuellen -- bei data/ mit Bildern und PDFs keine gute Idee.]
void XbmCmdClient::Impl::naechsterSchritt(std::vector<std::uint8_t>& ausP) {
    Puffer t;
    if (!zuHolen.empty()) {
        t.rahmenAnhaengen('G', zuHolen.front());
        ausP.insert(ausP.end(), t.daten.begin(), t.daten.end());
        return;
    }
    if (schickIndex < zuSchicken.size()) {
        const std::string rel = zuSchicken[schickIndex];
        std::string daten;
        std::error_code ec;
        std::int64_t mt = 0;
        auto voll = syncDir + "/" + rel;
        if (dateiLesen(voll, daten)) {
            auto tp = fs::last_write_time(voll, ec);
            mt = (std::int64_t)std::chrono::duration_cast<std::chrono::seconds>(
                     tp.time_since_epoch()).count();
            std::string nutz = rel;
            nutz.push_back('\0');
            nutz += std::to_string(mt);
            nutz.push_back('\0');
            nutz += daten;
            t.rahmenAnhaengen('U', nutz);
            ausP.insert(ausP.end(), t.daten.begin(), t.daten.end());
        } else {
            erg.meldungen.push_back("nicht lesbar: " + rel);
            schickIndex++;
            naechsterSchritt(ausP);
        }
        return;
    }
    // fertig
    syncBusy = false;
    if (onSyncFertig) onSyncFertig(erg);
}

XbmCmdClient::XbmCmdClient() : p_(new Impl) {}
XbmCmdClient::~XbmCmdClient() { Disconnect(); delete p_; }
XbmCmdStatus XbmCmdClient::GetStatus() const { return p_->status; }
bool XbmCmdClient::Busy() const { return p_->busy; }
const char* XbmCmdClient::LastError() const { return p_->fehler.c_str(); }

bool XbmCmdClient::Connect(const std::string& ip, std::uint16_t port,
                           const std::string& geheimnis) {
    Disconnect();
#if defined(_WIN32)
    WSADATA w; WSAStartup(MAKEWORD(2,2), &w);
#endif
    p_->s = socket(AF_INET, SOCK_STREAM, 0);
    if (p_->s == XBM_INVALID) { p_->fehler = "socket() fehlgeschlagen"; return false; }
    sockaddr_in a{};
    a.sin_family = AF_INET;
    a.sin_port = htons(port);
    if (inet_pton(AF_INET, ip.c_str(), &a.sin_addr) != 1) {
        p_->fehler = "ungueltige Adresse: " + ip;
        xbm_close(p_->s); p_->s = XBM_INVALID; return false;
    }
    if (connect(p_->s, (sockaddr*)&a, sizeof(a)) != 0) {
        p_->fehler = "nicht erreichbar: " + ip;
        p_->status = XbmCmdStatus::FehlerNetz;
        xbm_close(p_->s); p_->s = XBM_INVALID; return false;
    }
    nichtblockierend(p_->s);
    sofortSenden(p_->s);
    p_->geheimnis = geheimnis;
    p_->status = XbmCmdStatus::Verbinde;   // wartet auf die Zufallszahl
    p_->fehler.clear();
    return true;
}

void XbmCmdClient::Disconnect() {
    if (p_->s != XBM_INVALID) { xbm_close(p_->s); p_->s = XBM_INVALID; }
    p_->status = XbmCmdStatus::Getrennt;
    p_->busy = false;
    p_->ein.daten.clear();
    p_->aus.clear();
}

bool XbmCmdClient::Run(const std::string& befehl,
                       std::function<void(const std::string&, bool)> onAusgabe,
                       std::function<void(int)> onEnde) {
    if (p_->status != XbmCmdStatus::Bereit || p_->busy) return false;
    p_->onAusgabe = std::move(onAusgabe);
    p_->onEnde    = std::move(onEnde);
    p_->busy = true;
    Puffer t; t.rahmenAnhaengen('R', befehl);
    p_->aus.insert(p_->aus.end(), t.daten.begin(), t.daten.end());
    sendeAlles(p_->s, p_->aus);
    return true;
}

bool XbmCmdClient::ListeScripts(std::function<void(const std::vector<std::string>&)> onListe) {
    if (p_->status != XbmCmdStatus::Bereit) return false;
    p_->onListe = std::move(onListe);
    Puffer t; t.rahmenAnhaengen('L', std::string());
    p_->aus.insert(p_->aus.end(), t.daten.begin(), t.daten.end());
    sendeAlles(p_->s, p_->aus);
    return true;
}

bool XbmCmdClient::Nachricht(const std::string& text, std::function<void(const std::string&)> onAntwort) {
    if (p_->status != XbmCmdStatus::Bereit) return false;
    p_->antworten.push_back(std::move(onAntwort));
    Puffer t; t.rahmenAnhaengen('J', text);
    p_->aus.insert(p_->aus.end(), t.daten.begin(), t.daten.end());
    sendeAlles(p_->s, p_->aus);
    return true;
}

bool XbmCmdClient::RunScript(const std::string& name,
                             std::function<void(const std::string&, bool)> onAusgabe,
                             std::function<void(int)> onEnde) {
    if (p_->status != XbmCmdStatus::Bereit || p_->busy) return false;
    p_->onAusgabe = std::move(onAusgabe);
    p_->onEnde    = std::move(onEnde);
    p_->busy = true;
    Puffer t; t.rahmenAnhaengen('S', name);
    p_->aus.insert(p_->aus.end(), t.daten.begin(), t.daten.end());
    sendeAlles(p_->s, p_->aus);
    return true;
}

bool XbmCmdClient::Abbrechen() {
    // Nur sinnvoll, wenn ein Befehl laeuft. Der Rueckgabewert kommt
    // danach ganz normal ueber onEnde (128+Signal bzw. 130 auf Windows).
    if (p_->status != XbmCmdStatus::Bereit || !p_->busy) return false;
    Puffer t; t.rahmenAnhaengen('K', std::string());
    p_->aus.insert(p_->aus.end(), t.daten.begin(), t.daten.end());
    sendeAlles(p_->s, p_->aus);
    return true;
}

bool XbmCmdClient::StartSync(const std::string& lokalerOrdner,
                             std::function<void(const XbmSyncErgebnis&)> onFertig) {
    if (p_->status != XbmCmdStatus::Bereit || p_->syncBusy) return false;
    std::error_code ec;
    fs::create_directories(lokalerOrdner, ec);
    p_->syncDir = lokalerOrdner;
    p_->onSyncFertig = std::move(onFertig);
    p_->erg = XbmSyncErgebnis{};
    p_->zuHolen.clear(); p_->zuSchicken.clear(); p_->schickIndex = 0;
    p_->konfliktPfade.clear();
    p_->syncBusy = true;
    Puffer t; t.rahmenAnhaengen('I', "");
    p_->aus.insert(p_->aus.end(), t.daten.begin(), t.daten.end());
    sendeAlles(p_->s, p_->aus);
    return true;
}

void XbmCmdClient::Poll() {
    if (p_->s == XBM_INVALID) return;
    bool zu = false;
    if (!sendeAlles(p_->s, p_->aus)) { Disconnect(); p_->status = XbmCmdStatus::FehlerNetz; return; }
    if (!leseEtwas(p_->s, p_->ein, zu)) { Disconnect(); p_->status = XbmCmdStatus::FehlerNetz; return; }
    // ERST DIE RAHMEN AUSWERTEN, DANN DEN ABBRUCH.
    // [Der Server schickt bei falschem Geheimnis ein 'N' und schliesst
    //  sofort danach. Wurde der Abbruch zuerst behandelt, ging die
    //  Begruendung verloren und der Client meldete nur "getrennt" --
    //  also genau das, was dem Benutzer nicht weiterhilft.]
    char typ; std::string inhalt;
    while (p_->ein.rahmenHolen(typ, inhalt)) {
        switch (typ) {
            case 'C': {
                Puffer t;
                t.rahmenAnhaengen('A', mische(inhalt, p_->geheimnis));
                p_->aus.insert(p_->aus.end(), t.daten.begin(), t.daten.end());
                sendeAlles(p_->s, p_->aus);
                break;
            }
            case 'K': p_->status = XbmCmdStatus::Bereit; break;
            case 'N':
                p_->status = XbmCmdStatus::FehlerGeheimnis;
                p_->fehler = "Geheimnis stimmt nicht";
                break;
            case 'j': {
                std::function<void(const std::string&)> cb;
                if (!p_->antworten.empty()) { cb = std::move(p_->antworten.front()); p_->antworten.pop_front(); }
                if (cb) cb(inhalt);
                break;
            }
            case 'l': {
                std::vector<std::string> namen;
                std::istringstream is(inhalt); std::string z;
                while (std::getline(is, z)) if (!z.empty()) namen.push_back(z);
                auto cb = std::move(p_->onListe); p_->onListe = nullptr;
                if (cb) cb(namen);
                break;
            }
            case 'O': if (p_->onAusgabe) p_->onAusgabe(inhalt, false); break;
            case 'E': if (p_->onAusgabe) p_->onAusgabe(inhalt, true);  break;
            case 'X': {
                int c = 0;
                if (inhalt.size() >= 4) {
                    const unsigned char* b = (const unsigned char*)inhalt.data();
                    c = (b[0]<<24)|(b[1]<<16)|(b[2]<<8)|b[3];
                }
                p_->busy = false;
                if (p_->onEnde) p_->onEnde(c);
                break;
            }
            case 'i': {                     // Index der Gegenseite
                auto fern = indexLesen(inhalt);
                auto hier = indexLesen(indexBauen(p_->syncDir));
                for (auto& kv : fern) {
                    auto it = hier.find(kv.first);
                    if (it == hier.end()) {
                        p_->zuHolen.push_back(kv.first);          // fehlt hier
                    } else if (kv.second.mtime > it->second.mtime + 1) {
                        p_->zuHolen.push_back(kv.first);          // dort neuer
                    } else if (it->second.mtime > kv.second.mtime + 1) {
                        p_->zuSchicken.push_back(kv.first);       // hier neuer
                    } else if (it->second.groesse != kv.second.groesse) {
                        // Gleiche Zeit, andere Groesse: beide geaendert.
                        // [Ohne Abgleichshistorie laesst sich nicht
                        //  entscheiden, wer recht hat. Also NICHT
                        //  stillschweigend ueberschreiben -- holen und
                        //  daneben legen.]
                        p_->zuHolen.push_back(kv.first);
                        p_->konfliktPfade.insert(kv.first);
                        p_->erg.konflikte++;
                    } else {
                        p_->erg.gleich++;
                    }
                }
                for (auto& kv : hier) {
                    if (fern.find(kv.first) == fern.end())
                        p_->zuSchicken.push_back(kv.first);       // fehlt dort
                }
                p_->naechsterSchritt(p_->aus);
                sendeAlles(p_->s, p_->aus);
                break;
            }
            case 'F': {                     // Datei von der Gegenseite
                auto nul = inhalt.find('\0');
                if (nul != std::string::npos && !p_->zuHolen.empty()) {
                    std::string rel = inhalt.substr(0, nul);
                    std::string daten = inhalt.substr(nul + 1);
                    std::string ziel = p_->syncDir + "/" + rel;
                    // NUR die als Konflikt erkannten Dateien bekommen
                    // eine Kopie.
                    // [Vorher stand hier der globale Zaehler -- sobald
                    //  IRGENDEINE Datei ein Konflikt war, legte jede
                    //  weitere eine .konflikt-Kopie an. Im Test bekam
                    //  neuer.txt eine, obwohl die Gegenseite dort
                    //  eindeutig neuer war.]
                    std::error_code ec;
                    bool konflikt = p_->konfliktPfade.count(rel) > 0
                                    && fs::exists(ziel, ec);
                    if (konflikt) {
                        std::string sicher = ziel + ".konflikt";
                        fs::rename(ziel, sicher, ec);
                        p_->erg.meldungen.push_back(
                            "Konflikt: alte Fassung als " + rel + ".konflikt");
                    }
                    if (!daten.empty() || fs::exists(ziel, ec) || true) {
                        if (dateiSchreiben(ziel, daten, 0)) {
                            p_->erg.geholt++;
                        } else {
                            p_->erg.meldungen.push_back("nicht schreibbar: " + rel);
                        }
                    }
                    p_->zuHolen.erase(p_->zuHolen.begin());
                }
                p_->naechsterSchritt(p_->aus);
                sendeAlles(p_->s, p_->aus);
                break;
            }
            case 'Z': {                     // Gegenseite hat empfangen
                if (!inhalt.empty()) p_->erg.geschickt++;
                else p_->erg.meldungen.push_back("Gegenseite lehnte eine Datei ab");
                p_->schickIndex++;
                p_->naechsterSchritt(p_->aus);
                sendeAlles(p_->s, p_->aus);
                break;
            }
            default: break;
        }
    }

    if (zu) {
        bool warBusy = p_->busy;
        XbmCmdStatus vorher = p_->status;
        Disconnect();
        // Eine erklaerte Ablehnung ueberlebt den Abbruch.
        if (vorher == XbmCmdStatus::FehlerGeheimnis)
            p_->status = XbmCmdStatus::FehlerGeheimnis;
        if (warBusy && p_->onEnde) p_->onEnde(-1);
    }
}
