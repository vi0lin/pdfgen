#pragma once
// ---------------------------------------------------------------------------
// xbm_netnode.h -- der fehlende Baustein zwischen Bibliothek und Oberflaeche.
//
// WARUM ES DAS GIBT
// xbm_net_udp (Entdeckung) und xbm_cmdchan (Befehle, Dateiabgleich) sind
// beide fertig -- aber niemand ruft sie auf. Genau deshalb ist bei dir
// nichts passiert: es fehlte die Stelle, die sie startet, offen haelt
// und miteinander verbindet. Das ist dieser Knoten.
//
// EIN AUFRUF ZUM STARTEN, EINER JE BILDBILD:
//     XbmNetNode netz;
//     netz.Start(cfg);                 // einmal
//     ...
//     netz.Poll();                     // jeden Frame -- blockiert nie
//
// Danach:
//     netz.Peers()                     wer ist da
//     netz.RunOn(id, "ls -al", ...)    Befehl dort ausfuehren
//     netz.SyncTo(id) / SyncFrom(id)   Dateien abgleichen
//     netz.SetAutoSync(true)           Aenderungen von selbst verteilen
//
// WAS DER KNOTEN BEWUSST NICHT TUT
// Er kennt keine Oberflaeche. ImGui-Code gehoert nach ui_networking.h --
// so laesst sich alles hier ohne Fenster testen, und genau das habe ich
// getan.
// ---------------------------------------------------------------------------
#include "xbm_cmdchan.h"
#include "xbm_net_udp.h"

#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

struct XbmNetConfig {
    std::string name       = "Client";   // Anzeigename
    std::string geheimnis  = "";         // PFLICHT -- ohne startet nichts
    std::string syncDir    = "";         // Ordner, der abgeglichen wird
    std::string scriptsDir = "";         // .cmd-Scripts, die andere hier starten duerfen
    std::uint16_t cmdPort  = 47318;      // Befehlskanal (TCP)
    std::uint16_t discPort = 47317;      // Entdeckung (UDP-Broadcast)
    int  autoSyncMs        = 3000;       // wie oft nach Aenderungen sehen
};

// Ein bekannter Gegenpart.
struct XbmNetPeer {
    std::string  id;                  // stabile Kennung
    std::string  name;
    std::string  ip;
    std::uint16_t cmdPort = 0;
    std::int64_t lastSeenMs = 0;
    bool ausgewaehlt = false;         // Haken in der Oberflaeche
    XbmCmdStatus status = XbmCmdStatus::Getrennt;
};

// Wanduhr in Millisekunden -- dieselbe Uhr, mit der die Jobs ihre Start-
// und Endezeiten stempeln (fuer die Laufzeitanzeige in der Oberflaeche).
std::int64_t XbmNetNode_JetztMs();

class XbmNetNode {
public:
    XbmNetNode();
    ~XbmNetNode();
    XbmNetNode(const XbmNetNode&) = delete;
    XbmNetNode& operator=(const XbmNetNode&) = delete;

    bool Start(const XbmNetConfig& cfg);
    void Stop();
    bool Running() const;
    const char* LastError() const;

    // Einmal je Frame. Entdeckung, Befehlsserver, offene Verbindungen,
    // automatischer Abgleich -- alles nicht blockierend.
    void Poll();

    std::vector<XbmNetPeer> Peers() const;
    void SetAusgewaehlt(const std::string& id, bool an);
    std::string SelfId() const;

    // --- Befehle ---
    // Fuehrt den Befehl auf dem Gegenpart aus. Die Ausgabe kommt
    // zeilenweise, WAEHREND er laeuft.
    bool RunOn(const std::string& peerId, const std::string& befehl);
    // Auf allen angehakten.
    int  RunOnSelected(const std::string& befehl);
    bool BusyOn(const std::string& peerId) const;

    // ------------------------------------------------------------------
    // JOBS: MEHRERE BEFEHLE/SCRIPTS GLEICHZEITIG, JEDER MIT EIGENEM STATUS.
    // [Vorher gab es je Geraet EINE Verbindung und EINE Warteschlange --
    //  ein zweiter Befehl wartete, bis der erste fertig war, und "was
    //  laeuft gerade" war nur im Protokoll zu erahnen. Jetzt bekommt
    //  jeder Job seine eigene Verbindung; der Server verarbeitet beliebig
    //  viele Sitzungen. Die Jobliste ist der Ort, an dem man sieht, was
    //  wo laeuft, wie lange, und mit welchem Ergebnis.]
    enum class JobStatus { Wartet, Verbindet, Laeuft, Fertig, Fehler, Abgebrochen };
    struct Job {
        int          id = 0;
        std::string  peerId, peerName;
        std::string  anzeige;            // Scriptname oder Befehl
        bool         istScript = false;
        JobStatus    status = JobStatus::Wartet;
        int          code = 0;
        std::int64_t startMs = 0, endeMs = 0;
        std::vector<std::string> ausgabe;   // letzte Zeilen (begrenzt)
    };
    int  JobStarten(const std::string& peerId, const std::string& befehlOderScript, bool istScript);
    int  ScriptAufAngehakten(const std::string& scriptName);   // je Geraet ein Job
    std::vector<Job> Jobs() const;
    bool JobAbbrechen(int jobId);
    void JobsAufraeumen();               // fertige aus der Liste nehmen
    static const char* JobStatusText(JobStatus s);

    // SCRIPTS EINES GERAETS (Namen, die es freigibt). Wird beim Verbinden
    // abgefragt und periodisch aufgefrischt; leer = nichts freigegeben
    // oder noch nicht abgefragt.
    std::vector<std::string> ScriptsVon(const std::string& peerId) const;
    void ScriptsAuffrischen(const std::string& peerId);

    // FREIGABEN DIESES GERAETS (siehe XbmCmdServer).
    void SetBefehleErlauben(bool an);
    void SetScriptsFreigeben(bool an);
    bool BefehleErlauben() const;
    bool ScriptsFreigeben() const;

    // Kennung des Eintrags "dieses Geraet" in der Peer-Liste. [Lokale
    //  Befehle laufen ueber dieselbe Mechanik -- eine Verbindung zum
    //  eigenen Server ueber 127.0.0.1. Damit gibt es fuer "lokal" keinen
    //  Sonderweg, und alles (Status, Abbruch, Scripts) verhaelt sich gleich.]
    static const char* SelbstId() { return "selbst"; }

    // BEFEHL AUF EINEM GERAET / ALLEN ANGEHAKTEN ABBRECHEN.
    // [Ein Befehl kann endlos laufen (haengender Bau, eine Schleife). Der
    //  Kanal beendet die ganze Prozessgruppe, der Rueckgabewert kommt
    //  danach regulaer: 143 = SIGTERM, 137 = SIGKILL, 130 = Windows.]
    bool AbortOn(const std::string& peerId);
    int  AbortSelected();

    // LAUFZUSTAND JE GERAET fuer die Anzeige.
    struct BefehlStatus {
        bool   laeuft = false;
        double laufzeitSek = 0.0;    // seit Start des aktuellen Befehls
        int    letzterCode = 0;      // Rueckgabewert des zuletzt beendeten
        bool   hatteBefehl = false;  // ueberhaupt schon einer gelaufen?
        std::string befehl;          // laufender bzw. letzter Befehl
    };
    BefehlStatus StatusOn(const std::string& peerId) const;

    // --- Dateien ---
    // NACHRICHTEN (Rahmen J/j) -- fuer Schichten oberhalb von netlink, z.B.
    // den Scheduler-Abgleich: NachrichtAn() schickt einen Text an einen Peer
    // (Verbindung wird bei Bedarf aufgebaut; Antwort per Rueckruf), der
    // Haken beantwortet eingehende Nachrichten (text, Adresse der Gegenseite).
    bool NachrichtAn(const std::string& peerId, const std::string& text,
                     std::function<void(const std::string& antwort)> onAntwort);
    void SetNachrichtenHaken(std::function<std::string(const std::string& text, const std::string& von)> haken);
    bool PeerBereit(const std::string& peerId) const;   // Verbindung steht und ist angemeldet
    bool SyncTo(const std::string& peerId);     // meine Dateien hinueber
    bool SyncFrom(const std::string& peerId);   // seine Dateien herueber
    int  SyncSelected(bool hin);
    void SetAutoSync(bool an);
    bool AutoSync() const;
    // NICHT bis zum naechsten automatischen Blick warten (bis zu
    // autoSyncMs, Vorgabe 3 s) -- sofort beim naechsten Poll()
    // nachsehen. Fuer "so schnell wie moeglich": ein Aufrufer, der
    // gerade selbst etwas geaendert hat, muss nicht auf den naechsten
    // Zeitschritt warten.
    void AbgleichJetzt();

    // --- Rueckmeldungen fuer die Oberflaeche ---
    struct Zeile { std::string peer, text; bool fehler = false; };
    // Ringpuffer der letzten Meldungen -- die Oberflaeche liest ihn nur.
    const std::deque<Zeile>& Protokoll() const;
    void ProtokollLeeren();

    std::function<void(const XbmNetPeer&)> onJoin;
    std::function<void(const XbmNetPeer&)> onLeave;

    struct Stats {
        std::size_t peers = 0, verbunden = 0;
        std::uint64_t befehle = 0, syncLaeufe = 0;
        std::uint64_t dateienHin = 0, dateienHer = 0;
    };
    Stats GetStats() const;

private:
    struct Impl;
    std::unique_ptr<Impl> p_;
};
