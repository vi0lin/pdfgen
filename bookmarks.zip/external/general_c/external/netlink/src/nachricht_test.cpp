// Nachrichtenrahmen J/j ueber eine ECHTE TCP-Verbindung -- mit dem
// Scheduler-Abgleich (timeline::verarbeiten) als eingehaengtem Haken.
#include "xbm_cmdchan.h"
#include "sync.h"
#include <chrono>
#include <cstdio>
#include <thread>
using namespace timeline;
static int fehler = 0;
#define PRUEF(bed, text) do { bool ok = (bed); printf("  %s %s\n", ok ? "OK " : "FEHLER", text); if (!ok) fehler++; } while (0)

int main() {
    Speicher server; server.geraet = "server";
    Speicher handy;  handy.geraet = "handy";
    std::map<std::string, Partner> serverPartner;
    Partner handyZumServer; handyZumServer.geraet = "server";

    Event& e = handy.anlegen(1000); e.titel = "vom Handy"; e.start = 1700000000;
    Event& k = handy.anlegen(1001); k.art = Art::Aktion; k.versatz = 600; k.titel = "Aktion"; handy.zuordnen(e.id, k.id, 1001);

    XbmCmdServer srv;
    srv.onNachricht = [&](const std::string& text, const std::string& /*adresse*/) -> std::string {
        json ein = json::parse(text, nullptr, false); if (ein.is_discarded()) return "";
        const std::string von = ein.value("von", "");          // Geraetename aus dem Paket
        Partner& p = serverPartner[von]; p.geraet = von;
        json aus = verarbeiten(server, ein, p);
        return aus.is_null() ? std::string() : aus.dump();
    };
    PRUEF(srv.Start(0, "geheim"), "Server startet auf freiem Port");
    const std::uint16_t port = srv.Port();

    XbmCmdClient cl;
    PRUEF(cl.Connect("127.0.0.1", port, "geheim"), "Client verbindet");
    auto pump = [&](int ms) { for (int i = 0; i < ms / 5; ++i) { srv.Poll(); cl.Poll(); std::this_thread::sleep_for(std::chrono::milliseconds(5)); } };
    pump(300);
    PRUEF(cl.GetStatus() == XbmCmdStatus::Bereit, "Anmeldung abgeschlossen");

    // Runde 1: Handy schickt sein Delta, Server antwortet mit Bestaetigung
    std::string antwort1;
    PRUEF(cl.Nachricht(delta(handy, handyZumServer).dump(), [&](const std::string& a) { antwort1 = a; }), "Nachricht (Delta) gesendet");
    pump(300);
    json b1 = json::parse(antwort1, nullptr, false);
    PRUEF(b1.is_object() && b1.value("typ", "") == "bestaetigung", "Server antwortet mit Bestaetigung");
    bestaetigungAnwenden(b1, handyZumServer);
    PRUEF(server.events.size() == 2 && server.finde(e.id)->titel.wert == "vom Handy" && server.finde(k.id)->eltern == e.id, "Server hat Event samt Kind -- ueber TCP");
    PRUEF(ausstehend(handy, handyZumServer) == 0, "Handy schuldet dem Server nichts mehr");

    // Runde 2: Server aendert, Handy fragt an und bekommt das Delta
    Event* se = server.finde(e.id); se->notizen = "vom Server"; server.geaendert(*se, 2000);
    std::string antwort2;
    cl.Nachricht(anfrage(handy, handyZumServer).dump(), [&](const std::string& a) { antwort2 = a; });
    pump(300);
    json d2 = json::parse(antwort2, nullptr, false);
    PRUEF(d2.is_object() && d2.value("typ", "") == "delta" && d2["events"].size() == 1, "Server liefert Delta mit genau der einen Aenderung");
    deltaAnwenden(handy, d2, handyZumServer);
    PRUEF(handy.finde(e.id)->notizen.wert == "vom Server", "Aenderung des Servers auf dem Handy");

    cl.Disconnect(); srv.Stop();
    printf("\n%s\n", fehler ? "### FEHLER ###" : "ALLE PRUEFUNGEN BESTANDEN");
    return fehler;
}
