#include "xbm_cmdchan.h"
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <thread>
namespace fs = std::filesystem;

static void schreib(const std::string& p, const std::string& t) {
    fs::create_directories(fs::path(p).parent_path());
    std::ofstream f(p, std::ios::binary); f << t;
}
static std::string lies(const std::string& p) {
    std::ifstream f(p, std::ios::binary);
    return std::string((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
}

int main() {
    int fehler = 0;
    fs::remove_all("/tmp/synA"); fs::remove_all("/tmp/synB");

    // A hat zwei Dateien, B eine andere. Eine gibt es beidseitig gleich.
    schreib("/tmp/synA/nur-a.txt",          "ich komme von A\n");
    schreib("/tmp/synA/scripts/build.sh",   "#!/bin/sh\necho A\n");
    schreib("/tmp/synA/beide.txt",          "identisch\n");
    schreib("/tmp/synB/nur-b.txt",          "ich komme von B\n");
    schreib("/tmp/synB/beide.txt",          "identisch\n");

    XbmCmdServer srv;                      // B ist der Server
    srv.onLog = [](const std::string& z){ std::printf("  [B] %s\n", z.c_str()); };
    srv.Start(0, "geheim");
    srv.SetSyncDir("/tmp/synB");

    XbmCmdClient cli;                      // A ist der Client
    cli.Connect("127.0.0.1", srv.Port(), "geheim");
    for (int i = 0; i < 200 && cli.GetStatus() != XbmCmdStatus::Bereit; i++) {
        srv.Poll(); cli.Poll();
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
    if (cli.GetStatus() != XbmCmdStatus::Bereit) { std::printf("nicht bereit\n"); return 1; }

    bool fertig = false; XbmSyncErgebnis erg;
    auto t0 = std::chrono::steady_clock::now();
    cli.StartSync("/tmp/synA", [&](const XbmSyncErgebnis& e){ erg = e; fertig = true; });
    for (int i = 0; i < 3000 && !fertig; i++) {
        srv.Poll(); cli.Poll();
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                  std::chrono::steady_clock::now() - t0).count();
    if (!fertig) { std::printf("  ### Abgleich nicht fertig ###\n"); return 1; }

    std::printf("  geholt=%d geschickt=%d gleich=%d konflikte=%d  (%lld ms)\n",
                erg.geholt, erg.geschickt, erg.gleich, erg.konflikte, (long long)ms);
    for (auto& m : erg.meldungen) std::printf("    %s\n", m.c_str());

    struct { const char* p; const char* inhalt; } pruef[] = {
        {"/tmp/synA/nur-b.txt",        "ich komme von B\n"},
        {"/tmp/synB/nur-a.txt",        "ich komme von A\n"},
        {"/tmp/synB/scripts/build.sh", "#!/bin/sh\necho A\n"},
    };
    for (auto& p : pruef) {
        bool da = fs::exists(p.p);
        bool ok = da && lies(p.p) == p.inhalt;
        std::printf("  %-30s %s\n", p.p, ok ? "da, Inhalt stimmt" : "### FEHLT/FALSCH ###");
        if (!ok) fehler++;
    }
    std::printf(fehler ? "  ### %d FEHLER ###\n" : "  alles bestanden\n", fehler);
    return fehler ? 1 : 0;
}
