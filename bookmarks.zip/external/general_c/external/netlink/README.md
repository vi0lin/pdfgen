# netlink -- Netzwerkkern

Ausgelagert aus `bookmarks`, ohne UI und ohne andere Projekte:

- `xbm_net_udp`  -- Entdeckung im LAN per UDP-Broadcast, lokale Adressen
- `xbm_cmdchan`  -- TCP-Befehlskanal: Anmeldung mit Geheimnis, Befehle und
                    Scripts ausfuehren/abbrechen, Dateiabgleich (Index, Datei),
                    Freigaben je Geraet, und der allgemeine
                    **Nachrichtenrahmen J/j** (JSON-Text hin, Antwort zurueck)
- `xbm_netnode`  -- Peer-Verwaltung, Jobs, Selbst-Peer

Die Dateien heissen weiterhin `xbm_*`, damit `bookmarks` sie unveraendert
einbindet (`#include "xbm_netnode.h"`). Umbenennen ist ein eigener Schritt.

## Nachrichtenrahmen -- so haengt sich der Scheduler-Abgleich ein

    XbmCmdServer srv;
    srv.onNachricht = [&](const std::string& text, const std::string& adresse) {
        json ein = json::parse(text);                       // "von" = Geraetename
        Partner& p = partner[ein["von"]];
        return timeline::verarbeiten(speicher, ein, p).dump();
    };
    // Client:
    cl.Nachricht(timeline::delta(speicher, partner).dump(), [&](const std::string& antwort){ ... });

netlink kennt timeline nicht; der Haken ist der einzige Beruehrungspunkt.
`nachricht_test.cpp` prueft genau das ueber eine echte TCP-Verbindung
(wird gebaut, wenn `../timeline` daneben liegt).

## Bauen

    cmake -B build -S . && cmake --build build && ctest --test-dir build
    # in bookmarks: add_subdirectory(external/netlink)
    #               target_link_libraries(x_bookmark_manager PRIVATE netlink::netlink)

