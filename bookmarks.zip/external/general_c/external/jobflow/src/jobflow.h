#pragma once
// ===========================================================================
// jobflow -- QUEUES UND JOBS (die "Computing Power Unit"), netz- und UI-frei.
//
// BEGRIFFE
//   Queue    ein Baum von Jobs. Wurzeljobs laufen in Listenreihenfolge;
//            Kinder laufen, wenn ihr Elternteil fertig ist (nach rechts
//            gezogen = eingerueckt = Kind). Eine Gruppe ist ein Job ohne
//            Aktion, der nur Kinder buendelt (einklappbar, benennbar).
//   Ablauf   je Job, bezogen auf seine Geschwister:
//              Parallel    -- startet sofort, wenn das Elternteil fertig ist
//              WartenAuf   -- wartet auf bestimmte Geschwister (wartetAuf)
//              Prozedural  -- wartet auf den vorigen Geschwister-Job
//   Trigger  Jobs, die auf das Ergebnis eines anderen reagieren:
//            onSuccess / onFailure / onAbort (rechtsbuendig unter dem Job).
//   Eingaben ein Eingang kann fest sein ("wert") oder aus einem Ausgang eines
//            anderen Jobs kommen ("vonJob"/"ausgang") -- wie Verbindungen im
//            Node-Editor. Ausgaben liegen nach dem Lauf im Job.
//   Ziel     wo der Job laufen soll (lokal, bestimmte Hosts, irgendein
//            Online-Host, alle) -- der Ausfuehrer entscheidet die Maschine.
//   Status   Inaktiv, Wartet, Bereit, Laeuft, Pausiert, Fertig, Fehler,
//            Abgebrochen -- je Job; die Queue fasst zusammen.
//
// AUSFUEHRER: die Queue selbst startet keine Prozesse. Sie fragt einen
// Ausfuehrer (Schnittstelle unten): "starte Job X mit diesen Eingaben auf
// Ziel Y" und bekommt spaeter "X ist fertig/gescheitert mit Ausgaben".
// Lokal ist das actionkit; ueber netlink wird daraus ein Job auf einem
// anderen Host. So bleibt jobflow testbar und die Maschinenwahl austauschbar.
//
// TAKT: schritt(jetzt) prueft Abhaengigkeiten, startet Startbares und
// verarbeitet Ergebnisse. Der Aufrufer ruft es im Frame oder aus einem
// Timer -- keine eigenen Threads hier.
// ===========================================================================
#include <nlohmann/json.hpp>
#include <algorithm>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace jobflow {
using json = nlohmann::json;
using Id   = std::uint64_t;
using Zeit = std::int64_t;

enum class Ablauf : std::uint8_t { Parallel, WartenAuf, Prozedural };
enum class Zielwahl : std::uint8_t { Lokal, Bestimmte, IrgendeinOnline, Alle };
enum class Status : std::uint8_t { Inaktiv, Wartet, Bereit, Laeuft, Pausiert, Fertig, Fehler, Abgebrochen };
enum class Trigger : std::uint8_t { Keiner, OnSuccess, OnFailure, OnAbort };

inline const char* statusText(Status s) {
    static const char* t[] = { "inaktiv","wartet","bereit","laeuft","pausiert","fertig","fehler","abgebrochen" };
    return t[(int)s];
}

struct Eingang {
    std::string name;
    json        wert;                      // fester Wert ...
    Id          vonJob = 0;                // ... oder aus dem Ausgang eines Jobs
    std::string ausgang;
};

struct Ziel {
    Zielwahl wahl = Zielwahl::Lokal;
    std::vector<std::string> hosts;
    std::string bevorzugt;
};

struct Job {
    Id          id = 0;
    Id          eltern = 0;                // Kind-von (Einrueckung); 0 = Wurzel
    std::string name;
    std::string aktion;                    // Name der actionkit-Aktion; leer = Gruppe
    std::vector<Eingang> eingaenge;
    json        ausgaben = json::object();
    Ablauf      ablauf = Ablauf::Prozedural;
    std::vector<Id> wartetAuf;             // bei WartenAuf: diese Geschwister
    Trigger     trigger = Trigger::Keiner; // wenn != Keiner: laeuft nur bei diesem Ergebnis des Elternteils
    Ziel        ziel;
    bool        aktiv = true;              // inaktiv = wird uebersprungen (Kinder auch)
    bool        eingeklappt = false;       // nur Anzeige
    int         wiederholungen = 1;        // Schleife: so oft laufen (>=1); 0 = bis Abbruch
    Status      status = Status::Inaktiv;
    std::string fehler;
    std::string laeuftAuf;                 // Host, den der Ausfuehrer gewaehlt hat
    Zeit        gestartet = 0, beendet = 0;
    int         durchlauf = 0;             // bereits abgeschlossene Wiederholungen
    int         exitcode = 0;
};

// ---- Ausfuehrer-Schnittstelle --------------------------------------------------
struct Ausfuehrer {
    // Job starten; liefert false, wenn gerade kein Ziel verfuegbar (Job bleibt
    // Bereit und wird beim naechsten Takt erneut angeboten). Die Fertigmeldung
    // kommt spaeter ueber Queue::fertig(). <laeuftAuf> wird gesetzt.
    std::function<bool(Job& job, const json& eingaenge, std::string& laeuftAuf)> starten;
    std::function<void(Job& job)> abbrechen;       // laufenden Job stoppen
    std::function<void(Job& job)> pausieren;       // optional
    std::function<void(Job& job)> fortsetzen;      // optional
};

// ---- Queue --------------------------------------------------------------------
struct Queue {
    Id          id = 0;
    std::string name;
    // deque, NICHT vector: anlegen() gibt Job& zurueck, und die muss auch
    // nach weiteren anlegen()-Aufrufen gueltig bleiben (vector verschiebt
    // beim Wachsen alle Elemente -- die Referenz zeigte ins Leere).
    std::deque<Job> jobs;                  // Reihenfolge = Anzeigereihenfolge
    Id          naechsteId = 1;
    bool        pausiert = false;
    bool        istVorlage = false;
    Ausfuehrer* ausfuehrer = nullptr;
    std::function<void(const Job&)> onStatus;      // Statuswechsel (fuer Anzeige/Log)

    Job* finde(Id id) { for (Job& j : jobs) if (j.id == id) return &j; return nullptr; }
    const Job* finde(Id id) const { for (const Job& j : jobs) if (j.id == id) return &j; return nullptr; }
    std::vector<Job*> kinder(Id eltern) { std::vector<Job*> v; for (Job& j : jobs) if (j.eltern == eltern) v.push_back(&j); return v; }
    std::vector<const Job*> kinder(Id eltern) const { std::vector<const Job*> v; for (const Job& j : jobs) if (j.eltern == eltern) v.push_back(&j); return v; }

    Job& anlegen(const std::string& name, const std::string& aktion = "", Id eltern = 0) {
        Job j; j.id = naechsteId++; j.name = name; j.aktion = aktion; j.eltern = eltern; jobs.push_back(j); return jobs.back();
    }
    Job& gruppe(const std::string& name, Id eltern = 0) { return anlegen(name, "", eltern); }
    // Trigger-Job: laeuft nur bei diesem Ergebnis von <auf>
    Job& triggerJob(Id auf, Trigger t, const std::string& name, const std::string& aktion) {
        Job& j = anlegen(name, aktion, auf); j.trigger = t; return j;
    }
    // Verschieben: nach rechts (unter den Vorgaenger), nach links (eine Ebene hoch),
    // oder unter einen bestimmten Job (Drag & Drop). Zyklen abgewiesen.
    bool istVorfahr(Id moeglich, Id von) const { for (int i = 0; von && i < 64; ++i) { if (von == moeglich) return true; const Job* j = finde(von); von = j ? j->eltern : 0; } return false; }
    bool einhaengen(Id job, Id neuesEltern) {
        Job* j = finde(job); if (!j || job == neuesEltern || (neuesEltern && (!finde(neuesEltern) || istVorfahr(job, neuesEltern)))) return false;
        j->eltern = neuesEltern; return true;
    }
    bool nachRechts(Id job) {   // unter den vorigen Geschwister-Job
        Job* j = finde(job); if (!j) return false;
        Job* vorher = nullptr; for (Job& x : jobs) { if (x.id == job) break; if (x.eltern == j->eltern) vorher = &x; }
        return vorher ? einhaengen(job, vorher->id) : false;
    }
    bool nachLinks(Id job) { Job* j = finde(job); if (!j || !j->eltern) return false; const Job* p = finde(j->eltern); return einhaengen(job, p ? p->eltern : 0); }

    // ---- Laufzeit ----
    void setze(Job& j, Status s) { if (j.status != s) { j.status = s; if (onStatus) onStatus(j); } }
    void zuruecksetzen() { for (Job& j : jobs) { j.status = Status::Inaktiv; j.fehler.clear(); j.ausgaben = json::object(); j.durchlauf = 0; j.gestartet = j.beendet = 0; } }
    void starten(Zeit jetzt) { zuruecksetzen(); pausiert = false; for (Job& j : jobs) if (j.aktiv) setze(j, Status::Wartet); (void)jetzt; }
    void pausierenAlle() { pausiert = true; for (Job& j : jobs) if (j.status == Status::Laeuft) { if (ausfuehrer && ausfuehrer->pausieren) ausfuehrer->pausieren(j); setze(j, Status::Pausiert); } }
    void fortsetzenAlle() { pausiert = false; for (Job& j : jobs) if (j.status == Status::Pausiert) { if (ausfuehrer && ausfuehrer->fortsetzen) ausfuehrer->fortsetzen(j); setze(j, Status::Laeuft); } }
    void abbrechenAlle(Zeit jetzt) {
        for (Job& j : jobs) {
            if (j.status == Status::Laeuft || j.status == Status::Pausiert) { if (ausfuehrer && ausfuehrer->abbrechen) ausfuehrer->abbrechen(j); j.beendet = jetzt; setze(j, Status::Abgebrochen); }
            else if (j.status == Status::Wartet || j.status == Status::Bereit) setze(j, Status::Abgebrochen);
        }
    }
    bool istFertig(const Job& j) const { return j.status == Status::Fertig || j.status == Status::Fehler || j.status == Status::Abgebrochen; }
    bool laeuftNoch() const { for (const Job& j : jobs) if (j.aktiv && !istFertig(j) && j.status != Status::Inaktiv) return true; return false; }
    Status gesamt() const {
        bool laeuft = false, fehler = false, abgebrochen = false, wartet = false, pausiertJ = false, irgendwas = false;
        for (const Job& j : jobs) { if (!j.aktiv) continue; irgendwas = true;
            switch (j.status) { case Status::Laeuft: case Status::Bereit: laeuft = true; break; case Status::Wartet: wartet = true; break;
                case Status::Pausiert: pausiertJ = true; break; case Status::Fehler: fehler = true; break; case Status::Abgebrochen: abgebrochen = true; break; default: break; } }
        if (!irgendwas) return Status::Inaktiv;
        if (pausiertJ || pausiert) return Status::Pausiert;
        if (laeuft) return Status::Laeuft;
        if (wartet) return Status::Wartet;
        if (abgebrochen) return Status::Abgebrochen;
        if (fehler) return Status::Fehler;
        return Status::Fertig;
    }

    // Eingaenge aufloesen: feste Werte + Ausgaenge anderer Jobs.
    json eingaengeAufloesen(const Job& j, std::string& fehler) const {
        json e = json::object();
        for (const Eingang& x : j.eingaenge) {
            if (x.vonJob) { const Job* q = finde(x.vonJob);
                if (!q) { fehler = "Eingang '" + x.name + "': Job " + std::to_string(x.vonJob) + " fehlt"; return json(); }
                if (!q->ausgaben.contains(x.ausgang)) { fehler = "Eingang '" + x.name + "': Ausgang '" + x.ausgang + "' von '" + q->name + "' nicht vorhanden"; return json(); }
                e[x.name] = q->ausgaben[x.ausgang];
            } else e[x.name] = x.wert;
        }
        return e;
    }
    // Ist der Job jetzt startbar?
    bool startbar(const Job& j) const {
        if (!j.aktiv || j.status != Status::Wartet || pausiert) return false;
        // Elternteil: fertig (bei Trigger: mit passendem Ergebnis); Gruppe: startet ihre Kinder sofort
        if (j.eltern) {
            const Job* p = finde(j.eltern); if (!p) return false;
            if (p->aktion.empty()) { if (p->status == Status::Wartet || p->status == Status::Inaktiv) return false; }   // Gruppe erst "eroeffnet"
            else {
                if (!istFertig(*p)) return false;
                if (j.trigger == Trigger::OnSuccess && p->status != Status::Fertig) return false;
                if (j.trigger == Trigger::OnFailure && p->status != Status::Fehler) return false;
                if (j.trigger == Trigger::OnAbort   && p->status != Status::Abgebrochen) return false;
                if (j.trigger == Trigger::Keiner    && p->status != Status::Fertig) return false;   // normale Kinder nur nach Erfolg
            }
        }
        // Geschwister: Ablaufart. TRIGGER-Jobs sind davon ausgenommen: sie
        // reagieren nur auf das Ergebnis des Elternteils, nicht auf die
        // Reihenfolge ihrer Geschwister (sonst wartete "onFailure" auf ein
        // normales Kind, das nach einem Fehler nie laeuft).
        std::vector<const Job*> g = kinder(j.eltern);
        if (j.trigger != Trigger::Keiner) { /* keine Geschwisterregel */ }
        else if (j.ablauf == Ablauf::Prozedural) {
            const Job* vorher = nullptr; for (const Job* x : g) { if (x->id == j.id) break; if (x->aktiv && x->trigger == Trigger::Keiner) vorher = x; }
            if (vorher && !istFertig(*vorher)) return false;
            if (vorher && vorher->status != Status::Fertig) return false;      // Vorgaenger gescheitert -> nicht weiter
        } else if (j.ablauf == Ablauf::WartenAuf) {
            for (Id w : j.wartetAuf) { const Job* x = finde(w); if (x && x->aktiv && x->status != Status::Fertig) return false; }
        }
        // Eingaenge aus anderen Jobs muessen vorliegen
        for (const Eingang& x : j.eingaenge) if (x.vonJob) { const Job* q = finde(x.vonJob); if (!q || q->status != Status::Fertig) return false; }
        return true;
    }

    // EIN TAKT: Startbares starten; Gruppen "eroeffnen" und schliessen.
    int schritt(Zeit jetzt) {
        int gestartet = 0;
        // Gruppen: eroeffnen, wenn startbar; fertig, wenn alle Kinder fertig
        for (Job& j : jobs) {
            if (!j.aktiv || !j.aktion.empty()) continue;
            if (j.status == Status::Wartet && startbar(j)) { j.gestartet = jetzt; setze(j, Status::Laeuft); }
            if (j.status == Status::Laeuft) {
                bool alleFertig = true, fehler = false, abgebrochen = false;
                for (const Job* k : kinder(j.id)) {
                    if (!k->aktiv || k->trigger != Trigger::Keiner) continue;
                    if (!istFertig(*k)) alleFertig = false;
                    if (k->status == Status::Fehler) fehler = true;
                    if (k->status == Status::Abgebrochen) abgebrochen = true;
                }
                if (alleFertig) { j.beendet = jetzt; setze(j, abgebrochen ? Status::Abgebrochen : fehler ? Status::Fehler : Status::Fertig); }
            }
        }
        // Jobs mit Aktion
        for (Job& j : jobs) {
            if (j.aktion.empty() || !startbar(j)) continue;
            std::string f; json e = eingaengeAufloesen(j, f);
            if (!f.empty()) { j.fehler = f; j.beendet = jetzt; setze(j, Status::Fehler); continue; }
            setze(j, Status::Bereit);
            std::string host;
            if (ausfuehrer && ausfuehrer->starten && ausfuehrer->starten(j, e, host)) { j.laeuftAuf = host; j.gestartet = jetzt; setze(j, Status::Laeuft); ++gestartet; }
            else setze(j, Status::Wartet);            // kein Ziel frei: naechster Takt
        }
        // Verwaiste Wartende: Elternteil endgueltig nicht passend -> ueberspringen
        for (Job& j : jobs) {
            if (!j.aktiv || j.status != Status::Wartet || !j.eltern) continue;
            const Job* p = finde(j.eltern); if (!p || !istFertig(*p) || p->aktion.empty()) continue;
            bool passt = (j.trigger == Trigger::OnSuccess && p->status == Status::Fertig) || (j.trigger == Trigger::OnFailure && p->status == Status::Fehler)
                      || (j.trigger == Trigger::OnAbort && p->status == Status::Abgebrochen) || (j.trigger == Trigger::Keiner && p->status == Status::Fertig);
            if (!passt) setze(j, Status::Inaktiv);   // dieser Zweig kommt nicht dran
        }
        return gestartet;
    }

    // FERTIGMELDUNG vom Ausfuehrer.
    void fertig(Id jobId, bool ok, const json& ausgaben, const std::string& fehlerText, Zeit jetzt, int exitcode = 0) {
        Job* j = finde(jobId); if (!j || (j->status != Status::Laeuft && j->status != Status::Pausiert)) return;
        j->ausgaben = ausgaben.is_object() ? ausgaben : json::object(); j->exitcode = exitcode; j->beendet = jetzt;
        if (ok) {
            ++j->durchlauf;
            if (j->wiederholungen == 0 || j->durchlauf < j->wiederholungen) { setze(*j, Status::Wartet); return; }   // Schleife: naechster Durchlauf
            setze(*j, Status::Fertig);
        } else { j->fehler = fehlerText; setze(*j, Status::Fehler); }
    }
    void abgebrochen(Id jobId, Zeit jetzt) { Job* j = finde(jobId); if (!j) return; j->beendet = jetzt; setze(*j, Status::Abgebrochen); }

    // ---- JSON (Speichern, Vorlage) ----
    json zuJson() const {
        json q; q["id"] = id; q["name"] = name; q["naechsteId"] = naechsteId; q["istVorlage"] = istVorlage;
        json arr = json::array();
        for (const Job& j : jobs) {
            json o; o["id"] = j.id; o["eltern"] = j.eltern; o["name"] = j.name; o["aktion"] = j.aktion;
            json ein = json::array(); for (const Eingang& x : j.eingaenge) { json e; e["name"] = x.name; if (x.vonJob) { e["vonJob"] = x.vonJob; e["ausgang"] = x.ausgang; } else e["wert"] = x.wert; ein.push_back(e); }
            o["eingaenge"] = ein; o["ablauf"] = (int)j.ablauf; o["wartetAuf"] = j.wartetAuf; o["trigger"] = (int)j.trigger;
            o["ziel"] = json{{"wahl",(int)j.ziel.wahl},{"hosts",j.ziel.hosts},{"bevorzugt",j.ziel.bevorzugt}};
            o["aktiv"] = j.aktiv; o["eingeklappt"] = j.eingeklappt; o["wiederholungen"] = j.wiederholungen;
            o["status"] = (int)j.status; o["ausgaben"] = j.ausgaben; o["fehler"] = j.fehler; o["laeuftAuf"] = j.laeuftAuf;
            arr.push_back(o);
        }
        q["jobs"] = arr; return q;
    }
    static Queue ausJson(const json& q) {
        Queue s; s.id = q.value("id", (Id)0); s.name = q.value("name", ""); s.naechsteId = q.value("naechsteId", (Id)1); s.istVorlage = q.value("istVorlage", false);
        for (auto& o : q.value("jobs", json::array())) {
            Job j; j.id = o.value("id", (Id)0); j.eltern = o.value("eltern", (Id)0); j.name = o.value("name", ""); j.aktion = o.value("aktion", "");
            for (auto& e : o.value("eingaenge", json::array())) { Eingang x; x.name = e.value("name", ""); x.vonJob = e.value("vonJob", (Id)0); x.ausgang = e.value("ausgang", ""); if (e.contains("wert")) x.wert = e["wert"]; j.eingaenge.push_back(x); }
            j.ablauf = (Ablauf)o.value("ablauf", 2); for (auto& w : o.value("wartetAuf", json::array())) j.wartetAuf.push_back(w.get<Id>()); j.trigger = (Trigger)o.value("trigger", 0);
            if (o.contains("ziel")) { j.ziel.wahl = (Zielwahl)o["ziel"].value("wahl", 0); for (auto& h : o["ziel"].value("hosts", json::array())) j.ziel.hosts.push_back(h.get<std::string>()); j.ziel.bevorzugt = o["ziel"].value("bevorzugt", ""); }
            j.aktiv = o.value("aktiv", true); j.eingeklappt = o.value("eingeklappt", false); j.wiederholungen = o.value("wiederholungen", 1);
            j.status = (Status)o.value("status", 0); j.ausgaben = o.value("ausgaben", json::object()); j.fehler = o.value("fehler", ""); j.laeuftAuf = o.value("laeuftAuf", "");
            s.jobs.push_back(j);
        }
        return s;
    }
    // Aus Vorlage: Kopie ohne Laufzeitzustand
    Queue alsInstanz(Id neueId, const std::string& neuerName) const {
        Queue k = *this; k.id = neueId; k.name = neuerName; k.istVorlage = false; k.zuruecksetzen(); return k;
    }
};

} // namespace jobflow
