#include "jobflow.h"
#include "actionkit.h"
#include <cstdio>
using namespace jobflow;
static int fehler = 0;
#define PRUEF(bed, text) do { bool ok = (bed); printf("  %s %s\n", ok ? "OK " : "FEHLER", text); if (!ok) fehler++; } while (0)

// Simulierter Ausfuehrer: merkt sich gestartete Jobs; der Test beendet sie gezielt.
struct Sim {
    std::vector<Id> laufend; std::vector<std::string> protokoll; int frei = 99;
    Ausfuehrer a;
    Sim() {
        a.starten = [this](Job& j, const json& e, std::string& host) { if ((int)laufend.size() >= frei) return false; laufend.push_back(j.id); host = "sim"; protokoll.push_back("start " + j.name + " " + e.dump()); return true; };
        a.abbrechen = [this](Job& j) { laufend.erase(std::remove(laufend.begin(), laufend.end(), j.id), laufend.end()); protokoll.push_back("abbruch " + j.name); };
    }
    void ende(Queue& q, Id id, bool ok, json aus = json::object(), Zeit t = 10) { laufend.erase(std::remove(laufend.begin(), laufend.end(), id), laufend.end()); q.fertig(id, ok, aus, ok ? "" : "kaputt", t); }
    std::string namen(const Queue& q) { std::string s; for (Id i : laufend) s += q.finde(i)->name + " "; return s; }
};

AKTION(Add, "", EIN(int, a), EIN(int, b), AUS(int, summe)) { HOLE(int, a); HOLE(int, b); SETZE(summe, a + b); return true; }
AKTION(Kaputt, "", EIN(int, x), AUS(int, y)) { HOLE(int, x); (void)x; fehler = "immer kaputt"; return false; }

int main() {
    printf("--- Prozedural / Parallel / WartenAuf ---\n");
    { Queue q; Sim sim; q.ausfuehrer = &sim.a;
      Job& a = q.anlegen("A", "x"); Job& b = q.anlegen("B", "x"); Job& c = q.anlegen("C", "x"); b.ablauf = Ablauf::Parallel; c.ablauf = Ablauf::Parallel;
      Job& d = q.anlegen("D", "x"); d.ablauf = Ablauf::WartenAuf; d.wartetAuf = { b.id, c.id };
      q.starten(0); q.schritt(1);
      PRUEF(sim.namen(q) == "A B C ", ("A (prozedural, erster) + B, C (parallel) starten sofort; D wartet auf B und C: laeuft " + sim.namen(q)).c_str());
      sim.ende(q, b.id, true); q.schritt(2);
      PRUEF(q.finde(d.id)->status == Status::Wartet, "D wartet noch (C laeuft)");
      sim.ende(q, c.id, true); q.schritt(3);
      PRUEF(q.finde(d.id)->status == Status::Laeuft, "D startet, sobald B und C fertig sind -- A darf noch laufen");
      sim.ende(q, a.id, true); sim.ende(q, d.id, true); q.schritt(4);
      PRUEF(q.gesamt() == Status::Fertig && !q.laeuftNoch(), "Queue fertig"); }

    printf("--- Kinder, Trigger, Eingabe-Weitergabe ---\n");
    { Queue q; Sim sim; q.ausfuehrer = &sim.a;
      Job& pdf = q.anlegen("pdf", "x"); Job& mail = q.anlegen("mail", "x", pdf.id);
      mail.eingaenge = { { "anhang", json(), pdf.id, "pdfPfad" }, { "an", "chef@x", 0, "" } };
      Job& warn = q.triggerJob(pdf.id, Trigger::OnFailure, "warnen", "x"); Job& ok = q.triggerJob(pdf.id, Trigger::OnSuccess, "loggen", "x");
      q.starten(0); q.schritt(1);
      PRUEF(sim.namen(q) == "pdf ", "nur pdf laeuft; Kind und Trigger warten");
      sim.ende(q, pdf.id, true, json{{"pdfPfad","/tmp/r.pdf"}}); q.schritt(2);
      PRUEF(sim.namen(q) == "mail loggen " && q.finde(warn.id)->status == Status::Inaktiv,
            ("nach Erfolg: Kind 'mail' und OnSuccess 'loggen' laufen, OnFailure 'warnen' faellt weg: " + sim.namen(q)).c_str());
      PRUEF(sim.protokoll.back().find("\"anhang\":\"/tmp/r.pdf\"") != std::string::npos || sim.protokoll[sim.protokoll.size()-2].find("\"anhang\":\"/tmp/r.pdf\"") != std::string::npos,
            "Ausgang 'pdfPfad' von pdf wurde Eingang 'anhang' von mail (fester Wert 'an' daneben)");
      sim.ende(q, mail.id, true); sim.ende(q, ok.id, true); q.schritt(3);
      PRUEF(q.gesamt() == Status::Fertig, "alles fertig"); (void)warn; }
    { Queue q; Sim sim; q.ausfuehrer = &sim.a;
      Job& pdf = q.anlegen("pdf", "x"); Job& mail = q.anlegen("mail", "x", pdf.id); Job& warn = q.triggerJob(pdf.id, Trigger::OnFailure, "warnen", "x");
      q.starten(0); q.schritt(1); sim.ende(q, pdf.id, false); q.schritt(2);
      PRUEF(sim.namen(q) == "warnen " && q.finde(mail.id)->status == Status::Inaktiv, "nach Fehler: OnFailure laeuft, normales Kind faellt weg");
      sim.ende(q, warn.id, true); q.schritt(3);
      PRUEF(q.gesamt() == Status::Fehler, "Queue meldet Fehler (pdf scheiterte), obwohl der Trigger sauber lief"); }

    printf("--- Gruppen, Schleifen, Einrueckung ---\n");
    { Queue q; Sim sim; q.ausfuehrer = &sim.a;
      Job& g = q.gruppe("Vorbereitung"); Job& g1 = q.anlegen("g1", "x", g.id); Job& g2 = q.anlegen("g2", "x", g.id); Job& n = q.anlegen("danach", "x");
      q.starten(0); q.schritt(1);
      PRUEF(sim.namen(q) == "g1 " && q.finde(g.id)->status == Status::Laeuft, "Gruppe eroeffnet, erstes Kind laeuft, 'danach' wartet auf die Gruppe");
      sim.ende(q, g1.id, true); q.schritt(2); sim.ende(q, g2.id, true); q.schritt(3);
      PRUEF(q.finde(g.id)->status == Status::Fertig && sim.namen(q) == "danach ", "Gruppe fertig, wenn alle Kinder fertig -> 'danach' startet");
      sim.ende(q, n.id, true); q.schritt(4);
      Queue ql; Sim siml; ql.ausfuehrer = &siml.a;
      Job& l = ql.anlegen("schleife", "x"); l.wiederholungen = 3; ql.starten(0); ql.schritt(1);
      int laeufe = 0; for (int i = 0; i < 10 && siml.namen(ql) == "schleife "; ++i) { siml.ende(ql, l.id, true); ++laeufe; ql.schritt(10 + i); }
      PRUEF(laeufe == 3 && ql.finde(l.id)->status == Status::Fertig && ql.finde(l.id)->durchlauf == 3, "Schleife: 3 Durchlaeufe, dann fertig");
      Queue r; Job& a = r.anlegen("A", "x"); Job& b = r.anlegen("B", "x"); Job& c = r.anlegen("C", "x");
      PRUEF(r.nachRechts(b.id) && r.finde(b.id)->eltern == a.id, "'nach rechts ziehen' haengt B unter A");
      PRUEF(r.nachRechts(c.id) && r.finde(c.id)->eltern == a.id && r.nachRechts(c.id) && r.finde(c.id)->eltern == b.id, "C unter A, noch einmal rechts: unter B");
      PRUEF(!r.einhaengen(a.id, c.id), "A unter C (Zyklus) wird abgewiesen");
      PRUEF(r.nachLinks(c.id) && r.finde(c.id)->eltern == a.id, "'nach links' eine Ebene hoch"); }

    printf("--- Pause, Abbruch, Ziel nicht frei ---\n");
    { Queue q; Sim sim; q.ausfuehrer = &sim.a; sim.frei = 1;
      Job& a = q.anlegen("A", "x"); Job& b = q.anlegen("B", "x"); b.ablauf = Ablauf::Parallel;
      q.starten(0); q.schritt(1);
      PRUEF(sim.namen(q) == "A " && q.finde(b.id)->status == Status::Wartet, "nur ein Platz frei: B bleibt wartend, kein Fehler");
      q.pausierenAlle(); q.schritt(2);
      PRUEF(q.gesamt() == Status::Pausiert && q.finde(a.id)->status == Status::Pausiert && sim.namen(q) == "A ", "Pause: nichts Neues startet");
      q.fortsetzenAlle(); sim.ende(q, a.id, true); q.schritt(3);
      PRUEF(sim.namen(q) == "B ", "nach Fortsetzen und Platz frei: B startet");
      q.abbrechenAlle(4);
      PRUEF(sim.protokoll.back() == "abbruch B" && q.gesamt() == Status::Abgebrochen, "Abbruch erreicht den Ausfuehrer und die Queue"); }

    printf("--- Echter Ausfuehrer ueber actionkit, JSON und Vorlage ---\n");
    { Queue q; Ausfuehrer ak;
      std::vector<std::pair<Id, actionkit::Ergebnis>> ergebnisse;
      ak.starten = [&](Job& j, const json& e, std::string& host) { const actionkit::Aktion* a = actionkit::Aktionen::finde(j.aktion); if (!a) return false; host = "lokal"; ergebnisse.push_back({ j.id, a->aufrufen(e) }); return true; };
      q.ausfuehrer = &ak;
      Job& s1 = q.anlegen("2+3", "Add"); s1.eingaenge = { {"a", 2, 0, ""}, {"b", 3, 0, ""} };
      Job& s2 = q.anlegen("+10", "Add"); s2.eingaenge = { {"a", json(), s1.id, "summe"}, {"b", 10, 0, ""} };
      Job& k = q.anlegen("kaputt", "Kaputt"); k.eingaenge = { {"x", 1, 0, ""} }; k.ablauf = Ablauf::Parallel;
      Job& t = q.triggerJob(k.id, Trigger::OnFailure, "aufraeumen", "Add"); t.eingaenge = { {"a", 0, 0, ""}, {"b", 0, 0, ""} };
      auto takt = [&](Zeit z) { q.schritt(z); for (auto& p : ergebnisse) q.fertig(p.first, p.second.ok, p.second.ausgaben, p.second.fehler, z); ergebnisse.clear(); };
      q.starten(0); for (int i = 1; i < 6; ++i) takt(i);
      PRUEF(q.finde(s2.id)->status == Status::Fertig && q.finde(s2.id)->ausgaben["summe"] == 15, "echte Aktionen verkettet: (2+3)+10 = 15");
      PRUEF(q.finde(k.id)->status == Status::Fehler && q.finde(k.id)->fehler == "immer kaputt" && q.finde(t.id)->status == Status::Fertig, "Fehler einer Aktion loest OnFailure aus");
      json j = q.zuJson(); Queue q2 = Queue::ausJson(j);
      PRUEF(q2.jobs.size() == 4 && q2.finde(s2.id)->eingaenge[0].vonJob == s1.id && q2.finde(s2.id)->ausgaben["summe"] == 15, "JSON-Rundreise erhaelt Struktur, Verbindungen und Ausgaben");
      q2.istVorlage = true; Queue inst = q2.alsInstanz(7, "Lauf 2");
      PRUEF(!inst.istVorlage && inst.name == "Lauf 2" && inst.finde(s2.id)->status == Status::Inaktiv && inst.finde(s2.id)->ausgaben.empty() && inst.finde(s2.id)->eingaenge[0].vonJob == s1.id,
            "Instanz aus Vorlage: gleiche Struktur, ohne Laufzeitzustand"); }

    printf("\n%s\n", fehler ? "### FEHLER ###" : "ALLE PRUEFUNGEN BESTANDEN");
    return fehler;
}
