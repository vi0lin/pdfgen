#pragma once
// ===========================================================================
// jobflow/planer.h -- BRUECKE timeline -> jobflow.
//
// Ein Aktions-Event (timeline::Art::Aktion) traegt in seiner Aktion:
//   befehl    "queue:<vorlagenId>"   eine jobflow-Queue-Vorlage starten
//             sonst                  eine einzelne actionkit-Aktion als
//                                    Ein-Job-Queue (parameter = Eingaenge-JSON)
// Beim Eintreten eines Vorkommens legt der Planer eine LAUF-Instanz an
// (Queue aus der Vorlage), startet sie und vermerkt das Vorkommen als
// gestartet (timeline::Gestartet -- wird abgeglichen, kein Doppelstart auf
// anderen Clients). Verpasste Vorkommen (Offline, App zu) werden ueber
// timeline::verpasst() nachgeholt, sofern das Event es erlaubt.
//
// Der Planer besitzt die Laeufe; der Aufrufer taktet ihn (schritt) und gibt
// ihm den Ausfuehrer. UI-frei; testbar mit einer Uhr aus dem Test.
// ===========================================================================
#include "jobflow.h"
#include "model.h"      // timeline

namespace jobflow {

struct Lauf {
    Id            id = 0;
    timeline::Id  event = 0;               // Aktions-Event
    timeline::Zeit vorkommen = 0;          // Start des Vorkommens
    Queue         queue;                   // die laufende Instanz
    bool          nachgeholt = false;      // aus "verpasst"
};

struct Planer {
    timeline::Speicher* speicher = nullptr;
    std::map<Id, Queue>  vorlagen;         // Queue-Vorlagen nach Id
    std::vector<Lauf>    laeufe;
    Ausfuehrer*          ausfuehrer = nullptr;
    timeline::Zeit       zuletztGeprueft = 0;
    timeline::Zeit       tz = 0;
    timeline::Zeit       toleranzSek = 60;  // bis dahin gilt ein Start als puenktlich
    Id                   naechsteLaufId = 1;
    std::function<void(const Lauf&)> onLaufStart;     // fuer Anzeige/Log

    // Queue aus der Aktion eines Events bauen
    bool queueFuer(const timeline::Event& e, Queue& aus) const {
        timeline::Opt<timeline::Aktion> a = timeline::wAktion(*speicher, e);
        if (!a.gesetzt) return false;
        const std::string& b = a.wert.befehl;
        if (b.rfind("queue:", 0) == 0) {
            Id vid = (Id)std::strtoull(b.c_str() + 6, nullptr, 10);
            auto it = vorlagen.find(vid); if (it == vorlagen.end()) return false;
            aus = it->second.alsInstanz(naechsteLaufId, timeline::wTitel(*speicher, e));
            return true;
        }
        // Einzelaktion
        Queue q; q.id = naechsteLaufId; q.name = timeline::wTitel(*speicher, e);
        Job& j = q.anlegen(b, b);
        json p = json::parse(a.wert.parameter, nullptr, false);
        if (p.is_object()) for (auto it = p.begin(); it != p.end(); ++it) j.eingaenge.push_back({ it.key(), it.value(), 0, "" });
        // Ziel uebernehmen
        j.ziel.wahl = (Zielwahl)(int)a.wert.ziel; j.ziel.hosts = a.wert.hosts; j.ziel.bevorzugt = a.wert.bevorzugt;
        aus = q; return true;
    }

    Lauf* starten(const timeline::Vorkommen& v, timeline::Zeit jetzt, bool nachgeholt) {
        const timeline::Event* e = speicher->finde(v.event); if (!e) return nullptr;
        Lauf l; l.id = naechsteLaufId; l.event = v.event; l.vorkommen = v.start; l.nachgeholt = nachgeholt;
        if (!queueFuer(*e, l.queue)) return nullptr;
        ++naechsteLaufId;
        l.queue.ausfuehrer = ausfuehrer;
        l.queue.starten(jetzt);
        speicher->vermerkeGestartet({ v.event, v.start });
        laeufe.push_back(l);
        if (onLaufStart) onLaufStart(laeufe.back());
        return &laeufe.back();
    }

    // EIN TAKT: faellige und verpasste Vorkommen starten, Laeufe takten.
    int schritt(timeline::Zeit jetzt) {
        int gestartet = 0;
        if (speicher) {
            // Faellig seit der letzten Pruefung: genau das liefert verpasst()
            // -- mit Startvermerken und "nachstarten wenn verpasst".
            // Nachgeholt = Vorkommen liegt weiter zurueck als ein Takt.
            for (const timeline::Vorkommen& v : timeline::verpasst(*speicher, zuletztGeprueft, jetzt, tz, speicher->gestartet, toleranzSek)) {
                const timeline::Event* e = speicher->finde(v.event);
                if (!e || e->art != timeline::Art::Aktion) continue;
                if (starten(v, jetzt, /*nachgeholt=*/ jetzt - v.start > toleranzSek)) ++gestartet;
            }
            zuletztGeprueft = jetzt;
        }
        for (Lauf& l : laeufe) if (l.queue.laeuftNoch() || l.queue.gesamt() == Status::Wartet) l.queue.schritt(jetzt);
        return gestartet;
    }
    void fertig(Id laufId, Id jobId, bool ok, const json& aus, const std::string& fehler, timeline::Zeit jetzt) {
        for (Lauf& l : laeufe) if (l.id == laufId) { l.queue.fertig(jobId, ok, aus, fehler, jetzt); return; }
    }
    Lauf* finde(Id laufId) { for (Lauf& l : laeufe) if (l.id == laufId) return &l; return nullptr; }
    // Manuell (Knopf): ein Vorkommen jetzt starten, auch wenn es nicht faellig ist
    Lauf* manuell(timeline::Id event, timeline::Zeit vorkommen, timeline::Zeit jetzt) {
        timeline::Vorkommen v; v.event = event; v.serie = event; v.start = vorkommen; v.ende = vorkommen;
        return starten(v, jetzt, false);
    }
};

} // namespace jobflow
