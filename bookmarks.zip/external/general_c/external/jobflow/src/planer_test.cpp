#include "planer.h"
#include <cstdio>
using namespace jobflow;
static int fehler = 0;
#define PRUEF(bed, text) do { bool ok = (bed); printf("  %s %s\n", ok ? "OK " : "FEHLER", text); if (!ok) fehler++; } while (0)
static const timeline::Zeit TZ = 2 * 3600;
static timeline::Zeit um(int y, int m, int d, int h, int mi = 0) { return timeline::ausLokal({ timeline::tageSeitEpoche(y, m, d), h * 3600 + mi * 60 }, TZ); }

int main() {
    timeline::Speicher s; s.geraet = "laptop";
    // Queue-Vorlage 5: pdf -> mail (mail bekommt pdfPfad)
    Queue vl; vl.id = 5; vl.name = "Rechnung"; vl.istVorlage = true;
    Job& pdf = vl.anlegen("pdf", "pdfgen"); pdf.eingaenge = { {"quelle", "rechnung.txt", 0, ""} };
    Job& mail = vl.anlegen("mail", "mailen", pdf.id); mail.eingaenge = { {"anhang", json(), pdf.id, "pdfPfad"} };
    // Aktions-Event: monatlich am 1. um 09:00 die Queue-Vorlage 5
    timeline::Event& e = s.anlegen(um(2026, 9, 1, 0)); e.titel = "Monatsrechnung"; e.art = timeline::Art::Aktion;
    e.start = um(2026, 10, 1, 9); e.regel.takt = timeline::Takt::Monatlich;
    timeline::Aktion a; a.befehl = "queue:5"; e.aktion = a;
    // Zweites Aktions-Event: Einzelaktion mit Parametern, "nachstarten" aus
    timeline::Event& e2 = s.anlegen(um(2026, 9, 1, 0)); e2.titel = "Backup"; e2.art = timeline::Art::Aktion; e2.start = um(2026, 10, 1, 3); e2.regel.takt = timeline::Takt::Taeglich;
    timeline::Aktion a2; a2.befehl = "backup"; a2.parameter = "{\"ziel\":\"/mnt/nas\"}"; a2.nachstartenWennVerpasst = false; a2.ziel = timeline::Zielwahl::Bestimmte; a2.hosts = {"buildserver"}; e2.aktion = a2;

    // Ausfuehrer, der sofort "fertig" meldet (ueber den Planer)
    Planer p; p.speicher = &s; p.tz = TZ; p.vorlagen[5] = vl; p.zuletztGeprueft = um(2026, 9, 30, 0);
    std::vector<std::string> protokoll; std::vector<std::pair<Id, Id>> offen;   // (laufId, jobId)
    Ausfuehrer ax;
    ax.starten = [&](Job& j, const json& ein, std::string& host) {
        host = j.ziel.wahl == Zielwahl::Bestimmte && !j.ziel.hosts.empty() ? j.ziel.hosts[0] : "lokal";
        protokoll.push_back(j.aktion + " " + ein.dump() + " @" + host);
        for (Lauf& l : p.laeufe) if (l.queue.finde(j.id) == &j) offen.push_back({ l.id, j.id });
        return true; };
    p.ausfuehrer = &ax;
    auto abarbeiten = [&](timeline::Zeit t) { auto o = offen; offen.clear(); for (auto& x : o) p.fertig(x.first, x.second, true, json{{"pdfPfad","/tmp/r.pdf"}}, "", t); };

    printf("--- Faelligkeit ---\n");
    p.schritt(um(2026, 10, 1, 8));
    PRUEF(p.laeufe.empty(), "vor 09:00 startet nichts");
    p.schritt(um(2026, 10, 1, 9, 0)); 
    PRUEF(p.laeufe.size() == 1 && p.laeufe[0].event == e.id && !p.laeufe[0].nachgeholt && p.laeufe[0].queue.name == "Monatsrechnung", "um 09:00: Lauf aus der Queue-Vorlage, benannt nach dem Event");
    PRUEF(s.gestartet.count({ e.id, um(2026, 10, 1, 9) }) == 1, "Vorkommen als gestartet vermerkt (wird abgeglichen -> kein Doppelstart)");
    PRUEF(protokoll.size() == 1 && protokoll[0].find("pdfgen") == 0, "erster Job (pdf) laeuft");
    abarbeiten(um(2026, 10, 1, 9, 1)); p.schritt(um(2026, 10, 1, 9, 1));
    PRUEF(protokoll.size() == 2 && protokoll[1].find("\"anhang\":\"/tmp/r.pdf\"") != std::string::npos, "Kind 'mail' bekommt pdfPfad aus dem Vorgaenger");
    abarbeiten(um(2026, 10, 1, 9, 2)); p.schritt(um(2026, 10, 1, 9, 2));
    PRUEF(p.laeufe[0].queue.gesamt() == Status::Fertig, "Lauf fertig");
    p.schritt(um(2026, 10, 1, 10));
    PRUEF(p.laeufe.size() == 1, "kein zweiter Start desselben Vorkommens");

    printf("--- Verpasst / Nachholen ---\n");
    p.schritt(um(2026, 11, 3, 12));        // App war 2 Tage zu: 1.11. 09:00 verpasst, Backup 1.11. 03:00 auch
    PRUEF(p.laeufe.size() == 2 && p.laeufe[1].vorkommen == um(2026, 11, 1, 9) && p.laeufe[1].nachgeholt, "verpasster Monatslauf wird nachgeholt und als 'nachgeholt' markiert");
    bool backup = false; for (auto& l : p.laeufe) if (l.event == e2.id) backup = true;
    PRUEF(!backup, "taegliches Backup mit 'nachstarten wenn verpasst' = aus: kein einziger der verpassten Laeufe wird nachgeholt");
    p.zuletztGeprueft = um(2026, 12, 1, 2, 59); p.schritt(um(2026, 12, 1, 3, 0));

    backup = false; for (auto& l : p.laeufe) if (l.event == e2.id) backup = true;
    PRUEF(backup && protokoll.back() == "backup {\"ziel\":\"/mnt/nas\"} @buildserver", ("Einzelaktion puenktlich: Parameter und Zielhost kommen an: " + protokoll.back()).c_str());

    printf("--- Manuell (Knopf) ---\n");
    Lauf* m = p.manuell(e.id, um(2026, 10, 1, 9), um(2026, 10, 15, 14)); p.schritt(um(2026, 10, 15, 14));
    PRUEF(m && p.laeufe.size() == 4 && protokoll.back().find("pdfgen") == 0, "'nur diesen Job jetzt starten' erzeugt einen neuen Lauf, auch wenn das Vorkommen schon lief");

    printf("--- Abgleich: anderer Client sieht den Startvermerk ---\n");
    timeline::Speicher handy; handy.geraet = "handy"; timeline::zusammenfuehren(handy, s);
    Planer ph; ph.speicher = &handy; ph.tz = TZ; ph.vorlagen[5] = vl; ph.ausfuehrer = &ax; ph.zuletztGeprueft = um(2026, 9, 30, 0);
    size_t vorher = protokoll.size(); ph.schritt(um(2026, 11, 3, 13));
    PRUEF(ph.laeufe.empty() && protokoll.size() == vorher, "Handy startet die Oktober-/November-Laeufe nicht noch einmal");

    printf("\n%s\n", fehler ? "### FEHLER ###" : "ALLE PRUEFUNGEN BESTANDEN");
    return fehler;
}
