# jobflow -- Queues und Jobs

Die "Computing Power Unit": eine Queue ist ein Baum von Jobs.

- **Einrueckung** = Kind: laeuft, wenn das Elternteil fertig ist. `nachRechts()`,
  `nachLinks()`, `einhaengen()` (Drag & Drop) -- Zyklen werden abgewiesen.
- **Ablaufart je Job** gegenueber seinen Geschwistern: Parallel, WartenAuf
  (bestimmte Geschwister), Prozedural (der vorige).
- **Trigger**: `triggerJob(auf, OnSuccess|OnFailure|OnAbort, ...)` -- laeuft nur
  bei diesem Ergebnis, unabhaengig von der Geschwisterreihenfolge.
- **Eingaben**: fester Wert oder Ausgang eines anderen Jobs (`vonJob`/`ausgang`)
  -- die Verbindungen des Node-Editors.
- **Gruppen** (Job ohne Aktion, buendelt Kinder), **Schleifen**
  (`wiederholungen`), **Ziel** (lokal, bestimmte Hosts, irgendein Online-Host,
  alle), **Status** je Job und fuer die Queue, **Pause/Fortsetzen/Abbruch**.
- **JSON** (`zuJson`/`ausJson`) und **Vorlagen** (`alsInstanz`).

Die Queue startet keine Prozesse selbst. Ein **Ausfuehrer** (drei Funktionen:
starten, abbrechen, pausieren) bekommt "starte Job X mit diesen Eingaben" und
meldet spaeter `fertig()`. Lokal ist das actionkit; ueber netlink laeuft
derselbe Job auf einem anderen Host. `schritt(jetzt)` ist der Takt, den der
Aufrufer im Frame oder aus einem Timer ruft -- keine eigenen Threads.

    cmake -B build -S . && cmake --build build && ctest --test-dir build

