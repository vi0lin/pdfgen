#!/bin/sh
scriptname="$(basename -- "$0")"
# pkg install -y mesa-libs libglvnd libXcursor libXinerama libwebp-dev libcurl4-openssl-dev ccache ninja pkgconf nghttp2 mbedtls4-4.2.0                 
android_log_file="./builds/logs/log.android"
rm -f "$android_log_file"
# exec > >(ts '{%H:%M:%S}' | tee -a "${android_log_file}") 2>&1

# RUECKGABEWERT DURCH DIE PIPE RETTEN.
# [Der ganze Rumpf laeuft als  { ... } | ts | tee  -- und eine Pipe liefert
#  den Rueckgabewert des LETZTEN Befehls, also von tee: immer 0. Jedes
#  "exit 1" hier drin ging damit verloren; build.sh hielt den Bau fuer
#  gelungen, erst publish_release.sh merkte, dass keine neue APK entstand.
#  "set -o pipefail" gibt es nicht in jedem /bin/sh. Deshalb schreibt der
#  Block seinen Rueckgabewert beim Verlassen in eine Datei (EXIT-Trap --
#  greift bei "exit 1" ebenso wie bei einem Abbruch durch set -e), und das
#  Skript beendet sich am Ende mit genau diesem Wert.]
rc_file="${TMPDIR:-/tmp}/build_apk.rc.$$"
rm -f "$rc_file"
{
trap 'echo $? > "$rc_file"' EXIT
### android_log_file="/home/build/bookmarks/log.android"
### rm ${android_log_file}
### android_log=" 2>&1 | tee -a ${android_log_file}"
# build_apk.sh
# pkg install -y openjdk17 curl wget cmake gcc linux-rl9-libxml2 zip bash
# mount -t procfs proc /proc
#
# FreeBSD
# kldload linux64
# sysrc linux_enable=YES
# pkg install -y linux_base-rl9

#
# Baut eine installierbare .apk KOMPLETT OHNE Android Studio und ohne Gradle.
#
# Ablauf:
#   1. Java-Check (JDK wird nur fuer sdkmanager/apksigner/keytool gebraucht,
#      NICHT fuer App-Code -- die App ist hasCode=false, reine C++ .so)
#   2. Android SDK cmdline-tools herunterladen (falls fehlt)
#   3. platform, build-tools, NDK via sdkmanager installieren (falls fehlen)
#   4. C++ Build via CMake + NDK-Toolchain (arm64-v8a)
#   5. APK packen:  aapt2 link  ->  .so einfuegen  ->  zipalign  ->  apksigner
#
# Aufruf:   ./build_apk.sh          (aus dem Projekt-Root)
# Ergebnis: builds/apk/x_bookmark_manager.apk
#
# Installation aufs Handy (USB-Debugging aktiv):
#   $ANDROID_HOME/platform-tools/adb install -r builds/apk/x_bookmark_manager.apk

set -eu
# set -euo pipefail

# Eindeutiger Lauf-Stempel: erscheint am Anfang jedes Logs. Damit ist
# sofort erkennbar, ob ein Log von einem frischen Lauf und von DIESER
# Skript-Version stammt.
echo "############################################################"
echo "# build_apk.sh  Version: 2026-07-05.2 (freebsd-custom-toolchain)"
echo "# Lauf gestartet: $(date)  Host: $(uname -s) $(hostname 2>/dev/null || true)"
echo "############################################################"

# ---------------------------------------------------------------------------
# 0. Plattform-Check
# ---------------------------------------------------------------------------
# Linux: Standardweg ueber die NDK-Toolchain-Datei (android.toolchain.cmake).
# FreeBSD: die NDK-Toolchain-Datei erkennt den Host NICHT (sie kennt nur
#   Linux/Darwin/Windows) -> ANDROID_HOST_TAG bleibt leer -> der Compiler-
#   Pfad wird 'prebuilt//bin/clang++' und "clang++ not found" ist die Folge.
#   Fix: CMakes EINGEBAUTE Android-Unterstuetzung nutzen und den Host-Tag
#   explizit setzen (CMAKE_ANDROID_NDK_TOOLCHAIN_HOST_TAG=linux-x86_64).
#   Voraussetzung: Linuxulator aktiv, damit die Linux-clang-Binaries laufen:
#     sudo sysrc linux_enable=YES && sudo service linux start
#     sudo pkg install linux_base-rl9
OS_NAME="$(uname -s)"
USE_CMAKE_BUILTIN_ANDROID=0
case "$OS_NAME" in
    Linux) ;;
    FreeBSD)
        echo "==> FreeBSD erkannt: nutze CMakes eingebaute Android-Unterstuetzung"
        echo "    mit explizitem Host-Tag linux-x86_64 (NDK-Toolchain-Datei kann"
        echo "    den FreeBSD-Host nicht erkennen)."
        echo "    Achtung: die NDK-clang-Binaries sind Linux-ELF und brauchen den"
        echo "    Linuxulator (sysrc linux_enable=YES; service linux start;"
        echo "    pkg install linux_base-rl9)."
        USE_CMAKE_BUILTIN_ANDROID=1
        ;;
    *)
        echo "FEHLER: Nicht unterstuetzter Host '$OS_NAME'. Android SDK/NDK gibt"
        echo "es nur fuer Linux/macOS/Windows (FreeBSD via Linuxulator-Sonderweg)."
        exit 1
        ;;
esac

# nproc gibt es auf FreeBSD nicht -- portabler CPU-Zaehler:
num_cpus() {
    if command -v nproc >/dev/null 2>&1; then nproc
    else sysctl -n hw.ncpu 2>/dev/null || echo 2
    fi
}

# ---------------------------------------------------------------------------
# Konfiguration
# ---------------------------------------------------------------------------
ANDROID_HOME="${ANDROID_HOME:-$HOME/android-sdk}"
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
PLATFORM_VERSION="34"            # android.jar zum Linken des Manifests
BUILD_TOOLS_VERSION="34.0.0"     # aapt2, zipalign, apksigner
NDK_VERSION="29.0.1406865"       # Ziel-Version FALLS via sdkmanager installiert wird
                                  # (falls du das NDK manuell entpackt hast, wird es
                                  # trotzdem automatisch ueber find_ndk() gefunden --
                                  # diese Variable ist nur der sdkmanager-Fallback)
ANDROID_ABI="arm64-v8a"          # praktisch jedes moderne Smartphone
ANDROID_MIN_API="26"             # Android 8.0+

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
# 'builds/apk/' ist ein WEGWERF-Build-Verzeichnis (native/, apk/, fertige .apk).
# [Frueher 'android/' im Projektstamm -- als einziges Ziel NICHT unter
#  builds/<ziel>/ wie deb, deb-asan und exe. Folgen: eigene Pfade in
#  targets.conf, und weil nur builds/ vom Abgleich ausgeschlossen ist,
#  konnte android/native/ samt Objektdateien zwischen den Rechnern
#  wandern. Ein alter android/-Ordner kann geloescht werden.]
# Quell-Dateien fuers Packaging liegen dauerhaft unter packaging/android/:
#   packaging/android/AndroidManifest.xml   (eingecheckt)
#   packaging/android/debug.keystore        (einmalig erzeugt, bleibt bestehen --
#     wuerde er im Build-Ordner liegen und mitgeloescht, aendert sich bei jedem
#     Neubau die APK-Signatur und 'adb install -r' scheitert mit
#     INSTALL_FAILED_UPDATE_INCOMPATIBLE, bis man die App deinstalliert)
BUILD_SUBDIR="builds/apk"
BUILD_DIR="$PROJECT_ROOT/$BUILD_SUBDIR"
# Unter diesem Namen sucht die App in release.json -- derselbe, den
#   publish_release.sh builds/apk
# vergibt (Ordnername). Siehe XBM_RELEASE_NAME in CMakeLists.txt.
# Von build.sh aus PUBLISH_CMD gesetzt (z.B. "x_bookmark_manager_apk");
# von Hand gebaut bleibt es beim Ordnernamen "apk".
XBM_APK_RELEASE_NAME="${XBM_RELEASE_NAME:-$(basename "$BUILD_DIR")}"
PACKAGING_DIR="$PROJECT_ROOT/packaging/android"
MANIFEST="$PACKAGING_DIR/AndroidManifest.xml"
APK_STAGING="$BUILD_DIR/apk"
APK_NAME="x_bookmark_manager"
KEYSTORE="$PACKAGING_DIR/debug.keystore"

# NDK-Verzeichnis automatisch finden, statt eine feste Version anzunehmen.
# Zwei moegliche Layouts:
#   $ANDROID_HOME/ndk/<version>/                (via sdkmanager installiert)
#   $ANDROID_HOME/ndk/android-ndk-r29/           (manuell entpackt, aeltere/andere Layouts)
find_ndk() {
    local candidate
    # 1. Falls die im Skript vorgesehene sdkmanager-Version bereits existiert
    if [ -d "$ANDROID_HOME/ndk/$NDK_VERSION" ]; then
        echo "$ANDROID_HOME/ndk/$NDK_VERSION"
        return 0
    fi
    # 2. Sonst: irgendein Unterordner von ndk/, der ein Toolchain-CMake-File hat
    #    (deckt sowohl 'ndk/26.3.xxx/' als auch 'ndk/android-ndk-r29/' ab)
    for candidate in "$ANDROID_HOME"/ndk/*/ "$ANDROID_HOME"/ndk/*/*/; do
        if [ -f "${candidate}build/cmake/android.toolchain.cmake" ]; then
            echo "${candidate%/}"
            return 0
        fi
    done
    return 1
}

# ---------------------------------------------------------------------------
# 1. Java pruefen (Build-Werkzeug, kein App-Code)
# ---------------------------------------------------------------------------
if ! command -v java >/dev/null 2>&1; then
    echo "FEHLER: Java (JDK) nicht gefunden."
    echo "sdkmanager/apksigner/keytool sind Java-Programme. Installation:"
    echo "  sudo apt install openjdk-17-jdk-headless"
    exit 1
fi
echo "==> Java gefunden: $(java -version 2>&1 | head -1)"

# ---------------------------------------------------------------------------
# 2. SDK cmdline-tools herunterladen (falls fehlt)
# ---------------------------------------------------------------------------
SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
if [ ! -x "$SDKMANAGER" ]; then
    echo "==> Lade Android SDK cmdline-tools nach $ANDROID_HOME ..."
    mkdir -p "$ANDROID_HOME/cmdline-tools"
    TMP_ZIP="$(mktemp /tmp/cmdline-tools-XXXX.zip)"
    curl -fL "$CMDLINE_TOOLS_URL" -o "$TMP_ZIP"
    unzip -q "$TMP_ZIP" -d "$ANDROID_HOME/cmdline-tools"
    # Google packt sie als 'cmdline-tools/' -- muss 'latest/' heissen:
    mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
    rm -f "$TMP_ZIP"
fi
echo "==> sdkmanager: $SDKMANAGER"

# ---------------------------------------------------------------------------
# 3. Pakete installieren (Lizenzabfragen automatisch akzeptieren)
# ---------------------------------------------------------------------------
echo "==> Installiere/pruefe SDK-Pakete (platform, build-tools, ndk, platform-tools) ..."
yes | "$SDKMANAGER" --licenses >/dev/null 2>&1 || true

# Einzeln installieren statt alles-oder-nichts: manche cmdline-tools-Staende
# haben veraltete Paketlisten und kennen z.B. eine bestimmte build-tools-
# oder platform-Version nicht (Fehler "Failed to find package"). Damit das
# nicht das ganze Skript stoppt, wird pro Paket versucht und bei Fehlschlag
# klar benannt, was fehlt -- inkl. Hinweis auf 'sdkmanager --list'.
install_pkg() {
    local pkg="$1"
    if ! "$SDKMANAGER" --install "$pkg" >/tmp/sdkmanager_out.$$ 2>&1; then
        echo "WARNUNG: Paket '$pkg' konnte nicht installiert werden:"
        cat /tmp/sdkmanager_out.$$
        echo "  -> Verfuegbare Versionen anzeigen: $SDKMANAGER --list | grep -i '${pkg%%;*}'"
        rm -f /tmp/sdkmanager_out.$$
        return 1
    fi
    rm -f /tmp/sdkmanager_out.$$
    return 0
}
# LOKAL VORPRUEFEN, BEVOR "$SDKMANAGER --install" ANGERUFEN WIRD.
# [Bisher wurde bei JEDEM einzelnen Bau versucht, alle drei Pakete neu zu
#  installieren -- selbst wenn sie laengst auf der Platte liegen.
#  "sdkmanager --install" laedt dafuer erst die Paketliste (lokal UND aus
#  dem Netz), was auf diesem Server sichtbar mehrere Sekunden pro Paket
#  kostet, und schlaegt bei build-tools/platform-tools hier ohnehin IMMER
#  mit "Failed to find package" fehl (die Versionen liegen zwar
#  installiert vor, stehen aber nicht mehr in der Repository-Liste
#  dieser cmdline-tools-Installation). Der Bau lief bisher trotzdem
#  durch, weil die spaeteren Existenz-Pruefungen (BUILD_TOOLS,
#  ANDROID_JAR) die bereits vorhandenen Pakete fanden -- der
#  sdkmanager-Aufruf war also reine, wiederkehrende Zeitverschwendung.
#  Jetzt: erst per einfachem Datei-/Ordnertest nachsehen, ob das Paket
#  schon da ist, und NUR wenn nicht, den (langsamen) Netzweg gehen.]
pkg_vorhanden() {
    case "$1" in
        platforms\;*)
            [ -f "$ANDROID_HOME/platforms/${1#platforms;}/android.jar" ] ;;
        build-tools\;*)
            [ -d "$ANDROID_HOME/build-tools/${1#build-tools;}" ] ;;
        platform-tools)
            [ -x "$ANDROID_HOME/platform-tools/adb" ] ;;
        *) return 1 ;;
    esac
}
install_pkg_falls_noetig() {
    local pkg="$1"
    if pkg_vorhanden "$pkg"; then
        echo "==> '$pkg' bereits vorhanden -- sdkmanager-Netzwerkweg uebersprungen"
        return 0
    fi
    install_pkg "$pkg"
}

install_pkg_falls_noetig "platforms;android-$PLATFORM_VERSION"   || true
install_pkg_falls_noetig "build-tools;$BUILD_TOOLS_VERSION"       || true
install_pkg_falls_noetig "platform-tools"                          || true
# NDK separat unten behandelt (find_ndk deckt auch manuell installierte NDKs ab)

NDK="$(find_ndk || true)"
if [ -z "$NDK" ]; then
    echo "==> Kein NDK gefunden, installiere via sdkmanager ($NDK_VERSION) ..."
    "$SDKMANAGER" --install "ndk;$NDK_VERSION" >/dev/null
    NDK="$ANDROID_HOME/ndk/$NDK_VERSION"
fi
# build_tools_path=/home/build/android-sdk/build-tools
# build_tools_fullpath=$build_tools_path/$BUILD_TOOLS_VERSION
# mkdir -p $build_tools_fullpath
# build_tools_dl="https://dl.google.com/android/repository/build-tools_r34-linux.zip"
# build_tools_dest_file=$build_tools_path/build_tools.zip
# wget $build_tools_dl -O $build_tools_dest_file
# unzip $build_tools_dest_file -d $build_tools_path/
# mv $build_tools_fullpath/android-14 $build_tools_path/$BUILD_TOOLS_VERSION
# rm $build_tools_dest_file

# platform_tools_zip=/home/build/bookmarks/external/platform-tools-latest-linux.zip
# platform_tools_path=/home/build/android-sdk/platform-tools
# platform_tools_fullpath=$platform_tools_path/$PLATFORM_VERSION
# mkdir -p $platform_tools_fullpath
# unzip $platform_tools_zip -d $platform_tools_fullpath

# rm $platform_tools_dest_file

# ndk_zip="/home/build/bookmarks/external/android-ndk-r29-linux.zip"
# NDK_PARENT="$ANDROID_HOME/ndk"
# NDK="$ANDROID_HOME/ndk/${NDK_VERSION}"

# mkdir -p ${NDK}
# unzip $ndk_zip -d ${NDK_PARENT}
# mv ${NDK_PARENT}/android-ndk-r29 ${NDK_PARENT}/${NDK_VERSION}

# $SDKMANAGER --update
# yes | $SDKMANAGER --install "platforms;android-$PLATFORM_VERSION"
# yes | $SDKMANAGER --install "ndk;$NDK_VERSION"
# >/dev/null
    # "platform-tools" \
    # "build-tools;$BUILD_TOOLS_VERSION" \

# NDK="$ANDROID_HOME/ndk/$NDK_VERSION"

# NDK="$ANDROID_HOME/ndk/${NDK_VERSION}"
BUILD_TOOLS="$ANDROID_HOME/build-tools/$BUILD_TOOLS_VERSION"
ANDROID_JAR="$ANDROID_HOME/platforms/android-$PLATFORM_VERSION/android.jar"
echo "==> NDK gefunden: $NDK"
if [ ! -f "$NDK/build/cmake/android.toolchain.cmake" ]; then
    echo "FEHLER: $NDK/build/cmake/android.toolchain.cmake existiert nicht."
    echo "Pruefe, ob '$NDK' wirklich das NDK-Wurzelverzeichnis ist (nicht z.B. .../toolchains/llvm/...)."
    exit 1
fi
if [ ! -d "$BUILD_TOOLS" ]; then
    echo "FEHLER: build-tools nicht gefunden unter $BUILD_TOOLS"
    echo "Installierte Versionen anzeigen:  ls $ANDROID_HOME/build-tools/"
    echo "Falls eine andere Version installiert ist, BUILD_TOOLS_VERSION im Skript anpassen."
    exit 1
fi
if [ ! -f "$ANDROID_JAR" ]; then
    echo "FEHLER: android.jar nicht gefunden unter $ANDROID_JAR"
    echo "Installierte Plattformen anzeigen:  ls $ANDROID_HOME/platforms/"
    echo "Falls eine andere Version installiert ist, PLATFORM_VERSION im Skript anpassen."
    exit 1
fi

# ---------------------------------------------------------------------------
# 4. C++ Build (CMake + NDK-Toolchain)
# ---------------------------------------------------------------------------
# WICHTIG: Hier NIEMALS -DCMAKE_C_COMPILER / -DCMAKE_CXX_COMPILER manuell
# angeben. Die Toolchain-Datei setzt beide selbst.
#
# INKREMENTELL vs. CLEAN:
#   Standard: inkrementell -- mbedTLS und curl (die teuersten Brocken)
#   bleiben gebaut und werden NICHT neu kompiliert. Nur geaenderte eigene
#   Dateien werden neu uebersetzt. Das spart den Grossteil der Zeit.
#   Vollreset nur wenn noetig (z.B. nach Aenderung der mbedTLS/curl-CMake-
#   Optionen): mit  CLEAN=1 ./build_apk.sh

clean_external() {
  echo "Cleaning External"
  sudo rm -rf "${PROJECT_ROOT}/external/pdf/build"
  # find . -wholename ./external/*/CMakeCache 2>/dev/null | xargs -I {} sudo rm -rf {}
}

clean_cache() {
  ccache --cleanup
  ccache -c
  ccache -s
}

clean() {
  echo "Clean $1"
  # Fast clean of all build products (main project + everything under external/)
  #
  # HIER BRICHT DER LAUF AB, WENN DIESE PRUEFUNG FEHLT:
  # Ohne CMakeCache.txt (frischer Baum, nach CLEAN_DEEP, oder nach einem
  # manuellen rm -rf android) meldet cmake
  #     Error: could not load cache
  # und liefert 1 zurueck. Wegen  set -eu  (Zeile 37) beendet das
  # kommentarlos das GANZE Skript -- noch vor dem Konfigurieren. Im Log
  # steht dann nur "Clean android" und danach nichts mehr.
  if [ -f "${PROJECT_ROOT}/$1/CMakeCache.txt" ]; then
    cmake --build "${PROJECT_ROOT}/$1" --target clean \
      || echo "  Hinweis: clean-Ziel fehlgeschlagen -- ignoriert, es wird ohnehin neu gebaut."
  else
    echo "  nichts zu tun: ${PROJECT_ROOT}/$1 ist noch nicht konfiguriert."
  fi
}
  # cmake --build ${PROJECT_ROOT}/$1 --target clean

clean_deep() {
  echo "Clean $1 Deep"
  # Schutz vor leerem Argument: "sudo rm -rf $1" raeumte sonst das
  # aktuelle Verzeichnis ab.
  if [ -z "${1:-}" ]; then
    echo "  clean_deep ohne Argument -- abgebrochen."
    return 0
  fi
  sudo rm -rf "${PROJECT_ROOT}/$1"
  find "${PROJECT_ROOT}" -wholename "${PROJECT_ROOT}/$1*/CMakeCache" 2>/dev/null \
    | xargs -I {} sudo rm -rf {}
  # sudo rm -rf $1
  # find . -wholename "./$1*/CMakeCache" 2>/dev/null | xargs -I {} sudo rm -rf {}
}

clean_all() {
  echo Cleaning All
  remove_log android
  # doubled for further - keep - logs - option
  clean_cache
  # ueber clean() statt direkt: gleiche Absicherung, und der Pfad wird
  # absolut aufgeloest (hier stand ein relatives "android", das nur
  # zufaellig stimmt, solange man im Projektstamm steht).
  # native/: dort liegt der CMake-Cache (clean prueft auf CMakeCache.txt).
  clean "$BUILD_SUBDIR/native"
  # cmake --build ${PROJECT_ROOT}/$1 --target clean
}

clean_all_deep() {
  echo Cleaning All Deep
  clean_cache
  clean_external
  sudo rm -rf "$BUILD_DIR"
  find . -wholename "./$BUILD_SUBDIR*/CMakeCache" 2>/dev/null | xargs -I {} sudo rm -rf {}
  # --exclude external/
}

if [ "${CLEAN:-0}" = "1" ]; then
  clean "$BUILD_SUBDIR/native"
fi

if [ "${CLEAN_DEEP:-0}" = "1" ]; then
  clean_deep "$BUILD_SUBDIR"
fi

if [ "${CLEAN_ALL:-0}" = "1" ]; then
  clean_all
fi

if [ "${CLEAN_ALL_DEEP:-0}" = "1" ]; then
  clean_all_deep
fi

### Old Clean Logic
## if [ "${CLEAN:-0}" = "1" ]; then
##     echo "==> CLEAN=1: kompletter Neuaufbau (loesche $BUILD_DIR/native)"
##     ccache --cleanup
##     ccache -c
##     ccache -s
##     rm -rf "${PROJECT_ROOT}/android/native"
##     rm -rf "${PROJECT_ROOT}/android"
##     rm -rf "${PROJECT_ROOT}/external/pdf/build"
##     rm -rf "${PROJECT_ROOT}/CMakeCache.txt"
##     rm -rf "${PROJECT_ROOT}/windows"
##     rm -rf "${PROJECT_ROOT}/linux"
##     find . -name CMakeCache 2>/dev/null | xargs -I {} sudo rm -rf {}
## else
##     echo "==> Inkrementeller Build (CLEAN=0)"
## fi

# eval "
# cmake -B "${BUILD_DIR}/native" -S "${PROJECT_ROOT}" \
#     -DCMAKE_TOOLCHAIN_FILE="${NDK}/build/cmake/android.toolchain.cmake" \
#     -DANDROID_ABI="${ANDROID_ABI}" \
#     -DANDROID_PLATFORM="android-${ANDROID_MIN_API}" \
#     -DCMAKE_BUILD_TYPE=Release \
#     -DANDROID_HOST_TAG=linux-x86_64 \
#     $android_log
# "

# ccache beschleunigt Wiederholungs-Builds massiv (cached Objektdateien).
# Automatisch nutzen, wenn installiert (FreeBSD: pkg install ccache).
# (POSIX-sh: keine Arrays -- Strings reichen, unsere Pfade sind leerzeichenfrei)
CCACHE_ARGS=""
if command -v ccache >/dev/null 2>&1; then
    echo "==> ccache gefunden -- wird als Compiler-Launcher genutzt"
    CCACHE_ARGS="-DCMAKE_C_COMPILER_LAUNCHER=ccache -DCMAKE_CXX_COMPILER_LAUNCHER=ccache"
fi

# Ninja ist deutlich schneller als Make (bessere Parallelisierung, weniger
# Overhead). Automatisch nutzen, wenn installiert (FreeBSD: pkg install ninja).
# PREFIX_ARGS="-DCMAKE_PREFIX_PATH=/usr/local -DCURL_INCLUDE_DIR=/usr/local/include -DCURL_LIBRARY=/usr/local/lib/libcurl.so -DOpenGL_GL_PREFERENCE=GLVND -DOPENGL_gl_library=/usr/local/lib/libGL.so -DOPENGL_opengl_library=/usr/local/lib/libOpenGL.so -DOPENGL_INCLUDE_DIR=/usr/local/include"
# -DCMAKE_PREFIX_PATH=${PROJECT_ROOT}/external/pdf/external/curl 
# sysroot/usr/local
# -DCMAKE_SYSROOT=${PROJECT_ROOT}/external/pdf/sysroot/linux \
#-DCMAKE_PREFIX_PATH=${PROJECT_ROOT}/external/pdf/external/curl 
# -DCURL_LIBRARY=${PROJECT_ROOT}/external/pdf/sysroot/linux/usr/local/lib/libcurl.so \
# -DCURL_INCLUDE_DIR=${PROJECT_ROOT}/external/curl/include \
PREFIX_ARGS="-DOpenGL_GL_PREFERENCE=GLVND -DOPENGL_gl_library=/usr/local/lib/libGL.so -DOPENGL_opengl_library=/usr/local/lib/libOpenGL.so -DOPENGL_INCLUDE_DIR=/usr/local/include
"
if command -v ninja >/dev/null 2>&1; then
    echo "==> Ninja gefunden -- wird als Generator genutzt"
    GEN_ARGS="-G Ninja"
fi

echo "==> Baue C++ (${ANDROID_ABI}, min API ${ANDROID_MIN_API}) ..."
if [ "$USE_CMAKE_BUILTIN_ANDROID" = "1" ]; then
    echo "==> FreeBSD-Zweig aktiv: eigene Toolchain toolchain-android-freebsd.cmake"
    if [ -f "$PROJECT_ROOT/toolchain-android-freebsd.cmake" ]; then
        FREEBSD_TOOLCHAIN="$PROJECT_ROOT/toolchain-android-freebsd.cmake"
    elif [ -f "$PROJECT_ROOT/cmake/toolchain-android-freebsd.cmake" ]; then
        FREEBSD_TOOLCHAIN="$PROJECT_ROOT/cmake/toolchain-android-freebsd.cmake"
    else
        echo "FEHLER: toolchain-android-freebsd.cmake weder im Projekt-Root noch in cmake/ gefunden."
        exit 1
    fi
    set -x
    cmake -B "$BUILD_DIR/native" -S "$PROJECT_ROOT" \
        $GEN_ARGS $CCACHE_ARGS $PREFIX_ARGS \
        -DCMAKE_TOOLCHAIN_FILE="$FREEBSD_TOOLCHAIN" \
        -DANDROID_NDK_ROOT="$NDK" \
        -DANDROID_API="$ANDROID_MIN_API" \
        -DRENDERER=VULKAN \
        -DXBM_RELEASE_NAME="$XBM_APK_RELEASE_NAME" \
        -DCMAKE_BUILD_TYPE=Release
    set +x
else
    # Linux-Standardweg: NDK-Toolchain-Datei (erkennt den Host selbst).
eval "
    cmake -B "$BUILD_DIR/native" -S "$PROJECT_ROOT" -G Ninja \
        $GEN_ARGS $CCACHE_ARGS $PREFIX_ARGS \
        -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
        -DANDROID_ABI="$ANDROID_ABI" \
        -DANDROID_PLATFORM="android-$ANDROID_MIN_API" \
        -DXBM_RELEASE_NAME=$XBM_APK_RELEASE_NAME \
        -DCMAKE_BUILD_TYPE=Release
"
        # $android_log
fi
eval "
cmake --build "$BUILD_DIR/native" -j"$(num_cpus)"
"
  # $android_log

SO_FILE="$BUILD_DIR/native/libx_bookmark_manager.so"
if [ ! -f "$SO_FILE" ]; then
    echo "FEHLER: $SO_FILE wurde nicht gebaut."
    exit 1
fi

# ---------------------------------------------------------------------------
# 5. APK packen
# ---------------------------------------------------------------------------
echo "==> Packe APK ..."
rm -rf "$APK_STAGING"
mkdir -p "$APK_STAGING/lib/$ANDROID_ABI"
cp "$SO_FILE" "$APK_STAGING/lib/$ANDROID_ABI/"

# 5a0. JAVA-TEIL: XbmActivity kompilieren und nach classes.dex uebersetzen.
# Grund: Gboards Zwischenablage (und Swipe/Autokorrektur) liefert Text nur
# ueber eine InputConnection -- die gibt es erst mit einer echten View.
# XbmActivity haelt dafuer ein unsichtbares EditText bereit.
JAVA_SRC_DIR="$PACKAGING_DIR/java"
# Selbstsuche: Liegt der Java-Teil nicht am erwarteten Ort, im Projekt
# danach suchen (haeufigster Fehler: Datei woanders abgelegt). Ohne
# Java-Teil ist die Texteingabe funktionslos -- deshalb LAUT abbrechen
# statt still zu ueberspringen.
if [ ! -d "$JAVA_SRC_DIR" ]; then
    FOUND_JAVA=$(find "$PROJECT_ROOT" -name 'XbmActivity.java' \
                      -not -path "$BUILD_DIR/*" -not -path '*/android/*' 2>/dev/null | head -1)
    if [ -n "$FOUND_JAVA" ]; then
        # Wurzel = Verzeichnis oberhalb von com/mrtn/...
        JAVA_SRC_DIR=$(echo "$FOUND_JAVA" | sed 's|/com/mrtn/.*||')
        echo "==> Java-Quelle gefunden: $FOUND_JAVA"
        echo "    (Quellwurzel: $JAVA_SRC_DIR)"
    else
        echo "FEHLER: XbmActivity.java nicht gefunden."
        echo "        Erwartet unter: $PACKAGING_DIR/java/com/mrtn/xbookmarkmanager/"
        echo "        Ohne diese Datei bleibt die Texteingabe (Gboard-"
        echo "        Zwischenablage, Swipe, Autokorrektur) OHNE FUNKTION."
        exit 1
    fi
fi
if [ -d "$JAVA_SRC_DIR" ]; then
    echo "==> Java-Teil kompilieren (XbmActivity)"
    # d8 finden: Die JARs der build-tools tragen je nach Version
    # unterschiedliche Einstiegsklassen (d8.jar ist intern R8). Statt zu
    # raten werden die Kandidaten AKTIV getestet -- gewaehlt wird der
    # erste, der wirklich startet.
    D8=""
    for CAND in \
        "java -cp $BUILD_TOOLS/lib/d8.jar com.android.tools.r8.D8" \
        "java -cp $BUILD_TOOLS/lib/r8.jar com.android.tools.r8.D8" \
        "java -cp $BUILD_TOOLS/lib/d8.jar com.android.tools.d8.D8" \
        "java -jar $BUILD_TOOLS/lib/d8.jar" \
        "$BUILD_TOOLS/d8"
    do
        # Existiert die JAR/das Binary ueberhaupt?
        case "$CAND" in
            *lib/d8.jar*) [ -f "$BUILD_TOOLS/lib/d8.jar" ] || continue ;;
            *lib/r8.jar*) [ -f "$BUILD_TOOLS/lib/r8.jar" ] || continue ;;
            "$BUILD_TOOLS/d8") [ -x "$BUILD_TOOLS/d8" ] || continue ;;
        esac
        if $CAND --version >/dev/null 2>&1; then D8="$CAND"; break; fi
    done
    if [ -z "$D8" ]; then
        echo "FEHLER: kein funktionierender d8-Aufruf gefunden."
        echo "        Getestet: d8.jar/r8.jar (r8.D8, d8.D8), -jar, Binary"
        echo "        Inhalt von $BUILD_TOOLS/lib:"
        ls -1 "$BUILD_TOOLS/lib" 2>/dev/null | head -20 | sed 's|^|          |'
        exit 1
    fi
    echo "==> d8: $D8"
    JAVA_OUT="$BUILD_DIR/javaclasses"
    rm -rf "$JAVA_OUT"; mkdir -p "$JAVA_OUT"
    # NUR Dateien im Paketbaum (com/...) uebersetzen. Eine Streukopie
    # direkt in der Quellwurzel ergaebe "duplicate class" und damit kein
    # classes.dex -- die Installation scheiterte dann mit "code is
    # missing", weil das Manifest bereits hasCode=true traegt.
    if [ -d "$JAVA_SRC_DIR/com" ]; then
        find "$JAVA_SRC_DIR/com" -name '*.java' > "$BUILD_DIR/java_sources.txt"
        STRAY=$(find "$JAVA_SRC_DIR" -maxdepth 1 -name '*.java' | head -3)
        if [ -n "$STRAY" ]; then
            echo "==> Hinweis: Streukopien in der Quellwurzel werden"
            echo "    IGNORIERT (bitte loeschen):"
            echo "$STRAY" | sed 's|^|      |'
        fi
    else
        find "$JAVA_SRC_DIR" -name '*.java' > "$BUILD_DIR/java_sources.txt"
    fi
    javac -source 8 -target 8 -nowarn \
          -bootclasspath "$ANDROID_JAR" -classpath "$ANDROID_JAR" \
          -d "$JAVA_OUT" @"$BUILD_DIR/java_sources.txt"
    (cd "$JAVA_OUT" && find . -name '*.class' > "$BUILD_DIR/class_list.txt")
    $D8 --lib "$ANDROID_JAR" --output "$BUILD_DIR" \
        $(cd "$JAVA_OUT" && find . -name '*.class' | sed "s|^\./|$JAVA_OUT/|")
    if [ ! -f "$BUILD_DIR/classes.dex" ]; then
        echo "FEHLER: classes.dex wurde nicht erzeugt."
        echo "        javac-Ausgabe oben pruefen (Pfade/JDK-Version)."
        exit 1
    fi
    echo "==> classes.dex erzeugt"
fi

# 5a. aapt2: Manifest kompilieren + Basis-APK erzeugen (keine Ressourcen noetig)
# Manifest-Existenz VOR aapt2 pruefen -- klare Meldung statt aapt2-Fehler
if [ ! -f "$MANIFEST" ]; then
    echo "==> AndroidManifest.xml fehlt -- erzeuge Standard-Manifest: $MANIFEST"
    mkdir -p "$PACKAGING_DIR"
    cat > "$MANIFEST" << 'MANIFEST_EOF'
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.mrtn.xbookmarkmanager"
    android:versionCode="1" android:versionName="1.0">
    <uses-sdk android:minSdkVersion="26" android:targetSdkVersion="34" />
    <uses-permission android:name="android.permission.INTERNET" />
    <!-- Selbst-Aktualisierung: ohne diese Berechtigung nimmt der Paket-Installer
         seit Android 8 den Intent an und tut dann NICHTS. -->
    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />
    <application
        android:label="X Bookmark Manager"
        android:hasCode="true"
        android:extractNativeLibs="true"
        android:debuggable="true"
        android:allowBackup="false">
        <activity android:name=".XbmActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden|keyboard"
            android:windowSoftInputMode="adjustNothing">
            <meta-data android:name="android.app.lib_name"
                       android:value="x_bookmark_manager" />
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
MANIFEST_EOF
fi

# 5a2. VORHANDENES Manifest automatisch auf den Java-Teil umstellen.
# Der Logcat zeigte "xbmPollText FEHLT": das eingecheckte Manifest zeigte
# noch auf android.app.NativeActivity und hasCode=false -- dann laedt
# Android die Java-Klasse nie, egal ob classes.dex im APK liegt.
if [ -f "$MANIFEST" ]; then
    NEED_PATCH=0
    grep -q 'hasCode="false"' "$MANIFEST" && NEED_PATCH=1
    grep -q 'android.app.NativeActivity' "$MANIFEST" && NEED_PATCH=1
    grep -q 'windowSoftInputMode' "$MANIFEST" || NEED_PATCH=1
    if [ "$NEED_PATCH" = "1" ]; then
        echo "==> Manifest wird fuer XbmActivity angepasst (Backup: .bak)"
        cp "$MANIFEST" "$MANIFEST.bak"
        sed -e 's|android:hasCode="false"|android:hasCode="true"|' \
            -e 's|android:name="android.app.NativeActivity"|android:name=".XbmActivity"|' \
            "$MANIFEST" > "$MANIFEST.tmp" && mv "$MANIFEST.tmp" "$MANIFEST"
        if ! grep -q 'windowSoftInputMode' "$MANIFEST"; then
            sed -e 's|android:name=".XbmActivity"|android:name=".XbmActivity"\n            android:windowSoftInputMode="adjustNothing"|' \
                "$MANIFEST" > "$MANIFEST.tmp" && mv "$MANIFEST.tmp" "$MANIFEST"
        fi
    fi
    echo "--- Manifest-Status ---"
    grep -n 'hasCode\|android:name="\.\|windowSoftInputMode' "$MANIFEST" || true
fi

# DATEN (Vorlagen, pdfgen, Scripts) ALS ASSETS MITGEBEN.
# [CMake (cmake/xbm_data.cmake) legt data/shared + data/android beim Bauen
#  nach native/assets/data und schreibt dort index.txt -- die Liste, nach
#  der xbm_paths.cpp zur Laufzeit entpackt. Hier fehlte aber das "-A":
#  aapt2 packte die Assets nie ein. Die APK enthielt KEINE Daten; auf dem
#  Handy meldete ExtractAssets "data/index.txt fehlt im APK -- nichts zu
#  entpacken". Deshalb fehlten dort die Scripts aus data/shared/scripts
#  (und ebenso die pdfgen-Vorlagen) -- auf Linux/Windows liegen sie
#  dagegen als normaler Ordner neben dem Programm.]
ASSETS_DIR="$BUILD_DIR/native/assets"
if [ ! -f "$ASSETS_DIR/data/index.txt" ]; then
    echo "FEHLER: $ASSETS_DIR/data/index.txt fehlt -- die Datenregel"
    echo "        (cmake/xbm_data.cmake) ist nicht gelaufen. Ohne sie haette"
    echo "        die APK keine Vorlagen und keine Scripts."
    exit 1
fi
echo "==> Assets: $(wc -l < "$ASSETS_DIR/data/index.txt") Datei(en) aus data/"

"$BUILD_TOOLS/aapt2" link \
    -o "$BUILD_DIR/$APK_NAME-unaligned.apk" \
    --manifest "$MANIFEST" \
    -I "$ANDROID_JAR" \
    -A "$ASSETS_DIR"

# 5b. .so in die APK einfuegen (Pfad in der ZIP MUSS lib/<abi>/lib<name>.so sein)
(cd "$APK_STAGING" && zip -q -r "$BUILD_DIR/$APK_NAME-unaligned.apk" lib)

# 5b2. classes.dex ins APK-Wurzelverzeichnis
if [ -f "$BUILD_DIR/classes.dex" ]; then
    (cd "$BUILD_DIR" && zip -q "$APK_NAME-unaligned.apk" classes.dex)
    echo "==> classes.dex ins APK aufgenommen"
fi

# 5b2b. Kontrolle: liegen die Daten wirklich im APK?
if unzip -l "$BUILD_DIR/$APK_NAME-unaligned.apk" | grep -q 'assets/data/index.txt'; then
    echo "==> OK: assets/data im APK ($(unzip -l "$BUILD_DIR/$APK_NAME-unaligned.apk" | grep -c 'assets/data/') Eintraege)"
else
    echo "FEHLER: assets/data FEHLT im APK -- die App haette keine Vorlagen/Scripts."
    exit 1
fi

# 5b3. Kontrolle: liegt classes.dex wirklich im APK?
if unzip -l "$BUILD_DIR/$APK_NAME-unaligned.apk" | grep -q 'classes.dex'; then
    echo "==> OK: classes.dex im APK"
else
    echo "FEHLER: classes.dex FEHLT im APK -- die App wuerde mit"
    echo "        hasCode=true und .XbmActivity gar nicht starten."
    exit 1
fi

# 5c. zipalign (4-Byte-Alignment, Pflicht seit API 30 vor dem Signieren)
"$BUILD_TOOLS/zipalign" -f -p 4 \
    "$BUILD_DIR/$APK_NAME-unaligned.apk" \
    "$BUILD_DIR/$APK_NAME-aligned.apk"

# 5c2. ENDKONTROLLE am fertigen APK: Inhalt und Manifest-Ziel anzeigen.
# Grund: Schlaegt die Installation mit "code is missing" fehl, laeuft auf
# dem Geraet weiter die ALTE App (im Logcat an
# "com.mrtn.xbookmarkmanager/android.app.NativeActivity" erkennbar) --
# jeder Test danach prueft den alten Stand.
echo "--- APK-Inhalt (Auszug) ---"
unzip -l "$BUILD_DIR/$APK_NAME-aligned.apk" | grep -E 'classes.dex|\.so' || true

# 5d. Debug-Keystore erzeugen (einmalig) + signieren
mkdir -p "$PACKAGING_DIR"
if [ ! -f "$KEYSTORE" ]; then
    echo "==> Erzeuge Debug-Keystore (dauerhaft unter packaging/android/) ..."
    keytool -genkeypair -v \
        -keystore "$KEYSTORE" \
        -storepass android -keypass android \
        -alias androiddebugkey \
        -keyalg RSA -keysize 2048 -validity 10000 \
        -dname "CN=Android Debug,O=Android,C=US" >/dev/null 2>&1
fi
# apksigner NICHT ueber das Wrapper-Skript aufrufen: das ist ein
# '#!/bin/bash'-Shellscript, und /bin/bash existiert auf FreeBSD nicht
# (-> irrefuehrendes "not found" trotz vorhandener Datei). Stattdessen
# das dahinterliegende JAR direkt starten -- identisches Verhalten,
# laeuft auf FreeBSD und Linux gleichermassen.
java -jar "$BUILD_TOOLS/lib/apksigner.jar" sign \
    --ks "$KEYSTORE" --ks-pass pass:android --key-pass pass:android \
    --out "$BUILD_DIR/$APK_NAME.apk" \
    "$BUILD_DIR/$APK_NAME-aligned.apk"

rm -f "$BUILD_DIR/$APK_NAME-unaligned.apk" "$BUILD_DIR/$APK_NAME-aligned.apk" \
      "$BUILD_DIR/$APK_NAME.apk.idsig"

echo ""
echo "=========================================================="
echo "HINWEIS: Die Activity heisst jetzt .XbmActivity (vorher"
echo "         android.app.NativeActivity). Ein Update ueber -r kann"
echo "         daran scheitern. Bei INSTALL_FAILED_INVALID_APK bitte:"
echo "           adb uninstall com.mrtn.xbookmarkmanager"
echo "           adb install $BUILD_SUBDIR/$APK_NAME.apk"
echo " FERTIG: $BUILD_DIR/$APK_NAME.apk"
echo ""
echo " Installation (USB-Debugging am Handy aktivieren):"
echo "   $ANDROID_HOME/platform-tools/adb install -r $BUILD_DIR/$APK_NAME.apk"
echo "=========================================================="
} 2>&1 | ts "build@build ${scriptname} {%H:%M:%S}" | tee -a "${android_log_file}"

# Rueckgabewert des Blocks (fehlt die Datei, wurde er hart beendet: Fehler)
rc=$(cat "$rc_file" 2>/dev/null || echo 1)
rm -f "$rc_file"
exit "${rc:-1}"
