# Helligkeit setzen, aufgerufen als:  windows.ps1 <1..10>
param([int]$Stufe = 5)
# UMRECHNUNG AN EINER STELLE: Windows will 5..100.
$Prozent = [int](5 + ($Stufe - 1) * (95 / 9))
if ($Prozent -lt 5)   { $Prozent = 5 }
if ($Prozent -gt 100) { $Prozent = 100 }
Write-Host "[windows] Stufe $Stufe -> $Prozent Prozent"
Invoke-CimMethod -InputObject (Get-CimInstance -Namespace root/wmi `
  -ClassName WmiMonitorBrightnessMethods) -MethodName WmiSetBrightness `
  -Arguments @{Brightness = $Prozent; Timeout = 0}
