# Helligkeit setzen, Skala 1..10 (1 = dunkel).
# Bekommt die Parameter als "$@".
wert=${1:-5}
echo "[posix] setze Helligkeit auf $wert von 10"
# hier stuende dein  d "$wert"
