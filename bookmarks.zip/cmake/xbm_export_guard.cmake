# ---------------------------------------------------------------------------
# cmake/xbm_export_guard.cmake -- gegen
#   CMake Error: install(EXPORT "libssh2-targets" ...) includes target
#                "mbedcrypto" more than once in the export set.
#
# WAS PASSIERT
# libssh2 haengt sein Krypto-Backend an die eigene Bibliothek:
#     list(APPEND LIBSSH2_LIBS ${MBEDTLS_LIBRARIES})     # -> mbedcrypto
#     target_link_libraries(libssh2_static PRIVATE ${LIBSSH2_LIBS})
# Weil mbedcrypto damit in der Link-Schnittstelle des exportierten Ziels
# steht, verlangt CMake, dass mbedcrypto ebenfalls in einem Export-Satz
# liegt. Wird es daraufhin (an mehr als einer Stelle, oder von einem Aufruf
# der zweimal laeuft) in denselben Satz eingetragen, bricht der
# Generierungsschritt ab.
#
# WARUM AUSGERECHNET SO
# Ausprobiert und verworfen:
#   * FetchContent EXCLUDE_FROM_ALL  -- hilft NICHT. Der Fehler entsteht
#     beim Erzeugen der Export-Datei, nicht beim Bauen; nachgestellt und
#     bestaetigt mit CMake 3.28.
#   * CMAKE_SKIP_INSTALL_RULES       -- hilft, legt aber die install-Regeln
#     des GESAMTEN Projekts still. Zu grob.
#   * install() als leeres Makro     -- hilft, legt aber ebenfalls alles
#     Nachfolgende stillt; und der Befehl laesst sich danach NICHT wieder
#     herstellen (nachgemessen: _install zeigt nach der zweiten Definition
#     auf das leere Makro, nicht auf den eingebauten Befehl).
# Deshalb dieser Weg: install() bleibt voll funktionsfaehig, es wird nur
# ein bereits eingetragenes Ziel NICHT ein zweites Mal in denselben
# Export-Satz aufgenommen.
#
# Dasselbe Muster tritt bei libwebp (WebPTargets) und mbedTLS
# (MbedTLSTargets) auf.
#
# ---------------------------------------------------------------------------
# ACHTUNG, HIER LAG EIN FEHLER -- NICHT WIEDER AUF CACHE UMSTELLEN:
# Die erste Fassung merkte sich die eingetragenen Ziele in einer
# CACHE-INTERNAL-Variablen. Die ueberlebt aber in der CMakeCache.txt. Beim
# ZWEITEN Konfigurieren galt dadurch alles als schon eingetragen, JEDER
# install(TARGETS ...)-Aufruf fiel weg, der Export-Satz entstand nie:
#     CMake Error: INSTALL(EXPORT) given unknown export "libssh2-targets"
#     CMake Error: INSTALL(EXPORT) given unknown export "WebPTargets"
# Erkennbar daran, dass die Wache sogar 'libssh2_static' als "bereits
# vorhanden" meldete -- innerhalb eines Laufs unmoeglich.
#
# Der Zustand gehoert in eine GLOBAL PROPERTY: gilt fuer den ganzen
# Konfigurationslauf und ueber Verzeichnisgrenzen hinweg (was eine
# gewoehnliche Variable nicht leistet), wird aber NICHT gespeichert und
# startet bei jedem Lauf frisch.
#
# Notmassnahme, kein Ersatz fuer die Ursache: die Meldung nennt den Satz,
# in dem die Doppelung entsteht. Dort gehoert sie behoben, dann kann
# dieses Modul wieder raus.
# ---------------------------------------------------------------------------

if (COMMAND _install)
    return()   # schon aktiv
endif()

# Alle Schluesselwoerter, die auf die Zielliste von install(TARGETS ...)
# folgen koennen. Was davor steht, sind Zielnamen.
set(_XBM_INSTALL_KEYWORDS
    EXPORT ARCHIVE LIBRARY RUNTIME OBJECTS FRAMEWORK BUNDLE
    PRIVATE_HEADER PUBLIC_HEADER RESOURCE FILE_SET CXX_MODULES_BOM
    INCLUDES DESTINATION PERMISSIONS CONFIGURATIONS COMPONENT
    NAMELINK_COMPONENT OPTIONAL EXCLUDE_FROM_ALL NAMELINK_ONLY
    NAMELINK_SKIP RUNTIME_DEPENDENCY_SET RUNTIME_DEPENDENCIES
    CACHE_PREFIX)

macro(install)
    set(_xbm_a "${ARGV}")
    set(_xbm_first "")
    if (_xbm_a)
        list(GET _xbm_a 0 _xbm_first)
    endif()

    if (_xbm_first STREQUAL "TARGETS")
        # --- Export-Satz und Zielliste herausloesen ---
        set(_xbm_set "")
        set(_xbm_targets "")
        set(_xbm_intargets TRUE)
        set(_xbm_i 0)
        list(LENGTH _xbm_a _xbm_n)
        while (_xbm_i LESS _xbm_n)
            list(GET _xbm_a ${_xbm_i} _xbm_tok)
            if (_xbm_i GREATER 0)
                if (_xbm_tok IN_LIST _XBM_INSTALL_KEYWORDS)
                    set(_xbm_intargets FALSE)
                    if (_xbm_tok STREQUAL "EXPORT")
                        math(EXPR _xbm_j "${_xbm_i} + 1")
                        if (_xbm_j LESS _xbm_n)
                            list(GET _xbm_a ${_xbm_j} _xbm_set)
                        endif()
                    endif()
                elseif (_xbm_intargets)
                    list(APPEND _xbm_targets "${_xbm_tok}")
                endif()
            endif()
            math(EXPR _xbm_i "${_xbm_i} + 1")
        endwhile()

        if (_xbm_set AND _xbm_targets)
            # Zustand je LAUF (siehe Kopfkommentar), nicht im Cache.
            get_property(_xbm_seen GLOBAL PROPERTY "XBM_EXPORTSET_${_xbm_set}")
            set(_xbm_drop "")
            foreach (_xbm_t IN LISTS _xbm_targets)
                if (_xbm_t IN_LIST _xbm_seen)
                    list(APPEND _xbm_drop "${_xbm_t}")
                else()
                    list(APPEND _xbm_seen "${_xbm_t}")
                endif()
            endforeach()
            set_property(GLOBAL PROPERTY "XBM_EXPORTSET_${_xbm_set}" "${_xbm_seen}")
            if (_xbm_drop)
                message(STATUS
                    "Export-Wache: '${_xbm_drop}' steht bereits im Satz "
                    "'${_xbm_set}' -- zweiter Eintrag uebergangen.")
                set_property(GLOBAL APPEND PROPERTY XBM_EXPORTGUARD_HITS
                             "${_xbm_set}")
                # Alle Ziele schon drin -> Aufruf faellt ganz weg. Der Satz
                # EXISTIERT dann bereits (vom ersten Aufruf angelegt), das
                # spaetere install(EXPORT ...) findet ihn also.
                list(LENGTH _xbm_drop _xbm_nd)
                list(LENGTH _xbm_targets _xbm_nt)
                if (_xbm_nd EQUAL _xbm_nt)
                    set(_xbm_a "")
                else()
                    foreach (_xbm_t IN LISTS _xbm_drop)
                        list(REMOVE_ITEM _xbm_a "${_xbm_t}")
                    endforeach()
                endif()
            endif()
        endif()
    endif()

    if (_xbm_a)
        _install(${_xbm_a})
    endif()
endmacro()

# VERSIONSKENNUNG in der Meldung: so steht im Bauprotokoll, WELCHE Fassung
# gelaufen ist. Die erste (v1) hielt ihren Zustand im CMake-Cache und
# zerlegte damit jeden zweiten Konfigurationslauf -- ohne Kennung war das
# im Log nicht von der funktionierenden Fassung zu unterscheiden.
message(STATUS "Export-Wache v2 aktiv (laufweiter Zustand, kein Cache)")

# ---------------------------------------------------------------------------
# Abschlussbericht am Ende des Konfigurationslaufs. Ohne ihn muss man die
# Treffer im Protokoll zusammensuchen; mit ihm steht in einer Zeile, ob die
# Wache ueberhaupt etwas zu tun hatte -- und wenn ja, wo die Ursache sitzt.
# ---------------------------------------------------------------------------
function(xbm_export_guard_report)
    get_property(_sets GLOBAL PROPERTY XBM_EXPORTGUARD_HITS)
    if (_sets)
        list(REMOVE_DUPLICATES _sets)
        message(STATUS "Export-Wache v2: Doppelungen abgefangen in: ${_sets}")
        message(STATUS "  Das ist eine Notmassnahme. Die Ursache sitzt dort, "
                       "wo diese Saetze befuellt werden (vermutlich "
                       "cmake/net_deps.cmake).")
    else()
        message(STATUS "Export-Wache v2: keine Doppelungen -- "
                       "das Modul wird nicht mehr gebraucht.")
    endif()
endfunction()
