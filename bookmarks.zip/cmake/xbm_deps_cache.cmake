# ---------------------------------------------------------------------------
# cmake/xbm_deps_cache.cmake -- den FetchContent-Cache je Toolchain trennen.
#
# WAS SCHIEFGING
# Bisher stand in der CMakeLists:
#     set(FETCHCONTENT_BASE_DIR "${CMAKE_SOURCE_DIR}/.deps-cache" ...)
# EIN Ordner fuer ALLE drei Bauwerke. FetchContent legt darunter aber nicht
# nur die heruntergeladenen Quellen ab (<name>-src), sondern auch das
# KONFIGURIERTE Bauwerk (<name>-build) samt erzeugter config.h und
# CMakeCache.txt. Und die sind toolchain-spezifisch.
#
# Beobachtete Folge im Linux-Log:
#     .deps-cache/librsync_android-build/src/config.h
# wurde von der Windows-Toolchain erzeugt, die <io.h> vorfand und
# HAVE_IO_H setzte. Der Linux-Lauf nahm dieselbe config.h mit
# /usr/bin/cc -- und scheiterte an
#     fileutil.c:47: fatal error: io.h: No such file or directory
# Das sieht wie ein Fehler in librsync aus, ist aber schlicht die
# Konfiguration der falschen Plattform.
#
# Und im Android-Log:
#     current CMakeCache.txt directory /home/build/bookmarks/.deps-cache/...
#     is different than /home/user/MRTN/m/c/bookmarks/.deps-cache/...
# Ein CMakeCache.txt enthaelt ABSOLUTE Pfade. Wird das Projekt verschoben
# oder der Cache auf eine andere Maschine kopiert, ist er unbrauchbar.
#
# WAS SICH AENDERT
#   .deps-cache/linux/    .deps-cache/windows/    .deps-cache/android-arm64/
# Die Quellen werden dadurch je Plattform einmal geholt statt einmal
# insgesamt -- das ist der Preis. Er faellt nur beim ERSTEN Bauen je
# Plattform an, der Cache bleibt danach bestehen. Korrektheit ist das
# wert: die Alternative sind Fehler, die nach einem Bibliotheksfehler
# aussehen und es nicht sind.
#
# Zusaetzlich merkt sich dieses Modul den Projektpfad und meldet
# VERSTAENDLICH, wenn der Cache von woanders stammt -- statt der kryptischen
# FetchContent-Meldung mitten im Konfigurationslauf.
# ---------------------------------------------------------------------------

# --- Kennung der Toolchain --------------------------------------------------
if (ANDROID)
    set(_xbm_tag "android")
    if (CMAKE_ANDROID_ARCH_ABI)
        set(_xbm_tag "android-${CMAKE_ANDROID_ARCH_ABI}")
    elseif (ANDROID_ABI)
        set(_xbm_tag "android-${ANDROID_ABI}")
    endif()
elseif (CMAKE_SYSTEM_NAME STREQUAL "Windows")
    set(_xbm_tag "windows")
elseif (APPLE)
    set(_xbm_tag "macos")
else()
    set(_xbm_tag "linux")
endif()

set(XBM_DEPS_CACHE_ROOT "${CMAKE_SOURCE_DIR}/.deps-cache")
set(XBM_DEPS_CACHE_DIR  "${XBM_DEPS_CACHE_ROOT}/${_xbm_tag}")

# --- Umzugs-/Fremdkopie-Erkennung ------------------------------------------
# CMakeCache.txt-Dateien im Cache enthalten absolute Pfade. Stimmt der
# hinterlegte Projektpfad nicht mehr, ist der Cache wertlos: lieber jetzt
# klar sagen als spaeter an unverstaendlicher Stelle scheitern.
set(_xbm_stamp "${XBM_DEPS_CACHE_DIR}/.projektpfad")
if (EXISTS "${_xbm_stamp}")
    file(READ "${_xbm_stamp}" _xbm_old)
    string(STRIP "${_xbm_old}" _xbm_old)
    if (NOT _xbm_old STREQUAL "${CMAKE_SOURCE_DIR}")
        message(WARNING
            "Abhaengigkeits-Cache stammt aus einem anderen Projektpfad:\n"
            "    hinterlegt: ${_xbm_old}\n"
            "    jetzt:      ${CMAKE_SOURCE_DIR}\n"
            "In den CMakeCache.txt-Dateien darin stehen absolute Pfade, sie "
            "sind nicht umziehbar. Der Cache wird jetzt fuer diese "
            "Plattform geleert und neu geholt.")
        file(REMOVE_RECURSE "${XBM_DEPS_CACHE_DIR}")
    endif()
endif()
file(MAKE_DIRECTORY "${XBM_DEPS_CACHE_DIR}")
file(WRITE "${_xbm_stamp}" "${CMAKE_SOURCE_DIR}\n")

# --- Alten, gemeinsamen Cache erkennen und darauf hinweisen -----------------
# Nach dem Umstieg liegen die alten, plattformvermischten Ordner noch da.
# Sie stoeren nicht, belegen aber Platz -- einmal darauf hinweisen genuegt.
file(GLOB _xbm_alt "${XBM_DEPS_CACHE_ROOT}/*-src" "${XBM_DEPS_CACHE_ROOT}/*-build")
if (_xbm_alt)
    list(LENGTH _xbm_alt _xbm_altn)
    message(STATUS
        "Hinweis: ${_xbm_altn} Ordner aus dem alten, plattformuebergreifenden "
        "Cache liegen noch unter ${XBM_DEPS_CACHE_ROOT}/ . Sie werden nicht "
        "mehr benutzt und koennen geloescht werden.")
endif()

set(FETCHCONTENT_BASE_DIR "${XBM_DEPS_CACHE_DIR}" CACHE PATH
    "FetchContent-Cache, je Toolchain getrennt" FORCE)
message(STATUS "Abhaengigkeits-Cache: ${FETCHCONTENT_BASE_DIR}")
