# net_deps.cmake -- libssh2 (fuer SFTP) und librsync (fuer Delta-Abgleich)
#
# EINBINDEN IM ANDROID-ZWEIG von CMakeLists.txt:
#
#     FetchContent_MakeAvailable(mbedtls)        # <- schon vorhanden
#     include(${CMAKE_CURRENT_SOURCE_DIR}/cmake/net_deps.cmake)
#     xbm_net_before_curl()                      # VOR dem curl-Block!
#     ...  FetchContent_Declare(curl_android ...)  set(...)  ...
#     FetchContent_MakeAvailable(curl_android)   # <- schon vorhanden
#     xbm_net_after_curl()                       # danach: librsync
#
# und beim Linken (im Android-Zweig, vor dem return()):
#     target_link_libraries(x_bookmark_manager PRIVATE rsync)
#
# WARUM DIE REIHENFOLGE ZAEHLT: curl sucht libssh2 WAEHREND seiner
# eigenen Konfiguration. Existiert das Target zu diesem Zeitpunkt noch
# nicht, baut curl sich ohne SFTP -- ohne Fehlermeldung. Genau dieselbe
# Falle wie damals bei pdfgen und curl.

include(FetchContent)

# ---------------------------------------------------------------------------
# VOR curl: libssh2 bauen und curl die noetigen Optionen vorgeben.
# ---------------------------------------------------------------------------
macro(xbm_net_before_curl)
    # --- libssh2 ---------------------------------------------------------
    set(BUILD_SHARED_LIBS  OFF CACHE BOOL "" FORCE)
    set(BUILD_EXAMPLES     OFF CACHE BOOL "" FORCE)
    set(BUILD_TESTING      OFF CACHE BOOL "" FORCE)
    set(ENABLE_ZLIB_COMPRESSION OFF CACHE BOOL "" FORCE)

    # IST UEBERHAUPT EIN BACKEND VERFUEGBAR?
    # Auf Android: mbedTLS aus dem FetchContent-Baum. Auf dem Desktop:
    # OpenSSL des Systems (Debian/Ubuntu: libssl-dev). Fehlt beides, wird
    # libssh2 UEBERSPRUNGEN statt den ganzen Build abzubrechen -- SFTP ist
    # ein Zusatzfeature, kein Grund, Linux und Windows lahmzulegen.
    set(XBM_SSH2 OFF)
    if (DEFINED mbedtls_SOURCE_DIR AND
        EXISTS "${mbedtls_SOURCE_DIR}/include/mbedtls/version.h")
        set(XBM_SSH2 ON)
    else()
        find_package(OpenSSL QUIET)
        if (OPENSSL_FOUND)
            set(XBM_SSH2 ON)
        else()
            message(STATUS "libssh2: kein OpenSSL gefunden -> SFTP "
                           "deaktiviert (Paket libssl-dev installieren, "
                           "um es einzuschalten)")
        endif()
    endif()

    # KRYPTO-BACKEND JE NACH PLATTFORM WAEHLEN.
    # [Vorher stand hier fest "mbedTLS". Das stimmt NUR fuer Android:
    #  dort wird mbedTLS per FetchContent gebaut. Auf Linux/Windows gibt
    #  es kein mbedtls_SOURCE_DIR -- MBEDTLS_INCLUDE_DIR wurde damit zu
    #  "/include", und libssh2 brach ab mit
    #  "mbedtls/version.h: No such file or directory".]
    if (DEFINED mbedtls_SOURCE_DIR AND
        EXISTS "${mbedtls_SOURCE_DIR}/include/mbedtls/version.h")
        set(CRYPTO_BACKEND "mbedTLS" CACHE STRING "" FORCE)
        # Kein Config-Paket vorhanden (FetchContent installiert nichts),
        # deshalb die Pfade direkt vorgeben:
        set(MBEDTLS_INCLUDE_DIR "${mbedtls_SOURCE_DIR}/include"
            CACHE PATH "" FORCE)
        set(MBEDCRYPTO_LIBRARY mbedcrypto CACHE STRING "" FORCE)
        message(STATUS "libssh2: Krypto-Backend mbedTLS (FetchContent)")
    else()
        # Desktop: OpenSSL des Systems. Fehlt es, baut libssh2 gar nicht --
        # dann lieber verstaendlich abbrechen als mit falschen Pfaden.
        set(CRYPTO_BACKEND "OpenSSL" CACHE STRING "" FORCE)
        message(STATUS "libssh2: Krypto-Backend OpenSSL (System)")
    endif()

    if (XBM_SSH2)
        FetchContent_Declare(libssh2_android
            GIT_REPOSITORY https://github.com/libssh2/libssh2.git
            GIT_TAG        libssh2-1.11.1
            GIT_SHALLOW    ON)
        FetchContent_MakeAvailable(libssh2_android)

        # EXPORT-SET-FALLE:
        # libssh2 traegt seine Targets in ein install(EXPORT ...) UND in
        # ein Build-Tree-export() ein. CMake verlangt fuer BEIDE, dass
        # jede verlinkte Abhaengigkeit ebenfalls in irgendeinem Export
        # steht. Die Kette reicht dabei ueber mbedcrypto hinaus bis zu
        # dessen 3rdparty-Teilen everest und p256m:
        #   "install(EXPORT libssh2-targets) includes target mbedcrypto
        #    which requires target everest that is not in any export set"
        # Deshalb ALLE mbedTLS-Targets in beide Mechanismen aufnehmen --
        # ein Target darf in mehreren Exporten stehen, installiert wird
        # dadurch nichts.
        set(_xbm_exp "")
        foreach (t mbedcrypto mbedx509 mbedtls everest p256m
                   builtin ${MBEDTLS_TARGET_PREFIX}mbedcrypto)
            if (TARGET ${t})
                install(TARGETS ${t} EXPORT libssh2-targets)
                list(APPEND _xbm_exp ${t})
            endif()
        endforeach()
        if (_xbm_exp)
            # Doppelte raus: ${MBEDTLS_TARGET_PREFIX}mbedcrypto ist bei
            # leerem Prefix DERSELBE Name wie mbedcrypto -- export()
            # bricht dann ab: "given target mbedcrypto more than once".
            list(REMOVE_DUPLICATES _xbm_exp)
            export(TARGETS ${_xbm_exp}
                   FILE "${CMAKE_BINARY_DIR}/xbm_mbedtls_targets.cmake")
        endif()

        # curl findet libssh2 sonst nicht        # curl findet libssh2 sonst nicht (kein find_package moeglich,
        # weil nichts installiert wurde): Pfade direkt vorgeben.
        set(LIBSSH2_INCLUDE_DIR "${libssh2_android_SOURCE_DIR}/include"
            CACHE PATH "" FORCE)
        set(LIBSSH2_LIBRARY libssh2_static CACHE STRING "" FORCE)
    endif()

    # --- curl-Optionen ---------------------------------------------------
    # HTTP_ONLY MUSS AUS: Es schaltet ALLE Protokolle ausser HTTP/HTTPS
    # ab -- also auch SFTP und SMTP. (Mit HTTP_ONLY=ON kann auch der
    # Mailversand aus gmail_send.c nicht funktionieren; curl meldet dann
    # "Unsupported protocol".)
    set(HTTP_ONLY        OFF CACHE BOOL "" FORCE)
    set(CURL_USE_LIBSSH2 ${XBM_SSH2} CACHE BOOL "" FORCE)
    # Alles Ungenutzte einzeln abschalten, damit die Bibliothek klein
    # bleibt -- das war ja der Sinn von HTTP_ONLY.
    foreach(p FTP TFTP TELNET DICT LDAP LDAPS FILE POP3 IMAP MQTT
              RTSP GOPHER SMB)
        set(CURL_DISABLE_${p} ON CACHE BOOL "" FORCE)
    endforeach()
    set(CURL_DISABLE_SMTP OFF CACHE BOOL "" FORCE)   # Mailversand
    set(CURL_DISABLE_HTTP OFF CACHE BOOL "" FORCE)
endmacro()

# ---------------------------------------------------------------------------
# NACH curl: librsync.
# ---------------------------------------------------------------------------
macro(xbm_net_after_curl)
    # rdiff (das CLI) braucht popt -- gibt es auf Android nicht, und wir
    # brauchen nur die Bibliothek.
    set(BUILD_RDIFF   OFF CACHE BOOL "" FORCE)
    set(ENABLE_TRACE  OFF CACHE BOOL "" FORCE)
    # Testprogramme sparen: librsync baut sonst netint_test & Co. mit.
    set(BUILD_TESTING OFF CACHE BOOL "" FORCE)
    set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
    # librsync nutzt optional libb2 fuer BLAKE2; ohne libb2 nimmt es die
    # mitgelieferte Fassung. Auf Android ist libb2 nicht vorhanden --
    # die Suche wuerde nur Zeit kosten.
    set(USE_LIBB2 OFF CACHE BOOL "" FORCE)
    FetchContent_Declare(librsync_android
        GIT_REPOSITORY https://github.com/librsync/librsync.git
        GIT_TAG        v2.3.4
        GIT_SHALLOW    ON)
    FetchContent_MakeAvailable(librsync_android)
    # Der Header liegt im Quellbaum, das erzeugte librsync_export.h im
    # Bauverzeichnis -- beide Pfade werden gebraucht.
    target_include_directories(rsync INTERFACE
        "${librsync_android_SOURCE_DIR}/src"
        "${librsync_android_BINARY_DIR}/src")
endmacro()
