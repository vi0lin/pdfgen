# ---------------------------------------------------------------------------
# cmake/xbm_data_post.cmake -- laeuft im Skriptmodus (cmake -P) nach dem
# Kopieren der Datenordner. Erwartet:
#   XBM_DATA_DIR   Zielordner der Daten
#   XBM_PLATFORM   linux | windows | android | macos
#   XBM_BIN_DIR    Bauwerk-Stamm (dort liegt die Binaerdatei)
# ---------------------------------------------------------------------------

if (XBM_PLATFORM STREQUAL "windows")
    # Windows sucht Programmbibliotheken IM PROGRAMMORDNER, nicht in
    # Unterordnern. Alles, was als .dll in data/windows/ liegt, landet
    # deshalb zusaetzlich direkt neben der .exe. Die Kopie im data/-Ordner
    # bleibt bestehen -- sie stoert nicht und haelt die Struktur einheitlich.
    file(GLOB _dlls "${XBM_DATA_DIR}/*.dll")
    foreach(_d ${_dlls})
        get_filename_component(_n "${_d}" NAME)
        configure_file("${_d}" "${XBM_BIN_DIR}/${_n}" COPYONLY)
        message(STATUS "  DLL neben die exe: ${_n}")
    endforeach()
endif()

if (XBM_PLATFORM STREQUAL "android")
    # index.txt: ALLE relativen Pfade unter data/, eine je Zeile.
    # Begruendung siehe xbm_data.cmake -- der Asset-Manager kann keine
    # Verzeichnisse aufzaehlen, also liefern wir die Liste mit.
    file(GLOB_RECURSE _all RELATIVE "${XBM_DATA_DIR}" "${XBM_DATA_DIR}/*")
    set(_lines "")
    foreach(_f ${_all})
        if (NOT IS_DIRECTORY "${XBM_DATA_DIR}/${_f}")
            if (NOT _f STREQUAL "index.txt")
                string(APPEND _lines "${_f}\n")
            endif()
        endif()
    endforeach()
    file(WRITE "${XBM_DATA_DIR}/index.txt" "${_lines}")
    string(REGEX MATCHALL "\n" _nl "${_lines}")
    list(LENGTH _nl _count)
    message(STATUS "  Android-Asset-Index: ${_count} Dateien")
endif()
