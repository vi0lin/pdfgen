# ---------------------------------------------------------------------------
# BAUSTEMPEL, DER SICH WIRKLICH AENDERT
#
# [__DATE__ und __TIME__ setzt der Compiler beim UEBERSETZEN ein. Wird
#  eine Datei nicht neu uebersetzt -- und das ist bei einem
#  inkrementellen Bau der Normalfall -- bleibt der alte Stempel darin
#  stehen. Deshalb zeigte das APK noch den 29. August, obwohl es heute
#  gepackt wurde.
#
#  Hier entsteht bei JEDEM Bau eine winzige Datei mit dem aktuellen
#  Zeitpunkt. Nur SIE wird neu uebersetzt (ein paar Millisekunden), der
#  Rest bleibt unangetastet. So bleibt der inkrementelle Bau schnell und
#  der Stempel trotzdem ehrlich.]
# ---------------------------------------------------------------------------

# Der eigentliche Erzeuger -- laeuft als eigener Schritt bei jedem Bau.
set(XBM_BUILDINFO_WRITER "${CMAKE_BINARY_DIR}/xbm_write_buildinfo.cmake")
file(WRITE "${XBM_BUILDINFO_WRITER}" [=[
# [Der Inhalt wird zeilenweise zusammengesetzt statt mit \n in einem
#  String: in CMake muesste man dort jedes Semikolon maskieren, und die
#  Maskierung landet dann woertlich in der C++-Datei
#      const char* const XBM_BUILD_ZEIT = "..."\;
#      error: stray '\' in program
#  Mit einer Liste und file(WRITE) je Zeile gibt es das Problem nicht.]
string(TIMESTAMP JETZT "%Y-%m-%d %H:%M:%S" UTC)
set(Z1 "// erzeugt von xbm_buildinfo.cmake -- nicht von Hand aendern")
set(Z2 "extern const char* const XBM_BUILD_ZEIT;")
set(Z3 "const char* const XBM_BUILD_ZEIT = \"${JETZT} UTC\";")
set(INHALT "${Z1}\n${Z2}\n${Z3}\n")
if(EXISTS "${AUSGABE}")
  file(READ "${AUSGABE}" ALT)
else()
  set(ALT "")
endif()
# Nur schreiben, wenn sich der Inhalt aendert.
# [Sonst loeste jeder Bau eine Neuuebersetzung aus -- auch wenn es
#  nichts zu tun gibt. Die Sekunde im Stempel reicht als Unterschied.]
if(NOT ALT STREQUAL INHALT)
  file(WRITE "${AUSGABE}" "${INHALT}")
endif()
]=])

set(XBM_BUILDINFO_CPP "${CMAKE_BINARY_DIR}/xbm_buildinfo.cpp")

add_custom_target(xbm_buildinfo ALL
  COMMAND ${CMAKE_COMMAND} -DAUSGABE=${XBM_BUILDINFO_CPP}
                           -P ${XBM_BUILDINFO_WRITER}
  BYPRODUCTS ${XBM_BUILDINFO_CPP}
  COMMENT "Baustempel wird erneuert"
  VERBATIM)

# Damit die Datei beim ersten Konfigurieren schon existiert.
if(NOT EXISTS "${XBM_BUILDINFO_CPP}")
  execute_process(COMMAND ${CMAKE_COMMAND} -DAUSGABE=${XBM_BUILDINFO_CPP}
                                           -P ${XBM_BUILDINFO_WRITER})
endif()

# xbm_buildinfo_anhaengen(<ziel>)
#
# [WARUM DIE APK DEN 09:31-STEMPEL ZEIGTE, OBWOHL DEB UND EXE STIMMTEN:
#  build_apk.sh setzt ccache als Compiler-Launcher
#  (-DCMAKE_CXX_COMPILER_LAUNCHER=ccache), build.sh (deb/exe) tut das
#  NICHT. Der Erzeuger oben schreibt xbm_buildinfo.cpp bei JEDEM Bau neu
#  -- das ist bestaetigt, die Zeile "Baustempel wird erneuert" steht in
#  jedem Log. Trotzdem kann ccache dafuer einen ALTEN Treffer liefern:
#  im "direct mode" (Vorgabe an) benutzt ccache zuerst einen schnellen
#  Abgleich ueber Dateigroesse/Zeitstempel-Muster, bevor es den Inhalt
#  wirklich neu hasht -- bei einer winzigen, sich nur in einer
#  Textstelle aendernden Datei kann dieser Kurzweg danebengreifen.
#  Deshalb bekommt DIESE eine Datei ein EIGENES Objekt-Ziel mit
#  ausdruecklich GELEERTEM Compiler-Launcher: das uebersteuert den
#  global gesetzten ccache-Launcher gezielt fuer genau diese
#  Uebersetzungseinheit, unabhaengig davon, welche der beiden moeglichen
#  Ursachen (ccache-Fehltreffer oder etwas anderes) tatsaechlich
#  zutrifft -- diese Datei wird garantiert IMMER frisch uebersetzt.]
function(xbm_buildinfo_anhaengen ziel)
  if(NOT TARGET xbm_buildinfo_obj)
    add_library(xbm_buildinfo_obj OBJECT "${XBM_BUILDINFO_CPP}")
    add_dependencies(xbm_buildinfo_obj xbm_buildinfo)
    set_target_properties(xbm_buildinfo_obj PROPERTIES
      CXX_COMPILER_LAUNCHER ""
      C_COMPILER_LAUNCHER   "")
  endif()
  target_sources(${ziel} PRIVATE $<TARGET_OBJECTS:xbm_buildinfo_obj>)
  add_dependencies(${ziel} xbm_buildinfo_obj)
endfunction()
