# ---------------------------------------------------------------------------
# cmake/xbm_model.cmake -- das Whisper-Modell einmalig beschaffen und
#                          in den Datenbaum legen.
#
# WOHIN
#   data/shared/models/ggml-<name>.bin
# Von dort nimmt es xbm_data.cmake mit:
#   Desktop -> <build>/data/models/    (also neben der ausfuehrbaren Datei)
#   Android -> ins APK, beim Start ausgepackt nach <intern>/data/models/
# Beide Orte durchsucht xbm_audio.cpp bereits.
#
# ---------------------------------------------------------------------------
# WARUM NICHT EINFACH INS REPOSITORY LEGEN
# Das Modell ist 75 bis 148 MB. Eine solche Datei in die Versions-
# verwaltung zu legen, blaeht jeden Klon dauerhaft auf -- git speichert
# Binaerdateien vollstaendig und fuer immer, auch nach dem Loeschen.
# Deshalb wird sie hier BESCHAFFT statt mitgeliefert, und data/shared/models
# gehoert in die .gitignore:
#     data/shared/models/*.bin
#
# ---------------------------------------------------------------------------
# ACHTUNG APK-GROESSE
# Alles unter data/shared/ landet AUCH im APK. Mit ggml-base.bin waechst
# es um rund 148 MB -- Google Play laesst als APK ohnehin nur 100 MB zu
# (darueber braucht es ein App Bundle mit Asset Packs). Fuer Android ist
# deshalb "tiny" voreingestellt, fuer den Schreibtisch "base".
# Wer beides gleich haben will: -DXBM_MODEL=base.
# ---------------------------------------------------------------------------

if (ANDROID)
    set(_xbm_model_default "tiny")
else()
    set(_xbm_model_default "base")
endif()

set(XBM_MODEL "${_xbm_model_default}" CACHE STRING
    "Whisper-Modell: tiny | base | small | medium | none")
set_property(CACHE XBM_MODEL PROPERTY STRINGS tiny base small medium none)

# Zielort im Quellbaum -- xbm_data.cmake verteilt ihn weiter.
set(XBM_MODEL_DIR "${CMAKE_CURRENT_SOURCE_DIR}/data/shared/models")

if (XBM_MODEL STREQUAL "none")
    message(STATUS "Modell: keines (XBM_MODEL=none)")
    return()
endif()

set(_xbm_model_file "ggml-${XBM_MODEL}.bin")
set(_xbm_model_path "${XBM_MODEL_DIR}/${_xbm_model_file}")
set(_xbm_model_url
    "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/${_xbm_model_file}")

# Ungefaehre Groessen -- als PLAUSIBILITAETSPRUEFUNG, nicht als Pruefsumme.
# [Echte Pruefsummen waeren besser, aber ich kann sie hier nicht
#  verifizieren und moechte keine erfundenen Werte eintragen: eine falsche
#  Pruefsumme laesst einen KORREKTEN Download scheitern, und der Fehler
#  waere schwer zu deuten. Die Mindestgroesse faengt den haeufigen Fall ab
#  -- abgebrochener Download oder eine HTML-Fehlerseite unter dem Namen
#  der Datei.]
# [CMake erlaubt keinen Befehl in derselben Zeile wie if/elseif --
#  "Parse error. Expected a newline". Deshalb je eigene Zeile.]
if (XBM_MODEL STREQUAL "tiny")
    set(_xbm_min_mb 60)
elseif (XBM_MODEL STREQUAL "base")
    set(_xbm_min_mb 120)
elseif (XBM_MODEL STREQUAL "small")
    set(_xbm_min_mb 400)
elseif (XBM_MODEL STREQUAL "medium")
    set(_xbm_min_mb 1300)
else()
    set(_xbm_min_mb 10)
endif()
math(EXPR _xbm_min_bytes "${_xbm_min_mb} * 1024 * 1024")

# Schon da und plausibel gross? Dann nichts tun -- das ist der Normalfall
# bei jedem weiteren Bau.
set(_xbm_have FALSE)
if (EXISTS "${_xbm_model_path}")
    file(SIZE "${_xbm_model_path}" _xbm_have_size)
    if (_xbm_have_size GREATER_EQUAL _xbm_min_bytes)
        set(_xbm_have TRUE)
        math(EXPR _xbm_have_mb "${_xbm_have_size} / 1048576")
        message(STATUS "Modell: vorhanden (${_xbm_model_file}, ${_xbm_have_mb} MB)")
    else()
        message(WARNING "Modell ${_xbm_model_file} ist zu klein "
                        "(${_xbm_have_size} Byte) -- vermutlich ein "
                        "abgebrochener Download. Wird neu geholt.")
        file(REMOVE "${_xbm_model_path}")
    endif()
endif()

if (NOT _xbm_have)
    file(MAKE_DIRECTORY "${XBM_MODEL_DIR}")
    message(STATUS "Modell: hole ${_xbm_model_file} (~${_xbm_min_mb} MB)...")
    message(STATUS "  ${_xbm_model_url}")
    # In eine NEBENDATEI laden und erst nach der Pruefung umbenennen.
    # [Sonst bleibt bei einem Abbruch eine halbe Datei unter dem richtigen
    #  Namen liegen, und der naechste Lauf haelt sie fuer gueltig.]
    set(_xbm_tmp "${_xbm_model_path}.teil")
    file(DOWNLOAD "${_xbm_model_url}" "${_xbm_tmp}"
         SHOW_PROGRESS
         INACTIVITY_TIMEOUT 60
         STATUS _xbm_dl_status
         LOG     _xbm_dl_log)
    list(GET _xbm_dl_status 0 _xbm_dl_code)
    list(GET _xbm_dl_status 1 _xbm_dl_msg)

    set(_xbm_ok FALSE)
    if (_xbm_dl_code EQUAL 0 AND EXISTS "${_xbm_tmp}")
        file(SIZE "${_xbm_tmp}" _xbm_dl_size)
        if (_xbm_dl_size GREATER_EQUAL _xbm_min_bytes)
            file(RENAME "${_xbm_tmp}" "${_xbm_model_path}")
            math(EXPR _xbm_dl_mb "${_xbm_dl_size} / 1048576")
            message(STATUS "Modell: geholt (${_xbm_dl_mb} MB)")
            set(_xbm_ok TRUE)
        else()
            message(WARNING "Modell-Download zu klein (${_xbm_dl_size} Byte) "
                            "-- vermutlich eine Fehlerseite statt der Datei.")
        endif()
    endif()
    file(REMOVE "${_xbm_tmp}")

    if (NOT _xbm_ok)
        # KEIN FEHLER, nur eine Warnung.
        # [Ein Bau soll nicht daran scheitern, dass gerade kein Netz da
        #  ist. Die App laeuft ohne Modell einwandfrei -- sie nimmt auf,
        #  spielt ab und sagt in der Statuszeile, dass nicht transkribiert
        #  wird. Ein harter Fehler wuerde jeden Bau ohne Internet
        #  blockieren, auch wenn niemand transkribieren will.]
        message(WARNING
            "Modell konnte nicht geholt werden (${_xbm_dl_msg}).\n"
            "Der Bau laeuft weiter, die App transkribiert dann nicht.\n"
            "Von Hand nachholen:\n"
            "  curl -L -o \"${_xbm_model_path}\" ${_xbm_model_url}\n"
            "Oder abschalten mit -DXBM_MODEL=none")
    endif()
endif()
