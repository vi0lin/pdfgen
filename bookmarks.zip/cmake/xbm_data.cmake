# ---------------------------------------------------------------------------
# cmake/xbm_data.cmake -- die Datenordner in die Bauwerke bringen.
#
# PROJEKTSEITE          ->  ZIEL
#   data/shared/            alle Plattformen
#   data/<plattform>/       nur dort, UEBER shared gelegt
#
#   Linux/Windows:  ${CMAKE_BINARY_DIR}/data
#                   (also ./linux/data bzw. ./windows/data -- derselbe
#                    Ordner, in dem auch die Binaerdatei entsteht)
#   Windows extra:  data/windows/*.dll zusaetzlich NEBEN die .exe
#   Android:        Staging nach ${CMAKE_BINARY_DIR}/assets/data, von dort
#                   packt es das APK; zur Laufzeit entpackt xbm_paths.cpp
#                   nach <internalDataPath>/data.
#
# WARUM ZUR BAUZEIT UND NICHT ZUR KONFIGURATIONSZEIT: mit
# configure_file/file(COPY) beim Konfigurieren bemerkt niemand, wenn du
# spaeter eine .txt aenderst -- du muesstest jedes Mal cmake neu aufrufen.
# Das hier haengt an einem Ziel und laeuft bei jedem Bauen.
#
# WARUM index.txt (nur Android): der Asset-Manager im NDK kann
# VERZEICHNISSE NICHT AUFZAEHLEN (AAssetDir_getNextFileName liefert nur
# Dateien der einen Ebene und ueberspringt Unterordner). Ohne eine Liste
# aller relativen Pfade muesste der Code jeden Unterordner fest kennen.
# Deshalb erzeugen wir sie beim Bauen.
# ---------------------------------------------------------------------------

function(xbm_setup_data TARGET_NAME)
    set(_src "${CMAKE_CURRENT_SOURCE_DIR}/data")
    if (NOT IS_DIRECTORY "${_src}")
        message(STATUS "xbm_data: kein data/-Ordner im Projekt -- uebersprungen")
        return()
    endif()

    if (ANDROID)
        set(_platform "android")
        set(_dst "${CMAKE_BINARY_DIR}/assets/data")
    elseif (CMAKE_SYSTEM_NAME STREQUAL "Windows")
        set(_platform "windows")
        set(_dst "${CMAKE_BINARY_DIR}/data")
    elseif (APPLE)
        set(_platform "macos")
        set(_dst "${CMAKE_BINARY_DIR}/data")
    else()
        set(_platform "linux")
        set(_dst "${CMAKE_BINARY_DIR}/data")
    endif()

    message(STATUS "xbm_data: ${_src}/{shared,${_platform}} -> ${_dst}")

    # Abhaengigkeiten sammeln, damit ein geaenderter Inhalt neu kopiert wird.
    #
    # CONFIGURE_DEPENDS IST HIER PFLICHT, NICHT KOSMETIK: ohne das laeuft
    # der Glob nur beim Konfigurieren. Legst du spaeter eine neue Datei in
    # data/ ab, steht sie in keiner Abhaengigkeitsliste, der Zeitstempel
    # gilt als aktuell und der Kopierschritt wird UEBERSPRUNGEN -- die
    # Datei taucht nie im Bauwerk auf, und niemand sagt warum. (Genau so
    # gesehen beim Durchspielen.) Mit CONFIGURE_DEPENDS prueft CMake den
    # Glob bei JEDEM Bauen neu. Das Projekt nutzt dieses Verfahren
    # ohnehin schon an anderer Stelle (VerifyGlobs.cmake).
    file(GLOB_RECURSE _files CONFIGURE_DEPENDS
         "${_src}/shared/*" "${_src}/${_platform}/*")

    # Nur vorhandene Ordner kopieren: 'cmake -E copy_directory' bricht bei
    # fehlender Quelle ab (z.B. kein data/android/). Legst du den Ordner
    # spaeter an, loest der CONFIGURE_DEPENDS-Glob oben ein Neukonfigurieren
    # aus, und er wird hier aufgenommen.
    set(_copy_cmds)
    foreach(_part shared ${_platform})
        if (IS_DIRECTORY "${_src}/${_part}")
            list(APPEND _copy_cmds COMMAND ${CMAKE_COMMAND} -E copy_directory
                 "${_src}/${_part}" "${_dst}")
        endif()
    endforeach()

    set(_stamp "${CMAKE_BINARY_DIR}/xbm_data.stamp")
    add_custom_command(
        OUTPUT  "${_stamp}"
        COMMENT "Datenordner verteilen (shared + ${_platform})"
        COMMAND ${CMAKE_COMMAND} -E make_directory "${_dst}"
        # shared zuerst, danach die Plattform darueber -- so gewinnt bei
        # gleichem Dateinamen die plattformspezifische Fassung.
        ${_copy_cmds}
        COMMAND ${CMAKE_COMMAND}
                -DXBM_DATA_DIR=${_dst}
                -DXBM_PLATFORM=${_platform}
                -DXBM_BIN_DIR=${CMAKE_BINARY_DIR}
                -P "${CMAKE_CURRENT_SOURCE_DIR}/cmake/xbm_data_post.cmake"
        COMMAND ${CMAKE_COMMAND} -E touch "${_stamp}"
        DEPENDS ${_files}
        VERBATIM)

    add_custom_target(${TARGET_NAME}_data DEPENDS "${_stamp}")
    add_dependencies(${TARGET_NAME} ${TARGET_NAME}_data)
endfunction()
