# (rm -rf build-windows; cmake -B build-windows -S . -DCMAKE_TOOLCHAIN_FILE=toolchain-mingw-clang.cmake ) 2>&1 | tee error.txt && sudo mv error.txt $ftp/Downloads/bm/ && sudo chmod u+rw $ftp/Downloads/bm/error.txt && sudo chown ftpuser:user $ftp/Downloads/bm/error.txt

# cmake -B build-windows -S . -DCMAKE_TOOLCHAIN_FILE=toolchain-mingw-clang.cmake 2>&1 | tee error.txt && sudo mv error.txt $ftp/Downloads/bm/ && sudo chmod u+rw $ftp/Downloads/bm/error.txt && sudo chown ftpuser:user $ftp/Downloads/bm/error.txt

# (find / -iname "libgcc.a" 2>/dev/null; find / -iname "libgcc_eh.a" 2>/dev/null; update-alternatives --display x86_64-w64-mingw32-gcc;) 2>&1 | tee error.txt; sudo mv error.txt $ftp/Downloads/bm/ && sudo chmod u+rw $ftp/Downloads/bm/error.txt && sudo chown ftpuser:user $ftp/Downloads/bm/error.txt


# toolchain-mingw-clang.cmake
#
# Cross-compile x_bookmark_manager for Windows (x86_64) from Linux, using
# clang targeting the MinGW-w64 (GNU) ABI -- NOT the MSVC ABI. This avoids
# needing a staged copy of the Microsoft Windows SDK/CRT (which the MSVC-ABI
# route requires via tools like `xwin`).
#
# Prerequisites (Debian/Ubuntu):
#   sudo apt install clang mingw-w64
#
# You also need a Windows (mingw-w64) build of GLFW available -- either:
#   (a) a prebuilt mingw-w64 GLFW package, or
#   (b) build GLFW yourself with this same toolchain file, or
#   (c) let CMake/FetchContent build it as part of this project (if your
#       top-level CMakeLists already does this via HELLOIMGUI_DOWNLOAD_GLFW_IF_NEEDED,
#       it should "just work" since FetchContent will build glfw with
#       whatever compiler this toolchain file selects).
#
# Usage:
#   cmake -B build-windows -S . \
#       -DCMAKE_TOOLCHAIN_FILE=toolchain-mingw-clang.cmake \
#       -DCMAKE_BUILD_TYPE=Release
#   cmake --build build-windows -j

set(CMAKE_SYSTEM_NAME Windows)
set(CMAKE_SYSTEM_PROCESSOR x86_64)

set(MINGW_TRIPLE x86_64-w64-mingw32)

# Use clang/clang++ directly with --target=, rather than relying on a
# triple-prefixed wrapper binary (e.g. x86_64-w64-mingw32-clang++) which may
# not exist unless you've installed something like wclang. This works with
# a stock `clang`/`mingw-w64` apt install.
set(CMAKE_C_COMPILER   clang)
set(CMAKE_CXX_COMPILER clang++)

set(CMAKE_C_COMPILER_TARGET   ${MINGW_TRIPLE})
set(CMAKE_CXX_COMPILER_TARGET ${MINGW_TRIPLE})

# Tell clang where the mingw-w64 sysroot (headers/libs for the Windows GNU
# ABI) lives. This is the standard install location on Debian/Ubuntu after
# `apt install mingw-w64`; adjust if your distro puts it elsewhere.
set(MINGW_SYSROOT /usr/${MINGW_TRIPLE})
set(CMAKE_SYSROOT ${MINGW_SYSROOT})

# Use the mingw linker driver semantics (so -lXXX resolves .a/.dll.a files,
# CRT startup objects are linked correctly, .exe suffix is applied, etc).
set(CMAKE_C_FLAGS_INIT   "--target=${MINGW_TRIPLE} --sysroot=${MINGW_SYSROOT}")
set(CMAKE_CXX_FLAGS_INIT "--target=${MINGW_TRIPLE} --sysroot=${MINGW_SYSROOT} -I /usr/lib/gcc/x86_64-w64-mingw32/12-posix -I /usr/lib/gcc/x86_64-w64-mingw32/12-posix/include/c++ -I /usr/lib/gcc/x86_64-w64-mingw32/12-posix/include/c++/x86_64-w64-mingw32")
# Use the mingw-w64 GNU linker directly. (lld would also work and is
# slightly faster, but it isn't packaged on every distro -- e.g. Parrot OS
# doesn't ship an `lld` package -- so we just use the linker that's
# guaranteed to exist once mingw-w64 is installed.)
find_program(MINGW_LD_EXECUTABLE ${MINGW_TRIPLE}-ld REQUIRED)
set(MINGW_LINKER_FLAGS "--target=${MINGW_TRIPLE} --sysroot=${MINGW_SYSROOT} -L/usr/lib/gcc/x86_64-w64-mingw32/12-posix/ -fuse-ld=${MINGW_LD_EXECUTABLE}")

# set(CMAKE_EXE_LINKER_FLAGS "${MINGW_LINKER_FLAGS}")
set(CMAKE_EXE_LINKER_FLAGS_INIT "${MINGW_LINKER_FLAGS}")
set(CMAKE_SHARED_LINKER_FLAGS_INIT "${MINGW_LINKER_FLAGS}")
set(CMAKE_MODULE_LINKER_FLAGS_INIT "${MINGW_LINKER_FLAGS}")

# Resource compiler (needed if HelloImGui or your app embeds a .rc file for
# an icon, version info, etc). Harmless to set even if unused.
find_program(CMAKE_RC_COMPILER ${MINGW_TRIPLE}-windres)

# Where to look for pre-existing Windows libraries/headers (e.g. if you
# manually placed a mingw-built GLFW somewhere). Adjust/add paths as needed.
list(APPEND CMAKE_FIND_ROOT_PATH ${MINGW_SYSROOT})

# Search programs (cmake helper tools, code generators) on the HOST only;
# search libraries/headers/packages in the TARGET sysroot only. This is the
# standard cross-compilation split and matters once find_package(CURL),
# find_package(OpenGL), etc. start resolving paths.
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE ONLY)

# set(ENV{PKG_CONFIG_LIBDIR} "${MINGW_SYSROOT}/lib/pkgconfig")
# set(ENV{PKG_CONFIG_PATH} "")
# set(ENV{PKG_CONFIG_SYSROOT_DIR} "${MINGW_SYSROOT}")
set(CMAKE_DISABLE_FIND_PACKAGE_glfw3 ON)
