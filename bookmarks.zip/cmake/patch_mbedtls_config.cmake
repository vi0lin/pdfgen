# cmake/patch_mbedtls_config.cmake
# Wird von FetchContent als PATCH_COMMAND im mbedTLS-Quellverzeichnis
# ausgefuehrt (direkt nach dem git-Checkout, VOR dem Build).
#
# Zweck: mbedTLS 3.6-Default-Config anpassen:
#  (1) Threading aktivieren (Worker-Threads der App).
#  (2) TLS 1.3 deaktivieren -- mbedTLS 3.6 verlangt bei einkompiliertem
#      TLS 1.3 einen psa_crypto_init()-Aufruf, den curl 8.7 nie macht;
#      mbedtls_ssl_setup() schlaegt sonst fehl und curl meldet
#      "mbedTLS: ssl_init failed". x.com laeuft vollstaendig ueber TLS 1.2.

set(_f "include/mbedtls/mbedtls_config.h")
if(NOT EXISTS "${_f}")
    message(FATAL_ERROR "patch_mbedtls_config: ${_f} nicht gefunden (falsches Arbeitsverzeichnis?)")
endif()

file(READ "${_f}" _c)
if(_c MATCHES "XBM_TLS_PATCH_V2")
    message(STATUS "mbedTLS config bereits gepatcht (V2)")
else()
    string(REPLACE "//#define MBEDTLS_THREADING_C"
                   "#define MBEDTLS_THREADING_C" _c "${_c}")
    string(REPLACE "//#define MBEDTLS_THREADING_PTHREAD"
                   "#define MBEDTLS_THREADING_PTHREAD" _c "${_c}")
    string(REPLACE "#define MBEDTLS_SSL_PROTO_TLS1_3"
                   "//#define MBEDTLS_SSL_PROTO_TLS1_3" _c "${_c}")
    set(_c "${_c}\n/* XBM_TLS_PATCH_V2 applied */\n")
    file(WRITE "${_f}" "${_c}")
    message(STATUS "mbedTLS config gepatcht: Threading an, TLS 1.3 aus (V2)")
endif()
