# toolchain-android-freebsd.cmake
#
# Explizite Android-Cross-Toolchain fuer Hosts, die das NDK nicht kennt
# (FreeBSD). Hintergrund: android.toolchain.cmake leitet ANDROID_HOST_TAG
# aus dem Host-OS ab (nur Linux/Darwin/Windows bekannt). Auf FreeBSD bleibt
# das Tag leer -> Sysroot wird 'prebuilt//sysroot' -> crtbegin/libc/libm
# werden nicht gefunden. Ein per -D gesetztes ANDROID_HOST_TAG greift nicht
# zuverlaessig, weil CMakes try_compile-Unterprojekte die Toolchain-Datei
# NEU einlesen, ohne die aeusseren Cache-Variablen mitzunehmen.
#
# Diese Datei umgeht das komplett: JEDER Pfad ist absolut gesetzt, es gibt
# keinerlei Host-Erkennung. Beim erneuten Einlesen (try_compile) ergeben
# sich exakt dieselben Pfade.
#
# Aufruf (macht build_apk.sh automatisch):
#   cmake -B build -S . \
#     -DCMAKE_TOOLCHAIN_FILE=toolchain-android-freebsd.cmake \
#     -DANDROID_NDK_ROOT=$HOME/android-sdk/ndk/29.0.1406865

cmake_minimum_required(VERSION 3.20)

# WICHTIG: try_compile-Unterprojekte (CMakes Compiler-Tests) lesen diese
# Toolchain-Datei NEU ein und sehen aeussere -D-Cache-Variablen NICHT.
# CMAKE_TRY_COMPILE_PLATFORM_VARIABLES ist der offizielle Mechanismus,
# um benoetigte Variablen samt Wert dorthin weiterzureichen. Ohne diese
# Zeile schlaegt der allererste Compiler-ABI-Test mit
# "ANDROID_NDK_ROOT nicht gesetzt" fehl (Call Stack: TryCompile-*/
# CMakeLists.txt -> CMakeSystem.cmake -> diese Datei).
list(APPEND CMAKE_TRY_COMPILE_PLATFORM_VARIABLES ANDROID_NDK_ROOT ANDROID_API)

# --- Parameter (per -D ueberschreibbar) ------------------------------------
if(NOT DEFINED ANDROID_NDK_ROOT)
    set(ANDROID_NDK_ROOT "$ENV{ANDROID_NDK_ROOT}")
endif()
if(NOT ANDROID_NDK_ROOT)
    message(FATAL_ERROR
        "ANDROID_NDK_ROOT nicht gesetzt. Uebergib -DANDROID_NDK_ROOT=/pfad/zum/ndk "
        "oder setze die Umgebungsvariable ANDROID_NDK_ROOT.")
endif()

if(NOT DEFINED ANDROID_API)
    set(ANDROID_API 26)
endif()

# Host-Tag der NDK-Binaries: die heruntergeladenen NDK-Binaries sind Linux-
# Builds (laufen auf FreeBSD via Linuxulator), daher fest linux-x86_64.
set(_NDK_HOST_TAG linux-x86_64)
set(_TC "${ANDROID_NDK_ROOT}/toolchains/llvm/prebuilt/${_NDK_HOST_TAG}")
if(NOT EXISTS "${_TC}/bin/clang")
    message(FATAL_ERROR "NDK-Compiler nicht gefunden: ${_TC}/bin/clang -- ist ANDROID_NDK_ROOT korrekt?")
endif()

# Target-Triple: arm64-v8a, API-Level im Triple kodiert (so waehlt der
# clang-Treiber selbststaendig das richtige versionierte lib-Verzeichnis
# im Sysroot, z.B. usr/lib/aarch64-linux-android/26/ fuer crtbegin & libc).
set(_TRIPLE "aarch64-none-linux-android${ANDROID_API}")

# --- Cross-Compile-Grundeinstellungen ---------------------------------------
# CMAKE_SYSTEM_NAME Linux (nicht 'Android'!): behandelt den Build als
# generisches ELF-Cross-Compiling und haelt CMakes eingebaute Android-
# Module heraus, deren Host-Erkennung FreeBSD ebenfalls nicht kennt.
# Das __ANDROID__-Makro kommt trotzdem korrekt vom Target-Triple.
set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_SYSTEM_PROCESSOR aarch64)

# Unser CMakeLists.txt verzweigt mit if(ANDROID) in den Android-Pfad und
# nutzt ${ANDROID_NDK} fuer native_app_glue -- beides hier bereitstellen:
set(ANDROID TRUE)
set(ANDROID_NDK "${ANDROID_NDK_ROOT}")

# --- Compiler & Binutils (alle absolut) --------------------------------------
set(CMAKE_C_COMPILER          "${_TC}/bin/clang")
set(CMAKE_CXX_COMPILER        "${_TC}/bin/clang++")
set(CMAKE_ASM_COMPILER        "${_TC}/bin/clang")
set(CMAKE_C_COMPILER_TARGET   "${_TRIPLE}")
set(CMAKE_CXX_COMPILER_TARGET "${_TRIPLE}")
set(CMAKE_ASM_COMPILER_TARGET "${_TRIPLE}")
set(CMAKE_AR                  "${_TC}/bin/llvm-ar"     CACHE FILEPATH "")
set(CMAKE_RANLIB              "${_TC}/bin/llvm-ranlib" CACHE FILEPATH "")
set(CMAKE_STRIP               "${_TC}/bin/llvm-strip"  CACHE FILEPATH "")

# Sysroot explizit -- DER Pfad, der ueber die NDK-Toolchain auf FreeBSD
# leer/kaputt war und die crtbegin/-lc/-lm-Fehler verursacht hat:
set(CMAKE_SYSROOT "${_TC}/sysroot")

# --- Uebliche Cross-Compile-Suchregeln ---------------------------------------
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# libc++ STATISCH einlinken: clangs Android-Treiber linkt sonst dynamisch
# gegen libc++_shared.so -- die liegt aber nicht in unserer APK. Folge:
# UnsatisfiedLinkError beim Laden der .so, App stuerzt VOR android_main ab
# (logcat -s XBookmarks bleibt komplett leer). Mit -static-libstdc++ wird
# libc++_static.a direkt in libx_bookmark_manager.so eingebettet -- keine
# externe C++-Runtime-Abhaengigkeit mehr. (Alternative waere, libc++_shared.so
# aus dem Sysroot mit in die APK zu packen; statisch ist hier einfacher.)
#
# NICHT MEHR HIER GLOBAL (per _INIT) gesetzt -- das galt bisher fuer JEDES
# Ziel im ganzen Bau, auch fuer Drittanbieter-Unterprojekte wie mbedTLS'
# p256-m/everest (reine C-Bibliotheken ohne jede C++-Abhaengigkeit). Dort
# ist "-static-libstdc++" schlicht bedeutungslos, clang meldet es als
# "argument unused during compilation" -- und mbedTLS baut mit eigenen,
# strengen Warnungen-als-Fehler-Einstellungen, wodurch genau diese
# harmlose Meldung den ganzen Bau zum Scheitern brachte.
# "-static-libstdc++" steht jetzt NUR NOCH gezielt an unserem eigenen Ziel
# in CMakeLists.txt (target_link_options) -- max-page-size bleibt global,
# das ist fuer jedes Android-Ziel harmlos und sogar erwuenscht.
set(CMAKE_SHARED_LINKER_FLAGS_INIT "-Wl,-z,max-page-size=16384")
set(CMAKE_EXE_LINKER_FLAGS_INIT    "-Wl,-z,max-page-size=16384")

set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE ONLY)
