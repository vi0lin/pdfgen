#pragma once
// ---------------------------------------------------------------------------
// ui_jobs -- Seite "Jobs": Queues aus jobflow bearbeiten und laufen lassen.
//
// Links die Queue-Vorlagen, rechts der Jobbaum der gewaehlten Vorlage mit
// Einrueckung (Kind = laeuft nach dem Elternteil), Ablaufart, Trigger und
// Ziel je Job; darunter die laufenden Instanzen mit Status je Job.
// Ein Aktions-Event im Kalender mit befehl "queue:<id>" startet die Vorlage
// zur Terminzeit (jobflow::Planer); "Jetzt starten" hier tut es sofort.
// Vorlagen liegen in <Datenstamm>/jobs.json.
// ---------------------------------------------------------------------------
#include <string>
void UiJobs_Init(const std::string& dataDir);
void UiJobs_Poll();          // jeden Frame: Planer takten, Ergebnisse abholen
void UiJobs_Draw();          // Inhalt des Seitenfensters
