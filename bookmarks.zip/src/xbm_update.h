#pragma once
// ---------------------------------------------------------------------------
// xbm_update.h -- In-App-Update ueber release.json im Releases-Repo.
//
// ABLAUF
//   1. XbmUpdate_PruefenAsync(url)  -- beim Start (nach 5 s) und auf Knopf.
//   2. Ist eine neuere Version da, merkt sich das Modul die Angaben
//      (XbmUpdate_Verfuegbar) und zeigt einen Alert mit "Installieren".
//   3. XbmUpdate_Installieren() laedt, prueft SHA-256, wendet an:
//        Linux   : Archiv entpacken, Programmdatei per rename() tauschen,
//                  Neustart durch den Nutzer.
//        Windows : Archiv entpacken, ein Nachlauf-Script (.cmd) wartet,
//                  bis dieser Prozess weg ist, kopiert drueber und startet
//                  neu -- die App beendet sich dafuer selbst.
//        Android : APK nach Downloads legen und dem System-Installer
//                  uebergeben (Intent). Der Rest ist Android-Sache.
//   Die BENUTZERDATEN (XbmPaths_UserData) werden dabei NIE angefasst --
//   nur das Programm und die mitgelieferten Vorlagen.
// ---------------------------------------------------------------------------
#include <string>

struct XbmUpdateInfo {
    int         version = 0;
    std::string notes;
    std::string url;       // Download-Adresse fuer DIESE Plattform
    std::string sha256;    // Pruefsumme -- Pflicht vor jeder Anwendung
};

// Pruefung anstossen (laeuft im Hintergrund). Beim Start mit Verzoegerung,
// auf Knopfdruck sofort.
void XbmUpdate_PruefenAsync(const std::string& releaseJsonUrl, bool sofort = false);

// Zuletzt gefundenes Update, falls neuer als XBM_APP_VERSION; sonst
// version == 0. Fuer die Einstellungsseite ("aktuell 3, verfuegbar 4").
XbmUpdateInfo XbmUpdate_Verfuegbar();
// Laeuft gerade eine Pruefung / eine Installation? (Knoepfe sperren)
bool XbmUpdate_Beschaeftigt();
// Letzte Meldung der Pruefung ("aktuell", "Server nicht erreichbar" ...).
std::string XbmUpdate_LetzteMeldung();
// Das gefundene Update jetzt herunterladen und anwenden (Hintergrund).
void XbmUpdate_Installieren();
// AUTO-UPDATE: eine erkannte neue Version ohne Rueckfrage installieren und
// bei eingeschaltetem Auto-Update alle 30 min nachpruefen. Jede Version
// wird nur einmal automatisch versucht. Android: der System-Installer
// fragt trotzdem nach -- das laesst Android nicht anders zu.
void XbmUpdate_SetAuto(bool an);
bool XbmUpdate_Auto();
// Lesbare Darstellung: Commit-Zeitstempel -> "Stand 17.09.2026 14:32",
// kleine Zahlen unveraendert als "Version N".
std::string XbmUpdate_VersionText(int version);

// Von der Plattform gesetzt:
//   Windows: App sauber beenden, damit das Nachlauf-Script kopieren kann.
//   Android: APK dem Installer uebergeben (Pfad der .apk). true = uebergeben.
extern void (*XbmUpdate_BeendenHook)();
extern bool (*XbmUpdate_ApkInstallierenHook)(const std::string& apkPfad);
