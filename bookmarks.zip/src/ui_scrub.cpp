// ---------------------------------------------------------------------------
// ui_scrub.cpp -- siehe ui_scrub.h.
// ---------------------------------------------------------------------------
#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif
#include "ui_scrub.h"
#include "imgui_internal.h"

#include <cmath>
#include <cstdio>
#include <map>

void (*UiScrub_ClaimGesture)() = nullptr;

namespace {

struct ScrubState {
    bool   active     = false;
    double value      = 0.0;     // laufender Stand, inkrementell gefuehrt
    float  lastX      = 0.0f;
    double rate       = 1.0;
    const char* label = "";
};

std::map<ImGuiID, ScrubState>& States() {
    static std::map<ImGuiID, ScrubState> m;
    return m;
}

void Claim() { if (UiScrub_ClaimGesture) UiScrub_ClaimGesture(); }

// Faktor zur senkrechten Entfernung. Die Stufen sind aufsteigend sortiert
// erwartet; genommen wird die letzte, deren Schwelle erreicht ist.
void RateFor(const XbmScrubOptions& o, float dist, double& rate,
             const char*& label) {
    rate = 1.0; label = "ganze Laufzeit";
    for (const XbmScrubStep& s : o.steps) {
        if (dist >= s.distancePx) { rate = s.rate; label = s.label; }
    }
}

}  // namespace

std::string UiScrub_FormatTime(double sec, bool withMillis) {
    if (sec < 0) sec = 0;
    const long long total = (long long)sec;
    const int h = (int)(total / 3600);
    const int m = (int)((total % 3600) / 60);
    const int s = (int)(total % 60);
    const int ms = (int)((sec - (double)total) * 1000.0 + 0.5);
    char buf[64];
    if (h > 0) {
        if (withMillis) std::snprintf(buf, sizeof(buf), "%d:%02d:%02d.%03d", h, m, s, ms);
        else            std::snprintf(buf, sizeof(buf), "%d:%02d:%02d", h, m, s);
    } else {
        if (withMillis) std::snprintf(buf, sizeof(buf), "%02d:%02d.%03d", m, s, ms);
        else            std::snprintf(buf, sizeof(buf), "%02d:%02d", m, s);
    }
    return std::string(buf);
}

// ---------------------------------------------------------------------------
bool UiScrubber(const char* id, double* value, double vmin, double vmax,
                const XbmScrubOptions& opt, XbmScrubInfo* info) {
    if (info) *info = XbmScrubInfo{};
    if (!value) return false;
    if (vmax <= vmin) vmax = vmin + 1.0;

    ImGuiWindow* win = ImGui::GetCurrentWindow();
    if (win->SkipItems) return false;

    ImGui::PushID(id);
    const ImGuiID gid = win->GetID("##scrub");
    ScrubState& st = States()[gid];

    const float w = ImGui::GetContentRegionAvail().x;
    const ImVec2 p0 = ImGui::GetCursorScreenPos();
    const ImVec2 p1(p0.x + w, p0.y + opt.height);

    ImGui::InvisibleButton("##scrub", ImVec2(w, opt.height));
    const bool activated   = ImGui::IsItemActivated();
    const bool active      = ImGui::IsItemActive();
    const bool deactivated = ImGui::IsItemDeactivated();
    const bool hovered     = ImGui::IsItemHovered();

    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImGuiIO& io = ImGui::GetIO();
    bool changed = false;

    double rate = 1.0;
    const char* rateLabel = "ganze Laufzeit";
    float offset = 0.0f;

    if (activated) {
        st.active = true;
        st.value  = *value;
        st.lastX  = io.MousePos.x;
        if (info) info->began = true;
    }

    if (active && st.active) {
        Claim();
        // Senkrechter Abstand ZUM REGLER (nicht zum Startpunkt): so ist die
        // Stufe eine Eigenschaft der Fingerlage, und die Rueckkehr zum
        // Regler stellt zuverlaessig die grobe Uebersetzung wieder her --
        // auch wenn der Finger unterwegs seitlich weit gewandert ist.
        const float cy = (p0.y + p1.y) * 0.5f;
        offset = std::fabs(io.MousePos.y - cy);
        // Innerhalb des Reglers selbst zaehlt kein Abstand.
        const float half = opt.height * 0.5f;
        offset = offset > half ? offset - half : 0.0f;
        RateFor(opt, offset, rate, rateLabel);

        // ---- INKREMENTELL, nicht absolut (siehe Kopfkommentar) ----
        const float dx = io.MousePos.x - st.lastX;
        st.lastX = io.MousePos.x;
        if (dx != 0.0f && w > 1.0f) {
            st.value += (double)dx / (double)w * (vmax - vmin) * rate;
            if (st.value < vmin) st.value = vmin;
            if (st.value > vmax) st.value = vmax;
        }

        double out = st.value;
        if (opt.snapToFrame && opt.fps > 0.0)
            out = std::round(out * opt.fps) / opt.fps;
        if (out != *value) { *value = out; changed = true; }

        st.rate = rate; st.label = rateLabel;
    } else {
        st.active = false;
    }

    if (deactivated) {
        st.active = false;
        if (info) info->ended = true;
    }

    // ---- Zeichnen ----------------------------------------------------------
    const float trackH = 6.0f;
    const float ty = (p0.y + p1.y) * 0.5f;
    const ImU32 colTrack = ImGui::GetColorU32(ImGuiCol_FrameBg);
    const ImU32 colFill  = ImGui::GetColorU32(active ? ImGuiCol_SliderGrabActive
                                                     : ImGuiCol_SliderGrab);
    dl->AddRectFilled(ImVec2(p0.x, ty - trackH * 0.5f),
                      ImVec2(p1.x, ty + trackH * 0.5f), colTrack, trackH * 0.5f);

    const double t = (vmax > vmin) ? (*value - vmin) / (vmax - vmin) : 0.0;
    const float hx = p0.x + (float)t * w;
    dl->AddRectFilled(ImVec2(p0.x, ty - trackH * 0.5f),
                      ImVec2(hx, ty + trackH * 0.5f), colFill, trackH * 0.5f);

    const float r = (active || hovered) ? 9.0f : 7.0f;
    dl->AddCircleFilled(ImVec2(hx, ty), r, colFill);
    dl->AddCircle(ImVec2(hx, ty), r, IM_COL32(255, 255, 255, 200), 0, 1.5f);

    if (opt.showTime) {
        const std::string s = UiScrub_FormatTime(*value)
                            + " / " + UiScrub_FormatTime(vmax, false);
        const ImVec2 ts = ImGui::CalcTextSize(s.c_str());
        dl->AddText(ImVec2(p1.x - ts.x - 2.0f, p0.y - ts.y - 1.0f),
                    ImGui::GetColorU32(ImGuiCol_TextDisabled), s.c_str());
    }

    // Faktor einblenden, sobald verfeinert wird -- ohne diese Rueckmeldung
    // wirkt der Regler schlicht kaputt ("er reagiert ja kaum").
    if (active && opt.showRate && rate < 1.0) {
        char buf[96];
        std::snprintf(buf, sizeof(buf), "Feinjustierung  %s", rateLabel);
        const ImVec2 ts = ImGui::CalcTextSize(buf);
        const float bx = ImClamp(io.MousePos.x - ts.x * 0.5f, p0.x, p1.x - ts.x);
        const float by = io.MousePos.y - ts.y - 12.0f;
        dl->AddRectFilled(ImVec2(bx - 6, by - 3), ImVec2(bx + ts.x + 6, by + ts.y + 3),
                          IM_COL32(20, 20, 24, 230), 4.0f);
        dl->AddText(ImVec2(bx, by), IM_COL32(255, 220, 120, 255), buf);
        // Leitlinie vom Regler zum Finger: macht die Geste sofort begreiflich.
        dl->AddLine(ImVec2(hx, ty), ImVec2(io.MousePos.x, io.MousePos.y),
                    IM_COL32(255, 220, 120, 90), 1.5f);
    }

    if (info) {
        info->scrubbing = active;
        info->rate      = active ? rate : 1.0;
        info->rateLabel = active ? rateLabel : "";
        info->offsetPx  = offset;
    }
    ImGui::PopID();
    return changed;
}

// ---------------------------------------------------------------------------
bool UiScrubTransport(const char* id, double* value, double vmin, double vmax,
                      double fps, bool* playing) {
    if (!value) return false;
    if (fps <= 0.0) fps = 25.0;
    const double frame = 1.0 / fps;
    bool changed = false;

    ImGui::PushID(id);
    auto step = [&](double d) {
        double v = *value + d;
        if (v < vmin) v = vmin;
        if (v > vmax) v = vmax;
        // Auf das Bildraster runden, sonst summieren sich Gleitkommareste
        // ueber viele Schritte zu sichtbarem Versatz.
        v = std::round(v * fps) / fps;
        if (v != *value) { *value = v; changed = true; }
    };

    if (ImGui::Button("|<")) { *value = vmin; changed = true; }
    ImGui::SetItemTooltip("an den Anfang");
    ImGui::SameLine();
    if (ImGui::Button("<<")) step(-frame * 10.0);
    ImGui::SetItemTooltip("10 Bilder zurueck");
    ImGui::SameLine();
    if (ImGui::Button("<|")) step(-frame);
    ImGui::SetItemTooltip("ein Bild zurueck");
    ImGui::SameLine();
    if (playing) {
        if (ImGui::Button(*playing ? "||" : ">")) *playing = !*playing;
        ImGui::SetItemTooltip(*playing ? "Pause" : "Wiedergabe");
        ImGui::SameLine();
    }
    if (ImGui::Button("|>")) step(frame);
    ImGui::SetItemTooltip("ein Bild vor");
    ImGui::SameLine();
    if (ImGui::Button(">>")) step(frame * 10.0);
    ImGui::SetItemTooltip("10 Bilder vor");
    ImGui::SameLine();
    if (ImGui::Button(">|")) { *value = vmax; changed = true; }
    ImGui::SetItemTooltip("ans Ende");
    ImGui::SameLine();
    ImGui::TextDisabled("Bild %lld", (long long)std::llround(*value * fps));

    // Tastatur: Pfeil links/rechts = Einzelbild, mit Umschalt = 10 Bilder.
    // Nur wenn das Fenster den Fokus hat, sonst kapert es die Textfelder.
    if (ImGui::IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows) &&
        !ImGui::GetIO().WantTextInput) {
        const double mul = ImGui::GetIO().KeyShift ? 10.0 : 1.0;
        if (ImGui::IsKeyPressed(ImGuiKey_LeftArrow,  true)) step(-frame * mul);
        if (ImGui::IsKeyPressed(ImGuiKey_RightArrow, true)) step( frame * mul);
    }
    ImGui::PopID();
    return changed;
}
