#pragma once
// thumbnails.h
//
// Async thumbnail manager.
// Workers download image files to disk. The main thread decodes and uploads.

#include <atomic>
#include <condition_variable>
#include <mutex>
#include <optional>
#include <queue>
#include <string>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>

void set_thumbnail_cache_dir(const std::string& dir);

class ThumbnailManager {
public:
    explicit ThumbnailManager(int num_workers = 2, int max_in_flight = 8);
    ~ThumbnailManager();

    // Call from the render loop to request a thumbnail download.
    void request(const std::string& tweet_id,
                 const std::optional<std::string>& url);

    // Call once per frame from the main/render thread.
    // Decodes downloaded images and uploads GL textures.
    void poll(int max_uploads_per_frame = 2);

    // Returns the GL texture ID for a tweet, or 0 if not ready.
    unsigned int get_texture(const std::string& tweet_id) const;

    // Frees all GL textures and clears state (call before context destruction).
    void clear_all_textures();

private:
    // A pending download job queued to a worker thread.
    struct PendingDownload {
        std::string tweet_id;
        std::string url;
    };

    // A completed download: the file is on disk, ready for main-thread decode.
    struct ReadyPath {
        std::string tweet_id;
        std::string path;   // absolute path to the cached JPEG file
    };

    std::string cache_path(const std::string& url) const;
    void worker_loop();

    // Worker threads -- download only, no stb or GL calls.
    std::vector<std::thread>      workers_;
    std::atomic<bool>             shutting_down_{false};

    // Download queue (worker-side)
    std::mutex                    queue_mutex_;
    std::condition_variable       queue_cv_;
    std::queue<PendingDownload>   pending_;

    // Ready-to-decode queue (main-thread-side)
    std::mutex                    ready_mutex_;
    std::queue<ReadyPath>         ready_;

    // Deduplication state
    std::mutex                    state_mutex_;
    std::unordered_set<std::string> requested_;   // by tweet_id
    std::unordered_set<std::string> in_flight_;   // by tweet_id

    int                           max_in_flight_;

    // GL texture map (main thread only)
    std::unordered_map<std::string, unsigned int> textures_;
};
