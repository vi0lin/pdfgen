#pragma once
// ---------------------------------------------------------------------------
// xbm_alarm.h -- Erinnerungen beim BETRIEBSSYSTEM anmelden.
//
// [Der bisherige Weg (UiCalendar_SetReminderHandler) ist ein Rueckruf im
//  UI-Thread: er laeuft nur, solange die App zeichnet. Bei geschlossener
//  App oder im Standby gibt es keinen Frame -- also keine Erinnerung.
//  Das war die Ursache dafuer, dass "Erinnern nicht richtig
//  funktioniert".
//
//  Hier wird die Erinnerung stattdessen beim System angemeldet. Auf
//  Android uebernimmt XbmAlarm (AlarmManager, weckt aus dem Doze-Schlaf,
//  spielt auf Wunsch die Memo-WAV als Alarmton). Auf Linux und Windows
//  gibt es kein Gegenstueck, das bei geschlossener App weckt -- dort
//  bleibt der Rueckruf, solange die App laeuft, und XbmAlarm_Verfuegbar()
//  meldet false, damit die Oberflaeche das sagen kann.]
// ---------------------------------------------------------------------------
#include <cstdint>
#include <string>

// EINMAL IN android_main() AUFRUFEN:  XbmAlarm_SetApp(app);
// [Ohne das kennt das Modul die Activity nicht und tut nichts -- es
//  stuerzt aber auch nicht ab. Auf Linux/Windows ohne Wirkung.]
void XbmAlarm_SetApp(void* app);

// Kann das System eine Erinnerung auch bei geschlossener App ausloesen?
bool XbmAlarm_Verfuegbar();

// Darf die App EXAKTE Alarme setzen? (Android 12+: eigenes Recht, das der
// Nutzer in den Einstellungen geben muss. false = Erinnerungen kommen, aber
// eventuell ein paar Minuten spaeter.)
bool XbmAlarm_ExakteErlaubt();

// Oeffnet die Systemeinstellung fuer exakte Alarme (Android 12+).
void XbmAlarm_RechteOeffnen();

// Erinnerung anmelden. zeitUnix = Zeitpunkt in Unix-Sekunden.
// audioPfad = volle Pfadangabe einer WAV (Memo) oder leer fuer den
// Standard-Alarmton.
void XbmAlarm_Planen(std::uint64_t id, std::int64_t zeitUnix,
                     const std::string& titel,
                     const std::string& audioPfad);

// Angemeldete Erinnerung wieder entfernen.
void XbmAlarm_Loeschen(std::uint64_t id);

// Laufenden Alarmton beenden (z.B. wenn der Nutzer den Eintrag oeffnet).
void XbmAlarm_TonStoppen();
