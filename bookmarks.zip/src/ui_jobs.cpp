#include "ui_jobs.h"
#include "imgui.h"
#include "misc/cpp/imgui_stdlib.h"
#include "xbm_timeline_adapter.h"
#include "xbm_timeline_sync.h"   // Anstossen nach Aenderungen
#include "xbm_sched.h"           // XbmTime_NowUtc
#include "planer.h"              // jobflow + timeline
#include "fernausfuehrer.h"      // netlink: Ausfuehrer (lokal ueber actionkit)
#include "actionkit.h"
#include "ui_networking.h"       // Netzknoten (Peers) und Geheimnis fuer eigene Verbindungen
#include "ui_pages.h"            // UiMailSender (pdfgen: PDF erzeugen, Mails senden)
#include "xbm_audio.h"           // Audio abspielen
#include <memory>
#include <cstdio>
#include <fstream>
#include <functional>
#include <set>

// ---------------------------------------------------------------------------
// EINGEBAUTE AKTIONEN. [Der Katalog ist die Grundlage der Aktions-Auswahl im
//  Jobbaum; weitere kommen mit AKTION(...) in jeder Quelldatei dazu.]
// ---------------------------------------------------------------------------
AKTION(Befehl, "Shell-Befehl ausfuehren", EIN_H(std::string, befehl, "Kommandozeile"), AUS(int, exitcode)) {
    HOLE(std::string, befehl);
    if (befehl.empty()) { fehler = "kein Befehl"; return false; }
    const int rc = std::system(befehl.c_str());
    SETZE(exitcode, rc);
    if (rc != 0) { fehler = "Exit " + std::to_string(rc); return false; }
    return true;
}
AKTION(Warten, "Nichts tun (Platzhalter zum Testen)", EIN_VORGABE(int, sekunden, 0), AUS(int, gewartet)) {
    HOLE(int, sekunden); SETZE(gewartet, sekunden); return true;
}
// KALENDER-AKTIONEN (Namen wie im Kalender: befehl, audio, pdf, mail). Der
// Planer baut aus einem Aktions-Event einen Job mit diesem Namen; die
// Felder des Kalenders (ziel, ton, ...) kommen als Eingaenge.
AKTION(befehl, "Kalender: Befehl ausfuehren (ziel = Kommandozeile)", EIN_H(std::string, ziel, "Kommandozeile"), AUS(int, exitcode)) {
    HOLE(std::string, ziel);
    if (ziel.empty()) { fehler = "kein Befehl"; return false; }
    const int rc = std::system(ziel.c_str()); SETZE(exitcode, rc);
    if (rc != 0) { fehler = "Exit " + std::to_string(rc); return false; }
    return true;
}
AKTION(audio, "Kalender: Audiodatei abspielen (ziel = Datei)", EIN_H(std::string, ziel, "Audiodatei"), AUS(bool, gestartet)) {
    HOLE(std::string, ziel);
    if (ziel.empty()) { fehler = "keine Datei"; return false; }
    const bool ok = XbmAudio_PlayFile(ziel); SETZE(gestartet, ok);
    if (!ok) { fehler = XbmAudio_LastError(); return false; }
    return true;
}
AKTION(pdf, "Kalender: PDF aus pdfgen-Quelle erzeugen (ziel = Quelle)", EIN_H(std::string, ziel, "pdfgen-Quelle (.txt/.md/Ordner)"), AUS(bool, erzeugt)) {
    HOLE(std::string, ziel);
    if (!UiMailSender()) { fehler = "pdfgen nicht eingebunden"; return false; }
    const bool ok = UiMailSender()({ std::string_view(ziel) }, {}, /*mailMode=*/0, false); SETZE(erzeugt, ok);
    if (!ok) { fehler = "pdfgen meldet Fehler -- siehe Protokoll"; return false; }
    return true;
}
AKTION(mail, "Kalender: Mails aus pdfgen-Quelle senden (ziel = Quelle)", EIN_H(std::string, ziel, "pdfgen-Quelle mit \\mail-Definitionen"), AUS(bool, gesendet)) {
    HOLE(std::string, ziel);
    if (!UiMailSender()) { fehler = "pdfgen nicht eingebunden"; return false; }
    const bool ok = UiMailSender()({ std::string_view(ziel) }, {}, /*mailMode=*/1, false); SETZE(gesendet, ok);
    if (!ok) { fehler = "Versand fehlgeschlagen -- siehe Protokoll"; return false; }
    return true;
}

namespace {
struct Z {
    std::string datei;
    std::vector<jobflow::Queue> vorlagen;
    jobflow::Id naechsteQueueId = 1;
    jobflow::Id gewaehlt = 0;
    netlink::Fernausfuehrer fern;
    jobflow::Planer planer;
    bool init = false;
    // EIGENE VERBINDUNGEN ZU DEN HOSTS. [Der Netzknoten haelt seine
    //  Verbindungen intern; der Ausfuehrer braucht je Host einen
    //  XbmCmdClient. Wie beim Hub-Abgleich oeffnet das Jobs-Modul sie
    //  selbst, mit dem Geheimnis der Netzwerkseite, nur fuer Hosts, die
    //  ein Job als Ziel nennt (oder alle bei "irgendein/alle").]
    struct Verb { std::unique_ptr<XbmCmdClient> cl; std::int64_t letzterVersuchMs = 0; std::string ip; std::uint16_t port = 0; };
    std::map<std::string, Verb> verb;   // Peer-Name -> Verbindung
};
Z& z() { static Z s; return s; }
using json = nlohmann::json;

// QUEUES LIEGEN IN DER TIMELINE (xbm_tl::QueueVorlagen): je Queue ein
// Vorlagen-Event mit dem Queue-JSON. So wandern sie mit dem Abgleich auf alle
// Geraete, und ein Kalender-Job "queue:<id>" findet seine Vorlage ueberall.
// [jobs.json war rein lokal; eine einmalige Uebernahme beim ersten Start.]
void speichern() {
    const std::int64_t jetzt = XbmTime_NowUtc(); bool ge = false;
    for (jobflow::Queue& q : z().vorlagen) {
        if (q.id == 0) { q.id = xbm_tl::QueueAnlegen(q.name, q.zuJson().dump(), jetzt); ge = true; }
        else if (xbm_tl::QueueSpeichern(q.id, q.name, q.zuJson().dump(), jetzt)) ge = true;
    }
    if (ge) { xbm_tl::Speichern(); xbm_tls::Anstossen(); }
    z().planer.vorlagen.clear(); for (const jobflow::Queue& q : z().vorlagen) z().planer.vorlagen[q.id] = q;
}
void laden() {
    z().vorlagen.clear();
    for (const xbm_tl::QueueVorlage& v : xbm_tl::QueueVorlagen()) {
        json q = json::parse(v.json, nullptr, false); if (!q.is_object()) continue;
        jobflow::Queue qu = jobflow::Queue::ausJson(q); qu.id = v.id; qu.name = v.name; qu.istVorlage = true;
        z().vorlagen.push_back(qu);
    }
    // Einmalige Uebernahme aus jobs.json (alter, lokaler Speicher)
    std::ifstream f(z().datei);
    if (f) {
        json j = json::parse(f, nullptr, false); f.close();
        if (j.is_object()) {
            const std::int64_t jetzt = XbmTime_NowUtc();
            for (auto& qj : j.value("vorlagen", json::array())) {
                jobflow::Queue qu = jobflow::Queue::ausJson(qj); qu.istVorlage = true;
                qu.id = xbm_tl::QueueAnlegen(qu.name, qu.zuJson().dump(), jetzt); z().vorlagen.push_back(qu);
            }
            xbm_tl::Speichern();
        }
        std::rename(z().datei.c_str(), (z().datei + ".uebernommen").c_str());
    }
    z().planer.vorlagen.clear(); for (const jobflow::Queue& q : z().vorlagen) z().planer.vorlagen[q.id] = q;
}
// Nach einem Abgleich koennen Queues von anderen Geraeten dazukommen:
// Vorlagenliste neu aufbauen, wenn sich die Zahl oder die Ids geaendert haben.
void nachladenWennNoetig() {
    static std::string letzteSignatur; std::string sig;
    for (const xbm_tl::QueueVorlage& v : xbm_tl::QueueVorlagen()) sig += std::to_string(v.id) + ":" + std::to_string(v.json.size()) + ";";
    if (sig == letzteSignatur) return;
    letzteSignatur = sig;
    if (ImGui::IsAnyItemActive()) return;                 // nicht waehrend einer Eingabe
    laden();
}
jobflow::Queue* gewaehlt() { for (auto& q : z().vorlagen) if (q.id == z().gewaehlt) return &q; return nullptr; }
// TYPEN: passt ein Ausgang an einen Eingang? Gleich ist immer gut; alles laesst
// sich in einen string geben; int in double; "json" nimmt alles.
bool typPasst(const std::string& aus, const std::string& ein) {
    if (aus == ein || ein == "json" || ein == "string" || aus == "json") return true;
    if (ein == "double" && aus == "int") return true;
    return false;
}

// Jobs in Anzeigereihenfolge (Tiefensuche) mit Tiefe
struct Zeile { jobflow::Id id; int tiefe; };
void sammeln(const jobflow::Queue& q, jobflow::Id eltern, int tiefe, std::vector<Zeile>& aus) {
    for (const jobflow::Job& j : q.jobs) if (j.eltern == eltern) { aus.push_back({ j.id, tiefe }); sammeln(q, j.id, tiefe + 1, aus); }
}
const char* statusFarbe(jobflow::Status s, ImVec4& c) {
    switch (s) {
        case jobflow::Status::Laeuft:      c = ImVec4(0.4f, 0.8f, 1.0f, 1); break;
        case jobflow::Status::Fertig:      c = ImVec4(0.5f, 0.9f, 0.5f, 1); break;
        case jobflow::Status::Fehler:      c = ImVec4(1.0f, 0.4f, 0.4f, 1); break;
        case jobflow::Status::Abgebrochen: c = ImVec4(1.0f, 0.7f, 0.3f, 1); break;
        case jobflow::Status::Pausiert:    c = ImVec4(0.9f, 0.9f, 0.4f, 1); break;
        default:                           c = ImVec4(0.7f, 0.7f, 0.7f, 1); break;
    }
    return jobflow::statusText(s);
}

void vorlagenSpalte() {
    ImGui::TextDisabled("Queue-Vorlagen");
    for (auto& q : z().vorlagen) {
        ImGui::PushID((int)q.id);
        if (ImGui::Selectable(q.name.empty() ? "(ohne Namen)" : q.name.c_str(), q.id == z().gewaehlt)) z().gewaehlt = q.id;
        ImGui::PopID();
    }
    if (ImGui::SmallButton("+ Queue")) { jobflow::Queue q; q.id = 0; q.name = "Neue Queue"; q.istVorlage = true; z().vorlagen.push_back(q); speichern(); z().gewaehlt = z().vorlagen.back().id; }
    if (jobflow::Queue* q = gewaehlt()) {
        ImGui::SameLine();
        if (ImGui::SmallButton("Loeschen")) { const std::uint64_t id = q->id; for (auto it = z().vorlagen.begin(); it != z().vorlagen.end(); ++it) if (it->id == id) { z().vorlagen.erase(it); break; } xbm_tl::QueueLoeschen(id, XbmTime_NowUtc()); xbm_tl::Speichern(); xbm_tls::Anstossen(); z().gewaehlt = 0; speichern(); return; }
        ImGui::Separator();
        if (ImGui::Button("Jetzt starten", ImVec2(-1, 0))) {
            jobflow::Lauf l; l.id = z().planer.naechsteLaufId++; l.queue = q->alsInstanz(l.id, q->name); l.queue.ausfuehrer = &z().fern.ausfuehrer; l.queue.starten(XbmTime_NowUtc());
            z().planer.laeufe.push_back(l);
        }
        ImGui::TextWrapped("Im Kalender als Aktion: befehl \"queue:%llu\"", (unsigned long long)q->id);
    }
}

void jobbaum(jobflow::Queue& q) {
    bool ge = false;
    ImGui::SetNextItemWidth(ImGui::GetFontSize() * 12.0f);
    if (ImGui::InputText("Name", &q.name)) ge = true;
    std::vector<std::string> aktionen = actionkit::Aktionen::alle();
    std::vector<Zeile> zeilen; sammeln(q, 0, 0, zeilen);
    const float einzug = ImGui::GetFontSize() * 1.4f;
    jobflow::Id loeschen = 0;
    for (const Zeile& zl : zeilen) {
        jobflow::Job* j = q.finde(zl.id); if (!j) continue;
        ImGui::PushID((int)j->id);
        ImGui::Indent(einzug * zl.tiefe);
        if (ImGui::Checkbox("##aktiv", &j->aktiv)) ge = true;
        ImGui::SameLine();
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 8.0f);
        if (ImGui::InputText("##name", &j->name)) ge = true;
        ImGui::SameLine();
        // Aktion (leer = Gruppe)
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 7.0f);
        if (ImGui::BeginCombo("##aktion", j->aktion.empty() ? "(Gruppe)" : j->aktion.c_str())) {
            if (ImGui::Selectable("(Gruppe)", j->aktion.empty())) { j->aktion.clear(); ge = true; }
            for (const std::string& a : aktionen) if (ImGui::Selectable(a.c_str(), a == j->aktion)) { j->aktion = a; ge = true; }
            ImGui::EndCombo();
        }
        ImGui::SameLine();
        int ab = (int)j->ablauf; ImGui::SetNextItemWidth(ImGui::GetFontSize() * 6.0f);
        if (ImGui::Combo("##ablauf", &ab, "parallel\0warten auf\0prozedural\0")) { j->ablauf = (jobflow::Ablauf)ab; ge = true; }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Gegenueber den Geschwistern: sofort / auf bestimmte warten / nach dem vorigen");
        if (j->eltern) {
            ImGui::SameLine(); int tr = (int)j->trigger; ImGui::SetNextItemWidth(ImGui::GetFontSize() * 6.0f);
            if (ImGui::Combo("##trigger", &tr, "normal\0on_success\0on_failure\0on_abort\0")) { j->trigger = (jobflow::Trigger)tr; ge = true; }
        }
        ImGui::SameLine(); int zw = (int)j->ziel.wahl; ImGui::SetNextItemWidth(ImGui::GetFontSize() * 6.5f);
        if (ImGui::Combo("##ziel", &zw, "lokal\0bestimmte Hosts\0irgendein Host\0alle Hosts\0")) { j->ziel.wahl = (jobflow::Zielwahl)zw; ge = true; }
        if (j->ziel.wahl == jobflow::Zielwahl::Bestimmte || j->ziel.wahl == jobflow::Zielwahl::Alle) {
            ImGui::SameLine(); std::string hosts; for (auto& h : j->ziel.hosts) hosts += (hosts.empty() ? "" : ",") + h;
            ImGui::SetNextItemWidth(ImGui::GetFontSize() * 7.0f);
            if (ImGui::InputText("##hosts", &hosts)) { j->ziel.hosts.clear(); std::string t; for (char c : hosts) { if (c == ',') { if (!t.empty()) j->ziel.hosts.push_back(t); t.clear(); } else t += c; } if (!t.empty()) j->ziel.hosts.push_back(t); ge = true; }
        }
        if (!j->aktion.empty()) {
            // Eingaenge: feste Werte je Parameter (Verbindungen zu anderen Jobs: spaeter im Node-Editor)
            if (const actionkit::Aktion* a = actionkit::Aktionen::finde(j->aktion)) {
                for (const actionkit::Parameter& p : a->parameter) {
                    if (!p.eingang) continue;
                    jobflow::Eingang* e = nullptr; for (auto& x : j->eingaenge) if (x.name == p.name) e = &x;
                    if (!e) { j->eingaenge.push_back({ p.name, p.pflicht ? jobflow::json() : p.vorgabe, 0, "" }); e = &j->eingaenge.back(); }
                    ImGui::Indent(einzug); ImGui::PushID(p.name.c_str());
                    // QUELLE: fester Wert, oder der Ausgang eines anderen Jobs
                    // (Verbindung wie im Node-Editor; dort auch per Ziehen).
                    {
                        std::string quelle = e->vonJob ? "aus Job" : "fest";
                        if (e->vonJob) { if (const jobflow::Job* qj = q.finde(e->vonJob)) quelle = qj->name + "." + e->ausgang; }
                        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 9.0f);
                        if (ImGui::BeginCombo("##quelle", quelle.c_str())) {
                            if (ImGui::Selectable("fester Wert", !e->vonJob)) { e->vonJob = 0; e->ausgang.clear(); ge = true; }
                            for (const jobflow::Job& oj : q.jobs) {
                                if (oj.id == j->id || oj.aktion.empty()) continue;
                                const actionkit::Aktion* oa = actionkit::Aktionen::finde(oj.aktion); if (!oa) continue;
                                for (const actionkit::Parameter& op : oa->parameter) {
                                    if (op.eingang) continue;
                                    const bool passt = typPasst(op.typ, p.typ);
                                    const std::string lb = oj.name + "." + op.name + "  (" + op.typ + (passt ? ")" : ") -- Typ passt nicht");
                                    if (!passt) ImGui::BeginDisabled();
                                    if (ImGui::Selectable(lb.c_str(), e->vonJob == oj.id && e->ausgang == op.name)) { e->vonJob = oj.id; e->ausgang = op.name; ge = true; }
                                    if (!passt) ImGui::EndDisabled();
                                }
                            }
                            ImGui::EndCombo();
                        }
                        ImGui::SameLine();
                    }
                    if (e->vonJob) { ImGui::TextDisabled("-> %s", p.name.c_str()); }
                    else {
                        std::string w = e->wert.is_string() ? e->wert.get<std::string>() : (e->wert.is_null() ? "" : e->wert.dump());
                        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 14.0f);
                        if (ImGui::InputText(p.name.c_str(), &w)) {
                            if (p.typ == "string") e->wert = w; else { jobflow::json pj = jobflow::json::parse(w, nullptr, false); e->wert = pj.is_discarded() ? jobflow::json(w) : pj; }
                            ge = true;
                        }
                    }
                    if (ImGui::IsItemHovered() && !p.hilfe.empty()) ImGui::SetTooltip("%s", p.hilfe.c_str());
                    ImGui::PopID(); ImGui::Unindent(einzug);
                }
            }
        }
        ImGui::SameLine(0, ImGui::GetFontSize());
        if (ImGui::SmallButton("<")) { if (q.nachLinks(j->id)) ge = true; } ImGui::SameLine();
        if (ImGui::SmallButton(">")) { if (q.nachRechts(j->id)) ge = true; } ImGui::SameLine();
        if (ImGui::SmallButton("+Kind")) { jobflow::Job& k = q.anlegen("neu", "", j->id); (void)k; ge = true; } ImGui::SameLine();
        if (ImGui::SmallButton("x")) loeschen = j->id;
        ImGui::Unindent(einzug * zl.tiefe);
        ImGui::PopID();
    }
    if (loeschen) {   // Job samt Teilbaum entfernen
        std::vector<jobflow::Id> weg{ loeschen }; for (size_t i = 0; i < weg.size(); ++i) for (auto& j : q.jobs) if (j.eltern == weg[i]) weg.push_back(j.id);
        for (jobflow::Id id : weg) for (auto it = q.jobs.begin(); it != q.jobs.end(); ++it) if (it->id == id) { q.jobs.erase(it); break; }
        ge = true;
    }
    if (ImGui::SmallButton("+ Job")) { q.anlegen("neu", ""); ge = true; }
    if (ge) speichern();
}

// ---------------------------------------------------------------------------
// NODE-EDITOR: jeder Job ein Kasten (Spalte = Tiefe, Zeile = Reihenfolge),
// links die Eingangs-Pins, rechts die Ausgangs-Pins; Verbindungen als
// Kurven. Ziehen von einem Ausgang auf einen Eingang verbindet, Tippen auf
// einen verbundenen Eingangs-Pin loest. Kaesten lassen sich verschieben
// (nur Anzeige, nicht gespeichert).
// ---------------------------------------------------------------------------
struct PinLage { jobflow::Id job; std::string name; bool eingang; ImVec2 pos; };
void graph(jobflow::Queue& q) {
    static std::map<jobflow::Id, ImVec2> lagen; static jobflow::Id ziehVon = 0; static std::string ziehAusgang;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 org = ImGui::GetCursorScreenPos();
    const float fs = ImGui::GetFontSize(), kw = fs * 11.0f, zeileH = fs * 1.4f, spaltenAbstand = fs * 4.0f;
    std::vector<Zeile> zeilen; sammeln(q, 0, 0, zeilen);
    const float hoehe = ImMax(fs * 8.0f, ImGui::GetContentRegionAvail().y - fs * 2.0f);
    ImGui::BeginChild("##graph", ImVec2(0, hoehe), true, ImGuiWindowFlags_HorizontalScrollbar);
    const ImVec2 o = ImGui::GetCursorScreenPos();
    // Lagen: Spalte nach Tiefe, Zeile nach Reihenfolge
    std::map<int, int> zeileJeTiefe;
    for (const Zeile& zl : zeilen) {
        if (!lagen.count(zl.id)) { int& r = zeileJeTiefe[zl.tiefe]; lagen[zl.id] = ImVec2(fs + zl.tiefe * (kw + spaltenAbstand), fs + r * fs * 7.0f); ++r; }
        else ++zeileJeTiefe[zl.tiefe];
    }
    std::vector<PinLage> pins; bool ge = false;
    ImVec2 maxExt(0, 0);
    for (const Zeile& zl : zeilen) {
        jobflow::Job* j = q.finde(zl.id); if (!j) continue;
        const actionkit::Aktion* a = j->aktion.empty() ? nullptr : actionkit::Aktionen::finde(j->aktion);
        int nEin = 0, nAus = 0; if (a) for (auto& p : a->parameter) (p.eingang ? nEin : nAus)++;
        const int zeilenZahl = ImMax(1, ImMax(nEin, nAus));
        ImVec2& lage = lagen[j->id];
        const ImVec2 p0(o.x + lage.x, o.y + lage.y), p1(p0.x + kw, p0.y + zeileH * (1 + zeilenZahl) + fs * 0.4f);
        maxExt.x = ImMax(maxExt.x, lage.x + kw + fs); maxExt.y = ImMax(maxExt.y, p1.y - o.y + fs);
        ImGui::PushID((int)j->id);
        ImGui::SetCursorScreenPos(p0); ImGui::InvisibleButton("##kopf", ImVec2(kw, zeileH));
        if (ImGui::IsItemActive() && ImGui::IsMouseDragging(ImGuiMouseButton_Left)) { lage.x += ImGui::GetIO().MouseDelta.x; lage.y += ImGui::GetIO().MouseDelta.y; }
        ImVec4 sc; statusFarbe(j->status, sc);
        dl->AddRectFilled(p0, p1, IM_COL32(40, 42, 50, 230), 5.0f);
        dl->AddRectFilled(p0, ImVec2(p1.x, p0.y + zeileH), j->aktion.empty() ? IM_COL32(70, 70, 80, 255) : IM_COL32(60, 90, 130, 255), 5.0f, ImDrawFlags_RoundCornersTop);
        dl->AddRect(p0, p1, j->aktiv ? IM_COL32(120, 140, 170, 200) : IM_COL32(90, 90, 90, 160), 5.0f);
        dl->AddText(ImVec2(p0.x + fs * 0.4f, p0.y + zeileH * 0.15f), IM_COL32(255, 255, 255, 240), j->name.c_str());
        if (!j->aktion.empty()) dl->AddText(ImVec2(p0.x + fs * 0.4f, p0.y + zeileH * 1.05f), IM_COL32(200, 200, 200, 200), j->aktion.c_str());
        if (a) {
            int ri = 0, ro = 0;
            for (const actionkit::Parameter& p : a->parameter) {
                const float py = p0.y + zeileH * (1.1f + (p.eingang ? ri : ro)) + zeileH * 0.5f;
                const ImVec2 pp(p.eingang ? p0.x : p1.x, py);
                pins.push_back({ j->id, p.name, p.eingang, pp });
                bool verbunden = false; if (p.eingang) for (auto& e : j->eingaenge) if (e.name == p.name && e.vonJob) verbunden = true;
                dl->AddCircleFilled(pp, fs * 0.28f, p.eingang ? (verbunden ? IM_COL32(120, 220, 140, 255) : IM_COL32(170, 170, 170, 255)) : IM_COL32(240, 190, 90, 255), 10);
                const ImVec2 ts = ImGui::CalcTextSize(p.name.c_str());
                dl->AddText(p.eingang ? ImVec2(pp.x + fs * 0.5f, py - ts.y * 0.5f) : ImVec2(pp.x - fs * 0.5f - ts.x, py - ts.y * 0.5f), IM_COL32(220, 220, 220, 220), p.name.c_str());
                // Pin als Item
                ImGui::SetCursorScreenPos(ImVec2(pp.x - fs * 0.5f, py - fs * 0.5f)); ImGui::PushID(p.name.c_str());
                ImGui::InvisibleButton("##pin", ImVec2(fs, fs));
                if (!p.eingang && ImGui::IsItemActivated()) { ziehVon = j->id; ziehAusgang = p.name; }
                if (p.eingang && ImGui::IsItemClicked() && verbunden && !ziehVon) { for (auto& e : j->eingaenge) if (e.name == p.name) { e.vonJob = 0; e.ausgang.clear(); ge = true; } }
                if (p.eingang && ziehVon && ziehVon != j->id && ImGui::IsItemHovered()) {
                    // Typ des gezogenen Ausgangs pruefen; bei Nichtpassen roter Pin und kein Verbinden
                    std::string ausTyp = "json";
                    if (const jobflow::Job* qj = q.finde(ziehVon)) if (const actionkit::Aktion* qa = actionkit::Aktionen::finde(qj->aktion)) for (auto& qp : qa->parameter) if (!qp.eingang && qp.name == ziehAusgang) ausTyp = qp.typ;
                    const bool passt = typPasst(ausTyp, p.typ);
                    dl->AddCircle(pp, fs * 0.45f, passt ? IM_COL32(120, 220, 140, 255) : IM_COL32(240, 80, 80, 255), 12, 2.0f);
                    if (!passt) ImGui::SetTooltip("%s -> %s: Typ passt nicht", ausTyp.c_str(), p.typ.c_str());
                    if (ImGui::IsMouseReleased(ImGuiMouseButton_Left) && passt) {
                        jobflow::Eingang* e = nullptr; for (auto& x : j->eingaenge) if (x.name == p.name) e = &x;
                        if (!e) { j->eingaenge.push_back({ p.name, jobflow::json(), 0, "" }); e = &j->eingaenge.back(); }
                        e->vonJob = ziehVon; e->ausgang = ziehAusgang; ge = true; ziehVon = 0;
                    }
                }
                if (ImGui::IsItemHovered() && !p.hilfe.empty()) ImGui::SetTooltip("%s (%s)", p.hilfe.c_str(), p.typ.c_str());
                ImGui::PopID();
                (p.eingang ? ri : ro)++;
            }
        }
        ImGui::PopID();
    }
    // Verbindungen
    auto pinPos = [&](jobflow::Id job, const std::string& name, bool eingang, ImVec2& aus) { for (auto& p : pins) if (p.job == job && p.name == name && p.eingang == eingang) { aus = p.pos; return true; } return false; };
    for (const jobflow::Job& j : q.jobs) for (const jobflow::Eingang& e : j.eingaenge) {
        if (!e.vonJob) continue;
        ImVec2 a, b;
        if (pinPos(e.vonJob, e.ausgang, false, a) && pinPos(j.id, e.name, true, b)) dl->AddBezierCubic(a, ImVec2(a.x + fs * 2.5f, a.y), ImVec2(b.x - fs * 2.5f, b.y), b, IM_COL32(120, 220, 140, 220), 2.0f);
    }
    if (ziehVon) {
        ImVec2 a; if (pinPos(ziehVon, ziehAusgang, false, a)) { const ImVec2 m = ImGui::GetIO().MousePos; dl->AddBezierCubic(a, ImVec2(a.x + fs * 2.5f, a.y), ImVec2(m.x - fs * 2.5f, m.y), m, IM_COL32(240, 190, 90, 220), 2.0f); }
        if (!ImGui::GetIO().MouseDown[ImGuiMouseButton_Left]) ziehVon = 0;   // nicht auf einem Eingang losgelassen
    }
    ImGui::SetCursorScreenPos(ImVec2(o.x + maxExt.x, o.y + maxExt.y)); ImGui::Dummy(ImVec2(1, 1));
    ImGui::EndChild();
    if (ge) speichern();
    (void)org;
}

void laeufe() {
    auto& P = z().planer; if (P.laeufe.empty()) return;
    ImGui::Separator(); ImGui::TextDisabled("Laeufe");
    const std::int64_t jetzt = XbmTime_NowUtc();
    for (auto it = P.laeufe.begin(); it != P.laeufe.end(); ) {
        jobflow::Lauf& l = *it; ImGui::PushID((int)l.id);
        ImVec4 c; const char* st = statusFarbe(l.queue.gesamt(), c);
        ImGui::TextColored(c, "[%s]", st); ImGui::SameLine(); ImGui::TextUnformatted(l.queue.name.c_str());
        ImGui::SameLine();
        const jobflow::Status g = l.queue.gesamt();
        if (g == jobflow::Status::Laeuft || g == jobflow::Status::Wartet) { if (ImGui::SmallButton("Pause")) l.queue.pausierenAlle(); ImGui::SameLine(); if (ImGui::SmallButton("Abbrechen")) l.queue.abbrechenAlle(jetzt); }
        else if (g == jobflow::Status::Pausiert) { if (ImGui::SmallButton("Fortsetzen")) l.queue.fortsetzenAlle(); ImGui::SameLine(); if (ImGui::SmallButton("Abbrechen")) l.queue.abbrechenAlle(jetzt); }
        else { if (ImGui::SmallButton("Entfernen")) { ImGui::PopID(); it = P.laeufe.erase(it); continue; } }
        std::vector<Zeile> zeilen; sammeln(l.queue, 0, 0, zeilen);
        for (const Zeile& zl : zeilen) {
            const jobflow::Job* j = l.queue.finde(zl.id); if (!j) continue;
            ImVec4 cj; const char* sj = statusFarbe(j->status, cj);
            ImGui::Indent(ImGui::GetFontSize() * (1.0f + zl.tiefe));
            ImGui::TextColored(cj, "%-11s", sj); ImGui::SameLine(); ImGui::TextUnformatted(j->name.c_str());
            if (!j->laeuftAuf.empty()) { ImGui::SameLine(); ImGui::TextDisabled("@%s", j->laeuftAuf.c_str()); }
            if (!j->fehler.empty()) { ImGui::SameLine(); ImGui::TextColored(ImVec4(1, 0.5f, 0.5f, 1), "%s", j->fehler.c_str()); }
            ImGui::Unindent(ImGui::GetFontSize() * (1.0f + zl.tiefe));
        }
        ImGui::PopID(); ++it;
    }
}
} // namespace

void UiJobs_Init(const std::string& dataDir) {
    Z& s = z(); if (dataDir.empty()) return; s.datei = dataDir + "/jobs.json";
    s.fern.lokalerName = "lokal";
    s.planer.speicher = &xbm_tl::Speicher(); s.planer.tz = xbm_tl::LokaleZeitzone(); s.planer.ausfuehrer = &s.fern.ausfuehrer;
    s.planer.zuletztGeprueft = XbmTime_NowUtc();
    if (xbm_tl::Geladen()) laden();
    s.init = true;
}
// Welche Hosts brauchen die laufenden und geplanten Jobs?
static void zieleSammeln(const jobflow::Queue& q, std::set<std::string>& bestimmte, bool& alle) {
    for (const jobflow::Job& j : q.jobs) {
        if (j.ziel.wahl == jobflow::Zielwahl::IrgendeinOnline || j.ziel.wahl == jobflow::Zielwahl::Alle) alle = true;
        if (j.ziel.wahl == jobflow::Zielwahl::Bestimmte || j.ziel.wahl == jobflow::Zielwahl::Alle) for (auto& h : j.ziel.hosts) bestimmte.insert(h);
    }
}
static void verbindungenPflegen(std::int64_t jetztMs) {
    Z& s = z();
    std::set<std::string> noetig; bool alle = false;
    for (auto& l : s.planer.laeufe) zieleSammeln(l.queue, noetig, alle);
    for (auto& q : s.vorlagen) zieleSammeln(q, noetig, alle);
    const std::string geheimnis = UiNetImpl::Z().geheimnis;
    XbmNetNode& node = UiNetImpl::Node();
    s.fern.lokalerName = UiNetImpl::Z().name[0] ? UiNetImpl::Z().name : "lokal";
    s.fern.hosts.clear();
    for (const XbmNetPeer& p : node.Peers()) {
        if (p.name.empty() || p.cmdPort == 0) continue;
        if (!alle && !noetig.count(p.name)) continue;
        Z::Verb& v = s.verb[p.name];
        if (!v.cl) v.cl = std::make_unique<XbmCmdClient>();
        v.cl->Poll();
        const XbmCmdStatus st = v.cl->GetStatus();
        if (st != XbmCmdStatus::Bereit && st != XbmCmdStatus::Verbinde && jetztMs - v.letzterVersuchMs > 15000 && !geheimnis.empty()) {
            v.letzterVersuchMs = jetztMs; v.ip = p.ip; v.port = p.cmdPort;
            v.cl->Disconnect(); v.cl->Connect(p.ip, p.cmdPort, geheimnis);
        }
        if (v.cl->GetStatus() == XbmCmdStatus::Bereit) s.fern.hosts[p.name] = v.cl.get();
    }
    // Verbindungen zu Hosts, die niemand mehr braucht, schliessen
    for (auto it = s.verb.begin(); it != s.verb.end(); ) {
        bool gebraucht = alle || noetig.count(it->first);
        if (!gebraucht) { if (it->second.cl) it->second.cl->Disconnect(); it = s.verb.erase(it); } else ++it;
    }
}
void UiJobs_Poll() {
    Z& s = z(); if (!s.init) return;
    verbindungenPflegen(XbmNetNode_JetztMs());    // jeden Frame: Poll der eigenen Verbindungen
    static std::int64_t letzterTakt = 0;
    const std::int64_t t = XbmTime_NowUtc();
    if (t == letzterTakt) return;          // einmal je Sekunde reicht
    letzterTakt = t;
    if (xbm_tl::Geladen()) { nachladenWennNoetig(); s.planer.schritt(t); }
    for (auto& l : s.planer.laeufe) s.fern.abholen(l.queue, t);
}
void UiJobs_Draw() {
    if (!z().init) { ImGui::TextDisabled("Jobs: nicht initialisiert"); return; }
    ImGui::BeginChild("##jobs_links", ImVec2(ImGui::GetFontSize() * 13.0f, 0), true);
    vorlagenSpalte();
    ImGui::Separator(); ImGui::TextDisabled("Hosts");
    if (z().fern.hosts.empty()) ImGui::TextDisabled("  (nur lokal)");
    for (auto& h : z().fern.hosts) ImGui::BulletText("%s", h.first.c_str());
    for (auto& v : z().verb) if (!z().fern.hosts.count(v.first)) ImGui::TextDisabled("  %s: %s", v.first.c_str(), v.second.cl ? XbmCmdStatusText(v.second.cl->GetStatus()) : "-");
    ImGui::EndChild();
    ImGui::SameLine();
    ImGui::BeginChild("##jobs_rechts", ImVec2(0, 0), false);
    static bool alsGraph = false;
    if (jobflow::Queue* q = gewaehlt()) {
        if (ImGui::RadioButton("Liste", !alsGraph)) alsGraph = false;
        ImGui::SameLine();
        if (ImGui::RadioButton("Graph", alsGraph)) alsGraph = true;
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Node-Editor: Ausgang (orange) auf Eingang (grau) ziehen = verbinden; verbundenen Eingang tippen = loesen");
        if (alsGraph) graph(*q); else jobbaum(*q);
    } else ImGui::TextDisabled("Links eine Queue waehlen oder anlegen.");
    laeufe();
    ImGui::EndChild();
}
