#pragma once
#include "ui_form.h"   // UiFormLabel, UiFormWidth
// ui_textstore.h -- Textfelder mit Gedaechtnis (eigener Header, damit die
// Include-Reihenfolge egal ist: aus jeder eigenen Datei nutzbar via
//     #include "ui_textstore.h"
#include "imgui.h"
#include <map>
#include <string>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cfloat>
#include <string>

// ===========================================================================
// TEXTFELDER MIT GEDAECHTNIS
// ---------------------------------------------------------------------------
// Problem, das das hier loest: Ein Puffer, der als LOKALE Variable im
// Fenster-Code liegt, wird jeden Frame neu angelegt. Waehrend des Tippens
// sieht man trotzdem Text -- ImGui haelt den Bearbeitungszustand des
// AKTIVEN Feldes intern. Sobald das Feld den Fokus verliert, zeigt ImGui
// wieder den Puffer der Anwendung, und der ist leer. Deshalb "verliert"
// InputTextMultiline seinen Inhalt beim Herausklicken.
//
// UiText(key) liefert einen Puffer, der (a) ueber Frames hinweg lebt,
// (b) beim Bearbeiten automatisch in die xbm.ini geschrieben wird und
// (c) beim naechsten Start wieder da ist.
//
// Benutzung:
//     UiInputText("Betreff", "bewerben.betreff");
//     UiInputTextMultiline("Anschreiben", "bewerben.text",
//                          ImVec2(-1, 220));
// Der zweite Parameter ist ein frei waehlbarer, EINDEUTIGER Schluessel;
// unter ihm steht der Text in der ini.
// ===========================================================================
namespace ui_textstore_detail {
struct UiTextBuf { std::vector<char> data; };
inline std::map<std::string, UiTextBuf>& g_textBufs() {
    static std::map<std::string, UiTextBuf> m;
    return m;
}
inline UiTextBuf& TextBufFor(const std::string& key, size_t minCap) {
    UiTextBuf& b = g_textBufs()[key];
    if (b.data.size() < minCap) b.data.resize(minCap, 0);
    return b;
}
} // namespace ui_textstore_detail

// Speicher-Haken: app_settings.h haengt hier seine Save-Funktion ein,
// damit dieser Header NICHTS ueber die Persistenz wissen muss.
inline void (*&UiTextPersistHookPtr())() {
    static void (*fn)() = nullptr;
    return fn;
}
inline void UiTextPersistHook() {
    if (UiTextPersistHookPtr()) UiTextPersistHookPtr()();
}
// ABWAERTSKOMPATIBILITAET: Vor der Ausgliederung lagen die Puffer in
// ui_pages_detail. Aelterer Code (z.B. eine noch nicht ersetzte Fassung
// von app_settings.h) darf weiterhin ui_pages_detail::g_textBufs()
// schreiben -- der Name zeigt hier auf dieselbe Ablage.
namespace ui_pages_detail { using ui_textstore_detail::g_textBufs; }

// Zugriff auf ALLE Puffer (fuer das Speichern/Laden).
inline std::map<std::string, ui_textstore_detail::UiTextBuf>& UiTextAll() {
    return ui_textstore_detail::g_textBufs();
}

// ---------------------------------------------------------------------------
// UNBEGRENZTE TEXTLAENGE
// ---------------------------------------------------------------------------
// ImGui schreibt normalerweise in einen Puffer FESTER Groesse und hoert
// am Ende einfach auf. Mit ImGuiInputTextFlags_CallbackResize meldet es
// sich stattdessen, sobald der Platz nicht mehr reicht -- wir vergroessern
// dann den Puffer und reichen den neuen Zeiger zurueck. Damit ist die
// Textlaenge nur noch durch den Arbeitsspeicher begrenzt.
inline int UiTextResizeCb(ImGuiInputTextCallbackData* d) {
    if (d->EventFlag != ImGuiInputTextFlags_CallbackResize) return 0;
    auto* b = (ui_textstore_detail::UiTextBuf*)d->UserData;
    const size_t need = (size_t)d->BufTextLen + 1;   // inkl. Endnull
    // NUR VERGROESSERN, WENN ES WIRKLICH ZU KLEIN IST.
    // [Vorfassung verdoppelte bei JEDEM Aufruf. ImGui ruft diesen
    //  Callback aber in JEDEM Frame, solange das Feld aktiv ist (es
    //  schreibt den Puffer jedes Mal zurueck) -- aus 16 KB wurden so
    //  binnen ~17 Frames ueber 2 GB. Kein Absturz, sondern Androids
    //  Low-Memory-Killer per SIGKILL; deshalb blieb "logcat -b crash"
    //  leer.]
    if (b->data.size() >= need) {
        d->Buf = b->data.data();      // Zeiger trotzdem zurueckgeben
        return 0;
    }
    size_t want = b->data.size() * 2;         // amortisiertes Wachstum
    if (want < need)     want = need;
    if (want < 1024)     want = 1024;
    b->data.resize(want, 0);
    d->Buf = b->data.data();          // ImGui MUSS den neuen Zeiger
    return 0;                         // bekommen (realloc verschiebt!)
}

// Rohzugriff (z.B. um Inhalte zu setzen oder auszulesen).
inline char* UiText(const char* key, size_t capacity = 4096) {
    return ui_textstore_detail::TextBufFor(key, capacity).data.data();
}
inline void UiTextSet(const char* key, const char* value,
                      size_t capacity = 4096) {
    size_t need = (value ? strlen(value) : 0) + 1;
    if (capacity < need) capacity = need;      // langer Text passt immer
    auto& b = ui_textstore_detail::TextBufFor(key, capacity);
    snprintf(b.data.data(), b.data.size(), "%s", value ? value : "");
}
// Bequeme Ueberladung fuer std::string (z.B. Rueckgabe einer
// Datei-Lesefunktion): spart das .c_str() an jeder Aufrufstelle.
inline void UiTextSet(const char* key, const std::string& value,
                      size_t capacity = 0) {
    UiTextSet(key, value.c_str(),
              capacity ? capacity : value.size() + 1024);
}
// Inhalt als std::string abholen (Gegenstueck zu UiTextSet).
inline std::string UiTextGet(const char* key) {
    auto& m = ui_textstore_detail::g_textBufs();
    auto it = m.find(key);
    if (it == m.end() || it->second.data.empty()) return std::string();
    return std::string(it->second.data.data());
}
// SCHALTER mit Gedaechtnis: liegt als "0"/"1" in derselben Ablage wie
// die Textfelder und wandert damit automatisch in die xbm.ini.
inline bool UiFlagGet(const char* key, bool defVal = false) {
    auto& m = ui_textstore_detail::g_textBufs();
    auto it = m.find(key);
    if (it == m.end() || it->second.data.empty() || it->second.data[0] == 0)
        return defVal;
    return it->second.data[0] == '1';
}
inline void UiFlagSet(const char* key, bool v) {
    UiTextSet(key, v ? "1" : "0", 8);
    UiTextPersistHook();
}

// Einzeilig -- ersetzt ImGui::InputText, speichert automatisch.
inline bool UiInputText(const char* label, const char* key,
                        ImGuiInputTextFlags flags = 0,
                        size_t capacity = 1024) {
    auto& b = ui_textstore_detail::TextBufFor(key, capacity);
    // BESCHRIFTUNG DARUEBER, BREITE BEGRENZT (Regel aus ui_form.h).
    // [ImGui malt die Beschriftung RECHTS neben das Feld -- zusammen sind
    //  beide breiter als das Fenster, und das Fenster scrollt horizontal.
    //  Ueber dieses eine Feld laufen alle gespeicherten Textfelder der
    //  App; die Regel gilt damit ueberall.]
    UiFormLabel(label);
    ImGui::SetNextItemWidth(UiFormWidth());
    char id[160];
    ImFormatString(id, sizeof(id), "##%s", label);
    bool ch = ImGui::InputText(id, b.data.data(), b.data.size(),
                               flags | ImGuiInputTextFlags_CallbackResize,
                               &UiTextResizeCb, &b);
    if (ImGui::IsItemDeactivatedAfterEdit()) UiTextPersistHook();
    return ch;
}
// Mehrzeilig -- ersetzt ImGui::InputTextMultiline, speichert automatisch.
// GROESSE des Feldes (nicht der Textmenge!): ImGui deutet NEGATIVE Werte
// als "nimm den verfuegbaren Platz, abzueglich des Betrags". -FLT_MIN ist
// deshalb der uebliche Weg fuer "voll ausfuellen" -- Standard hier ist
// volle Breite UND volle Resthoehe des Fensters.
inline bool UiInputTextMultiline(const char* label, const char* key,
                                 const ImVec2& size
                                     = ImVec2(-FLT_MIN, -FLT_MIN),
                                 ImGuiInputTextFlags flags = 0,
                                 size_t capacity = 16384) {
    auto& b = ui_textstore_detail::TextBufFor(key, capacity);
    bool ch = ImGui::InputTextMultiline(
        label, b.data.data(), b.data.size(), size,
        flags | ImGuiInputTextFlags_CallbackResize,
        &UiTextResizeCb, &b);
    if (ImGui::IsItemDeactivatedAfterEdit()) UiTextPersistHook();
    return ch;
}

