#pragma once
// ui_navi.h -- FINGER-GEFUEHRTE RAND-NAVIGATIONEN.
//
// Links: Navi 0 (Seitenliste usw., Inhalt kommt per Callback aus
// ui_pages) plus beliebig viele ZUSATZ-Navis (schmaler, dunkler, fuer
// Buttons/Fenster), die beim Weiterziehen ueber den rechten Rand von
// Navi 0 nacheinander herauskommen. Rechts: eine schmale Button-Leiste
// mit vertikalem Scroll (ohne sichtbaren Balken).
//
// BEDIENUNG (Schiebe-Variante 1, per Dropdown im Navi-Zahnrad):
//  * Wisch von der Bildschirmkante: oeffnet (Navi klebt am Finger).
//  * Offene Navi irgendwo packen und schieben: klebt am Finger.
//  * LOSLASSEN entscheidet:
//      - SCHNELL (>900 px/s): ganz auf bzw. ganz zu.
//      - LANGSAM: die LETZTE Bewegungs-Delta auf X bestimmt die
//        Richtung (Vorschlag des Auftraggebers -- Geschwindigkeit ist
//        beim langsamen Schieben zu verrauscht, das letzte Delta ist
//        die ehrlichste Absicht); Ziel ist der NAECHSTE Begrenzer in
//        dieser Richtung (Navi fuer Navi).
//  * Kurzer STUBS auf freien Navi-Grund (kein Widget): faehrt ein.
//  * GRENZE zwischen Navi k und k+1 packen und nach links ziehen:
//    faehrt bis genau zu dieser Grenze ein.
//  * Langer Wisch: alle Navis breiten sich am Finger klebend aus;
//    Loslassen an der Wunsch-Grenze laesst genau bis dorthin offen.
//
// ANDOCKEN: Jede linke Navi traegt unten einen eigenen DockSpace --
// Fenster lassen sich dort hineinziehen oder per UiNaviDockWindow()
// programmatisch einsortieren. MENUEPUNKTE: UiNaviAddItem() mit page=""
// fuer GLOBAL oder page="Seitenname" fuer TAB-SPEZIFISCH (Mehrfach-
// Registrierung fuer mehrere Tabs).
#include <algorithm>
#include <utility>
#include <cstdio>
#include <cstdlib>
#include "imgui.h"
#include "ui_condbuttons.h"
#include "imgui_internal.h"
#include <string>
#include <vector>
#include <map>
#include <cmath>
#include <functional>
#include "ui_helpers.h"   // UiAndroidTastaturVerwenden()

namespace UiNavi {

// Bildschirm-Rechtecke der Abschnitte (Name -> (min, max)) -- Drop-Ziele.
inline std::map<std::string, std::pair<ImVec2, ImVec2>>& AbschnittRects() { static std::map<std::string, std::pair<ImVec2, ImVec2>> m; return m; }

struct Item {
    std::string label;
    std::string page;                 // "" = global, sonst Tab-Name(n)
    std::function<void()> fn;
};

struct Panel {
    std::string name;
    // GEFALTET: Panel ist eingeklappt (Grenz-Griff!) und nimmt keine
    // Breite ein; animW gleitet zwischen 0 und widthPx. Der Falt-
    // Zustand UEBERLEBT das Schliessen -- der naechste (langsame wie
    // schnelle) Swipe faehrt genau die VERSCHACHTELUNG wieder aus.
    bool  folded = false;
    float animW  = -1.0f;
    float widthPx = 220.0f;
    ImU32 bg      = IM_COL32(38, 38, 42, 245);
    std::vector<Item> items;
    ImGuiID dockId = 0;               // DockSpace-Id (0 = keiner)
    std::vector<std::string> dockQueue;   // Fenster, die hinein sollen
    std::function<void()> content;    // eigener Inhalt (vor den Items)
    // ABSCHNITTE: mehrere eigenstaendige Kind-Elemente untereinander, alle
    // gleich hoch (1:1, 1:1:1 ...), jedes mit eigener Ueberschrift und
    // eigenem Scrollbereich. Ist die Liste gesetzt, ersetzt sie "content".
    std::vector<std::pair<std::string, std::function<void()>>> abschnitte;
};

struct EdgeState {
    bool right = false;
    std::vector<Panel> panels;
    float openX   = 0.0f;             // aufgedeckte Breite (px)
    float targetX = 0.0f;
    bool  dragging  = false;
    bool  dragArmed = false;          // Druck liegt, Schwelle noch nicht
    float grabOff   = 0.0f;
    float lastDx    = 0.0f;           // letztes Frame-Delta (Richtung!)
    float vel       = 0.0f;           // geglaettet, px/s
    double pressT   = 0.0;
    ImVec2 pressP   = ImVec2(0, 0);
    int   grabBoundary = -1;          // Index der gepackten Grenze
    int   variant = 1;                // Schiebe-Variante (Dropdown)
    // Beim SCHNELL-ZUZIEHEN gemerkte Sichtbarkeit (folded je Panel):
    // die naechste Schnell-AUF-Geste stellt exakt diese Navis wieder
    // her. Leer = nichts gemerkt -> Schnell-AUF entfaltet alles.
    std::vector<unsigned char> savedFolded;
    // GESTEN-MODUS nach START-TEMPO: 0 = unbestimmt (erste ~90 ms),
    // 1 = LANGSAM gestartet (stufenweise), 2 = SCHNELL gestartet
    // (ganz auf/zu). fastDir merkt einen SPAETEREN schnellen Schub
    // waehrend einer langsam gestarteten Geste (2 Frames in Folge
    // ueber der Schwelle) -- dann gilt doch "komplett".
    int    mode    = 0;
    double dragT0  = 0.0;
    float  dragX0  = 0.0f;
    // Auf WELCHEM Panel hat der Finger aufgesetzt? -1 = ausserhalb.
    // Wird beim Druck festgehalten, weil sich die Aufteilung waehrend
    // des Zuges verschiebt. Bezugsgroesse fuer "kurzer Wisch faehrt DAS
    // Untermenue ein" -- die gepackte GRENZE taugt dafuer nicht: man
    // wischt ueblicherweise mitten auf dem Panel, nicht auf der Fuge.
    int    pressPanel = -1;
    float  fastDir = 0.0f;
    double fastDirT = 0.0;   // Ablauf: alter Schub zaehlt nicht mehr
    int    fastRun = 0;
    // RING der letzten Positionen: Richtungs-/Stillstandsentscheidung
    // ueber ein 120-ms-Fenster statt ueber das nervoese letzte Frame.
    double ringT[8] = {};
    float  ringX[8] = {};
    int    ringN    = 0;
    // LIVE-GRENZGRIFF: Ketten-Panel, das der Finger gerade faltet/
    // entfaltet, urspruengliche Grenze, und ob die Navi beim Griff
    // buendig offen war (dann bleibt die Kante buendig nachgefuehrt).
    int   foldChain = -1;
    int   foldPi0   = -1;
    bool  grabFlush = false;
    int   pendPanelOrd = 0;   // Ordinal des gedrueckten Unternavis
                              // (0 = Navi 0/keins -> klassischer Strip)
};
// ---- Z-ORDNUNG DER DREI SCHWEBENDEN ELEMENTE -----------------------
// Linke Navi, rechte Navi und das Einstellungsblatt lagen bisher jedes
// fuer sich per BringWindowToDisplayFront ganz vorn -- wer zuletzt
// gezeichnet wurde, gewann. Da die Reihenfolge fest war (links, dann
// Einstellungen, dann rechts), verschwand das Blatt zuverlaessig hinter
// der rechten Navi, und eine gerade herausgefahrene Navi blieb hinter
// dem Blatt.
//
// Jetzt entscheidet, WER ZULETZT ANGEFASST wurde. Jedes Element merkt
// sich beim Antippen bzw. beim Ziehen einen Zeitstempel; nach dem
// Zeichnen holt ApplyZOrder() sie in aufsteigender Reihenfolge nach
// vorn, so dass das juengste ganz oben liegt.
enum class ZElem { LeftNavi = 0, RightNavi = 1, Settings = 2 };
inline double& ZTime(ZElem e) {
    static double t[3] = { 0.0, 0.0, 0.0 };
    return t[(int)e];
}
inline void ZTouch(ZElem e) { ZTime(e) = ImGui::GetTime(); }
// Waehrend des Zeichnens gesammelt, danach von ApplyZOrder() benutzt.
inline std::vector<std::pair<double, ImGuiWindow*>>& ZPending() {
    static std::vector<std::pair<double, ImGuiWindow*>> v;
    return v;
}
inline void ZCollect(ZElem e, ImGuiWindow* w) {
    if (!w) return;
    // FOKUS ZAEHLT ALS BERUEHRUNG.
    // [Vorher wurde ZTouch nur an einzelnen Stellen gerufen: beim
    //  Ziehbeginn und beim Klick ins Einstellungsblatt. Jeder andere Weg
    //  zum Fokus -- ein Knopf in der Navigation, ein Eingabefeld in den
    //  Einstellungen, Tastaturnavigation -- blieb unbemerkt, und das
    //  Fenster blieb hinten. ImGui setzt den Fokus beim Klick auf
    //  IRGENDEIN Element des Fensters; wertet man ihn direkt aus, stimmt
    //  die Stapelordnung per Konstruktion statt an aufgezaehlten
    //  Einzelstellen.]
    ImGuiContext& g = *ImGui::GetCurrentContext();
    if (g.NavWindow
        && g.NavWindow->RootWindowDockTree == w->RootWindowDockTree)
        ZTouch(e);
    ZPending().push_back({ ZTime(e), w });
}
// NACH beiden DrawPanels-Aufrufen und nach dem Einstellungsblatt rufen.
inline void ApplyZOrder() {
    auto& v = ZPending();
    std::sort(v.begin(), v.end(),
              [](const std::pair<double, ImGuiWindow*>& a,
                 const std::pair<double, ImGuiWindow*>& b) {
                  return a.first < b.first;   // aeltestes zuerst
              });
    for (auto& e : v) ImGui::BringWindowToDisplayFront(e.second);
    v.clear();
}

inline float WindowedDelta(EdgeState& s, double window) {
    double now = ImGui::GetTime();
    float ref = s.openX;
    for (int i = 0; i < (s.ringN < 8 ? s.ringN : 8); ++i) {
        int idx = (s.ringN - 1 - i) & 7;
        ref = s.ringX[idx];
        if (now - s.ringT[idx] >= window) break;
    }
    return s.openX - ref;
}

inline EdgeState& Left()  { static EdgeState s;                    return s; }
inline EdgeState& Right() { static EdgeState s; s.right = true;    return s; }

// FLAECHE DER RECHTEN NAVI im letzten Frame -- ui_pages braucht sie, um
// zu erkennen, ob ein gezogenes Fenster DARUEBER losgelassen wurde.
// [Die Navi zeichnet sich selbst und kennt ihre Rechtecke; ui_pages
//  kennt den Fensterzug. Ein Merker statt einer Abhaengigkeit.]
inline ImRect& RightRectLastFrame() { static ImRect r(0,0,0,0); return r; }
inline bool& AppSettingsOpen() { static bool b = false; return b; }
// Einstellungsblatt oeffnen UND nach vorn holen.
// Soll das Einstellungsblatt seitlich mit dem DockSpace abschliessen
// (also die offenen Navis aussparen) statt ueber die volle Breite zu
// laufen? Wird in xbm.ini gesichert.
inline bool& AppSheetAlignDock() { static bool v = false; return v; }

inline void AppSettingsShow(bool on) {
    AppSettingsOpen() = on;
    if (on) ZTouch(ZElem::Settings);
}
inline float& AppBtnTop()      { static float y = -1.0f; return y; }
inline ImRect& AppSheetRect()  { static ImRect r(0, 0, 0, 0); return r; }
// Klick von der Navi verbraucht (Bruecke zu UiDragHandledThisFrame,
// das hier nicht sichtbar ist -- ui_pages reicht es durch).
inline bool& ConsumedClick()   { static bool b = false; return b; }
// Boden-Faenger-IDs der Panels (pro Frame): der Kurz-Stubs-Schliesser
// muss diese Treffer als "freien Navi-Grund" durchwinken.
inline ImVector<ImGuiID>& GroundIds() {
    static ImVector<ImGuiID> v;
    return v;
}
inline std::function<void()>& AppSettingsContent() {
    static std::function<void()> f;
    return f;
}

// EFFEKTIVE Breite eines Panels: REINER Leser (keine Seiteneffekte).
// [Die Vorfassung lerpte bei JEDEM Aufruf -- Boundaries/TotalW/Zeichnen
// riefen sie mehrfach pro Frame, die Animation lief vervielfacht und
// die Gesamtbreite wackelte unterm Finger: DAS zerlegte das Kleben der
// langen Swipes und die Begrenzer-Griffe.]
inline float EffW(Panel& p) {
    if (p.animW < 0.0f) p.animW = p.folded ? 0.0f : p.widthPx;
    return p.animW;
}
// Falt-Animation EINMAL pro Frame vorruecken; das vom Finger gefuehrte
// Ketten-Panel bleibt eingefroren (der Finger schreibt animW direkt).
inline void AdvanceFold(Panel& p, bool frozen) {
    if (p.animW < 0.0f) p.animW = p.folded ? 0.0f : p.widthPx;
    if (frozen) return;
    float tgt = p.folded ? 0.0f : p.widthPx;
    float dt = ImGui::GetIO().DeltaTime;
    p.animW += (tgt - p.animW)
             * (1.0f - expf(-24.0f * (dt > 0 ? dt : 0.016f)));
    // GROSSZUEGIG schnappen (3px): der fruehere 0.5px-Ausklang liess in
    // Kombination mit der 2px-Zeichenschwelle sichtbar "ein paar Pixel
    // haengen, die dann verschwinden".
    if (fabsf(tgt - p.animW) < 3.0f) p.animW = tgt;
}
// Breite, die die Kante nach der aktuellen FALTUNG anstreben soll.
// TotalW() summiert animW und hinkt der Faltung deshalb hinterher --
// direkt nach dem Setzen von folded liefert es noch den alten Wert.
// Welches Panel liegt an der Bildschirmposition x?
inline int PanelAtX(EdgeState& s, float x, float workL, float workR) {
    float acc = 0.0f;
    for (int i = 0; i < (int)s.panels.size(); ++i) {
        const float ew = s.panels[i].folded ? 0.0f : s.panels[i].animW;
        if (ew <= 0.5f) continue;
        const float from = s.right ? (workR - acc - ew) : (workL + acc);
        if (x >= from && x < from + ew) return i;
        acc += ew;
    }
    return -1;
}

// Grenzen aus den ZIELbreiten (gefaltet = 0, sonst widthPx).
// Boundaries() rechnet mit animW und wandert deshalb WAEHREND einer
// Faltung mit -- als Raster fuer die Ruhelage ist es unbrauchbar.
inline void TargetBoundaries(EdgeState& s, std::vector<float>& out) {
    out.clear();
    out.push_back(0.0f);
    float acc = 0.0f;
    for (auto& p : s.panels) {
        if (p.folded) continue;
        acc += p.widthPx;
        out.push_back(acc);
    }
}

inline float TargetW(EdgeState& s) {
    float t = 0.0f;
    for (auto& p : s.panels) t += p.folded ? 0.0f : p.widthPx;
    return t;
}

// RICHTUNGSENTSCHEIDUNG BEIM LOSLASSEN.  +1 = aufziehen, -1 = einfahren.
//
// Bisher stand das zweimal als Ausdruck im Code:
//     float dir = fastDir ? fastDir : (lastDx ? lastDx : vel);
//     if (dir >= 0.0f) FastOpenAll(s); else fastCloseAll(s);
// Zwei Fehler darin:
//  * Es zaehlte das Delta des LETZTEN FRAMES. Hebt man den Finger, ist
//    das haeufig exakt 0 -- und 0 fiel wegen ">= 0" auf die Seite
//    AUFZIEHEN. Genau daher das "springt am Ende total unangenehm
//    wieder raus".
//  * Ein alter Schub (fastDir) schlug das aktuelle Zeitfenster, auch
//    wenn der Finger laengst die Richtung gewechselt hatte.
// Jetzt zaehlt zuerst das ZEITFENSTER (die letzten ~120 ms), und nur
// wenn das nichts hergibt, der gemerkte Schub bzw. die Geschwindigkeit.
// Unentschieden faehrt EIN, nicht aus.
inline int ReleaseDir(float windowedDelta, float fastDir, float vel) {
    if (windowedDelta >  1.0f) return  1;
    if (windowedDelta < -1.0f) return -1;
    if (fastDir >  0.0f) return  1;
    if (fastDir <  0.0f) return -1;
    return (vel > 1.0f) ? 1 : -1;
}

inline float TotalW(EdgeState& s) {
    float t = 0.0f;
    for (auto& p : s.panels) t += EffW(p);
    return t;
}
// Begrenzer ueber die EFFEKTIVEN Breiten: 0, e0, e0+e1, ..., total.
// Gefaltete Panels tragen 0 bei -- die Stufen des langsamen Swipes
// sind damit exakt die gespeicherte Verschachtelung.
inline void Boundaries(EdgeState& s, std::vector<float>& out) {
    out.clear(); out.push_back(0.0f);
    float a = 0.0f;
    for (auto& p : s.panels) {
        float e = EffW(p);
        if (e > 0.5f) { a += e; out.push_back(a); }
    }
}
// Panel links einer effektiven Grenze k (fuer den Grenz-Griff): liefert
// den Index des k-ten SICHTBAREN Panels (1-basiert -> k-1).
inline int PanelLeftOfBoundary(EdgeState& s, int k) {
    int vis = 0;
    for (int i = 0; i < (int)s.panels.size(); ++i) {
        if (EffW(s.panels[i]) <= 0.5f) continue;
        if (++vis == k) return i;
    }
    return -1;
}

inline void RequestClose(EdgeState& s) { s.targetX = 0.0f; }
// Welcher Abschnitt im App-Blatt ist aufgeklappt: 0 = App, 1 = Navigation.
// [Das Navi-Zahnrad oeffnete vorher ein Popup. Das lag hinter der Navi
//  und an der Mausposition statt am Knopf -- Popups nehmen am Z-System
//  nicht teil. Jetzt zeigt derselbe Knopf einen Abschnitt IM App-Blatt,
//  das obenauf liegt und an Ort und Stelle steht.]
inline int& AppSheetAbschnitt() { static int a = 0; return a; }
// Von aussen aufzurufen, wenn eine Navi per Knopf/Geste herausgefahren
// wird -- damit sie in den Vordergrund rueckt.
inline void RequestOpen(EdgeState& s, float w) {
    s.targetX = w;
    ZTouch(s.right ? ZElem::RightNavi : ZElem::LeftNavi);
}
inline void AddItem(EdgeState& s, int panel, const char* label,
                    const char* page, std::function<void()> fn) {
    if (panel < 0 || panel >= (int)s.panels.size()) return;
    s.panels[panel].items.push_back({label, page ? page : "", fn});
}
inline void DockWindow(EdgeState& s, int panel, const char* winName) {
    if (panel < 0 || panel >= (int)s.panels.size()) return;
    s.panels[panel].dockQueue.push_back(winName);
}

// ---------------------------------------------------------------------------
// EINGABE-MASCHINE eines Randes. workL/workR/topY/botY = nutzbare Flaeche.
// ---------------------------------------------------------------------------
// ---- WAS SOLL BEIM LOSLASSEN PASSIEREN? ---------------------------
// Als eigene, reine Funktion, damit die Regel pruefbar ist statt als
// Kette von else-if im Zeichencode zu stehen.
//
// WARUM DER KURZE WISCH BISHER WIRKUNGSLOS WAR:
// Das Tempo wurde als GESAMTSTRECKE / GESAMTZEIT bestimmt. Ein kurzer,
// schneller Wisch (etwa 25 px in 80 ms) ergibt 310 px/s und galt damit
// als "langsam" -- obwohl er sich schnell anfuehlt. Die Geste landete im
// Stufen-Zweig und bewegte hoechstens eine Grenze. Jetzt zaehlt die
// ENDGESCHWINDIGKEIT (s.vel, geglaettet), unabhaengig von der Strecke.
enum class NaviPlan {
    CloseAll,      // ganze Navigation einfahren
    FoldGrabbed,   // nur das angefasste Unternavi einfahren
    OpenSaved,     // gemerkten Stand ausfahren
    Step,          // eine Stufe weiter (langsamer Zug)
    Snap           // zur naechsten Grenze (Stillstand)
};

// travel   = zurueckgelegte Strecke der ganzen Geste (openX - dragX0)
// dWin     = Bewegung im letzten ~120-ms-Fenster (Richtung)
// vel      = geglaettete Endgeschwindigkeit in px/s
// grabbed  = Index des angefassten Unternavis, -1 = Navi 0 / freie Flaeche
inline NaviPlan PlanRelease(float travel, float dWin, float fastDir,
                            float vel, int grabbed, bool startedClosed,
                            double heldSec) {
    // Ein WISCH ist eine Geste mit Schwung -- ODER eine, die einfach sehr
    // kurz war. Beides muss zaehlen:
    //  * kFlickVel: klarer Schwung am Ende.
    //  * kQuickSec/kQuickPx: der "ganz kurze Pinch" -- etwa 10 px in
    //    30 ms. Das sind nur ~330 px/s und lag damit UNTER kFlickVel;
    //    die Geste landete bei Snap und die Navigation schnappte zur
    //    naechsten Grenze zurueck. Genau das gemeldete Zurueckschnappen.
    const float  kFlickVel = 600.0f;
    const double kQuickSec = 0.25;   // so lange gilt eine Geste als kurz
    const float  kQuickPx  = 6.0f;   // darunter ist es ein Tipp
    // Bis hierhin gilt ein Wisch als "kurz": er meint dann nur das
    // angefasste Unternavi, nicht die ganze Leiste.
    const float kShortPx  = 120.0f;

    const bool flick = fabsf(vel) > kFlickVel
                    || (heldSec < kQuickSec && fabsf(travel) > kQuickPx);
    const int  dir   = ReleaseDir(dWin, fastDir, vel);

    if (flick) {
        if (dir > 0) return NaviPlan::OpenSaved;      // nach innen
        // nach aussen (zum Bildschirmrand)
        if (grabbed >= 0 && fabsf(travel) < kShortPx)
            return NaviPlan::FoldGrabbed;             // kurz auf Unternavi
        return NaviPlan::CloseAll;                    // lang, oder Navi 0
    }
    (void)startedClosed;
    if (fabsf(dWin) < 14.0f) return NaviPlan::Snap;
    return NaviPlan::Step;
}

inline void FastOpenAll(EdgeState& es) {
    // ENTSCHEIDEND: ob die Navi beim BEGINN der Geste zu war, nicht beim
    // Loslassen.
    // [Vorher stand hier  es.openX <= 4.0f  -- also der Zustand am ENDE.
    //  Beim Hereinwischen vom Rand faehrt die Navi waehrend des Ziehens
    //  aber bereits auf; bei Loslassen war openX laengst gross, der
    //  Zweig "war schon offen -> ALLES entfalten" griff, und deshalb kam
    //  jedes Mal die komplette Navigation heraus statt des gemerkten
    //  Standes. dragX0 haelt den Stand beim Antippen fest.]
    const bool wasClosed = (es.dragX0 <= 4.0f);
    auto setFold = [&](size_t idx, bool f) {
        es.panels[idx].folded = f;
        es.panels[idx].animW  = f ? 0.0f : es.panels[idx].widthPx;
    };
    if (wasClosed && es.savedFolded.size() == es.panels.size()) {
        for (size_t i2 = 0; i2 < es.panels.size(); ++i2)
            setFold(i2, es.savedFolded[i2] != 0);
        // Notbremse: eine Merkliste, in der ALLES gefaltet ist,
        // wuerde beim Aufwischen nichts zeigen. Dann mindestens
        // Navi 0.
        bool any = false;
        for (auto& P : es.panels) if (!P.folded) any = true;
        if (!any) setFold(0, false);
    } else if (wasClosed) {
        for (size_t i2 = 0; i2 < es.panels.size(); ++i2)
            setFold(i2, i2 != 0);          // nur Navi 0
    } else {
        for (size_t i2 = 0; i2 < es.panels.size(); ++i2)
            setFold(i2, false);            // alles
    }
    es.targetX = TargetW(es);
}

inline void UpdateDrag(EdgeState& s, float workL, float workR,
                       float topY, float botY) {
    ImGuiIO& io = ImGui::GetIO();
    if (!s.right) GroundIds().clear();   // pro Frame frisch (links zuerst)
    // Falt-Animationen genau EINMAL pro Frame vorruecken.
    for (int i = 0; i < (int)s.panels.size(); ++i)
        AdvanceFold(s.panels[i],
                    s.dragging && s.grabBoundary >= 0 && i == s.foldChain);
    // App-Einstellungen offen: NUR der Bereich UNTER dem Sheet ist
    // gesperrt -- daneben bleibt die Navi voll bedienbar.
    if (AppSettingsOpen()
        && AppSheetRect().Contains(io.MousePos)) {
        s.dragging = false; s.dragArmed = false;
        return;
    }
    ImGuiContext* g = ImGui::GetCurrentContext();
    float total = TotalW(s);
    if (total < 1.0f) {
        bool anyOpen = false;
        for (auto& pp : s.panels) if (!pp.folded) { anyOpen = true; break; }
        if (!anyOpen && !s.panels.empty()) {
            for (auto& pp : s.panels) pp.folded = false;
        }
        return;   // animW waechst ab dem naechsten Frame nach
    }
    // Bildschirm-X der Kante der aufgedeckten Navi:
    float edgeX = s.right ? (workR - s.openX) : (workL + s.openX);
    auto fingerOpen = [&](float mx) -> float {
        return s.right ? (workR - mx) : (mx - workL);   // Kanten-Abstand
    };
    bool inBandY = io.MousePos.y >= topY && io.MousePos.y <= botY;

    // TIPP AUSSERHALB DER NAVI FAEHRT SIE EIN.
    // [Wer ein Fenster der Seite beruehrt, will dort arbeiten -- die
    //  offene Navi daneben stoert dann nur. Ausgenommen: die Tab-Leiste
    //  oben (die schliesst ohnehin selbst) und ein offenes
    //  Einstellungsblatt (dort klickt man bewusst neben die Navi).
    //  Ein Sicherheitsabstand von einer Griffbreite verhindert, dass ein
    //  Tipp knapp neben die Kante als "aussen" gilt.]
    if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) && inBandY
        && !s.right                      // nur die LINKE -- die rechte bleibt
        && !s.dragging && s.openX > 4.0f && !AppSettingsOpen()) {
        float abstand = fingerOpen(io.MousePos.x) - s.openX;   // > 0 = ausserhalb
        if (abstand > 24.0f) {
            s.savedFolded.clear();
            for (auto& P : s.panels) s.savedFolded.push_back(P.folded ? 1 : 0);
            RequestClose(s);
            // Diesen Klick nicht zusaetzlich als Ziehbeginn werten.
            s.pressT = 0.0; s.dragArmed = false; s.grabBoundary = -1;
            return;
        }
    }

    if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) && inBandY) {
        s.pressT = ImGui::GetTime(); s.pressP = io.MousePos;
        s.grabBoundary = -1; s.dragArmed = false;
        s.pressPanel = PanelAtX(s, io.MousePos.x, workL, workR);
        // Stand beim ANTIPPEN festhalten. FastOpenAll entscheidet daran,
        // ob der gemerkte Stand wiederhergestellt oder weiter entfaltet
        // wird -- und ohne Zieh-Schwelle wird dragX0 sonst nie gesetzt.
        s.dragX0 = s.openX;
        s.pendPanelOrd = 0;   // Richtungs-Modus gilt NUR fuer den
                              // Druck, der ihn gesetzt hat
        float fo = fingerOpen(io.MousePos.x);
        if (s.openX < 4.0f) {
            // GESCHLOSSEN: der Kanten-Wisch oeffnet -- GNAEDIGE Zone
            // von 56 px, denn der Daumen startet selten exakt an der
            // Bildschirmkante. Gefahrlos, weil der Zug erst nach 6 px
            // Bewegung in OEFFNUNGS-Richtung uebernimmt (s.u.) --
            // Tipps auf randnahe Buttons bleiben normale Tipps.
            if (fo <= 56.0f) {
                s.dragArmed = true; s.grabOff = fo - s.openX;
            }
        } else if (ImGui::IsDragDropActive()) {
            // ZIEHEN AUS DER PALETTE HAT VORRANG.
            // [Ein waagerechter Wisch IN der offenen Navi galt als
            //  Navi-Zug und stahl das Ziehen: das Fenster liess sich nicht
            //  auf den DockSpace bringen. Laeuft ein DragDrop, haelt sich
            //  die Navi heraus.]
        } else if (fo <= s.openX + 24.0f) {
            // OFFEN: Druck auf der Navi (oder knapp an ihrer Kante).
            s.dragArmed = true; s.grabOff = fo - s.openX;
            // GRENZE gepackt? (±14 px um eine innere Grenze)
            std::vector<float> b; Boundaries(s, b);
            // BREITERE Grenzzone (22px, Touch!) und bei Ueberlappung
            // die NAECHSTGELEGENE Grenze -- die Zone zwischen schmalen
            // Unternavis war sonst kaum zu treffen. Auch die LETZTE
            // Kante (Strip-Front) zaehlt: von dort faehrt die Kette
            // nacheinander aus bzw. ein.
            float bestD = 22.0f + 1.0f; int bestI = -1;
            for (int i = 1; i < (int)b.size(); ++i) {
                float d = fabsf(fo - b[i]);
                if (d <= 22.0f && d < bestD) { bestD = d; bestI = i; }
            }
            if (bestI >= 0) {
                s.grabBoundary = bestI;
                s.foldPi0 = s.foldChain = PanelLeftOfBoundary(s, bestI);
                s.grabFlush = (s.openX >= TotalW(s) - 0.5f);
            } else {
                // KEINE Grenze getroffen: gedrueckt in welchem Panel?
                // Unternavis (Ordinal >= 1) bekommen den RICHTUNGS-
                // Modus (s.u.), Navi 0 den klassischen Strip.
                s.pendPanelOrd = 0;
                float acc = 0.0f; int ord = 0;
                for (auto& pp : s.panels) {
                    float e = EffW(pp);
                    if (e <= 0.5f) continue;
                    if (fo >= acc && fo < acc + e)
                        { s.pendPanelOrd = ord; break; }
                    acc += e; ++ord;
                }
            }
        }
    }
    if (s.dragArmed && io.MouseDown[0]) {
        // Liegt der Druck auf einem echten Widget (Button, Checkbox,
        // Slider), uebernimmt die Navi-Geste erst nach 24 px statt 8 --
        // ein Tipp bleibt so sicher ein Tipp, ein Wisch bleibt Wisch.
        bool onWidget = false;
        if (g && g->ActiveId != 0) {
            onWidget = true;
            for (int gi = 0; gi < GroundIds().Size; ++gi)
                if (g->ActiveId == GroundIds()[gi]) { onWidget = false; break; }
        }
        float mvThresh = onWidget ? 24.0f : 8.0f;
        float mv = fabsf(io.MousePos.x - s.pressP.x);
        // Geschlossen: erst 6 px Bewegung RICHTUNG OEFFNEN starten den
        // Zug. [Vorher startete er beim blossen Druck in der Zone --
        // mit der breiteren Zone wuerde das randnahe Buttons toeten.]
        float openDx = (io.MousePos.x - s.pressP.x)
                     * (s.right ? -1.0f : 1.0f);
        if (!s.dragging
            && (mv > mvThresh || (s.openX < 4.0f && openDx > 6.0f))) {
            // Ab hier klebt die Navi am Finger; ein evtl. angedrueckter
            // Widget-Klick wird freigegeben (wie beim Pinpoint).
            s.dragging = true;
            ZTouch(s.right ? ZElem::RightNavi : ZElem::LeftNavi);
            s.mode = 0; s.dragT0 = ImGui::GetTime();
            s.dragX0 = s.openX; s.fastDir = 0.0f; s.fastRun = 0;
            if (g->ActiveId != 0 && !g->ActiveIdHasBeenEditedBefore)
                ImGui::ClearActiveID();
            // RICHTUNGS-MODUS der Unternavis: Die erste Zugrichtung
            // waehlt. LINKS = das ANGEWAEHLTE Subnavi selbst faehrt
            // ein (seine RECHTE Grenze wird gefuehrt; ueber sein Ende
            // hinaus faltet die Kette das naechste links liegende
            // Element weiter). RECHTS = die FRONT: nacheinander alles
            // wieder heraus, am Ende die ganze Navi.
            if (s.grabBoundary < 0 && s.pendPanelOrd >= 1) {
                std::vector<float> b2; Boundaries(s, b2);
                float dir0 = (io.MousePos.x - s.pressP.x)
                           * (s.right ? -1.0f : 1.0f);
                int bIdx = (dir0 < 0.0f)
                         ? s.pendPanelOrd + 1   // RECHTE Grenze des
                                                // beruehrten Panels
                         : (int)b2.size() - 1;  // Front
                if (bIdx >= 1 && bIdx < (int)b2.size()) {
                    s.grabBoundary = bIdx;
                    s.foldPi0 = s.foldChain =
                        PanelLeftOfBoundary(s, bIdx);
                    s.grabFlush = (s.openX >= TotalW(s) - 0.5f);
                }
            }
            s.pendPanelOrd = 0;
        }
        if (s.dragging && s.grabBoundary >= 0 && s.foldChain >= 0) {
            // LIVE-GRENZGRIFF: Der Finger faltet/entfaltet AB DER
            // GRENZE -- das Panel links davon schrumpft/waechst am
            // Finger; ist es zu, faltet der Zug das naechste links
            // weiter, ist es voll, entfaltet er das naechste versteckte
            // links der urspruenglichen Grenze.
            float dx = io.MouseDelta.x * (s.right ? -1.0f : 1.0f);
            while (fabsf(dx) > 0.01f && s.foldChain >= 0) {
                Panel& P = s.panels[s.foldChain];
                if (dx < 0.0f) {
                    float take = P.animW < -dx ? P.animW : -dx;
                    P.animW -= take; dx += take;
                    s.openX -= take;   // Front folgt der Faltung
                    if (P.animW <= 0.01f) {
                        P.animW = 0.0f; P.folded = true;
                        int nxt = -1;
                        for (int i = s.foldChain - 1; i >= 0; --i)
                            if (!s.panels[i].folded) { nxt = i; break; }
                        s.foldChain = nxt;
                    }
                } else {
                    float room = P.widthPx - P.animW;
                    float take = room < dx ? room : dx;
                    P.animW += take; dx -= take;
                    s.openX += take;   // Front folgt der Entfaltung --
                                       // die rechten Nachbarn rueckten
                                       // sonst UEBER die Front hinaus
                                       // und wurden abgeschnitten
                    if (P.animW >= P.widthPx - 0.01f) {
                        P.animW = P.widthPx; P.folded = false;
                        // NAECHSTES Entfalt-Ziel: ERST die an dieser
                        // Grenze verschluckten Panels RECHTS davon
                        // (kleinster Index > foldPi0 -- genau die waren
                        // vorher UNERREICHBAR: die Suche lief nur nach
                        // links, eingeklappte Navi 2/3 liessen sich nie
                        // wieder oeffnen, "rechts ging gar nichts"),
                        // dann als Rueckfall die Gefalteten links.
                        int nxt = -1;
                        for (int i = s.foldPi0 + 1;
                             i < (int)s.panels.size(); ++i)
                            if (s.panels[i].folded) { nxt = i; break; }
                        if (nxt < 0)
                            for (int i = s.foldPi0; i >= 0; --i)
                                if (s.panels[i].folded) { nxt = i; break; }
                        s.foldChain = nxt;
                        if (nxt < 0) break;
                    }
                }
            }
            if (fabsf(dx) > 0.01f) {
                // KETTE ERSCHOEPFT: Rest-Bewegung fuehrt die GESAMT-
                // Oeffnung weiter -- am Ende faehrt die ganze Navi am
                // Stueck weiter aus (oder ein) und bleibt beim Los-
                // lassen exakt dort stehen.
                s.openX += dx;
                s.grabFlush = false;
            }
            float tot = TotalW(s);
            if (s.openX < 0.0f)  s.openX = 0.0f;
            if (s.openX > tot)   s.openX = tot;
            if (s.grabFlush)     s.openX = tot;
            s.targetX = s.openX;
        } else if (s.dragging) {
            float nx = fingerOpen(io.MousePos.x) - s.grabOff;
            if (nx < 0.0f)   nx = 0.0f;
            float total2 = TotalW(s);
            // KOLLABIERTE Unternavis wieder herausziehen: Gefaltete
            // Panels tragen 0 zur Gesamtbreite bei -- ein normaler
            // Strip-Zug (Griff NICHT an einer Grenze) klemmte deshalb
            // bei der Breite der sichtbaren Panels fest und konnte die
            // eingeklappten NIE wieder hervorholen ("teilweise nicht
            // mehr rausziehen"). Erreicht der Zug die Front und will
            // weiter nach aussen, entfaltet er das naechste versteckte
            // Panel (von links nach rechts) und zieht danach normal
            // weiter -- Panel fuer Panel, wie beim Grenz-Griff.
            if (nx >= total2 - 0.5f) {
                float dxOut = io.MouseDelta.x * (s.right ? -1.0f : 1.0f);
                if (dxOut > 0.0f) {
                    for (auto& pp : s.panels)
                        if (pp.folded) { pp.folded = false; break; }
                    total2 = TotalW(s);
                }
            }
            if (nx > total2) nx = total2;
            float dxScreen = io.MouseDelta.x * (s.right ? -1.0f : 1.0f);
            s.lastDx = dxScreen;
            float dt = io.DeltaTime > 0.0f ? io.DeltaTime : 0.016f;
            float v  = dxScreen / dt;
            s.vel += (v - s.vel) * (1.0f - expf(-14.0f * dt));
            // DESENSIBILISIERT: 1600 px/s -- die alte 900er-Schwelle
            // stufte normales, zuegiges Ziehen schon als "schnell" ein;
            // Einzelstufen brauchten Zeitlupe. Jetzt zaehlt nur ein
            // echter Flick als schnell.
            const float kFast = 1600.0f;
            if (s.mode == 0
                && ImGui::GetTime() - s.dragT0 >= 0.09) {
                float avg = fabsf(nx - s.dragX0)
                          / (float)(ImGui::GetTime() - s.dragT0);
                s.mode = (avg > kFast) ? 2 : 1;
            }
            s.ringT[s.ringN & 7] = ImGui::GetTime();
            s.ringX[s.ringN & 7] = nx;
            ++s.ringN;
            // SPAETERER SCHNELL-SCHUB in einer langsamen Geste:
            // zwei Frames in Folge ueber der Schwelle uebersteuern
            // zu "komplett" in Schub-Richtung.
            if (fabsf(v) > kFast) {
                // DESENSIBILISIERT: 3 Frames in Folge UND >40px im
                // 80-ms-Fenster -- ein Wackler beim Loslassen einer
                // langsamen Geste fuhr sonst alles komplett ein.
                if (++s.fastRun >= 3
                    && fabsf(WindowedDelta(s, 0.08)) > 40.0f) {
                    s.fastDir = (v > 0) ? 1.0f : -1.0f;
                    s.fastDirT = ImGui::GetTime();
                }
            } else s.fastRun = 0;
            s.openX = s.targetX = nx;
        }
    }
    // SCHNELL GANZ ZU: Sichtbarkeit merken, alles einfahren.
    auto fastCloseAll = [&](EdgeState& es) {
        es.savedFolded.clear();
        for (auto& P : es.panels)
            es.savedFolded.push_back(P.folded ? 1 : 0);
        es.targetX = 0.0f;
    };
    // SCHNELL GANZ AUF: gemerkte Sichtbarkeit wiederherstellen; ohne
    // Merkliste (oder wenn schon offen) ALLES entfalten -- auch die an
    // Grenzen verschluckten Navi 1..n.
    // SCHNELL GANZ AUF -- drei klar getrennte Faelle:
    //  1. War ZU und es gibt eine Merkliste -> genau diese Kombination
    //     von Unternavis wiederherstellen.
    //  2. War ZU und es gibt keine -> NUR NAVI 0. [Vorher fuhr hier
    //     alles auf einmal aus; beim ersten Wisch sprang die komplette
    //     Kaskade heraus, was mit "erstmal nur Navi 0" nicht
    //     zusammenpasst.]
    //  3. War schon OFFEN und es wird weiter nach innen gewischt ->
    //     alles entfalten (der Nutzer will erkennbar MEHR sehen).
    // (Definition steht als FastOpenAll vor UpdateDrag)
    if (s.dragArmed && !io.MouseDown[0]) {
        // ---- LOSLASSEN: EINE Auswertung fuer ALLE Faelle ---------------
        // [Vorher gab es hier ZWEI Pfade mit je eigenen Schwellen: einen
        //  fuer "die Zieh-Schwelle wurde ueberschritten" (s.dragging) und
        //  einen fuer kurze Gesten. Dieselbe Fingerbewegung fiel je nach
        //  Panel mal in den einen, mal in den anderen -- und die Schwellen
        //  passten nicht zueinander. Genau daher das Zurueckschnappen bei
        //  ganz kurzen Wischern. Jetzt wird EINMAL aus den Rohdaten des
        //  Fingers entschieden; s.dragging steuert nur noch, ob es
        //  ueberhaupt eine Alternative zum Nichtstun gibt.]
        const double held = ImGui::GetTime() - s.pressT;
        const float  dxS  = io.MousePos.x - s.pressP.x;
        // In OEFFNUNGS-Richtung: an der linken Kante oeffnet +x, rechts -x.
        const float  dOpen = s.right ? -dxS : dxS;
        const float  speed = (held > 0.001) ? (fabsf(dxS) / (float)held)
                                            : 0.0f;
        std::vector<float> b; Boundaries(s, b);

        // Was ist ein WISCH? Drei Wege dorthin, damit weder ein sehr
        // kurzer noch ein sehr langsamer durchfaellt:
        //   * knapp und kurz   -- der "Pinch": >= 3 px in < 0.30 s
        //   * schnell          -- Schwung am Ende, egal wie weit
        //   * als schnell erkannt -- mode 2 oder ein Schub in den
        //     letzten 0.30 s
        const float  kMinPx   = 3.0f;
        const double kQuickS  = 0.30;
        const float  kSpeed   = 500.0f;
        const bool   schub    = (s.fastDir != 0.0f)
                             && (ImGui::GetTime() - s.fastDirT < 0.30);
        const bool   wisch    = (fabsf(dOpen) >= kMinPx)
                             && (held < kQuickS || speed > kSpeed
                                 || s.mode == 2 || schub);

        if (wisch) {
            if (dOpen < 0.0f) {
                // ---- ZUM BILDSCHIRMRAND ----------------------------
                // Lange Strecke oder auf Navi 0 begonnen: alles zu.
                // Kurz und auf einem Untermenue begonnen: nur dieses.
                const float kShortPx = 120.0f;
                if (s.pressPanel > 0 && fabsf(dOpen) < kShortPx) {
                    s.panels[s.pressPanel].folded = true;
                    s.targetX = TargetW(s);
                } else {
                    s.savedFolded.clear();
                    for (auto& P : s.panels)
                        s.savedFolded.push_back(P.folded ? 1 : 0);
                    s.targetX = 0.0f;
                }
            } else {
                // ---- ZUR BILDSCHIRMMITTE ---------------------------
                // NIE HINTER DIE ERREICHTE POSITION ZURUECK.
                // [FastOpenAll stellt den GEMERKTEN Stand her. Wer die Navi
                //  bis zum Anschlag zieht und mit etwas Schwung loslaesst,
                //  landete damit bei einem alten, schmaleren Stand -- das
                //  Zurueckschnappen. Ist die Navi beim Loslassen schon so
                //  weit wie oder weiter als der gemerkte Stand, gilt die
                //  Position: naechste Grenze bei oder hinter openX.]
                {
                    float hier = s.openX;
                    std::vector<float> bb; TargetBoundaries(s, bb);
                    float ziel = -1.0f;
                    for (float x : bb) if (x >= hier - 8.0f) { ziel = x; break; }
                    if (ziel < 0.0f) ziel = TotalW(s);
                    FastOpenAll(s);
                    if (s.targetX < ziel - 1.0f) {
                        // Gemerkter Stand liegt hinter der erreichten
                        // Position: alles bis zum Ziel entfalten.
                        float lauf = 0.0f;
                        for (auto& P : s.panels) {
                            if (lauf < ziel - 1.0f) { P.folded = false; lauf += P.widthPx; }
                        }
                        s.targetX = TargetW(s);
                    }
                }
            }
        } else if (s.dragging) {
            // Kein Wisch, aber gezogen: langsame Auswertung wie gehabt.
            const float dWin = WindowedDelta(s, 0.12);
            // NUR EINE DEUTLICHE ENDBEWEGUNG ENTSCHEIDET DIE RICHTUNG.
            // [Vorher reichten 14 px in den letzten 120 ms. Wer die Navi
            //  200 px weit aufzieht, kurz innehaelt und beim Loslassen
            //  15 px zurueckdriftet, bekam sie ZUGEKLAPPT -- die kleine
            //  Drift ueberstimmte die ganze Geste. Das ist das gemeldete
            //  "komische Zurueckschnappen".
            //  Jetzt muss die Endbewegung mindestens ein Viertel der
            //  Gesamtstrecke ausmachen; sonst zaehlt die POSITION, also
            //  die naechstgelegene Grenze.]
            const float kEndMin = 14.0f;
            const float kEndAnteil = 0.25f * fabsf(dOpen);
            if (fabsf(dWin) < kEndMin || fabsf(dWin) < kEndAnteil) {
                // Stillstand oder nur Drift: naechstgelegene Grenze.
                float bestD = 1e9f;
                for (float x : b) {
                    float d = fabsf(x - s.openX);
                    if (d < bestD) { bestD = d; s.targetX = x; }
                }
            } else {
                // Eine Stufe in Zugrichtung; Faltung binaer nachziehen.
                for (auto& P : s.panels)
                    P.folded = (P.animW < P.widthPx * 0.5f);
                if (dWin > 0.0f) {
                    s.targetX = TotalW(s);
                    for (float x : b)
                        if (x > s.openX + 1.0f) { s.targetX = x; break; }
                } else {
                    s.targetX = 0.0f;
                    for (int i2 = (int)b.size() - 1; i2 >= 0; --i2)
                        if (b[i2] < s.openX - 1.0f)
                            { s.targetX = b[i2]; break; }
                }
            }
        }
        // Sonst: reiner Tipp -- folgenlos.

        // ---- PROTOKOLL DER GESTE (mit XBM_NAVILOG=1) -------------------
        // Gibt beim Loslassen die Groessen aus, aus denen die
        // Entscheidung faellt. Damit laesst sich am GERAET nachsehen,
        // welcher Zweig zuschlaegt -- was sich hier nicht nachstellen
        // laesst, weil die Kette den Druckpunkt waehrend des Zuges neu
        // setzt.
        {
            static int an = -1;
            if (an < 0) {
                const char* e = getenv("XBM_NAVILOG");
                an = (e && e[0] == '1') ? 1 : 0;
            }
            if (an) {
                char folds[16] = {0};
                int n = (int)s.panels.size(); if (n > 12) n = 12;
                for (int i2 = 0; i2 < n; ++i2)
                    folds[i2] = s.panels[i2].folded ? '.' : '#';
                printf("[navi] %s dOpen=%+.1f openX-dragX0=%+.1f held=%.3f "
                       "speed=%.0f vel=%.0f mode=%d fastDir=%+.0f "
                       "grab=%d pressPanel=%d dragging=%d wisch=%d -> "
                       "targetX=%.0f folds=%s\n",
                       s.right ? "R" : "L", (double)dOpen,
                       (double)(s.openX - s.dragX0), held, (double)speed,
                       (double)s.vel, s.mode, (double)s.fastDir,
                       s.grabBoundary, s.pressPanel, (int)s.dragging,
                       (int)wisch, (double)s.targetX, folds);
                fflush(stdout);
            }
        }

        // ZUSTAND NACH JEDER GESTE SICHERN.
        s.savedFolded.clear();
        for (auto& P : s.panels) s.savedFolded.push_back(P.folded ? 1 : 0);

        s.dragging = false; s.dragArmed = false; s.grabBoundary = -1;
        s.foldChain = s.foldPi0 = -1; s.grabFlush = false;
        s.vel = 0.0f;
    }
    // Gesamtbreite kann durch FALTUNG schrumpfen/wachsen: Ziel und
    // Oeffnung mitnehmen, damit die Kante buendig bleibt.
    bool frontFolgtFaltung = false;
    {
        const float totAnim = TotalW(s);                 // summiert animW
        const float totTgt  = s.dragging ? totAnim : TargetW(s);
        // Laeuft gerade eine Faltung? Dann klaffen animierte und
        // Zielbreite auseinander.
        const bool faltLaeuft = fabsf(totAnim - totTgt) > 0.5f;

        if (s.targetX > totTgt) s.targetX = totTgt;

        if (!s.dragging) {
            // Koppeln NUR, wenn das Ziel genau die Faltkonfiguration
            // ist. [Ohne diese Bedingung griff die Kopplung auch nach
            //  einem langsamen Zug: dort federn halb eingeschobene
            //  Panels auf ihre volle Breite zurueck, TotalW WAECHST
            //  dabei, und die Front ritt mit -- gemessen 615 -> 667,
            //  bevor sie auf 560 zurueckfiel. Also ein sichtbarer
            //  Ausschlag nach aussen. Beim echten Einfalten ist
            //  targetX == TargetW, dort gehoert die Kopplung hin.]
            const bool zielIstFaltung = fabsf(s.targetX - totTgt) < 0.5f;
            if (faltLaeuft && zielIstFaltung && s.targetX > 0.5f) {
                // ---- FRONT KLEBT AN DEN PANELS ----------------------
                // [Hier lag der Fehler. Die Klemmung setzte openX SOFORT
                //  auf die Zielbreite, waehrend die Panelbreiten noch
                //  herunteranimierten: gemessen 560 gegen 683, also
                //  120 px Versatz. Die Front lief der Faltung davon, und
                //  weil jedes Panel bei openX abgeschnitten wird, wurde
                //  das aeusserste um genau diesen Betrag beschnitten --
                //  es wirkte gestaucht und die Nachbarn schienen nicht
                //  aneinanderzukleben. Genau das gemeldete "unstatisch
                //  und unstabil".
                //
                //  Waehrend einer Faltung gibt es nur EINE Bewegung: die
                //  der Panelbreiten. Die Front wird daraus abgeleitet,
                //  nicht daneben animiert.]
                s.openX = totAnim;
                frontFolgtFaltung = true;
            } else if (s.openX > totAnim) {
                s.openX = totAnim;
            }
        }
        // Voll geoeffnet gehaltene Navi folgt einer ENTfaltung nach.
        if (!s.dragging && s.targetX >= totTgt - 0.5f
            && s.openX >= s.targetX - 0.5f) s.targetX = totTgt;
    }
    // RUHELAGE IMMER AUF EINER GRENZE: Ohne Finger darf die Front nie
    // MITTEN in einem Panel stehen -- dessen Fenster wuerde sonst
    // beschnitten unter dem Vorgaenger kleben ("Subnavis schieben
    // ineinander"). Ein ausgefahrenes Subnavi hat IMMER seine volle
    // Standardbreite, ein eingefahrenes ist unsichtbar. Sicherheits-
    // halber wird auch das Ziel selbst auf die naechste Grenze
    // gerundet, sobald keine Geste laeuft.
    if (!s.dragging && !frontFolgtFaltung) {
        // ZIEL-Grenzen, nicht die animierenden.
        // [Hier stand Boundaries(s, bs). Waehrend eine Faltung laeuft,
        //  verschieben sich diese Grenzen jeden Frame; ein Ziel, das
        //  gerade nicht exakt auf einer lag, wurde deshalb Frame fuer
        //  Frame auf die naechste gerundet und wanderte dabei nach
        //  unten. Ein auf 560 gesetztes Ziel landete so bei 410 -- das
        //  Untermenue fuhr ein, aber die Navigation schrumpfte um ein
        //  Panel zu viel.]
        std::vector<float> bs; TargetBoundaries(s, bs);
        bool onB = false;
        for (float x : bs) if (fabsf(s.targetX - x) < 0.5f) onB = true;
        if (!onB && !bs.empty()) {
            float best = bs[0], bd = 1e9f;
            for (float x : bs) {
                float d = fabsf(x - s.targetX);
                if (d < bd) { bd = d; best = x; }
            }
            s.targetX = best;
        }
    }
    // FLUG zum Ziel (nach dem Loslassen "fliegt sie rein oder raus").
    // Der Flug entfaellt, solange die Front bereits der Faltung folgt --
    // sonst zoegen zwei Bewegungen gleichzeitig an openX.
    if (!s.dragging && !frontFolgtFaltung
        && fabsf(s.targetX - s.openX) > 0.25f) {
        float dt = io.DeltaTime > 0.0f ? io.DeltaTime : 0.016f;
        const bool warUnterwegs = fabsf(s.targetX - s.openX) > 0.25f;
        s.openX += (s.targetX - s.openX) * (1.0f - expf(-14.0f * dt));
        if (fabsf(s.targetX - s.openX) <= 0.25f) {
            s.openX = s.targetX;
            // ZUR RUHE GEKOMMEN -> Stand sichern.
            // [Die Sicherung beim Loslassen deckt nur Gesten ab. Wird die
            //  Navigation ueber einen Knopf, einen Seitenwechsel oder
            //  RequestClose/RequestOpen bewegt, gibt es kein Loslassen --
            //  der Stand ging verloren und das naechste Aufwischen
            //  brachte etwas anderes. Jetzt zaehlt jedes ENDE einer
            //  Bewegung.
            //
            //  NUR im geoeffneten Zustand sichern: beim Zufahren laeuft
            //  openX auf 0, und ein dort gesicherter Stand wuerde die
            //  Erinnerung an das, was offen war, ueberschreiben.]
            if (warUnterwegs && s.openX > 4.0f
                && !s.dragging && !s.dragArmed) {
                s.savedFolded.clear();
                for (auto& P : s.panels)
                    s.savedFolded.push_back(P.folded ? 1 : 0);
            }
        }
    }
    (void)edgeX;
}

// Kleine gezeichnete Tastatur -- Gegenstueck zum Zahnrad, gleicher Stil
// und dieselbe Strichstaerke, damit beide in der Tab-Leiste als Paar
// wirken. <an> steuert nur die Fuellung: eingeschaltet wirkt sie
// ausgemalt, ausgeschaltet nur umrissen -- so ist der Zustand auch ohne
// Farbe erkennbar (wichtig auf dem kleinen Handy-Bildschirm).
inline void DrawKeyboardGlyph(ImVec2 mn, ImVec2 mx, bool an) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 c((mn.x + mx.x) * 0.5f, (mn.y + mx.y) * 0.5f);
    const float h = (mx.y - mn.y);
    const float bw = h * 0.62f;          // Gehaeusebreite
    const float bh = h * 0.42f;          // Gehaeusehoehe
    ImU32 col = ImGui::GetColorU32(ImGuiCol_Text);
    ImVec2 a(c.x - bw * 0.5f, c.y - bh * 0.5f);
    ImVec2 b(c.x + bw * 0.5f, c.y + bh * 0.5f);
    dl->AddRect(a, b, col, h * 0.06f, 0, 1.5f);

    // Tastenraster: zwei Reihen zu je vier Punkten, darunter die
    // Leertaste als kurzer Strich.
    const float padx = bw * 0.16f, pady = bh * 0.24f;
    const float usableW = bw - padx * 2.0f;
    const float rs = h * (an ? 0.050f : 0.038f);   // Tastenradius
    for (int reihe = 0; reihe < 2; ++reihe) {
        float y = a.y + pady + (bh - pady * 2.0f) * (reihe == 0 ? 0.18f : 0.50f);
        for (int k = 0; k < 4; ++k) {
            float x = a.x + padx + usableW * ((float)k + 0.5f) / 4.0f;
            if (an) dl->AddCircleFilled(ImVec2(x, y), rs, col, 6);
            else    dl->AddCircle(ImVec2(x, y), rs, col, 6, 1.0f);
        }
    }
    // Leertaste
    float sy = a.y + bh * 0.78f;
    dl->AddLine(ImVec2(a.x + padx + usableW * 0.22f, sy),
                ImVec2(a.x + padx + usableW * 0.78f, sy), col, an ? 2.0f : 1.2f);

    // AUSGESCHALTET: Schraegstrich darueber. [Ein blosses Ausgrauen
    //  waere bei hellem Design und Sonnenlicht kaum zu unterscheiden --
    //  der Strich ist auf einen Blick eindeutig.]
    if (!an) {
        dl->AddLine(ImVec2(a.x - bw * 0.08f, b.y + bh * 0.10f),
                    ImVec2(b.x + bw * 0.08f, a.y - bh * 0.10f),
                    col, 1.8f);
    }
}

// Kleines gezeichnetes Zahnrad ueber dem zuletzt abgelegten Item.
inline void DrawGearGlyph(ImVec2 mn, ImVec2 mx) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 c((mn.x + mx.x) * 0.5f, (mn.y + mx.y) * 0.5f);
    float r = (mx.y - mn.y) * 0.30f;
    ImU32 col = ImGui::GetColorU32(ImGuiCol_Text);
    dl->AddCircle(c, r * 0.62f, col, 12, 1.5f);
    dl->AddCircleFilled(c, r * 0.20f, col);
    for (int t = 0; t < 6; ++t) {
        float an = (float)t * 1.0471975512f;
        dl->AddLine(ImVec2(c.x + cosf(an) * r * 0.62f,
                           c.y + sinf(an) * r * 0.62f),
                    ImVec2(c.x + cosf(an) * r, c.y + sinf(an) * r),
                    col, 1.8f);
    }
}

// Panels eines Randes zeichnen. activePage filtert Tab-spezifische Items.
inline void DrawPanels(EdgeState& s, float workL, float workR,
                       float topY, float botY,
                       const std::string& activePage) {
    // Flaeche merken, solange die Navi offen ist (fuer das Ablegen von
    // Fenstern -- siehe RightRectLastFrame).
    if (s.right) {
        if (s.openX > 0.5f)
            RightRectLastFrame() = ImRect(ImVec2(workR - s.openX, topY),
                                          ImVec2(workR, botY));
        else
            RightRectLastFrame() = ImRect(0, 0, 0, 0);
    }
    if (s.openX <= 0.5f) return;
    // REIHENFOLGE: Panel 0 sitzt an der BILDSCHIRMKANTE (links: ganz
    // links / rechts: ganz rechts), jedes weitere faehrt DANEBEN in
    // Richtung Bildschirmmitte aus -- und zwar NACHEINANDER: Panel i
    // schiebt sich unter Panel i-1 hervor, bis es an seiner Endlage
    // (prefix_i) anliegt. [Die erste Fassung hing alle Panels an der
    // WANDERNDEN Kante -- Navi 0 war damit ganz aussen an der
    // Zieh-Front statt an der Bildschirmkante.]
    float prefix = 0.0f;
    int lastVisible = -1;
    for (int i = 0; i < (int)s.panels.size(); ++i) {
        Panel& p = s.panels[i];
        float ew = EffW(p);
        if (ew <= 0.5f) continue;              // gefaltet: nimmt nichts
        float visFrom = prefix, visTo = prefix + ew;
        if (visFrom >= s.openX) break;
        lastVisible = i;
        float reveal = s.openX < visTo ? s.openX : visTo;
        // ---- SCHIEBEN, NICHT SCHRUMPFEN --------------------------------
        // Gezeichnet wird IMMER die volle Panelbreite; nur die POSITION
        // wandert. Sichtbar bleibt der Streifen der Breite ew, der Rest
        // gleitet unter das davorliegende Panel (das ist undurchsichtig
        // und liegt in der Stapelordnung davor -- Panel 0 obenauf, dann
        // 1, 2, ...).
        //
        // [Vorher bekam das Fenster die ANIMIERTE Breite ew. ImGui hat
        //  den Inhalt dann bei jedem Frame neu umbrochen: Text rutschte,
        //  Knoepfe wurden gestaucht, der Rand zog sich zusammen. Genau
        //  das gemeldete "es verkleinert sich den Rand und sieht nicht
        //  schoen aus". Mit fester Breite bleibt das Layout stehen und
        //  Inhalt UND Text fahren mit hinein und heraus.]
        const float drawW = p.widthPx > 1.0f ? p.widthPx : 1.0f;
        float x = s.right ? (workR - reveal)                  // linke Kante
                          : (workL + reveal - drawW);         // rechte Kante
        (void)visFrom;
        char wn[64];
        ImFormatString(wn, sizeof(wn), "##navi_%c_%d",
                       s.right ? 'R' : 'L', i);
        if (ew < 2.0f) { prefix += ew; continue; }   // Splitter-Rest
        ImGui::SetNextWindowPos(ImVec2(x, topY));
        ImGui::SetNextWindowSize(ImVec2(drawW, botY - topY));
        // DER BUG: ImGui erzwingt style.WindowMinSize (32-44px je nach
        // Touch-Skalierung) NACH den SizeConstraints -- Panels konnten
        // deshalb nie schmaler als diese Mindestbreite RENDERN, obwohl
        // animW laengst kleiner war: Beim Falten blieb eine "dumme
        // Mindestbreite" stehen (etwa Settings-Knopf-Breite), die
        // Nachbarn wurden per prefix trotzdem enger gesetzt (ineinander
        // geschoben), und beim Unterschreiten der Zeichen-Schwelle
        // verschwand der Rest schlagartig. Fix: Mindestgroesse fuer die
        // Panel-Begins auf 1x1 senken und danach wiederherstellen --
        // damit rendert das Fenster EXAKT animW breit und die Faltung
        // gleitet ueberall fluessig bis auf null.
        ImGuiStyle& nst = ImGui::GetStyle();
        ImVec2 savedMin = nst.WindowMinSize;
        nst.WindowMinSize = ImVec2(1.0f, 1.0f);
        ImGui::PushStyleColor(ImGuiCol_WindowBg, p.bg);
        ImGui::Begin(wn, nullptr,
            ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove
            | ImGuiWindowFlags_NoSavedSettings
            | ImGuiWindowFlags_NoScrollbar        // Wunsch: kein Balken
            | ImGuiWindowFlags_NoDocking);
        // Kopf: nur der Name.
        // [Das Navi-Zahnrad stand hier rechts neben der Ueberschrift und
        //  wurde von ihr ueberdeckt, sobald die Navi schmal war. Es sitzt
        //  jetzt unten neben dem App-Einstellungen-Knopf -- da ist Platz,
        //  und beide Einstellungen stehen an EINER Stelle.]
        ImGui::TextUnformatted(p.name.c_str());
        ImGui::Separator();
        if (!p.abschnitte.empty()) {
            // GLEICH HOHE ABSCHNITTE: verfuegbare Hoehe durch die Anzahl.
            const float reserve = (i == 0 && !s.right) ? ImGui::GetFrameHeightWithSpacing() + 8.0f : 0.0f;
            const float gesamt = ImGui::GetContentRegionAvail().y - reserve;
            const float je = gesamt / (float)p.abschnitte.size();
            int k = 0;
            for (auto& ab : p.abschnitte) {
                ImGui::PushID(k++);
                ImGui::TextDisabled("%s", ab.first.c_str());
                const float inhaltH = je - ImGui::GetTextLineHeightWithSpacing() - ImGui::GetStyle().ItemSpacing.y;
                ImGui::BeginChild("##abschnitt", ImVec2(0, ImMax(inhaltH, ImGui::GetTextLineHeight() * 2.0f)), true);
                AbschnittRects()[ab.first] = { ImGui::GetWindowPos(), ImVec2(ImGui::GetWindowPos().x + ImGui::GetWindowSize().x, ImGui::GetWindowPos().y + ImGui::GetWindowSize().y) };
                if (ab.second) ab.second();
                ImGui::EndChild();
                ImGui::PopID();
            }
        } else if (p.content) p.content();
        // Items (global oder fuer die aktive Seite registriert).
        for (auto& it : p.items) {
            if (!it.page.empty() && it.page != activePage) continue;
            if (ImGui::Selectable(it.label.c_str()) && it.fn) it.fn();
        }
        // DockSpace: Fenster in DIESE Navi andocken. Der untere Rest
        // gehoert dem Dock (Navi 0 reserviert eine Zeile fuer den
        // App-Einstellungen-Knopf).
        float reserve = (i == 0 && !s.right)
                      ? ImGui::GetFrameHeightWithSpacing() + 8.0f : 0.0f;
        float dsH = ImGui::GetContentRegionAvail().y - reserve;
        if (dsH > 40.0f) {
            char dsn[64];
            ImFormatString(dsn, sizeof(dsn), "navi_ds_%c_%d",
                           s.right ? 'R' : 'L', i);
            p.dockId = ImGui::GetID(dsn);
            // KEIN Passthru: der leere Dock-Bereich muss Eingaben
            // SCHLUCKEN -- mit Passthru fielen Grenz-Griffe und Tipps
            // auf die Fenster UNTER der Navi durch.
            ImGui::DockSpace(p.dockId, ImVec2(0, dsH),
                             ImGuiDockNodeFlags_None);
            for (const auto& q : p.dockQueue)
                ImGui::DockBuilderDockWindow(q.c_str(), p.dockId);
            p.dockQueue.clear();
        }
        if (i == 0 && !s.right) {
            ImGui::Separator();
            ImVec2 bmin = ImGui::GetCursorScreenPos();
            float bh = ImGui::GetFrameHeight();
            AppBtnTop() = bmin.y;               // Anker fuer das Sheet
            // ZWEI KNOEPFE NEBENEINANDER, JEDER MIT SYMBOL UND KURZTEXT.
            // [Vorher: ein vollbreiter Knopf "App-Einstellungen" -- zu lang
            //  fuer eine schmale Navi -- und das Navi-Zahnrad oben im Kopf,
            //  wo die Ueberschrift es verdeckte. Jetzt links "App", rechts
            //  "Navi", beide mit Zahnrad; der Tooltip nennt es ganz.]
            float avail = ImGui::GetContentRegionAvail().x;
            // TASTATUR-UMSCHALTER -- QUADRATISCH, LINKS VOR "App".
            // [Wirkt zugleich als Checkbox: blau hinterlegt, wenn
            //  "Android-Tastatur verwenden" an ist, sonst normal. Ein
            //  Klick schaltet um.]
            {
                bool an = UiAndroidTastaturVerwenden();
                if (an) ImGui::PushStyleColor(ImGuiCol_Button,
                    ImGui::GetStyleColorVec4(ImGuiCol_ButtonActive));
                if (ImGui::Button("Tast.##tastaturein", ImVec2(bh * 1.4f, bh)))
                    UiAndroidTastaturVerwenden() = !an;
                if (an) ImGui::PopStyleColor();
                if (ImGui::IsItemHovered())
                    ImGui::SetTooltip(an ? "Android-Tastatur verwenden (an)"
                                         : "Android-Tastatur verwenden (aus)");
                ImGui::SameLine();
            }
            avail = ImGui::GetContentRegionAvail().x;
            float halb  = (avail - ImGui::GetStyle().ItemSpacing.x) * 0.5f;
            if (halb < bh) halb = bh;
            // -- App-Einstellungen --
            if (ImGui::Button("    App##appset", ImVec2(halb, 0.0f))) {
                if (AppSettingsOpen() && AppSheetAbschnitt() == 0)
                    AppSettingsOpen() = false;
                else {
                    AppSettingsOpen() = true; AppSheetAbschnitt() = 0;
                    // NACH VORN. [Ohne ZTouch behielt das Blatt seinen
                    //  alten Zeitstempel und lag hinter einer spaeter
                    //  angefassten Navi -- "nicht immer im Vordergrund".]
                    ZTouch(ZElem::Settings);
                }
            }
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("App-Einstellungen");
            DrawGearGlyph(bmin, ImVec2(bmin.x + bh, bmin.y + bh));
            // -- Navi-Einstellungen --
            ImGui::SameLine();
            ImVec2 nmin = ImGui::GetCursorScreenPos();
            if (ImGui::Button("    Navi##navset", ImVec2(-1.0f, 0.0f))) {
                // Dasselbe Blatt, anderer Abschnitt. Zweiter Klick schliesst.
                if (AppSettingsOpen() && AppSheetAbschnitt() == 1)
                    AppSettingsOpen() = false;
                else {
                    AppSettingsOpen() = true; AppSheetAbschnitt() = 1;
                    ZTouch(ZElem::Settings);
                }
            }
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Navigations-Einstellungen");
            DrawGearGlyph(nmin, ImVec2(nmin.x + bh, nmin.y + bh));
        }
        {   // BODEN-FAENGER als LETZTES Item ueber die ganze Flaeche.
            // ER MUSS ZULETZT KOMMEN: Als ERSTES Item schnappte er sich
            // im Klick-Frame die ActiveId, bevor Buttons/Checkboxen
            // ueberhaupt submittet waren -- die liessen sich dadurch NIE
            // betaetigen. Zuletzt submittet ist er automatisch inaktiv,
            // sobald ein echtes Widget den Klick beansprucht, faengt
            // aber weiterhin JEDEN Tipp auf freien Grund ab (sonst
            // fielen die auf die Fenster unter der Navi durch).
            ImVec2 keep = ImGui::GetCursorPos();
            ImGui::SetCursorPos(ImVec2(0, 0));
            ImGui::InvisibleButton("##navi_ground",
                ImVec2(drawW, (botY - topY) > 1 ? (botY - topY) : 1));
            GroundIds().push_back(ImGui::GetItemID());
            ImGui::SetCursorPos(keep);
            // PFLICHT-ITEM NACH DEM CURSOR-SPRUNG.
            // [Ohne das meldet ImGui beim End():
            //    "In window '##navi_L_0': Code uses SetCursorPos()/
            //     SetCursorScreenPos() to extend window/parent boundaries.
            //     Please submit an item e.g. Dummy() afterwards to
            //     validate extents."
            //  Diese Meldung erscheint als grosses ROTES Fenster mitten
            //  auf dem Schirm, verdeckt die Oberflaeche und faengt
            //  Eingaben ab -- genau das, was auf den Handy-Bildern zu
            //  sehen war. Ursache: SetCursorPos allein verschiebt nur den
            //  Schreibkopf; ImGui erfaehrt erst durch ein FOLGENDES Item,
            //  wie gross der Inhalt wirklich ist. Ein Dummy der Groesse
            //  null genuegt und kostet nichts.]
            ImGui::Dummy(ImVec2(0.0f, 0.0f));
        }
        ZCollect(s.right ? ZElem::RightNavi : ZElem::LeftNavi,
                 ImGui::GetCurrentWindow());
        ImGui::End();
        nst.WindowMinSize = savedMin;          // Mindestgroesse zurueck
        ImGui::PopStyleColor();
        prefix += ew;
    }
    // Panel 0 obenauf, dann 1, 2, ...: in UMGEKEHRTER Reihenfolge nach
    // vorn holen (der letzte Front-Ruf gewinnt).
    for (int i = lastVisible; i >= 0; --i) {
        char wn[64];
        ImFormatString(wn, sizeof(wn), "##navi_%c_%d",
                       s.right ? 'R' : 'L', i);
        if (ImGuiWindow* pw = ImGui::FindWindowByName(wn))
            ZCollect(s.right ? ZElem::RightNavi : ZElem::LeftNavi, pw);
    }
    // APP-EINSTELLUNGEN als vollbreites Sheet: Unterkante klebt an der
    // OBERKANTE des App-Einstellungen-Knopfs, Hoehe = Inhalt; reicht
    // der Platz bis zur Bildschirm-Oberkante nicht, wird intern
    // gescrollt (Pinpoint funktioniert dort wie ueberall). Es liegt
    // OBEN AUF (Display-Front), die Navi darunter ist gesperrt
    // (UpdateDrag kehrt um) und ein Klick daneben schliesst.
    if (AppSettingsOpen() && !s.right) {
        static float wantH = 240.0f;            // Inhaltshoehe (gemessen)
        float anchor = AppBtnTop() > topY ? AppBtnTop() : botY;
        float availH = anchor - topY;
        float h = wantH < availH ? wantH : availH;
        if (h < 60.0f) h = 60.0f;
        // BREITE: entweder volle Arbeitsflaeche (wie bisher) oder
        // buendig mit dem DockSpace, also um die gerade offenen Navis
        // eingerueckt.
        float sheetL = workL, sheetR = workR;
        if (AppSheetAlignDock()) {
            sheetL += Left().openX;
            sheetR -= Right().openX;
            if (sheetR - sheetL < 120.0f) {   // Notbremse bei schmalem Rest
                sheetL = workL; sheetR = workR;
            }
        }
        ImGui::SetNextWindowPos(ImVec2(sheetL, anchor - h));
        ImGui::SetNextWindowSize(ImVec2(sheetR - sheetL, h));
        ImGui::Begin("###xbm_appsheet", nullptr,
            ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove
            | ImGuiWindowFlags_NoSavedSettings
            | ImGuiWindowFlags_NoDocking);
        // Kopf mit zwei Reitern: App | Navigation.
        {
            int ab = AppSheetAbschnitt();
            if (ImGui::RadioButton("App-Einstellungen", ab == 0)) ab = 0;
            ImGui::SameLine();
            if (ImGui::RadioButton("Navigation", ab == 1)) ab = 1;
            AppSheetAbschnitt() = ab;
        }
        ImGui::Separator();
        if (AppSheetAbschnitt() == 1) {
            // ---- NAVIGATIONS-EINSTELLUNGEN (frueher das Popup) ----
            const char* vars[] = { "Variante 1 (Begrenzer)" };
            int vi = 0;
            ImGui::SetNextItemWidth(220.0f);
            if (ImGui::Combo("Schiebe-Variante", &vi, vars, 1))
                s.variant = 1;   // weitere Varianten: hier anbauen
        }
        // Beruehrung zaehlt fuer die Z-Ordnung -- in beiden Abschnitten.
        if (ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows)
            && ImGui::IsMouseClicked(ImGuiMouseButton_Left))
            ZTouch(ZElem::Settings);
        // Inhalt: die fruehere "Effekt-Einstellungen"-Seite (das
        // eigene Fenster ist abgeschafft; Einbindung via Hook, damit
        // ui_navi.h frei von effects_gl-Abhaengigkeit bleibt).
        if (AppSheetAbschnitt() == 0 && AppSettingsContent())
            AppSettingsContent()();
        // Inhaltshoehe fuer den naechsten Frame messen.
        wantH = ImGui::GetCursorPosY()
              + ImGui::GetStyle().WindowPadding.y;
        ImVec2 smin = ImGui::GetWindowPos();
        ImVec2 smax(smin.x + ImGui::GetWindowSize().x,
                    smin.y + ImGui::GetWindowSize().y);
        AppSheetRect() = ImRect(smin, smax);
        ZCollect(ZElem::Settings, ImGui::GetCurrentWindow());
        ImGui::End();
        if (ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
            ImVec2 mp = ImGui::GetIO().MousePos;
            bool inside = mp.x >= smin.x && mp.x <= smax.x
                       && mp.y >= smin.y && mp.y <= smax.y;
            // DEN KNOPF SELBST AUSNEHMEN.
            // [Ein Klick auf "App-Einstellungen" liegt ebenfalls
            //  "daneben": hier wurde geschlossen, gleich danach schaltete
            //  der Knopf wieder um -- netto blieb das Sheet offen, und ein
            //  zweiter Klick auf den Knopf konnte es nie schliessen.
            //  Der Knopf sitzt direkt UNTER dem Sheet (Oberkante
            //  AppBtnTop, eine Zeile hoch); der Klick dort gehoert ihm.]
            float bh = ImGui::GetFrameHeight();
            bool aufKnopf = mp.y >= AppBtnTop() && mp.y <= AppBtnTop() + bh
                         && mp.x >= smin.x && mp.x <= smax.x;
            if (!inside && !aufKnopf) AppSettingsOpen() = false;
        }
    } else if (!s.right) {
        AppSheetRect() = ImRect(0, 0, 0, 0);
    }
}

// Huebsche gezeichnete Icon-Buttons fuer die rechte Leiste (ohne
// Funktion) + kleines "Shader"-Display (prozedurales Plasma per
// DrawList -- als Scroll-Futter und Blickfang; echtes GL/VK haengt an
// der Effekt-Naht und kommt mit der Renderer-Migration).
// ---- RECHTE LEISTE (Navi 0 rechts) --------------------------------
// Frueher standen hier sechs Platzhalter-Symbole ohne Funktion
// (Kreis, Quadrat, Dreieck, Linien, Kreuz, Punkte). Sie sind ersatzlos
// entfallen; die Leiste zeigt jetzt ausschliesslich BEDINGTE Knoepfe,
// die sich selbst angemeldet haben (ui_condbuttons.h). Damit muss die
// Leiste nichts mehr ueber die Knoepfe wissen und umgekehrt.
// ---------------------------------------------------------------------------
// FENSTERPALETTE (navi1): die Fenster der AKTIVEN Seite, die gerade
// GESCHLOSSEN sind -- zum Zurueckholen per Ziehen oder Klick.
//
// [Ein geschlossenes Fenster war bisher weg; es gab keinen Weg zurueck.
//  Die Liste liefert der Aufrufer ueber einen Haken: ui_navi.h kennt die
//  Seitenverwaltung nicht und soll sie auch nicht kennen.]
// ---------------------------------------------------------------------------
struct WinPaletteEintrag { std::string name; };
inline std::function<std::vector<WinPaletteEintrag>()>& WinPaletteQuelle() {
    static std::function<std::vector<WinPaletteEintrag>()> f; return f;
}
inline std::function<void(const std::string&)>& WinPaletteOeffnen() {
    static std::function<void(const std::string&)> f; return f;
}
inline std::function<void(const std::string&, ImVec2, ImVec2, ImU32)>& WinPaletteGlyph() {
    static std::function<void(const std::string&, ImVec2, ImVec2, ImU32)> f; return f;
}

// EIGENER ZUG STATT ImGui-DragDrop.
// [Dreimal hat das Herausziehen mit BeginDragDropSource nicht
//  funktioniert -- zu viele Beteiligte: die Navi-Geste greift nach
//  waagerechten Wischern, das Ziel am DockSpace ist kein Item, und auf
//  Touch beginnt ImGui den Zug oft nicht. Also fuehre ich ihn selbst:
//  ein Name, ein Merker "wird gezogen", und ui_pages fragt beim
//  Loslassen ab, ob die Maus ueber dem DockSpace war. Das hat drei
//  Zeilen Zustand und keine Abhaengigkeit von ImGuis Item-Kette.]
struct WinZug { std::string name; bool aktiv = false; };
inline WinZug& WinPaletteZug() { static WinZug z; return z; }
// Inhalt des Abschnitts "Vorlagen" in Navi 1 (rechts) -- kommt vom Kalender.
inline std::function<void()>& VorlagenInhalt() { static std::function<void()> f; return f; }
inline std::function<void()>& PapierkorbInhalt() { static std::function<void()> f; return f; }
// Bildschirm-Rechtecke der Abschnitte (Name -> (min, max)) -- Drop-Ziele.


inline void WinPaletteContent() {
    if (!WinPaletteQuelle()) { ImGui::TextDisabled("(keine Quelle)"); return; }
    auto liste = WinPaletteQuelle()();
    if (liste.empty()) { ImGui::TextDisabled("alle Fenster offen"); return; }
    float kante = ImGui::GetFrameHeight() * 1.6f;
    for (auto& e : liste) {
        ImGui::PushID(e.name.c_str());
        ImVec2 bmin = ImGui::GetCursorScreenPos();
        // GANZE ZEILE ist die Flaeche -- Symbol UND Name treffen.
        float breite = ImGui::GetContentRegionAvail().x;
        if (breite < kante) breite = kante;
        ImGui::InvisibleButton("##pal", ImVec2(breite, kante));
        bool ueber = ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem);

        // ZUG SELBST FUEHREN: Druck auf dem Eintrag merkt den Namen.
        WinZug& zug = WinPaletteZug();
        ImGuiIO& pio = ImGui::GetIO();
        if (ueber && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
            zug.name = e.name; zug.aktiv = true;
        }
        bool zieht = zug.aktiv && zug.name == e.name
                  && (fabsf(pio.MousePos.x - bmin.x) > 8.0f
                      || fabsf(pio.MousePos.y - bmin.y) > 8.0f);

        // Loslassen AUF dem Eintrag = oeffnen (Antippen).
        // [ui_pages behandelt das Loslassen ueber dem DockSpace; hier nur
        //  der Fall "Finger ist nicht weggewandert".]
        bool oeffnen = false;
        if (ueber && zug.aktiv && zug.name == e.name
            && ImGui::IsMouseReleased(ImGuiMouseButton_Left))
            oeffnen = true;

        // Flaeche und Symbol selbst zeichnen.
        ImU32 bg = ueber ? ImGui::GetColorU32(ImGuiCol_ButtonHovered) : 0;
        if (bg)
            ImGui::GetWindowDrawList()->AddRectFilled(
                bmin, ImVec2(bmin.x + breite, bmin.y + kante), bg, 3.0f);
        if (WinPaletteGlyph())
            WinPaletteGlyph()(e.name, bmin, ImVec2(bmin.x + kante, bmin.y + kante),
                              ImGui::GetColorU32(ImGuiCol_Text));
        // Name neben das Symbol, in die gezeichnete Flaeche.
        ImGui::GetWindowDrawList()->AddText(
            ImVec2(bmin.x + kante + 4.0f,
                   bmin.y + (kante - ImGui::GetTextLineHeight()) * 0.5f),
            ImGui::GetColorU32(ImGuiCol_Text), e.name.c_str());
        if (ueber && !ImGui::IsDragDropActive())
            ImGui::SetTooltip("%s -- ziehen oder antippen", e.name.c_str());

        if (zieht) {
            // Geisterbild am Finger, damit man sieht, dass etwas haengt.
            ImDrawList* fdl = ImGui::GetForegroundDrawList();
            ImVec2 mp2 = pio.MousePos;
            ImVec2 ts2 = ImGui::CalcTextSize(e.name.c_str());
            fdl->AddRectFilled(ImVec2(mp2.x + 12, mp2.y - 8),
                               ImVec2(mp2.x + 20 + ts2.x, mp2.y + 12 + ts2.y),
                               IM_COL32(30, 30, 34, 230), 4.0f);
            fdl->AddText(ImVec2(mp2.x + 16, mp2.y - 4),
                         IM_COL32(240, 240, 240, 255), e.name.c_str());
        }
        if (oeffnen && WinPaletteOeffnen()) WinPaletteOeffnen()(e.name);
        ImGui::PopID();
    }
}

inline void RightRailContent() {
    // KNOPFGROESSE AN DIE SCHRIFT KOPPELN.
    // [Hier stand eine feste Obergrenze von 72 Pixeln. Auf einem Handy mit
    //  hoher Punktdichte ist die Schrift zwei- bis dreimal so gross wie am
    //  Schreibtisch -- 72 px sind dort ein Briefmarkenformat, das man mit
    //  dem Finger kaum trifft. Die Zeilenhoehe skaliert bereits mit der
    //  Punktdichte, also richtet sich die Kante daran aus. Untergrenze
    //  44 px: das ist die uebliche Mindestgroesse fuer Beruehrziele.]
    const float availW = ImGui::GetContentRegionAvail().x;
    float bw = ImGui::GetFrameHeight() * 1.8f;
    if (bw < 44.0f) bw = 44.0f;
    if (bw > availW) bw = availW;
    if (bw < 8.0f) return;
    const float indent = (availW - bw) * 0.5f;
    const ImVec2 start(ImGui::GetCursorScreenPos().x + indent + bw,
                       ImGui::GetCursorScreenPos().y);
    const float used = UiCondButtons_DrawColumn(start, bw);
    // Hoehe belegen, damit der Inhalt der Navi stimmt (sonst dieselbe
    // Falle wie beim Boden-Faenger weiter oben).
    ImGui::Dummy(ImVec2(availW, used > 0.0f ? used : 1.0f));
}

// EINMALIGE Grundausstattung: Navi 0 + drei Beispiel-Zusatznavis links,
// eine schmale Button-Leiste rechts. Weitere Panels jederzeit per
// Left().panels.push_back(...).
inline void EnsureDefaults(float workW) {
    EdgeState& L = Left();
    if (L.panels.empty()) {
        Panel p0; p0.name = "Navigation";
        // FESTE Breite. [Vorher workW * 0.60f: auf dem Desktop nahm die
        // Navi damit den halben Bildschirm ein -- und wurde workW im
        // allerersten Frame mit 0 gemessen, blieb sie UNSICHTBAR
        // ("Navi 0 erscheint manchmal nicht"): EnsureDefaults laeuft nur
        // einmal, die 0 war damit eingebrannt.]
        (void)workW;
        p0.widthPx = 260.0f;
        p0.bg = IM_COL32(45, 45, 50, 248);
        L.panels.push_back(p0);
        const char* nm[3] = { "Navi 1", "Navi 2", "Navi 3" };
        for (int i = 0; i < 3; ++i) {
            Panel px; px.name = nm[i];
            px.widthPx = 150.0f;               // ALLE gleich breit
            px.bg = IM_COL32(26 - i * 4, 26 - i * 4, 30 - i * 4, 250);
            for (int k = 0; k < 5; ++k)
                px.items.push_back({ std::string("Aktion ")
                                     + std::to_string(i) + "."
                                     + std::to_string(k), "", nullptr });
            L.panels.push_back(px);
        }
    }
    EdgeState& R = Right();
    if (R.panels.empty()) {
        Panel pr; pr.name = "";
        pr.widthPx = 96.0f;                 // breiter: Icons quadratisch
        pr.bg = IM_COL32(22, 22, 26, 250);
        pr.content = &RightRailContent;
        R.panels.push_back(pr);
        Panel p1; p1.name = "Navi 1";      // rechts: Fenster-Palette und Vorlagen, gleich hoch
        p1.widthPx = 230.0f;
        p1.bg = IM_COL32(30, 30, 34, 250);
        // ABSCHNITTE 1:1: oben die Fenster der aktiven Seite, die gerade
        // geschlossen sind; darunter die Vorlagen des Kalenders.
        p1.abschnitte.push_back({ "Fenster", &WinPaletteContent });
        p1.abschnitte.push_back({ "Vorlagen", []{ if (VorlagenInhalt()) VorlagenInhalt()(); else ImGui::TextDisabled("(keine Quelle)"); } });
        p1.abschnitte.push_back({ "Papierkorb", []{ if (PapierkorbInhalt()) PapierkorbInhalt()(); else ImGui::TextDisabled("(keine Quelle)"); } });
        R.panels.push_back(p1);
    }
}

// ---- PERSISTENZ (xbm.ini, Record "V") ------------------------------
// Eine Zeile pro Kante: offene Breite als 0/1 (zu/offen), dann je Panel
// folded-Bit, dann die Merkliste der Schnellgeste. Bewusst simpel --
// Panelanzahl aendert sich zwischen Laeufen nicht.
inline std::string SerializeEdge(EdgeState& es) {
    std::string out = es.openX > 4.0f ? "1" : "0";
    out += "\t";
    for (auto& P : es.panels) out += P.folded ? '1' : '0';
    out += "\t";
    for (unsigned char b : es.savedFolded) out += b ? '1' : '0';
    return out;
}
inline void DeserializeEdge(EdgeState& es, const char* open,
                            const char* folded, const char* saved) {
    if (folded)
        for (size_t i = 0; i < es.panels.size() && folded[i]; ++i) {
            es.panels[i].folded = folded[i] == '1';
            es.panels[i].animW  = es.panels[i].folded
                                ? 0.0f : es.panels[i].widthPx;
        }
    es.savedFolded.clear();
    if (saved) for (const char* q = saved; *q; ++q)
        es.savedFolded.push_back(*q == '1' ? 1 : 0);
    if (open && open[0] == '1') {
        es.openX = es.targetX = TotalW(es);
    } else {
        es.openX = es.targetX = 0.0f;
    }
}

} // namespace UiNavi
