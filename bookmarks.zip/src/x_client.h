// x_client.h
//
// Thin client around X's (Twitter's) internal GraphQL endpoints, the same
// ones the web app (x.com) uses in your browser. There is no free public
// API for bookmarks, so this re-uses your logged-in browser session via
// cookies instead of automating a real login.
//
// HOW TO GET YOUR COOKIES
// ------------------------
// 1. Open x.com in your browser, logged in.
// 2. Open DevTools (F12) -> Application/Storage -> Cookies -> x.com
// 3. Copy the values of:
//      - auth_token
//      - ct0
//
// These two cookies are enough to authenticate as you. Treat them like a
// password.
//
// NOTE ON TOS: this uses X's internal/undocumented endpoints, not the
// official public API. Standard approach for unofficial bookmark tools,
// but against the letter of X's ToS -- use only on your own account.

#pragma once

#include <string>
#include <vector>
#include <optional>
#include <functional>
#include <atomic>

struct Tweet {
    std::string id;
    std::string text;
    std::string author_name;
    std::string author_handle;
    std::string created_at;
    std::optional<std::string> thumb_url;  // smallest available media preview
    std::optional<std::string> media_type; // "photo" | "video" | "animated_gif"
    std::string url;                       // link to the tweet on x.com
};

class XClient {
public:
    XClient(std::string auth_token, std::string ct0);
    ~XClient();

    // Quick check that the cookies actually authenticate. Returns true on
    // a successful (200) response from a lightweight account endpoint.
    bool verify_credentials();

    // Fetches one page of bookmarks. Returns the tweets found and sets
    // next_cursor (empty string if there's no more data).
    // Throws std::runtime_error on a non-200 HTTP response.
    std::vector<Tweet> fetch_bookmarks_page(const std::string& cursor, std::string& next_cursor, int count = 100);

    // Deletes (unbookmarks) a single tweet. Returns true on success.
    bool delete_bookmark(const std::string& tweet_id);

    // Streams all bookmark pages, calling on_page for each page as it
    // arrives (so callers can render progressively). Stops when a page
    // is empty, there's no next cursor, max_pages is hit, or
    // should_stop() returns true (checked between pages, lets callers
    // cancel a long-running fetch from another thread).
    void fetch_all_bookmarks(
        const std::function<void(const std::vector<Tweet>&)>& on_page,
        const std::function<bool()>& should_stop = [] { return false; },
        int max_pages = 1000,
        int page_size = 100
    );

private:
    std::string auth_token_;
    std::string ct0_;

    // Performs a GET request with the standard auth headers. Throws
    // std::runtime_error on curl failure or non-200 response.
    std::string http_get(const std::string& url);

    // Performs a POST request with a JSON body and the standard auth
    // headers. Throws std::runtime_error on curl failure.
    std::string http_post_json(const std::string& url, const std::string& json_body);

    // Parses a raw Bookmarks GraphQL JSON response into tweets + next cursor.
    std::vector<Tweet> parse_bookmarks_page(const std::string& json_text, std::string& next_cursor);
};
