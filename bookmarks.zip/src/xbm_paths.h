#pragma once
// ---------------------------------------------------------------------------
// xbm_paths.h -- WO liegen die mitgelieferten Dateien?
//
// PROJEKTSEITE (was du bearbeitest):
//   data/shared/     -> landet auf ALLEN Plattformen
//   data/linux/      -> nur Linux
//   data/windows/    -> nur Windows
//   data/android/    -> nur Android
// Die plattformspezifischen Ordner werden UEBER data/shared gelegt, gleiche
// Dateinamen gewinnen also plattformseitig.
//
// ZIELSEITE (was zur Laufzeit da ist) -- EIN Datenstamm je Plattform:
//   Linux / Windows : <Ordner der ausfuehrbaren Datei>/data
//   Android         : <internalDataPath>/data
// Und darunter, weil sie in data/shared/ liegen:
//   <Datenstamm>/assets
//   <Datenstamm>/pdfgen
//
// ANMERKUNG ZUR AUSLEGUNG: In der Anforderung stand einmal "assets liegt
// neben der ausfuehrbaren Datei" und einmal "data/shared wird in den
// Datenordner gemischt". Beides zusammen geht nicht. Umgesetzt ist die
// mechanisch stimmige Lesart: data/shared/assets wandert beim Mischen
// natuerlich nach <Datenstamm>/assets. Willst du assets stattdessen als
// Geschwister von data/ neben der Binaerdatei, ist das GENAU EINE Zeile --
// XbmPaths_Assets() unten -- plus die entsprechende Kopierregel im CMake.
//
// ANDROID BESONDERS: In einem APK gibt es kein Dateisystem, aus dem man
// einfach lesen koennte -- Mitgeliefertes steckt als Asset im Archiv. Beim
// ersten Start (und nach jedem Update) entpackt XbmPaths_Init() den
// Asset-Baum nach <internalDataPath>/data. Danach ist der Zugriff auf allen
// drei Plattformen identisch: ein normaler Pfad.
// ---------------------------------------------------------------------------
#include <string>
#include <vector>

struct AAssetManager;   // vorwaerts, damit Desktop nichts von Android weiss

// Einmal beim Start aufrufen, VOR jedem Dateizugriff.
//   Desktop : argv[0] genuegt (dient nur als Rueckfall, wenn das System
//             den eigenen Pfad nicht verraet).
//   Android : Asset-Manager und internalDataPath uebergeben; dann wird
//             entpackt.
void XbmPaths_Init(const char* argv0);
void XbmPaths_InitAndroid(AAssetManager* mgr, const char* internalDataPath);

// Ordner der ausfuehrbaren Datei (Desktop) bzw. internalDataPath (Android).
std::string XbmPaths_AppDir();
// Vollstaendiger Pfad zur eigenen, gerade laufenden Programmdatei --
// gebraucht fuers Selbst-Update: dort muss die neue Fassung genau
// hin/darueber. Leer, falls XbmPaths_Init() noch nicht lief oder das
// System (Android) keinen solchen Pfad kennt.
std::string XbmPaths_SelfExe();
// MITGELIEFERTE VORLAGEN (schreibgeschuetzt gedacht) -- siehe Kopf.
// [Kommen mit jedem Bau und jedem Update neu mit. Die App SCHREIBT hier
//  NIE. Wer hier schrieb, verlor seine Aenderungen beim naechsten Bau
//  (CMake kopiert data/shared drueber) und beim naechsten Update (das
//  Paket bringt data/ mit) -- so ging eine bearbeitete Bewerbungsvorlage
//  verloren, als ein APK gebaut wurde.]
std::string XbmPaths_DataRoot();
std::string XbmPaths_Assets();          // Shader usw. -- nur lesen, bleibt bei den Vorlagen

// BENUTZERDATEN (bestaendig, beschreibbar) -- HIER arbeitet die App.
// [Eigener Ordner ausserhalb des Programmordners: Desktop
//  <AppUserConfigFolder>/data, Android <internalDataPath>/userdata.
//  Weder Bau noch Update fassen ihn an. Beim Start wird ERGAENZT, was
//  aus den Vorlagen noch fehlt (Datei existiert dort, hier nicht) --
//  vorhandene Dateien werden NIE ueberschrieben. Ein frisches Geraet hat
//  damit alle Standarddaten, ein bestehendes behaelt seine Aenderungen.]
std::string XbmPaths_UserData();
std::string XbmPaths_Pdfgen();          // = UserData/pdfgen -- lesen UND schreiben
std::string XbmPaths_Sub(const std::string& relative);   // = UserData/<relative>
// Vorlagen-Gegenstueck fuer den Vergleich "was hat der Nutzer geaendert".
std::string XbmPaths_PdfgenVorlagen();  // = DataRoot/pdfgen
// Fehlende Dateien aus den Vorlagen in die Benutzerdaten kopieren --
// laeuft automatisch beim Start, kann aber auch ausdruecklich angestossen
// werden (z.B. "Vorlagen nachladen"). Liefert die Zahl kopierter Dateien.
int  XbmPaths_VorlagenErgaenzen();

// PROJEKTORDNER (Quellbaum mit .git und data/shared), falls die App aus
// einem Bauordner heraus laeuft -- fuer den "Push"-Knopf, der geaenderte
// Benutzerdaten zurueck ins Projekt und nach Git bringt. Leer, wenn keiner
// gefunden wird (z.B. installierte Fassung, Android).
std::string XbmPaths_ProjektRoot();

// Datei/Ordner mit dem Standardprogramm des Systems oeffnen (PDF im
// Betrachter, Ordner im Dateimanager). Android: geht ueber den Hook, den
// main_android.cpp setzt (Intent ueber Java); ohne Hook tut es nichts.
bool XbmPaths_OeffnenExtern(const std::string& pfad);
extern bool (*XbmPaths_OeffnenExternHook)(const std::string& pfad);
// Datei kopieren (ueberschreibt). true bei Erfolg.
bool XbmPaths_KopiereDatei(const std::string& von, const std::string& nach);

// Beschreibbarer Ordner fuer Nutzerdaten (Kalender, Einstellungen, Cache).
// Auf Android identisch mit internalDataPath, auf dem Desktop der bereits
// verwendete AppUserConfigFolder -- den setzt die App per Setter, damit
// dieses Modul nicht von HelloImGui abhaengt.
void        XbmPaths_SetUserDir(const std::string& dir);
std::string XbmPaths_UserDir();

// Existenz / Anlegen / Auflisten -- knapp gehalten, es gibt schon
// UiReadFile/UiWriteFile in ui_files.h.
bool XbmPaths_Exists(const std::string& path);
bool XbmPaths_IsDir(const std::string& path);
bool XbmPaths_MakeDirs(const std::string& path);
// Dateien eines Ordners (nicht rekursiv), optional nach Endung gefiltert.
// Liefert reine Dateinamen, alphabetisch sortiert.
std::vector<std::string> XbmPaths_ListFiles(const std::string& dir,
                                            const std::string& ext = "");
std::vector<std::string> XbmPaths_ListDirs(const std::string& dir);

// Kurzbericht fuer den Eingabe-Monitor: welche Pfade wurden ermittelt und
// existieren sie? Spart beim Einrichten viel Ratespiel.
std::string XbmPaths_Report();
