#pragma once
// bookmark_window.h  (v2)
// Gemeinsames Bookmark-Fenster fuer Desktop UND Android -- identisches
// Verhalten, eine Codebasis.
//
// AUSWAHL-SYSTEM
//  Maus (Desktop):
//   - Linksklick:  Item waehlen        | Rechtsklick: Item abwaehlen
//   - Links-Drag:  Items hinzufuegen   | Rechts-Drag: Items entfernen
//   - Shift+Links: Bereich bis hier waehlen | Shift+Rechts: ... abwaehlen
//   - Drag ueber den Fensterrand: Auto-Scroll, Geschwindigkeit proportional
//     zur Distanz ausserhalb; ueberstrichene Items werden mit-(ab)gewaehlt.
//  Touch (Android):
//   - Einfacher Drag: scrollt die Liste (bewegt NICHT das Fenster)
//   - Doppeltipp, dann Drag: waehlt Items (+Auto-Scroll am Rand)
//   - Dreifachtipp, dann Drag: waehlt Items ab (+Auto-Scroll am Rand)
//
// THUMBNAILS: optionaler getTexture-Callback liefert die GL-Textur-ID
// pro Tweet (0 = keine); wird links neben dem Text gezeichnet.

#include "imgui.h"
#include "ui_helpers.h"
#include <functional>
#include <string>
#include <unordered_set>
#include <unordered_map>
#include <vector>
#include <cmath>

struct BookmarkItem {
    std::string id;
    std::string author;
    std::string text;
};

struct BookmarkCallbacks {
    std::function<void()>                                onLoad;
    std::function<void(const std::vector<std::string>&)> onDelete;
    std::function<void(const std::string&)>              onOpen;
    std::function<unsigned int(const std::string&)>      getTexture; // optional
    std::function<void()>                                onLogin;    // optional:
                                       // "Login"-Knopf neben Max -- zurueck
                                       // zur X-Login-(Cookies)-Oberflaeche
    // LOGIN IM SELBEN FENSTER.
    // [Statt eines eigenen Login-Fensters je Plattform zeichnet drawLogin
    //  den Anmeldebereich OBEN IM Manager-Fenster: aufgeklappt, solange
    //  nicht angemeldet; danach ueber den "Login"-Knopf im Titel ein- und
    //  ausklappbar. Ein Fenster je Plattform, dieselbe Bedienung fuer
    //  alle drei -- und kein zweites Fenster, das man suchen muss.]
    std::function<void()>                                drawLogin;  // optional
    std::function<bool()>                                loggedIn;   // optional
};

namespace bookmark_detail {
struct SelState {
    // Maus/Touch-Drag
    bool  dragging   = false;
    bool  dragRemove = false;   // false = hinzufuegen, true = entfernen
    int   anchor     = -1;      // fuer Shift-Ranges & letzter Klick
    // Touch-Mehrfachtipp
    int    tapCount   = 0;
    double lastTapT   = 0.0;
    ImVec2 lastTapPos{};
    int    armedMode  = 0;      // 0=aus, 1=waehlen, 2=abwaehlen (nach 2/3 Tipps)
};
inline void applyRange(std::unordered_set<std::string>& sel,
                       const std::vector<BookmarkItem>& items,
                       int a, int b, bool remove) {
    if (a < 0 || b < 0) return;
    if (a > b) { int t = a; a = b; b = t; }
    for (int i = a; i <= b && i < (int)items.size(); ++i) {
        if (remove) sel.erase(items[i].id);
        else        sel.insert(items[i].id);
    }
}
} // namespace bookmark_detail

inline void DrawBookmarkWindow(const char*                       title,
                               const std::vector<BookmarkItem>&  items,
                               std::unordered_set<std::string>&  selected,
                               const BookmarkCallbacks&          cb,
                               const std::string&                status,
                               bool*                             open = nullptr) {
    using namespace bookmark_detail;
    // ZUSTAND JE FENSTER, nicht je Funktion.
    // [Vorher:  static UiMaxState maxState;  -- EIN Zustand fuer alle
    //  Aufrufe. Seit Reddit und Facebook wird die Funktion dreimal je
    //  Frame gerufen; alle drei teilten sich Maximier-, Auswahl- und
    //  Tippzustand. Was X als "maximiert" gemerkt hatte, galt auch fuer
    //  die anderen -- die Fenster lagen deckungsgleich uebereinander.]
    static std::unordered_map<std::string, UiMaxState> maxStates;
    UiMaxState& maxState = maxStates[title];
    static std::unordered_map<std::string, SelState> sels;
    SelState& st = sels[title];

#if defined(__ANDROID__)
    const bool touchMode = true;
#else
    const bool touchMode = false;
#endif

    ImGui::SetNextWindowSize(ImVec2(560, 640), ImGuiCond_FirstUseEver);
    // Anfangsposition je Fenster versetzt -- sonst starten drei Fenster
    // mit derselben Groesse an derselben Stelle und sehen wie eines aus.
    {
        unsigned h = 0; for (const char* c = title; *c; ++c) h = h * 31u + (unsigned char)*c;
        float off = 40.0f + (float)(h % 4) * 60.0f;
        ImGui::SetNextWindowPos(ImVec2(off, off + 60.0f), ImGuiCond_FirstUseEver);
    }
    bool loginClicked = false;
    if (!UiBeginMaximizable(title, maxState, open, 0,
                            cb.onLogin ? "Login" : nullptr,
                            &loginClicked)) { ImGui::End(); return; }
    // SOFORT ausfuehren (noch INNERHALB des Begin): der Handler liest
    // die aktuelle Fenster-Geometrie fuer die Platz-Uebergabe.
    if (loginClicked && cb.onLogin) cb.onLogin();

    // --- Anmeldebereich (nur wenn die Plattform einen liefert) ------------
    if (cb.drawLogin) {
        static std::unordered_map<std::string, bool> loginAuf;
        bool angemeldet = cb.loggedIn ? cb.loggedIn() : false;
        bool& auf = loginAuf[title];
        // Nicht angemeldet: immer offen. Der Titel-Knopf schaltet um.
        if (!angemeldet) auf = true;
        else if (loginClicked) auf = !auf;
        if (auf) {
            ImGui::PushStyleColor(ImGuiCol_ChildBg,
                                  ImGui::GetStyleColorVec4(ImGuiCol_FrameBg));
            // Hoehe = Inhalt (ChildFlags, wie in ui_filetree.h benutzt).
            ImGui::BeginChild("##login_bereich", ImVec2(0, 0),
                              ImGuiChildFlags_Borders | ImGuiChildFlags_AutoResizeY,
                              ImGuiWindowFlags_NoScrollbar);
            cb.drawLogin();
            if (angemeldet) {
                if (ImGui::SmallButton("Bereich einklappen")) auf = false;
            }
            ImGui::EndChild();
            ImGui::PopStyleColor();
            ImGui::Separator();
        }
    }

    // Der Doppeltipp hat in DIESEM Fenster eine EIGENE Bedeutung
    // (Auswahl-Modus der Liste: Doppeltipp+Drag waehlt, Dreifachtipp+
    // Drag waehlt ab). Der Doppeltipp-WIEDEREINTRITT der globalen
    // Pinpoint-Geste ist hier deshalb abgeschaltet -- sonst wuerde ein
    // Auswahl-Doppeltipp nebenbei das Scroll-Ziel verstellen.
    UiDblTapReentryOptOut().push_back(ImGui::GetCurrentWindow()->Rect());

    // --- Kopfzeile mit Umbruch bei schmalem Fenster -------------------------
    bool first = true;
    auto btn = [&](const char* label) {
        if (!first) UiWrapSameLine(label);
        first = false;
        return ImGui::Button(label);
    };
    if (cb.onLoad && btn("Laden")) cb.onLoad();
    if (btn("Alle"))  for (const auto& it : items) selected.insert(it.id);
    if (btn("Keine")) selected.clear();
    {
        char lbl[64];
        snprintf(lbl, sizeof(lbl), "Loeschen (%d)", (int)selected.size());
        if (!first) UiWrapSameLine(lbl);
        first = false;
        ImGui::BeginDisabled(selected.empty() || !cb.onDelete);
        if (ImGui::Button(lbl)) {
            std::vector<std::string> ids(selected.begin(), selected.end());
            cb.onDelete(ids);
        }
        ImGui::EndDisabled();
    }
    if (!status.empty()) ImGui::TextWrapped("%s", status.c_str());
    ImGui::Separator();

    // --- Liste --------------------------------------------------------------
    std::vector<ImVec2> rowMin, rowMax;

    if (ImGui::BeginChild("bookmark_list")) {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        const float thumbSz = 56.0f;

        // ListClipper: rendert NUR sichtbare Zeilen. Ohne ihn skaliert die
        // Framezeit linear mit der Anzahl der Bookmarks (TextWrapped-Layout
        // fuer hunderte Eintraege pro Frame) -- der progressive FPS-Einbruch
        // nach dem Laden der Liste.
        // SCROLL-ANKER: Die Liste waechst zur Laufzeit (Nachladen) und
        // Zeilenhoehen aendern sich (Thumbnails treffen spaeter ein).
        // Ohne Verankerung rutscht der Inhalt unter dem Finger weg.
        // Gemerkt wird der OBERSTE sichtbare Eintrag samt Pixelversatz;
        // nach dem Aufbau wird er exakt wieder an dieselbe Stelle
        // gelegt.
        static std::string anchorId;
        static float       anchorOff = 0.0f;
        {   // Anker aus dem VORFRAME bestimmen (rowMin ist noch gefuellt)
            float top = ImGui::GetWindowPos().y;
            anchorId.clear();
            for (size_t i = 0; i < rowMin.size() && i < items.size(); ++i) {
                if (rowMin[i].y == 0.0f && rowMax[i].y == 0.0f) continue;
                if (rowMax[i].y >= top) {
                    anchorId  = items[i].id;
                    anchorOff = rowMin[i].y - top;
                    break;
                }
            }
        }
        rowMin.assign(items.size(), ImVec2(0, 0));
        rowMax.assign(items.size(), ImVec2(0, 0));
        // EINHEITLICHE ZEILENHOEHE: Der ListClipper schaetzt die
        // Zeilenhoehe aus den ersten Eintraegen. Sind die Zeilen
        // unterschiedlich hoch (Thumbnail ja/nein, verschieden langer
        // Umbruchtext), korrigiert er die Schaetzung beim Scrollen
        // laufend -- die Gesamthoehe aendert sich mitten in der Geste
        // und die Liste SPRINGT, auch ohne neue Eintraege. Mit fester
        // Hoehe ist die Rechnung exakt und das Scrollen glatt.
        // Zeilenhoehe so bemessen, dass Autor, zwei Textzeilen und der
        // Knopf hineinpassen -- vorher wurde der Text abgeschnitten.
        const float rowTextH = ImGui::GetTextLineHeightWithSpacing() * 3.0f
                             + ImGui::GetFrameHeight();
        const float rowH = (thumbSz > rowTextH ? thumbSz : rowTextH)
                         + ImGui::GetStyle().ItemSpacing.y * 2.0f;
        ImGuiListClipper clip;
        clip.Begin((int)items.size(), rowH);
        while (clip.Step())
        for (int i = clip.DisplayStart; i < clip.DisplayEnd; ++i) {
            const auto& it = items[i];
            ImGui::PushID(it.id.c_str());
            ImVec2 rMin = ImGui::GetCursorScreenPos();
            float rowY0 = ImGui::GetCursorPosY();
            // Inhalt auf die Zeile begrenzen, damit langer Text die
            // Hoehe nicht sprengt.
            ImGui::PushClipRect(rMin,
                ImVec2(rMin.x + ImGui::GetWindowWidth(), rMin.y + rowH),
                true);

            unsigned int tex = cb.getTexture ? cb.getTexture(it.id) : 0;
            if (tex) {
                ImGui::Image((ImTextureID)(intptr_t)tex,
                             ImVec2(thumbSz, thumbSz));
                ImGui::SameLine();
            }
            ImGui::BeginGroup();
            ImGui::TextUnformatted(it.author.c_str());
            ImGui::TextWrapped("%s", it.text.c_str());
            if (cb.onOpen && ImGui::SmallButton("Oeffnen")) cb.onOpen(it.id);
            ImGui::EndGroup();

            ImGui::PopClipRect();
            ImGui::SetCursorPosY(rowY0 + rowH);   // exakte Zeilenhoehe
            ImVec2 rMax(rMin.x + ImGui::GetWindowWidth(),
                        rMin.y + rowH);
            rowMin[i] = rMin; rowMax[i] = rMax;

            // Auswahl-Highlight hinter der Zeile
            if (selected.count(it.id))
                dl->AddRectFilled(rMin, rMax, IM_COL32(80, 140, 255, 45));

            ImGui::Separator();
            ImGui::PopID();
        }

        // --- Eingabe-Logik (auf dem Child) ---------------------------------
        ImGuiIO& io = ImGui::GetIO();
        bool hoveredChild = ImGui::IsWindowHovered(
            ImGuiHoveredFlags_AllowWhenBlockedByActiveItem);
        ImVec2 cMin = ImGui::GetWindowPos();
        ImVec2 cMax(cMin.x + ImGui::GetWindowSize().x,
                    cMin.y + ImGui::GetWindowSize().y);

        auto hoveredIndex = [&]() -> int {
            for (int i = 0; i < (int)rowMin.size(); ++i)
                if (rowMax[i].y > rowMin[i].y
                    && io.MousePos.y >= rowMin[i].y && io.MousePos.y < rowMax[i].y
                    && io.MousePos.x >= cMin.x && io.MousePos.x < cMax.x)
                    return i;
            return -1;
        };

        if (!touchMode) {
            // ---------------- Desktop-Maus-Modus ----------------
            int hi = hoveredIndex();
            for (int mb = 0; mb <= 1; ++mb) { // 0=links(waehlen) 1=rechts(abwaehlen)
                bool rem = (mb == 1);
                if (hoveredChild && ImGui::IsMouseClicked(mb) && hi >= 0) {
                    if (io.KeyShift && st.anchor >= 0)
                        applyRange(selected, items, st.anchor, hi, rem);
                    else if (rem) selected.erase(items[hi].id);
                    else          selected.insert(items[hi].id);
                    st.anchor = hi;
                    st.dragging = true; st.dragRemove = rem;
                }
            }
            if (st.dragging) {
                if (!io.MouseDown[0] && !io.MouseDown[1]) st.dragging = false;
                else {
                    int hi2 = hoveredIndex();
                    if (hi2 >= 0)
                        applyRange(selected, items, hi2, hi2, st.dragRemove);
                    // Rand-Autoscroll, proportional zur Distanz
                    float dy = 0;
                    if (io.MousePos.y > cMax.y) dy = io.MousePos.y - cMax.y;
                    else if (io.MousePos.y < cMin.y) dy = io.MousePos.y - cMin.y;
                    if (dy != 0) {
                        ImGui::SetScrollY(ImGui::GetScrollY()
                                          + dy * 8.0f * io.DeltaTime);
                        int hi3 = hoveredIndex();
                        if (hi3 < 0) hi3 = dy > 0 ? (int)items.size()-1 : 0;
                        applyRange(selected, items, hi3, hi3, st.dragRemove);
                    }
                }
            }
        } else {
            // ---------------- Android-Touch-Modus ----------------
            // Tipp-Zaehlung (Doppel-/Dreifachtipp) auf dem Child
            if (hoveredChild && ImGui::IsMouseClicked(0)) {
                double now = ImGui::GetTime();
                float dx = io.MousePos.x - st.lastTapPos.x;
                float dyp = io.MousePos.y - st.lastTapPos.y;
                bool isNear = (dx*dx + dyp*dyp) < 60.0f*60.0f;
                st.tapCount = (now - st.lastTapT < 0.35 && isNear)
                              ? st.tapCount + 1 : 1;
                st.lastTapT = now; st.lastTapPos = io.MousePos;
                if (st.tapCount == 2) st.armedMode = 1;   // waehlen
                if (st.tapCount >= 3) st.armedMode = 2;   // abwaehlen
                // SOFORTWIRKUNG auf den getippten Eintrag: Doppeltipp
                // waehlt ihn, Dreifachtipp waehlt ihn ab -- ohne dass
                // man zusaetzlich ziehen muss.
                {
                    int hiTap = hoveredIndex();
                    if (hiTap >= 0 && st.tapCount >= 2)
                        applyRange(selected, items, hiTap, hiTap,
                                   st.tapCount >= 3);
                }
            }
            // Zieh-Ursprung merken: Verlaesst der Finger die Liste,
            // war hoveredChild false und der ganze Block (inkl. Edge-
            // Auto-Scroll) lief nicht mehr -- genau dann soll er aber
            // arbeiten.
            static bool dragFromChild = false;
            if (ImGui::IsMouseClicked(0)) dragFromChild = hoveredChild;
            if (!io.MouseDown[0]) dragFromChild = false;
            // NUR wenn die Geste IN der Liste begonnen hat. Wischt man
            // von aussen herein, bleibt sie beim bisherigen Besitzer.
            if (io.MouseDown[0] && dragFromChild) {
                if (st.armedMode == 0) {
                    // KEIN eigenes Scrollen mehr: Die globale
                    // Pin-Point-Regelung behandelt auch diese Liste
                    // (sie ist Teil der Scroll-Kette). Damit gilt
                    // ueberall dasselbe Modell, und Doppel-Scrollen
                    // sowie Uebergabe-Konflikte entfallen.
                } else {
                    UiDragHandledThisFrame() = true;  // Auswahl hat Vorrang
                    bool rem = (st.armedMode == 2);
                    int hi2 = hoveredIndex();
                    if (hi2 >= 0)
                        applyRange(selected, items, hi2, hi2, rem);
                    float dy = 0;
                    if (io.MousePos.y > cMax.y) dy = io.MousePos.y - cMax.y;
                    else if (io.MousePos.y < cMin.y) dy = io.MousePos.y - cMin.y;
                    if (dy != 0)
                        ImGui::SetScrollY(ImGui::GetScrollY()
                                          + dy * 8.0f * io.DeltaTime);
                }
            }
            if (ImGui::IsMouseReleased(0)) {
                // MODUS ZURUECKSETZEN, DEN TIPPZAEHLER ABER NICHT.
                // [Hier stand  st.tapCount = 0  beim Loslassen. Damit
                //  fing der dritte Tipp wieder bei 1 an -- die 3 war
                //  schlicht unerreichbar, und das Abwaehlen per
                //  Dreifachtipp konnte nie funktionieren.
                //  Der Zaehler verfaellt von selbst: nach 0,35 s ohne
                //  weiteren Tipp beginnt die Zaehlung ohnehin neu.]
                if (st.armedMode != 0) st.armedMode = 0;
            }
        }
        // Anker wiederherstellen: Sitzt der gemerkte Eintrag nicht mehr
        // an seinem Platz (Nachladen/Hoehenaenderung), wird die
        // Scrollposition um die Differenz korrigiert -- fuer den Nutzer
        // bleibt das Bild stehen, statt zu springen. Waehrend einer
        // laufenden Geste NICHT eingreifen.
        if (!anchorId.empty() && !ImGui::GetIO().MouseDown[0]) {
            float top = ImGui::GetWindowPos().y;
            for (size_t i = 0; i < items.size() && i < rowMin.size(); ++i) {
                if (items[i].id != anchorId) continue;
                if (rowMin[i].y == 0.0f && rowMax[i].y == 0.0f) break;
                float now  = rowMin[i].y - top;
                float diff = now - anchorOff;
                if (fabsf(diff) > 0.5f) {
                    float ns = ImGui::GetScrollY() + diff;
                    float mx = ImGui::GetScrollMaxY();
                    if (ns < 0.0f) ns = 0.0f;
                    if (ns > mx)   ns = mx;
                    ImGui::SetScrollY(ns);
                }
                break;
            }
        }
    }
    ImGui::EndChild();
    ImGui::End();
}
