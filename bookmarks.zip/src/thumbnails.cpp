// thumbnails.cpp
//
// Architecture: worker threads ONLY download files to disk (no stb calls).
// The main thread (poll()) does ALL image decoding and GL uploads.
// This ensures stb_image is only ever called from one thread, eliminating
// any duplicate-symbol or thread-safety issues with the JPEG decoder.

#include "thumbnails.h"

#include <curl/curl.h>
#include "curl_android_ca.h"  // Android: CA-Pfad zur Laufzeit (APEX vs. Legacy)

// Isolate our stb_image from HelloImGui's copy by prefixing all symbols.
// HelloImGui compiles its own stb_image.h (possibly a different version)
// with -DSTB_IMAGE_IMPLEMENTATION. If we share that copy, struct layout
// mismatches between versions corrupt the JPEG decoder. Using a prefix
// gives us a completely separate, self-contained copy that never conflicts.
#define STBI_NO_HDR
#define STBI_NO_LINEAR
#define STB_IMAGE_STATIC          // make all functions static = no symbol conflict at all
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// stb_image_resize2: not compiled by HelloImGui, but make it static anyway
// for the same isolation principle.
#define STBIR_STATIC
#define STB_IMAGE_RESIZE_IMPLEMENTATION
#include "stb_image_resize2.h"

#if defined(__ANDROID__)
#include <GLES3/gl3.h>
#else
#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>
#include <imgui_impl_opengl3_loader.h>
#endif
#ifdef _WIN32
#include <windows.h>  // wglGetCurrentContext
#endif

#include <fstream>
#include <sstream>
#include <cstdint>
#include <filesystem>
#include <system_error>
#include <unordered_map>
#include <memory>

namespace {

constexpr int kMaxThumbDim = 160;

size_t curl_write_to_string(char* ptr, size_t size, size_t nmemb, void* userdata) {
    auto* out = static_cast<std::string*>(userdata);
    out->append(ptr, size * nmemb);
    return size * nmemb;
}

// FNV-1a 64-bit: deterministic across platforms, unlike std::hash which
// produces different values on Windows vs Linux causing cache filename
// collisions.
uint64_t fnv1a_64(const std::string& s) {
    uint64_t hash = 14695981039346656037ULL;
    for (unsigned char c : s) {
        hash ^= c;
        hash *= 1099511628211ULL;
    }
    return hash;
}

std::string get_cache_dir() {
    static std::string dir = "./thumb_cache";
    return dir;
}

}  // namespace

static std::string g_cache_dir = "./thumb_cache";

void set_thumbnail_cache_dir(const std::string& dir) {
    // LEEREN PFAD NICHT UEBERNEHMEN und NIE WERFEN.
    // [create_directories("") wirft filesystem_error("Invalid argument []")
    //  -- und da niemand hier faengt, beendet das die App:
    //      terminate called after throwing ... cannot create directories
    //  Ein Bildchen-Zwischenspeicher ist keinen Programmabbruch wert.]
    if (!dir.empty()) g_cache_dir = dir;
    std::error_code ec;
    std::filesystem::create_directories(g_cache_dir, ec);
}

std::string ThumbnailManager::cache_path(const std::string& url) const {
    uint64_t h = fnv1a_64(url);
    std::ostringstream oss;
    oss << g_cache_dir << "/" << std::hex << h << ".jpg";
    return oss.str();
}

ThumbnailManager::ThumbnailManager(int num_workers, int max_in_flight)
    : max_in_flight_(max_in_flight) {
    // Must be called once before any thread uses curl. On Windows this
    // initialises WinSock2 and Schannel (SSL).
    curl_global_init(CURL_GLOBAL_ALL);

    // Ebenfalls ohne Werfen: dieser Konstruktor laeuft bei statischen
    // Instanzen VOR main() -- dort gibt es noch keinen gesetzten Pfad,
    // und ein Wurf waere ein Abbruch vor der ersten Bildzeile.
    {
        std::error_code ec;
        if (!g_cache_dir.empty())
            std::filesystem::create_directories(g_cache_dir, ec);
    }
    for (int i = 0; i < num_workers; ++i) {
        workers_.emplace_back([this] { worker_loop(); });
    }
}

ThumbnailManager::~ThumbnailManager() {
    shutting_down_ = true;
    queue_cv_.notify_all();
    for (auto& t : workers_) {
        if (t.joinable()) t.join();
    }
    curl_global_cleanup();
}

void ThumbnailManager::request(const std::string& tweet_id,
                               const std::optional<std::string>& url) {
    if (!url.has_value() || url->empty()) return;

    {
        std::lock_guard<std::mutex> lock(state_mutex_);
        if (requested_.count(tweet_id)) return;
        if (static_cast<int>(in_flight_.size()) >= max_in_flight_) return;
        requested_.insert(tweet_id);
        in_flight_.insert(tweet_id);
    }

    {
        std::lock_guard<std::mutex> lock(queue_mutex_);
        pending_.push({tweet_id, *url});
    }
    queue_cv_.notify_one();
}

void ThumbnailManager::worker_loop() {
    // Workers ONLY download files to disk -- no stbi_load, no image decoding.
    // All decoding happens on the main thread in poll() to avoid any
    // duplicate-symbol or thread-safety issues with stb_image's JPEG decoder.
    while (true) {
        PendingDownload job;
        {
            std::unique_lock<std::mutex> lock(queue_mutex_);
            queue_cv_.wait(lock, [this] {
                return shutting_down_ || !pending_.empty();
            });
            if (shutting_down_ && pending_.empty()) return;
            if (pending_.empty()) continue;
            job = pending_.front();
            pending_.pop();
        }

        std::string path = cache_path(job.url);
        bool downloaded = false;

        if (!std::filesystem::exists(path)) {
            CURL* curl = curl_easy_init();
            if (curl) {
                ApplyAndroidCaPath(curl);  // Android 14+: CAs liegen im Conscrypt-APEX
                std::string body;
                curl_easy_setopt(curl, CURLOPT_URL, job.url.c_str());
                curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_write_to_string);
                curl_easy_setopt(curl, CURLOPT_WRITEDATA, &body);
                curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);
                curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
                CURLcode res = curl_easy_perform(curl);
                long status = 0;
                curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
                curl_easy_cleanup(curl);

                if (res == CURLE_OK && status == 200 && !body.empty()) {
                    std::ofstream out(path, std::ios::binary);
                    if (out) {
                        out.write(body.data(),
                                  static_cast<std::streamsize>(body.size()));
                        out.close();
                        downloaded = true;
                    }
                }
            }
        } else {
            downloaded = true; // already cached
        }

        if (downloaded) {
            // Signal the main thread that this path is ready to decode.
            std::lock_guard<std::mutex> lock(ready_mutex_);
            ready_.push({job.tweet_id, path});
        }

        {
            std::lock_guard<std::mutex> lock(state_mutex_);
            in_flight_.erase(job.tweet_id);
        }
    }
}

void ThumbnailManager::poll(int max_uploads_per_frame) {
    // Guard: don't make GL calls without a current context.
    // On Linux/macOS we use GLFW so glfwGetCurrentContext() works.
    // On Windows we use a manual Win32+WGL context (no GLFW window),
    // so glfwGetCurrentContext() always returns NULL -- use wglGetCurrentContext() instead.
#if defined(_WIN32)
    if (!wglGetCurrentContext()) return;
#elif !defined(__ANDROID__)
    if (!glfwGetCurrentContext()) return;
#endif

    int uploaded = 0;
    while (uploaded < max_uploads_per_frame) {
        ReadyPath rp;
        {
            std::lock_guard<std::mutex> lock(ready_mutex_);
            if (ready_.empty()) break;
            rp = ready_.front();
            ready_.pop();
        }

        fprintf(stderr, "[thumb] poll: decoding %s from %s\n",
                rp.tweet_id.c_str(), rp.path.c_str());
        int w = 0, h = 0, channels = 0;
        unsigned char* pixels =
            stbi_load(rp.path.c_str(), &w, &h, &channels, 4);
        if (!pixels) {
            fprintf(stderr, "[thumb] stbi_load failed: %s\n", rp.path.c_str());
            continue;
        }

        int target_w = w, target_h = h;
        if (w > kMaxThumbDim || h > kMaxThumbDim) {
            double scale =
                std::min(double(kMaxThumbDim) / w, double(kMaxThumbDim) / h);
            target_w = std::max(1, static_cast<int>(w * scale));
            target_h = std::max(1, static_cast<int>(h * scale));
        }

        std::vector<unsigned char> resized(
            static_cast<size_t>(target_w) * target_h * 4);
        stbir_resize_uint8_linear(pixels, w, h, 0, resized.data(),
                                  target_w, target_h, 0, STBIR_RGBA);
        stbi_image_free(pixels);

        GLuint tex_id = 0;
        glGenTextures(1, &tex_id);
        if (tex_id == 0) {
            fprintf(stderr, "[thumb] glGenTextures returned 0, skipping\n");
            continue;
        }
        glBindTexture(GL_TEXTURE_2D, tex_id);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, target_w, target_h, 0,
                     GL_RGBA, GL_UNSIGNED_BYTE, resized.data());

        textures_[rp.tweet_id] = tex_id;
        fprintf(stderr, "[thumb] uploaded tex_id=%u for %s (%dx%d)\n",
                tex_id, rp.tweet_id.c_str(), target_w, target_h);
        uploaded++;
    }
}

unsigned int ThumbnailManager::get_texture(const std::string& tweet_id) const {
    auto it = textures_.find(tweet_id);
    return it == textures_.end() ? 0 : it->second;
}

void ThumbnailManager::clear_all_textures() {
    for (auto& [id, tex] : textures_) {
        GLuint t = tex;
        glDeleteTextures(1, &t);
    }
    textures_.clear();

    std::lock_guard<std::mutex> lock(state_mutex_);
    requested_.clear();
    in_flight_.clear();
}
