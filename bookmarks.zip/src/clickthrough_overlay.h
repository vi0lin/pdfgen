#pragma once
#include <vector>
#include "imgui.h"
#include "imgui_internal.h"
struct GLFWwindow;
namespace ClickThroughOverlay {
// Call once, BEFORE glfwCreateWindow() / HelloImGui::Run() window creation.
// For HelloImGui, do this in runnerParams.callbacks.PostInit or just before Run()
// by hooking into the GLFW window hints (see usage notes below).
void SetupWindowHintsForTransparency();
// Call once, AFTER the native window is created (e.g. in PostInit callback,
// once HelloImGui::GetRunnerParams()->backendPointers.glfwWindow is valid).
void InitPlatformWindow(GLFWwindow* window);
// Call every frame, AFTER ImGui::Render() (or right after collecting your
// panel rects), BEFORE glfwSwapBuffers / before HelloImGui's present.
// rects = screen-space (OS pixel) rectangles of each interactive panel.
void UpdateClickThroughRegion(GLFWwindow* window, const std::vector<ImRect>& rects);
} // namespace ClickThroughOverlay
