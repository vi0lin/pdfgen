#pragma once
// effects_gl.h
//
// Rain- und Spin-Effekte als OpenGL/GLES-Renderings in verschiebbaren
// ImGui-Fenstern. Ersetzt die Vulkan-Overlay-Fenster: laeuft mit
// identischem Code auf Linux, Windows und Android, kein Threading,
// keine transparenten OS-Fenster, kein Click-through-Gefrickel noetig.
//
// Nutzung (im Renderloop, GL-Kontext muss current sein):
//   EffectsGl_ShowRainWindow(&showRain);
//   EffectsGl_ShowSpinWindow(&showSpin);
// Beim Beenden (optional, gibt GL-Objekte frei):
//   EffectsGl_Shutdown();

#include "imgui.h"   // ImVec2 fuer EffectsGl_GetOverlayRect

void EffectsGl_ShowRainWindow(bool* open);
void EffectsGl_ShowSpinWindow(bool* open);

// Zwei Dreiecks-Fenster, identisch auf Linux/Windows/Android:
//  Normal:  gewoehnliches Fenster mit Dreieck, normale Eingaben.
//  Overlay: NUR das orange Dreieck, kein Rahmen, transparenter Hintergrund;
//           per Ziehen auf dem Dreieck frei ueber den Viewport bewegbar.
//           (Click-through wurde auf Wunsch komplett entfernt.)
void EffectsGl_ShowTriangleNormal(bool* open);
void EffectsGl_ShowTriangleOverlay(bool* open);

// 2.2: animierter Vollbild-Hintergrund HINTER allen Fenstern
//      (Maus/Touch steuert den Glow). 2.3: animiertes Overlay UEBER allen
//      Fenstern (Teilbereich oben rechts; faengt keine Eingaben -- alles
//      bleibt bedienbar). Jeden Frame vor/nach den Fenstern aufrufen.
void EffectsGl_DrawBackground();
void EffectsGl_DrawOverlay();

// Einstellungen (Settings-Fenster steuert Sichtbarkeit/Deckkraft/Modus)
struct EffectsSettings {
    // Standard: AUS -- die Shader sind Zierde; wer sie will, schaltet
    // sie in den Effekt-Einstellungen ein (persistiert wie gehabt).
    bool  bgVisible  = false;  float bgOpacity = 100.0f; // in PROZENT (0..100)
    bool  ovVisible  = false;  float ovOpacity = 100.0f;
    bool  bgWindowed = false;  // true: Shader in verschiebbarem Fenster
    bool  clickThrough = true; // Desktop-Klicks ausserhalb der Fenster ans OS
    // TASKLEISTE BERUECKSICHTIGEN (nur Vollbild):
    //   true  -> Das Fenster nimmt nur den ARBEITSBEREICH des Monitors ein,
    //            also alles ausser Taskleiste/Panels, und liegt normal im
    //            Stapel. Die eigene Kopfzeile bleibt sichtbar.
    //   false -> Das Fenster nimmt den GANZEN Monitor ein und liegt
    //            dauerhaft OBEN, also auch ueber der Taskleiste. Sonst
    //            verschwindet die obere Leiste hinter dem Panel.
    bool  respectTaskbar = true;
    // Wird von der Checkbox gesetzt und von main.cpp nach dem Anwenden
    // wieder geloescht -- damit die Fenstergeometrie nicht in JEDEM Frame
    // neu gesetzt wird (das flackert und kostet).
    bool  taskbarDirty   = false;
    int   canvasMode   = 0;    // 0=Primaermonitor (schnell), 1=alle Monitore
    bool  dockingEnabled = true;  // Andocken/Tab-Gruppierung an/aus
    bool  lockLayout = false;             // Globale Layout-Sperre
    bool  showTriangle = false;           // transparentes Dreieck-Overlay
    bool  resizeAffectsNeighbors = false; // Splitter druecken Nachbarn zusammen
    bool  multiViewports = false; // Fenster auf andere Monitore ausloesen (experimentell)
};
EffectsSettings& EffectsGl_Settings();
void EffectsGl_SettingsContent();   // Inhalt (Fenster abgeschafft --
                                    // lebt in den App-Einstellungen)
// Kompakte Instanz-Uebersicht fuer den Eingabe-Monitor
void EffectsGl_AppendInstanceInfo();
// Bildschirm-Rechteck des Overlays (fuer die Win32-Sichtbarkeitsregion).
// Liefert false, wenn das Overlay unsichtbar ist.
bool EffectsGl_GetOverlayRect(ImVec2* outMin, ImVec2* outMax);

// Nach einem App-Wechsel aufrufen: verwirft GPU-Objekte, die den
// Kontextverlust nicht ueberlebt haben (sie werden dann neu erzeugt).
void EffectsGl_ValidateGpu();

void EffectsGl_Shutdown();
