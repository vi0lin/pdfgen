#pragma once
// android_insets.h -- System-Leisten-Abstaende (Statusleiste oben,
// Navigationsleiste unten) per JNI abfragen und auf ImGuis Arbeitsbereich
// anwenden. Danach respektieren alle Fenster/Module, die WorkPos/WorkSize
// nutzen (Pages, Monitor, Drawer, Tabs), die Safe-Areas automatisch.
#if defined(__ANDROID__)
#include <android_native_app_glue.h>
#include <jni.h>
#include "imgui.h"
#include "android_clipboard.h"   // JniEnvGuard + g_app wiederverwenden

namespace AndroidInsets {
inline float g_top = 0, g_bottom = 0;
inline double g_lastPoll = -1.0;

inline void Poll() {
    using namespace AndroidClipboard;
    if (!g_app) return;
    JniEnvGuard j; JNIEnv* e = j.env;
    jobject act = g_app->activity->clazz;
    jclass cAct = e->GetObjectClass(act);
    jmethodID mWin = e->GetMethodID(cAct, "getWindow",
        "()Landroid/view/Window;");
    jobject win = e->CallObjectMethod(act, mWin);
    if (!win) return;
    jclass cWin = e->GetObjectClass(win);
    jmethodID mDec = e->GetMethodID(cWin, "getDecorView",
        "()Landroid/view/View;");
    jobject dec = e->CallObjectMethod(win, mDec);
    if (!dec) return;
    jclass cV = e->GetObjectClass(dec);
    jmethodID mIns = e->GetMethodID(cV, "getRootWindowInsets",
        "()Landroid/view/WindowInsets;");
    if (!mIns) return;
    jobject ins = e->CallObjectMethod(dec, mIns);
    if (!ins) return;
    jclass cI = e->GetObjectClass(ins);
    jmethodID mT = e->GetMethodID(cI, "getSystemWindowInsetTop", "()I");
    jmethodID mB = e->GetMethodID(cI, "getSystemWindowInsetBottom", "()I");
    if (mT) g_top    = (float)e->CallIntMethod(ins, mT);
    if (mB) g_bottom = (float)e->CallIntMethod(ins, mB);
}

// Direkt NACH ImGui::NewFrame() aufrufen: verkleinert den Arbeitsbereich
// des Hauptviewports um die Leisten (JNI-Abfrage gedrosselt, 1x/Sekunde).
inline void Apply() {
    double now = ImGui::GetTime();
    // 4x/Sekunde: der Tastatur-Anteil der Insets kam mit 1-s-Drossel
    // bis zu einer Sekunde zu spaet -- die Seite sprang nach.
    if (now - g_lastPoll > 0.25) { g_lastPoll = now; Poll(); }
    ImGuiViewport* vp = ImGui::GetMainViewport();
    vp->WorkPos.y  += g_top;
    vp->WorkSize.y -= (g_top + g_bottom);
    if (vp->WorkSize.y < 100.0f) vp->WorkSize.y = 100.0f;
}
} // namespace AndroidInsets
#endif
