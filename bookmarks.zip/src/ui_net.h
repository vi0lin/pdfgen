#pragma once
// ui_net.h -- HTTP/HTTPS-Downloads (curl), einzeln oder als Verzeichnis.
//
// LAEUFT MIT DEINEM VORHANDENEN CURL: Der Android-Build zieht curl mit
// HTTP_ONLY=ON und mbedTLS -- genau das reicht hier. Fuer SFTP waere ein
// anderer Bau noetig (s. Hinweise am Dateiende).
//
// ALLES LAEUFT IM HINTERGRUND: send/recv blockieren, und ein blockierter
// UI-Thread heisst auf Android eingefrorene Oberflaeche und im
// schlimmsten Fall ein ANR. Deshalb Thread + atomare Statuswerte, die
// das UI pro Frame ausliest -- niemals Sperren im Zeichencode.
//
// BENUTZUNG:
//     UiNetDownload("https://example.org/datei.zip", "datei.zip");
//     ...
//     const UiNetJob& j = UiNetStatus();
//     if (j.running) ImGui::ProgressBar(j.Progress());
#include "ui_files.h"
#include <atomic>
#include <string>
#include <thread>
#include <vector>
#include <cstdio>
#include <curl/curl.h>

// ---------------------------------------------------------------------------
// Zustand eines laufenden Auftrags. Nur atomare Felder -- das UI liest
// sie jeden Frame, der Thread schreibt sie; ohne Sperre, ohne Wartezeit.
// ---------------------------------------------------------------------------
struct UiNetJob {
    std::atomic<bool>      running{false};
    std::atomic<bool>      cancel{false};
    std::atomic<long long> done{0};       // bereits geladene Bytes
    std::atomic<long long> total{0};      // Gesamtgroesse (0 = unbekannt)
    std::atomic<int>       filesDone{0};
    std::atomic<int>       filesTotal{0};
    std::atomic<long>      httpCode{0};
    // Nur vom Thread geschrieben, wenn running gerade false wird:
    std::string            lastError;
    std::string            lastFile;

    float Progress() const {
        long long t = total.load(), d = done.load();
        if (t > 0) return (float)((double)d / (double)t);
        int ft = filesTotal.load();
        if (ft > 0) return (float)filesDone.load() / (float)ft;
        return 0.0f;
    }
};

inline UiNetJob& UiNetStatus() { static UiNetJob j; return j; }

namespace ui_net_detail {

inline size_t WriteCb(char* ptr, size_t sz, size_t nm, void* ud) {
    FILE* f = (FILE*)ud;
    return fwrite(ptr, sz, nm, f);
}

inline int ProgressCb(void*, curl_off_t dlTotal, curl_off_t dlNow,
                      curl_off_t, curl_off_t) {
    UiNetJob& j = UiNetStatus();
    j.total.store((long long)dlTotal);
    j.done.store((long long)dlNow);
    return j.cancel.load() ? 1 : 0;      // != 0 bricht die Uebertragung ab
}

// Laedt EINE URL in eine Datei unterhalb von UiFilesBaseDir().
// Rueckgabe: leerer String = Erfolg, sonst die Fehlermeldung.
inline std::string FetchOne(const std::string& url,
                            const std::string& destName) {
    std::string path = UiFilePath(destName.c_str());
    // Erst in eine .part-Datei: Ein Abbruch hinterlaesst so keine
    // halbe Datei unter dem richtigen Namen.
    std::string tmp = path + ".part";
    FILE* f = fopen(tmp.c_str(), "wb");
    if (!f) return "Kann nicht schreiben: " + tmp;

    CURL* c = curl_easy_init();
    if (!c) { fclose(f); remove(tmp.c_str()); return "curl_easy_init fehlgeschlagen"; }

    char errbuf[CURL_ERROR_SIZE] = {0};
    curl_easy_setopt(c, CURLOPT_URL, url.c_str());
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, &WriteCb);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, (void*)f);
    curl_easy_setopt(c, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(c, CURLOPT_MAXREDIRS, 10L);
    curl_easy_setopt(c, CURLOPT_NOPROGRESS, 0L);
    curl_easy_setopt(c, CURLOPT_XFERINFOFUNCTION, &ProgressCb);
    curl_easy_setopt(c, CURLOPT_ERRORBUFFER, errbuf);
    curl_easy_setopt(c, CURLOPT_FAILONERROR, 1L);   // 404 = Fehler
    curl_easy_setopt(c, CURLOPT_CONNECTTIMEOUT, 20L);
    // KEIN Timeout auf die Gesamtdauer: Grosse Dateien ueber eine
    // langsame Mobilverbindung wuerden sonst mittendrin abbrechen.
    // Stattdessen Abbruch, wenn laenger als 60s < 100 Byte/s fliessen.
    curl_easy_setopt(c, CURLOPT_LOW_SPEED_LIMIT, 100L);
    curl_easy_setopt(c, CURLOPT_LOW_SPEED_TIME, 60L);
    // Zertifikate: Android hat keinen Bundle-Pfad, sondern ein
    // Verzeichnis -- dasselbe, das der Build als CURL_CA_PATH setzt.
    curl_easy_setopt(c, CURLOPT_CAPATH, "/system/etc/security/cacerts");

    CURLcode rc = curl_easy_perform(c);
    long code = 0;
    curl_easy_getinfo(c, CURLINFO_RESPONSE_CODE, &code);
    UiNetStatus().httpCode.store(code);
    curl_easy_cleanup(c);
    fclose(f);

    if (rc != CURLE_OK) {
        remove(tmp.c_str());
        std::string msg = errbuf[0] ? errbuf : curl_easy_strerror(rc);
        if (rc == CURLE_ABORTED_BY_CALLBACK) msg = "abgebrochen";
        return msg;
    }
    remove(path.c_str());                       // altes Ziel weg
    if (rename(tmp.c_str(), path.c_str()) != 0) {
        remove(tmp.c_str());
        return "Umbenennen fehlgeschlagen: " + destName;
    }
    return std::string();
}

inline void RunJob(std::vector<std::pair<std::string, std::string>> items) {
    UiNetJob& j = UiNetStatus();
    j.filesTotal.store((int)items.size());
    j.filesDone.store(0);
    std::string err;
    for (auto& it : items) {
        if (j.cancel.load()) { err = "abgebrochen"; break; }
        j.lastFile = it.second;
        j.done.store(0);
        j.total.store(0);
        err = FetchOne(it.first, it.second);
        if (!err.empty()) break;
        j.filesDone.fetch_add(1);
    }
    j.lastError = err;
    j.running.store(false);
}

} // namespace ui_net_detail

// Einmalige curl-Initialisierung (beim App-Start aufrufen).
inline void UiNetInit()    { curl_global_init(CURL_GLOBAL_DEFAULT); }
inline void UiNetCleanup() { curl_global_cleanup(); }

// Startet einen Download im Hintergrund. false = es laeuft schon einer.
inline bool UiNetDownload(const std::string& url, const std::string& destName) {
    UiNetJob& j = UiNetStatus();
    bool expected = false;
    if (!j.running.compare_exchange_strong(expected, true)) return false;
    j.cancel.store(false);
    j.lastError.clear();
    std::vector<std::pair<std::string, std::string>> items{{url, destName}};
    std::thread(ui_net_detail::RunJob, items).detach();
    return true;
}

// Mehrere Dateien am Stueck (URL -> Zielname), z.B. ein ganzes
// Verzeichnis, dessen Dateiliste du woanders herbekommen hast.
inline bool UiNetDownloadMany(
        std::vector<std::pair<std::string, std::string>> items) {
    UiNetJob& j = UiNetStatus();
    bool expected = false;
    if (!j.running.compare_exchange_strong(expected, true)) return false;
    j.cancel.store(false);
    j.lastError.clear();
    std::thread(ui_net_detail::RunJob, std::move(items)).detach();
    return true;
}

inline void UiNetCancel() { UiNetStatus().cancel.store(true); }

// ---------------------------------------------------------------------------
// HINWEIS ZU SFTP UND VERZEICHNISSEN
// ---------------------------------------------------------------------------
// * SFTP kann curl NUR, wenn es mit libssh2 gebaut wurde UND HTTP_ONLY
//   ausgeschaltet ist. Dein Android-curl hat beides nicht -- s. die
//   CMake-Aenderungen, die ich dir dazu getrennt gebe.
// * Ein "Verzeichnis herunterladen" gibt es im HTTP-Protokoll nicht: Es
//   braucht eine Dateiliste. Ueblich sind ein JSON-Index auf dem Server
//   oder ein einzelnes Archiv (.tar/.zip), das die App entpackt.
