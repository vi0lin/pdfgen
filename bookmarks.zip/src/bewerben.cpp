#include "project.h"        // project::MailSpec / processSource
#include "mail_config.h"    // pdfgen::MailConfig -- Absenderkonten
#include "mail_dispatch.h"  // pdfgen::sendMails
#include "pdfgen_host.h"    // Log-Sink + Pfad-Resolver fuer pdfgen
#include "ui_pages.h"
#include <string>
#include <vector>
#include <string_view>
#include <sstream>

#include "imgui.h"
#include "misc/cpp/imgui_stdlib.h"
#include "Utils.h"
#include "ui_files.h"
#include "ui_textstore.h"

// ===========================================================================
// ANBINDUNG pdfgen <-> x_bookmark_manager
// ---------------------------------------------------------------------------
// pdfgen kennt die App nicht. Die App haengt sich an drei Stellen ein:
//   1. Log:    pdfgen_set_log_sink       -> jede pdfgen-Meldung landet in
//                                           UIP_LOGF (Protokollfenster,
//                                           logcat, stdout)
//   2. Pfade:  pdfgen::setPathResolver   -> UiFilePath (Android-Basisordner)
//   3. Konten: pdfgen::setMailConfig     -> Absender aus den Seiten-
//                                           Einstellungen von "Bewerben"
// Standalone laufen dieselben Stellen ueber stderr, unveraenderte Pfade und
// pdfgen.conf. Kein #include aus der App in pdfgen.
// ===========================================================================
namespace {

// Die Konten liegen als Text im pdfgen.conf-Format im Textspeicher (xbm.ini).
// Ein Format fuer alles: pdfgen parst es, die App muss nichts selbst kodieren.
// BEWUSST NICHT in data/pdfgen/pdfgen.conf: dieser Ordner wird per
// "Push ins Projekt" nach Git geschoben -- Tokens gehoeren da nicht hin.
constexpr const char* kMailConfKey = "pdfgen.mailconf";

pdfgen::MailConfig KontenLaden() {
    pdfgen::MailConfig c;
    std::vector<std::string> w;
    pdfgen::parseMailConfig(UiTextGet(kMailConfKey), c, w);
    for (const auto& s : w) UIP_LOGF("pdfgen-Konten: Warnung: " + s);
    return c;
}

// Aktuellen Stand an pdfgen uebergeben. Wird nach jeder Aenderung in den
// Einstellungen UND vor jedem Lauf aufgerufen -- so sieht pdfgen immer
// die neuesten Konten, auch wenn xbm.ini erst nach BewerbenInit() geladen
// wurde (siehe main.cpp: BewerbenInit() steht VOR AppSettings::Load).
void KontenAnPdfgen() { pdfgen::setMailConfig(KontenLaden()); }

void PdfgenLog(int level, const char* msg, void*) {
    // Praefix so gewaehlt, dass ui_log.h (Raten) die Stufe erkennt.
    const char* p = level >= PDFGEN_LOG_ERROR ? "[pdfgen] Fehler: "
                  : level == PDFGEN_LOG_WARN  ? "[pdfgen] Warnung: "
                  :                             "[pdfgen] ";
    UipLog(std::string(p) + (msg ? msg : ""));
}

std::vector<std::string> SplitWs(const std::string& s) {
    std::vector<std::string> v;
    std::stringstream ss(s);
    std::string w;
    while (ss >> w) {
        while (!w.empty() && (w.back() == ',' || w.back() == ';')) w.pop_back();
        if (!w.empty()) v.push_back(w);
    }
    return v;
}

// ---- Seiten-Einstellungen "Bewerben": Absender verwalten -------------------
void MailAbsenderEinstellungen() {
    static pdfgen::MailConfig s_cfg;
    static std::string s_test;
    static bool s_geladen = false;
    if (!s_geladen) {
        s_cfg = KontenLaden();
        s_test.clear();
        for (const auto& t : s_cfg.testTo) s_test += (s_test.empty() ? "" : " ") + t;
        s_geladen = true;
    }
    bool geaendert = false;

    ImGui::TextUnformatted("Mail-Absender (pdfgen)");
    ImGui::TextDisabled("Auswahl in der Quelle: \\mail Name, to=..., from=adresse");

    int loeschen = -1;
    for (int i = 0; i < (int)s_cfg.accounts.size(); ++i) {
        pdfgen::MailAccount& a = s_cfg.accounts[i];
        ImGui::PushID(i);
        ImGui::SetNextItemWidth(-FLT_MIN);
        geaendert |= ImGui::InputTextWithHint("##adr", "E-Mail-Adresse", &a.address);
        ImGui::SetNextItemWidth(-FLT_MIN);
        geaendert |= ImGui::InputTextWithHint("##tok", "App-Passwort / Token", &a.token,
                                              ImGuiInputTextFlags_Password);
        if (ImGui::RadioButton("Standard", a.isDefault) && !a.isDefault) {
            for (auto& x : s_cfg.accounts) x.isDefault = false;
            a.isDefault = true;
            geaendert = true;
        }
        ImGui::SameLine();
        if (ImGui::SmallButton("Entfernen")) loeschen = i;
        ImGui::Separator();
        ImGui::PopID();
    }
    if (loeschen >= 0) {
        bool warDefault = s_cfg.accounts[loeschen].isDefault;
        s_cfg.accounts.erase(s_cfg.accounts.begin() + loeschen);
        if (warDefault && !s_cfg.accounts.empty()) s_cfg.accounts[0].isDefault = true;
        geaendert = true;
    }
    if (ImGui::Button("+ Absender hinzufuegen")) {
        pdfgen::MailAccount a;
        a.isDefault = s_cfg.accounts.empty();
        s_cfg.accounts.push_back(a);
        geaendert = true;
    }
    ImGui::SetNextItemWidth(-FLT_MIN);
    if (ImGui::InputTextWithHint("##testto", "Test-Empfaenger (fuer 'Testlauf')", &s_test)) {
        s_cfg.testTo = SplitWs(s_test);
        geaendert = true;
    }
    if (geaendert) {
        UiTextSet(kMailConfKey, pdfgen::formatMailConfig(s_cfg));
        UiTextPersistHook();
        KontenAnPdfgen();
    }
}

} // namespace

void BewerbenInit() {
  pdfgen_set_log_sink(&PdfgenLog, nullptr);
  pdfgen::setPathResolver([](const std::string& p) { return UiFilePath(p); });
  UiPageSettingsExtras()["Bewerben"] = &MailAbsenderEinstellungen;

  UiMailSender() = [](const std::vector<std::string_view>& sources,
                      const std::vector<std::string_view>& mailNames,
                      int mailMode, bool mailTest) -> bool {
  UIP_LOGF("UiMailSender bewerben.cpp");
  KontenAnPdfgen();                        // immer mit dem neuesten Stand
  std::vector<project::MailSpec> mails;
  std::vector<std::string> warnings;
  bool ok = true;
  // ---- WARNUNGEN VON pdfgen SICHTBAR MACHEN -----------------------
  // pdfgen sammelt in 'warnings' die Meldungen, die erklaeren, warum ein
  // Lauf nichts oder Leeres liefert. Sie gehen ins Protokoll UND in die
  // Statuszeile des Prototype-Fensters.
  auto ZeigeWarnungen = [&](const char* wo) {
    if (warnings.empty()) return;
    std::string zus;
    for (const auto& w : warnings) {
      UIP_LOGF(std::string("pdfgen-Warnung: ") + w);
      if (!zus.empty()) zus += " | ";
      zus += w;
    }
    UiTextSet("prototype.status",
              std::string(wo) + ": " + std::to_string(warnings.size())
              + " Warnung(en) -- " + zus);
    warnings.clear();
  };
  for (const auto& s : sources) {
    ok = project::processSource(std::string(s), mails, warnings) && ok;
    UIP_LOGF(std::string(s) + " processSource: " + (ok ? "ok" : "not ok"));
    ZeigeWarnungen("pdfgen");
  }
  if (mailMode) {
    std::vector<std::string> namen(mailNames.begin(), mailNames.end());
    const bool gesendet = pdfgen::sendMails(mails, namen, mailTest);
    ok = gesendet && ok;
    UiTextSet("prototype.status", gesendet
              ? std::string("Versand: ok")
              : std::string("Versand: Fehler -- Details im Protokoll"));
  }
  return ok;          // true = alles versendet
  };
}
