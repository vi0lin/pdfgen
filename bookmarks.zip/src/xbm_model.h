#pragma once
// ---------------------------------------------------------------------------
// xbm_model.h -- Sprachmodell zur LAUFZEIT holen, mit Auswahl und Fortschritt.
//
// WARUM NICHT MEHR BEIM BAUEN
// Der Bauzeit-Weg legte das Modell nach data/shared/models -- und alles
// darunter landet AUCH im APK. Mit ggml-base.bin waechst es um rund
// 148 MB, und Google Play nimmt als APK ohnehin nur 100 MB an. Ausserdem
// zwingt er jedem dieselbe Modellgroesse auf, auch wenn er gar nicht
// transkribieren will.
//
// Zur Laufzeit geholt heisst: das Programm bleibt klein, der Nutzer waehlt
// selbst, und wer es nicht braucht, laedt nichts.
//
// HEADER-ONLY, wie ui_log.h und ui_condbuttons.h -- kein Eintrag in die
// Quellenliste noetig. [Genau das ist bei ui_condbuttons schiefgegangen:
//  Linux und Windows brachen beim Linken ab, Android linkte klaglos und
//  stuerzte beim Start.]
//
// ZUM DATENSCHUTZ: Dies ist der EINZIGE Netzzugriff der Transkription --
// einmalig, ausdruecklich vom Nutzer ausgeloest, und es wird nur eine
// oeffentliche Datei geladen. Aufnahmen verlassen das Geraet nie; die
// Erkennung selbst laeuft danach vollstaendig auf der CPU.
// ---------------------------------------------------------------------------
#include "imgui.h"

#include <curl/curl.h>

#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

struct XbmModelEntry {
    const char* name;      // "tiny", "base", ...
    const char* file;      // "ggml-tiny.bin"
    int         mb;        // ungefaehre Groesse
    const char* hinweis;   // was man davon erwarten darf
};

// Reihenfolge = Anzeigereihenfolge. Bewusst ohne "large": ueber 3 GB ist
// auf einem Handy nicht sinnvoll und auf dem Schreibtisch eine eigene
// Entscheidung, die man dann von Hand trifft.
inline const std::vector<XbmModelEntry>& XbmModel_List() {
    static const std::vector<XbmModelEntry> v = {
        { "tiny",   "ggml-tiny.bin",    75, "schnell, ungenau -- fuer kurze Notizen" },
        { "base",   "ggml-base.bin",   148, "guter Ausgleich, empfohlen" },
        { "small",  "ggml-small.bin",  466, "deutlich genauer, spuerbar langsamer" },
        { "medium", "ggml-medium.bin",1500, "sehr genau, braucht Zeit und Speicher" },
    };
    return v;
}

namespace xbm_model_detail {

struct State {
    std::atomic<bool>          laeuft{false};
    std::atomic<bool>          abbrechen{false};
    std::atomic<long long>     geladen{0};
    std::atomic<long long>     gesamt{0};
    std::atomic<double>        tempo{0.0};    // Byte je Sekunde
    std::atomic<long long>     start{0};      // schon vorhandene Bytes
    std::mutex                 mtx;
    std::string                meldung;
    std::string                zielDir;      // wohin gespeichert wird
    std::string                aktuellName;  // welches Modell gerade laeuft
    std::thread                worker;
    bool                       fertigFlag = false;
};
inline State& S() { static State s; return s; }

inline void SetzeMeldung(const std::string& m) {
    std::lock_guard<std::mutex> lk(S().mtx);
    S().meldung = m;
}

inline std::size_t Schreiben(char* p, std::size_t gr, std::size_t n, void* ud) {
    std::FILE* f = (std::FILE*)ud;
    return std::fwrite(p, gr, n, f);
}

// Fortschritt + Abbruch. Ein Rueckgabewert ungleich 0 bricht curl ab.
inline int Fortschritt(void* ud, curl_off_t dlTotal, curl_off_t dlNow,
                       curl_off_t, curl_off_t) {
    // Beim WIEDERAUFNEHMEN zaehlt curl nur die NEUEN Bytes -- die schon
    // vorhandenen dazurechnen, sonst springt die Anzeige zurueck.
    const long long vorhanden = S().start.load(std::memory_order_relaxed);
    S().gesamt.store((long long)dlTotal + vorhanden, std::memory_order_relaxed);
    S().geladen.store((long long)dlNow + vorhanden,  std::memory_order_relaxed);
    if (CURL* c = (CURL*)ud) {
        curl_off_t v = 0;
        if (curl_easy_getinfo(c, CURLINFO_SPEED_DOWNLOAD_T, &v) == CURLE_OK)
            S().tempo.store((double)v, std::memory_order_relaxed);
    }
    return S().abbrechen.load(std::memory_order_relaxed) ? 1 : 0;
}

// Ein einzelner Versuch. Rueckgabe: CURLE_OK oder der Fehlercode.
inline CURLcode EinVersuch(const std::string& url, const std::string& teilPfad);
inline void NachDemLauf(CURLcode r, const std::string& zielPfad,
                        const std::string& teilPfad, long long minBytes);

inline void Lauf(std::string url, std::string zielPfad, std::string teilPfad,
                 long long minBytes) {
    // MEHRERE VERSUCHE.
    // [Auf dem Handy sind "SSL connect error" und abgerissene Verbindungen
    //  meist voruebergehend -- Funkzellenwechsel, schlafende Verbindung,
    //  ueberlastetes Gegenueber. Beim ersten Fehler aufzugeben zwingt den
    //  Nutzer, von Hand neu anzustossen, und bei 3 kB/s ist das bitter.
    //  Dank Fortsetzen kostet ein weiterer Versuch nichts: er macht dort
    //  weiter, wo abgebrochen wurde.]
    const int kVersuche = 4;
    CURLcode letzter = CURLE_OK;
    for (int v = 1; v <= kVersuche; ++v) {
        if (S().abbrechen.load()) break;
        if (v > 1) {
            SetzeMeldung("Versuch " + std::to_string(v) + " von "
                         + std::to_string(kVersuche) + "...");
            // Kurz warten, aber auf Abbruch achten.
            for (int i = 0; i < 20 && !S().abbrechen.load(); ++i)
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        letzter = EinVersuch(url, teilPfad);
        if (letzter == CURLE_OK) break;
        if (S().abbrechen.load()) break;
    }
    NachDemLauf(letzter, zielPfad, teilPfad, minBytes);
}

inline CURLcode EinVersuch(const std::string& url, const std::string& teilPfad) {
    SetzeMeldung("verbinde...");
    CURL* c = curl_easy_init();
    if (!c) {
        SetzeMeldung("curl konnte nicht gestartet werden");
        return CURLE_FAILED_INIT;
    }
    // WIEDERAUFNEHMEN: liegt schon ein Teilstueck, dort weitermachen.
    // [Bei 3 kB/s -- so langsam laedt es auf dem Handy -- braucht ein
    //  75-MB-Modell Stunden. Jeder Abbruch von vorn zu beginnen ist dann
    //  keine Option. curl kann per HTTP-Range fortsetzen; der Server muss
    //  es unterstuetzen, HuggingFace tut das.]
    long long schon = 0;
    if (std::FILE* t = std::fopen(teilPfad.c_str(), "rb")) {
        std::fseek(t, 0, SEEK_END);
        schon = (long long)std::ftell(t);
        std::fclose(t);
    }
    S().start.store(schon);
    std::FILE* f = std::fopen(teilPfad.c_str(), schon > 0 ? "ab" : "wb");
    if (!f) {
        SetzeMeldung("kann nicht schreiben: " + teilPfad);
        curl_easy_cleanup(c);
        return CURLE_WRITE_ERROR;
    }
    curl_easy_setopt(c, CURLOPT_URL, url.c_str());
    curl_easy_setopt(c, CURLOPT_FOLLOWLOCATION, 1L);   // HuggingFace leitet um
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, Schreiben);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, (void*)f);
    curl_easy_setopt(c, CURLOPT_NOPROGRESS, 0L);
    curl_easy_setopt(c, CURLOPT_XFERINFOFUNCTION, Fortschritt);
    curl_easy_setopt(c, CURLOPT_XFERINFODATA, (void*)c);
    // Groesserer Puffer: bei langsamen Verbindungen weniger Systemaufrufe.
    curl_easy_setopt(c, CURLOPT_BUFFERSIZE, 262144L);
    if (schon > 0) {
        curl_easy_setopt(c, CURLOPT_RESUME_FROM_LARGE, (curl_off_t)schon);
        SetzeMeldung("setze fort bei " + std::to_string(schon / (1024 * 1024))
                     + " MB");
    }
    curl_easy_setopt(c, CURLOPT_FAILONERROR, 1L);
    curl_easy_setopt(c, CURLOPT_CONNECTTIMEOUT, 30L);
    // KEIN Gesamt-Zeitlimit: ein Modell ueber eine langsame Leitung darf
    // Stunden dauern. Stattdessen ein Riegel gegen STEHENGEBLIEBENE
    // Verbindungen -- weniger als 1 kB/s ueber 60 s gilt als tot.
    curl_easy_setopt(c, CURLOPT_LOW_SPEED_LIMIT, 1024L);
    curl_easy_setopt(c, CURLOPT_LOW_SPEED_TIME, 60L);
    SetzeMeldung("laedt...");
    const CURLcode r = curl_easy_perform(c);
    std::fclose(f);
    curl_easy_cleanup(c);
    return r;
}

// Auswertung NACH allen Versuchen.
inline void NachDemLauf(CURLcode r, const std::string& zielPfad,
                        const std::string& teilPfad, long long minBytes) {
    if (S().abbrechen.load()) {
        // Teilstueck BEHALTEN -- der naechste Versuch setzt dort fort.
        SetzeMeldung("angehalten -- erneutes Laden setzt fort");
        S().laeuft.store(false);
        return;
    }
    if (r != CURLE_OK) {
        // Nur wegwerfen, wenn kaum etwas ankam -- sonst laesst sich
        // fortsetzen. [Ein SSL-Fehler nach 30 MB soll nicht 30 MB
        //  vernichten.]
        long long da2 = 0;
        if (std::FILE* g2 = std::fopen(teilPfad.c_str(), "rb")) {
            std::fseek(g2, 0, SEEK_END); da2 = (long long)std::ftell(g2);
            std::fclose(g2);
        }
        if (da2 < 1024 * 1024) std::remove(teilPfad.c_str());
        SetzeMeldung(std::string("fehlgeschlagen: ") + curl_easy_strerror(r)
                     + (da2 >= 1024 * 1024
                        ? "  -- erneutes Laden setzt fort" : ""));
        S().laeuft.store(false);
        return;
    }
    // GROESSE PRUEFEN, bevor umbenannt wird.
    // [Ohne das bliebe eine HTML-Fehlerseite unter dem Namen der
    //  Modelldatei liegen -- und die Suche haette sie fuer gueltig
    //  gehalten. Erst nach der Pruefung bekommt sie den richtigen Namen.]
    long long gr = 0;
    if (std::FILE* g = std::fopen(teilPfad.c_str(), "rb")) {
        std::fseek(g, 0, SEEK_END);
        gr = (long long)std::ftell(g);
        std::fclose(g);
    }
    if (gr < minBytes) {
        std::remove(teilPfad.c_str());
        char m[160];
        std::snprintf(m, sizeof(m),
                      "Datei zu klein (%lld Byte) -- vermutlich eine "
                      "Fehlerseite statt des Modells", gr);
        SetzeMeldung(m);
        S().laeuft.store(false);
        return;
    }
    std::remove(zielPfad.c_str());
    if (std::rename(teilPfad.c_str(), zielPfad.c_str()) != 0) {
        SetzeMeldung("konnte nicht umbenennen: " + zielPfad);
        S().laeuft.store(false);
        return;
    }
    SetzeMeldung("fertig: " + zielPfad);
    {
        std::lock_guard<std::mutex> lk(S().mtx);
        S().fertigFlag = true;
    }
    S().laeuft.store(false);
}

}  // namespace xbm_model_detail

// --- Steuerung ---------------------------------------------------------------
inline bool XbmModel_Busy() { return xbm_model_detail::S().laeuft.load(); }

inline float XbmModel_Progress() {
    const long long g = xbm_model_detail::S().gesamt.load();
    const long long n = xbm_model_detail::S().geladen.load();
    if (g <= 0) return 0.0f;
    const float p = (float)n / (float)g;
    return p < 0.0f ? 0.0f : (p > 1.0f ? 1.0f : p);
}
inline long long XbmModel_LoadedBytes() { return xbm_model_detail::S().geladen.load(); }
inline long long XbmModel_TotalBytes()  { return xbm_model_detail::S().gesamt.load(); }

inline std::string XbmModel_Message() {
    std::lock_guard<std::mutex> lk(xbm_model_detail::S().mtx);
    return xbm_model_detail::S().meldung;
}
// Einmal true, nachdem ein Download fertig wurde -- der Aufrufer kann
// damit die Modellsuche neu anstossen.
inline bool XbmModel_TakeFinished() {
    std::lock_guard<std::mutex> lk(xbm_model_detail::S().mtx);
    const bool f = xbm_model_detail::S().fertigFlag;
    xbm_model_detail::S().fertigFlag = false;
    return f;
}
inline void XbmModel_Cancel() { xbm_model_detail::S().abbrechen.store(true); }

inline void XbmModel_Shutdown() {
    XbmModel_Cancel();
    if (xbm_model_detail::S().worker.joinable())
        xbm_model_detail::S().worker.join();
}

// zielDir: Ordner, in den gespeichert wird (z.B. der Datenordner der App).
inline bool XbmModel_Start(const std::string& name, const std::string& zielDir) {
    using namespace xbm_model_detail;
    if (S().laeuft.load()) return false;
    const XbmModelEntry* e = nullptr;
    for (const auto& x : XbmModel_List())
        if (name == x.name) { e = &x; break; }
    if (!e) return false;

    if (S().worker.joinable()) S().worker.join();   // vorigen Lauf abraeumen
    S().abbrechen.store(false);
    S().geladen.store(0);
    S().gesamt.store(0);
    S().zielDir = zielDir;
    S().aktuellName = e->name;
    S().laeuft.store(true);

    const std::string ziel = zielDir + "/" + e->file;
    const std::string teil = ziel + ".teil";
    const std::string url  =
        std::string("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/")
        + e->file;
    // Untergrenze grosszuegig: 60 % der NennGroesse. Sie soll Fehlerseiten
    // abfangen, nicht knapp danebenliegende Modellfassungen ablehnen.
    const long long minB = (long long)e->mb * 1024 * 1024 * 6 / 10;
    S().worker = std::thread(Lauf, url, ziel, teil, minB);
    return true;
}

// --- Oberflaeche -------------------------------------------------------------
// Zeichnet die Auswahl. installiert(name) meldet, welche Modelle schon da
// sind -- damit die Liste zeigt, was bereits vorliegt.
inline double XbmModel_SpeedBps() {
    return xbm_model_detail::S().tempo.load(std::memory_order_relaxed);
}

// zielDir     Ordner, in dem die Modelle liegen
// installiert meldet, ob eine Datei schon da ist
// gewaehlt    aktuell benutztes Modell (Dateiname), leer = automatisch
// waehlen     wird gerufen, wenn der Nutzer eines auswaehlt
// loeschen    wird gerufen, wenn der Nutzer eines entfernt
inline void XbmModel_DrawUi(const std::string& zielDir,
                            bool (*installiert)(const char* datei),
                            const std::string& gewaehlt = std::string(),
                            void (*waehlen)(const std::string&) = nullptr,
                            bool (*loeschen)(const std::string&) = nullptr) {
    ImGui::TextUnformatted("Sprachmodell fuer die Transkription");
    ImGui::TextDisabled(
        "Einmaliger Download. Danach laeuft die Erkennung vollstaendig\n"
        "auf diesem Geraet -- Aufnahmen werden nie verschickt.");
    ImGui::Separator();

    const float fh = ImGui::GetFrameHeight();
    for (const auto& e : XbmModel_List()) {
        ImGui::PushID(e.name);
        const bool da  = installiert && installiert(e.file);
        const bool ist = da && (gewaehlt == e.file);

        // VORHANDENE Modelle sind auswaehlbar, fehlende ladbar.
        // [Vorher stand bei vorhandenen nur "vorhanden" -- unanklickbar.
        //  Damit liess sich weder wechseln noch etwas entfernen, und der
        //  ganze Knopf verschwand, sobald EIN Modell da war.]
        if (da) {
            if (ImGui::RadioButton("##wahl", ist) && waehlen) waehlen(e.file);
            ImGui::SetItemTooltip("dieses Modell benutzen");
        } else {
            ImGui::BeginDisabled(XbmModel_Busy());
            if (ImGui::Button("Laden", ImVec2(fh * 3.2f, fh)))
                XbmModel_Start(e.name, zielDir);
            ImGui::EndDisabled();
        }
        ImGui::SameLine();
        if (ist) ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(120, 220, 140, 255));
        ImGui::Text("%-7s  %5d MB", e.name, e.mb);
        if (ist) ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::TextDisabled("%s", e.hinweis);
        if (da && loeschen) {
            ImGui::SameLine();
            if (ImGui::SmallButton("Loeschen")) loeschen(e.file);
            ImGui::SetItemTooltip("Datei entfernen und Platz freigeben");
        }
        ImGui::PopID();
    }

    if (XbmModel_Busy()) {
        ImGui::Separator();
        const long long n = XbmModel_LoadedBytes();
        const long long g = XbmModel_TotalBytes();
        const double    v = XbmModel_SpeedBps();
        char txt[160];
        if (g > 0) {
            // TEMPO UND RESTZEIT mit anzeigen. [Ein Balken, der sich kaum
            //  bewegt, sagt nicht, ob es langsam laeuft oder haengt.]
            const double rest = (v > 1.0) ? (double)(g - n) / v : -1.0;
            if (rest >= 0.0)
                std::snprintf(txt, sizeof(txt),
                              "%lld / %lld MB   %.0f kB/s   noch ~%d min",
                              n / (1024 * 1024), g / (1024 * 1024),
                              v / 1024.0, (int)(rest / 60.0 + 0.5));
            else
                std::snprintf(txt, sizeof(txt), "%lld / %lld MB",
                              n / (1024 * 1024), g / (1024 * 1024));
        } else {
            std::snprintf(txt, sizeof(txt), "%lld MB", n / (1024 * 1024));
        }
        ImGui::ProgressBar(XbmModel_Progress(), ImVec2(-1, fh), txt);
        if (ImGui::Button("Anhalten")) XbmModel_Cancel();
        ImGui::SameLine();
        ImGui::TextDisabled("%s", XbmModel_Message().c_str());
        ImGui::TextDisabled(
            "Anhalten ist gefahrlos: das Teilstueck bleibt erhalten,\n"
            "ein erneutes Laden setzt dort fort.");
    } else {
        const std::string m = XbmModel_Message();
        if (!m.empty()) {
            ImGui::Separator();
            ImGui::TextWrapped("%s", m.c_str());
        }
    }
}
