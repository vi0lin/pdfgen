// x_client.cpp

#include "x_client.h"

#include <curl/curl.h>
#include "curl_android_ca.h"   // Android: CA-Pfad
#if defined(__ANDROID__)
#include <android/log.h>
static int curl_debug_cb(CURL*, curl_infotype type, char* data, size_t size, void*) {
    if (type == CURLINFO_TEXT) {
        __android_log_print(ANDROID_LOG_INFO, "XBookmarks", "curl: %.*s",
                            (int)size, data);
    }
    return 0;
}
#endif
#include <nlohmann/json.hpp>

#include <stdexcept>
#include <sstream>
#include <thread>
#include <chrono>

using json = nlohmann::json;

// This is X's public web-client bearer token, used by the website itself
// for every logged-out AND logged-in request. It's not a secret tied to
// any account; it's hardcoded into x.com's own JS bundle.
static const char* kBearerToken =
    "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D"
    "1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";

// NOTE: X changes these GraphQL queryId hashes periodically whenever they
// ship a frontend update. If requests start failing or returning empty
// results, grab fresh IDs from your browser's Network tab (filter by
// "Bookmarks" / "DeleteBookmark") and update these two constants.
// See the README for exact steps.
static const char* kBookmarksQueryId = "tUVliYsHyxrQIT4HXUWNdA";
static const char* kDeleteBookmarkQueryId = "Wlmlj2-xzyS1GN3a6cj-mQ";

static const char* kGraphqlBase = "https://x.com/i/api/graphql";

namespace {

// libcurl write callback: appends received bytes to a std::string buffer.
size_t write_callback(char* ptr, size_t size, size_t nmemb, void* userdata) {
    auto* out = static_cast<std::string*>(userdata);
    out->append(ptr, size * nmemb);
    return size * nmemb;
}

// URL-encodes a string (for query parameters). Uses curl's own escaper so
// behavior matches what the server expects.
std::string url_encode(CURL* curl, const std::string& value) {
    char* escaped = curl_easy_escape(curl, value.c_str(), static_cast<int>(value.size()));
    std::string result = escaped ? escaped : "";
    if (escaped) curl_free(escaped);
    return result;
}

// The "features" flag blob the Bookmarks endpoint expects. Mirrors what
// x.com's own web client sends as of this writing. If the bookmarks
// endpoint starts returning 400 errors, copy the current "features" JSON
// straight from your browser's Network tab for the same request and
// paste it in here.
json bookmarks_features() {
    return json{
        {"rweb_video_screen_enabled", false},
        {"payments_enabled", false},
        {"rweb_xchat_enabled", false},
        {"profile_label_improvements_pcf_label_in_post_enabled", true},
        {"rweb_tipjar_consumption_enabled", true},
        {"verified_phone_label_enabled", false},
        {"creator_subscriptions_tweet_preview_api_enabled", true},
        {"responsive_web_graphql_timeline_navigation_enabled", true},
        {"responsive_web_graphql_skip_user_profile_image_extensions_enabled", false},
        {"premium_content_api_read_enabled", false},
        {"communities_web_enable_tweet_community_results_fetch", true},
        {"c9s_tweet_anatomy_moderator_badge_enabled", true},
        {"responsive_web_grok_analyze_button_fetch_trends_enabled", false},
        {"responsive_web_grok_analyze_post_followups_enabled", false},
        {"responsive_web_jetfuel_frame", false},
        {"responsive_web_grok_share_attachment_enabled", true},
        {"articles_preview_enabled", true},
        {"responsive_web_edit_tweet_api_enabled", true},
        {"graphql_is_translatable_rweb_tweet_is_translatable_enabled", true},
        {"view_counts_everywhere_api_enabled", true},
        {"longform_notetweets_consumption_enabled", true},
        {"responsive_web_twitter_article_tweet_consumption_enabled", true},
        {"tweet_awards_web_tipping_enabled", false},
        {"responsive_web_grok_show_grok_translated_post", false},
        {"responsive_web_grok_analysis_button_from_backend", false},
        {"creator_subscriptions_quote_tweet_preview_enabled", false},
        {"freedom_of_speech_not_reach_fetch_enabled", true},
        {"standardized_nudges_misinfo", true},
        {"tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled", true},
        {"rweb_video_timestamps_enabled", true},
        {"longform_notetweets_rich_text_read_enabled", true},
        {"longform_notetweets_inline_media_enabled", true},
        {"responsive_web_grok_image_annotation_enabled", true},
        {"responsive_web_enhance_cards_enabled", false},
    };
}

// Safely walks a nested JSON path, returning a null json if any step is
// missing -- mirrors the forgiving dict.get() chaining the Python version
// relied on, since X's response shape has optional/nested fields.
const json& jget(const json& obj, const char* key) {
    static const json kNull = nullptr;
    if (!obj.is_object()) return kNull;
    auto it = obj.find(key);
    if (it == obj.end()) return kNull;
    return it.value();
}

std::string jstr(const json& obj, const char* key, const std::string& fallback = "") {
    const json& v = jget(obj, key);
    if (v.is_string()) return v.get<std::string>();
    return fallback;
}

}  // namespace

XClient::XClient(std::string auth_token, std::string ct0)
    : auth_token_(std::move(auth_token)), ct0_(std::move(ct0)) {
    curl_global_init(CURL_GLOBAL_DEFAULT);
}

XClient::~XClient() {
    curl_global_cleanup();
}

std::string XClient::http_get(const std::string& url) {
    CURL* curl = curl_easy_init();
    ApplyAndroidCaPath(curl);
    if (!curl) throw std::runtime_error("Failed to init curl");

    std::string response_body;
    long status_code = 0;

    std::string cookie_header = "Cookie: auth_token=" + auth_token_ + "; ct0=" + ct0_;
    std::string csrf_header = "x-csrf-token: " + ct0_;
    std::string auth_header = "authorization: Bearer " + std::string(kBearerToken);

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, cookie_header.c_str());
    headers = curl_slist_append(headers, csrf_header.c_str());
    headers = curl_slist_append(headers, auth_header.c_str());
    headers = curl_slist_append(headers, "x-twitter-auth-type: OAuth2Session");
    headers = curl_slist_append(headers, "x-twitter-active-user: yes");
    headers = curl_slist_append(headers, "x-twitter-client-language: en");
    headers = curl_slist_append(headers, "content-type: application/json");
    headers = curl_slist_append(headers, "referer: https://x.com/i/bookmarks");
    headers = curl_slist_append(
        headers,
        "user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    );

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_body);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 20L);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);

    char errbuf[CURL_ERROR_SIZE] = {0};
    curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, errbuf);
#if defined(__ANDROID__)
    curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
    curl_easy_setopt(curl, CURLOPT_DEBUGFUNCTION, curl_debug_cb);
#endif

    CURLcode res = curl_easy_perform(curl);
    if (res == CURLE_OK) {
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status_code);
    }
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) {
        // errbuf enthaelt die konkrete mbedTLS/curl-Detailmeldung
        // (z.B. welcher Handshake-Schritt scheiterte) -- deutlich
        // aussagekraeftiger als der generische strerror-Text.
        std::string detail = errbuf[0] ? errbuf : curl_easy_strerror(res);
        throw std::runtime_error("curl GET failed: " + detail);
    }
    if (status_code != 200) {
        throw std::runtime_error(
            "GET " + url + " failed: HTTP " + std::to_string(status_code) +
            " body: " + response_body.substr(0, 500)
        );
    }
    return response_body;
}

std::string XClient::http_post_json(const std::string& url, const std::string& json_body) {
    CURL* curl = curl_easy_init();
    ApplyAndroidCaPath(curl);
    if (!curl) throw std::runtime_error("Failed to init curl");

    std::string response_body;
    long status_code = 0;

    std::string cookie_header = "Cookie: auth_token=" + auth_token_ + "; ct0=" + ct0_;
    std::string csrf_header = "x-csrf-token: " + ct0_;
    std::string auth_header = "authorization: Bearer " + std::string(kBearerToken);

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, cookie_header.c_str());
    headers = curl_slist_append(headers, csrf_header.c_str());
    headers = curl_slist_append(headers, auth_header.c_str());
    headers = curl_slist_append(headers, "x-twitter-auth-type: OAuth2Session");
    headers = curl_slist_append(headers, "x-twitter-active-user: yes");
    headers = curl_slist_append(headers, "content-type: application/json");
    headers = curl_slist_append(headers, "referer: https://x.com/i/bookmarks");

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, json_body.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_body);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 15L);

    char errbuf[CURL_ERROR_SIZE] = {0};
    curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, errbuf);
#if defined(__ANDROID__)
    curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
    curl_easy_setopt(curl, CURLOPT_DEBUGFUNCTION, curl_debug_cb);
#endif

    CURLcode res = curl_easy_perform(curl);
    if (res == CURLE_OK) {
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status_code);
    }
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) {
        std::string detail = errbuf[0] ? errbuf : curl_easy_strerror(res);
        throw std::runtime_error("curl POST failed: " + detail);
    }
    if (status_code != 200) {
        return "";  // caller treats empty as failure for delete_bookmark
    }
    return response_body;
}

bool XClient::verify_credentials() {
    try {
        http_get("https://api.x.com/1.1/account/verify_credentials.json");
        return true;
    } catch (...) {
        return false;
    }
}

std::vector<Tweet> XClient::fetch_bookmarks_page(const std::string& cursor, std::string& next_cursor, int count) {
    CURL* curl = curl_easy_init();  // only used here for its escaper
    ApplyAndroidCaPath(curl);
    if (!curl) throw std::runtime_error("Failed to init curl");

    json variables = {
        {"count", count},
        {"includePromotedContent", false},
    };
    if (!cursor.empty()) {
        variables["cursor"] = cursor;
    }

    std::string variables_str = url_encode(curl, variables.dump());
    std::string features_str = url_encode(curl, bookmarks_features().dump());
    curl_easy_cleanup(curl);

    std::string url = std::string(kGraphqlBase) + "/" + kBookmarksQueryId + "/Bookmarks"
                       + "?variables=" + variables_str + "&features=" + features_str;

    std::string body = http_get(url);
    return parse_bookmarks_page(body, next_cursor);
}

std::vector<Tweet> XClient::parse_bookmarks_page(const std::string& json_text, std::string& next_cursor) {
    std::vector<Tweet> tweets;
    next_cursor.clear();

    json data;
    try {
        data = json::parse(json_text);
    } catch (const json::parse_error&) {
        return tweets;  // not valid JSON -- caller sees an empty page
    }

    const json& instructions = jget(jget(jget(jget(data, "data"), "bookmark_timeline_v2"), "timeline"), "instructions");
    if (!instructions.is_array()) return tweets;

    for (const auto& instr : instructions) {
        const json& entries = jget(instr, "entries");
        if (!entries.is_array()) continue;

        for (const auto& entry : entries) {
            std::string entry_id = jstr(entry, "entryId");
            const json& content = jget(entry, "content");

            if (entry_id.rfind("cursor-bottom", 0) == 0) {
                const json& value = jget(content, "value");
                if (value.is_string()) next_cursor = value.get<std::string>();
                continue;
            }

            const json& item = jget(content, "itemContent");
            json tweet_results = jget(jget(item, "tweet_results"), "result");
            if (tweet_results.is_null()) continue;

            if (jstr(tweet_results, "__typename") == "TweetWithVisibilityResults") {
                tweet_results = jget(tweet_results, "tweet");
            }

            const json& legacy = jget(tweet_results, "legacy");
            if (!legacy.is_object()) continue;

            std::string tweet_id = jstr(legacy, "id_str");
            if (tweet_id.empty()) tweet_id = jstr(tweet_results, "rest_id");
            if (tweet_id.empty()) continue;

            const json& user_legacy = jget(jget(jget(tweet_results, "core"), "user_results"), "result");
            const json& user_legacy_inner = jget(user_legacy, "legacy");
            std::string author_name = jstr(user_legacy_inner, "name", "unknown");
            std::string author_handle = jstr(user_legacy_inner, "screen_name", "unknown");

            std::optional<std::string> thumb_url;
            std::optional<std::string> media_type;

            json media_list = jget(jget(legacy, "extended_entities"), "media");
            if (!media_list.is_array() || media_list.empty()) {
                media_list = jget(jget(legacy, "entities"), "media");
            }
            if (media_list.is_array() && !media_list.empty()) {
                const json& m = media_list[0];
                std::string mt = jstr(m, "type");
                if (!mt.empty()) media_type = mt;
                if (mt == "photo") {
                    std::string base = jstr(m, "media_url_https");
                    if (!base.empty()) thumb_url = base + "?format=jpg&name=small";
                } else {
                    std::string base = jstr(m, "media_url_https");
                    if (!base.empty()) thumb_url = base;
                }
            }

            Tweet tweet;
            tweet.id = tweet_id;
            tweet.text = jstr(legacy, "full_text");
            tweet.author_name = author_name;
            tweet.author_handle = author_handle;
            tweet.created_at = jstr(legacy, "created_at");
            tweet.thumb_url = thumb_url;
            tweet.media_type = media_type;
            tweet.url = "https://x.com/" + author_handle + "/status/" + tweet_id;
            tweets.push_back(std::move(tweet));
        }
    }

    return tweets;
}

bool XClient::delete_bookmark(const std::string& tweet_id) {
    std::string url = std::string(kGraphqlBase) + "/" + kDeleteBookmarkQueryId + "/DeleteBookmark";
    json payload = {
        {"variables", {{"tweet_id", tweet_id}}},
        {"queryId", kDeleteBookmarkQueryId},
    };
    std::string response = http_post_json(url, payload.dump());
    if (response.empty()) return false;

    try {
        json data = json::parse(response);
        const json& result = jget(jget(data, "data"), "tweet_bookmark_delete");
        return !result.is_null() && result != false;
    } catch (...) {
        return false;
    }
}

void XClient::fetch_all_bookmarks(
    const std::function<void(const std::vector<Tweet>&)>& on_page,
    const std::function<bool()>& should_stop,
    int max_pages,
    int page_size
) {
    std::string cursor;
    for (int i = 0; i < max_pages; ++i) {
        if (should_stop()) return;

        std::string next_cursor;
        std::vector<Tweet> tweets = fetch_bookmarks_page(cursor, next_cursor, page_size);
        on_page(tweets);

        if (next_cursor.empty() || tweets.empty()) return;
        cursor = next_cursor;

        std::this_thread::sleep_for(std::chrono::milliseconds(600));  // be polite, avoid rate limiting
    }
}
