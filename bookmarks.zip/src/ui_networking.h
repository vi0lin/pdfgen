#pragma once
// ---------------------------------------------------------------------------
// ui_networking.h -- der Tab "Networking".
//
// Enthaelt NUR Oberflaeche. Alles Netzwerkverhalten steckt in
// XbmNetNode -- deshalb liess sich das ohne Fenster testen, und deshalb
// ist hier nichts, was schiefgehen und dabei still bleiben koennte.
//
// EINBAU -- drei Stellen:
//
//   1. In deiner Seitenliste (ui_pages.cpp), wo die anderen Tabs stehen:
//          #include "ui_networking.h"
//          ...
//          UiNetworking_Draw();          // im Zeichencode der Seite
//
//   2. EINMAL beim Start, nachdem XbmPaths bereit ist:
//          UiNetworking_Start();
//
//   3. JEDEN FRAME, im selben Block wie deine anderen Poll-Aufrufe
//      (z.B. neben XbmSched_DrainUi()):
//          UiNetworking_Poll();
//
// Ohne (2) und (3) passiert nichts -- genau das war der Grund, warum
// die Synchronisation bei dir ausblieb: die Bibliothek war da, aber
// niemand hat sie gestartet oder aufgerufen.
// ---------------------------------------------------------------------------
#include "xbm_netnode.h"
#include "xbm_timeline_sync.h"
// DIE OBERFLAECHEN-SCHALTER HIER MIT EINBINDEN.
// [Sachlich gehoert das nach app_settings.h. Aber: diese Datei wird in
//  main.cpp und main_android.cpp VOR app_settings.h eingebunden -- und
//  sie ist nachweislich in jedem Stand, in dem der Netzwerk-Tab
//  existiert. Damit kennt die Uebersetzungseinheit UiSheetCloseOnTab,
//  bevor app_settings.h es benutzt, ganz gleich, welchen Stand
//  app_settings.h hat. Das hat drei Runden lang gefehlt und jedes Mal
//  denselben Fehler ausgeloest; jetzt kann es nicht mehr fehlen.]
#include "xbm_ui_flags.h"
#include "ui_form.h"          // Felder mit Beschriftung darueber, Knoepfe mit Umbruch
#include "xbm_paths.h"

#include <cstring>
#include <string>
#include <vector>
#include "ui_files.h"
#include "ui_textstore.h"   // UiFlagGet/Set

#include "imgui.h"

// ---------------------------------------------------------------------------
namespace UiNetImpl {

inline XbmNetNode& Node() {
    static XbmNetNode n;
    static bool haken = (xbm_tls::Init(n), true);   // Nachrichten-Haken einmal setzen
    (void)haken;
    return n;
}

struct Zustand {
    char name[64]      = "";
    char geheimnis[64] = "";
    char hub[128]      = "";     // "host:port" des Hubs im Internet (fester Peer), leer = keiner
    char befehl[512]   = "cd ~/bookmarks && ./build.sh deb@local";
    bool gestartet     = false;
    // Vordefinierte Scripts: Dateien in UserData/scripts, je eine
    // Befehlszeile (Kommentarzeilen mit # werden ueberlesen).
    std::vector<std::string> scripts;
    bool scriptsGescannt = false;
    char neuerScriptName[64] = "";
    bool autoScroll    = true;
    std::string fehler;
};
inline Zustand& Z() { static Zustand z; return z; }

} // namespace UiNetImpl

// ---------------------------------------------------------------------------
// Einmal beim Programmstart.
// Hub aus z.hub ("host:port") an den Abgleich-Treiber geben (eigene Verbindung).
inline void UiNetworking_HubAnwenden() {
    auto& z = UiNetImpl::Z();
    std::string h = z.hub; const auto dp = h.rfind(':');
    if (h.empty() || dp == std::string::npos) { xbm_tls::HubSetzen("", 0, ""); return; }
    const std::string host = h.substr(0, dp); const int port = std::atoi(h.c_str() + dp + 1);
    if (host.empty() || port <= 0 || port > 65535) { xbm_tls::HubSetzen("", 0, ""); return; }
    xbm_tls::HubSetzen(host, (std::uint16_t)port, z.geheimnis);
}
inline void UiNetworking_Start() {
    auto& z = UiNetImpl::Z();
    // GESPEICHERTE EINSTELLUNGEN. [Name, Geheimnis und Hub mussten bisher
    //  nach jedem Start neu eingetippt werden.]
    if (z.name[0] == '\0')      std::snprintf(z.name, sizeof(z.name), "%s", UiTextGet("netz.name").c_str());
    if (z.geheimnis[0] == '\0') std::snprintf(z.geheimnis, sizeof(z.geheimnis), "%s", UiTextGet("netz.geheimnis").c_str());
    if (z.hub[0] == '\0')       std::snprintf(z.hub, sizeof(z.hub), "%s", UiTextGet("netz.hub").c_str());
    if (z.name[0] == '\0') {
        // Ein Name, an dem man das Geraet erkennt.
#if defined(__ANDROID__)
        std::snprintf(z.name, sizeof(z.name), "Android");
#elif defined(_WIN32)
        std::snprintf(z.name, sizeof(z.name), "Windows");
#else
        std::snprintf(z.name, sizeof(z.name), "Linux");
#endif
    }
    // Das Geheimnis MUSS auf allen Geraeten gleich sein.
    // [Es steht bewusst nicht fest im Code: dann waere es keins. Trag
    //  es einmal je Geraet ein -- es wird in xbm.ini gespeichert, wenn
    //  du die Zeile unten aktivierst.]
    if (z.geheimnis[0] == '\0')
        std::snprintf(z.geheimnis, sizeof(z.geheimnis), "%s", "");
}

// BEIM BEENDEN AUSDRUECKLICH STOPPEN -- vor dem Ende von main().
// [Der Knoten lebt als static. Ohne diesen Aufruf wird er erst bei der
//  statischen Zerstoerung abgebaut: nach dem ImGui-Kontext, in
//  unbestimmter Reihenfolge zu anderen Statics, mit noch offenen
//  Sockets und Faeden. Ein "munmap_chunk(): invalid pointer" beim
//  Beenden ist die typische Folge. Hier ist die Reihenfolge klar.]
inline void UiNetworking_Stop() {
    if (UiNetImpl::Z().gestartet) {
        UiNetImpl::Node().Stop();
        UiNetImpl::Z().gestartet = false;
    }
}

// Jeden Frame -- auch wenn der Tab NICHT sichtbar ist.
// [Sonst laufen Entdeckung und Abgleich nur, solange man hinsieht. Das
//  ist genau der Fehler, den man hinterher lange sucht.]
inline void UiNetworking_Poll() {
    if (UiNetImpl::Z().gestartet) {
        UiNetImpl::Node().Poll();
        xbm_tls::Poll(XbmNetNode_JetztMs());     // Kalender-Abgleich ueber das Netz
    }
}

// ---------------------------------------------------------------------------
inline void UiNetworking_Draw() {
    auto& z = UiNetImpl::Z();
    auto& n = UiNetImpl::Node();

    // --- Kopf: starten und einstellen ---------------------------------
    if (!z.gestartet) {
        ImGui::TextWrapped(
            "Alle Geraete brauchen dasselbe Geheimnis. Der Ordner data/ "
            "wird abgeglichen.");
        UiFormInput("Name", z.name, sizeof(z.name));
        UiFormInput("Geheimnis", z.geheimnis, sizeof(z.geheimnis),
                    ImGuiInputTextFlags_Password);
        UiFormInput("Hub (host:port)", z.hub, sizeof(z.hub));
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Server im Internet (hub): Abgleich und Rueckfall, gleiches Geheimnis -- leer lassen, wenn keiner");
        ImGui::BeginDisabled(z.geheimnis[0] == '\0');
        if (ImGui::Button("Netzwerk starten")) {
            UiTextSet("netz.name", z.name); UiTextSet("netz.geheimnis", z.geheimnis); UiTextSet("netz.hub", z.hub);
            XbmNetConfig cfg;
            cfg.name      = z.name;
            cfg.geheimnis = z.geheimnis;
            // BENUTZERDATEN abgleichen, nicht die Vorlagen. [Die Vorlagen
            // kommen ohnehin per Bau/Update; was zwischen Geraeten
            // wandern soll, sind die BEARBEITETEN Dateien -- und die
            // liegen jetzt hier. Damit landet auch ein auf dem Handy
            // geaendertes pdfgen-Dokument auf dem Desktop, wo der
            // Push-Knopf es ins Git bringen kann.]
            cfg.syncDir   = XbmPaths_UserData();
            cfg.scriptsDir = XbmPaths_Sub("scripts");
            if (n.Start(cfg)) {
                z.gestartet = true; z.fehler.clear();
                UiNetworking_HubAnwenden();
                // Gespeicherte Freigaben anwenden (Vorgabe: beides an).
                n.SetBefehleErlauben(UiFlagGet("netz.befehleErlauben", true));
                n.SetScriptsFreigeben(UiFlagGet("netz.scriptsFreigeben", true));
            }
            else                z.fehler = n.LastError();
        }
        ImGui::EndDisabled();
        if (z.geheimnis[0] == '\0') {
            ImGui::SameLine();
            ImGui::TextDisabled("(erst ein Geheimnis eintragen)");
        }
        if (!z.fehler.empty())
            ImGui::TextColored(ImVec4(1, 0.4f, 0.4f, 1), "%s", z.fehler.c_str());
        return;
    }

    auto st = n.GetStats();
    ImGui::Text("%zu Geraete gefunden, %zu verbunden", st.peers, st.verbunden);
    ImGui::TextDisabled("%s", xbm_tls::Statuszeile().c_str());    // Kalender-Abgleich (timeline)
    if (UiFormButton("Netzwerk stoppen")) { n.Stop(); z.gestartet = false; }

    bool autoAn = n.AutoSync();
    if (ImGui::Checkbox("Aenderungen automatisch verteilen", &autoAn))
        n.SetAutoSync(autoAn);
    ImGui::SameLine();
    ImGui::TextDisabled("(nur an die angehakten Geraete)");

    ImGui::Separator();

    // --- Freigaben DIESES Geraets ----------------------------------------
    // [Zwei Schalter, getrennt: ob andere hier beliebige Befehle starten
    //  duerfen, und ob die hiesigen Scripts fuer andere sichtbar und
    //  startbar sind. Werden gespeichert, damit ein bewusst abgeriegeltes
    //  Geraet nach dem Neustart abgeriegelt bleibt.]
    {
        bool befehle = n.BefehleErlauben();
        if (ImGui::Checkbox("Befehle von anderen Geraeten hier ausfuehren", &befehle)) {
            n.SetBefehleErlauben(befehle); UiFlagSet("netz.befehleErlauben", befehle);
        }
        bool scripts = n.ScriptsFreigeben();
        if (ImGui::Checkbox("Meine Scripts fuer andere sichtbar und startbar", &scripts)) {
            n.SetScriptsFreigeben(scripts); UiFlagSet("netz.scriptsFreigeben", scripts);
        }
        ImGui::SameLine(); ImGui::TextDisabled("(?)");
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Scripts: %s\n(.cmd-Dateien, je eine Befehlszeile; Kommentarzeilen mit #)\n"
                              "Der Inhalt verlaesst dieses Geraet nie -- andere sehen nur Namen.",
                              XbmPaths_Sub("scripts").c_str());
    }
    ImGui::Separator();

    // --- Geraeteliste mit den Scripts JEDES Geraets ----------------------
    // [Das eigene Geraet steht als "(lokal)" mit in der Liste -- lokale
    //  Befehle und Scripts laufen ueber genau dieselbe Mechanik.]
    ImGui::TextUnformatted("Geraete");
    auto peers = n.Peers();
    if (peers.size() <= 1) {
        ImGui::TextDisabled("  noch kein anderes gefunden -- gleiches WLAN? "
                            "Broadcast erlaubt?");
    }
    for (auto& p : peers) {
        ImGui::PushID(p.id.c_str());
        bool an = p.ausgewaehlt;
        if (ImGui::Checkbox("##an", &an)) n.SetAusgewaehlt(p.id, an);
        ImGui::SameLine();
        const auto scr = n.ScriptsVon(p.id);
        char kopf[160];
        std::snprintf(kopf, sizeof(kopf), "%s  %s:%u  [%s]  %zu Script(s)###peer",
                      p.name.c_str(), p.ip.c_str(), (unsigned)p.cmdPort,
                      XbmCmdStatusText(p.status), scr.size());
        if (ImGui::TreeNode(kopf)) {
            if (ImGui::SmallButton("abgleichen")) n.SyncFrom(p.id);
            ImGui::SameLine();
            if (ImGui::SmallButton("Scripts auffrischen")) n.ScriptsAuffrischen(p.id);
            if (scr.empty()) {
                ImGui::TextDisabled("  keine Scripts freigegeben (oder noch nicht abgefragt)");
            }
            const bool istLokal = (p.id == XbmNetNode::SelbstId());
            for (const std::string& sc : scr) {
                ImGui::PushID(sc.c_str());
                ImGui::Bullet(); ImGui::SameLine();
                if (istLokal) {
                    // EIGENES SCRIPT ANKLICKEN = ZUM BEARBEITEN LADEN.
                    // [Befehlszeile bekommt den Befehl, das Namensfeld den
                    //  Dateinamen -- aendern, "Sichern", fertig. Nur fuer
                    //  (lokal): den Inhalt fremder Scripts sieht dieses
                    //  Geraet bewusst nie, von dort kommen nur Namen.]
                    const float startBreite = 60.0f;
                    if (ImGui::Selectable(sc.c_str(), false, ImGuiSelectableFlags_AllowOverlap,
                            ImVec2(ImGui::GetContentRegionAvail().x - startBreite, 0))) {
                        std::string inhalt;
                        if (UiReadFile(XbmPaths_Sub("scripts") + "/" + sc, inhalt)) {
                            std::string befehl;
                            std::size_t pos = 0;
                            while (pos < inhalt.size()) {
                                std::size_t nl = inhalt.find('\n', pos);
                                if (nl == std::string::npos) nl = inhalt.size();
                                std::string zeile = inhalt.substr(pos, nl - pos);
                                pos = nl + 1;
                                while (!zeile.empty() && (zeile.back() == '\r' || zeile.back() == ' '
                                                          || zeile.back() == '\t'))
                                    zeile.pop_back();
                                if (!zeile.empty() && zeile[0] != '#') { befehl = zeile; break; }
                            }
                            std::snprintf(z.befehl, sizeof(z.befehl), "%s", befehl.c_str());
                            std::string name = sc;
                            if (name.size() > 4 && name.substr(name.size() - 4) == ".cmd")
                                name.resize(name.size() - 4);
                            std::snprintf(z.neuerScriptName, sizeof(z.neuerScriptName), "%s",
                                          name.c_str());
                        }
                    }
                    if (ImGui::IsItemHovered())
                        ImGui::SetTooltip("Klicken: in die Befehlszeile laden und bearbeiten");
                } else {
                    ImGui::TextUnformatted(sc.c_str());
                }
                ImGui::SameLine(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x - 60.0f);
                if (ImGui::SmallButton("Start")) n.JobStarten(p.id, sc, /*istScript=*/true);
                ImGui::PopID();
            }
            ImGui::TreePop();
        }
        ImGui::PopID();
    }
    ImGui::Separator();

    // --- Befehl frei eingeben (auf angehakten Geraeten) -------------------
    ImGui::TextUnformatted("Befehl auf den angehakten Geraeten ausfuehren");
    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
    bool losSenden = ImGui::InputText("##befehl", z.befehl, sizeof(z.befehl),
                                      ImGuiInputTextFlags_EnterReturnsTrue);
    if (UiFormButton("Senden", /*ersterInZeile=*/true) || losSenden) {
        int gestartet = 0;
        for (auto& p : peers) if (p.ausgewaehlt && n.JobStarten(p.id, z.befehl, false)) gestartet++;
        if (gestartet == 0) ImGui::OpenPopup("nichts ausgewaehlt");
    }
    if (ImGui::BeginPopup("nichts ausgewaehlt")) {
        ImGui::TextUnformatted("Kein Geraet angehakt.");
        ImGui::EndPopup();
    }
    if (UiFormButton("Alle abgleichen")) n.SyncSelected(true);
    // Aktuellen Befehl als eigenes Script sichern -- dann sehen ihn die
    // anderen Geraete in DIESER Geraeteliste (bei Freigabe).
    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x * 0.5f);
    ImGui::InputTextWithHint("##scriptname", "als Script sichern: Name",
                             z.neuerScriptName, sizeof(z.neuerScriptName));
    ImGui::SameLine();
    ImGui::BeginDisabled(z.neuerScriptName[0] == '\0' || z.befehl[0] == '\0');
    if (ImGui::SmallButton("Sichern")) {
        std::string name = z.neuerScriptName;
        if (name.size() < 4 || name.substr(name.size() - 4) != ".cmd") name += ".cmd";
        const std::string scriptDir = XbmPaths_Sub("scripts");
        XbmPaths_MakeDirs(scriptDir);
        // VORHANDENES SCRIPT UEBERSCHREIBEN, OHNE SEINE KOMMENTARE ZU VERLIEREN.
        // [Wer ein geladenes Script aendert und sichert, will nur den
        //  Befehl ersetzen -- die Beschreibung darueber soll bleiben.]
        std::string alt, inhalt;
        if (UiReadFile(scriptDir + "/" + name, alt)) {
            std::size_t pos = 0;
            while (pos < alt.size()) {
                std::size_t nl = alt.find('\n', pos);
                if (nl == std::string::npos) nl = alt.size();
                std::string zeile = alt.substr(pos, nl - pos);
                pos = nl + 1;
                if (!zeile.empty() && zeile.back() == '\r') zeile.pop_back();
                if (!zeile.empty() && zeile[0] == '#') inhalt += zeile + "\n";
            }
        }
        if (inhalt.empty()) inhalt = "# Netzwerk-Script -- eine Befehlszeile\n";
        inhalt += z.befehl; inhalt += "\n";
        if (UiWriteFile(scriptDir + "/" + name, inhalt)) {
            z.neuerScriptName[0] = '\0';
            n.ScriptsAuffrischen(XbmNetNode::SelbstId());
        }
    }
    ImGui::EndDisabled();
    ImGui::Separator();

    // --- Jobs: was laeuft wo, wie lange, mit welchem Ergebnis -------------
    {
        auto jobs = n.Jobs();
        ImGui::Text("Jobs (%zu)", jobs.size());
        ImGui::SameLine();
        if (ImGui::SmallButton("fertige entfernen")) n.JobsAufraeumen();
        if (jobs.empty()) ImGui::TextDisabled("  keine");
        const std::int64_t jetzt = (std::int64_t)(ImGui::GetTime() * 1000.0);
        (void)jetzt;
        for (auto& j : jobs) {
            ImGui::PushID(j.id);
            ImVec4 farbe(0.8f, 0.8f, 0.8f, 1.0f);
            switch (j.status) {
                case XbmNetNode::JobStatus::Laeuft:      farbe = ImVec4(1.0f, 0.85f, 0.3f, 1.0f); break;
                case XbmNetNode::JobStatus::Fertig:      farbe = ImVec4(0.4f, 0.9f, 0.4f, 1.0f); break;
                case XbmNetNode::JobStatus::Fehler:      farbe = ImVec4(1.0f, 0.4f, 0.4f, 1.0f); break;
                case XbmNetNode::JobStatus::Abgebrochen: farbe = ImVec4(1.0f, 0.6f, 0.2f, 1.0f); break;
                default: break;
            }
            // Zeile: Status | Geraet | Script/Befehl | Dauer/Code | Stoppen
            ImGui::TextColored(farbe, "%-11s", XbmNetNode::JobStatusText(j.status));
            ImGui::SameLine();
            ImGui::Text("%s", j.peerName.c_str());
            ImGui::SameLine();
            ImGui::TextDisabled("%s%s", j.istScript ? "> " : "$ ", j.anzeige.c_str());
            ImGui::SameLine();
            if (j.status == XbmNetNode::JobStatus::Laeuft) {
                double sek = 0.0;
                if (j.startMs > 0) {
                    // Laufzeit aus Wanduhr-Millisekunden des Knotens.
                    sek = (double)(XbmNetNode_JetztMs() - j.startMs) / 1000.0;
                }
                ImGui::Text("%.0f s", sek);
                ImGui::SameLine();
                if (ImGui::SmallButton("Stoppen")) n.JobAbbrechen(j.id);
            } else if (j.status == XbmNetNode::JobStatus::Fertig || j.status == XbmNetNode::JobStatus::Fehler
                       || j.status == XbmNetNode::JobStatus::Abgebrochen) {
                ImGui::Text("Code %d, %.1f s", j.code,
                            (double)(j.endeMs - j.startMs) / 1000.0);
            } else {
                if (ImGui::SmallButton("Abbrechen")) n.JobAbbrechen(j.id);
            }
            // Letzte Ausgabezeilen aufklappbar.
            if (!j.ausgabe.empty()) {
                if (ImGui::TreeNode("ausgabe", "Ausgabe (%zu Zeilen)", j.ausgabe.size())) {
                    const std::size_t von = j.ausgabe.size() > 30 ? j.ausgabe.size() - 30 : 0;
                    for (std::size_t i = von; i < j.ausgabe.size(); ++i)
                        ImGui::TextUnformatted(j.ausgabe[i].c_str());
                    ImGui::TreePop();
                }
            }
            ImGui::PopID();
        }
    }
    ImGui::Separator();

    // --- Protokoll ------------------------------------------------------
    ImGui::Checkbox("mitlaufen", &z.autoScroll);
    ImGui::SameLine();
    if (ImGui::SmallButton("leeren")) n.ProtokollLeeren();

    ImGui::BeginChild("netzlog", ImVec2(0, 0), true,
                      ImGuiWindowFlags_HorizontalScrollbar);
    for (auto& zeile : n.Protokoll()) {
        if (zeile.fehler)
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 0.45f, 0.45f, 1));
        ImGui::Text("%-12s %s", zeile.peer.c_str(), zeile.text.c_str());
        if (zeile.fehler) ImGui::PopStyleColor();
    }
    if (z.autoScroll && ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 1.0f)
        ImGui::SetScrollHereY(1.0f);
    ImGui::EndChild();
}
