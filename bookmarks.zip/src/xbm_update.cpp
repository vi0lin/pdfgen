#include "xbm_update.h"
#include "xbm_http.h"
#include "xbm_sched.h"
#include "ui_alerts.h"
#include "xbm_version.h"
#include "xbm_paths.h"
#include "xbm_sha256.h"

#include <nlohmann/json.hpp>
#include <chrono>
#include <ctime>
#include <cstdio>
#include <cstdlib>

#if defined(_WIN32)
  #ifndef WIN32_LEAN_AND_MEAN
  #define WIN32_LEAN_AND_MEAN
  #endif
  #include <windows.h>
  #include <fstream>
#elif !defined(__ANDROID__)
  #include <unistd.h>
  #include <sys/stat.h>
#endif
#include <atomic>
#include <vector>
#include <mutex>

namespace {

// WELCHER SCHLUESSEL in release.json fuer DIESES Programm gilt.
// [Jetzt: der Name des Bauordners, den CMake als XBM_RELEASE_NAME
//  hereinreicht (builds/exe -> "exe", builds/deb-asan -> "deb-asan") --
//  derselbe Name, unter dem  publish_release.sh builds/<ordner>
//  veroeffentlicht. Vorher stand hier fest "windows"/"linux"/...; unter
//  diesen Namen wurde aber nie veroeffentlicht, die App fand also nichts.
//  Das Raten unten bleibt nur als Rueckfall fuer einen Bau ohne CMake.]
//
// Alte Beschreibung:
// [Kein eigenes Compile-Flag noetig: die Unterscheidung "normaler
// Linux-Bau" vs. "ASan-Diagnose-Bau" (deb vs. deb-asan) laesst sich
// direkt aus Makros ablesen, die der COMPILER SELBST setzt, sobald
// -fsanitize=address aktiv ist -- GCC definiert dafuer
// __SANITIZE_ADDRESS__, Clang bietet stattdessen __has_feature(...) an.
// Beide werden abgefragt, damit es mit beiden Compilern funktioniert.
// Passend zu den Bezeichnungen, die publish_release.sh als ERSTEN
// Parameter erwartet -- die vergibst du frei, hier folgen wir demselben
// Muster (linux/linux-debug/windows/android).]
const char* XbmUpdate_PlattformSchluessel() {
#if defined(XBM_RELEASE_NAME)
    return XBM_RELEASE_NAME;
#elif defined(_WIN32)
    return "windows";
#elif defined(__ANDROID__)
    return "android";
#elif defined(__SANITIZE_ADDRESS__)
    return "linux-debug";
#elif defined(__has_feature)
    #if __has_feature(address_sanitizer)
    return "linux-debug";
    #else
    return "linux";
    #endif
#else
    return "linux";
#endif
}

#if !defined(_WIN32) && !defined(__ANDROID__)
// LINUX-SELBSTUPDATE: Archiv entpacken, Programmdatei per rename()
// AUSTAUSCHEN, waehrend der aktuelle Prozess noch laeuft.
//
// [Auf Linux unbedenklich: ein laufender Prozess haelt seine Programmdatei
//  ueber die INODE offen, nicht ueber den Dateinamen. "rename()" aendert
//  nur, worauf der PFAD ab sofort zeigt -- der laufende Prozess merkt
//  davon nichts, er benutzt weiter seine alte Inode bis zum Beenden. Erst
//  der NAECHSTE Start bekommt die neue Fassung zu sehen. Deshalb reicht
//  hier "bitte neu starten" -- ein Neustart ist ohnehin noetig, damit der
//  neue Code tatsaechlich laeuft, nicht nur auf der Platte liegt.]
bool XbmUpdate_AnwendenLinux(const std::string& archivPfad, std::string& fehlerAus) {
    char tmplate[] = "/tmp/xbm-update-XXXXXX";
    char* tempdir = mkdtemp(tmplate);
    if (!tempdir) { fehlerAus = "konnte kein Arbeitsverzeichnis anlegen"; return false; }
    const std::string entpackOrdner = tempdir;

    const std::string entpackBefehl =
        "tar -xzf '" + archivPfad + "' -C '" + entpackOrdner + "'";
    if (std::system(entpackBefehl.c_str()) != 0) {
        fehlerAus = "Archiv liess sich nicht entpacken";
        std::system(("rm -rf '" + entpackOrdner + "'").c_str());
        return false;
    }

    const std::string neueDatei = entpackOrdner + "/x_bookmark_manager";
    if (!XbmPaths_Exists(neueDatei)) {
        fehlerAus = "Archiv enthielt keine Programmdatei";
        std::system(("rm -rf '" + entpackOrdner + "'").c_str());
        return false;
    }

    const std::string selfExe = XbmPaths_SelfExe();
    if (selfExe.empty()) {
        fehlerAus = "eigener Programmpfad unbekannt";
        std::system(("rm -rf '" + entpackOrdner + "'").c_str());
        return false;
    }

    // Ausfuehrrecht auf die neue Datei uebertragen -- tar bewahrt es meist
    // aus dem Archiv, aber sicher ist sicher.
    chmod(neueDatei.c_str(), 0755);

    // ATOMISCH AUSTAUSCHEN. [rename() innerhalb DESSELBEN Dateisystems ist
    // atomar -- entweder ganz oder gar nicht, nie ein halb geschriebener
    // Zustand. Liegt /tmp auf einem ANDEREN Dateisystem als die
    // Programmdatei, schlaegt ein direktes rename() mit EXDEV fehl --
    // dann ersatzweise kopieren.]
    bool ausgetauscht = (::rename(neueDatei.c_str(), selfExe.c_str()) == 0);
    if (!ausgetauscht) {
        const std::string kopierBefehl =
            "cp '" + neueDatei + "' '" + selfExe + "'";
        ausgetauscht = (std::system(kopierBefehl.c_str()) == 0);
        if (ausgetauscht) chmod(selfExe.c_str(), 0755);
    }
    if (!ausgetauscht) {
        fehlerAus = "Austausch der Programmdatei fehlgeschlagen "
                    "(Schreibrecht im Programmordner vorhanden?)";
        std::system(("rm -rf '" + entpackOrdner + "'").c_str());
        return false;
    }

    // data/-Ordner MIT AKTUALISIEREN -- das sind seit der Trennung in
    // xbm_paths NUR NOCH die mitgelieferten VORLAGEN neben dem Programm.
    // Die Benutzerdaten (XbmPaths_UserData) liegen woanders und werden
    // hier NICHT beruehrt; neue Vorlagen werden beim naechsten Start
    // ergaenzt, bearbeitete Dateien bleiben. Nur wenn das Archiv data/
    // ueberhaupt mitbringt.
    const std::string neueDaten = entpackOrdner + "/data";
    if (XbmPaths_IsDir(neueDaten)) {
        const std::string zielDaten = XbmPaths_AppDir() + "/data";
        std::system(("cp -r '" + neueDaten + "'/. '" + zielDaten
                     + "'/ 2>/dev/null").c_str());   // best effort
    }

    std::system(("rm -rf '" + entpackOrdner + "'").c_str());
    return true;
}
#endif

// Fuehrt Download, Pruefsummen-Verifikation und plattformspezifisches
// Anwenden aus -- LAEUFT SELBST IM HINTERGRUND-POOL (vom Knopf-Callback
// dorthin verschoben), da alles hier blockierend/langsam ist. Jede
// Meldung an die Oberflaeche geht ueber XbmSched_PostUi, wie fuer jede
// ImGui-Beruehrung von einem Nicht-UI-Thread aus Pflicht.

// ZUSTAND FUER DIE EINSTELLUNGSSEITE -- vom Hintergrund gesetzt, vom
// UI-Thread gelesen; deshalb hinter einem Mutex.
struct UpdateZustand {
    std::mutex m;
    XbmUpdateInfo gefunden;      // version 0 = nichts Neueres
    std::string   meldung;
    std::string   releaseUrl;    // fuer "jetzt pruefen"
    std::atomic<bool> beschaeftigt{false};
    // AUTO-UPDATE. [versuchteVersion: jede Version wird automatisch nur
    //  EINMAL versucht -- scheitert sie (Netz, Pruefsumme, Rechte), soll
    //  nicht jede weitere Pruefung erneut dutzende MB herunterladen.
    //  periodischGeplant: es gibt hoechstens EINE Kette von
    //  Nachpruefungen, egal wie oft der Schalter umgelegt wird.]
    std::atomic<bool> autoUpdate{false};
    std::atomic<int>  versuchteVersion{0};
    std::atomic<bool> periodischGeplant{false};
};
UpdateZustand& Z() { static UpdateZustand z; return z; }

void MeldungSetzen(const std::string& m) {
    std::lock_guard<std::mutex> g(Z().m); Z().meldung = m;
}

// Archiv (tar.gz oder zip) nach <ziel> entpacken -- ueber das
// Systemwerkzeug "tar". [Windows 10+ liefert bsdtar mit, das auch .zip
//  kann; Linux hat GNU tar. Beides ohne eigene Entpackbibliothek.]
bool ArchivEntpacken(const std::string& archiv, const std::string& ziel) {
#if defined(_WIN32)
    const std::string cmd = "tar -xf \"" + archiv + "\" -C \"" + ziel + "\"";
#else
    const std::string cmd = "tar -xzf '" + archiv + "' -C '" + ziel + "'";
#endif
    return std::system(cmd.c_str()) == 0;
}

#if defined(_WIN32)
// WINDOWS: laufende .exe kann nicht ueberschrieben werden. Deshalb ein
// Nachlauf-Script, das (1) wartet, bis dieser Prozess weg ist, (2) die
// entpackten Dateien ueber den Programmordner kopiert, (3) die App neu
// startet, (4) sich selbst loescht. Die App beendet sich direkt nach dem
// Start des Scripts ueber XbmUpdate_BeendenHook.
bool XbmUpdate_AnwendenWindows(const std::string& entpackOrdner, std::string& fehlerAus) {
    const std::string selfExe = XbmPaths_SelfExe();
    const std::string appDir  = XbmPaths_AppDir();
    if (selfExe.empty() || appDir.empty()) { fehlerAus = "eigener Programmpfad unbekannt"; return false; }
    char tmp[MAX_PATH]; GetTempPathA(MAX_PATH, tmp);
    const std::string script = std::string(tmp) + "xbm-update-nachlauf.cmd";
    const DWORD pid = GetCurrentProcessId();
    std::ofstream f(script, std::ios::binary);
    if (!f) { fehlerAus = "konnte Nachlauf-Script nicht schreiben"; return false; }
    f << "@echo off\r\n"
      << ":warte\r\n"
      << "tasklist /FI \"PID eq " << pid << "\" 2>nul | find \"" << pid << "\" >nul\r\n"
      << "if not errorlevel 1 (timeout /t 1 /nobreak >nul & goto warte)\r\n"
      << "xcopy /E /Y /Q \"" << entpackOrdner << "\\*\" \"" << appDir << "\\\" >nul\r\n"
      << "rmdir /S /Q \"" << entpackOrdner << "\" >nul 2>&1\r\n"
      << "start \"\" \"" << selfExe << "\"\r\n"
      << "del \"%~f0\"\r\n";
    f.close();
    // Losgeloest starten -- die App darf danach sofort enden.
    STARTUPINFOA st{}; st.cb = sizeof(st); st.dwFlags = STARTF_USESHOWWINDOW; st.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi{};
    std::string cmd = "cmd.exe /C \"" + script + "\"";
    std::vector<char> cv(cmd.begin(), cmd.end()); cv.push_back(0);
    if (!CreateProcessA(nullptr, cv.data(), nullptr, nullptr, FALSE,
                        CREATE_NEW_CONSOLE | DETACHED_PROCESS, nullptr, nullptr, &st, &pi)) {
        fehlerAus = "konnte Nachlauf-Script nicht starten"; return false;
    }
    CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
    return true;
}
#endif

void XbmUpdate_InstallierenIntern(XbmUpdateInfo info) {
    Z().beschaeftigt = true;
    XbmSched_PostUi([]() {
        UiAlertZeigen("xbm_update", "Update wird heruntergeladen ...", UiAlertArt::Info);
    });
    auto fertig = [](bool ok, const std::string& text) {
        MeldungSetzen(text);
        Z().beschaeftigt = false;
        XbmSched_PostUi([ok, text]() {
            UiAlertZeigen("xbm_update", text, ok ? UiAlertArt::Info : UiAlertArt::Fehler);
        });
    };

    XbmHttpAntwort a = XbmHttp("GET", info.url, {}, {});
    if (!a.fehler.empty() || a.status != 200 || a.body.empty()) {
        fertig(false, "Update-Download fehlgeschlagen -- Netzwerk oder Server nicht erreichbar.");
        return;
    }
    if (!info.sha256.empty() && XbmSha256Hex(a.body) != info.sha256) {
        fertig(false, "Update-Pruefsumme stimmt nicht -- Installation abgebrochen.");
        return;
    }

    // Heruntergeladenes in eine Datei schreiben.
#if defined(_WIN32)
    char tmpdir[MAX_PATH]; GetTempPathA(MAX_PATH, tmpdir);
    const std::string arbeit = std::string(tmpdir) + "xbm-update";
    XbmPaths_MakeDirs(arbeit);
    const std::string archiv = arbeit + "\\paket" + (info.url.size() > 4 && info.url.substr(info.url.size()-4) == ".zip" ? ".zip" : ".tar.gz");
#elif defined(__ANDROID__)
    const std::string arbeit = XbmPaths_UserDir() + "/update";
    XbmPaths_MakeDirs(arbeit);
    const std::string archiv = arbeit + "/x_bookmark_manager.apk";
#else
    char arbeitTmpl[] = "/tmp/xbm-update-XXXXXX";
    const char* mk = mkdtemp(arbeitTmpl);
    if (!mk) { fertig(false, "Konnte kein Arbeitsverzeichnis anlegen."); return; }
    const std::string arbeit = mk;
    const std::string archiv = arbeit + "/paket.tar.gz";
#endif
    {
        std::FILE* f = std::fopen(archiv.c_str(), "wb");
        if (!f) { fertig(false, "Konnte die Update-Datei nicht schreiben."); return; }
        std::fwrite(a.body.data(), 1, a.body.size(), f);
        std::fclose(f);
    }

#if defined(__ANDROID__)
    // APK an den System-Installer. Der Rest (Bestaetigung, Austausch,
    // Neustart) ist Sache von Android.
    if (XbmUpdate_ApkInstallierenHook && XbmUpdate_ApkInstallierenHook(archiv))
        fertig(true, "Version " + std::to_string(info.version)
                     + " an den Android-Installer uebergeben -- bitte dort bestaetigen.");
    else
        fertig(false, "Konnte das APK nicht an den Installer uebergeben. Falls sich die Einstellung "
                      "\"Unbekannte Apps installieren\" geoeffnet hat: dort erlauben und die Aktualisierung noch einmal starten.");
#elif defined(_WIN32)
    const std::string entpackt = arbeit + "\\entpackt";
    XbmPaths_MakeDirs(entpackt);
    if (!ArchivEntpacken(archiv, entpackt)) { fertig(false, "Archiv liess sich nicht entpacken."); return; }
    std::string fehler;
    if (!XbmUpdate_AnwendenWindows(entpackt, fehler)) { fertig(false, "Update fehlgeschlagen: " + fehler); return; }
    MeldungSetzen("Update wird beim Neustart angewendet.");
    Z().beschaeftigt = false;
    XbmSched_PostUi([]() {
        UiAlertZeigen("xbm_update", "Update bereit -- die App startet in wenigen Sekunden neu.", UiAlertArt::Info);
        // Kurz zeigen, dann beenden; das Nachlauf-Script uebernimmt.
        XbmSched_After(std::chrono::seconds(2), []() {
            XbmSched_PostUi([]() { if (XbmUpdate_BeendenHook) XbmUpdate_BeendenHook(); });
        }, XbmRun::Pool);
    });
#else
    std::string fehler;
    const bool ok = XbmUpdate_AnwendenLinux(archiv, fehler);
    std::system(("rm -rf '" + arbeit + "'").c_str());
    if (ok) fertig(true, "Update auf Version " + std::to_string(info.version)
                         + " installiert -- bitte die App neu starten, damit es wirkt.");
    else    fertig(false, "Update fehlgeschlagen: " + fehler);
#endif
}

void XbmUpdate_Auswerten(const std::string& body) {
    nlohmann::json j;
    try { j = nlohmann::json::parse(body); }
    catch (...) { MeldungSetzen("release.json ist kein gueltiges JSON."); return; }
    if (!j.is_object() || !j.contains("version") || !j["version"].is_number_integer()) {
        MeldungSetzen("release.json ohne 'version'."); return;
    }
    const int neueVersion = j["version"].get<int>();
    const char* plat = XbmUpdate_PlattformSchluessel();
    if (!j.contains(plat) || !j[plat].is_object()) {
        MeldungSetzen(std::string("release.json kennt '") + plat + "' (noch) nicht.");
        return;
    }
    const auto& pj = j[plat];
    XbmUpdateInfo info;
    // Version des EIGENEN Plattform-Eintrags hat Vorrang -- die
    // Plattformen werden zu verschiedenen Zeiten veroeffentlicht, die
    // globale Zahl passt nie zu allen zugleich (siehe publish_release.sh).
    info.version = pj.value("version", neueVersion);
    info.notes   = j.value("notes", std::string());
    info.url     = pj.value("url", std::string());
    info.sha256  = pj.value("sha256", std::string());
    if (info.url.empty()) { MeldungSetzen("Eintrag unvollstaendig (keine URL)."); return; }

    if (info.version <= XBM_APP_VERSION) {
        { std::lock_guard<std::mutex> g(Z().m); Z().gefunden = XbmUpdateInfo{}; }
        MeldungSetzen("Aktuell (" + XbmUpdate_VersionText(XBM_APP_VERSION)
                      + ", Server: " + XbmUpdate_VersionText(info.version) + ").");
        return;
    }
    { std::lock_guard<std::mutex> g(Z().m); Z().gefunden = info; }
    MeldungSetzen(XbmUpdate_VersionText(info.version) + " verfuegbar.");
    XbmSched_PostUi([info]() {
        std::string text = XbmUpdate_VersionText(info.version) + " verfuegbar";
        if (!info.notes.empty()) text += " -- " + info.notes;
        if (Z().autoUpdate.load())
            UiAlertZeigen("xbm_update", text + " -- wird automatisch installiert",
                          UiAlertArt::Info);
        else
            UiAlertZeigen("xbm_update", text, UiAlertArt::Info, "Installieren",
                          []() { XbmUpdate_Installieren(); });
    });
}

}  // namespace

void (*XbmUpdate_BeendenHook)() = nullptr;
bool (*XbmUpdate_ApkInstallierenHook)(const std::string&) = nullptr;

// REGELMAESSIG NACHPRUEFEN, solange Auto-Update an ist.
// [Ohne das wuerde eine neue Version nur beim Programmstart bemerkt -- wer
//  die App tagelang offen laesst, bekaeme das Update nie.]
static void XbmUpdate_NaechstePruefungPlanen() {
    if (!Z().autoUpdate.load()) return;
    bool erwartet = false;
    if (!Z().periodischGeplant.compare_exchange_strong(erwartet, true)) return;
    XbmSched_After(std::chrono::minutes(30), []() {
        Z().periodischGeplant = false;
        std::string url;
        { std::lock_guard<std::mutex> g(Z().m); url = Z().releaseUrl; }
        if (Z().autoUpdate.load() && !url.empty()) XbmUpdate_PruefenAsync(url, true);
    }, XbmRun::Pool);
}

void XbmUpdate_SetAuto(bool an) {
    Z().autoUpdate = an;
    if (!an) return;
    // Einschalten wirkt sofort: liegt schon eine erkannte Version vor,
    // jetzt installieren; sonst gleich pruefen.
    const XbmUpdateInfo info = XbmUpdate_Verfuegbar();
    if (info.version > 0 && info.version != Z().versuchteVersion.load()
        && !Z().beschaeftigt.load()) {
        Z().versuchteVersion = info.version;
        XbmUpdate_Installieren();
    } else {
        std::string url;
        { std::lock_guard<std::mutex> g(Z().m); url = Z().releaseUrl; }
        if (!url.empty()) XbmUpdate_PruefenAsync(url, true);
    }
}
bool XbmUpdate_Auto() { return Z().autoUpdate.load(); }

void XbmUpdate_PruefenAsync(const std::string& releaseJsonUrl, bool sofort) {
    { std::lock_guard<std::mutex> g(Z().m); Z().releaseUrl = releaseJsonUrl; }
    if (Z().beschaeftigt.load()) return;
    Z().beschaeftigt = true;
    MeldungSetzen("pruefe ...");
    XbmSched_After(sofort ? std::chrono::seconds(0) : std::chrono::seconds(5),
        [releaseJsonUrl]() {
            XbmHttpAntwort a = XbmHttp("GET", releaseJsonUrl, {}, {});
            if (!a.fehler.empty() || a.status != 200 || a.body.empty())
                MeldungSetzen("Update-Server nicht erreichbar.");
            else
                XbmUpdate_Auswerten(a.body);
            Z().beschaeftigt = false;
            // AUTOMATISCH INSTALLIEREN -- erst HIER, nach dem Freigeben.
            // [Waehrend der Pruefung steht beschaeftigt auf true, und
            //  XbmUpdate_Installieren() bricht dann sofort ab. Ein Aufruf
            //  direkt beim Erkennen (in XbmUpdate_Auswerten) haette deshalb
            //  nie etwas getan. Wir sind hier ohnehin schon im Hintergrund-
            //  Pool, also direkt den internen Weg nehmen.]
            if (Z().autoUpdate.load()) {
                const XbmUpdateInfo info = XbmUpdate_Verfuegbar();
                if (info.version > 0 && info.version != Z().versuchteVersion.load()) {
                    Z().versuchteVersion = info.version;
                    XbmUpdate_InstallierenIntern(info);
                }
            }
            XbmUpdate_NaechstePruefungPlanen();
        }, XbmRun::Pool);
}

XbmUpdateInfo XbmUpdate_Verfuegbar() { std::lock_guard<std::mutex> g(Z().m); return Z().gefunden; }
bool XbmUpdate_Beschaeftigt()         { return Z().beschaeftigt.load(); }
std::string XbmUpdate_LetzteMeldung() { std::lock_guard<std::mutex> g(Z().m); return Z().meldung; }

void XbmUpdate_Installieren() {
    XbmUpdateInfo info = XbmUpdate_Verfuegbar();
    if (info.version == 0 || Z().beschaeftigt.load()) return;
    XbmSched_After(std::chrono::milliseconds(0), [info]() {
        XbmUpdate_InstallierenIntern(info);
    }, XbmRun::Pool);
}

std::string XbmUpdate_VersionText(int version) {
    // Ein Commit-Zeitstempel (Sekunden seit 1970) ist als Zahl unlesbar --
    // als Datum sofort verstaendlich. Kleine Zahlen (Rueckfall "1") bleiben
    // so, wie sie sind.
    if (version < 1000000000) return "Version " + std::to_string(version);
    std::time_t t = (std::time_t)version;
    std::tm tmv{};
#if defined(_WIN32)
    localtime_s(&tmv, &t);
#else
    localtime_r(&t, &tmv);
#endif
    char buf[48];
    std::strftime(buf, sizeof(buf), "Stand %d.%m.%Y %H:%M", &tmv);
    return buf;
}
