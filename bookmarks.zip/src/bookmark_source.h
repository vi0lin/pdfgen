#pragma once
// ---------------------------------------------------------------------------
// bookmark_source.h -- EINE Schnittstelle fuer X, Reddit und Facebook.
//
// [Das Bookmark-Fenster, das Laden im Hintergrund, das Loeschen, die
//  Auswahl -- all das ist plattformunabhaengig. Nur vier Dinge sind je
//  Plattform anders: welche Cookies der Login braucht, wie man prueft,
//  ob sie gelten, wie man die Lesezeichen holt und wie man eines
//  entfernt. Genau diese vier stehen hier. Alles andere gibt es EINMAL.]
// ---------------------------------------------------------------------------
#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

// Ein Lesezeichen, plattformneutral.
struct BookmarkEntry {
    std::string id;         // stabil, wird zum Loeschen benutzt
    std::string author;     // "@handle", "u/name", Seitenname
    std::string text;
    std::string url;        // zum Oeffnen im Browser
    std::string created;    // frei formatiert, nur Anzeige
};

// Ein Eingabefeld des Logins (Cookie-Name, Beschriftung, Passwortfeld?).
struct LoginField {
    std::string key;
    std::string label;
    bool secret = false;
};

class BookmarkSource {
public:
    virtual ~BookmarkSource() = default;

    virtual const char* Name() const = 0;          // "X", "Reddit", "Facebook"
    virtual const char* Slug() const = 0;          // "x", "reddit", "facebook" (Dateinamen)

    // Welche Werte der Login braucht -- die Oberflaeche baut daraus
    // die Eingabefelder. Kein Plattformwissen in der Oberflaeche.
    virtual std::vector<LoginField> LoginFields() const = 0;

    // Werte uebernehmen und PRUEFEN. false = Cookies gelten nicht.
    // Setzt bei Fehlern eine lesbare Meldung in `fehler`.
    virtual bool Login(const std::map<std::string, std::string>& werte,
                       std::string& fehler) = 0;
    virtual bool LoggedIn() const = 0;
    virtual void Logout() = 0;

    // Alle Lesezeichen seitenweise holen. on_page je Seite, damit die
    // Oberflaeche waehrenddessen zeichnen kann; should_stop zwischen den
    // Seiten geprueft. Wirft std::runtime_error bei HTTP-Fehlern.
    virtual void FetchAll(const std::function<void(const std::vector<BookmarkEntry>&)>& on_page,
                          const std::function<bool()>& should_stop) = 0;

    // Ein Lesezeichen entfernen. true = gelungen.
    virtual bool Remove(const std::string& id) = 0;

    // Was in der Oberflaeche als Hinweis stehen soll (z.B. "experimentell").
    virtual const char* Hint() const { return ""; }
};

// Die drei Quellen. Jede in ihrer eigenen Datei.
std::unique_ptr<BookmarkSource> MakeXSource();
std::unique_ptr<BookmarkSource> MakeRedditSource();
std::unique_ptr<BookmarkSource> MakeFacebookSource();
