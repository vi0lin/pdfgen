#pragma once
// ---------------------------------------------------------------------------
// ui_form.h -- Eingabefelder und Knoepfe, die NIE horizontal scrollen.
//
// DIE REGELN (einmal hier, nicht in jedem Fenster neu):
//   * Textfelder: Beschriftung KLEIN DARUEBER, nicht rechts daneben.
//     Breite = min(verfuegbare Breite, Hoechstbreite). Sie fuellen die
//     Zeile also nur, wenn wenig Platz ist -- und ragen nie darueber.
//   * Knoepfe: rutschen in die naechste Zeile, wenn sie nicht mehr passen
//     (UiFormButton), und brechen ihren Text um, wenn er allein schon zu
//     breit ist (UiButtonWrap).
//
// [Warum eine eigene Datei: jedes Fenster hat diese Regeln bisher selbst
//  umgesetzt -- oder eben nicht. Das Netzwerk-Fenster scrollte
//  horizontal, weil ImGui::InputText die Beschriftung RECHTS anhaengt und
//  der Knopf daneben nicht umbrach. Hier steht es einmal richtig.]
// ---------------------------------------------------------------------------
#include "imgui.h"
#include "imgui_internal.h"

#include <cstring>

// [OHNE ui_helpers.h. Diese Datei muss sich von ui_helpers.h einbinden
//  lassen -- dort wird UiFormInput inzwischen benutzt. Ein Include in
//  die Gegenrichtung waere ein Zirkel. Die eine Hilfsfunktion, die hier
//  gebraucht wird, steht deshalb hier noch einmal, unter eigenem Namen.]
inline void UiFormWrapSameLine(const char* next_label) {
    float need = ImGui::CalcTextSize(next_label, nullptr, true).x
               + ImGui::GetStyle().FramePadding.x * 2
               + ImGui::GetStyle().ItemSpacing.x;
    float avail = ImGui::GetContentRegionAvail().x;
    ImGui::SameLine();
    if (need > ImGui::GetContentRegionAvail().x + 0.01f || avail <= 0) ImGui::NewLine();
}

// Hoechstbreite eines Textfelds bei viel Platz. [Ein Cookie-Feld ueber
//  die ganze Bildschirmbreite ist nicht besser lesbar, nur groesser.]
inline float& UiFormMaxWidth() { static float w = 360.0f; return w; }

// Breite, die ein Feld jetzt bekommen soll.
inline float UiFormWidth(float wunsch = -1.0f) {
    float avail = ImGui::GetContentRegionAvail().x;
    float mx = wunsch > 0.0f ? wunsch : UiFormMaxWidth();
    return avail < mx ? avail : mx;
}

// Beschriftung klein darueber.
inline void UiFormLabel(const char* label) {
    if (!label || !label[0] || label[0] == '#') return;
    // Text bis "##" (ImGui-Kennung nicht anzeigen)
    const char* ende = strstr(label, "##");
    ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled));
    if (ende) ImGui::TextUnformatted(label, ende); else ImGui::TextUnformatted(label);
    ImGui::PopStyleColor();
}

// Textfeld: Beschriftung darueber, Breite begrenzt.
inline bool UiFormInput(const char* label, char* buf, size_t size,
                        ImGuiInputTextFlags flags = 0, float wunschBreite = -1.0f) {
    UiFormLabel(label);
    ImGui::SetNextItemWidth(UiFormWidth(wunschBreite));
    // Eigene Kennung: "##"+label, damit ImGui keine Beschriftung rechts malt.
    char id[128];
    ImFormatString(id, sizeof(id), "##%s", label);
    return ImGui::InputText(id, buf, size, flags);
}

// Knopf, dessen Text umbricht, wenn er allein schon zu breit ist.
// Liefert true beim Klick. maxW <= 0: verfuegbare Breite.
inline bool UiButtonWrap(const char* label, float maxW = -1.0f) {
    ImGuiStyle& st = ImGui::GetStyle();
    float avail = maxW > 0.0f ? maxW : ImGui::GetContentRegionAvail().x;
    ImVec2 einzeilig = ImGui::CalcTextSize(label, nullptr, true);
    if (einzeilig.x + st.FramePadding.x * 2 <= avail || avail <= 0.0f)
        return ImGui::Button(label);          // passt: normaler Knopf

    // Umbruch noetig: Knopf in Handarbeit -- Flaeche, dann umbrochener Text.
    float textW = avail - st.FramePadding.x * 2;
    if (textW < 10.0f) textW = 10.0f;
    ImVec2 ts = ImGui::CalcTextSize(label, nullptr, true, textW);
    ImVec2 groesse(avail, ts.y + st.FramePadding.y * 2);
    ImVec2 p = ImGui::GetCursorScreenPos();
    bool klick = ImGui::InvisibleButton(label, groesse);
    bool hov = ImGui::IsItemHovered(), akt = ImGui::IsItemActive();
    ImU32 bg = ImGui::GetColorU32(akt ? ImGuiCol_ButtonActive
                                : hov ? ImGuiCol_ButtonHovered : ImGuiCol_Button);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(p, ImVec2(p.x + groesse.x, p.y + groesse.y), bg, st.FrameRounding);
    const char* ende = strstr(label, "##");
    dl->AddText(ImGui::GetFont(), ImGui::GetFontSize(),
                ImVec2(p.x + st.FramePadding.x, p.y + st.FramePadding.y),
                ImGui::GetColorU32(ImGuiCol_Text), label, ende, textW);
    return klick;
}

// Knopf, der in die naechste Zeile rutscht, wenn er nicht mehr passt.
// Zwischen zwei Knoepfen statt ImGui::SameLine() benutzen:
//     if (UiFormButton("Senden")) ...; if (UiFormButton("Abgleichen")) ...
// Der ERSTE Knopf einer Zeile bekommt kein SameLine -- daher der Merker.
inline bool UiFormButton(const char* label, bool ersterInZeile = false) {
    if (!ersterInZeile) UiFormWrapSameLine(label);
    return UiButtonWrap(label);
}
