// ---------------------------------------------------------------------------
// xbm_paths.cpp -- siehe xbm_paths.h.
// ---------------------------------------------------------------------------
#include "xbm_paths.h"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <sys/stat.h>

#if defined(_WIN32)
    #ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
    #endif
    #include <windows.h>
    #include <shellapi.h>
    #include <direct.h>
#else
    #include <dirent.h>
    #include <unistd.h>
    #include <limits.h>
#endif

#if defined(__APPLE__)
    #include <mach-o/dyld.h>
#endif

#if defined(__ANDROID__)
    #include <android/asset_manager.h>
    #include <android/log.h>
    #define PATH_LOG(...) __android_log_print(ANDROID_LOG_INFO, "xbm.paths", __VA_ARGS__)
#else
    #define PATH_LOG(...) do { std::fprintf(stderr, "[pfade] " __VA_ARGS__); \
                               std::fprintf(stderr, "\n"); } while (0)
#endif

namespace {

struct Paths {
    std::string appDir;
    std::string selfExe;   // vollstaendiger Pfad zur eigenen Programmdatei -- fuer das App-Update noetig
    std::string dataRoot;
    std::string userDir;
    std::string userData;  // bestaendiger, beschreibbarer Datenstamm -- siehe xbm_paths.h
    bool ready = false;
};
Paths& P() { static Paths p; return p; }

std::string DirOf(const std::string& p) {
    const std::size_t s = p.find_last_of("/\\");
    return (s == std::string::npos) ? std::string(".") : p.substr(0, s);
}

std::string Join(const std::string& a, const std::string& b) {
    if (a.empty()) return b;
    if (b.empty()) return a;
    const char last = a[a.size() - 1];
    if (last == '/' || last == '\\') return a + b;
    return a + "/" + b;
}

// Pfad der eigenen ausfuehrbaren Datei. argv[0] ist NUR der Rueckfall: wird
// das Programm ueber PATH gestartet, steht dort blosss "x_bookmark_manager"
// und der Datenordner waere nicht auffindbar. Jedes System hat dafuer einen
// verlaesslichen Weg.
std::string SelfPath(const char* argv0) {
#if defined(_WIN32)
    char buf[MAX_PATH];
    const DWORD n = GetModuleFileNameA(nullptr, buf, MAX_PATH);
    if (n > 0 && n < MAX_PATH) return std::string(buf, n);
#elif defined(__APPLE__)
    char buf[4096];
    uint32_t sz = sizeof(buf);
    if (_NSGetExecutablePath(buf, &sz) == 0) return std::string(buf);
#elif defined(__linux__) && !defined(__ANDROID__)
    char buf[4096];
    const ssize_t n = ::readlink("/proc/self/exe", buf, sizeof(buf) - 1);
    if (n > 0) { buf[n] = '\0'; return std::string(buf); }
#endif
    return std::string(argv0 ? argv0 : "");
}

#if defined(__ANDROID__)
// Asset-Baum rekursiv nach <ziel> entpacken.
//
// WARUM UEBERHAUPT: AAssetDir_getNextFileName liefert nur DATEIEN, keine
// Unterordner -- der Asset-Manager kann Verzeichnisse nicht aufzaehlen.
// Deshalb liegt im Asset-Stamm eine Datei "index.txt" mit allen relativen
// Pfaden, die das CMake beim Bauen erzeugt. Ohne die muesste man jeden
// Unterordner im Code fest verdrahten.
void ExtractAssets(AAssetManager* mgr, const std::string& dst) {
    if (!mgr) return;
    AAsset* idx = AAssetManager_open(mgr, "data/index.txt", AASSET_MODE_BUFFER);
    if (!idx) {
        PATH_LOG("data/index.txt fehlt im APK -- nichts zu entpacken. "
                 "Liegt data/ im Projekt und wurde neu gebaut?");
        return;
    }
    const off_t len = AAsset_getLength(idx);
    std::string list((std::size_t)len, '\0');
    AAsset_read(idx, &list[0], (std::size_t)len);
    AAsset_close(idx);

    int nOk = 0, nSkip = 0;
    std::size_t pos = 0;
    while (pos <= list.size()) {
        std::size_t nl = list.find('\n', pos);
        if (nl == std::string::npos) nl = list.size();
        std::string rel = list.substr(pos, nl - pos);
        pos = nl + 1;
        while (!rel.empty() && (rel.back() == '\r' || rel.back() == ' ')) rel.pop_back();
        if (rel.empty()) { if (pos > list.size()) break; else continue; }

        const std::string out = Join(dst, rel);
        XbmPaths_MakeDirs(DirOf(out));

        AAsset* a = AAssetManager_open(mgr, ("data/" + rel).c_str(),
                                       AASSET_MODE_STREAMING);
        if (!a) { ++nSkip; continue; }
        // Vorhandene Datei nur ersetzen, wenn die Groesse abweicht. So
        // ueberlebt eine vom Nutzer bearbeitete Datei einen Neustart, ein
        // App-Update mit geaenderten Inhalten setzt sie aber neu.
        struct stat st{};
        const off_t alen = AAsset_getLength(a);
        if (::stat(out.c_str(), &st) == 0 && st.st_size == alen) {
            AAsset_close(a); ++nSkip; continue;
        }
        if (std::FILE* f = std::fopen(out.c_str(), "wb")) {
            char buf[16384];
            int r;
            while ((r = AAsset_read(a, buf, sizeof(buf))) > 0)
                std::fwrite(buf, 1, (std::size_t)r, f);
            std::fclose(f);
            ++nOk;
        }
        AAsset_close(a);
        if (pos > list.size()) break;
    }
    PATH_LOG("Assets entpackt: %d neu, %d unveraendert -> %s",
             nOk, nSkip, dst.c_str());
}
#endif  // __ANDROID__

}  // namespace

// ---------------------------------------------------------------------------
void XbmPaths_Init(const char* argv0) {
#if defined(__ANDROID__)
    (void)argv0;   // Android geht ueber XbmPaths_InitAndroid
#else
    const std::string self = SelfPath(argv0);
    P().appDir   = self.empty() ? std::string(".") : DirOf(self);
    P().selfExe  = self;
    P().dataRoot = Join(P().appDir, "data");
    P().ready    = true;
    PATH_LOG("Programm: %s", self.c_str());
    PATH_LOG("Datenstamm: %s%s", P().dataRoot.c_str(),
             XbmPaths_IsDir(P().dataRoot) ? "" : "   (FEHLT!)");
#endif
}

void XbmPaths_InitAndroid(AAssetManager* mgr, const char* internalDataPath) {
#if defined(__ANDROID__)
    P().appDir   = internalDataPath ? internalDataPath : "";
    P().dataRoot = Join(P().appDir, "data");
    P().userDir  = P().appDir;
    P().userData = Join(P().appDir, "userdata");
    P().ready    = true;
    XbmPaths_MakeDirs(P().dataRoot);
    // Die Vorlagen (data/) werden weiterhin bei Groessenabweichung neu
    // entpackt -- das ist jetzt RICHTIG, denn sie sind die mitgelieferte
    // Kopie. Die Arbeitskopie liegt daneben in userdata/ und wird nur
    // ERGAENZT, nie ueberschrieben.
    ExtractAssets(mgr, P().dataRoot);
    XbmPaths_MakeDirs(P().userData);
    XbmPaths_VorlagenErgaenzen();
#else
    (void)mgr; (void)internalDataPath;
#endif
}

std::string XbmPaths_AppDir()   { return P().appDir; }
std::string XbmPaths_SelfExe()  { return P().selfExe; }
std::string XbmPaths_DataRoot() { return P().dataRoot; }
std::string XbmPaths_Assets()   { return Join(P().dataRoot, "assets"); }
std::string XbmPaths_UserData() {
    // Solange kein Nutzerordner bekannt ist (Desktop: vor SetUserDir),
    // auf die Vorlagen zurueckfallen -- besser als ein leerer Pfad.
    return P().userData.empty() ? P().dataRoot : P().userData;
}
std::string XbmPaths_Pdfgen()         { return Join(XbmPaths_UserData(), "pdfgen"); }
std::string XbmPaths_PdfgenVorlagen() { return Join(P().dataRoot, "pdfgen"); }
std::string XbmPaths_Sub(const std::string& rel) { return Join(XbmPaths_UserData(), rel); }

void XbmPaths_SetUserDir(const std::string& d) {
    P().userDir = d;
#if !defined(__ANDROID__)
    // DESKTOP: der bestaendige Datenstamm liegt im Nutzer-Konfigordner,
    // nicht im Programmordner. Erst hier bekannt, deshalb erst hier
    // ergaenzen. [Android setzt userData schon in InitAndroid.]
    if (!d.empty()) {
        P().userData = Join(d, "data");
        XbmPaths_MakeDirs(P().userData);
        XbmPaths_VorlagenErgaenzen();
    }
#endif
}
std::string XbmPaths_UserDir() {
    return P().userDir.empty() ? P().appDir : P().userDir;
}

bool XbmPaths_Exists(const std::string& p) {
    if (p.empty()) return false;
    struct stat st{};
    return ::stat(p.c_str(), &st) == 0;
}

bool XbmPaths_IsDir(const std::string& p) {
    if (p.empty()) return false;
    struct stat st{};
    if (::stat(p.c_str(), &st) != 0) return false;
    return (st.st_mode & S_IFMT) == S_IFDIR;
}

bool XbmPaths_MakeDirs(const std::string& p) {
    if (p.empty()) return false;
    std::string cur;
    for (std::size_t i = 0; i <= p.size(); ++i) {
        if (i == p.size() || p[i] == '/' || p[i] == '\\') {
            if (!cur.empty() && cur != "." && cur.back() != ':') {
#if defined(_WIN32)
                _mkdir(cur.c_str());
#else
                ::mkdir(cur.c_str(), 0775);
#endif
            }
        }
        if (i < p.size()) cur += p[i];
    }
    return XbmPaths_IsDir(p);
}

namespace {
bool EndsWith(const std::string& s, const std::string& suf) {
    if (suf.empty()) return true;
    if (s.size() < suf.size()) return false;
    // Endung ohne Ruecksicht auf Gross-/Kleinschreibung: ".TXT" soll bei
    // einem Filter ".txt" mitgehen (Windows-Dateien kommen so oft daher).
    for (std::size_t i = 0; i < suf.size(); ++i) {
        char a = s[s.size() - suf.size() + i], b = suf[i];
        if (a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
        if (b >= 'A' && b <= 'Z') b = (char)(b - 'A' + 'a');
        if (a != b) return false;
    }
    return true;
}
}  // namespace

std::vector<std::string> XbmPaths_ListFiles(const std::string& dir,
                                            const std::string& ext) {
    std::vector<std::string> out;
    if (dir.empty()) return out;
#if defined(_WIN32)
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA((dir + "\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return out;
    do {
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
        if (EndsWith(fd.cFileName, ext)) out.push_back(fd.cFileName);
    } while (FindNextFileA(h, &fd));
    FindClose(h);
#else
    DIR* d = ::opendir(dir.c_str());
    if (!d) return out;
    while (dirent* e = ::readdir(d)) {
        const std::string name = e->d_name;
        if (name == "." || name == "..") continue;
        if (XbmPaths_IsDir(Join(dir, name))) continue;
        if (EndsWith(name, ext)) out.push_back(name);
    }
    ::closedir(d);
#endif
    std::sort(out.begin(), out.end());
    return out;
}

std::vector<std::string> XbmPaths_ListDirs(const std::string& dir) {
    std::vector<std::string> out;
    if (dir.empty()) return out;
#if defined(_WIN32)
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA((dir + "\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return out;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
        const std::string n = fd.cFileName;
        if (n == "." || n == "..") continue;
        out.push_back(n);
    } while (FindNextFileA(h, &fd));
    FindClose(h);
#else
    DIR* d = ::opendir(dir.c_str());
    if (!d) return out;
    while (dirent* e = ::readdir(d)) {
        const std::string name = e->d_name;
        if (name == "." || name == "..") continue;
        if (XbmPaths_IsDir(Join(dir, name))) out.push_back(name);
    }
    ::closedir(d);
#endif
    std::sort(out.begin(), out.end());
    return out;
}

std::string XbmPaths_Report() {
    auto line = [](const char* label, const std::string& p) {
        std::string s = "  ";
        s += label; s += ": "; s += p.empty() ? "(leer)" : p;
        s += XbmPaths_IsDir(p) ? "   [ok]" : "   [fehlt]";
        s += "\n";
        return s;
    };
    std::string r = "Pfade\n";
    r += line("Programm ", XbmPaths_AppDir());
    r += line("Daten    ", XbmPaths_DataRoot());
    r += line("assets   ", XbmPaths_Assets());
    r += line("pdfgen   ", XbmPaths_Pdfgen());
    r += line("Nutzer   ", XbmPaths_UserDir());
    const auto txt = XbmPaths_ListFiles(XbmPaths_Pdfgen(), ".txt");
    r += "  pdfgen: " + std::to_string(txt.size()) + " .txt-Dateien\n";
    return r;
}

// ---------------------------------------------------------------------------
// BENUTZERDATEN ERGAENZEN / KOPIEREN / PROJEKTORDNER / EXTERN OEFFNEN
// ---------------------------------------------------------------------------
bool XbmPaths_KopiereDatei(const std::string& von, const std::string& nach) {
    std::FILE* in = std::fopen(von.c_str(), "rb");
    if (!in) return false;
    XbmPaths_MakeDirs(DirOf(nach));
    std::FILE* out = std::fopen(nach.c_str(), "wb");
    if (!out) { std::fclose(in); return false; }
    char buf[65536]; std::size_t r; bool ok = true;
    while ((r = std::fread(buf, 1, sizeof(buf), in)) > 0)
        if (std::fwrite(buf, 1, r, out) != r) { ok = false; break; }
    std::fclose(in); std::fclose(out);
    return ok;
}

namespace {
// Rekursiv: alles aus <von>, was in <nach> FEHLT, dorthin kopieren.
// Vorhandenes bleibt unangetastet -- das ist die eine Regel, die
// Nutzeraenderungen schuetzt.
int ErgaenzeFehlende(const std::string& von, const std::string& nach) {
    int n = 0;
    for (const std::string& d : XbmPaths_ListDirs(von))
        n += ErgaenzeFehlende(Join(von, d), Join(nach, d));
    for (const std::string& f : XbmPaths_ListFiles(von)) {
        const std::string ziel = Join(nach, f);
        if (XbmPaths_Exists(ziel)) continue;          // NIE ueberschreiben
        if (XbmPaths_KopiereDatei(Join(von, f), ziel)) ++n;
    }
    return n;
}
}  // namespace

int XbmPaths_VorlagenErgaenzen() {
    if (P().userData.empty() || P().dataRoot.empty()) return 0;
    if (P().userData == P().dataRoot) return 0;
    if (!XbmPaths_IsDir(P().dataRoot)) return 0;
    // assets/ NICHT kopieren -- Shader usw. werden nur gelesen und sollen
    // mit jedem Update aktuell sein; XbmPaths_Assets() zeigt ohnehin auf
    // die Vorlagen.
    int n = 0;
    for (const std::string& d : XbmPaths_ListDirs(P().dataRoot)) {
        if (d == "assets") continue;
        n += ErgaenzeFehlende(Join(P().dataRoot, d), Join(P().userData, d));
    }
    for (const std::string& f : XbmPaths_ListFiles(P().dataRoot)) {
        if (f == "index.txt") continue;               // Android-Entpackliste
        const std::string ziel = Join(P().userData, f);
        if (!XbmPaths_Exists(ziel) && XbmPaths_KopiereDatei(Join(P().dataRoot, f), ziel)) ++n;
    }
    PATH_LOG("Benutzerdaten: %d Datei(en) aus den Vorlagen ergaenzt -> %s",
             n, P().userData.c_str());
    return n;
}

std::string XbmPaths_ProjektRoot() {
#if defined(__ANDROID__)
    return "";
#else
    // Vom Programmordner aufwaerts: der erste Ordner mit .git UND
    // data/shared ist der Quellbaum. [Typisch: builds/deb/ -> zwei
    //  Stufen hoch. Eine INSTALLIERTE Fassung liegt in keinem Quellbaum;
    //  dann bleibt es leer, und der Push-Knopf erklaert das.]
    std::string p = P().appDir;
    for (int i = 0; i < 6 && !p.empty(); ++i) {
        if (XbmPaths_IsDir(Join(p, ".git")) && XbmPaths_IsDir(Join(p, "data/shared")))
            return p;
        const std::string eltern = DirOf(p);
        if (eltern == p || eltern == ".") break;
        p = eltern;
    }
    return "";
#endif
}

bool (*XbmPaths_OeffnenExternHook)(const std::string& pfad) = nullptr;

bool XbmPaths_OeffnenExtern(const std::string& pfad) {
    if (pfad.empty()) return false;
    if (XbmPaths_OeffnenExternHook) return XbmPaths_OeffnenExternHook(pfad);
#if defined(_WIN32)
    HINSTANCE h = ShellExecuteA(nullptr, "open", pfad.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    return (INT_PTR)h > 32;
#elif defined(__ANDROID__)
    return false;   // ohne Hook (siehe main_android.cpp) nicht moeglich
#elif defined(__APPLE__)
    return std::system(("open \"" + pfad + "\" >/dev/null 2>&1 &").c_str()) == 0;
#else
    // Im Hintergrund, damit die Oberflaeche nicht wartet, bis der
    // Betrachter geschlossen wird.
    return std::system(("xdg-open \"" + pfad + "\" >/dev/null 2>&1 &").c_str()) == 0;
#endif
}
