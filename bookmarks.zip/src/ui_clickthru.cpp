// ---------------------------------------------------------------------------
// ui_clickthru.cpp -- siehe ui_clickthru.h.
// ---------------------------------------------------------------------------
#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif
#include "ui_clickthru.h"
#include "imgui_internal.h"

#include <cstdio>
#include <cstring>

namespace {
bool  g_debug = false;
const char* g_reason = "(noch nichts entschieden)";

bool IsPageHost(const ImGuiWindow* w) {
    return w && std::strncmp(w->Name, "##page_host_", 12) == 0;
}
}  // namespace

void UiClickThru_SetDebug(bool on) { g_debug = on; }
bool UiClickThru_Debug() { return g_debug; }
const char* UiClickThru_LastReason() { return g_reason; }

void UiClickThru_FeedCursor(float x, float y, bool valid) {
    ImGuiIO& io = ImGui::GetIO();
    if (!valid) return;
    // NACH dem NewFrame des Backends einreihen, damit dieser Wert gewinnt:
    // Ereignisse werden in Reihenfolge angewandt, das letzte zaehlt.
    io.AddMousePosEvent(x, y);
}

bool UiClickThru_OverUi() {
    ImGuiContext* ctx = ImGui::GetCurrentContext();
    if (!ctx) { g_reason = "kein ImGui-Kontext"; return true; }
    ImGuiContext& g = *ctx;

    // Laeuft gerade eine Interaktion (Knopf gedrueckt, Regler gezogen,
    // Fenster verschoben)? Dann auf keinen Fall mittendrin durchlassen --
    // sonst kaeme beim Gegenueber ein halber Klick an.
    if (g.ActiveId != 0)      { g_reason = "Interaktion aktiv"; return true; }
    if (g.MovingWindow)       { g_reason = "Fenster wird bewegt"; return true; }
    // Offene Popups/Menues liegen ueber allem und fangen.
    if (g.OpenPopupStack.Size > 0 && g.HoveredWindow) {
        g_reason = "Popup offen"; return true;
    }

    ImGuiWindow* hw = g.HoveredWindow;
    if (!hw) { g_reason = "kein Fenster unter dem Zeiger"; return false; }

    // Von innen nach aussen: das erste eindeutige Urteil gewinnt.
    for (ImGuiWindow* w = hw; w != nullptr; w = w->ParentWindow) {
        if (w->DockIsActive) {
            // Ein GEDOCKTES Nutzerfenster -- faengt.
            g_reason = "gedocktes Fenster";
            return true;
        }
        if (IsPageHost(w)) {
            // Bis zum Seiten-Host durchgereicht, ohne unterwegs auf ein
            // gedocktes Fenster zu stossen: das ist der Hintergrund bzw.
            // ein leerer Bereich des DockSpace -- FREI.
            g_reason = "Seiten-Hintergrund / leerer DockSpace";
            return false;
        }
    }
    g_reason = "Fenster";
    return true;
}

void UiClickThru_DrawDebugOverlay() {
    if (!g_debug) return;
    ImGuiContext* ctx = ImGui::GetCurrentContext();
    if (!ctx) return;
    ImDrawList* dl = ImGui::GetForegroundDrawList();

    // Alles, was faengt, gruen umranden; der Seiten-Host bleibt frei.
    for (ImGuiWindow* w : ctx->Windows) {
        if (!w->WasActive || w->Hidden) continue;
        if (w->Flags & ImGuiWindowFlags_NoInputs) continue;
        if ((w->Flags & ImGuiWindowFlags_ChildWindow) && !w->DockIsActive) continue;
        if (IsPageHost(w)) continue;
        const ImVec2 a = w->Pos, b(w->Pos.x + w->Size.x, w->Pos.y + w->Size.y);
        dl->AddRectFilled(a, b, IM_COL32(0, 200, 90, 26));
        dl->AddRect(a, b, IM_COL32(0, 220, 110, 160));
    }
    const bool over = UiClickThru_OverUi();
    const ImVec2 mp = ImGui::GetIO().MousePos;
    dl->AddCircleFilled(mp, 7.0f,
        over ? IM_COL32(0, 220, 110, 220) : IM_COL32(230, 80, 60, 220));
    char buf[192];
    std::snprintf(buf, sizeof(buf), "%s  (%s)",
                  over ? "FAENGT" : "DURCHLAESSIG", UiClickThru_LastReason());
    const ImVec2 ts = ImGui::CalcTextSize(buf);
    dl->AddRectFilled(ImVec2(mp.x + 12, mp.y - 4),
                      ImVec2(mp.x + 18 + ts.x, mp.y + 4 + ts.y),
                      IM_COL32(15, 15, 20, 225), 3.0f);
    dl->AddText(ImVec2(mp.x + 15, mp.y - 2), IM_COL32(255, 255, 255, 245), buf);
}
