#pragma once
// ---------------------------------------------------------------------------
// xbm_audio.h -- Mikrofonaufnahme + Transkription fuer Linux, Windows, Android.
//
// AUFBAU
//   Mikrofon -> miniaudio (ALSA/PulseAudio | WASAPI | AAudio/OpenSL)
//            -> sperrfreier Ringpuffer (Audio-Callback schreibt NIE mit
//               Mutex, alloziert NIE und ruft NIE Nutzercode auf)
//            -> Abholung im UI-/Worker-Thread
//            -> WAV-Datei + optional whisper.cpp
//
// WARUM miniaudio und nicht Oboe: EIN Header fuer alle drei Plattformen,
// keine zusaetzliche Build-Abhaengigkeit, und miniaudio nutzt auf Android
// intern AAudio (mit OpenSL-Rueckfall). Oboe waere latenzseitig minimal
// besser -- fuer Sprachmemos ist das ohne Bedeutung, und die eine gemeinsame
// Codebasis ist hier mehr wert.
//
// WICHTIG (Android): RECORD_AUDIO ist eine Laufzeitberechtigung. Vor der
// ersten Aufnahme XbmAudio_EnsurePermission() rufen; die Erlaubnis kommt
// asynchron -- der erste Druck auf "Memo" kann also nur den Dialog oeffnen.
// ---------------------------------------------------------------------------
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

// Whisper mag 16 kHz Mono float32 -- genau das nehmen wir durchgaengig auf,
// dann entfaellt jedes Resampling.
inline constexpr int kXbmSampleRate = 16000;
inline constexpr int kXbmChannels   = 1;

struct XbmClip {
    std::vector<float> pcm;                 // Mono, -1..1
    int    sampleRate = kXbmSampleRate;
    double seconds() const {
        return sampleRate > 0 ? (double)pcm.size() / (double)sampleRate : 0.0;
    }
    bool empty() const { return pcm.empty(); }
};

// --- Geraet ---------------------------------------------------------------
bool        XbmAudio_Init();        // faul; mehrfach aufrufbar
void        XbmAudio_Shutdown();
bool        XbmAudio_Available();   // Geraet offen und brauchbar?
const char* XbmAudio_LastError();
const char* XbmAudio_BackendName();

// --- Berechtigung (nur Android relevant, sonst immer true) ----------------
enum class XbmPerm { Unknown, Granted, Denied, Pending };
XbmPerm XbmAudio_PermissionState();
void    XbmAudio_EnsurePermission();   // stoesst ggf. den Systemdialog an

// --- Aufnahme -------------------------------------------------------------
bool   XbmAudio_RecordStart();
XbmClip XbmAudio_RecordStop();      // stoppt und liefert das Aufgenommene
bool   XbmAudio_IsRecording();
double XbmAudio_RecordSeconds();
float  XbmAudio_Level();            // 0..1, geglaetteter RMS fuer die Anzeige
float  XbmAudio_PeakLevel();
// Obergrenze, damit ein klemmender Knopf nicht den Speicher frisst.
void   XbmAudio_SetMaxSeconds(double s);

// --- Nachbearbeitung ------------------------------------------------------
// Messwerte eines Clips -- fuer Anzeige und Fehlersuche unentbehrlich:
// damit laesst sich unterscheiden zwischen "Mikrofon liefert gar nichts"
// (Spitze nahe 0 -> Rechte, Geraet, Stummschaltung) und "leise, aber da"
// (Spitze klein, aber deutlich ueber dem Grundrauschen).
struct XbmClipStats {
    float peak      = 0.0f;   // groesster Betrag
    float rms       = 0.0f;   // Gesamtenergie
    float noiseFloor= 0.0f;   // geschaetztes Grundrauschen
    float threshold = 0.0f;   // daraus abgeleitete Sprachschwelle
    int   voicedMs  = 0;      // wie lange lag der Pegel darueber
};
XbmClipStats XbmAudio_Analyse(const XbmClip& clip);

// Schneidet Stille vorn/hinten weg. Die Schwelle wird aus dem
// GRUNDRAUSCHEN DES CLIPS SELBST abgeleitet, nicht fest vorgegeben.
// Liefert false, wenn nichts Sprachaehnliches gefunden wurde -- der Clip
// bleibt dann UNVERAENDERT (es wird nie alles weggeschnitten).
bool XbmAudio_TrimSilence(XbmClip& clip, double padSec = 0.15);
// Enthaelt der Clip Sprache? Ebenfalls mit angepasster Schwelle.
bool XbmAudio_HasSpeech(const XbmClip& clip);

// ---------------------------------------------------------------------------
// WIEDERGABE
//
// Eigenes Ausgabegeraet neben der Aufnahme -- beides kann gleichzeitig
// offen sein, ohne sich zu stoeren. Der Abspielkopf ist ein ATOMARER
// Rahmenzaehler: der Audio-Rueckruf liest ihn und schreibt ihn fort, die
// Oberflaeche darf ihn jederzeit lesen und durch Springen setzen. Damit
// braucht es keine Sperre im Echtzeitkontext.
// ---------------------------------------------------------------------------
bool   XbmAudio_PlayClip(const XbmClip& clip);        // startet von vorn
bool   XbmAudio_PlayFile(const std::string& wavPath); // laedt und startet
void   XbmAudio_PlayPause();     // Pause <-> weiter
void   XbmAudio_PlayStop();      // haelt an und springt an den Anfang
bool   XbmAudio_IsPlaying();     // laeuft gerade Ton?
bool   XbmAudio_IsPaused();      // geladen, aber angehalten
bool   XbmAudio_HasClip();       // ueberhaupt etwas geladen?
double XbmAudio_PlayPos();       // Abspielkopf in Sekunden
double XbmAudio_PlayLen();       // Gesamtlaenge in Sekunden
void   XbmAudio_PlaySeek(double seconds);
float  XbmAudio_PlayLevel();     // 0..1 fuer eine Pegelanzeige
// Welche Datei liegt gerade im Abspieler? Leer, wenn nichts geladen ist.
std::string XbmAudio_PlayName();

// Ordner, in den ein zur Laufzeit geholtes Modell gehoert -- und in dem
// als erstes gesucht wird. Damit muss die Oberflaeche den Ablageort nicht
// selbst kennen.
std::string XbmStt_ModelDir();
// Liegt diese Modelldatei schon vor? (Dateiname ohne Pfad.)
bool        XbmStt_HasModelFile(const char* datei);
// Nach einem Download erneut suchen.
void        XbmStt_RescanModel();
// AUSGEWAEHLTES Modell (Dateiname ohne Pfad). Leer = automatisch das
// erstbeste. Die Wahl wird neben den Modellen gesichert und ueberlebt
// den Neustart.
std::string XbmStt_ChosenModel();
void        XbmStt_ChooseModel(const std::string& datei);
// Ein vorhandenes Modell loeschen (Dateiname ohne Pfad).
bool        XbmStt_DeleteModel(const std::string& datei);

// --- WAV (eigener Minimalschreiber, kein libsndfile noetig) ---------------
bool XbmAudio_WriteWav(const std::string& path, const XbmClip& clip);
bool XbmAudio_ReadWav(const std::string& path, XbmClip& out);
// Beliebiges Format (WAV, MP3, FLAC, ...) ueber den miniaudio-Decoder, Mono f32 bei kXbmSampleRate.
bool XbmAudio_ReadAny(const std::string& path, XbmClip& out);

// ---------------------------------------------------------------------------
// Transkription
//
// Ist XBM_WITH_WHISPER nicht gesetzt, bleibt die Schnittstelle vollstaendig
// vorhanden und liefert leeren Text mit erklaerendem Status. Die App laeuft
// dadurch ueberall, auch ohne Modell -- und der Kalender speichert die
// Aufnahme trotzdem.
// ---------------------------------------------------------------------------
bool        XbmStt_Compiled();      // mit whisper.cpp gebaut?
bool        XbmStt_Ready();         // Modell geladen?
// Gibt eine KOPIE zurueck, keinen Zeiger.
// [Vorher const char* auf eine std::string, die der Arbeitsfaden
//  jederzeit neu setzt -- der UI-Faden las damit an einem Puffer, der
//  ihm unter den Fingern neu angelegt werden konnte. Der
//  Thread-Sanitizer hat den Wettlauf bestaetigt.]
std::string XbmStt_Status();
void        XbmStt_SetModelPath(const std::string& path);
std::string XbmStt_ModelPath();
void        XbmStt_SetLanguage(const std::string& lang);  // "de", "en", "auto"
std::string XbmStt_Language();

// Auftrag einreihen. onDone laeuft GARANTIERT im UI-Thread (ueber
// XbmSched_PostUi) -- der Aufrufer darf darin bedenkenlos ImGui-Zustand und
// Kalendereintraege anfassen.
std::uint64_t XbmStt_Submit(XbmClip clip,
                            std::function<void(std::string text, bool ok)> onDone);
std::size_t XbmStt_Queued();
bool        XbmStt_Busy();
void        XbmStt_Shutdown();
