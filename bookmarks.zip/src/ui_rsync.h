#pragma once
// ui_rsync.h -- Delta-Abgleich mit librsync.
//
// WAS DAS IST UND WAS NICHT:
// librsync liefert NUR den Algorithmus hinter rsync -- also die drei
// Schritte Signatur, Delta, Patch. Es spricht NICHT das rsync-Protokoll
// und kann sich mit keinem rsync-Server verbinden. Der Transport der
// drei Dateien ist deine Sache: HTTP (ui_net.h) oder SFTP (ui_sftp.h).
//
// DER ABLAUF (Datei vom Server holen, aber nur die Unterschiede):
//   1. Lokal:  UiRsSignature("alt.txt", "alt.sig")
//   2. Hoch:   alt.sig zum Server (SFTP-Upload oder HTTP-POST)
//   3. Server: rdiff delta alt.sig neu.txt neu.delta
//   4. Runter: neu.delta holen
//   5. Lokal:  UiRsPatch("alt.txt", "neu.delta", "neu.txt")
// Uebertragen wird nur die Signatur (klein) und das Delta (nur die
// Aenderungen) -- genau der Gewinn, den rsync ausmacht.
//
// IN DIE ANDERE RICHTUNG (lokale Datei zum Server bringen):
//   1. Server: rdiff signature fern.txt fern.sig  -> herunterladen
//   2. Lokal:  UiRsDelta("fern.sig", "meine.txt", "meine.delta")
//   3. Hoch:   meine.delta -- Server: rdiff patch fern.txt meine.delta ...
//
// OHNE Gegenstelle mit rdiff geht das nicht. Hast du auf dem Server nur
// einen reinen Dateizugriff (SFTP ohne Shell), bleibt der einfache Weg:
// die Datei ganz uebertragen.
#include "ui_files.h"
#include <string>
#include <cstdio>
#include <librsync.h>

// Ergebnis eines Schritts: leer = Erfolg, sonst die Fehlermeldung.
namespace ui_rsync_detail {

inline std::string Err(rs_result r, const char* was) {
    if (r == RS_DONE) return std::string();
    return std::string(was) + ": " + rs_strerror(r);
}

struct FileGuard {
    FILE* f = nullptr;
    ~FileGuard() { if (f) fclose(f); }
};

} // namespace ui_rsync_detail

// SCHRITT 1: Signatur der (alten) Datei erzeugen.
// Sie beschreibt die Datei blockweise und ist klein -- typisch weniger
// als ein Prozent der Datei.
inline std::string UiRsSignature(const std::string& baseName,
                                 const std::string& sigName) {
    using namespace ui_rsync_detail;
    FileGuard in, out;
    in.f = fopen(UiFilePath(baseName.c_str()).c_str(), "rb");
    if (!in.f) return "Nicht lesbar: " + baseName;
    out.f = fopen(UiFilePath(sigName.c_str()).c_str(), "wb");
    if (!out.f) return "Nicht schreibbar: " + sigName;

    // Blockgroesse und Pruefsummenlaenge passend zur Dateigroesse
    // waehlen -- das empfiehlt librsync ausdruecklich, sonst wird die
    // Signatur bei grossen Dateien unnoetig gross.
    fseek(in.f, 0, SEEK_END);
    rs_long_t fsize = (rs_long_t)ftell(in.f);
    fseek(in.f, 0, SEEK_SET);
    // 0 bedeutet "librsync waehlt" -- der Wert ist ein enum, deshalb
    // ausdruecklich umwandeln (C++ ist hier strenger als C).
    rs_magic_number magic = (rs_magic_number)0;
    size_t blockLen = 0, strongLen = 0;
    rs_result r = rs_sig_args(fsize, &magic, &blockLen, &strongLen);
    if (r != RS_DONE) return Err(r, "rs_sig_args");

    r = rs_sig_file(in.f, out.f, blockLen, strongLen, magic, nullptr);
    return Err(r, "rs_sig_file");
}

// SCHRITT 2: Delta aus fremder Signatur + eigener neuer Datei.
// Laeuft dort, wo die NEUE Fassung liegt.
inline std::string UiRsDelta(const std::string& sigName,
                             const std::string& newName,
                             const std::string& deltaName) {
    using namespace ui_rsync_detail;
    FileGuard sig, nw, dl;
    sig.f = fopen(UiFilePath(sigName.c_str()).c_str(), "rb");
    if (!sig.f) return "Nicht lesbar: " + sigName;

    rs_signature_t* sumset = nullptr;
    rs_result r = rs_loadsig_file(sig.f, &sumset, nullptr);
    if (r != RS_DONE) return Err(r, "rs_loadsig_file");
    // PFLICHT vor rs_delta_file -- ohne Hash-Tabelle findet der
    // Vergleich keine uebereinstimmenden Bloecke und das Delta waere
    // so gross wie die ganze Datei.
    r = rs_build_hash_table(sumset);
    if (r != RS_DONE) { rs_free_sumset(sumset); return Err(r, "rs_build_hash_table"); }

    nw.f = fopen(UiFilePath(newName.c_str()).c_str(), "rb");
    if (!nw.f) { rs_free_sumset(sumset); return "Nicht lesbar: " + newName; }
    dl.f = fopen(UiFilePath(deltaName.c_str()).c_str(), "wb");
    if (!dl.f) { rs_free_sumset(sumset); return "Nicht schreibbar: " + deltaName; }

    r = rs_delta_file(sumset, nw.f, dl.f, nullptr);
    rs_free_sumset(sumset);
    return Err(r, "rs_delta_file");
}

// SCHRITT 3: Alte Datei + Delta = neue Datei.
inline std::string UiRsPatch(const std::string& baseName,
                             const std::string& deltaName,
                             const std::string& outName) {
    using namespace ui_rsync_detail;
    FileGuard base, dl, out;
    base.f = fopen(UiFilePath(baseName.c_str()).c_str(), "rb");
    if (!base.f) return "Nicht lesbar: " + baseName;
    dl.f = fopen(UiFilePath(deltaName.c_str()).c_str(), "rb");
    if (!dl.f) return "Nicht lesbar: " + deltaName;

    // Erst in eine .part-Datei schreiben: Bricht der Patch ab, bleibt
    // die alte Fassung unangetastet.
    std::string finalPath = UiFilePath(outName.c_str());
    std::string tmpPath   = finalPath + ".part";
    out.f = fopen(tmpPath.c_str(), "wb");
    if (!out.f) return "Nicht schreibbar: " + outName;

    rs_result r = rs_patch_file(base.f, dl.f, out.f, nullptr);
    if (out.f) { fclose(out.f); out.f = nullptr; }
    if (r != RS_DONE) { remove(tmpPath.c_str()); return Err(r, "rs_patch_file"); }
    remove(finalPath.c_str());
    if (rename(tmpPath.c_str(), finalPath.c_str()) != 0) {
        remove(tmpPath.c_str());
        return "Umbenennen fehlgeschlagen: " + outName;
    }
    return std::string();
}

// Groesse einer Datei im Stammverzeichnis (fuer Anzeigen wie
// "Delta 12 KB statt 4 MB"). -1 = nicht lesbar.
inline long long UiRsFileSize(const std::string& name) {
    FILE* f = fopen(UiFilePath(name.c_str()).c_str(), "rb");
    if (!f) return -1;
    fseek(f, 0, SEEK_END);
    long long n = (long long)ftell(f);
    fclose(f);
    return n;
}
