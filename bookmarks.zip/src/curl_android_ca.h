#pragma once
// curl_android_ca.h
//
// Android-CA-Zertifikate fuer curl+mbedTLS zur LAUFZEIT verdrahten.
//
// Hintergrund: Seit Android 14 liegen die System-CAs nicht mehr unter
// /system/etc/security/cacerts (dort ist es auf neuen Geraeten LEER),
// sondern im Conscrypt-APEX: /apex/com.android.conscrypt/cacerts.
// Ein zur Compile-Zeit fest eingebrannter Pfad (CURL_CA_PATH) trifft
// also je nach Android-Version ins Leere -> mbedTLS laedt 0 CAs ->
// Handshake-Abbruch -> "SSL connect error" (CURLE 35).
//
// Nutzung: nach JEDEM curl_easy_init() einmal aufrufen:
//     CURL* curl = curl_easy_init();
//     ApplyAndroidCaPath(curl);
//
// Auf Desktop-Plattformen ist die Funktion ein No-op (dort gilt die
// System-Standard-Konfiguration von curl).

#include <curl/curl.h>

#if defined(__ANDROID__)
#include <sys/stat.h>
#endif

inline void ApplyAndroidCaPath(CURL* curl) {
#if defined(__ANDROID__)
    if (!curl) return;
    static const char* kCandidates[] = {
        "/apex/com.android.conscrypt/cacerts",   // Android 14+ (APEX)
        "/system/etc/security/cacerts",          // aeltere Android-Versionen
    };
    for (const char* dir : kCandidates) {
        struct stat st;
        if (stat(dir, &st) == 0 && S_ISDIR(st.st_mode)) {
            curl_easy_setopt(curl, CURLOPT_CAPATH, dir);
            curl_easy_setopt(curl, CURLOPT_CAINFO, (const char*)nullptr);
            return;
        }
    }
    // Kein Pfad gefunden: nichts setzen -- curl faellt auf die
    // Compile-Zeit-Defaults zurueck (bessere Fehlermeldung als Absturz).
#else
    (void)curl;
#endif
}
