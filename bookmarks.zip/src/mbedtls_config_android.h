/* mbedtls_config_android.h
 *
 * Eigene mbedTLS-Konfiguration fuer den Android-Build.
 *
 * Problem, das dies loest: "mbedTLS: ssl_init failed" direkt nach dem
 * TCP-Connect (mbedtls_ssl_config_defaults schlaegt fehl). Ursache war
 * eine inkonsistente Konfiguration -- mbedTLS und curl sahen unter-
 * schiedliche Feature-Defines. Diese Datei wird via -DMBEDTLS_CONFIG_FILE
 * SOWOHL beim Bau von mbedTLS ALS AUCH beim Bau von curl gesetzt, sodass
 * beide exakt dieselbe, vollstaendige Konfiguration verwenden.
 *
 * Ansatz: die vollstaendige, offiziell getestete Default-Config von
 * mbedTLS 3.6 einbinden und nur die zwei fuer uns noetigen Zusaetze
 * ergaenzen (Threading fuer den Multi-Thread-Fetch; alles andere ist im
 * Default bereits enthalten, inkl. TLS 1.2/1.3, X.509, alle gaengigen
 * Cipher-Suites und Kurven, die x.com/Cloudflare erwartet).
 */

/* Die komplette, von mbedTLS mitgelieferte Standard-Konfiguration.
 * Enthaelt TLS-Client, X.509-Verifikation, RSA/ECDSA, AES-GCM/ChaCha20,
 * die Standard-Kurven usw. -- also alles, was ein normaler HTTPS-Client
 * braucht. */
#include "mbedtls/mbedtls_config.h"

/* --- Zusaetze ueber den Default hinaus ----------------------------------- */

/* Threading: unsere Bookmarks werden in einem Worker-Thread geladen und
 * die Thumbnails in mehreren. mbedTLS braucht MBEDTLS_THREADING_C, damit
 * seine internen Mutexe existieren; MBEDTLS_THREADING_PTHREAD waehlt die
 * pthread-Implementierung (Android/Bionic hat pthreads). */
#ifndef MBEDTLS_THREADING_C
#define MBEDTLS_THREADING_C
#endif
#ifndef MBEDTLS_THREADING_PTHREAD
#define MBEDTLS_THREADING_PTHREAD
#endif

/* Zertifikats-Parsing aus einem Verzeichnis (CURLOPT_CAPATH):
 * mbedtls_x509_crt_parse_path wird von curl fuer den Android-CA-Store
 * (/apex/.../cacerts bzw. /system/etc/security/cacerts) benoetigt.
 * MBEDTLS_FS_IO ist im Default aktiv; sicherheitshalber erzwingen. */
#ifndef MBEDTLS_FS_IO
#define MBEDTLS_FS_IO
#endif
