// ---------------------------------------------------------------------------
// ui_titlebar.cpp -- siehe ui_titlebar.h.
// ---------------------------------------------------------------------------
#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif
#include "ui_titlebar.h"
#include "imgui_internal.h"

#include <cmath>

void (*UiTitleBar_ClaimGesture)() = nullptr;

namespace {

UiTitleBarHooks g_hooks;
bool  g_enabled = false;
bool  g_dragging = false;
ImVec2 g_dragRef{0, 0};

void Claim() { if (UiTitleBar_ClaimGesture) UiTitleBar_ClaimGesture(); }

// Die drei Zeichen malen wir selbst statt eine Schriftart mit Symbolen zu
// verlangen: eine Linie, ein Rechteck bzw. zwei Rechtecke, ein Kreuz. Das
// ist ein Dutzend Zeilen und macht die Leiste unabhaengig davon, welcher
// Zeichensatz gerade geladen ist (die App laedt je nach Plattform
// unterschiedliche).
void GlyphMinimize(ImDrawList* dl, ImVec2 c, float s, ImU32 col) {
    dl->AddLine(ImVec2(c.x - s, c.y + s * 0.6f),
                ImVec2(c.x + s, c.y + s * 0.6f), col, 1.6f);
}
void GlyphRestore(ImDrawList* dl, ImVec2 c, float s, ImU32 col) {
    // Zwei versetzte Rechtecke = "aus dem Vollbild zurueck".
    dl->AddRect(ImVec2(c.x - s, c.y - s * 0.4f),
                ImVec2(c.x + s * 0.4f, c.y + s), col, 0.0f, 0, 1.5f);
    dl->AddLine(ImVec2(c.x - s * 0.4f, c.y - s),
                ImVec2(c.x + s, c.y - s), col, 1.5f);
    dl->AddLine(ImVec2(c.x + s, c.y - s),
                ImVec2(c.x + s, c.y + s * 0.4f), col, 1.5f);
}
void GlyphMaximize(ImDrawList* dl, ImVec2 c, float s, ImU32 col) {
    dl->AddRect(ImVec2(c.x - s, c.y - s), ImVec2(c.x + s, c.y + s),
                col, 0.0f, 0, 1.6f);
}
void GlyphClose(ImDrawList* dl, ImVec2 c, float s, ImU32 col) {
    dl->AddLine(ImVec2(c.x - s, c.y - s), ImVec2(c.x + s, c.y + s), col, 1.8f);
    dl->AddLine(ImVec2(c.x + s, c.y - s), ImVec2(c.x - s, c.y + s), col, 1.8f);
}

// Ein Knopf der Leiste. Gibt true bei Klick zurueck.
bool BarButton(const char* id, ImVec2 pos, ImVec2 size, int glyph,
               bool danger) {
    ImGui::SetCursorScreenPos(pos);
    ImGui::InvisibleButton(id, size);
    const bool hov = ImGui::IsItemHovered();
    const bool act = ImGui::IsItemActive();
    const bool clk = ImGui::IsItemDeactivated() && hov;

    ImDrawList* dl = ImGui::GetWindowDrawList();
    if (hov || act) {
        // Schliessen wird rot -- die uebliche Erwartung, und es verhindert
        // versehentliches Zuklicken beim Zielen auf "Vollbild".
        const ImU32 bg = danger
            ? (act ? IM_COL32(190, 40, 40, 255) : IM_COL32(215, 60, 60, 255))
            : (act ? IM_COL32(255, 255, 255, 55) : IM_COL32(255, 255, 255, 32));
        dl->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), bg, 0.0f);
    }
    const ImVec2 c(pos.x + size.x * 0.5f, pos.y + size.y * 0.5f);
    const float s = 4.5f;
    const ImU32 col = (danger && (hov || act)) ? IM_COL32(255, 255, 255, 255)
                                               : ImGui::GetColorU32(ImGuiCol_Text);
    switch (glyph) {
        case 0: GlyphMinimize(dl, c, s, col); break;
        case 1: GlyphMaximize(dl, c, s, col); break;
        case 2: GlyphRestore(dl, c, s, col);  break;
        default: GlyphClose(dl, c, s, col);   break;
    }
    return clk;
}

}  // namespace

void UiTitleBar_SetHooks(const UiTitleBarHooks& h) { g_hooks = h; }
const UiTitleBarHooks& UiTitleBar_Hooks() { return g_hooks; }
void UiTitleBar_SetEnabled(bool on) { g_enabled = on; }
bool UiTitleBar_Enabled() { return g_enabled; }

float UiTitleBar_Height() {
    if (!g_enabled) return 0.0f;
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g || !g->Font) return 0.0f;
    return ImGui::GetTextLineHeight() + 12.0f;
}

bool UiTitleBar_Draw(const char* appName) {
    if (!g_enabled) return false;
    ImGuiViewport* vp = ImGui::GetMainViewport();
    if (!vp) return false;

    const float h = UiTitleBar_Height();
    ImGui::SetNextWindowPos(vp->Pos);
    ImGui::SetNextWindowSize(ImVec2(vp->Size.x, h));
    ImGui::SetNextWindowViewport(vp->ID);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));

    ImGui::Begin("##xbm_titlebar", nullptr,
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize
        | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar
        | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoCollapse
        | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoDocking
        | ImGuiWindowFlags_NoBringToFrontOnFocus);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 p0 = vp->Pos;
    const ImVec2 p1(p0.x + vp->Size.x, p0.y + h);
    // Deckender Streifen -- auch im Overlay-Betrieb, sonst schwebt die
    // Leiste unlesbar ueber dem Desktop.
    dl->AddRectFilled(p0, p1, IM_COL32(26, 28, 34, 245));
    dl->AddLine(ImVec2(p0.x, p1.y - 1), ImVec2(p1.x, p1.y - 1),
                IM_COL32(255, 255, 255, 28));

    const bool fs = g_hooks.isFullscreen ? g_hooks.isFullscreen() : false;

    // ---- Knoepfe rechts ----------------------------------------------
    const float bw = h * 1.45f;
    float x = p1.x - bw;
    bool clickedButton = false;

    if (g_hooks.close) {
        if (BarButton("##tb_close", ImVec2(x, p0.y), ImVec2(bw, h), 3, true)) {
            g_hooks.close(); clickedButton = true;
        }
        x -= bw;
    }
    if (g_hooks.setFullscreen) {
        if (BarButton("##tb_fs", ImVec2(x, p0.y), ImVec2(bw, h),
                      fs ? 2 : 1, false)) {
            g_hooks.setFullscreen(!fs); clickedButton = true;
        }
        ImGui::SetItemTooltip(fs ? "Fenstermodus" : "Vollbild");
        x -= bw;
    }
    if (g_hooks.minimize) {
        if (BarButton("##tb_min", ImVec2(x, p0.y), ImVec2(bw, h), 0, false)) {
            g_hooks.minimize(); clickedButton = true;
        }
        ImGui::SetItemTooltip("Zur Taskleiste minimieren");
        x -= bw;
    }

    // ---- Titel links --------------------------------------------------
    const float ty = p0.y + (h - ImGui::GetTextLineHeight()) * 0.5f;
    dl->AddText(ImVec2(p0.x + 10.0f, ty),
                ImGui::GetColorU32(ImGuiCol_Text),
                appName ? appName : "Anwendung");

    // ---- Ziehflaeche (alles links der Knoepfe) ------------------------
    // ZULETZT submittet: bei ueberlappenden Items gewinnt in ImGui das
    // ZUERST submittete den Druck. Stuende der breite Ziehbereich vor den
    // Knoepfen, waere keiner von ihnen mehr treffbar.
    const float dragW = x - p0.x;
    if (dragW > 4.0f) {
        ImGui::SetCursorScreenPos(p0);
        ImGui::InvisibleButton("##tb_drag", ImVec2(dragW, h));
        if (ImGui::IsItemActivated()) {
            g_dragging = true;
            g_dragRef = ImGui::GetIO().MousePos;
        }
        if (ImGui::IsItemActive() && g_dragging) {
            Claim();
            const ImVec2 mp = ImGui::GetIO().MousePos;
            const int dx = (int)std::lround(mp.x - g_dragRef.x);
            const int dy = (int)std::lround(mp.y - g_dragRef.y);
            // Im Vollbild wird nicht verschoben -- das Fenster deckt
            // ohnehin den Schirm, und ein Versatz waere nur ein schwarzer
            // Streifen am Rand.
            if ((dx || dy) && g_hooks.moveBy && !fs) {
                g_hooks.moveBy(dx, dy);
                // g_dragRef NICHT nachfuehren: der Zeiger bewegt sich mit
                // dem Fenster, die naechste Differenz ist wieder relativ
                // zum selben Bezugspunkt.
            }
        }
        if (ImGui::IsItemDeactivated()) g_dragging = false;
        if (ImGui::IsItemHovered() &&
            ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left) &&
            g_hooks.setFullscreen) {
            g_hooks.setFullscreen(!fs);
        }
    }

    ImGui::End();
    ImGui::PopStyleVar(3);
    return g_dragging || clickedButton;
}
