#pragma once
// ui_filetree.h -- aufklappbarer Dateibaum ab UiFilesBaseDir().
//
// WARUM ZWISCHENSPEICHER: Ein Verzeichnis wird 60x pro Sekunde neu zu
// lesen kostet auf Android spuerbar Zeit (jeder Eintrag ist ein
// syscall). Deshalb wird jeder Ordner NUR EINMAL gelesen -- und zwar
// erst, wenn er tatsaechlich aufgeklappt wird ("lazy loading"). Der
// Knopf "Neu laden" wirft den Speicher weg und liest frisch.
//
// BENUTZUNG (im Fenster "Prototype", Reiter "Bewerben"):
//     std::string gewaehlt;
//     if (UiFileTree("##dateien", &gewaehlt)) {
//         // gewaehlt = vollstaendiger Pfad der angeklickten Datei
//     }
#include "imgui.h"
#include "ui_files.h"
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <cstdio>

#if defined(_WIN32)
  #include <windows.h>
#else
  #include <dirent.h>
  #include <sys/stat.h>
#endif

namespace ui_filetree_detail {

struct Entry {
    std::string name;
    bool        isDir = false;
    long long   size  = 0;
};

// Ein gelesener Ordner. 'loaded' unterscheidet "leer" von "noch nicht
// gelesen" -- ohne das Feld wuerde ein leerer Ordner jeden Frame neu
// geoeffnet werden.
struct DirCache {
    std::vector<Entry> entries;
    bool               loaded = false;
    bool               ok     = true;    // false = nicht lesbar
};

inline std::map<std::string, DirCache>& Cache() {
    static std::map<std::string, DirCache> m;
    return m;
}

// Verzeichnis einlesen. Bewusst OHNE Ausnahmen/Abbruch: Ein nicht
// lesbarer Ordner (Rechte) liefert ok=false statt den Prozess zu
// beenden -- dieselbe Regel wie in ui_files.h.
inline void ReadDir(const std::string& path, DirCache& dc) {
    dc.entries.clear();
    dc.loaded = true;
    dc.ok     = false;
#if defined(_WIN32)
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA((path + "\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    dc.ok = true;
    do {
        std::string n = fd.cFileName;
        if (n == "." || n == "..") continue;
        Entry e;
        e.name  = n;
        e.isDir = (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
        e.size  = ((long long)fd.nFileSizeHigh << 32) | fd.nFileSizeLow;
        dc.entries.push_back(e);
    } while (FindNextFileA(h, &fd));
    FindClose(h);
#else
    DIR* d = opendir(path.c_str());
    if (!d) return;                      // z.B. keine Leserechte
    dc.ok = true;
    while (struct dirent* de = readdir(d)) {
        std::string n = de->d_name;
        if (n == "." || n == "..") continue;
        Entry e;
        e.name = n;
        // d_type ist nicht auf jedem Dateisystem gefuellt (DT_UNKNOWN),
        // deshalb im Zweifel nachfragen.
        std::string full = path + "/" + n;
        struct stat st;
        if (de->d_type == DT_DIR)       e.isDir = true;
        else if (de->d_type == DT_UNKNOWN && stat(full.c_str(), &st) == 0)
                                        e.isDir = S_ISDIR(st.st_mode);
        if (!e.isDir && stat(full.c_str(), &st) == 0)
            e.size = (long long)st.st_size;
        dc.entries.push_back(e);
    }
    closedir(d);
#endif
    // Ordner zuerst, dann alphabetisch (Gross/Klein egal).
    std::sort(dc.entries.begin(), dc.entries.end(),
              [](const Entry& a, const Entry& b) {
                  if (a.isDir != b.isDir) return a.isDir;
                  std::string x = a.name, y = b.name;
                  for (char& c : x) c = (char)tolower((unsigned char)c);
                  for (char& c : y) c = (char)tolower((unsigned char)c);
                  return x < y;
              });
}

inline DirCache& DirOf(const std::string& path) {
    DirCache& dc = Cache()[path];
    if (!dc.loaded) ReadDir(path, dc);
    return dc;
}

inline std::string HumanSize(long long b) {
    char buf[32];
    if (b < 1024)             snprintf(buf, sizeof(buf), "%lld B", b);
    else if (b < 1024 * 1024) snprintf(buf, sizeof(buf), "%.1f KB", b / 1024.0);
    else                      snprintf(buf, sizeof(buf), "%.1f MB",
                                       b / (1024.0 * 1024.0));
    return buf;
}

// Zeichnet einen Ordnerinhalt und ruft sich fuer Unterordner selbst auf.
inline bool DrawDir(const std::string& path, std::string* outSel,
                    const std::string& selected, int depth) {
    bool clicked = false;
    DirCache& dc = DirOf(path);
    if (!dc.ok) {
        ImGui::TextDisabled("(nicht lesbar)");
        return false;
    }
    if (dc.entries.empty()) {
        ImGui::TextDisabled("(leer)");
        return false;
    }
    for (const Entry& e : dc.entries) {
        std::string full = path + "/" + e.name;
        if (e.isDir) {
            ImGuiTreeNodeFlags f = ImGuiTreeNodeFlags_SpanAvailWidth
                                 | ImGuiTreeNodeFlags_OpenOnArrow
                                 | ImGuiTreeNodeFlags_OpenOnDoubleClick;
            // Der Ordnerinhalt wird ERST beim Aufklappen gelesen: der
            // rekursive Aufruf steht innerhalb von TreeNodeEx.
            if (ImGui::TreeNodeEx(("\xF0\x9F\x93\x81 " + e.name).c_str(), f)) {
                if (depth < 32)          // Schutz vor Symlink-Schleifen
                    clicked |= DrawDir(full, outSel, selected, depth + 1);
                else
                    ImGui::TextDisabled("(zu tief verschachtelt)");
                ImGui::TreePop();
            }
        } else {
            ImGuiTreeNodeFlags f = ImGuiTreeNodeFlags_Leaf
                                 | ImGuiTreeNodeFlags_NoTreePushOnOpen
                                 | ImGuiTreeNodeFlags_SpanAvailWidth;
            if (full == selected) f |= ImGuiTreeNodeFlags_Selected;
            ImGui::TreeNodeEx(("\xF0\x9F\x93\x84 " + e.name).c_str(), f);
            if (ImGui::IsItemClicked()) {
                if (outSel) *outSel = full;
                clicked = true;
            }
            ImGui::SameLine();
            ImGui::TextDisabled("%s", HumanSize(e.size).c_str());
        }
    }
    return clicked;
}

} // namespace ui_filetree_detail

// Wirft den Zwischenspeicher weg -- naechster Frame liest frisch.
inline void UiFileTreeRefresh() { ui_filetree_detail::Cache().clear(); }

// Zeichnet den Baum ab UiFilesBaseDir(). Rueckgabe true = eine Datei
// wurde angeklickt; ihr voller Pfad steht dann in *outSelected.
// root == nullptr bedeutet: ab UiFilesBaseDir().
inline bool UiFileTree(const char* id, std::string* outSelected = nullptr,
                       const char* root = nullptr) {
    using namespace ui_filetree_detail;
    std::string base = root ? std::string(root) : UiFilesBaseDir();
    if (base.empty()) base = ".";
    // Merkt sich die Auswahl ueber Frames hinweg (fuer die Hervorhebung).
    static std::map<std::string, std::string> s_sel;
    std::string& sel = s_sel[id ? id : "##filetree"];

    ImGui::PushID(id ? id : "##filetree");
    if (ImGui::SmallButton("Neu laden")) UiFileTreeRefresh();
    ImGui::SameLine();
    ImGui::TextDisabled("%s", base.c_str());
    ImGui::Separator();

    bool clicked = false;
    if (ImGui::BeginChild("##tree", ImVec2(0, 0), ImGuiChildFlags_Borders)) {
        clicked = DrawDir(base, &sel, sel, 0);
    }
    ImGui::EndChild();
    ImGui::PopID();

    if (clicked && outSelected) *outSelected = sel;
    return clicked;
}
