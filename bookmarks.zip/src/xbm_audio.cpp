// ---------------------------------------------------------------------------
// xbm_audio.cpp -- siehe xbm_audio.h.
// ---------------------------------------------------------------------------
#include "xbm_audio.h"
#include "xbm_sched.h"

#include <algorithm>
#include <atomic>
#include <condition_variable>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#if defined(_WIN32)
  #define WIN32_LEAN_AND_MEAN
  #include <windows.h>      // GetModuleFileNameA
#endif
#if !defined(_WIN32)
#include <unistd.h>   // readlink
#include <dirent.h>   // opendir/readdir -- Ordner nach Modellen durchsuchen
#include <sys/stat.h>
#endif
#include <deque>
#include <mutex>
#include <thread>

// miniaudio: EINE Uebersetzungseinheit definiert die Implementierung.
// Wir brauchen nur Aufnahme -- alles andere abschalten haelt die
// Uebersetzungszeit und die Binaergroesse im Rahmen.
// MA_NO_DECODING ist AUS: ma_decoder liest WAV, MP3, FLAC (und Vorbis ueber
// stb_vorbis, falls eingebunden) -- fuer das Tab Media.
#define MA_NO_ENCODING
#define MA_NO_GENERATION
#define MA_NO_RESOURCE_MANAGER
#define MA_NO_NODE_GRAPH
#define MA_NO_ENGINE
#define MINIAUDIO_IMPLEMENTATION
#include "miniaudio.h"

#if defined(XBM_WITH_WHISPER)
    #include "whisper.h"
#endif

#if defined(__ANDROID__)
// In main_android.cpp implementiert (JNI zur Activity).
bool XbmAndroid_HasMicPermission();
void XbmAndroid_RequestMicPermission();
#endif

namespace {

// ---------------------------------------------------------------------------
// Ringpuffer. Ein Schreiber (Audio-Callback), ein Leser -- deshalb reichen
// zwei atomare Indizes ohne Mutex. Der Callback laeuft im Echtzeitkontext
// des Audiotreibers: dort NIE allozieren, NIE sperren, NIE loggen.
// ---------------------------------------------------------------------------
constexpr std::size_t kRingFrames = kXbmSampleRate * 30;   // 30 s Reserve

struct Ring {
    std::vector<float>       buf;
    std::atomic<std::size_t> w{0};
    std::atomic<std::size_t> r{0};

    void reset() {
        if (buf.size() != kRingFrames) buf.assign(kRingFrames, 0.0f);
        w.store(0, std::memory_order_relaxed);
        r.store(0, std::memory_order_relaxed);
    }
    // Aus dem Audio-Callback.
    void push(const float* src, std::size_t n) {
        const std::size_t cap = buf.size();
        if (!cap || !src) return;
        std::size_t wi = w.load(std::memory_order_relaxed);
        // SCHREIBKOPF PRUEFEN, BEVOR geschrieben wird.
        // [Meldungen wie "malloc(): unaligned tcache chunk detected" oder
        //  "double free or corruption" kommen von der C-Bibliothek, wenn
        //  die Heap-Verwaltung schon BESCHAEDIGT ist -- also lange nach
        //  dem eigentlichen Fehler und meist an ganz anderer Stelle. Ein
        //  Schreibkopf ausserhalb des Puffers waere genau so ein Fall.
        //  Diese Pruefung kostet einen Vergleich je Aufruf (alle 20 ms)
        //  und macht aus einem spaeteren Raetselabsturz eine klare
        //  Meldung an der Quelle.]
        if (wi >= cap) {
            std::fprintf(stderr,
                "[audio] Schreibkopf ausserhalb des Ringpuffers "
                "(%zu >= %zu) -- zurueckgesetzt\n", wi, cap);
            wi = 0;
        }
        for (std::size_t i = 0; i < n; ++i) {
            buf[wi] = src[i];
            ++wi;
            if (wi >= cap) wi = 0;
        }
        w.store(wi, std::memory_order_release);
    }
    // Aus dem Anwendungsthread.
    std::size_t pop(std::vector<float>& out) {
        const std::size_t cap = buf.size();
        if (!cap) return 0;
        std::size_t wi = w.load(std::memory_order_acquire);
        std::size_t ri = r.load(std::memory_order_relaxed);
        // Dieselbe Absicherung fuer den LESEkopf.
        if (wi >= cap) wi = 0;
        if (ri >= cap) ri = 0;
        std::size_t n = 0;
        // Obergrenze: hoechstens einmal rundherum. Ohne sie liefe die
        // Schleife bei widerspruechlichen Zeigern endlos und haengte die
        // Oberflaeche auf.
        while (ri != wi && n <= cap) {
            out.push_back(buf[ri]);
            ++ri; if (ri >= cap) ri = 0;
            ++n;
        }
        r.store(ri, std::memory_order_release);
        return n;
    }
};

struct Audio {
    ma_context ctx{};
    ma_device  dev{};
    bool ctxOk = false;
    bool devOk = false;
    std::atomic<bool> recording{false};
    Ring ring;

    std::mutex        clipMtx;
    std::vector<float> clip;          // gesammelte Aufnahme
    double maxSeconds = 300.0;

    std::atomic<float> level{0.0f};   // geglaettet
    std::atomic<float> peak{0.0f};

    std::string lastError;
    std::string backend = "(nicht initialisiert)";
    XbmPerm perm = XbmPerm::Unknown;
};

Audio& A() { static Audio a; return a; }

void SetErr(const char* what, ma_result r) {
    char b[256];
    std::snprintf(b, sizeof(b), "%s: %s", what, ma_result_description(r));
    A().lastError = b;
    std::fprintf(stderr, "[audio] %s\n", b);
}

// --- Audio-Callback -- Echtzeitkontext, siehe Warnung oben ----------------
void OnCapture(ma_device* dev, void* /*out*/, const void* in, ma_uint32 frames) {
    (void)dev;
    if (!in || frames == 0) return;
    const float* src = (const float*)in;

    // Pegel fuer die Anzeige direkt hier bilden (billig, keine Allokation).
    float sum = 0.0f, pk = 0.0f;
    for (ma_uint32 i = 0; i < frames; ++i) {
        const float v = src[i];
        sum += v * v;
        const float a = v < 0 ? -v : v;
        if (a > pk) pk = a;
    }
    const float rms = std::sqrt(sum / (float)frames);
    // Exponentielle Glaettung: schnelles Ansteigen, traeges Abfallen --
    // sonst zappelt ein Pegelbalken unlesbar.
    const float prev = A().level.load(std::memory_order_relaxed);
    const float sm = rms > prev ? (prev * 0.4f + rms * 0.6f)
                                : (prev * 0.85f + rms * 0.15f);
    A().level.store(sm, std::memory_order_relaxed);
    if (pk > A().peak.load(std::memory_order_relaxed))
        A().peak.store(pk, std::memory_order_relaxed);

    if (A().recording.load(std::memory_order_acquire))
        A().ring.push(src, frames);
}

// Ringpuffer in die Aufnahme uebernehmen. Wird beim Pollen und beim Stoppen
// gerufen -- so bleibt der Ring immer weit unter seiner Kapazitaet.
void DrainRing() {
    std::lock_guard<std::mutex> lk(A().clipMtx);
    A().ring.pop(A().clip);
    const std::size_t maxN = (std::size_t)(A().maxSeconds * kXbmSampleRate);
    if (A().clip.size() > maxN) {
        A().clip.resize(maxN);
        A().recording.store(false);     // Notbremse
    }
}

// ---------------------------------------------------------------------------
// WAV (16 Bit PCM -- kleiner als float und von allem lesbar)
// ---------------------------------------------------------------------------
void put32(std::FILE* f, std::uint32_t v) { std::fwrite(&v, 4, 1, f); }
void put16(std::FILE* f, std::uint16_t v) { std::fwrite(&v, 2, 1, f); }
// Lesen mit ausgewertetem Rueckgabewert: abgeschnittene Dateien duerfen
// nicht stillschweigend Muell in die Felder schreiben.
template <class T> bool rd(std::FILE* f, T& v) {
    return std::fread(&v, sizeof(T), 1, f) == 1;
}

}  // namespace

// ---------------------------------------------------------------------------
// Geraet
// ---------------------------------------------------------------------------
bool XbmAudio_Init() {
    if (A().devOk) return true;
#if defined(__ANDROID__)
    if (!XbmAndroid_HasMicPermission()) {
        A().perm = XbmPerm::Pending;
        A().lastError = "Mikrofonberechtigung fehlt noch";
        return false;
    }
    A().perm = XbmPerm::Granted;
#else
    A().perm = XbmPerm::Granted;
#endif
    if (!A().ctxOk) {
        // ---- BACKENDS EINZELN UND IN FESTER REIHENFOLGE -----------------
        // [Mit ma_context_init(nullptr, 0, ...) probiert miniaudio ALLE
        //  eingebauten Backends in einem Rutsch durch -- auf Linux also
        //  PulseAudio, ALSA, JACK, sndio, OSS. Die Erkennung laedt dabei
        //  Fremdbibliotheken nach (dlopen) und fragt sie ab. Genau dort
        //  bricht es bei dir ab: das Protokoll zeigt "RecordStart: Anfang"
        //  und danach "double free or corruption (out)", die Zeile
        //  "[audio] Backend: ..." kommt NICHT mehr. Der Fehler liegt also
        //  in dieser Erkennung, noch bevor ein Geraet geoeffnet wird --
        //  in fremdem Code, den ich nicht reparieren kann.
        //
        //  Was ich tun kann: die Backends EINZELN probieren. Faellt eines
        //  aus, ist nur dieses betroffen, und das naechste kommt zum Zug.
        //  Mit XBM_AUDIO_BACKEND=alsa|pulse|jack|null laesst sich eines
        //  erzwingen -- damit ist der Absturz sofort umgehbar, ohne auf
        //  eine Korrektur in miniaudio zu warten.]
        struct Kandidat { const char* name; ma_backend b; };
        const Kandidat alle[] = {
        #if defined(__ANDROID__)
            { "aaudio",     ma_backend_aaudio     },
            { "opensl",     ma_backend_opensl     },
        #elif defined(_WIN32)
            { "wasapi",     ma_backend_wasapi     },
            { "dsound",     ma_backend_dsound     },
            { "winmm",      ma_backend_winmm      },
        #else
            // ALSA ZUERST, nicht PulseAudio.
            // [miniaudios Vorgabe probiert PulseAudio zuerst -- und genau
            //  dessen Erkennung stuerzt auf dem Zielsystem ab, noch bevor
            //  ein Geraet geoeffnet wird. ALSA ist auf jedem Linux
            //  vorhanden, und sein "default"-Geraet wird von PulseAudio
            //  ohnehin uebernommen, sobald PulseAudio laeuft: der Ton geht
            //  also weiterhin den gewohnten Weg, nur die riskante
            //  Erkennung entfaellt. Wer PulseAudio ausdruecklich will:
            //      XBM_AUDIO_BACKEND=pulse]
            { "alsa",       ma_backend_alsa       },
            { "pulse",      ma_backend_pulseaudio },
            { "jack",       ma_backend_jack       },
        #endif
            { "null",       ma_backend_null       },
        };

        const char* wunsch = std::getenv("XBM_AUDIO_BACKEND");
        bool ok = false;
        for (const Kandidat& k : alle) {
            if (wunsch && std::strcmp(wunsch, k.name) != 0) continue;
            std::fprintf(stderr, "[audio] versuche Backend: %s\n", k.name);
            std::fflush(stderr);
            ma_backend liste[1] = { k.b };
            if (ma_context_init(liste, 1, nullptr, &A().ctx) == MA_SUCCESS) {
                ok = true;
                break;
            }
            std::fprintf(stderr, "[audio]   %s nicht verfuegbar\n", k.name);
            std::fflush(stderr);
        }
        if (!ok) {
            A().lastError = "kein Audio-Backend verfuegbar";
            std::fprintf(stderr, "[audio] KEIN Backend verfuegbar\n");
            return false;
        }
        A().ctxOk = true;
        A().backend = ma_get_backend_name(A().ctx.backend);
        std::fprintf(stderr, "[audio] Backend: %s\n", A().backend.c_str());
        std::fflush(stderr);
    }

    ma_device_config cfg = ma_device_config_init(ma_device_type_capture);
    cfg.capture.format   = ma_format_f32;
    cfg.capture.channels = kXbmChannels;
    cfg.sampleRate       = kXbmSampleRate;
    cfg.dataCallback     = OnCapture;
    // Kleine Perioden = kurze Latenz beim Loslassen der Taste. 20 ms ist
    // fuer Sprachmemos ein guter Kompromiss und ueberall erreichbar.
    cfg.periodSizeInMilliseconds = 20;

    // ---- AUFNAHMEGERAETE AUFLISTEN UND WAEHLBAR MACHEN -----------------
    // [Dein Protokoll zeigt: 8.28 s aufgenommen, Spitze EXAKT 0.0000. Der
    //  Rueckruf lief also, aber das geoeffnete Geraet liefert Stille --
    //  ALSAs "default" zeigt bei dir auf etwas ohne Mikrofon. Bisher gab
    //  es keine Moeglichkeit, das zu sehen oder zu aendern: miniaudio
    //  nahm kommentarlos die Vorgabe.
    //
    //  Jetzt werden alle Aufnahmegeraete aufgelistet, und
    //      XBM_AUDIO_DEVICE=<nummer>   oder   XBM_AUDIO_DEVICE=<textteil>
    //  waehlt eines aus. Ohne Angabe bleibt es bei der Vorgabe.]
    ma_device_info* eingaenge = nullptr;
    ma_uint32 nEin = 0;
    ma_device_id* gewaehlt = nullptr;
    static ma_device_id merker;
    if (ma_context_get_devices(&A().ctx, nullptr, nullptr, &eingaenge, &nEin)
        == MA_SUCCESS && eingaenge && nEin > 0) {
        const char* wunsch = std::getenv("XBM_AUDIO_DEVICE");
        std::fprintf(stderr, "[audio] Aufnahmegeraete (%u):\n", (unsigned)nEin);
        for (ma_uint32 i = 0; i < nEin; ++i) {
            std::fprintf(stderr, "[audio]   [%u] %s%s\n", (unsigned)i,
                         eingaenge[i].name,
                         eingaenge[i].isDefault ? "  (Vorgabe)" : "");
            if (!wunsch) continue;
            bool treffer = false;
            if (wunsch[0] >= '0' && wunsch[0] <= '9')
                treffer = ((ma_uint32)std::atoi(wunsch) == i);
            else {
                // OHNE Ruecksicht auf Gross-/Kleinschreibung. [strstr ist
                //  streng: "Mikro" faende "MIKROFON" nicht. Bei einem
                //  Geraetenamen, den man abtippt, ist das nur laestig.]
                std::string a2(eingaenge[i].name), b2(wunsch);
                for (char& c : a2) if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
                for (char& c : b2) if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
                treffer = (a2.find(b2) != std::string::npos);
            }
            if (treffer && !gewaehlt) {
                merker = eingaenge[i].id;
                gewaehlt = &merker;
                std::fprintf(stderr, "[audio]   -> gewaehlt: [%u] %s\n",
                             (unsigned)i, eingaenge[i].name);
            }
        }
        std::fflush(stderr);
    }
    cfg.capture.pDeviceID = gewaehlt;

    ma_result r = ma_device_init(&A().ctx, &cfg, &A().dev);
    if (r != MA_SUCCESS) { SetErr("ma_device_init", r); return false; }
    A().devOk = true;
    std::fprintf(stderr, "[audio] Aufnahme laeuft ueber: %s (%u Hz, %u Kanaele)\n",
                 A().dev.capture.name,
                 (unsigned)A().dev.capture.internalSampleRate,
                 (unsigned)A().dev.capture.internalChannels);
    std::fflush(stderr);
    A().ring.reset();
    A().lastError.clear();
    return true;
}

// (XbmAudio_Shutdown steht am DATEIENDE -- es muss auch das
//  Wiedergabegeraet freigeben, und PL() ist erst weiter unten deklariert.)

bool        XbmAudio_Available()   { return A().devOk; }
const char* XbmAudio_LastError()   { return A().lastError.c_str(); }
const char* XbmAudio_BackendName() { return A().backend.c_str(); }

XbmPerm XbmAudio_PermissionState() {
#if defined(__ANDROID__)
    if (XbmAndroid_HasMicPermission()) A().perm = XbmPerm::Granted;
    return A().perm;
#else
    return XbmPerm::Granted;
#endif
}

void XbmAudio_EnsurePermission() {
#if defined(__ANDROID__)
    if (XbmAndroid_HasMicPermission()) { A().perm = XbmPerm::Granted; return; }
    A().perm = XbmPerm::Pending;
    XbmAndroid_RequestMicPermission();
#endif
}

// ---------------------------------------------------------------------------
// Aufnahme
// ---------------------------------------------------------------------------
// SCHRITTMARKEN.
// [Meldungen wie "free(): invalid pointer" kommen von der C-Bibliothek,
//  wenn die Heap-Verwaltung schon beschaedigt ist -- also NACH dem
//  eigentlichen Fehler und ohne Hinweis auf die Stelle. Diese Marken
//  kosten fuenf Zeilen je Aufnahme und zeigen, zwischen WELCHEN beiden
//  Schritten es abbricht. Damit laesst sich der Fehler eingrenzen, ohne
//  das Programm neu zu bauen.]
static void Marke(const char* s2) {
    std::fprintf(stderr, "[audio] %s\n", s2);
    std::fflush(stderr);
}

bool XbmAudio_RecordStart() {
    Marke("RecordStart: Anfang");
    if (A().recording.load()) { Marke("RecordStart: laeuft schon"); return true; }
    if (!XbmAudio_Init()) {
        Marke("RecordStart: Init fehlgeschlagen");
        XbmAudio_EnsurePermission();
        return false;
    }
    Marke("RecordStart: Init ok");
    {
        std::lock_guard<std::mutex> lk(A().clipMtx);
        A().clip.clear();
        A().clip.reserve(kXbmSampleRate * 8);
    }
    Marke("RecordStart: Clip bereit");
    A().ring.reset();
    Marke("RecordStart: Ring bereit");
    A().peak.store(0.0f);
    A().level.store(0.0f);
    ma_result r = ma_device_start(&A().dev);
    if (r != MA_SUCCESS) {
        Marke("RecordStart: device_start fehlgeschlagen");
        SetErr("ma_device_start", r);
        return false;
    }
    A().recording.store(true, std::memory_order_release);
    Marke("RecordStart: laeuft");
    return true;
}

XbmClip XbmAudio_RecordStop() {
    Marke("RecordStop: Anfang");
    XbmClip out;
    if (!A().devOk) { Marke("RecordStop: kein Geraet"); return out; }
    A().recording.store(false, std::memory_order_release);
    // Kurz nachlaufen lassen: der Treiber hat typischerweise noch eine
    // Periode im Flug. Ohne das fehlt regelmaessig die letzte Silbe.
    std::this_thread::sleep_for(std::chrono::milliseconds(40));
    Marke("RecordStop: nach Nachlauf");
    DrainRing();
    Marke("RecordStop: Ring geleert");
    ma_device_stop(&A().dev);
    Marke("RecordStop: Geraet gestoppt");
    {
        std::lock_guard<std::mutex> lk(A().clipMtx);
        out.pcm.swap(A().clip);
    }
    out.sampleRate = kXbmSampleRate;
    A().level.store(0.0f);
    // PEGEL AUF DIE KONSOLE.
    // [Die Messwerte gingen bisher nur in die Statuszeile und damit ins
    //  Protokollfenster -- im Terminal-Mitschnitt fehlten sie. Genau sie
    //  beantworten aber die Frage "nimmt das Mikrofon ueberhaupt etwas
    //  auf?": eine Spitze nahe null bedeutet, dass das geoeffnete Geraet
    //  Stille liefert (falsche Quelle, stummgeschaltet, fehlende
    //  Berechtigung) -- und nicht etwa, dass die Anzeige klemmt.]
    {
        const XbmClipStats st = XbmAudio_Analyse(out);
        std::fprintf(stderr,
            "[audio] RecordStop: %.2f s, Spitze %.4f, RMS %.4f, "
            "Rauschen %.4f, Stimme %d ms\n",
            out.seconds(), (double)st.peak, (double)st.rms,
            (double)st.noiseFloor, st.voicedMs);
        if (st.peak < 1.0e-3f)
            std::fprintf(stderr,
                "[audio] ACHTUNG: praktisch Stille -- das Geraet liefert "
                "kein Signal. Andere Quelle probieren:\n"
                "        XBM_AUDIO_BACKEND=pulse ./x_bookmark_manager\n");
        std::fflush(stderr);
    }
    Marke("RecordStop: fertig");
    return out;
}

bool XbmAudio_IsRecording() { return A().recording.load(); }

double XbmAudio_RecordSeconds() {
    if (A().recording.load()) DrainRing();
    std::lock_guard<std::mutex> lk(A().clipMtx);
    return (double)A().clip.size() / (double)kXbmSampleRate;
}

float XbmAudio_Level()     { return A().level.load(); }
float XbmAudio_PeakLevel() { return A().peak.load(); }
void  XbmAudio_SetMaxSeconds(double s) { if (s > 1.0) A().maxSeconds = s; }

// ---------------------------------------------------------------------------
// VAD / Trimmen
// ---------------------------------------------------------------------------
namespace {
// Fensterweise RMS -- robuster als Einzelwerte gegen Knackser.
void FrameRms(const XbmClip& c, std::vector<float>& out, std::size_t win) {
    out.clear();
    if (c.pcm.empty() || win == 0) return;
    for (std::size_t i = 0; i < c.pcm.size(); i += win) {
        const std::size_t n = (i + win <= c.pcm.size()) ? win : c.pcm.size() - i;
        float s = 0.0f;
        for (std::size_t k = 0; k < n; ++k) s += c.pcm[i + k] * c.pcm[i + k];
        out.push_back(std::sqrt(s / (float)n));
    }
}
}  // namespace

// ---------------------------------------------------------------------------
// WARUM DIE SCHWELLE NICHT MEHR FEST IST
//
// Vorher entschied ein FESTER Wert (0.012 RMS), ob eine Aufnahme ueberhaupt
// behalten wird. Das ist der Grund, warum die Sprachmemos auf ALLEN drei
// Plattformen "nicht funktionierten": viele Eingaenge liefern von Haus aus
// leise (Notebook-Mikrofone ohne Vorverstaerkung, AAudio ohne
// Verstaerkungsregelung, PulseAudio-Quellen auf 30 %). Der Pegel blieb dann
// unter der Schwelle, HasSpeech meldete "nur Stille", und der Kalender
// verwarf die Aufnahme kommentarlos. Ein leises Memo ist aber immer noch
// ein Memo.
//
// Jetzt kommt die Schwelle aus dem GRUNDRAUSCHEN DES CLIPS SELBST: als
// Rauschen gilt das 20%-Quantil der Fenster-Energien (die leisesten
// Fuenftel sind mit grosser Sicherheit Pause), Sprache muss das deutlich
// uebersteigen. Ob der Eingang mit 0.02 oder 0.6 arbeitet, ist damit egal.
//
// Und: NIE ETWAS WEGWERFEN. Findet die Erkennung nichts, bleibt der Clip
// unveraendert. Lieber ein Eintrag mit Rauschen als ein verlorener Gedanke.
// ---------------------------------------------------------------------------
XbmClipStats XbmAudio_Analyse(const XbmClip& clip) {
    XbmClipStats st;
    if (clip.pcm.empty()) return st;

    double sum = 0.0;
    for (float v : clip.pcm) {
        const float a = v < 0 ? -v : v;
        if (a > st.peak) st.peak = a;
        sum += (double)v * (double)v;
    }
    st.rms = (float)std::sqrt(sum / (double)clip.pcm.size());

    std::vector<float> frames;
    FrameRms(clip, frames, kXbmSampleRate / 50);      // 20-ms-Fenster
    if (frames.empty()) return st;

    std::vector<float> sorted = frames;
    std::sort(sorted.begin(), sorted.end());
    st.noiseFloor = sorted[sorted.size() / 5];        // 20%-Quantil

    // Faktor 3 ueber dem Rauschen. Die winzige Untergrenze faengt
    // "digitale Stille" ab, wo das Quantil 0 ist und jede Multiplikation
    // 0 bliebe.
    st.threshold = st.noiseFloor * 3.0f;
    if (st.threshold < 1.0e-4f) st.threshold = 1.0e-4f;

    int voiced = 0;
    for (float v : frames) if (v > st.threshold) ++voiced;
    st.voicedMs = voiced * 20;
    return st;
}

bool XbmAudio_HasSpeech(const XbmClip& clip) {
    const XbmClipStats st = XbmAudio_Analyse(clip);
    // Mindestens 100 ms ueber der Schwelle UND ueberhaupt ein Signal.
    // Liegt die Spitze bei praktisch null, hat das Geraet nichts geliefert.
    return st.voicedMs >= 100 && st.peak > 1.0e-3f;
}

bool XbmAudio_TrimSilence(XbmClip& clip, double padSec) {
    if (clip.pcm.empty()) return false;
    const XbmClipStats st = XbmAudio_Analyse(clip);

    const std::size_t win = kXbmSampleRate / 50;
    std::vector<float> rms;
    FrameRms(clip, rms, win);
    if (rms.empty()) return false;

    std::size_t first = rms.size(), last = 0;
    for (std::size_t i = 0; i < rms.size(); ++i) {
        if (rms[i] > st.threshold) { if (i < first) first = i; last = i; }
    }
    // NICHTS GEFUNDEN -> Clip UNVERAENDERT lassen (frueher wurde hier
    // faktisch alles verworfen).
    if (first > last) return false;

    const std::size_t pad = (std::size_t)(padSec * kXbmSampleRate);
    std::size_t a = first * win;
    std::size_t b = (last + 1) * win;
    a = (a > pad) ? a - pad : 0;
    b = (b + pad < clip.pcm.size()) ? b + pad : clip.pcm.size();
    if (b <= a) return false;                 // Sicherheitsnetz
    // UEBER EINEN ZWISCHENSPEICHER.
    // [Hier stand clip.pcm.assign(clip.pcm.begin()+a, clip.pcm.begin()+b) --
    //  also assign AUS DEN EIGENEN ITERATOREN. Der Standard erklaert das
    //  fuer ueberlappende Bereiche fuer undefiniert: assign darf den
    //  Puffer neu anlegen oder leeren, BEVOR es die Quelle liest, und
    //  liest dann aus freigegebenem Speicher. In der Praxis geht es
    //  meistens gut, weil die neue Groesse kleiner ist -- "meistens" ist
    //  aber genau die Sorte Fehler, die als "double free or corruption"
    //  irgendwo anders auffaellt. Der Zwischenspeicher kostet einmal
    //  Kopieren und nimmt die Frage vom Tisch.]
    std::vector<float> teil(clip.pcm.begin() + (long)a,
                            clip.pcm.begin() + (long)b);
    clip.pcm.swap(teil);
    return true;
}


// ---------------------------------------------------------------------------
// WIEDERGABE
// ---------------------------------------------------------------------------
namespace {

struct Player {
    ma_device dev{};
    bool devOk = false;
    std::vector<float> pcm;          // wird nur bei angehaltener Wiedergabe
                                     // ausgetauscht -- s. LadeClip()
    std::string name;
    std::atomic<std::size_t> cursor{0};   // Rahmen, ATOMAR
    std::atomic<bool> playing{false};
    std::atomic<bool> loaded{false};
    std::atomic<float> level{0.0f};
};
Player& PL() { static Player p; return p; }

// Ausgabe-Rueckruf: Echtzeitkontext -- keine Allokation, keine Sperre.
void OnPlayback(ma_device* dev, void* out, const void* in, ma_uint32 frames) {
    (void)dev; (void)in;
    float* dst = (float*)out;
    const std::size_t n = PL().pcm.size();
    std::size_t c = PL().cursor.load(std::memory_order_relaxed);

    if (!PL().playing.load(std::memory_order_acquire) || n == 0 || c >= n) {
        for (ma_uint32 i = 0; i < frames; ++i) dst[i] = 0.0f;
        PL().level.store(0.0f, std::memory_order_relaxed);
        if (c >= n && n > 0) PL().playing.store(false, std::memory_order_release);
        return;
    }
    float pk = 0.0f;
    for (ma_uint32 i = 0; i < frames; ++i) {
        float v = (c < n) ? PL().pcm[c++] : 0.0f;
        dst[i] = v;
        const float a = v < 0 ? -v : v;
        if (a > pk) pk = a;
    }
    PL().cursor.store(c, std::memory_order_release);
    const float prev = PL().level.load(std::memory_order_relaxed);
    PL().level.store(pk > prev ? pk : prev * 0.85f, std::memory_order_relaxed);
    if (c >= n) PL().playing.store(false, std::memory_order_release);
}

bool EnsurePlayDevice() {
    if (PL().devOk) return true;
    // Denselben Weg wie die Aufnahme nehmen -- der Kontext wird geteilt.
    if (!A().ctxOk && !XbmAudio_Init()) return false;
    ma_device_config cfg = ma_device_config_init(ma_device_type_playback);
    cfg.playback.format   = ma_format_f32;
    cfg.playback.channels = kXbmChannels;
    cfg.sampleRate        = kXbmSampleRate;
    cfg.dataCallback      = OnPlayback;
    cfg.periodSizeInMilliseconds = 20;
    ma_result r = ma_device_init(&A().ctx, &cfg, &PL().dev);
    if (r != MA_SUCCESS) {
        // ZWEITER VERSUCH MIT GERAETEVORGABEN.
        // [16 kHz Mono ist fuer eine AUFNAHME ueblich, fuer eine AUSGABE
        //  nicht: manche Windows-Geraete lehnen genau diese Kombination im
        //  gemeinsamen Modus ab. ma_device_init scheitert dann, PlayFile
        //  liefert false -- der Clip bleibt aber geladen, also zeigt die
        //  Leiste eine Laenge, und es kommt trotzdem kein Ton. Genau das
        //  gemeldete Bild. Mit sampleRate 0 waehlt miniaudio die Vorgabe
        //  des Geraets und rechnet selbst um.]
        // GERAETESTRUKTUR VORHER ZURUECKSETZEN.
        // [ma_device_init schreibt auch dann in die Struktur, wenn es
        //  scheitert -- Zeiger auf halb angelegte Puffer bleiben stehen.
        //  Ein zweiter Aufruf auf DERSELBEN Struktur arbeitet dann auf
        //  Resten und kann abstuerzen. Genau das Bild: der erste Druck auf
        //  Play reisst die App mit, nach einem Neustart klappt es (weil
        //  dann ein anderer Zweig greift). miniaudio erwartet eine frische
        //  Struktur -- also eine geben.]
        std::memset(&PL().dev, 0, sizeof(PL().dev));
        cfg.sampleRate = 0;
        cfg.playback.channels = 0;
        r = ma_device_init(&A().ctx, &cfg, &PL().dev);
        if (r != MA_SUCCESS) {
            SetErr("ma_device_init (Wiedergabe)", r);
            return false;
        }
        std::fprintf(stderr, "[audio] Wiedergabe mit Geraetevorgaben: "
                             "%u Hz, %u Kanaele\n",
                     (unsigned)PL().dev.playback.internalSampleRate,
                     (unsigned)PL().dev.playback.internalChannels);
    }
    PL().devOk = true;
    return true;
}

// Clip uebernehmen. Wird NUR mit angehaltener Wiedergabe aufgerufen,
// damit der Rueckruf nicht in einen Vektor greift, der gerade umzieht.
void LadeClip(const XbmClip& c, const std::string& nm) {
    PL().playing.store(false, std::memory_order_release);
    if (PL().devOk) ma_device_stop(&PL().dev);
    PL().pcm = c.pcm;
    PL().name = nm;
    PL().cursor.store(0, std::memory_order_release);
    PL().loaded.store(!PL().pcm.empty(), std::memory_order_release);
}

}  // namespace

bool XbmAudio_PlayClip(const XbmClip& clip) {
    if (clip.empty()) return false;
    // ERST LADEN, DANN das Geraet oeffnen.
    // [Vorher brach die Funktion ab, wenn kein Ausgabegeraet da war --
    //  der Clip blieb ungeladen, und die Oberflaeche konnte weder Laenge
    //  noch Position anzeigen. Ohne Ton ist die Aufnahme aber immer noch
    //  da; Regler und Zeitanzeige sollen funktionieren, und der Nutzer
    //  bekommt eine klare Meldung statt einer toten Leiste.]
    LadeClip(clip, "(Aufnahme)");
    if (!EnsurePlayDevice()) return false;
    PL().playing.store(true, std::memory_order_release);
    return ma_device_start(&PL().dev) == MA_SUCCESS;
}

bool XbmAudio_PlayFile(const std::string& wavPath) {
    XbmClip c;
    if (!XbmAudio_ReadWav(wavPath, c) || c.empty()) {
        A().lastError = "WAV nicht lesbar: " + wavPath;
        return false;
    }
    const std::size_t sl = wavPath.find_last_of("/\\\\");
    LadeClip(c, sl == std::string::npos ? wavPath : wavPath.substr(sl + 1));
    if (!EnsurePlayDevice()) return false;   // Clip bleibt geladen
    PL().playing.store(true, std::memory_order_release);
    return ma_device_start(&PL().dev) == MA_SUCCESS;
}

void XbmAudio_PlayPause() {
    if (!PL().loaded.load()) return;
    const bool lief = PL().playing.load();
    PL().playing.store(!lief, std::memory_order_release);
    if (!lief && PL().devOk) {
        // Am Ende stehengeblieben? Dann von vorn.
        if (PL().cursor.load() >= PL().pcm.size())
            PL().cursor.store(0, std::memory_order_release);
        ma_device_start(&PL().dev);
    }
}

void XbmAudio_PlayStop() {
    PL().playing.store(false, std::memory_order_release);
    PL().cursor.store(0, std::memory_order_release);
    if (PL().devOk) ma_device_stop(&PL().dev);
    PL().level.store(0.0f);
}

bool XbmAudio_IsPlaying() { return PL().playing.load(); }
bool XbmAudio_IsPaused()  { return PL().loaded.load() && !PL().playing.load(); }
bool XbmAudio_HasClip()   { return PL().loaded.load(); }
float XbmAudio_PlayLevel(){ return PL().level.load(); }
std::string XbmAudio_PlayName() { return PL().loaded.load() ? PL().name : std::string(); }

double XbmAudio_PlayPos() {
    return (double)PL().cursor.load() / (double)kXbmSampleRate;
}
double XbmAudio_PlayLen() {
    return (double)PL().pcm.size() / (double)kXbmSampleRate;
}
void XbmAudio_PlaySeek(double seconds) {
    if (seconds < 0.0) seconds = 0.0;
    std::size_t f = (std::size_t)(seconds * kXbmSampleRate);
    if (f > PL().pcm.size()) f = PL().pcm.size();
    PL().cursor.store(f, std::memory_order_release);
}

// ---------------------------------------------------------------------------
// WAV
// ---------------------------------------------------------------------------
bool XbmAudio_WriteWav(const std::string& path, const XbmClip& clip) {
    std::FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) return false;
    const std::uint32_t n     = (std::uint32_t)clip.pcm.size();
    const std::uint32_t bytes = n * 2;
    std::fwrite("RIFF", 1, 4, f);  put32(f, 36 + bytes);
    std::fwrite("WAVE", 1, 4, f);
    std::fwrite("fmt ", 1, 4, f);  put32(f, 16);
    put16(f, 1);                                    // PCM
    put16(f, (std::uint16_t)kXbmChannels);
    put32(f, (std::uint32_t)clip.sampleRate);
    put32(f, (std::uint32_t)(clip.sampleRate * kXbmChannels * 2));
    put16(f, (std::uint16_t)(kXbmChannels * 2));
    put16(f, 16);
    std::fwrite("data", 1, 4, f);  put32(f, bytes);
    for (std::uint32_t i = 0; i < n; ++i) {
        float v = clip.pcm[i];
        if (v >  1.0f) v =  1.0f;
        if (v < -1.0f) v = -1.0f;
        const std::int16_t s = (std::int16_t)(v * 32767.0f);
        std::fwrite(&s, 2, 1, f);
    }
    std::fclose(f);
    return true;
}

bool XbmAudio_ReadWav(const std::string& path, XbmClip& out) {
    std::FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) return false;
    char riff[4], wave[4];
    std::uint32_t sz = 0;
    if (std::fread(riff, 1, 4, f) != 4 || std::fread(&sz, 4, 1, f) != 1 ||
        std::fread(wave, 1, 4, f) != 4 ||
        std::memcmp(riff, "RIFF", 4) || std::memcmp(wave, "WAVE", 4)) {
        std::fclose(f); return false;
    }
    std::uint16_t channels = 1, bits = 16;
    std::uint32_t rate = kXbmSampleRate;
    bool haveFmt = false;
    for (;;) {
        char id[4]; std::uint32_t csz = 0;
        if (std::fread(id, 1, 4, f) != 4 || std::fread(&csz, 4, 1, f) != 1) break;
        if (!std::memcmp(id, "fmt ", 4)) {
            std::uint16_t fmt = 0, blockAlign = 0;
            std::uint32_t byteRate = 0;
            if (!rd(f, fmt) || !rd(f, channels) || !rd(f, rate) ||
                !rd(f, byteRate) || !rd(f, blockAlign) || !rd(f, bits)) break;
            if (channels == 0) break;
            if (csz > 16) std::fseek(f, (long)csz - 16, SEEK_CUR);
            haveFmt = true;
        } else if (!std::memcmp(id, "data", 4) && haveFmt && bits == 16) {
            const std::uint32_t frames = csz / 2 / (channels ? channels : 1);
            out.pcm.resize(frames);
            for (std::uint32_t i = 0; i < frames; ++i) {
                std::int32_t acc = 0;
                for (std::uint16_t c = 0; c < channels; ++c) {
                    std::int16_t s = 0; if (!rd(f, s)) { std::fclose(f); return false; }
                    acc += s;
                }
                out.pcm[i] = (float)acc / (float)(channels * 32768);
            }
            out.sampleRate = (int)rate;
            std::fclose(f);
            return true;
        } else {
            std::fseek(f, (long)csz + (csz & 1), SEEK_CUR);
        }
    }
    std::fclose(f);
    return false;
}

// ---------------------------------------------------------------------------
// Transkription
// ---------------------------------------------------------------------------
namespace {

struct SttJob {
    std::uint64_t id;
    XbmClip clip;
    std::function<void(std::string, bool)> done;
};

struct Stt {
    std::thread worker;
    std::mutex mtx;
    std::condition_variable cv;
    std::deque<SttJob> queue;
    std::atomic<bool> running{false};
    std::atomic<bool> busy{false};
    std::atomic<std::uint64_t> nextId{1};
    std::string modelPath;
    std::string gesucht;   // zuletzt gepruefte Orte, fuer die Meldung
    std::atomic<bool> rescan{false};  // Wunsch: Modell neu suchen
    // Schuetzt status / modelPath / gesucht: der Arbeitsfaden schreibt
    // sie, der UI-Faden liest sie jeden Frame.
    std::mutex        txtMtx;
    std::string language = "de";
    std::string status =
#if defined(XBM_WITH_WHISPER)
        "bereit (Modell noch nicht geladen)";
#else
        "ohne whisper.cpp gebaut -- Aufnahme wird gespeichert, "
        "aber nicht transkribiert";
#endif
#if defined(XBM_WITH_WHISPER)
    whisper_context* ctx = nullptr;
#endif
};

Stt& T() { static Stt s; return s; }

#if defined(XBM_WITH_WHISPER)
// Modelldatei suchen. [Bisher galt genau EIN gesetzter Pfad; stimmte er
//  nicht, hiess es nur "Modell konnte nicht geladen werden", ohne zu
//  sagen, wo gesucht wurde. Jetzt werden mehrere uebliche Namen und Orte
//  probiert, und die Statuszeile nennt im Fehlerfall die Liste.]
std::string SucheModell(const std::string& gesetzt) {
    std::vector<std::string> kandidaten;
    if (!gesetzt.empty()) {
        kandidaten.push_back(gesetzt);

    }
    if (const char* env = std::getenv("XBM_WHISPER_MODEL"))
        kandidaten.insert(kandidaten.begin(), env);
    // AUSDRUECKLICHE WAHL hat Vorrang vor allem anderen.
    {
        const std::string wahl = XbmStt_ChosenModel();
        if (!wahl.empty())
            kandidaten.insert(kandidaten.begin(),
                              XbmStt_ModelDir() + "/" + wahl);
    }

    // WEITERE ORTE, an denen das Modell realistisch liegt.
    // [Bisher wurde nur der eine gesetzte Pfad geprueft, auf Android also
    //  ausschliesslich /data/user/0/<paket>/files/. Dorthin kommt man ohne
    //  gerootetes Geraet nur ueber "adb push" in Verbindung mit
    //  "run-as" -- fuer den Alltag zu umstaendlich. Ein Modell im
    //  Download-Ordner oder im mitgelieferten Datenbaum ist der weit
    //  naheliegendere Fall, deshalb wird dort mitgesucht.]
    const char* namen[] = { "ggml-base.bin", "ggml-base.de.bin",
                            "ggml-small.bin", "ggml-tiny.bin",
                            "ggml-medium.bin" };
    std::vector<std::string> orte;
    if (!gesetzt.empty()) {
        const std::size_t sl2 = gesetzt.find_last_of("/\\");
        if (sl2 != std::string::npos) {
            const std::string d = gesetzt.substr(0, sl2);
            orte.push_back(d);            // <daten>
            orte.push_back(d + "/models");
            orte.push_back(d + "/data/models");
        }
    }
#if defined(__ANDROID__)
    // ---- APP-EIGENER EXTERNER ORDNER -------------------------------------
    // /sdcard/Android/data/<paket>/files/
    // Das ist der einzige Ort ausserhalb des internen Datenordners, an den
    // die App OHNE JEDE BERECHTIGUNG herankommt -- und den zugleich
    //     adb push datei /sdcard/Android/data/<paket>/files/
    // ohne "run-as" befuellen kann.
    //
    // [/sdcard/Download stand hier vorher und ist WERTLOS: seit Android 11
    //  (Scoped Storage) darf eine App dort nicht mehr frei lesen, und weil
    //  .bin keine Mediendatei ist, hilft auch READ_MEDIA_* nicht. Der
    //  Eintrag hat nur die Fehlermeldung verlaengert.]
    //
    // Den Paketnamen liefert /proc/self/cmdline -- dort steht auf Android
    // der Prozessname, und der ist der Paketname. Damit braucht es weder
    // JNI noch eine Aenderung an main_android.cpp.
    {
        std::string paket;
        if (std::FILE* f = std::fopen("/proc/self/cmdline", "rb")) {
            char b[256] = {0};
            const std::size_t n = std::fread(b, 1, sizeof(b) - 1, f);
            std::fclose(f);
            for (std::size_t i = 0; i < n && b[i]; ++i) paket += b[i];
            // Nebenprozesse heissen "<paket>:dienst" -- den Zusatz weg.
            const std::size_t dp = paket.find(':');
            if (dp != std::string::npos) paket = paket.substr(0, dp);
            // Ein PFAD ist kein Paketname. [Auf Android steht in cmdline
            //  der Paketname; laeuft die Datei aber einmal woanders (Test,
            //  anderer Starter), stuende dort ein Pfad wie /data/local/tmp/x
            //  -- daraus wuerde /sdcard/Android/data//data/local/tmp/x/files.
            //  Harmlos, aber es verlaengert die Fehlermeldung um Unsinn.]
            if (paket.find('/') != std::string::npos) paket.clear();
        }
        if (!paket.empty()) {
            const std::string ext = "/sdcard/Android/data/" + paket + "/files";
            orte.push_back(ext);
            orte.push_back(ext + "/models");
            const std::string ext2 =
                "/storage/emulated/0/Android/data/" + paket + "/files";
            orte.push_back(ext2);
            orte.push_back(ext2 + "/models");
        }
    }
#endif
    // NEBEN DEM PROGRAMM suchen. [Bisher wurde nur vom eingestellten Pfad
    //  ausgegangen -- auf Linux ist das der Ordner der xbm.ini, also
    //  ~/.config. Dorthin legt niemand freiwillig eine 148-MB-Datei. Neben
    //  der ausfuehrbaren Datei ist der naheliegende Ort, und im
    //  Datenordner daneben ebenso.]
#if !defined(__ANDROID__)
    {
        char exe[1024] = {0};
    #if defined(_WIN32)
        // [Hier stand eine "extern C"-Deklaration INNERHALB der Funktion.
        //  Eine Bindungsangabe ist nur auf Namensraum-Ebene erlaubt --
        //  clang meldet dafuer "expected unqualified-id". Der Header
        //  gehoert nach oben, nicht die Deklaration hierher.]
        const std::size_t n = ::GetModuleFileNameA(nullptr, exe,
                                                   (unsigned long)sizeof(exe) - 1);
    #else
        const long n0 = ::readlink("/proc/self/exe", exe, sizeof(exe) - 1);
        const std::size_t n = (n0 > 0) ? (std::size_t)n0 : 0;
    #endif
        if (n > 0) {
            exe[n] = 0;
            std::string p2(exe);
            const std::size_t sl4 = p2.find_last_of("/\\");
            if (sl4 != std::string::npos) {
                const std::string d = p2.substr(0, sl4);
                orte.push_back(d);
                orte.push_back(d + "/models");
                orte.push_back(d + "/data/models");
            }
        }
    }
#endif
    orte.push_back("models");
    orte.push_back(".");
    for (const auto& d : orte)
        for (const char* n : namen)
            kandidaten.push_back(d + "/" + n);

    // ---- ORDNER DURCHSUCHEN statt Namen raten ---------------------------
    // [Bisher wurden fuenf feste Dateinamen geprueft. Heisst die Datei
    //  anders -- ggml-base.en.bin, ggml-large-v3-turbo.bin, base.bin oder
    //  einfach modell.bin -- wird sie uebersehen, obwohl sie im richtigen
    //  Ordner liegt. Und die Fehlermeldung behauptet dann, es sei nichts
    //  da. Jede .bin-Datei ab 10 MB in diesen Ordnern ist als Modell
    //  plausibel; kleinere sind mit Sicherheit keine.]
    for (const auto& d : orte) {
        std::vector<std::string> gefunden;
#if defined(_WIN32)
        WIN32_FIND_DATAA fd;
        const std::string muster = d + "\\*.bin";
        HANDLE h = FindFirstFileA(muster.c_str(), &fd);
        if (h != INVALID_HANDLE_VALUE) {
            do {
                if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
                const unsigned long long gr =
                    ((unsigned long long)fd.nFileSizeHigh << 32) | fd.nFileSizeLow;
                if (gr >= 10ull * 1024 * 1024)
                    gefunden.push_back(d + "/" + fd.cFileName);
            } while (FindNextFileA(h, &fd));
            FindClose(h);
        }
#else
        if (DIR* dir = ::opendir(d.c_str())) {
            while (struct dirent* de = ::readdir(dir)) {
                const std::string nm(de->d_name);
                if (nm.size() < 5) continue;
                if (nm.compare(nm.size() - 4, 4, ".bin") != 0) continue;
                const std::string voll = d + "/" + nm;
                struct stat st2;
                if (::stat(voll.c_str(), &st2) == 0 && S_ISREG(st2.st_mode)
                    && st2.st_size >= 10L * 1024 * 1024)
                    gefunden.push_back(voll);
            }
            ::closedir(dir);
        }
#endif
        // Groesste zuerst: das groessere Modell ist in aller Regel das
        // bessere, und wer zwei ablegt, meint vermutlich das groessere.
        std::sort(gefunden.begin(), gefunden.end());
        for (const auto& g : gefunden) kandidaten.push_back(g);
    }
    // Doppelte Eintraege entfernen -- der gesetzte Pfad steht sonst
    // zweimal in der Liste und damit auch zweimal in der Fehlermeldung.
    {
        std::vector<std::string> eindeutig;
        for (const auto& k : kandidaten) {
            bool schon = false;
            for (const auto& e : eindeutig) if (e == k) { schon = true; break; }
            if (!schon) eindeutig.push_back(k);
        }
        kandidaten.swap(eindeutig);
    }
    for (const auto& k : kandidaten) {
        if (std::FILE* f = std::fopen(k.c_str(), "rb")) { std::fclose(f); return k; }
    }
    // Die geprueften Orte merken -- die Fehlermeldung soll sie nennen
    // koennen, sonst raet man, wo die Datei hingehoert.
    std::string gesuchtLokal;
    // Nur die ERSTEN JE ORDNER zeigen: 40 Zeilen mit fuenf
    // Modellnamen je Ordner sind unlesbar und verdecken, WELCHE
    // Ordner ueberhaupt geprueft wurden -- und genau das ist die
    // Information, die man braucht.
    std::vector<std::string> ordner;
    for (const auto& k : kandidaten) {
        const std::size_t sl3 = k.find_last_of("/\\");
        std::string d = (sl3 == std::string::npos) ? std::string(".")
                                                   : k.substr(0, sl3);
        bool schon = false;
        for (const auto& o : ordner) if (o == d) { schon = true; break; }
        if (!schon) ordner.push_back(d);
    }
    // ORDNER MIT ZUSTAND melden.
    // [Die blosse Liste sagt nicht, ob ein Ordner ueberhaupt existiert.
    //  Wer die Datei "nach models/" legt, obwohl es den Ordner nicht gibt,
    //  sucht sonst lange. Zusaetzlich wird gezaehlt, wie viele .bin-Dateien
    //  darin liegen -- steht dort "1 .bin, aber zu klein", ist die Lage
    //  sofort klar.]
    for (std::size_t i = 0; i < ordner.size(); ++i) {
        if (!gesuchtLokal.empty()) gesuchtLokal += "\n  ";
        std::string zusatz;
#if defined(_WIN32)
        {
            const DWORD att = GetFileAttributesA(ordner[i].c_str());
            zusatz = (att == INVALID_FILE_ATTRIBUTES)
                   ? "   (Ordner fehlt)" : "";
        }
#else
        {
            struct stat sd;
            if (::stat(ordner[i].c_str(), &sd) != 0 || !S_ISDIR(sd.st_mode)) {
                zusatz = "   (Ordner fehlt)";
            } else if (DIR* dd = ::opendir(ordner[i].c_str())) {
                int bins = 0, klein = 0;
                while (struct dirent* de2 = ::readdir(dd)) {
                    const std::string nm2(de2->d_name);
                    if (nm2.size() < 5) continue;
                    if (nm2.compare(nm2.size() - 4, 4, ".bin") != 0) continue;
                    ++bins;
                    struct stat s3;
                    if (::stat((ordner[i] + "/" + nm2).c_str(), &s3) == 0
                        && s3.st_size < 10L * 1024 * 1024) ++klein;
                }
                ::closedir(dd);
                if (bins > 0) {
                    zusatz = "   (" + std::to_string(bins) + " .bin";
                    if (klein > 0)
                        zusatz += ", " + std::to_string(klein)
                                + " davon unter 10 MB und damit ignoriert";
                    zusatz += ")";
                }
            }
        }
#endif
        gesuchtLokal += ordner[i] + "/*.bin" + zusatz;
    }

    {   // Ergebnis erst am Ende UNTER DER SPERRE ablegen.
        // [gesucht wurde stueckweise im Arbeitsfaden zusammengebaut und
        //  gleichzeitig fuer die Meldung gelesen -- der Thread-Sanitizer
        //  meldete dort ein "Write of size 8" mitten in einem
        //  operator delete, also einen String, der neu angelegt wird,
        //  waehrend ein anderer Faden ihn haelt.]
        std::lock_guard<std::mutex> lk(T().txtMtx);
        T().gesucht = gesuchtLokal;
    }
    return std::string();
}

bool EnsureModel() {
    if (T().ctx) return true;
    const std::string pfad = SucheModell(T().modelPath);
    if (pfad.empty()) {
        std::printf("[stt] KEIN MODELL gefunden, gesucht ab: %s\n",
                    T().modelPath.c_str());
        std::fflush(stdout);
        // ZIELORDNER + FERTIGER BEFEHL.
        // [Die Ordnerliste allein hat drei Runden lang nicht geholfen:
        //  sie sagt, WO gesucht wird, aber nicht, dass die Datei
        //  ueberhaupt erst besorgt werden muss und wie. Das Modell wird
        //  bewusst nicht mitgeliefert (148 MB), es ist also ein
        //  einmaliger Schritt -- der aber niemandem einfaellt, wenn ihn
        //  nichts nennt.]
        std::string ziel;
        { std::lock_guard<std::mutex> lk(T().txtMtx); ziel = T().modelPath; }
        {
            const std::size_t sl5 = ziel.find_last_of("/\\");
            ziel = (sl5 == std::string::npos) ? std::string(".")
                                              : ziel.substr(0, sl5);
        }
        std::lock_guard<std::mutex> lk(T().txtMtx);
        T().status =
            "kein Modell gefunden.\n\n"
            "Das Sprachmodell wird NICHT mitgeliefert (zu gross) und muss\n"
            "einmalig geholt werden. Danach laeuft alles offline.\n\n"
            "  curl -L -o \"" + ziel + "/ggml-tiny.bin\" \\\n"
            "       https://huggingface.co/ggerganov/whisper.cpp/"
            "resolve/main/ggml-tiny.bin\n\n"
            "(ggml-tiny.bin ~75 MB, ggml-base.bin ~148 MB und deutlich\n"
            " genauer -- im Befehl einfach tiny durch base ersetzen.)\n\n"
            "Gesucht wurde in:\n  " + T().gesucht;
        return false;
    }
    { std::lock_guard<std::mutex> lk(T().txtMtx); T().modelPath = pfad; }
    whisper_context_params cp = whisper_context_default_params();
    T().ctx = whisper_init_from_file_with_params(T().modelPath.c_str(), cp);
    if (!T().ctx) {
        { std::lock_guard<std::mutex> lk(T().txtMtx);
      T().status = "Modell nicht ladbar (beschaedigt oder falsches Format): "
                   + T().modelPath; }
        return false;
    }
    { std::lock_guard<std::mutex> lk(T().txtMtx);
      T().status = "Modell geladen: " + T().modelPath; }
    std::printf("[stt] Modell geladen: %s\n", T().modelPath.c_str());
    std::fflush(stdout);
    return true;
}

std::string RunWhisper(const XbmClip& clip, bool& ok) {
    ok = false;
    if (!EnsureModel()) return {};
    whisper_full_params wp = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    wp.print_progress   = false;
    wp.print_special    = false;
    wp.print_realtime   = false;
    wp.print_timestamps = false;
    wp.translate        = false;
    wp.no_context       = true;
    wp.single_segment   = false;
    wp.language = T().language == "auto" ? nullptr : T().language.c_str();
    // Faden zaehmen: hoechstens 4, und nie mehr als die Haelfte der Kerne --
    // sonst konkurriert die Transkription mit dem Renderthread und die
    // Oberflaeche ruckelt sichtbar waehrend des Tippens.
    int hw = (int)std::thread::hardware_concurrency();
    wp.n_threads = hw > 2 ? (hw / 2 > 4 ? 4 : hw / 2) : 1;

    if (whisper_full(T().ctx, wp, clip.pcm.data(), (int)clip.pcm.size()) != 0) {
        { std::lock_guard<std::mutex> lk(T().txtMtx);
      T().status = "whisper_full fehlgeschlagen"; }
        return {};
    }
    std::string text;
    const int n = whisper_full_n_segments(T().ctx);
    for (int i = 0; i < n; ++i) {
        const char* s = whisper_full_get_segment_text(T().ctx, i);
        if (s) text += s;
    }
    // Fuehrende Leerzeichen, die whisper gern voranstellt, weg.
    std::size_t a = text.find_first_not_of(" \t\n\r");
    if (a == std::string::npos) text.clear();
    else text = text.substr(a);
    { std::lock_guard<std::mutex> lk(T().txtMtx);
      T().status = "fertig"; }
    ok = true;
    return text;
}
#endif  // XBM_WITH_WHISPER

void SttWorker() {
    for (;;) {
        SttJob job;
        {
            std::unique_lock<std::mutex> lk(T().mtx);
            T().cv.wait(lk, [] { return !T().queue.empty() || !T().running.load(); });
            if (!T().running.load() && T().queue.empty()) return;
            job = std::move(T().queue.front());
            T().queue.pop_front();
        }
        T().busy.store(true);
        std::printf("[stt] 3 Auftrag angenommen\n"); std::fflush(stdout);
        // Neusuche-Wunsch HIER einloesen: nur dieser Faden fasst den
        // Kontext an, und gerade laeuft kein whisper-Aufruf.
        if (T().rescan.exchange(false, std::memory_order_acq_rel)) {
#if defined(XBM_WITH_WHISPER)
            if (T().ctx) { whisper_free(T().ctx); T().ctx = nullptr; }
#endif
            std::printf("[stt] Modell wird neu gesucht\n"); std::fflush(stdout);
        }
        std::string text;
        bool ok = false;
#if defined(XBM_WITH_WHISPER)
        try { text = RunWhisper(job.clip, ok); } catch (...) { ok = false; }
#else
        // Ohne whisper: klar und ehrlich melden statt still nichts zu tun.
        ok = false;
#endif
        T().busy.store(false);
        // Status UNTER DER SPERRE kopieren, bevor er ins Protokoll geht.
        // [printf hielt den Zeiger auf eine std::string, die ein anderer
        //  Faden gleichzeitig neu setzen kann.]
        std::string statusKopie = XbmStt_Status();
        std::printf("[stt] 4 Lauf beendet: ok=%d, %zu Zeichen, Status='%s'\n",
                    (int)ok, text.size(), statusKopie.c_str());
        std::fflush(stdout);
        if (job.done) {
            auto cb = job.done;
            // UI-Thread: der Aufrufer schreibt damit gefahrlos in Kalender
            // und ImGui-Zustand.
            std::printf("[stt] 5 an die UI-Warteschlange gereicht\n");
            std::fflush(stdout);
            XbmSched_PostUi([cb, text, ok] {
                std::printf("[stt] 6 im UI-Faden ausgefuehrt (%zu Zeichen)\n",
                            text.size());
                std::fflush(stdout);
                cb(text, ok);
            });
        }
    }
}

void EnsureSttThread() {
    if (T().running.load()) return;
    T().running.store(true);
    std::printf("[stt] 2 Arbeitsfaden gestartet\n"); std::fflush(stdout);
    T().worker = std::thread(SttWorker);
}

}  // namespace

bool XbmStt_Compiled() {
#if defined(XBM_WITH_WHISPER)
    return true;
#else
    return false;
#endif
}

bool XbmStt_Ready() {
#if defined(XBM_WITH_WHISPER)
    return T().ctx != nullptr;
#else
    return false;
#endif
}

std::string XbmStt_Status() {
    std::lock_guard<std::mutex> lk(T().txtMtx);
    return T().status;
}

std::string XbmStt_ModelDir() {
    // Der Ordner des eingestellten Modellpfads -- dort wird zuerst
    // gesucht, also gehoert ein Download auch dorthin.
    const std::string& p2 = T().modelPath;
    const std::size_t sl = p2.find_last_of("/\\");
    return (sl == std::string::npos) ? std::string(".") : p2.substr(0, sl);
}

bool XbmStt_HasModelFile(const char* datei) {
    if (!datei) return false;
    const std::string p2 = XbmStt_ModelDir() + "/" + datei;
    if (std::FILE* f = std::fopen(p2.c_str(), "rb")) {
        std::fseek(f, 0, SEEK_END);
        const long gr = std::ftell(f);
        std::fclose(f);
        return gr >= 10L * 1024 * 1024;
    }
    return false;
}

// ---------------------------------------------------------------------------
// MODELLWAHL
// [Bisher nahm die Suche das erstbeste gefundene Modell. Wer zwei
//  installiert hatte, konnte nicht bestimmen, welches benutzt wird -- und
//  der Knopf zum Nachladen verschwand, sobald EINES da war. Beides war
//  zu kurz gedacht: man will vergleichen, wechseln und Platz wieder
//  freigeben.]
// Die Wahl steht in einer kleinen Textdatei neben den Modellen, damit sie
// den Neustart ueberlebt, ohne die uebrigen Einstellungen anzufassen.
// ---------------------------------------------------------------------------
namespace {
std::string WahlDatei() { return XbmStt_ModelDir() + "/modell.txt"; }
}

std::string XbmStt_ChosenModel() {
    std::FILE* f = std::fopen(WahlDatei().c_str(), "rb");
    if (!f) return std::string();
    char b[256] = {0};
    const std::size_t n = std::fread(b, 1, sizeof(b) - 1, f);
    std::fclose(f);
    std::string r(b, n);
    while (!r.empty() && (r.back() == '\n' || r.back() == '\r' || r.back() == ' '))
        r.pop_back();
    // Nur gelten lassen, wenn die Datei auch (noch) da ist.
    return XbmStt_HasModelFile(r.c_str()) ? r : std::string();
}

void XbmStt_ChooseModel(const std::string& datei) {
    if (std::FILE* f = std::fopen(WahlDatei().c_str(), "wb")) {
        std::fwrite(datei.data(), 1, datei.size(), f);
        std::fclose(f);
    }
    XbmStt_RescanModel();
}

bool XbmStt_DeleteModel(const std::string& datei) {
    if (datei.empty()) return false;
    const std::string p2 = XbmStt_ModelDir() + "/" + datei;
    const bool ok = (std::remove(p2.c_str()) == 0);
    if (ok && XbmStt_ChosenModel().empty()) XbmStt_RescanModel();
    return ok;
}

void XbmStt_RescanModel() {
    // NUR EINEN WUNSCH HINTERLEGEN -- den Kontext fasst ausschliesslich
    // der Arbeitsfaden an.
    //
    // [Hier stand whisper_free(T().ctx) direkt. Aufgerufen wird das aus
    //  dem UI-Faden, sobald ein Download fertig ist -- und genau dann
    //  kann der Arbeitsfaden mitten in whisper_full stecken oder das
    //  Modell gerade laden. Den Kontext unter ihm wegzuziehen ist ein
    //  Wettlauf mit Ansage.
    //
    //  Im Protokoll sieht man die Folge: "3 Auftrag angenommen",
    //  "Modell geladen" -- und dann NIE ein "4 Lauf beendet". Der Faden
    //  haengt, alle weiteren Auftraege stauen sich dahinter, und die
    //  Textbox bleibt leer, ohne dass irgendwo ein Fehler erscheint.
    //  Genau das gemeldete Bild.]
    T().rescan.store(true, std::memory_order_release);
    { std::lock_guard<std::mutex> lk(T().txtMtx);
      T().status = "Modell wird neu gesucht"; }
}
void XbmStt_SetModelPath(const std::string& p) {
    // EINMAL beim Start deutlich sagen, woran man ist. [Ohne diese Zeile
    //  merkt man erst nach einer Aufnahme, dass gar nicht transkribiert
    //  wird -- und weiss dann immer noch nicht, ob das Kennzeichen fehlt
    //  oder nur das Modell.]
    static bool gemeldet = false;
    if (!gemeldet) {
        gemeldet = true;
        std::printf("[xbm] Transkription: %s | Modellpfad: %s\n",
                    XbmStt_Compiled() ? "EINKOMPILIERT" : "NICHT einkompiliert",
                    p.c_str());
        // GLEICH BEIM START zeigen, wo gesucht wird -- und ob die Datei
        // schon da ist. [Bisher erfuhr man das erst NACH einer Aufnahme,
        //  in einer Fehlermeldung. Wer das Modell erst noch ablegen muss,
        //  braucht die Pfade vorher.]
#if defined(XBM_WITH_WHISPER)
        // [Diese Zeilen stehen bewusst im whisper-Block: SucheModell und
        //  T().gesucht gibt es nur dort. Ohne die Klammerung uebersetzt
        //  die Datei OHNE whisper nicht mehr -- und genau so hatte ich sie
        //  zuletzt ausgeliefert.]
        {
            T().modelPath = p;
            const std::string gefunden = SucheModell(p);
            if (!gefunden.empty()) {
                std::printf("[xbm] Modell gefunden: %s\n", gefunden.c_str());
            } else {
                std::printf("[xbm] KEIN Modell. Ablegen unter einem von:\n  %s\n",
                            T().gesucht.c_str());
            }
        }
#endif
        std::fflush(stdout);
    } T().modelPath = p; }
std::string XbmStt_ModelPath() { return T().modelPath; }
void XbmStt_SetLanguage(const std::string& l) { T().language = l; }
std::string XbmStt_Language() { return T().language; }

std::uint64_t XbmStt_Submit(XbmClip clip,
                            std::function<void(std::string, bool)> onDone) {
    // SPUR: eine Zeile je Schritt. [Die Kette Submit -> Faden -> Modell ->
    //  whisper -> PostUi -> DrainUi -> Notiz hat sechs Glieder; bricht
    //  eines, bleibt das Feld leer und man sieht NICHT, welches. Diese
    //  Zeilen kosten nichts und beantworten die Frage in einem Lauf.]
    std::printf("[stt] 1 Submit: %.2f s Ton, einkompiliert=%d\n",
                clip.seconds(), (int)XbmStt_Compiled());
    std::fflush(stdout);
    EnsureSttThread();
    SttJob j;
    j.id   = T().nextId.fetch_add(1);
    j.clip = std::move(clip);
    j.done = std::move(onDone);
    const std::uint64_t id = j.id;
    {
        std::lock_guard<std::mutex> lk(T().mtx);
        T().queue.push_back(std::move(j));
    }
    T().cv.notify_one();
    return id;
}

std::size_t XbmStt_Queued() {
    std::lock_guard<std::mutex> lk(T().mtx);
    return T().queue.size();
}

bool XbmStt_Busy() { return T().busy.load(); }

void XbmStt_Shutdown() {
    if (!T().running.exchange(false)) return;
    T().cv.notify_all();
    if (T().worker.joinable()) T().worker.join();
#if defined(XBM_WITH_WHISPER)
    if (T().ctx) { whisper_free(T().ctx); T().ctx = nullptr; }
#endif
}

void XbmAudio_Shutdown() {
    if (A().recording.load()) { A().recording.store(false); }
    // REIHENFOLGE: erst alle Geraete, dann der Kontext.
    // [Das WIEDERGABEGERAET wurde nie freigegeben -- ma_device_uninit
    //  (&PL().dev) kam im ganzen Modul nicht vor. Und ma_context_uninit
    //  lief, waehrend dieses Geraet den Kontext noch benutzte. miniaudio
    //  gibt dabei Speicher frei, den das lebende Geraet weiterhin haelt;
    //  je nach Backend endet das in "free(): invalid pointer". Beides ist
    //  hier behoben.]
    XbmAudio_PlayStop();
    if (PL().devOk) { ma_device_uninit(&PL().dev); PL().devOk = false; }
    PL().loaded.store(false);
    PL().pcm.clear();
    PL().pcm.shrink_to_fit();

    if (A().devOk) { ma_device_uninit(&A().dev); A().devOk = false; }
    if (A().ctxOk) { ma_context_uninit(&A().ctx); A().ctxOk = false; }
}

// ---------------------------------------------------------------------------
// BELIEBIGE AUDIODATEI LESEN (Tab Media): ueber ma_decoder nach Mono f32 bei
// kXbmSampleRate. Liefert false mit lastError, wenn das Format unbekannt ist.
// ---------------------------------------------------------------------------
bool XbmAudio_ReadAny(const std::string& path, XbmClip& out) {
    out = XbmClip{};
    ma_decoder_config cfg = ma_decoder_config_init(ma_format_f32, 1, (ma_uint32)kXbmSampleRate);
    ma_decoder dec;
    if (ma_decoder_init_file(path.c_str(), &cfg, &dec) != MA_SUCCESS) {
        if (XbmAudio_ReadWav(path, out)) return true;          // Rueckfall: eigener WAV-Leser
        A().lastError = "Audio nicht lesbar: " + path; return false;
    }
    std::vector<float> puffer(4096);
    for (;;) {
        ma_uint64 gelesen = 0;
        if (ma_decoder_read_pcm_frames(&dec, puffer.data(), puffer.size(), &gelesen) != MA_SUCCESS || gelesen == 0) break;
        out.pcm.insert(out.pcm.end(), puffer.begin(), puffer.begin() + (std::size_t)gelesen);
    }
    ma_decoder_uninit(&dec);
    out.sampleRate = kXbmSampleRate;
    if (out.pcm.empty()) { A().lastError = "Audio leer: " + path; return false; }
    return true;
}
