#pragma once
// ===========================================================================
// xbm_timeline_sync -- Abgleich der Kalendereintraege ueber das Netz.
//
// Fuer jeden Peer, den netlink gesehen hat, laufen periodisch (und sofort
// nach einer eigenen Aenderung) die timeline-Pakete ueber den
// Nachrichtenrahmen: anfrage -> delta -> bestaetigung, in beide Richtungen.
// Eingehende Nachrichten beantwortet der Server-Haken mit
// timeline::verarbeiten(). Kommt dabei etwas Neues an, wird die Oberflaeche
// benachrichtigt (UiCalendar_TimelineNeuLaden), die ihre Eintraege neu aus
// timeline projiziert.
//
// Der Hub ist nur ein weiterer Peer (in netlink als Peer eintragen).
// Der bisherige DATEI-Abgleich von calendar.json ueber XbmNetNode bleibt
// vorerst bestehen; er transportiert jetzt nur noch den Ansichtszustand.
// ===========================================================================
#include <cstdint>
#include <string>
class XbmNetNode;

namespace xbm_tls {
void Init(XbmNetNode& node);              // Haken setzen; einmal beim Start
void Poll(std::int64_t jetztMs);          // im Frame, nach XbmNetNode::Poll()
void Anstossen();                          // nach einer lokalen Aenderung
std::string Statuszeile();                 // fuer die Netzwerkseite ["Status" ist unter X11 ein Makro]
// HUB (Server im Internet): eigene Verbindung des Treibers -- kein netlink-
// Peer noetig. host leer = kein Hub. Wiederverbindung alle 30 s.
void HubSetzen(const std::string& host, std::uint16_t port, const std::string& geheimnis);
bool HubVerbunden();
}
