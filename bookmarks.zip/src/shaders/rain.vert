#version 450
// rain.vert
// Fullscreen quad: no vertex buffer needed, generate positions from vertex index.
// gl_VertexIndex 0..5 produce two triangles covering [-1,1] clip space.

layout(location = 0) out vec2 fragUV;

void main() {
    // Two-triangle fullscreen quad via vertex index trick
    vec2 uv = vec2((gl_VertexIndex << 1) & 2, gl_VertexIndex & 2);
    fragUV = uv;
    gl_Position = vec4(uv * 2.0 - 1.0, 0.0, 1.0);
}
