#version 450
// spin.vert
// Procedural 3D cube: 36 vertices (6 faces x 2 tris x 3 verts) generated
// entirely in the vertex shader from gl_VertexIndex. No vertex buffer needed.
// Rotated around Z axis by the angle pushed from the CPU each frame.

layout(location = 0) out vec3 fragColor;

// Push constants: rotation angle (radians), time
layout(push_constant) uniform PushConstants {
    float angle;  // rotation around Z axis
    float time;
    float aspectRatio;
} pc;

// Cube face data: 6 faces, 2 tris each, indexed by gl_VertexIndex
// We generate positions and per-face colors procedurally.
const vec3 cubeVerts[8] = vec3[](
    vec3(-0.5, -0.5, -0.5),
    vec3( 0.5, -0.5, -0.5),
    vec3( 0.5,  0.5, -0.5),
    vec3(-0.5,  0.5, -0.5),
    vec3(-0.5, -0.5,  0.5),
    vec3( 0.5, -0.5,  0.5),
    vec3( 0.5,  0.5,  0.5),
    vec3(-0.5,  0.5,  0.5)
);

// Two triangles per face, 6 faces = 36 indices
const int faceIndices[36] = int[](
    0,1,2, 2,3,0,  // back
    4,5,6, 6,7,4,  // front
    0,4,7, 7,3,0,  // left
    1,5,6, 6,2,1,  // right
    3,2,6, 6,7,3,  // top
    0,1,5, 5,4,0   // bottom
);

const vec3 faceColors[6] = vec3[](
    vec3(1.0, 0.3, 0.3),  // back    - red
    vec3(0.3, 1.0, 0.3),  // front   - green
    vec3(0.3, 0.3, 1.0),  // left    - blue
    vec3(1.0, 1.0, 0.3),  // right   - yellow
    vec3(1.0, 0.3, 1.0),  // top     - magenta
    vec3(0.3, 1.0, 1.0)   // bottom  - cyan
);

void main() {
    int vi    = gl_VertexIndex;
    int face  = vi / 6;
    vec3 pos  = cubeVerts[faceIndices[vi]];
    fragColor = faceColors[face];

    // Rotate around Z axis
    float s = sin(pc.angle);
    float c = cos(pc.angle);
    mat3 rotZ = mat3(
        vec3( c, s, 0.0),
        vec3(-s, c, 0.0),
        vec3(0.0, 0.0, 1.0)
    );
    // Also slowly tilt around X for a 3D feel
    float tilt = 0.4;
    mat3 rotX = mat3(
        vec3(1.0, 0.0,      0.0),
        vec3(0.0, cos(tilt), sin(tilt)),
        vec3(0.0,-sin(tilt), cos(tilt))
    );
    pos = rotZ * rotX * pos;

    // Simple perspective projection
    float fov   = 1.5;
    float depth = pos.z + 2.5; // push cube 2.5 units away from camera
    float nx    = pos.x * fov / depth;
    float ny    = pos.y * fov / depth * pc.aspectRatio;

    gl_Position = vec4(nx, ny, depth / 10.0, 1.0);
}
