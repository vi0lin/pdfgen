#version 450
// spin.frag / drag.frag (shared between scenarios 2 and 3)
// Just outputs the interpolated per-face color. The background is made
// transparent by the clear color (0,0,0,0) set in BeginFrame(); pixels
// covered by the cube triangles are opaque.

layout(location = 0) in  vec3 fragColor;
layout(location = 0) out vec4 outColor;

void main() {
    outColor = vec4(fragColor, 1.0); // fully opaque cube faces
}
