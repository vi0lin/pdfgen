#version 450
// rain.frag
// Procedural rain: multiple layers of randomly-positioned vertical streaks
// falling at different speeds. Background is fully transparent (alpha = 0)
// so the desktop is visible between drops.

layout(location = 0) in  vec2 fragUV;
layout(location = 0) out vec4 outColor;

// Push constant: time in seconds
layout(push_constant) uniform PushConstants {
    float time;
    float aspectRatio;  // width / height
} pc;

// Simple hash function for pseudo-random values from 2D coordinates
float hash(vec2 p) {
    p = fract(p * vec2(234.34, 435.345));
    p += dot(p, p + 34.23);
    return fract(p.x * p.y);
}

// A single "column" of rain. Returns the brightness of a raindrop
// at the given column ID and UV position.
float rainColumn(vec2 uv, float speed, float offset) {
    // Each column is one unit wide in "column space"
    float col   = floor(uv.x);
    float colUV = fract(uv.x);

    // Random offset per column so drops start at different heights
    float startY = hash(vec2(col, offset));
    float dropY  = fract(startY - pc.time * speed);

    // Drop length: a streak rather than a single point
    float dropLen   = 0.06 + hash(vec2(col + 1.3, offset)) * 0.12;
    float brightness = smoothstep(dropLen, 0.0, dropY) *
                       smoothstep(dropLen * 0.1, dropLen * 0.8, dropY);

    // Narrow the drop horizontally (it occupies ~10% of the column width)
    float colEdge = smoothstep(0.45, 0.35, abs(colUV - 0.5));

    return brightness * colEdge;
}

void main() {
    // Scale UV so columns are roughly pixel-width (16 columns per unit)
    vec2 uv = fragUV;
    uv.x *= pc.aspectRatio;

    float rain = 0.0;

    // Layer 1: close rain -- faster, denser
    vec2 uv1 = uv * vec2(40.0, 20.0);
    rain += rainColumn(uv1, 1.8, 0.0) * 0.9;

    // Layer 2: mid rain -- medium speed/density
    vec2 uv2 = uv * vec2(25.0, 12.0);
    rain += rainColumn(uv2, 1.2, 1.7) * 0.6;

    // Layer 3: distant rain -- slower, sparser
    vec2 uv3 = uv * vec2(15.0, 8.0);
    rain += rainColumn(uv3, 0.7, 3.1) * 0.4;

    rain = clamp(rain, 0.0, 1.0);

    // Rain drop color: blue-white tint
    vec3 dropColor = vec3(0.7, 0.85, 1.0);

    // Output: transparent where there's no rain, colored where there is
    outColor = vec4(dropColor * rain, rain * 0.75);
}
