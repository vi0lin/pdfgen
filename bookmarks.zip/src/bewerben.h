#pragma once
void BewerbenInit();                     // haengt den Mail-Haken ein
void UiDrawBewerbenUI(bool* open);
