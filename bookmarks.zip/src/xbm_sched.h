#pragma once
// ---------------------------------------------------------------------------
// xbm_sched.h -- Zeitsteuerung fuer Linux, Windows und Android.
//
// EIN Timer-Thread mit Prioritaetswarteschlange (kein Thread pro Termin) +
// kleiner Worker-Pool fuer die Ausfuehrung. Der Timer-Thread blockiert damit
// NIE in Nutzercode, und 10.000 Termine kosten 10.000 Heap-Eintraege statt
// 10.000 Threads.
//
// EHRLICHKEIT ZUR GENAUIGKEIT -- bitte vor dem Benutzen lesen:
// Nanosekunden sind hier die AUFLOESUNG der Schnittstelle, nicht die
// zugesicherte Zustellgenauigkeit. Auf Universalbetriebssystemen begrenzen
// Timer-Granularitaet, Scheduler-Latenz, Interrupts, Kontextwechsel und
// Energieverwaltung die Weckgenauigkeit realistisch auf:
//     Linux (SCHED_FIFO, ruhiges System) : ~5-50 us
//     Linux (normal, unter Last)         : ~50 us - 5 ms
//     Windows (High-Resolution-Timer)    : ~0,5 - 2 ms, mit Spin ~50 us
//     Android (Doze/Big-Little/Governor)  : ~1 - 50 ms, Ausreisser weit mehr
// Deshalb misst dieses Modul die tatsaechliche Verspaetung mit und zeigt sie
// in XbmSchedStats an -- lieber eine gemessene Wahrheit als ein Versprechen.
// Fuer garantierte Fristen braucht es ein Echtzeitbetriebssystem.
//
// ZWEI ZEITBASEN, bewusst getrennt:
//   * WANDUHR  (XbmSched_AtWall)  -- Kalendertermine. Wird gegen
//     system_clock nachgefuehrt: NTP-Spruenge, Zeitzonenwechsel, manuelles
//     Stellen und Suspend/Resume verschieben den Termin korrekt mit.
//   * MONOTON  (XbmSched_After / _Every) -- Zeitspannen. Immun gegen jedes
//     Uhrstellen; "in 5 Minuten" bleibt "in 5 Minuten".
// ---------------------------------------------------------------------------
#include <chrono>
#include <cstdint>
#include <functional>
#include <string>

using XbmTaskId = std::uint64_t;
inline constexpr XbmTaskId XbmTaskNone = 0;

// Wo die Funktion laufen soll.
enum class XbmRun {
    Pool,   // im Worker-Pool (Standard) -- fuer alles Rechnende/Blockierende
    Ui      // in der UI-Warteschlange, abgeholt von XbmSched_DrainUi() im
            // Renderframe. PFLICHT fuer alles, was ImGui-Zustand anfasst.
};

// Startet Timer-Thread und Pool. Mehrfachaufrufe sind harmlos.
void XbmSched_Start(int poolThreads = 2);
void XbmSched_Shutdown();
bool XbmSched_Running();

// --- Terminieren ----------------------------------------------------------
XbmTaskId XbmSched_AtWall(std::chrono::system_clock::time_point when,
                          std::function<void()> fn,
                          XbmRun where = XbmRun::Pool);
XbmTaskId XbmSched_After(std::chrono::nanoseconds delay,
                         std::function<void()> fn,
                         XbmRun where = XbmRun::Pool);
XbmTaskId XbmSched_Every(std::chrono::nanoseconds interval,
                         std::function<void()> fn,
                         XbmRun where = XbmRun::Pool);
bool XbmSched_Cancel(XbmTaskId id);
void XbmSched_CancelAll();

// --- UI-Bruecke -----------------------------------------------------------
// Aus JEDEM Thread aufrufbar; die Funktion laeuft garantiert im UI-Thread.
void XbmSched_PostUi(std::function<void()> fn);
// Einmal pro Frame im UI-Thread aufrufen (arbeitet die Warteschlange ab).
// budgetMs begrenzt die Frame-Zeit; der Rest wandert in den naechsten Frame.
void XbmSched_DrainUi(double budgetMs = 4.0);

// --- Feineinstellung ------------------------------------------------------
// Restzeit, die am Ende AKTIV abgewartet wird (Busy-Wait) statt zu schlafen.
// Kostet CPU, kauft Genauigkeit. 0 = nie spinnen (Standard auf Android).
void XbmSched_SetSpinMargin(std::chrono::nanoseconds margin);
std::chrono::nanoseconds XbmSched_SpinMargin();

struct XbmSchedStats {
    std::size_t pending      = 0;   // wartende Termine
    std::uint64_t fired      = 0;   // ausgeloeste Termine seit Start
    double lastLateUs        = 0.0; // Verspaetung des letzten Termins
    double worstLateUs       = 0.0;
    double avgLateUs         = 0.0;
    bool   realtimePriority  = false; // SCHED_FIFO / TIME_CRITICAL bekommen?
    bool   highResTimer      = false; // hochaufloesender OS-Timer aktiv?
    std::size_t uiQueue      = 0;
    std::size_t poolQueue    = 0;
    int    poolThreads       = 0;
};
XbmSchedStats XbmSched_Stats();
void XbmSched_ResetStats();

// --- Kalender-Hilfen (lokale Zeit <-> Unix-Sekunden UTC) ------------------
// Bewusst hier und nicht im Kalendermodul: die Umrechnung ist die einzige
// Stelle, an der Zeitzonen und Sommerzeit im Spiel sind, und sie wird von
// Scheduler UND Kalender gebraucht.
struct XbmLocalTime { int year, month, day, hour, minute, second, weekday, yday; };
XbmLocalTime XbmTime_ToLocal(std::int64_t unixUtcSeconds);
std::int64_t XbmTime_FromLocal(int year, int month, int day,
                               int hour, int minute, int second);
std::int64_t XbmTime_NowUtc();
// Mitternacht (lokal) des Tages, in dem t liegt -- als Unix-UTC-Sekunden.
std::int64_t XbmTime_LocalMidnight(std::int64_t t);
// Tage addieren, sommerzeitsicher (ueber die Kalenderfelder, nicht 86400*n).
std::int64_t XbmTime_AddDays(std::int64_t t, int days);
std::int64_t XbmTime_AddMonths(std::int64_t t, int months);
// Formatierung ohne strftime-Gefrickel an der Aufrufstelle.
std::string XbmTime_Format(std::int64_t t, const char* fmt);
