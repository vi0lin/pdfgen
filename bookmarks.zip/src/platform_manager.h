#pragma once
// ---------------------------------------------------------------------------
// platform_manager.h -- EIN Manager fuer alle Plattformen.
//
// [Das hier ist die Verallgemeinerung des bisherigen X-Codes aus
//  main.cpp (AppState, start_loading, start_delete_selected, das
//  Cookie-Fenster). Er kennt keine Plattform -- er redet nur mit
//  BookmarkSource. Deshalb gibt es ihn genau einmal, und "X", "Reddit"
//  und "Facebook" sind drei Instanzen desselben Codes.]
//
// EINBAU (main.cpp / main_android.cpp):
//   static PlatformManager pmX(MakeXSource()), pmR(MakeRedditSource()),
//                          pmF(MakeFacebookSource());
//   ... beim Start:   pm.LoadCookies(cookieDir);
//   ... jeden Frame:  pm.Drain();
//   ... Fenster:      pm.DrawManager(titel, &show, flags);
//                     pm.DrawLogin(titel, &show, flags);
// ---------------------------------------------------------------------------
#include "bookmark_source.h"
#include "bookmark_window.h"
#include "thumbnails.h"

#include <nlohmann/json.hpp>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <unordered_set>

#include "imgui.h"
#include "ui_form.h"

class PlatformManager {
public:
    explicit PlatformManager(std::unique_ptr<BookmarkSource> q) : quelle_(std::move(q)) {
        for (auto& f : quelle_->LoginFields()) eingabe_[f.key] = std::string();
    }

    BookmarkSource& Quelle() { return *quelle_; }
    const char* Name() const { return quelle_->Name(); }

    // ---- Cookies laden/speichern: cookies_<slug>.json ----------------------
    void LoadCookies(const std::string& ordner) {
        pfad_ = ordner + "/cookies_" + quelle_->Slug() + ".json";
        std::ifstream f(pfad_);
        if (!f) return;
        try {
            nlohmann::json j; f >> j;
            std::map<std::string, std::string> w;
            for (auto& kv : j.items()) if (kv.value().is_string()) w[kv.key()] = kv.value().get<std::string>();
            for (auto& kv : w) eingabe_[kv.first] = kv.second;
            std::string fehler;
            if (quelle_->Login(w, fehler)) SetStatus(std::string(Name()) + ": angemeldet");
            else SetStatus(std::string(Name()) + ": gespeicherte Cookies gelten nicht -- " + fehler);
        } catch (...) {}
    }
    void SaveCookies() {
        if (pfad_.empty()) return;
        nlohmann::json j;
        for (auto& kv : eingabe_) j[kv.first] = kv.second;
        std::ofstream f(pfad_); f << j.dump(2);
    }

    // ---- Hintergrundfaeden -> Oberflaeche --------------------------------
    void Drain() {
        std::lock_guard<std::mutex> g(m_);
        for (auto& s : statusQueue_) status_ = s;
        statusQueue_.clear();
        for (auto& seite : pagesQueue_)
            for (auto& e : seite) {
                if (index_.count(e.id)) continue;
                index_[e.id] = eintraege_.size();
                eintraege_.push_back(e);
            }
        pagesQueue_.clear();
        for (auto& id : deletedQueue_) {
            auto it = index_.find(id);
            if (it == index_.end()) continue;
            size_t i = it->second;
            eintraege_.erase(eintraege_.begin() + (long)i);
            index_.clear();
            for (size_t k = 0; k < eintraege_.size(); ++k) index_[eintraege_[k].id] = k;
            selected_.erase(id);
        }
        deletedQueue_.clear();
    }

    void StartLoading() {
        if (loading_.load() || !quelle_->LoggedIn()) return;
        loading_ = true;
        { std::lock_guard<std::mutex> g(m_); eintraege_.clear(); index_.clear(); }
        SetStatus("Lade Lesezeichen ...");
        std::thread([this] {
            int n = 0;
            try {
                quelle_->FetchAll([this, &n](const std::vector<BookmarkEntry>& seite) {
                    n += (int)seite.size();
                    { std::lock_guard<std::mutex> g(m_); pagesQueue_.push_back(seite); }
                    SetStatus(std::to_string(n) + " geladen ...");
                }, [this] { return stop_.load(); });
                SetStatus("Fertig: " + std::to_string(n) + " Lesezeichen.");
            } catch (const std::exception& e) {
                SetStatus(std::string("Fehler: ") + e.what());
            }
            loading_ = false;
        }).detach();
    }

    void StartDeleteSelected() {
        if (deleting_.load() || selected_.empty()) return;
        std::vector<std::string> ids(selected_.begin(), selected_.end());
        deleting_ = true;
        std::thread([this, ids] {
            int ok = 0;
            for (size_t i = 0; i < ids.size(); ++i) {
                SetStatus("Entferne " + std::to_string(i + 1) + "/" + std::to_string(ids.size()) + " ...");
                if (quelle_->Remove(ids[i])) {
                    ok++;
                    std::lock_guard<std::mutex> g(m_); deletedQueue_.push_back(ids[i]);
                }
            }
            SetStatus(std::to_string(ok) + "/" + std::to_string(ids.size()) + " entfernt.");
            deleting_ = false;
        }).detach();
    }

    // ---- Fenster -----------------------------------------------------------
    void DrawManager(const char* titel, bool* show, ImGuiWindowFlags flags) {
        std::vector<BookmarkItem> items;
        items.reserve(eintraege_.size());
        for (auto& e : eintraege_) items.push_back({e.id, e.author, e.text});
        BookmarkCallbacks cb;
        cb.onLoad   = [this] { StartLoading(); };
        cb.onDelete = [this](const std::vector<std::string>& ids) {
            selected_.clear();
            for (auto& id : ids) selected_.insert(id);
            StartDeleteSelected();
        };
        cb.onOpen = [this](const std::string& id) {
            auto it = index_.find(id);
            if (it == index_.end()) return;
            const std::string& url = eintraege_[it->second].url;
            if (url.empty()) return;
#if defined(_WIN32)
            std::string cmd = "start \"\" \"" + url + "\"";
#elif defined(__APPLE__)
            std::string cmd = "open \"" + url + "\"";
#elif defined(__ANDROID__)
            std::string cmd; (void)cmd;   // auf Android ueber die Activity -- s. unten
#else
            std::string cmd = "xdg-open \"" + url + "\"";
#endif
#if !defined(__ANDROID__)
            (void)std::system(cmd.c_str());
#endif
        };
        cb.getTexture = [this](const std::string& id) -> unsigned int {
            return zeigeBilder_ ? thumbs_.get_texture(id) : 0;
        };
        // Login IM Fenster -- gleiches Verhalten fuer X, Reddit, Facebook.
        cb.drawLogin = [this] { DrawLoginInline(); };
        cb.loggedIn  = [this] { return quelle_->LoggedIn(); };
        cb.onLogin   = [] {};   // schaltet im Fenster nur den Bereich um
        (void)flags;
        DrawBookmarkWindow(titel, items, selected_, cb, status_, show);
    }

    // Der Anmeldebereich -- OHNE eigenes Fenster. Wird vom Manager-Fenster
    // oben eingeblendet (siehe BookmarkCallbacks::drawLogin).
    void DrawLoginInline() {
        const char* hint = quelle_->Hint();
        if (hint && hint[0]) ImGui::TextWrapped("%s", hint);
        for (auto& f : quelle_->LoginFields()) {
            auto& val = eingabe_[f.key];
            char buf[512];
            std::snprintf(buf, sizeof(buf), "%s", val.c_str());
            ImGui::PushID(f.key.c_str());
            // Beschriftung darueber, Breite begrenzt -- kein horizontaler Scroll.
            if (UiFormInput(f.label.c_str(), buf, sizeof(buf),
                            f.secret ? ImGuiInputTextFlags_Password : 0))
                val = buf;
            ImGui::PopID();
        }
        if (quelle_->LoggedIn()) {
            ImGui::TextColored(ImVec4(0.4f, 1, 0.4f, 1), "%s: angemeldet", Name());
            if (UiFormButton("Abmelden")) { quelle_->Logout(); SetStatus("abgemeldet"); }
        } else {
            if (UiButtonWrap("Anmelden und speichern")) {
                std::string fehler;
                std::map<std::string, std::string> w(eingabe_.begin(), eingabe_.end());
                if (quelle_->Login(w, fehler)) { SaveCookies(); SetStatus("angemeldet"); }
                else SetStatus("Login fehlgeschlagen: " + fehler);
            }
        }
    }

    // Weiterhin verfuegbar, falls jemand ein getrenntes Fenster will.
    void DrawLogin(const char* titel, bool* show, ImGuiWindowFlags flags) {
        if (!ImGui::Begin(titel, show, flags)) { ImGui::End(); return; }
        DrawLoginInline();
        if (!status_.empty()) ImGui::TextDisabled("%s", status_.c_str());
        ImGui::End();
    }

    bool zeigeBilder_ = true;
    std::unordered_set<std::string> selected_;

private:
    void SetStatus(const std::string& s) { std::lock_guard<std::mutex> g(m_); statusQueue_.push_back(s); }

    std::unique_ptr<BookmarkSource> quelle_;
    std::string pfad_;
    std::map<std::string, std::string> eingabe_;
    std::vector<BookmarkEntry> eintraege_;
    std::unordered_map<std::string, size_t> index_;
    ThumbnailManager thumbs_;
    std::atomic<bool> loading_{false}, deleting_{false}, stop_{false};
    std::string status_ = "Noch nicht geladen.";
    std::mutex m_;
    std::vector<std::string> statusQueue_, deletedQueue_;
    std::vector<std::vector<BookmarkEntry>> pagesQueue_;
};
