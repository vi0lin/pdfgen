// ---------------------------------------------------------------------------
// xbm_sched.cpp -- siehe xbm_sched.h fuer Entwurf und Genauigkeitsgrenzen.
// ---------------------------------------------------------------------------
#include "xbm_sched.h"

#include <algorithm>
#include <atomic>
#include <condition_variable>
#include <cstring>
#include <ctime>
#include <deque>
#include <mutex>
#include <thread>
#include <vector>

#if defined(_WIN32)
    #ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
    #endif
    #include <windows.h>
#else
    #include <pthread.h>
    #include <time.h>
    #include <unistd.h>
    #include <cerrno>
    #if defined(__linux__) || defined(__ANDROID__)
        #include <sched.h>
    #endif
#endif

namespace {

// ---------------------------------------------------------------------------
// Datenmodell
// ---------------------------------------------------------------------------
using Clock  = std::chrono::steady_clock;
using WClock = std::chrono::system_clock;

struct Task {
    XbmTaskId id = 0;
    bool wall = false;                  // Wanduhr- oder Monoton-Termin?
    WClock::time_point wallAt{};        // gueltig wenn wall
    Clock::time_point  monoAt{};        // gueltig wenn !wall
    std::chrono::nanoseconds interval{0};   // >0 = wiederholend
    std::function<void()> fn;
    XbmRun where = XbmRun::Pool;
    bool cancelled = false;
};

struct Sched {
    std::mutex               mtx;
    std::condition_variable  cv;
    std::vector<Task>        tasks;         // unsortiert; N ist klein
    std::atomic<XbmTaskId>   nextId{1};
    std::atomic<bool>        running{false};
    std::thread              timer;

    // Worker-Pool
    std::vector<std::thread>            pool;
    std::deque<std::function<void()>>   poolQueue;
    std::mutex                          poolMtx;
    std::condition_variable             poolCv;

    // UI-Warteschlange
    std::deque<std::function<void()>>   uiQueue;
    std::mutex                          uiMtx;

    // Messwerte
    std::mutex   statMtx;
    std::uint64_t fired = 0;
    double lastLateUs = 0.0, worstLateUs = 0.0, sumLateUs = 0.0;
    std::atomic<bool> rtPriority{false};
    std::atomic<bool> highRes{false};

    std::atomic<long long> spinMarginNs{
#if defined(__ANDROID__)
        0                       // Akku schlaegt Mikrosekunden
#else
        50 * 1000               // 50 us
#endif
    };
};

Sched& S() { static Sched s; return s; }

// ---------------------------------------------------------------------------
// Praezises Warten auf einen monotonen Zeitpunkt.
// Zweistufig: erst grob mit dem OS-Timer (weckbar/energiesparend), dann --
// falls eingestellt -- die letzten Mikrosekunden aktiv.
// ---------------------------------------------------------------------------
#if defined(_WIN32)
// Hochaufloesender wartbarer Timer (Windows 10 1803+). Kein timeBeginPeriod:
// das wirkt systemweit und ist als Nebenwirkung unhoeflich; ausserdem
// braeuchte es winmm als zusaetzliche Bibliothek.
//
// DAS FLAG SELBST DEFINIEREN, WENN DIE HEADER ES NICHT KENNEN.
// [Genau hier scheiterte der Windows-Build:
//    error: use of undeclared identifier
//           'CREATE_WAITABLE_TIMER_HIGH_RESOLUTION'
//  Die Konstante kam erst mit dem Windows-10-1803-SDK dazu; aeltere
//  mingw-w64-Headerpakete (und damit die mingw-clang-Toolchain hier)
//  kennen sie nicht. Sie ist aber nur eine Zahl, kein Symbol aus einer
//  Bibliothek -- die Funktion CreateWaitableTimerExW gibt es seit Vista
//  und nimmt beliebige Flags entgegen. Kennt das laufende Windows das
//  Flag nicht, liefert der Aufruf schlicht NULL und der Rueckfall unten
//  greift. Selbst definieren ist deshalb sicher und die uebliche
//  Vorgehensweise, wenn man gegen aeltere Header baut.]
#ifndef CREATE_WAITABLE_TIMER_HIGH_RESOLUTION
#define CREATE_WAITABLE_TIMER_HIGH_RESOLUTION 0x00000002
#endif

HANDLE WinTimer() {
    static HANDLE h = [] {
        HANDLE t = CreateWaitableTimerExW(
            nullptr, nullptr,
            CREATE_WAITABLE_TIMER_HIGH_RESOLUTION, TIMER_ALL_ACCESS);
        if (t) { S().highRes.store(true); return t; }
        // Aeltere Windows-Versionen kennen das Flag nicht -> normaler Timer.
        return CreateWaitableTimerExW(nullptr, nullptr, 0, TIMER_ALL_ACCESS);
    }();
    return h;
}
#endif

void SleepUntilMono(Clock::time_point deadline) {
    const auto now = Clock::now();
    if (deadline <= now) return;
    auto rel = std::chrono::duration_cast<std::chrono::nanoseconds>(deadline - now);
#if defined(_WIN32)
    HANDLE h = WinTimer();
    if (h) {
        LARGE_INTEGER due;
        // Negativ = relativ, Einheit 100 ns.
        due.QuadPart = -(LONGLONG)(rel.count() / 100);
        if (due.QuadPart == 0) due.QuadPart = -1;
        if (SetWaitableTimer(h, &due, 0, nullptr, nullptr, FALSE)) {
            WaitForSingleObject(h, INFINITE);
            return;
        }
    }
    std::this_thread::sleep_for(rel);
#elif defined(__linux__) || defined(__ANDROID__)
    // Relatives clock_nanosleep auf CLOCK_MONOTONIC: keine Annahme darueber,
    // ob steady_clock dieselbe Epoche hat wie CLOCK_MONOTONIC (sie hat sie
    // praktisch immer, aber die Norm sagt es nicht zu).
    timespec ts;
    ts.tv_sec  = (time_t)(rel.count() / 1000000000LL);
    ts.tv_nsec = (long)  (rel.count() % 1000000000LL);
    while (clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, &ts) == EINTR) { /* weiter */ }
    S().highRes.store(true);
#else
    std::this_thread::sleep_for(rel);
#endif
}

void WaitPrecise(Clock::time_point deadline) {
    const auto spin = std::chrono::nanoseconds(S().spinMarginNs.load());
    if (spin.count() > 0 && deadline - Clock::now() > spin) {
        SleepUntilMono(deadline - spin);
    } else if (spin.count() <= 0) {
        SleepUntilMono(deadline);
        return;
    }
    // Restzeit aktiv: yield() statt reines Drehen -- gibt dem Kern die
    // Chance, andere lauffaehige Threads dazwischenzuschieben, und kostet
    // damit deutlich weniger als ein nacktes Busy-Loop.
    while (Clock::now() < deadline) std::this_thread::yield();
}

// ---------------------------------------------------------------------------
// Thread-Prioritaet (best effort -- Fehlschlag ist voellig in Ordnung)
// ---------------------------------------------------------------------------
void TryRealtimePriority() {
#if defined(_WIN32)
    if (SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL))
        S().rtPriority.store(true);
#elif defined(__linux__) && !defined(__ANDROID__)
    sched_param sp{};
    sp.sched_priority = 10;             // niedrig im RT-Band: wir sind Gast
    if (pthread_setschedparam(pthread_self(), SCHED_FIFO, &sp) == 0)
        S().rtPriority.store(true);
    // Kein RT-Recht (der Normalfall ohne CAP_SYS_NICE / rtprio-Limit)?
    // Dann bleibt es beim normalen Scheduling -- kein Fehler, nur weniger
    // Genauigkeit. Genau deshalb steht das Ergebnis in den Stats.
#elif defined(__ANDROID__)
    // Auf Android gibt es kein SCHED_FIFO fuer normale Apps. Wir bitten
    // lediglich um eine bessere Nice-Stufe.
    ::nice(-5);
#endif
}

// ---------------------------------------------------------------------------
// Ausfuehrung
// ---------------------------------------------------------------------------
void Dispatch(std::function<void()> fn, XbmRun where) {
    if (!fn) return;
    if (where == XbmRun::Ui) {
        std::lock_guard<std::mutex> lk(S().uiMtx);
        S().uiQueue.push_back(std::move(fn));
        return;
    }
    {
        std::lock_guard<std::mutex> lk(S().poolMtx);
        S().poolQueue.push_back(std::move(fn));
    }
    S().poolCv.notify_one();
}

void PoolWorker() {
    for (;;) {
        std::function<void()> job;
        {
            std::unique_lock<std::mutex> lk(S().poolMtx);
            S().poolCv.wait(lk, [] {
                return !S().poolQueue.empty() || !S().running.load();
            });
            if (!S().running.load() && S().poolQueue.empty()) return;
            job = std::move(S().poolQueue.front());
            S().poolQueue.pop_front();
        }
        // Ein geworfener Nutzerfehler darf niemals den Pool killen.
        try { job(); } catch (...) { }
    }
}

// Naechsten faelligen Termin bestimmen. Wanduhr-Termine werden dabei JEDES
// MAL neu gegen system_clock gerechnet -- das ist die ganze Magie hinter
// "NTP-Sprung und Suspend verschieben den Termin korrekt mit".
bool NextDeadline(Clock::time_point& out, std::size_t& idx) {
    const auto monoNow = Clock::now();
    const auto wallNow = WClock::now();
    bool found = false;
    for (std::size_t i = 0; i < S().tasks.size(); ++i) {
        const Task& t = S().tasks[i];
        if (t.cancelled) continue;
        Clock::time_point d;
        if (t.wall) {
            auto rest = t.wallAt - wallNow;
            if (rest.count() < 0) rest = WClock::duration::zero();
            d = monoNow + std::chrono::duration_cast<Clock::duration>(rest);
        } else {
            d = t.monoAt;
        }
        if (!found || d < out) { out = d; idx = i; found = true; }
    }
    return found;
}

void TimerThread() {
    TryRealtimePriority();
    for (;;) {
        std::function<void()> fire;
        XbmRun where = XbmRun::Pool;
        Clock::time_point deadline;
        {
            std::unique_lock<std::mutex> lk(S().mtx);
            if (!S().running.load()) return;

            // Abgeraeumte Eintraege entfernen (billig, N ist klein).
            S().tasks.erase(std::remove_if(S().tasks.begin(), S().tasks.end(),
                                           [](const Task& t) { return t.cancelled; }),
                            S().tasks.end());

            std::size_t idx = 0;
            if (!NextDeadline(deadline, idx)) {
                S().cv.wait(lk, [] {
                    return !S().running.load() || !S().tasks.empty();
                });
                continue;
            }

            // GROBE Phase unter dem Schloss und weckbar: so kann ein neu
            // eingestellter, frueherer Termin uns jederzeit unterbrechen.
            // Wir lassen bewusst 1 ms Rest fuer die praezise Phase stehen.
            const auto coarse = deadline - std::chrono::milliseconds(1);
            if (Clock::now() < coarse) {
                S().cv.wait_until(lk, coarse);
                continue;    // neu bewerten: es kann sich alles geaendert haben
            }
            if (Clock::now() < deadline) {
                // PRAEZISE Phase OHNE Schloss -- sonst blockierten wir hier
                // bis zu 1 ms lang jedes XbmSched_After aus anderen Threads.
                lk.unlock();
                WaitPrecise(deadline);
                lk.lock();
                if (!S().running.load()) return;
                // Nach dem Warten neu suchen: die Liste kann sich in der
                // Zwischenzeit veraendert haben (Index waere ungueltig).
                std::size_t idx2 = 0;
                Clock::time_point d2;
                if (!NextDeadline(d2, idx2)) continue;
                if (d2 > Clock::now()) continue;   // jemand war schneller
                idx = idx2;
            }

            Task& t = S().tasks[idx];
            if (t.cancelled) continue;
            fire  = t.fn;
            where = t.where;

            // Verspaetung messen -- die ehrliche Zahl fuer die Anzeige.
            {
                const double lateUs = std::chrono::duration<double, std::micro>(
                                          Clock::now() - deadline).count();
                std::lock_guard<std::mutex> sl(S().statMtx);
                S().fired++;
                S().lastLateUs = lateUs;
                S().sumLateUs += lateUs;
                if (lateUs > S().worstLateUs) S().worstLateUs = lateUs;
            }

            if (t.interval.count() > 0) {
                // Wiederholung: FEST vom Sollzeitpunkt fortschreiben, nicht
                // von "jetzt" -- sonst summiert sich jede Verspaetung auf und
                // ein Minutentakt driftet ueber Stunden merklich weg.
                if (t.wall) {
                    t.wallAt += std::chrono::duration_cast<WClock::duration>(t.interval);
                    // Grosser Rueckstand (Suspend!): auf die naechste
                    // zukuenftige Rasterstelle springen statt alle
                    // verpassten Ticks nachzufeuern.
                    const auto wn = WClock::now();
                    if (t.wallAt < wn) {
                        const auto miss = wn - t.wallAt;
                        const auto steps = miss / t.interval + 1;
                        t.wallAt += std::chrono::duration_cast<WClock::duration>(
                                        t.interval * steps);
                    }
                } else {
                    t.monoAt += std::chrono::duration_cast<Clock::duration>(t.interval);
                    const auto mn = Clock::now();
                    if (t.monoAt < mn) {
                        const auto miss = mn - t.monoAt;
                        const auto steps = miss / t.interval + 1;
                        t.monoAt += std::chrono::duration_cast<Clock::duration>(
                                        t.interval * steps);
                    }
                }
            } else {
                t.cancelled = true;     // einmalig: beim naechsten Umlauf raus
            }
        }
        Dispatch(std::move(fire), where);
    }
}

XbmTaskId AddTask(Task t) {
    if (!S().running.load()) XbmSched_Start();
    const XbmTaskId id = S().nextId.fetch_add(1);
    t.id = id;
    {
        std::lock_guard<std::mutex> lk(S().mtx);
        S().tasks.push_back(std::move(t));
    }
    S().cv.notify_all();
    return id;   // NICHT aus nextId zurueckrechnen -- das waere ein Rennen
}

}  // namespace

// ---------------------------------------------------------------------------
// Oeffentliche Schnittstelle
// ---------------------------------------------------------------------------
void XbmSched_Start(int poolThreads) {
    static std::mutex startMtx;
    std::lock_guard<std::mutex> lk(startMtx);
    if (S().running.load()) return;
    S().running.store(true);
    if (poolThreads < 1) poolThreads = 1;
    for (int i = 0; i < poolThreads; ++i) S().pool.emplace_back(PoolWorker);
    S().timer = std::thread(TimerThread);
}

void XbmSched_Shutdown() {
    if (!S().running.exchange(false)) return;
    S().cv.notify_all();
    S().poolCv.notify_all();
    if (S().timer.joinable()) S().timer.join();
    for (auto& th : S().pool) if (th.joinable()) th.join();
    S().pool.clear();
    {
        std::lock_guard<std::mutex> lk(S().mtx);
        S().tasks.clear();
    }
}

bool XbmSched_Running() { return S().running.load(); }

XbmTaskId XbmSched_AtWall(std::chrono::system_clock::time_point when,
                          std::function<void()> fn, XbmRun where) {
    Task t; t.wall = true; t.wallAt = when; t.fn = std::move(fn); t.where = where;
    return AddTask(std::move(t));
}

XbmTaskId XbmSched_After(std::chrono::nanoseconds delay,
                         std::function<void()> fn, XbmRun where) {
    Task t; t.wall = false; t.monoAt = Clock::now() + delay;
    t.fn = std::move(fn); t.where = where;
    return AddTask(std::move(t));
}

XbmTaskId XbmSched_Every(std::chrono::nanoseconds interval,
                         std::function<void()> fn, XbmRun where) {
    if (interval.count() <= 0) return XbmTaskNone;
    Task t; t.wall = false; t.monoAt = Clock::now() + interval;
    t.interval = interval; t.fn = std::move(fn); t.where = where;
    return AddTask(std::move(t));
}

bool XbmSched_Cancel(XbmTaskId id) {
    if (id == XbmTaskNone) return false;
    bool hit = false;
    {
        std::lock_guard<std::mutex> lk(S().mtx);
        for (auto& t : S().tasks)
            if (t.id == id && !t.cancelled) { t.cancelled = true; hit = true; break; }
    }
    if (hit) S().cv.notify_all();
    return hit;
}

void XbmSched_CancelAll() {
    {
        std::lock_guard<std::mutex> lk(S().mtx);
        for (auto& t : S().tasks) t.cancelled = true;
    }
    S().cv.notify_all();
}

void XbmSched_PostUi(std::function<void()> fn) {
    if (!fn) return;
    std::lock_guard<std::mutex> lk(S().uiMtx);
    S().uiQueue.push_back(std::move(fn));
}

void XbmSched_DrainUi(double budgetMs) {
    const auto t0 = Clock::now();
    for (;;) {
        std::function<void()> job;
        {
            std::lock_guard<std::mutex> lk(S().uiMtx);
            if (S().uiQueue.empty()) return;
            job = std::move(S().uiQueue.front());
            S().uiQueue.pop_front();
        }
        try { job(); } catch (...) { }
        const double ms = std::chrono::duration<double, std::milli>(
                              Clock::now() - t0).count();
        if (ms >= budgetMs) return;    // Rest im naechsten Frame
    }
}

void XbmSched_SetSpinMargin(std::chrono::nanoseconds margin) {
    S().spinMarginNs.store(margin.count() < 0 ? 0 : margin.count());
}
std::chrono::nanoseconds XbmSched_SpinMargin() {
    return std::chrono::nanoseconds(S().spinMarginNs.load());
}

XbmSchedStats XbmSched_Stats() {
    XbmSchedStats st;
    {
        std::lock_guard<std::mutex> lk(S().mtx);
        for (const auto& t : S().tasks) if (!t.cancelled) st.pending++;
    }
    {
        std::lock_guard<std::mutex> lk(S().statMtx);
        st.fired       = S().fired;
        st.lastLateUs  = S().lastLateUs;
        st.worstLateUs = S().worstLateUs;
        st.avgLateUs   = S().fired ? S().sumLateUs / (double)S().fired : 0.0;
    }
    { std::lock_guard<std::mutex> lk(S().uiMtx);   st.uiQueue   = S().uiQueue.size(); }
    { std::lock_guard<std::mutex> lk(S().poolMtx); st.poolQueue = S().poolQueue.size(); }
    st.realtimePriority = S().rtPriority.load();
    st.highResTimer     = S().highRes.load();
    st.poolThreads      = (int)S().pool.size();
    return st;
}

void XbmSched_ResetStats() {
    std::lock_guard<std::mutex> lk(S().statMtx);
    S().fired = 0; S().lastLateUs = 0; S().worstLateUs = 0; S().sumLateUs = 0;
}

// ---------------------------------------------------------------------------
// Kalender-Hilfen
// ---------------------------------------------------------------------------
namespace {
std::tm LocalTm(std::int64_t t) {
    std::time_t tt = (std::time_t)t;
    std::tm out{};
#if defined(_WIN32)
    localtime_s(&out, &tt);
#else
    localtime_r(&tt, &out);
#endif
    return out;
}
}  // namespace

XbmLocalTime XbmTime_ToLocal(std::int64_t t) {
    const std::tm tm = LocalTm(t);
    XbmLocalTime o{};
    o.year = tm.tm_year + 1900; o.month = tm.tm_mon + 1; o.day = tm.tm_mday;
    o.hour = tm.tm_hour; o.minute = tm.tm_min; o.second = tm.tm_sec;
    o.weekday = tm.tm_wday; o.yday = tm.tm_yday;
    return o;
}

std::int64_t XbmTime_FromLocal(int year, int month, int day,
                               int hour, int minute, int second) {
    std::tm tm{};
    tm.tm_year = year - 1900; tm.tm_mon = month - 1; tm.tm_mday = day;
    tm.tm_hour = hour; tm.tm_min = minute; tm.tm_sec = second;
    // -1 = "Sommerzeit unbekannt, bitte selbst herausfinden". Genau das
    // will man: bei 02:30 an einem Umstellungstag entscheidet die
    // Bibliothek, statt dass wir eine falsche Stunde festschreiben.
    tm.tm_isdst = -1;
    return (std::int64_t)std::mktime(&tm);
}

std::int64_t XbmTime_NowUtc() {
    return (std::int64_t)std::chrono::duration_cast<std::chrono::seconds>(
               WClock::now().time_since_epoch()).count();
}

std::int64_t XbmTime_LocalMidnight(std::int64_t t) {
    const XbmLocalTime l = XbmTime_ToLocal(t);
    return XbmTime_FromLocal(l.year, l.month, l.day, 0, 0, 0);
}

std::int64_t XbmTime_AddDays(std::int64_t t, int days) {
    // UEBER DIE KALENDERFELDER, nicht 86400*n: An Umstellungstagen hat der
    // Tag 23 oder 25 Stunden. Mit der Sekundenrechnung landet "morgen
    // 09:00" sonst auf 08:00 bzw. 10:00.
    XbmLocalTime l = XbmTime_ToLocal(t);
    return XbmTime_FromLocal(l.year, l.month, l.day + days,
                             l.hour, l.minute, l.second);
}

std::int64_t XbmTime_AddMonths(std::int64_t t, int months) {
    XbmLocalTime l = XbmTime_ToLocal(t);
    int m = l.month - 1 + months;
    int y = l.year + (m >= 0 ? m / 12 : -((-m + 11) / 12));
    m = ((m % 12) + 12) % 12;
    // Tagesueberlauf begrenzen (31. Januar + 1 Monat -> 28./29. Februar).
    static const int mdays[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    int maxd = mdays[m];
    if (m == 1 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)) maxd = 29;
    int d = l.day < maxd ? l.day : maxd;
    return XbmTime_FromLocal(y, m + 1, d, l.hour, l.minute, l.second);
}

std::string XbmTime_Format(std::int64_t t, const char* fmt) {
    const std::tm tm = LocalTm(t);
    char buf[128];
    const std::size_t n = std::strftime(buf, sizeof(buf), fmt, &tm);
    return std::string(buf, n);
}
