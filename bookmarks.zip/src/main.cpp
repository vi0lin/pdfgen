//
// main.cpp
//
// X Bookmark Manager -- C++ / Dear ImGui (via hello_imgui) port of the
// original Python/imgui-bundle desktop tool, built to also target Android
// via hello_imgui's SDL2+GLES3 backend.
//
// Run it: it opens a window listing your X bookmarks (newest first) with
// thumbnails where available. Select items (click/ctrl-click/shift-click/
// drag) and hit "Unbookmark selected" to remove them in bulk.
#include <GLFW/glfw3.h>
#ifndef IMGUI_DEFINE_MATH_OPERATORS   // zielweit schon per -D gesetzt
#define IMGUI_DEFINE_MATH_OPERATORS
#endif
#include "hello_imgui/hello_imgui.h"
#include "imgui.h"
#include "imgui_internal.h"  // ImGuiContext/ImGuiWindow fuer CollectPanelRects()
#include "backends/imgui_impl_glfw.h"
#include "backends/imgui_impl_opengl3.h"
#include "imgui_internal.h"
#ifdef _WIN32
#include "win32_window.h"
#include "backends/imgui_impl_win32.h"
#include <dwmapi.h>   // DwmEnableBlurBehindWindow (Fenstermodus: AUS)
#else
#include "clickthrough_overlay.h"
#endif
// Effekte laufen jetzt als GL-Renderings in ImGui-Fenstern (effects_gl):
// plattformuebergreifend (auch Android), verschiebbar, transparent, kein
// separates OS-Fenster, kein Click-through-Problem mehr.
#include "effects_gl.h"
#if defined(__linux__)
  #define GLFW_EXPOSE_NATIVE_X11
  #include <GLFW/glfw3native.h>
  #include <X11/Xlib.h>
#endif
#include "ui_helpers.h"
#include "bookmark_window.h"
#include "xbm_paths.h"     // data/-Ordner finden
#include "xbm_net_udp.h"   // UDP-Entdeckung/Synchronisation
#include "ui_scrub.h"      // Positionsregler
#include "ui_windoctor.h" // Diagnose: warum ist ein Fenster weg?
#include "ui_clickthru.h" // Durchklick-Entscheidung ueber ImGuis Hover-Test
#include "ui_titlebar.h"  // eigene Kopfzeile (Minimieren/Vollbild/Schliessen)
#include "xbm_sched.h"     // Zeitsteuerung (Termine, Erinnerungen, UI-Bruecke)
#include "xbm_update.h"
#include "xbm_crash.h"     // Absturz-/Fehlerberichte an den Monitor
#include "xbm_audio.h"     // Mikrofon + Transkription
#include "ui_calendar.h"   // Kalenderfenster
#include "ui_pages.h"
#include "ui_networking.h"
#include "ui_form.h"   // Tab "Netzwerk": Geraete, Befehle, Abgleich
#include "ui_jobs.h"   // Tab "Jobs": Queues (jobflow)
#include "ui_media.h"  // Tab "Media": Audio, Scrubber, Schnitt
#include "platform_manager.h" // X, Reddit, Facebook -- EIN Manager, drei Instanzen
#include "app_settings.h"
#if defined(XBM_RENDERER_VULKAN)
#include "vk_core.h"   // P0: Instance/Device-Selbsttest
#endif
#include "x_client.h"
#include "thumbnails.h"
#include <nlohmann/json.hpp>
#include <atomic>
#include <cmath>
#include <fstream>
#include <memory>
#include <mutex>
#include <sstream>
#include <thread>
#include <unordered_map>
#include <vector>
#if !defined(_WIN32)
  #include <unistd.h>   // gethostname -- Geraetename fuer die Fehlerberichte
#endif
#include "bewerben.h"
#if defined(__ANDROID__)
#include <android/log.h>
#define APP_LOG(...) __android_log_print(ANDROID_LOG_INFO, "XBookmarkManager", __VA_ARGS__)
#else
#include <cstdio>
#define APP_LOG(...) printf(__VA_ARGS__); printf("\n")
#endif
using json = nlohmann::json;
namespace {
// Truncates text to roughly max_chars, replacing the tail with "...".
// Mirrors Python's textwrap.shorten() closely enough for this UI's needs.
std::string shorten(const std::string& text, size_t max_chars) {
    std::string flat = text;
    for (char& c : flat) {
        if (c == '\n' || c == '\r') c = ' ';
    }
    if (flat.size() <= max_chars) return flat;
    if (max_chars < 4) return flat.substr(0, max_chars);
    return flat.substr(0, max_chars - 3) + "...";
}
}  // namespace
// ---------------------------------------------------------------------
// AppState
// ---------------------------------------------------------------------
struct AppState {
    std::unique_ptr<XClient> client;
    std::vector<Tweet> tweets;
    std::unordered_map<std::string, size_t> tweet_index_by_id;  // for O(1) lookup during delete
    std::unordered_set<std::string> selected;
    std::optional<int> last_clicked_index;
    ThumbnailManager thumbs;
    std::atomic<bool> loading{false};
    std::string status_message = "Not loaded yet.";
    std::atomic<bool> delete_in_progress{false};
    std::string delete_status;
    bool show_thumbnails = true;
    // unified press / drag / click selection state
    bool press_active = false;
    std::optional<int> press_index;
    ImVec2 press_pos{0, 0};
    bool is_dragging = false;
    enum class DragMode { Replace, Add, Subtract } drag_mode = DragMode::Replace;
    std::unordered_set<std::string> pre_drag_selection;
    // Cross-thread message passing: background threads append human
    // readable status strings here; the render loop drains them each
    // frame. Avoids touching std::string status_message directly from
    // worker threads (std::string isn't safely lock-free to write/read
    // across threads without synchronization).
    std::mutex status_mutex;
    std::string pending_status;
    bool has_pending_status = false;
    void set_status(const std::string& msg) {
        std::lock_guard<std::mutex> lock(status_mutex);
        pending_status = msg;
        has_pending_status = true;
    }
    void drain_status() {
        std::lock_guard<std::mutex> lock(status_mutex);
        if (has_pending_status) {
            status_message = pending_status;
            has_pending_status = false;
        }
    }
    // Same cross-thread pattern for the list of newly-loaded tweets: the
    // background loader thread appends pages here; the render loop
    // drains them into `tweets` each frame instead of touching the
    // vector directly from the worker thread.
    std::mutex pages_mutex;
    std::vector<std::vector<Tweet>> pending_pages;
    void push_page(std::vector<Tweet> page) {
        std::lock_guard<std::mutex> lock(pages_mutex);
        pending_pages.push_back(std::move(page));
    }
    void drain_pages() {
        std::vector<std::vector<Tweet>> pages;
        {
            std::lock_guard<std::mutex> lock(pages_mutex);
            pages.swap(pending_pages);
        }
        for (auto& page : pages) {
            for (auto& tweet : page) {
                tweet_index_by_id[tweet.id] = tweets.size();
                tweets.push_back(std::move(tweet));
            }
        }
    }
    // Cross-thread "delete finished" notifications, same pattern.
    std::mutex deleted_mutex;
    std::vector<std::string> pending_deleted_ids;
    int delete_total = 0;
    int delete_done = 0;
    void mark_deleted(const std::string& id) {
        std::lock_guard<std::mutex> lock(deleted_mutex);
        pending_deleted_ids.push_back(id);
    }
    void drain_deleted() {
        std::vector<std::string> ids;
        {
            std::lock_guard<std::mutex> lock(deleted_mutex);
            ids.swap(pending_deleted_ids);
        }
        for (auto& id : ids) {
            selected.erase(id);
            auto it = tweet_index_by_id.find(id);
            if (it == tweet_index_by_id.end()) continue;
            size_t idx = it->second;
            if (idx < tweets.size() && tweets[idx].id == id) {
                tweets.erase(tweets.begin() + static_cast<long>(idx));
                // Rebuild the index map since every subsequent index shifted.
                // Bookmarks lists are large but deletes happen in small
                // batches relative to total size, so this is acceptable.
                tweet_index_by_id.clear();
                for (size_t i = 0; i < tweets.size(); ++i) {
                    tweet_index_by_id[tweets[i].id] = i;
                }
            }
        }
    }
};
// ---------------------------------------------------------------------
// Background work
// ---------------------------------------------------------------------
void start_loading(AppState& state) {
    if (state.loading.load() || !state.client) return;
    state.loading = true;
    state.set_status("Loading bookmarks...");
    std::thread([&state] {
        int count = 0;
        try {
            state.client->fetch_all_bookmarks(
                [&state, &count](const std::vector<Tweet>& page) {
                    count += static_cast<int>(page.size());
                    state.push_page(page);
                    state.set_status("Loaded " + std::to_string(count) + " bookmarks...");
                }
            );
            state.set_status("Done. " + std::to_string(count) + " bookmarks loaded.");
        } catch (const std::exception& e) {
            state.set_status(std::string("Error loading bookmarks: ") + e.what());
        }
        state.loading = false;
    }).detach();
}
void start_delete_selected(AppState& state) {
    if (state.delete_in_progress.load() || state.selected.empty()) return;
    std::vector<std::string> ids(state.selected.begin(), state.selected.end());
    state.delete_in_progress = true;
    state.delete_total = static_cast<int>(ids.size());
    state.delete_done = 0;
    std::thread([&state, ids] {
        int ok_count = 0;
        for (size_t i = 0; i < ids.size(); ++i) {
            state.set_status("Removing " + std::to_string(i + 1) + "/" + std::to_string(ids.size()) + "...");
            bool success = state.client->delete_bookmark(ids[i]);
            if (success) {
                ok_count++;
                state.mark_deleted(ids[i]);
            }
            state.delete_done = static_cast<int>(i) + 1;
        }
        state.set_status("Removed " + std::to_string(ok_count) + "/" + std::to_string(ids.size()) + " bookmarks.");
        state.delete_in_progress = false;
    }).detach();
}
// ---------------------------------------------------------------------
// Cookie loading
// ---------------------------------------------------------------------
bool load_cookies(const std::string& path, std::string& auth_token, std::string& ct0) {
    std::ifstream in(path);
    if (!in) return false;
    try {
        json data = json::parse(in);
        if (!data.contains("auth_token") || !data.contains("ct0")) return false;
        auth_token = data["auth_token"].get<std::string>();
        ct0 = data["ct0"].get<std::string>();
        return true;
    } catch (...) {
        return false;
    }
}
void save_cookies(const std::string& path, const std::string& auth_token, const std::string& ct0) {
    json data = {{"auth_token", auth_token}, {"ct0", ct0}};
    std::ofstream out(path);
    out << data.dump(2);
}
// ---------------------------------------------------------------------
// GUI
// ---------------------------------------------------------------------
// Desktop only: a tiny inline cookie-entry form, since there's no
// terminal to type into once this is a packaged app (and none at all on
// Android). Shown until both fields are saved.
struct CookieEntryState {
    char auth_token_buf[256] = {0};
    char ct0_buf[256] = {0};
    bool show = false;
};
void draw_cookie_entry(AppState& state, CookieEntryState& entry, const std::string& cookie_path) {
    ImGui::TextWrapped(
        "No saved session found. Paste your X (Twitter) cookies below. "
        "See the README for how to find these in your browser's DevTools."
    );
    UiFormInput("auth_token", entry.auth_token_buf, sizeof(entry.auth_token_buf));
    UiFormInput("ct0", entry.ct0_buf, sizeof(entry.ct0_buf));
    if (ImGui::Button("Save and continue")) {
        std::string auth_token(entry.auth_token_buf);
        std::string ct0(entry.ct0_buf);
        if (!auth_token.empty() && !ct0.empty()) {
            save_cookies(cookie_path, auth_token, ct0);
            state.client = std::make_unique<XClient>(auth_token, ct0);
            entry.show = false;
        }
    }
}

std::vector<ImRect> g_panelRects;

// DIE DREI PLATTFORMEN -- derselbe Code, dreimal instanziert.
// [Vorher stand der ganze Ablauf (Zustand, Laden, Loeschen, Cookies)
//  fest fuer X in AppState und main.cpp. Jetzt kennt ihn PlatformManager
//  einmal; die Plattformen unterscheiden sich nur in der Quelle.]
static PlatformManager& PmX()        { static PlatformManager m(MakeXSource());        return m; }
static PlatformManager& PmReddit()   { static PlatformManager m(MakeRedditSource());   return m; }
static PlatformManager& PmFacebook() { static PlatformManager m(MakeFacebookSource()); return m; }
// NICHT VOR main() ERZEUGEN.
// [So stand es hier:
//      static PlatformManager* AllePm[] = { &PmX(), &PmReddit(), ... };
//  Ein statisches Feld wird bei der Initialisierung der Datei gefuellt --
//  also VOR main(). Damit entstanden die drei Manager (und ihre
//  ThumbnailManager) bevor set_thumbnail_cache_dir() den Pfad gesetzt
//  hatte. Der Konstruktor rief create_directories auf einem leeren Pfad
//  und warf:
//      cannot create directories: Invalid argument []
//  Eine Funktion statt eines Feldes: die drei entstehen beim ersten
//  Aufruf, und der liegt in gui() -- lange nach dem Pfad.]
static PlatformManager** AllePmListe() {
    static PlatformManager* a[3] = { &PmX(), &PmReddit(), &PmFacebook() };
    return a;
}
#define AllePm_BEGIN (AllePmListe())
#define AllePm_ENDE  (AllePmListe() + 3)

// Sammelt die Rechtecke aller sichtbaren ImGui-Fenster, die EINGABEN
// FANGEN sollen. Die Liste speist auf beiden Plattformen ausschliesslich
// die Trefferpruefung fuer Click-through (Linux: GLFW_MOUSE_PASSTHROUGH,
// Windows: WS_EX_TRANSPARENT). Sie beschneidet NICHTS Sichtbares mehr --
// die Win32-Fensterregion steht dauerhaft auf NULL (siehe Renderschleife).
//
// >>> DER FEHLER, DER HIER JAHRELANG SASS <<<
// "if (w->Flags & ImGuiWindowFlags_ChildWindow) continue;" sieht nach
// "echte Kindfenster raus" aus, wirft aber JEDES ANGEDOCKTE FENSTER weg:
// ImGui setzt in BeginDocked() ausdruecklich
//     window->Flags |= ImGuiWindowFlags_ChildWindow | ImGuiWindowFlags_NoResize;
// (imgui.cpp; im Settings-Code steht sogar der Kommentar "Cannot rely on
// ImGuiWindowFlags_ChildWindow here as docked windows have this set").
// Folge: der komplette Inhalt eines Kompakt-Layouts war fuer die
// Trefferpruefung unsichtbar -> Klicks auf angedockte Panels fielen als
// "freie Flaeche" durch. Genau der Windows-Passthrough-Effekt.
// Richtig ist: nur echte Kindfenster ausschliessen, angedockte behalten.
static void CollectPanelRects() {
    ImGuiContext* ctx = ImGui::GetCurrentContext();
    if (!ctx) return;
    // BEZUGSSYSTEM: Sind Multi-Viewports aktiv, liegen w->Pos im
    // DESKTOP-Koordinatensystem. Unsere Trefferpruefung arbeitet aber
    // fensterrelativ (XQueryPointer bzw. ScreenToClient), also den
    // Ursprung des Hauptviewports abziehen. Ohne Viewports ist der (0,0)
    // und die Rechnung ein No-op.
    ImGuiViewport* mvp = ImGui::GetMainViewport();
    const ImVec2 org = mvp ? mvp->Pos : ImVec2(0.0f, 0.0f);
    for (ImGuiWindow* w : ctx->Windows) {
        if (!w->WasActive || w->Hidden) continue;
        // Echte Kindfenster raus, ANGEDOCKTE drin (s. Kommentar oben).
        if ((w->Flags & ImGuiWindowFlags_ChildWindow) && !w->DockIsActive)
            continue;
        // NoInputs-Fenster (transparentes Overlay): dort ist Durchklicken
        // der Sinn der Sache.
        if (w->Flags & ImGuiWindowFlags_NoInputs) continue;
        // Der Seiten-Host "##page_host_*" ist ein VOLLBILDfenster. Sein
        // Hintergrund UND der leere Teil des DockSpace darin sind "freie
        // Flaeche" im Sinne des Nutzers -- stuende er in der Liste, gaebe
        // es nirgends eine freie Stelle. Die angedockten Fenster darin
        // stehen einzeln in der Liste und fangen weiterhin.
        if (strncmp(w->Name, "##page_host_", 12) == 0) continue;
        // Fenster in einem EIGENEN OS-Viewport haben ein eigenes
        // Betriebssystem-Fenster mit eigener Eingabebehandlung; ihre
        // Rechtecke gehoeren nicht in die Region des Hauptfensters.
        if (mvp && w->Viewport && w->Viewport->ID != mvp->ID) continue;
        g_panelRects.push_back(ImRect(
            ImVec2(w->Pos.x - org.x, w->Pos.y - org.y),
            ImVec2(w->Pos.x - org.x + w->Size.x,
                   w->Pos.y - org.y + w->Size.y)));
    }
}

// SICHERHEITSNETZ gegen "Fenster ist weg". Ohne Multi-Viewports kann
// ImGui nur INNERHALB des Hauptfensters zeichnen. Landet ein frei
// schwebendes Fenster (z.B. frisch abgedockt, oder aus einer Sitzung mit
// eingeschalteten Multi-Viewports uebernommen) VOLLSTAENDIG ausserhalb
// des Canvas, ist es unsichtbar und per Maus nicht mehr erreichbar.
// Hier wird nur der Totalfall korrigiert -- teilweise ueberstehende
// Fenster bleiben unangetastet, damit diese Automatik der Layout-
// Zustandsmaschine nie ins Handwerk pfuscht.
static void RescueOffscreenWindows() {
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g) return;
    if (ImGui::GetIO().ConfigFlags & ImGuiConfigFlags_ViewportsEnable)
        return;                       // eigene OS-Fenster sind erlaubt
    ImGuiViewport* vp = ImGui::GetMainViewport();
    if (!vp) return;
    const ImRect canvas(vp->WorkPos,
                        ImVec2(vp->WorkPos.x + vp->WorkSize.x,
                               vp->WorkPos.y + vp->WorkSize.y));
    for (ImGuiWindow* w : g->Windows) {
        if (!w->WasActive || w->Hidden) continue;
        if (w->DockNode != nullptr) continue;   // gedockt: Layout regelt
        if (w->Flags & (ImGuiWindowFlags_ChildWindow
                        | ImGuiWindowFlags_Tooltip
                        | ImGuiWindowFlags_Popup)) continue;
        const ImRect r(w->Pos, ImVec2(w->Pos.x + w->Size.x,
                                      w->Pos.y + w->Size.y));
        const bool fullyOutside = r.Max.x <= canvas.Min.x
                               || r.Min.x >= canvas.Max.x
                               || r.Max.y <= canvas.Min.y
                               || r.Min.y >= canvas.Max.y;
        if (!fullyOutside) continue;
        float nx = r.Min.x, ny = r.Min.y;
        if (nx < canvas.Min.x)              nx = canvas.Min.x + 24.0f;
        if (nx > canvas.Max.x - 80.0f)      nx = canvas.Max.x - 80.0f;
        if (ny < canvas.Min.y)              ny = canvas.Min.y + 24.0f;
        if (ny > canvas.Max.y - 60.0f)      ny = canvas.Max.y - 60.0f;
        ImGui::SetWindowPos(w, ImVec2(nx, ny), ImGuiCond_Always);
        printf("[rettung] Fenster '%s' lag ausserhalb des Canvas -> "
               "zurueck auf (%.0f,%.0f)\n", w->Name, nx, ny);
    }
}

// Maustaste laut Systemabfrage gehalten? Waehrend eines laufenden Klicks
// wird der Durchlass-Zustand EINGEFROREN, sonst kaeme beim Gegenueber ein
// halber Klick an (Druck hier, Loslassen drueben).
static bool g_ptrButtonHeld = false;

#if defined(_WIN32)
// Fenstergriff fuer die Haken der eigenen Kopfzeile.
static HWND g_hwndForBar = nullptr;
// Zustandsmerker der Durchklick-Verwaltung. Liegt bewusst AUSSERHALB der
// Renderschleife, damit die Modusumschaltung ihn zuruecksetzen kann: sonst
// haelt ein "pass == prevPass" den erweiterten Fensterstil auf dem Stand
// von vor dem Wechsel fest.
static int g_win32PrevPass = -1;
static void XbmWin_ResetPassthroughLatch() { g_win32PrevPass = -1; }
#endif

// Ist die App im randlosen Vollbild (= Desktop-Overlay-Betrieb)?
// Nur dann sind transparenter Hintergrund und Click-through gewollt.
// Im FENSTER-Modus ist die App ein ganz normales Fenster: deckender
// Hintergrund, kein Klick faellt zum Desktop durch.
static bool OverlayModeActive() { return UiAppFullscreen(); }

#if !defined(_WIN32)
// Merker der Durchklick-Verwaltung (Linux). Global, damit der
// Modus-Umschalter ihn zuruecksetzen kann.
static int g_linuxPrevPass = -1;
#endif

// Hintergrund des Frames setzen und loeschen.
//  * Overlay/Vollbild: Alpha 0 -- der Desktop scheint durch.
//  * Fenster-Modus:    deckende Themefarbe. [Zuvor wurde IMMER mit
//    Alpha 0 geloescht; ein durchsichtiger Shader-Canvas liess damit
//    auch im Fenster-Modus den Desktop durchscheinen -- das Fenster
//    hatte optisch gar keinen Hintergrund.]
static void ClearFrameBackground() {
    if (OverlayModeActive()) {
        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    } else {
        const ImVec4 c = ImGui::GetStyle().Colors[ImGuiCol_WindowBg];
        glClearColor(c.x, c.y, c.z, 1.0f);
    }
    glClear(GL_COLOR_BUFFER_BIT);
}
GLFWwindow* window = nullptr;

void gui(AppState& state, CookieEntryState& entry, const std::string& cookie_path) {

    // =====================================================================
    // PAGES ZUERST: Der DockSpace des Kompakt-Layouts muss VOR saemtlichen
    // Seitenfenstern submittet werden -- jedes davor gezeichnete Fenster
    // kann prinzipbedingt nicht andocken (Ursache des "Monitor snappt
    // rein, Rest fliegt raus"-Verhaltens: Rain/Spin/Dreieck standen im
    // gui() VOR dem Pages-Block). Neue Fenster IMMER unterhalb einfuegen.
    // =====================================================================
    if (EffectsGl_Settings().dockingEnabled)
        ImGui::GetIO().ConfigFlags |=  ImGuiConfigFlags_DockingEnable;
    else if (!(UiActivePage() && UiActivePage()->compact))
        // Docking-Flag NIE kappen, solange die aktive Seite kompakt ist:
        // ohne das Flag kehrt DockSpace() intern frueh zurueck, und
        // DockBuilderAddNode liefert NULL -> Null-Deref beim naechsten
        // Layout-Wiederaufbau (der gemeldete SIGSEGV). Die Checkbox
        // regelt Nutzer-Docking; das Kompakt-Fundament braucht das Flag.
        ImGui::GetIO().ConfigFlags &= ~ImGuiConfigFlags_DockingEnable;
    if (UiPages().empty()) {
        UiPages().push_back({"Haupt"});
        UiPages().push_back({"Effekte"});
        UiPages().push_back({"Bewerben"});
        // Modell pro Fenster: UiWinShared = ein Fenster ueberall (Daten
        // eins, Geometrie pro Seite); UiWinPerPage = eigene Instanz
        // "Name##Seite" mit komplett eigenem Zustand.
        UiPageAdd("Haupt",   "X Bookmark Manager",       UiWinShared);
        UiPageAdd("Haupt",   "Eingabe-Monitor",          UiWinShared);
        // WICHTIG: JEDES dockbare Fenster gehoert in eine Registry --
        // unregistrierte Fenster sind fuer die Zustandsmaschine Fremd-
        // koerper: manuell in einen Host gedockt, filtert die (korrekte)
        // Cross-Tab-Schutzlogik sie aus dem Seiten-Baum, und der naechste
        // Wiederaufbau wirft sie hinaus (der "Login dockt ab"-Effekt).
        // EIN Fenster je Plattform -- der Login sitzt darin (oben,
        // aufgeklappt bis zur Anmeldung, danach ueber den Titel-Knopf).
        // [Die getrennten "... Login (Cookies)"-Fenster sind damit weg:
        //  ein Fenster weniger je Plattform, und alle drei bedienen sich
        //  gleich.]
        UiPageAdd("Haupt",   "Reddit Bookmark Manager",  UiWinShared);
        UiPageAdd("Haupt",   "Facebook Bookmark Manager",UiWinShared);
        // Cookies je Plattform laden (cookies_x.json, cookies_reddit.json, ...)
        {
            std::string cdir = HelloImGui::IniFolderLocation(
                HelloImGui::IniFolderType::AppUserConfigFolder);
            for (auto** it = AllePm_BEGIN; it != AllePm_ENDE; ++it) (*it)->LoadCookies(cdir);
        }
        UiPageAdd("Effekte", "Rain",                     UiWinShared);
        UiPageAdd("Effekte", "Spin (ziehen = drehen)",   UiWinShared);
        UiPageAdd("Effekte", "Dreieck (normal)",         UiWinShared);
        // MODELL B (eigene Instanz je Seite): Ein GETEILTES Fenster kann
        // nur an EINER Stelle gedockt sein -- beim Seitenwechsel verlor
        // es daher seinen Platz. Mit "Shader-Canvas##Seite" haelt jede
        // Seite ihre eigene Dock-Position.
        UiPageAdd("Effekte", "Shader-Canvas",            UiWinPerPage);
        UiPageAdd("Haupt",   "Shader-Canvas",            UiWinPerPage);
        UiPageAdd("Bewerben","Prototype",                UiWinPerPage);
        // KALENDER: eigene Seite. UiWinPerPage waere hier falsch -- es gibt
        // nur EINEN Kalender, und sein Zustand lebt in calendar.json, nicht
        // pro Seite.
        UiPages().push_back({"Kalender"});
        UiPageAdd("Kalender", "Kalender",                UiWinShared);
        // NETZWERK: eigene Seite. UiWinShared, denn es gibt nur EINEN
        // Netzknoten -- sein Zustand lebt in XbmNetNode, nicht je Seite.
        UiPages().push_back({"Netzwerk"});
        UiPageAdd("Netzwerk", "Netzwerk",                UiWinShared);
        // JOBS: Queues aus jobflow (Vorlagen, Jobbaum, Laeufe). UiWinShared.
        UiPages().push_back({"Jobs"});
        UiPageAdd("Jobs", "Jobs",                        UiWinShared);
        UiJobs_Init(UiCalendar_DataDir());
        // MEDIA: Audio (Video folgt): Dateien, Wellenform, Scrubber, Schnitt.
        UiPages().push_back({"Media"});
        UiPageAdd("Media", "Media",                      UiWinShared);
        UiMedia_Init(XbmPaths_UserData(), XbmPaths_DataRoot());
        UiNetworking_Start();
        // TEST-TABS zum Pruefen von Ueberlauf und Scrollen der Tab-Leiste.
        // [Wieder entfernen, wenn es sitzt -- oder XBM_TEST_TABS auf 0.]
        #ifndef XBM_TEST_TABS
        #define XBM_TEST_TABS 0
        #endif
        for (int ti = 1; ti <= XBM_TEST_TABS; ++ti) {
            std::string tn = "Test " + std::to_string(ti);
            UiPages().push_back({tn});
        }
        BewerbenInit();
        AppSettings::Load("xbm.ini");   // neben imgui.ini im Arbeitsverz.
    }
    AppSettings::Periodic();
    // NETZWERK JEDEN FRAME BEDIENEN -- auch wenn der Tab nicht sichtbar
    // ist. [Steht der Aufruf im Zeichencode des Tabs, laufen Entdeckung
    //  und Abgleich nur, solange man hinsieht. Das ist der Fehler, den
    //  man hinterher lange sucht.]
    UiNetworking_Poll();
    UiPagesFrame(/*touchMode=*/false);
    {   // Rand-Automatik: am Rand weiterscrollen, solange eine Geste
        // laeuft (Pinpoint-Scroll oder Fenster-/Tab-Zug).
        ImGuiViewport* evp = ImGui::GetMainViewport();
        UiEdgeAutoScroll(evp->WorkPos.y, evp->WorkPos.y + evp->WorkSize.y);
    }
    // Registriert ist "Prototype" (nicht "Bewerben") -- UiPageWindow
    // liefert daraus den gescopten Titel "Prototype##Bewerben".
    {
        const char* tProto = UiPageWindow("Prototype");
        UiWinDoctor_NoteSubmit("Prototype", tProto);
        if (tProto) UiDrawBewerbenUI(tProto, nullptr);
    }
    // Kalender -- wie jedes Seitenfenster NACH UiPagesFrame() submittet,
    // sonst kann er nicht andocken (siehe Dock-Regel oben).
    {
        static bool showCal = true;
        const char* tCal = UiPageWindow("Kalender");
        UiWinDoctor_NoteSubmit("Kalender", tCal);
        if (tCal) UiCalendar_Draw(tCal, &showCal, UiWinFlags(tCal));
    }
    // Netzwerk -- ebenfalls NACH UiPagesFrame() submittet (Dock-Regel).
    {
        const char* tNet = UiPageWindow("Netzwerk");
        UiWinDoctor_NoteSubmit("Netzwerk", tNet);
        if (tNet) {
            bool offen = true;
            if (ImGui::Begin(tNet, &offen, UiWinFlags(tNet)))
                UiNetworking_Draw();
            ImGui::End();
        }
    }
    // Media -- NACH UiPagesFrame() submittet.
    {
        const char* tMed = UiPageWindow("Media");
        UiWinDoctor_NoteSubmit("Media", tMed);
        if (tMed) {
            bool offen = true;
            if (ImGui::Begin(tMed, &offen, UiWinFlags(tMed)))
                UiMedia_Draw();
            ImGui::End();
        }
    }
    // Jobs -- ebenfalls NACH UiPagesFrame() submittet.
    {
        UiJobs_Poll();
        const char* tJobs = UiPageWindow("Jobs");
        UiWinDoctor_NoteSubmit("Jobs", tJobs);
        if (tJobs) {
            bool offen = true;
            if (ImGui::Begin(tJobs, &offen, UiWinFlags(tJobs)))
                UiJobs_Draw();
            ImGui::End();
        }
    }
    // (UiGlobalDragScroll ans gui()-Ende verlegt, s.u.)
    // WICHTIG: Seitenfenster MUESSEN NACH UiPagesFrame submittet werden.
    // Ein Fenster, das VOR seinem DockSpace gezeichnet wird, kann in dem
    // Frame nicht andocken (ImGui setzt es floatend) -> der Monitor konnte
    // strukturell nie einrasten -> Dauer-Rebuild -> alle Fenster sprangen
    // im 0,3s-Takt aus dem Kompakt-Layout, inkl. weiss flackerndem
    // Uebergangs-Dock-Knoten als "zweitem" Monitor.
    static bool showInputDbg = true;
    if (UiPageWindow("Eingabe-Monitor"))
        UiShowInputDebugWindow(&showInputDbg);
    state.thumbs.poll();

    // Rain & Spin als verschiebbare ImGui-Fenster (ersetzt die Vulkan-
    // Overlay-Fenster mit ihren schwarzen Hintergruenden).
    static bool showRain = true, showSpin = true;
    static bool showTriN = true, showTriOv = true;
    // GATES (die lange offene Restluecke): Seitenfenster duerfen NUR auf
    // ihrer Seite submittet werden. Ein Fenster, das auf einer fremden
    // Seite gezeichnet wird, waehrend sein DockSpace dort nicht submittet
    // ist, faellt bei ImGui auf Floating zurueck -- daher die konstanten
    // "Overlay"-Positionen ueber alle Tabs und das Herausfallen trotz
    // Andockung.
    if (UiPageWindow("Rain"))
        EffectsGl_ShowRainWindow(&showRain);
    if (UiPageWindow("Spin (ziehen = drehen)"))
        EffectsGl_ShowSpinWindow(&showSpin);
    if (UiPageWindow("Dreieck (normal)"))
        EffectsGl_ShowTriangleNormal(&showTriN);
    // Das ORANGE, TRANSPARENTE Dreieck ist das Overlay-Fenster --
    // hier gehoert die Checkbox hin (das Gate sass zuvor faelschlich
    // auf "Dreieck (normal)", weshalb das Overlay unbeirrt weiterflog).
    if (EffectsGl_Settings().showTriangle)
        EffectsGl_ShowTriangleOverlay(&showTriOv);
#if defined(XBM_RENDERER_VULKAN)
    static bool vkLogged = false;
    if (!vkLogged) { VkCore_SelftestLog(); vkLogged = true; }
#endif
    // (Pages-Block an den gui()-Anfang verschoben, s.u.)

    EffectsGl_DrawBackground();  // 2.2: Shader hinter allen Fenstern
    EffectsGl_DrawOverlay();     // 2.3: Shader-Overlay ueber allem
    ImGui::GetIO().ConfigWindowsMoveFromTitleBarOnly = true;
    state.drain_status();
    state.drain_pages();
    state.drain_deleted();
    // ImGui::Begin("MainDockhost", nullptr, dockspace_flags);
    // ImGui::DockSpace(dockspace_id);
    // ImGui::End();
    // ImGui::SetNextWindowSize(ImVec2(940, 740), ImGuiCond_FirstUseEver);
    // ImGuiViewport* viewport = ImGui::GetMainViewport();
    // ImGui::SetNextWindowPos(viewport->WorkPos);
    // ImGui::SetNextWindowSize(viewport->WorkSize);
    // ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0,0,0,0));
    // ImGui::Begin("X Bookmark Manager");
    //
    // ["New Window"/"TEST"-Fenster entfernt. ACHTUNG: Sein
    //  g_panelRects.clear() war der Sammelbeginn des Frames -- der
    //  zieht jetzt hierher, sonst wachsen die Rechtecke unbegrenzt.]
    g_panelRects.clear();

    // ---- Die drei Plattformen: Manager + Login, untereinander ---------
    // [Der bisherige X-Block (Items, Callbacks, DrawBookmarkWindow) lebt
    //  jetzt in PlatformManager::DrawManager -- einmal fuer alle drei.]
    for (auto** it = AllePm_BEGIN; it != AllePm_ENDE; ++it) (*it)->Drain();
    {
        struct { PlatformManager* pm; const char* mgr; } fenster[] = {
            { &PmX(),        "X Bookmark Manager"        },
            { &PmReddit(),   "Reddit Bookmark Manager"   },
            { &PmFacebook(), "Facebook Bookmark Manager" },
        };
        // EIN EINZIGER SCHALTER: UiWinOpen.
        // [Hier lag ein ZWEITER, unabhaengiger Schalter (show/sichtbar).
        //  Damit gab es zwei Wahrheiten: das X setzte UiWinOpen auf
        //  false, aber DrawManager bekam weiter &sichtbar(...) == true --
        //  und UiConsumeOpen verbrauchte den Wunsch sogar, BEVOR
        //  UiPageWindow ihn lesen konnte. Ergebnis: Reddit und Facebook
        //  liessen sich nie schliessen.
        //  Jetzt gibt es nur UiWinOpen. UiPageWindow liefert nullptr,
        //  sobald es false ist -- das Fenster wird dann gar nicht
        //  gezeichnet, und die Palette zeigt es an.]
        for (auto& f : fenster) {
            if (const char* t = UiPageWindow(f.mgr))
                f.pm->DrawManager(t, &UiWinOpen(f.mgr), UiWinFlags(t));
        }
    }

    // Globaler Drag-Scroll-Standard am gui()-Ende (nach allen Fenstern),
    // Desktop derzeit inaktiv -- Aufruf fuer kuenftige Touch-Desktops.
    UiLayoutLockEnforce();    // globale Sperre zuerst
    UiFixedHeightEnforce();
    UiGlobalDragScroll(/*touchMode=*/false);
}
// ---------------------------------------------------------------------
// main initial working
// ---------------------------------------------------------------------
// int main(int, char**) {
//     AppState state;
//     CookieEntryState entry;
//     // Writable, per-platform-correct location for cookies.json. On
//     // Android this resolves to the app's private data directory; on
//     // desktop, a folder next to user settings.
//     std::string cookie_path = HelloImGui::IniFolderLocation(HelloImGui::IniFolderType::AppUserConfigFolder) + "/cookies.json";
//     std::cout<<cookie_path+"\n";
//     std::string auth_token, ct0;
//     if (load_cookies(cookie_path, auth_token, ct0)) {
//         state.client = std::make_unique<XClient>(auth_token, ct0);
//     } else {
//         entry.show = true;
//     }
//     // Point the thumbnail cache at a writable, platform-correct folder
//     // too (same reasoning as cookies.json above).
//     extern void set_thumbnail_cache_dir(const std::string&);
//     set_thumbnail_cache_dir(
//         HelloImGui::IniFolderLocation(HelloImGui::IniFolderType::AppUserConfigFolder) + "/thumb_cache"
//     );
//     HelloImGui::RunnerParams runner_params;
//     runner_params.appWindowParams.windowTitle = "X Bookmark Manager";
//     // runner_params.appWindowParams.windowGeometry.size = {940, 740};
//     runner_params.appWindowParams.windowGeometry.fullScreenMode = HelloImGui::FullScreenMode::FullMonitorWorkArea;
//     runner_params.imGuiWindowParams.defaultImGuiWindowType = HelloImGui::DefaultImGuiWindowType::NoDefaultWindow;
//     // runner_params.appWindowParams.alphaBlend = true;
//     // ImGuiViewport* viewport = ImGui::GetMainViewport();
//     // runner_params.appWindowParams.windowGeometry.size = {int(viewport->WorkSize[0]), int(viewport->WorkSize[1])};
//     // runner_params.appWindowParams.windowGeometry.size = {
//     //   static_cast<int>(viewport->WorkSize.x),
//     //   static_cast<int>(viewport->WorkSize.y)
//     // };
//     // runner_params.appWindowParams.windowGeometry.pos = {
//     //   static_cast<int>(viewport->WorkPos.x),
//     //   static_cast<int>(viewport->WorkPos.y)
//     // };
//     runner_params.callbacks.ShowGui = [&state, &entry, &cookie_path] { gui(state, entry, cookie_path); };
//     // Performance: this is a static tool, nothing animates, so there's
//     // no need to redraw at hundreds of fps.
//     runner_params.fpsIdling.enableIdling = true;
//     runner_params.fpsIdling.fpsIdle = 3.0f;
//     runner_params.fpsIdling.fpsMax = 30.0f;
//     runner_params.fpsIdling.timeActiveAfterLastEvent = 1.0f;
//     HelloImGui::Run(runner_params);
//     return 0;
// }

// int main(int, char**) {
//   AppState state;
//   CookieEntryState entry;
//     std::string cookie_path = HelloImGui::IniFolderLocation(HelloImGui::IniFolderType::AppUserConfigFolder) + "/cookies.json";
//     std::cout<<cookie_path+"\n";
//     std::string auth_token, ct0;
//     if (load_cookies(cookie_path, auth_token, ct0)) {
//         state.client = std::make_unique<XClient>(auth_token, ct0);
//     } else {
//         entry.show = true;
//     }
//     // Point the thumbnail cache at a writable, platform-correct folder
//     // too (same reasoning as cookies.json above).
//     extern void set_thumbnail_cache_dir(const std::string&);
//     set_thumbnail_cache_dir(
//         HelloImGui::IniFolderLocation(HelloImGui::IniFolderType::AppUserConfigFolder) + "/thumb_cache"
//     );
//     HelloImGui::RunnerParams runner_params;
//     runner_params.appWindowParams.windowTitle = "X Bookmark Manager";
//     // runner_params.appWindowParams.windowGeometry.size = {940, 740};
//     runner_params.appWindowParams.windowGeometry.fullScreenMode = HelloImGui::FullScreenMode::FullMonitorWorkArea;
//     runner_params.imGuiWindowParams.defaultImGuiWindowType = HelloImGui::DefaultImGuiWindowType::NoDefaultWindow;
//     // runner_params.appWindowParams.alphaBlend = true;
//     // ImGuiViewport* viewport = ImGui::GetMainViewport();
//     // runner_params.appWindowParams.windowGeometry.size = {int(viewport->WorkSize[0]), int(viewport->WorkSize[1])};
//     // runner_params.appWindowParams.windowGeometry.size = {
//     //   static_cast<int>(viewport->WorkSize.x),
//     //   static_cast<int>(viewport->WorkSize.y)
//     // };
//     // runner_params.appWindowParams.windowGeometry.pos = {
//     //   static_cast<int>(viewport->WorkPos.x),
//     //   static_cast<int>(viewport->WorkPos.y)
//     // };
//     // Performance: this is a static tool, nothing animates, so there's
//     // no need to redraw at hundreds of fps.
//     runner_params.fpsIdling.enableIdling = true;
//     runner_params.fpsIdling.timeActiveAfterLastEvent = 1.0f;
//     // HelloImGui::Run(runner_params);
//     // HelloImGui::RunnerParams runner_params;
//     runner_params.imGuiWindowParams.defaultImGuiWindowType = HelloImGui::DefaultImGuiWindowType::NoDefaultWindow;
//     runner_params.callbacks.PostInit = [&]() {
//         g_glfwWindow = static_cast<GLFWwindow*>(HelloImGui::GetRunnerParams()->backendPointers.glfwWindow);
//         // NOTE: SetupWindowHintsForTransparency() must run BEFORE window creation —
//         // HelloImGui doesn't expose a pre-creation hint hook directly, so the
//         // practical route is to fork/patch hello_imgui's GLFW backend init to call
//         // glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, GLFW_TRUE) before glfwCreateWindow,
//         // OR build your own minimal GLFW+ImGui loop instead of HelloImGui::Run()
//         // if you need this hint guaranteed to land before window creation.
//         ClickThroughOverlay::InitPlatformWindow(g_glfwWindow);
//     };
//     runner_params.callbacks.ShowGui = [&state, &entry, &cookie_path] { gui(state, entry, cookie_path); };
//     // runner_params.callbacks.ShowGui = [&]() {
//     //     g_panelRects.clear();
//     //     ImGui::Begin("Panel A");
//     //     g_panelRects.push_back(ImRect(ImGui::GetWindowPos(),
//     //                                    ImGui::GetWindowPos() + ImGui::GetWindowSize()));
//     //     ImGui::Text("Content A");
//     //     ImGui::End();
//     //     ImGui::Begin("Panel B");
//     //     g_panelRects.push_back(ImRect(ImGui::GetWindowPos(),
//     //                                    ImGui::GetWindowPos() + ImGui::GetWindowSize()));
//     //     ImGui::Text("Content B");
//     //     ImGui::End();
//     // };
//     // runner_params.callbacks.AfterEndFrame = [&]() {
//     //     ClickThroughOverlay::UpdateClickThroughRegion(g_glfwWindow, g_panelRects);
//     // };
//     HelloImGui::Run(runner_params);
// }

int main(int argc, char** argv) {
  (void)argc;
  // ALS ALLERERSTES: Pfade aufloesen. Alles Weitere -- Vorlagen, Assets,
  // Kalenderordner -- haengt daran.
  XbmPaths_Init(argv && argv[0] ? argv[0] : nullptr);
  XbmNet_Init();
  AppState state;
  CookieEntryState entry;
  std::string cookie_path = HelloImGui::IniFolderLocation(HelloImGui::IniFolderType::AppUserConfigFolder) + "/cookies.json";
  std::cout<<cookie_path+"\n";
  std::string auth_token, ct0;
  if (load_cookies(cookie_path, auth_token, ct0)) {
      state.client = std::make_unique<XClient>(auth_token, ct0);
  } else {
      entry.show = true;
  }
  // Point the thumbnail cache at a writable, platform-correct folder
  // too (same reasoning as cookies.json above).
  extern void set_thumbnail_cache_dir(const std::string&);
  set_thumbnail_cache_dir(
      HelloImGui::IniFolderLocation(HelloImGui::IniFolderType::AppUserConfigFolder) + "/thumb_cache"
  );


  // -------------------------------------------------------------------------
  // Zeitsteuerung, Mikrofon und Kalender aufsetzen.
  // Reihenfolge zaehlt: der Scheduler traegt die UI-Bruecke, ueber die die
  // Transkription ihr Ergebnis zurueckreicht -- er muss vor dem Kalender
  // laufen.
  // -------------------------------------------------------------------------
  {
      // Fenster-Doktor: mit  XBM_DOKTOR=1 ./x_bookmark_manager  einschalten.
      // Meldet auf stderr, sobald sich der Sichtbarkeitszustand eines
      // beobachteten Fensters aendert -- inklusive Klartext-Befund.
      if (const char* dv = getenv("XBM_DOKTOR")) {
          if (dv[0] == '1') {
              UiWinDoctor_SetEnabled(true);
              UiWinDoctor_Watch("Prototype");
              UiWinDoctor_Watch("Kalender");
              printf("[doktor] eingeschaltet (XBM_DOKTOR=1)\n");
          }
      }
      // Sichtprobe der Durchklick-Flaechen: XBM_CTMAP=1 faerbt alles ein,
      // was das Programm fuer bedienbar haelt. Damit sieht man in einem
      // Lauf, ob die Entscheidung mit dem Bild uebereinstimmt.
      if (const char* cm = getenv("XBM_CTMAP")) UiClickThru_SetDebug(cm[0] == '1');
      XbmSched_Start(/*poolThreads=*/2);
      // UPDATE-CHECK. [BITTE ANPASSEN: die Rohdatei-URL deiner release.json
      //  im Git-Server -- typischerweise nach dem Muster
      //      http://<server>:<port>/<benutzer>/<releases-repo>/raw/branch/main/release.json
      //  Format der Datei: siehe xbm_update.h. Zeigt bei einer neueren
      //  Version einen Alert (ui_alerts.h) mit "Installieren"-Knopf --
      //  das Herunterladen/Anwenden selbst ist ein spaeterer Schritt.]
      // Rohdatei-URL im Releases-Repo (siehe publish_release.sh -- dasselbe
      // Muster, das dort fuer die Paket-URLs verwendet wird).
      // Auto-Update-Schalter VOR der ersten Pruefung setzen -- sonst
      // wuerde eine beim Start erkannte Version nicht automatisch geladen.
      XbmUpdate_SetAuto(UiFlagGet("update.auto", false));
      XbmUpdate_PruefenAsync(
          "http://192.168.1.69:3000/releases/raw/branch/main/release.json");
      // Windows-Update: das Nachlauf-Script braucht einen beendeten
      // Prozess -- sauber ueber das Fenster, damit Einstellungen noch
      // gesichert werden.
      XbmUpdate_BeendenHook = [] { if (window) glfwSetWindowShouldClose(window, GLFW_TRUE); };

      const std::string dataDir =
          HelloImGui::IniFolderLocation(HelloImGui::IniFolderType::AppUserConfigFolder);
      XbmPaths_SetUserDir(dataDir);
      // ABSTURZ-/FEHLERBERICHTE: ab hier faengt die App Signale ab und
      // schreibt Berichte nach <UserData>/logs; ungesendete gehen an den
      // Monitor (URL in den Einstellungen, gespeichert als Text
      // "monitor.url"). Geraetename = Rechnername.
      {
          char host[256] = "linux";
#if defined(_WIN32)
          DWORD hl = sizeof(host); GetComputerNameA(host, &hl);
#else
          gethostname(host, sizeof(host)); host[sizeof(host) - 1] = 0;
#endif
          XbmCrash_Init(host, UiTextGet("monitor.url"));
      }
      UiCalendar_Init(dataDir + "/kalender");
      UiScrub_ClaimGesture = [] { UiDragHandledThisFrame() = true; };
      std::fputs(XbmPaths_Report().c_str(), stderr);
#if !defined(_WIN32)
      // ---- Eigene Kopfzeile (Linux) -----------------------------------
      // Das Fenster ist in BEIDEN Modi randlos: ob eine Fensterverwaltung
      // _MOTIF_WM_HINTS an einem bereits gemappten Fenster auswertet, ist
      // ihr ueberlassen, und Marco/MATE tut es haeufig nicht -- deshalb
      // erschien die Systemleiste nie. Diese Leiste zeichnen wir selbst.
      {
          UiTitleBarHooks hk;
          hk.minimize = [] { if (window) glfwIconifyWindow(window); };
          hk.close    = [] { if (window) glfwSetWindowShouldClose(window, GLFW_TRUE); };
          hk.moveBy   = [](int dx, int dy) {
              if (!window) return;
              int x = 0, y = 0;
              glfwGetWindowPos(window, &x, &y);
              glfwSetWindowPos(window, x + dx, y + dy);
          };
          hk.isFullscreen  = [] { return UiAppFullscreen(); };
          hk.setFullscreen = [](bool on) { UiAppFullscreen() = on; };
          UiTitleBar_SetHooks(hk);
          UiTitleBar_SetEnabled(true);
          UiTitleBar_ClaimGesture = [] { UiDragHandledThisFrame() = true; };
      }
#endif

      // Sprachmodell: neben der xbm.ini erwartet. Fehlt es, laeuft alles
      // weiter -- nur ohne Transkript (der Ton wird trotzdem gespeichert).
      XbmStt_SetModelPath(dataDir + "/ggml-base.bin");
      XbmStt_SetLanguage("de");

      // Gesten-Vorfahrt: ohne diesen Haken stiehlt der globale Drag-Scroll
      // das Ziehen von Kalendereintraegen.
      UiCalendar_ClaimGesture = [] { UiDragHandledThisFrame() = true; };
      // Kanten-Navigation im Kalender richtet sich nach derselben
      // globalen Einstellung wie ueberall sonst in der App.
      UiCalendar_ScrollPinpoint = [] { return UiScrollPinpoint(); };
      // Sofort-Abgleich nach eigenen Aenderungen -- "so schnell wie
      // moeglich bei anderen Geraeten sichtbar". Node() ist die einzige
      // XbmNetNode-Instanz (ui_networking.h); ist sie nicht gestartet,
      // ignoriert AbgleichJetzt() das einfach.
      UiCalendar_NetzAbgleichJetzt = [] { UiNetImpl::Node().AbgleichJetzt(); };
      // Pinch-Zoom braucht Mehrfingerpunkte; auf dem Desktop gibt es die
      // nicht -- dort zoomt Strg+Rad, und der Haken bleibt leer.
      UiCalendar_GetTouches = nullptr;

      UiCalendar_SetReminderHandler([](const CalEntry& e) {
          // Vorlaeufig: Konsolenhinweis. Hier gehoert spaeter eine
          // Einblendung im Fenster hin (oder eine Systembenachrichtigung).
          printf("[erinnerung] %s um %s\n", e.title.c_str(),
                 XbmTime_Format(e.start, "%d.%m. %H:%M").c_str());
      });
  }

  // ---------------------------------------------------------------------------
  // Vulkan overlay scenarios -- each runs on its own thread
  // ---------------------------------------------------------------------------
  int monW = 1920, monH = 1080; // sensible fallback
  {
      glfwInit();
      GLFWmonitor* mon = glfwGetPrimaryMonitor();
      if (mon) {
          const GLFWvidmode* vm = glfwGetVideoMode(mon);
          if (vm) { monW = vm->width; monH = vm->height; }
          int mc = 0; glfwGetMonitors(&mc);
          printf("[geo] Primaermonitor: %dx%d, Monitore gesamt: %d\n",
                 monW, monH, mc);
      }
  }

  // Vulkan-Overlay-Szenarien entfernt: Rain & Spin laufen jetzt als
  // GL-Effekte in ImGui-Fenstern innerhalb von gui() -- ohne schwarze
  // Hintergruende, verschiebbar, identisch auf allen Plattformen.

#ifdef _WIN32
  // --- Windows: manual Win32 + WGL window/context, desktop-overlay mode ---
  //
  // GLFW_TRANSPARENT_FRAMEBUFFER is broken on Windows as of GLFW 3.4
  // (glfw/glfw#2731, #1237). This manual path bypasses GLFW's window
  // creation entirely and handles transparency via Dear ImGui's own
  // verified ImGui_ImplWin32_EnableAlphaCompositing.
  //
  // Two things are required to avoid earlier problems in this project's
  // history, both now handled inside win32_window.cpp -- see the comments
  // there for the full reasoning:
  //   1. The window must NOT be exactly screenW x screenH at (0,0), or
  //      DWM's fullscreen-optimization heuristic silently disables alpha
  //      compositing (Create() grows the window 1px and shifts it -1px).
  //   2. SetWindowRgn (used for click-through shaping) must NOT be called
  //      every single frame regardless of whether anything changed --
  //      doing so was the actual cause of compositor flicker observed
  //      earlier, not the 1px-size workaround itself
  //      (UpdateClickThroughRegionHwnd now skips the call when the
  //      region is unchanged since the last frame).
  HWND hwnd = nullptr;
  HDC hdc = nullptr;
  HGLRC hglrc = nullptr;
  int winW = 0, winH = 0;
  if (!Win32Window::Create(hwnd, hdc, hglrc, winW, winH)) {
    fprintf(stderr, "Win32Window::Create FAILED\n");
    return -1;
  }
  fprintf(stderr, "Win32Window::Create OK, hwnd=%p, %dx%d\n", (void*)hwnd, winW, winH);

  ImGui::CreateContext();
  ImGuiIO& io = ImGui::GetIO();
  // EINE WAHRHEITSQUELLE: imgui.ini abgeschaltet -- Fensterzustaende
  // verwaltet ausschliesslich die xbm.ini-Zustandsmaschine (siehe
  // Kommentar in main_android.cpp).
  io.IniFilename = nullptr;
  io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
  ImGui_ImplWin32_InitForOpenGL((void*)hwnd);
  ImGui_ImplOpenGL3_Init("#version 130");

  // ---- Eigene Kopfzeile: Haken setzen -----------------------------------
  // Die Systemleiste bleibt aus (WS_POPUP im Vollbild, und im Fenstermodus
  // hat sie sich als unzuverlaessig treffbar erwiesen). Diese hier
  // funktioniert in beiden Modi und auf beiden Plattformen gleich.
  g_hwndForBar = hwnd;
  {
      UiTitleBarHooks hk;
      hk.minimize = [] { if (g_hwndForBar) ShowWindow(g_hwndForBar, SW_MINIMIZE); };
      hk.close    = [] { if (g_hwndForBar) PostMessageW(g_hwndForBar, WM_CLOSE, 0, 0); };
      // UPDATE-NEUSTART UEBER DASSELBE FENSTER BEENDEN. [Der Hook wurde
      //  weiter oben fuer GLFW gesetzt -- unter Windows laeuft die App aber
      //  ueber ein eigenes Win32-Fenster, ein GLFW-Fenster gibt es hier
      //  nicht. Der Hook tat also nichts: das Nachlauf-Script wartete auf
      //  ein Programmende, das nie kam, und das Update wurde nie
      //  angewendet -- beim Knopf wie beim Auto-Update. Jetzt derselbe Weg
      //  wie der Schliessen-Knopf, inklusive Sichern des Kalenders.]
      XbmUpdate_BeendenHook = [] { if (g_hwndForBar) PostMessageW(g_hwndForBar, WM_CLOSE, 0, 0); };
      hk.moveBy   = [](int dx, int dy) {
          if (!g_hwndForBar) return;
          RECT r{}; GetWindowRect(g_hwndForBar, &r);
          SetWindowPos(g_hwndForBar, nullptr, r.left + dx, r.top + dy, 0, 0,
                       SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
      };
      hk.isFullscreen  = [] { return UiAppFullscreen(); };
      hk.setFullscreen = [](bool on) { UiAppFullscreen() = on; };
      UiTitleBar_SetHooks(hk);
      UiTitleBar_SetEnabled(true);
      UiTitleBar_ClaimGesture = [] { UiDragHandledThisFrame() = true; };
  }

  while (Win32Window::PollEvents()) {
      {   // VOLLBILD <-> FENSTER -- Win32-Gegenstueck zum GLFW-Block.
          // [Der Schalter sass bisher nur im GLFW-Loop; der Windows-
          //  Build laeuft aber HIER -- deshalb "toggelt nichts".]
          static int prevFs = -1;
          int wantFs = UiAppFullscreen() ? 1 : 0;
          // Auch anwenden, wenn die Checkbox "Taskleiste beruecksichtigen"
          // umgelegt wurde, ohne dass sich der Vollbildzustand aendert.
          bool geoDirty = EffectsGl_Settings().taskbarDirty;
          if (geoDirty) { EffectsGl_Settings().taskbarDirty = false; }
          if (wantFs != prevFs || (geoDirty && wantFs)) {
              if (prevFs != -1) {
                  int sw = GetSystemMetrics(SM_CXSCREEN);
                  int sh = GetSystemMetrics(SM_CYSCREEN);
                  LONG_PTR st = GetWindowLongPtr(hwnd, GWL_STYLE);
                  // ---- ERWEITERTE STILE MITSCHALTEN ---------------------
                  // WS_EX_LAYERED und die DWM-Durchsichtigkeit sind
                  // Werkzeuge des DESKTOP-OVERLAYS. Im Fenster-Modus sind
                  // sie reine Last:
                  //  * Ein Schichtfenster wird von Windows gesondert
                  //    behandelt; zusammen mit WS_EX_TRANSPARENT, das aus
                  //    einem frueheren Overlay-Frame haengengeblieben sein
                  //    kann, ist die TITELLEISTE nicht mehr treffbar --
                  //    Klicks fallen hindurch und das X schliesst nichts.
                  //    (Genau das gemeldete Verhalten.)
                  //  * Gebraucht werden sie hier gar nicht: im Fenster-
                  //    Modus loeschen wir ohnehin deckend.
                  // Deshalb: Fenster-Modus = ganz gewoehnliches Fenster.
                  LONG ex = GetWindowLong(hwnd, GWL_EXSTYLE);
                  if (wantFs) {
                      st &= ~(WS_OVERLAPPEDWINDOW);
                      st |= WS_POPUP;
                      ex |= WS_EX_LAYERED;
                      ex &= ~WS_EX_TRANSPARENT;      // frisch anfangen
                      SetWindowLongPtr(hwnd, GWL_STYLE, st);
                      SetWindowLong(hwnd, GWL_EXSTYLE, ex);
                      SetLayeredWindowAttributes(hwnd, 0, 255, LWA_ALPHA);
                      ImGui_ImplWin32_EnableAlphaCompositing(hwnd);
                      SetWindowPos(hwnd, nullptr, 0, 0, sw, sh,
                                   SWP_NOZORDER | SWP_FRAMECHANGED
                                   | SWP_SHOWWINDOW);
                  } else {
                      st &= ~WS_POPUP;
                      st |= WS_OVERLAPPEDWINDOW;
                      ex &= ~(WS_EX_LAYERED | WS_EX_TRANSPARENT);
                      SetWindowLongPtr(hwnd, GWL_STYLE, st);
                      SetWindowLong(hwnd, GWL_EXSTYLE, ex);
                      // DWM-DURCHSICHTIGKEIT ABSCHALTEN.
                      // [Das fehlte und ist der Grund, warum das Fenster
                      //  im Fenstermodus WEITERHIN durchsichtig war:
                      //  DwmEnableBlurBehindWindow wirkt UNABHAENGIG von
                      //  WS_EX_LAYERED. Das Entfernen des Stils allein
                      //  nimmt die Durchsichtigkeit also nicht zurueck --
                      //  der Compositor rechnet den Alphakanal des
                      //  Framebuffers weiter mit. ImGui bietet nur eine
                      //  "Enable"-Hilfsfunktion, das Gegenstueck muss man
                      //  selbst rufen.]
                      {
                          DWM_BLURBEHIND bb = {};
                          bb.dwFlags = DWM_BB_ENABLE | DWM_BB_BLURREGION;
                          bb.fEnable = FALSE;
                          bb.hRgnBlur = nullptr;
                          DwmEnableBlurBehindWindow(hwnd, &bb);
                      }
                      SetWindowPos(hwnd, nullptr, sw / 8, sh / 8,
                                   (sw * 3) / 4, (sh * 3) / 4,
                                   SWP_NOZORDER | SWP_FRAMECHANGED
                                   | SWP_SHOWWINDOW);
                      // Rahmen und Inhalt neu zeichnen lassen, sonst zeigt
                      // Windows noch die alte, geschichtete Darstellung.
                      RedrawWindow(hwnd, nullptr, nullptr,
                                   RDW_FRAME | RDW_INVALIDATE | RDW_UPDATENOW);
                  }
                  // Merker der Durchklick-Verwaltung zuruecksetzen, sonst
                  // haelt sie den alten Zustand fuer aktuell und schreibt
                  // den erweiterten Stil nie mehr.
                  XbmWin_ResetPassthroughLatch();
              }
              prevFs = wantFs;
          }
      }
      ImGui_ImplOpenGL3_NewFrame();
      ImGui_ImplWin32_NewFrame();
      // ZEIGERPOSITION EINSPEISEN -- Gegenstueck zum Linux-Zweig.
      // Mit WS_EX_TRANSPARENT erhaelt das Fenster keine Mausnachrichten
      // mehr; ohne diese Einspeisung friere ImGuis Position ein und die
      // Entscheidung bliebe fuer immer auf "durchlaessig" stehen.
      {
          POINT cp;
          if (GetCursorPos(&cp) && ScreenToClient(hwnd, &cp)) {
              UiClickThru_FeedCursor((float)cp.x, (float)cp.y, true);
          }
          g_ptrButtonHeld = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0
                         || (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
      }
      ImGui::NewFrame();
      UiLayoutLockNewFrame();   // Layout-Sperre VOR jedem Begin
      // Ergebnisse aus Hintergrundfaeden (Transkription, Erinnerungen)
      // in den UI-Thread holen -- VOR gui(), damit sie noch in DIESEM
      // Frame sichtbar werden.
      XbmSched_DrainUi();

      if (UiTitleBar_Enabled()) {
          // Kopfzeile ZUERST -- sie liegt oben und der Rest bekommt
          // darunter Platz. Danach die Arbeitsflaeche des Hauptviewports
          // um ihre Hoehe verkleinern, sonst zeichnet der Seiten-Host
          // (der vp->WorkPos/WorkSize benutzt) genau darunter weiter und
          // verdeckt die Leiste. Dasselbe Verfahren nutzt der Android-
          // Zweig bereits fuer die Bildschirmtastatur.
          UiTitleBar_Draw("X Bookmark Manager");
          ImGuiViewport* mvp_tb = ImGui::GetMainViewport();
          const float tbh = UiTitleBar_Height();
          mvp_tb->WorkPos.y  += tbh;
          mvp_tb->WorkSize.y -= tbh;
      }
      gui(state, entry, cookie_path);
      UiClickThru_DrawDebugOverlay();  // nur wenn XBM_CTMAP=1
      UiWinDoctor_Frame();        // meldet Zustandswechsel (nur wenn an)
      RescueOffscreenWindows();   // nie ein Fenster ins Nichts verlieren
      CollectPanelRects();

      // Vollbild-Hintergrund sichtbar -> Region KOMPLETT entfernen:
      // SetWindowRgn(hwnd, NULL) ist die offizielle Win32-Semantik fuer
      // "gesamtes Fenster zeichnen und Eingaben empfangen" -- ohne jede
      // Koordinaten-/DPI-Interpretation. (Ein "Vollbild-Rechteck" als
      // Region blieb auf manchen Setups wirkungslos -> Shader war nur
      // unter den Fensterflaechen sichtbar.)
      // Sichtbarkeit dauerhaft vollflaechig (Region NULL). Click-through
      // an andere PROZESSE geht auf Win32 NUR ueber die Fensterstile
      // WS_EX_TRANSPARENT|WS_EX_LAYERED (HTTRANSPARENT wirkt nur innerhalb
      // desselben Threads -- deshalb "funktionierte" der Hittest-Ansatz
      // nicht). Der Stil wird dynamisch geschaltet: Cursor ueber einem
      // ImGui-Fenster -> interaktiv, sonst -> durchlaessig. Waehrend der
      // Durchlaessigkeit kommen keine Mausnachrichten mehr an, daher wird
      // der Cursor global gepollt (GetCursorPos). Exakt das Muster von
      // GLFWs MOUSE_PASSTHROUGH -- vertraeglich mit DWM-Alpha.
      {
          static bool regionCleared = false;
          if (!regionCleared) { SetWindowRgn(hwnd, NULL, TRUE); regionCleared = true; }

          EffectsSettings& fx = EffectsGl_Settings();
          bool pass = false;
          // IDENTISCH ZU LINUX -- ausdruecklich gefordert: dasselbe
          // Verhalten auf beiden Plattformen. Auch hier entscheidet
          // ImGuis Hover-Test, nicht mehr eine eigene Rechteckliste.
          // [Mit der Liste fiel u.a. die obere Navigationsleiste im
          //  Vollbild durch: sie stand dort nicht so, wie sie gezeichnet
          //  wurde. Der Hover-Test kann per Konstruktion nicht abweichen.]
          static int forceModeW = [] {
              const char* e = getenv("XBM_PASSTHRU");
              if (!e) return 0;
              if (!strcmp(e, "force")) return 1;
              if (!strcmp(e, "off"))   return 2;
              return 0;
          }();
          if (forceModeW == 1)      pass = true;
          else if (forceModeW == 2) pass = false;
          else if (fx.clickThrough && OverlayModeActive()) {
              pass = !UiClickThru_OverUi();
          }
          if (!g_ptrButtonHeld && (int)pass != g_win32PrevPass) {
              LONG ex = GetWindowLong(hwnd, GWL_EXSTYLE);
              if (pass) {
                  ex |= WS_EX_TRANSPARENT;   // LAYERED besteht seit Erzeugung
                  SetWindowLong(hwnd, GWL_EXSTYLE, ex);
              } else {
                  ex &= ~WS_EX_TRANSPARENT;   // LAYERED bleibt (kein Flackern)
                  SetWindowLong(hwnd, GWL_EXSTYLE, ex);
              }
              g_win32PrevPass = (int)pass;
          }
      }

      if (UiPagesFrameNurWarm()) { ImGui::EndFrame(); continue; }   // Warmlauf: nicht praesentieren
      ImGui::Render();
      {   // VIEWPORT AUS DER ECHTEN CLIENT-GROESSE -- JEDEN FRAME.
          // [Hier stand "glViewport(0, 0, winW, winH)" mit den bei der
          //  Fenstererzeugung ermittelten BILDSCHIRM-Massen. Im Fenster-
          //  Modus ist der Clientbereich aber kleiner (3/4 des Schirms):
          //  ImGui projiziert mit io.DisplaySize = Clientgroesse, der
          //  Viewport streckte das Ergebnis danach auf Bildschirmmass.
          //  Was man SIEHT lag dadurch woanders als das, was ImGui als
          //  Fensterrechteck fuehrt -- ein Klick auf ein sichtbares Panel
          //  traf in g_panelRects daneben, die Trefferpruefung meldete
          //  "freie Flaeche" und WS_EX_TRANSPARENT liess ihn zum Desktop
          //  durch. Das war der gemeldete Fenster-Modus-Passthrough.]
          RECT crc = {};
          GetClientRect(hwnd, &crc);
          int fbW = (int)(crc.right - crc.left);
          int fbH = (int)(crc.bottom - crc.top);
          if (fbW < 1) fbW = 1;
          if (fbH < 1) fbH = 1;
          winW = fbW; winH = fbH;
          glViewport(0, 0, fbW, fbH);
      }
      ClearFrameBackground();   // Vollbild: transparent, Fenster: deckend
      ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
      Win32Window::SwapBuffers(hdc);
      Win32Window::ShowAfterFirstFrame(hwnd);  // erst jetzt sichtbar -> kein Schwarz-Blitz
  }

  UiNetworking_Stop();   // Netz zuerst, geordnet -- nicht bei der statischen Zerstoerung
  ImGui_ImplOpenGL3_Shutdown();
  ImGui_ImplWin32_Shutdown();
  ImGui::DestroyContext();
  Win32Window::Destroy(hwnd, hdc, hglrc);

#else
  // --- Linux / macOS: fullscreen transparent overlay via GLFW ---
  //
  // This path was confirmed working on Linux throughout the Windows
  // debugging session -- GLFW_TRANSPARENT_FRAMEBUFFER works correctly
  // on X11 (unlike Windows where it's broken per glfw/glfw#2731).
  // ClickThroughOverlay uses XShapeCombineRectangles (X11) or the
  // Cocoa -hitTest: override (macOS) for per-panel click-through.
  glfwInit();
  printf("[env] GLFW: %s\n", glfwGetVersionString());
  printf("[env] XDG_SESSION_TYPE: %s\n",
         getenv("XDG_SESSION_TYPE") ? getenv("XDG_SESSION_TYPE") : "(unbekannt)");
#if defined(GLFW_MOUSE_PASSTHROUGH)
  printf("[env] GLFW_MOUSE_PASSTHROUGH: verfuegbar\n");
#else
  printf("[env] GLFW_MOUSE_PASSTHROUGH: NICHT verfuegbar (GLFW < 3.4)\n");
#endif
  glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, GLFW_TRUE);
  glfwWindowHint(GLFW_DECORATED, GLFW_FALSE);
  // Gesamten virtuellen Desktop bestimmen (Bounding-Box ALLER Monitore) --
  // nur der Primaermonitor liess die App auf Multi-Monitor-Setups einen
  // Teil des Bildschirms frei ("nicht mehr auf den ganzen Bildschirm").
  int vdX = 0, vdY = 0, vdW = 0, vdH = 0;
  {
      int mc = 0;
      GLFWmonitor** mons = glfwGetMonitors(&mc);
      int minX = 1 << 30, minY = 1 << 30, maxX = -(1 << 30), maxY = -(1 << 30);
      for (int i = 0; i < mc; ++i) {
          int mx = 0, my = 0;
          glfwGetMonitorPos(mons[i], &mx, &my);
          const GLFWvidmode* vm = glfwGetVideoMode(mons[i]);
          if (!vm) continue;
          if (mx < minX) minX = mx;
          if (my < minY) minY = my;
          if (mx + vm->width  > maxX) maxX = mx + vm->width;
          if (my + vm->height > maxY) maxY = my + vm->height;
      }
      if (maxX > minX && maxY > minY) {
          vdX = minX; vdY = minY; vdW = maxX - minX; vdH = maxY - minY;
      } else {
          const GLFWvidmode* vm = glfwGetVideoMode(glfwGetPrimaryMonitor());
          vdW = vm ? vm->width : 1920; vdH = vm ? vm->height : 1080;
      }
      printf("[geo] Virtueller Desktop: %dx%d @ (%d,%d), Monitore: %d\n",
             vdW, vdH, vdX, vdY, mc);
  }
  // Primaermonitor-Geometrie fuer den umschaltbaren Canvas-Bereich merken.
  // Grund: 12+ Megapixel transparentes ARGB ueber ALLE Monitore zwingt den
  // Compositor auf schwachen iGPUs (Intel JSL: 14 fps) in die Knie; der
  // Primaermonitor allein ist ~6x guenstiger. Umschaltung zur Laufzeit in
  // den Effekt-Einstellungen.
  int pmX = 0, pmY = 0, pmW = vdW, pmH = vdH;
  {
      GLFWmonitor* pm = glfwGetPrimaryMonitor();
      if (pm) {
          glfwGetMonitorPos(pm, &pmX, &pmY);
          const GLFWvidmode* vm = glfwGetVideoMode(pm);
          if (vm) { pmW = vm->width; pmH = vm->height; }
      }
  }
  // A/B-Test Fuellrate/Compositor: XBM_WINDOW=1280x720 startet klein.
  // Springt die FPS damit hoch, ist der Frame fuellraten-/compositor-
  // gebunden (grosses transparentes ARGB-Fenster), nicht CPU/GL-Logik.
  if (const char* wenv = getenv("XBM_WINDOW")) {
      int w = 0, h = 0;
      if (sscanf(wenv, "%dx%d", &w, &h) == 2 && w > 100 && h > 100) {
          vdW = w; vdH = h; vdX = 100; vdY = 100;
          printf("[env] XBM_WINDOW aktiv: %dx%d\n", vdW, vdH);
      }
  }
  window = glfwCreateWindow(pmW, pmH, "Overlay", nullptr, nullptr);
  if (!window) {
    const char* desc = nullptr;
    int code = glfwGetError(&desc);
    fprintf(stderr, "glfwCreateWindow FAILED. Error code: %d, desc: %s\n", code, desc ? desc : "(none)");
    glfwTerminate();
    return -1;
  }
  // Klebende Hints zuruecksetzen: sie gelten sonst auch fuer die von
  // ImGui-Multi-Viewports erzeugten Zweitfenster -- transparente
  // Secondary-Fenster mit geteiltem GLX-Kontext scheitern auf manchen
  // Treibern bei der Erzeugung (-> NULL-Handle -> glfwGetWindowAttrib-
  // Assertion). Hints wirken nur bei Erzeugung; unser Hauptfenster ist fertig.
  glfwDefaultWindowHints();
  glfwSetWindowPos(window, pmX, pmY);   // Start: Primaermonitor (canvasMode 0)
  glfwMakeContextCurrent(window);
  // VSync: OHNE Swap-Intervall laeuft die Schleife ungebremst, der GPU-
  // Befehlspuffer laeuft voll und der Treiber blockiert an zufaelliger
  // Stelle (typisch: erster GL-Aufruf des Folgeframes) -- exakt das
  // beobachtete Muster "startet fluessig, degradiert auf 10-14 fps",
  // waehrend gui/render/swap zusammen nur ~1 ms messen.
  glfwSwapInterval(1);
  // Entscheidende Diagnose: Hardware- oder Software-Rendering?
  // "llvmpipe"/"softpipe" hier == CPU-Rendering -> erklaert 14 fps sofort.
  printf("[env] GL_RENDERER: %s\n", (const char*)glGetString(GL_RENDERER));
  printf("[env] GL_VERSION:  %s\n", (const char*)glGetString(GL_VERSION));
  ClickThroughOverlay::InitPlatformWindow(window);

  ImGui::CreateContext();
  ImGui::GetIO().IniFilename = nullptr;  // eine Wahrheitsquelle (s. main_android)
  ImGuiIO& io = ImGui::GetIO();
  io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
  // Multi-Viewports: ImGui-Fenster, die das Haupt-Canvas verlassen, werden
  // eigene kleine OS-Fenster -> auf jeden Monitor ziehbar, waehrend das
  // Canvas klein/schnell bleibt (Primaermonitor). Loest das Dilemma
  // "alle Bildschirme erreichbar" vs. "12-MP-Compositor-Kosten".
  // WICHTIG: ViewportsEnable muss BEIM BACKEND-INIT gesetzt sein -- nur
  // dann installieren imgui_impl_glfw/opengl3 ihre Multi-Viewport-
  // Schnittstellen (Fenster-Erzeugung, Monitor-Liste, Render-Hooks).
  // Ein spaeter zur Laufzeit gesetztes Flag laeuft sonst ins Leere und
  // Fenster koennen nie ausloesen. Die Einstellungs-Checkbox (Default AUS)
  // schaltet danach nur noch die NUTZUNG pro Frame an/ab.
  io.ConfigFlags |= ImGuiConfigFlags_ViewportsEnable;
  ImGui_ImplGlfw_InitForOpenGL(window, true);
  ImGui_ImplOpenGL3_Init("#version 130");

  while (!glfwWindowShouldClose(window)) {
      glfwPollEvents();
      {   // ---- VOLLBILD <-> FENSTER -------------------------------------
          // STEHT BEWUSST VOR ImGui::NewFrame().
          // [Vorher lief dieser Block ZWISCHEN NewFrame() und Render().
          //  glfwHideWindow/glfwShowWindow pumpen auf X11 intern die
          //  Ereigniswarteschlange (waitForVisibilityNotify ruft XIfEvent) --
          //  GLFWs Callbacks, also die des ImGui-Backends, treten damit
          //  MITTEN im laufenden Frame wieder ein: Fokus-, Groessen- und
          //  Zeigerereignisse landen in einem Frame, der bereits begonnen
          //  hat, und Groessenaenderungen wirken auf einen Zustand, den
          //  NewFrame schon festgeschrieben hat. Ein Umbau des Fensters
          //  gehoert zwischen zwei Frames, nicht in einen hinein -- der
          //  Windows-Zweig macht es seit jeher so. Das ist die
          //  wahrscheinlichste Ursache des Absturzes beim zweiten
          //  Umschalten.]
          static int prevFs = -1;
          int wantFs = UiAppFullscreen() ? 1 : 0;
          // Auch anwenden, wenn die Checkbox "Taskleiste beruecksichtigen"
          // umgelegt wurde, ohne dass sich der Vollbildzustand aendert.
          bool geoDirty = EffectsGl_Settings().taskbarDirty;
          if (geoDirty) { EffectsGl_Settings().taskbarDirty = false; }
          if (wantFs != prevFs || (geoDirty && wantFs)) {
              if (prevFs != -1 || geoDirty) {  // nicht beim allerersten Frame
                  GLFWmonitor* pm = glfwGetPrimaryMonitor();
                  int mx = 0, my = 0, mw = 1280, mh = 720;
                  const bool respect = EffectsGl_Settings().respectTaskbar;
                  if (pm) {
                      if (respect) {
                          // ARBEITSBEREICH: alles ausser Taskleiste/Panels.
                          // Genau dafuer gibt es glfwGetMonitorWorkarea --
                          // es fragt _NET_WORKAREA ab, also das, was die
                          // Fensterverwaltung als frei meldet.
                          glfwGetMonitorWorkarea(pm, &mx, &my, &mw, &mh);
                      } else {
                          glfwGetMonitorPos(pm, &mx, &my);
                          if (const GLFWvidmode* vm = glfwGetVideoMode(pm)) {
                              mw = vm->width; mh = vm->height;
                          }
                      }
                  }
                  // OBEN HALTEN nur, wenn die Taskleiste NICHT beruecksichtigt
                  // wird -- sonst laege die App auch ueber ihr, und genau das
                  // will die Einstellung ja vermeiden.
                  glfwSetWindowAttrib(window, GLFW_FLOATING,
                                      (wantFs && !respect) ? GLFW_TRUE : GLFW_FALSE);
                  // HIDE -> umbauen -> SHOW: Der Dekorations-Wechsel wird
                  // von manchen Fensterverwaltungen (u.a. Marco/MATE) erst
                  // beim NEU-MAPPEN ausgewertet.
                  glfwHideWindow(window);
                  if (wantFs) {
                      glfwSetWindowAttrib(window, GLFW_DECORATED, GLFW_FALSE);
                      glfwSetWindowPos(window, mx, my);
                      glfwSetWindowSize(window, mw, mh);
                  } else {
                      // KEINE Systemdekoration anfordern: die eigene
                      // Kopfzeile (ui_titlebar) uebernimmt das. Ob eine
                      // Fensterverwaltung _MOTIF_WM_HINTS an einem schon
                      // gemappten Fenster auswertet, ist ihr ueberlassen --
                      // genau deshalb blieb die Leiste unter Marco aus.
                      glfwSetWindowAttrib(window, GLFW_DECORATED, GLFW_FALSE);
                      glfwSetWindowSize(window, (mw * 3) / 4, (mh * 3) / 4);
                      glfwSetWindowPos(window, mx + mw / 8, my + mh / 8);
                  }
                  glfwShowWindow(window);
                  // Durchklick-Merker zuruecksetzen: nach dem Umbau ist der
                  // gespeicherte Zustand nicht mehr verlaesslich.
                  g_linuxPrevPass = -1;
                  printf("[fenster] %s: %dx%d\n",
                         wantFs ? "Vollbild" : "Fenster",
                         wantFs ? mw : (mw * 3) / 4,
                         wantFs ? mh : (mh * 3) / 4);
              }
              prevFs = wantFs;
          }
      }
      {   // ---- MULTI-VIEWPORTS: NUTZUNG pro Frame schalten ------------
          // Die Backends sind mit ViewportsEnable initialisiert (das MUSS
          // beim Init geschehen, s.o.), die Checkbox regelt die Nutzung.
          // [Genau dieses Umschalten fehlte: das Flag stand dauerhaft AN,
          //  obwohl die Einstellung "Multi-Viewport-Fenster" per Default
          //  AUS ist. Zusammen mit den fehlenden UpdatePlatformWindows()/
          //  RenderPlatformWindowsDefault() weiter unten war das die
          //  Ursache fuer "Prototype verschwindet beim Abdocken": Beim
          //  Herausziehen aus dem Dock legt ImGui fuer das nun frei
          //  schwebende Fenster einen EIGENEN Viewport an (imgui.cpp,
          //  UpdateSelectWindowViewport: Zweig "g.MovingWindow ..." bzw.
          //  fehlgeschlagenes UpdateTryMergeWindowIntoHostViewport, sobald
          //  das Fenster nicht mehr vollstaendig in den Hauptviewport
          //  passt). Sekundaere Viewports werden AUSSCHLIESSLICH von
          //  RenderPlatformWindowsDefault() gezeichnet -- ohne diesen
          //  Aufruf entsteht gar kein OS-Fenster und der Inhalt landet in
          //  keinem Framebuffer: das Fenster ist restlos weg, nicht nur
          //  unsichtbar.]
          ImGuiIO& vio = ImGui::GetIO();
          if (EffectsGl_Settings().multiViewports)
              vio.ConfigFlags |=  ImGuiConfigFlags_ViewportsEnable;
          else
              vio.ConfigFlags &= ~ImGuiConfigFlags_ViewportsEnable;
      }
      ImGui_ImplOpenGL3_NewFrame();
      ImGui_ImplGlfw_NewFrame();
      // ZEIGERPOSITION EINSPEISEN. Sobald das Fenster durchlaessig ist,
      // liefert das System keine Mausereignisse mehr und ImGuis Position
      // friert ein -- HoveredWindow bliebe fuer immer leer und die
      // Entscheidung haenge fest. XQueryPointer funktioniert dagegen auch
      // durch eine leere Eingaberegion hindurch.
      {
          Display* dpy = glfwGetX11Display();
          if (dpy) {
              ::Window rr, cr; int rx, ry, wx, wy; unsigned int mask;
              if (XQueryPointer(dpy, glfwGetX11Window(window), &rr, &cr,
                                &rx, &ry, &wx, &wy, &mask)) {
                  UiClickThru_FeedCursor((float)wx, (float)wy, true);
                  g_ptrButtonHeld = (mask & (Button1Mask | Button2Mask
                                             | Button3Mask)) != 0;
              }
      ImGui::NewFrame();
      UiLayoutLockNewFrame();   // Layout-Sperre VOR jedem Begin
      XbmSched_DrainUi();       // s. Windows-Zweig
          }
      }

      if (UiTitleBar_Enabled()) {
          // Kopfzeile ZUERST -- sie liegt oben und der Rest bekommt
          // darunter Platz. Danach die Arbeitsflaeche des Hauptviewports
          // um ihre Hoehe verkleinern, sonst zeichnet der Seiten-Host
          // (der vp->WorkPos/WorkSize benutzt) genau darunter weiter und
          // verdeckt die Leiste. Dasselbe Verfahren nutzt der Android-
          // Zweig bereits fuer die Bildschirmtastatur.
          UiTitleBar_Draw("X Bookmark Manager");
          ImGuiViewport* mvp_tb = ImGui::GetMainViewport();
          const float tbh = UiTitleBar_Height();
          mvp_tb->WorkPos.y  += tbh;
          mvp_tb->WorkSize.y -= tbh;
      }
      double tGui0 = glfwGetTime();
      gui(state, entry, cookie_path);
      UiProf().gui = (float)((glfwGetTime() - tGui0) * 1000.0);
      UiClickThru_DrawDebugOverlay();  // nur wenn XBM_CTMAP=1
      UiWinDoctor_Frame();        // meldet Zustandswechsel (nur wenn an)
      RescueOffscreenWindows();   // nie ein Fenster ins Nichts verlieren
      CollectPanelRects();

      // Canvas-Bereich zur Laufzeit umschalten (Primaer <-> alle Monitore)
      {
          static int prevCanvas = 0;
          int cm = EffectsGl_Settings().canvasMode;
          if (cm != prevCanvas) {
              if (cm == 1) { glfwSetWindowPos(window, vdX, vdY);
                             glfwSetWindowSize(window, vdW, vdH); }
              else         { glfwSetWindowPos(window, pmX, pmY);
                             glfwSetWindowSize(window, pmW, pmH); }
              prevCanvas = cm;
          }
      }

      // Dynamisches Click-through via GLFW_MOUSE_PASSTHROUGH (GLFW 3.4+):
      // offizielles, auf X11 UND Wayland korrekt implementiertes Attribut --
      // X11-Input-Shapes greifen unter Wayland/XWayland nicht zuverlaessig.
      // Cursor-Abfrage gedrosselt (alle ~100 ms) und ohne printf-Flut:
      // beides zusammen verursachte zuvor den massiven FPS-Einbruch.
      {
#if defined(GLFW_MOUSE_PASSTHROUGH)
          EffectsSettings& fx = EffectsGl_Settings();
          {
              // JEDEN FRAME entscheiden -- nicht alle 100 ms.
              // [Das alte 100-ms-Raster war die Ursache gleich zweier
              //  Fehlbilder: (1) Zeiger auf ein Fenster bewegen und zuegig
              //  klicken -> Attribut stand noch auf "durchlassen", der
              //  Klick fiel DURCH das eigene Fenster (daher das ueberall
              //  "tote" X). (2) Klick auf freier Flaeche -> Attribut
              //  stand noch auf "fangen", das Terminal dahinter bekam
              //  nie etwas. glfwSetWindowAttrib wird ohnehin nur bei
              //  ECHTEM Wechsel gerufen, die Abfrage selbst ist billig.]
              bool pass = false;
              // Zustand der Maustaste stammt aus der Systemabfrage weiter
              // oben -- glfwGetMouseButton schweigt, wenn das Fenster
              // durchlaessig ist.
              const bool buttonHeld = g_ptrButtonHeld;
              static int forceMode = [] {
                  const char* e = getenv("XBM_PASSTHRU");
                  if (!e) return 0;
                  if (!strcmp(e, "force")) { printf("[durchklick] ERZWUNGEN an\n"); return 1; }
                  if (!strcmp(e, "off"))   { printf("[durchklick] ERZWUNGEN aus\n"); return 2; }
                  return 0;
              }();
              if (forceMode == 1)      pass = true;
              else if (forceMode == 2) pass = false;
              else if (fx.clickThrough && OverlayModeActive()) {
                  // EINE Wahrheit: ImGuis eigener Hover-Test. Die frueher
                  // hier gefuehrte Rechteckliste war eine zweite, von Hand
                  // gepflegte -- und wich wiederholt von dem ab, was
                  // gezeichnet wurde. Siehe ui_clickthru.h.
                  pass = !UiClickThru_OverUi();
              }
              if (!buttonHeld && (int)pass != g_linuxPrevPass) {
                  glfwSetWindowAttrib(window, GLFW_MOUSE_PASSTHROUGH,
                                      pass ? GLFW_TRUE : GLFW_FALSE);
                  g_linuxPrevPass = (int)pass;
                  // SOFORT flushen. GLFWs X11-Implementierung von
                  // GLFW_MOUSE_PASSTHROUGH setzt die Input-Shape via
                  // XShapeCombineRegion/XShapeCombineMask und flusht die
                  // Xlib-Ausgabewarteschlange NICHT. Ohne das hier sieht
                  // der Server die neue Shape erst beim naechsten
                  // glfwPollEvents -- ein ganzer Frame Verzug, in dem ein
                  // zuegiger Klick noch im alten Zustand landet.
                  if (Display* fdpy = glfwGetX11Display()) XFlush(fdpy);
              }
          }
#else
          // GLFW < 3.4: Fallback auf statische Shape (Checkbox-gesteuert)
          ClickThroughOverlay::UpdateClickThroughRegion(window, g_panelRects);
#endif
      }

      if (UiPagesFrameNurWarm()) { ImGui::EndFrame(); continue; }   // Warmlauf: nicht praesentieren
      ImGui::Render();
      ClearFrameBackground();   // Vollbild: transparent, Fenster: deckend
      ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
      // ---- SEKUNDAERE VIEWPORTS ZEICHNEN --------------------------------
      // Pflichtpaar, sobald ImGuiConfigFlags_ViewportsEnable aktiv ist.
      // Fehlte komplett -> jedes Fenster, das seinen eigenen Viewport
      // bekam (typisch: beim Abdocken herausgezogen), wurde nie erzeugt
      // und nie gezeichnet und war damit spurlos verschwunden.
      // Der Kontext-Backup ist Vorschrift: RenderPlatformWindowsDefault()
      // macht die Kontexte der Zweitfenster current und gibt den unseren
      // nicht von selbst zurueck.
      if (ImGui::GetIO().ConfigFlags & ImGuiConfigFlags_ViewportsEnable) {
          GLFWwindow* backupCtx = glfwGetCurrentContext();
          ImGui::UpdatePlatformWindows();
          ImGui::RenderPlatformWindowsDefault();
          glfwMakeContextCurrent(backupCtx);
      }
      glfwSwapBuffers(window);
  }

  UiNetworking_Stop();   // Netz zuerst, geordnet -- nicht bei der statischen Zerstoerung
  ImGui_ImplOpenGL3_Shutdown();
  ImGui_ImplGlfw_Shutdown();
  ImGui::DestroyContext();
  glfwDestroyWindow(window);
  // glfwTerminate() called at end of main() after scenario threads stop
#endif
  // HelloImGui::RunnerParams runner_params;
  // runner_params.appWindowParams.windowTitle = "X Bookmark Manager";
  // // runner_params.appWindowParams.windowGeometry.size = {940, 740};
  // runner_params.appWindowParams.windowGeometry.fullScreenMode = HelloImGui::FullScreenMode::FullMonitorWorkArea;
  // runner_params.imGuiWindowParams.defaultImGuiWindowType = HelloImGui::DefaultImGuiWindowType::NoDefaultWindow;
  // // runner_params.appWindowParams.alphaBlend = true;
  // // ImGuiViewport* viewport = ImGui::GetMainViewport();
  // // runner_params.appWindowParams.windowGeometry.size = {int(viewport->WorkSize[0]), int(viewport->WorkSize[1])};
  // // runner_params.appWindowParams.windowGeometry.size = {
  // //   static_cast<int>(viewport->WorkSize.x),
  // //   static_cast<int>(viewport->WorkSize.y)
  // // };
  // // runner_params.appWindowParams.windowGeometry.pos = {
  // //   static_cast<int>(viewport->WorkPos.x),
  // //   static_cast<int>(viewport->WorkPos.y)
  // // };
  // // Performance: this is a static tool, nothing animates, so there's
  // // no need to redraw at hundreds of fps.
  // runner_params.fpsIdling.enableIdling = true;
  // runner_params.fpsIdling.timeActiveAfterLastEvent = 1.0f;
  // // HelloImGui::Run(runner_params);
  // // HelloImGui::RunnerParams runner_params;
  // runner_params.imGuiWindowParams.defaultImGuiWindowType = HelloImGui::DefaultImGuiWindowType::NoDefaultWindow;
  // runner_params.callbacks.PostInit = [&]() {
  //     g_glfwWindow = static_cast<GLFWwindow*>(HelloImGui::GetRunnerParams()->backendPointers.glfwWindow);
  //     // NOTE: SetupWindowHintsForTransparency() must run BEFORE window creation —
  //     // HelloImGui doesn't expose a pre-creation hint hook directly, so the
  //     // practical route is to fork/patch hello_imgui's GLFW backend init to call
  //     // glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, GLFW_TRUE) before glfwCreateWindow,
  //     // OR build your own minimal GLFW+ImGui loop instead of HelloImGui::Run()
  //     // if you need this hint guaranteed to land before window creation.
  //     ClickThroughOverlay::InitPlatformWindow(g_glfwWindow);
  // };
  // runner_params.callbacks.ShowGui = [&state, &entry, &cookie_path] { gui(state, entry, cookie_path); };
  // // runner_params.callbacks.ShowGui = [&]() {
  // //     g_panelRects.clear();
  // //     ImGui::Begin("Panel A");
  // //     g_panelRects.push_back(ImRect(ImGui::GetWindowPos(),
  // //                                    ImGui::GetWindowPos() + ImGui::GetWindowSize()));
  // //     ImGui::Text("Content A");
  // //     ImGui::End();
  // //     ImGui::Begin("Panel B");
  // //     g_panelRects.push_back(ImRect(ImGui::GetWindowPos(),
  // //                                    ImGui::GetWindowPos() + ImGui::GetWindowSize()));
  // //     ImGui::Text("Content B");
  // //     ImGui::End();
  // // };
  // // runner_params.callbacks.AfterEndFrame = [&]() {
  // //     ClickThroughOverlay::UpdateClickThroughRegion(g_glfwWindow, g_panelRects);
  // // };
  // HelloImGui::Run(runner_params);

  // Stop all Vulkan scenario threads cleanly before exiting.
  // ScenarioRain/Spin/Drag destructors call Stop() if not already called,
  // but being explicit here makes the shutdown sequence clear.
  UiCalendar_Shutdown();   // ungespeicherte Aenderungen sichern
  XbmNet_Shutdown();
  XbmStt_Shutdown();
  XbmAudio_Shutdown();
  XbmSched_Shutdown();
  EffectsGl_Shutdown();
  glfwTerminate();
}
