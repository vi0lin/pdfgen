#pragma once
// ---------------------------------------------------------------------------
// ui_log.h -- Protokoll mit kurzen Einblendungen und einem andockbaren
//             Fenster.
//
// HEADER-ONLY, mit Absicht. [Ein eigenes .cpp muesste in die Quellenliste
//  der CMakeLists eingetragen werden, und genau das ist bei ui_condbuttons
//  schiefgegangen: Linux und Windows brachen beim Linken ab, Android
//  linkte klaglos und stuerzte beim Start. Einbinden genuegt hier.]
//
// DREI TEILE
//   1. Ringpuffer  -- die letzten Meldungen, mit Zeit und Stufe.
//   2. Einblendung -- Warnungen und Fehler erscheinen kurz oben rechts und
//                     verschwinden von selbst wieder.
//   3. Fenster     -- vollstaendige Liste, filterbar, kopierbar. Es ist ein
//                     gewoehnliches ImGui-Fenster und laesst sich deshalb
//                     auf jeder Seite andocken.
//
// ANSCHLUSS AN DAS BESTEHENDE PROTOKOLL
// Utils.h ruft ueber einen Haken UipLogSink jede UIP_LOGF-Zeile hier
// herein. Damit landet alles, was bisher nur auf der Konsole stand, auch
// im Fenster -- ohne dass eine einzige Aufrufstelle geaendert werden muss.
// ---------------------------------------------------------------------------
#include "imgui.h"
#include "imgui_internal.h"   // ImMax
#include "Utils.h"            // Haken UipLogSink -- ohne dieses Include
                              // haengt es davon ab, wer zuerst eingebunden
                              // wird, und UiLog_Install() findet den Haken
                              // je nach Datei mal und mal nicht.

#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <deque>
#include <string>

enum class UiLogLevel { Info, Warn, Error };

namespace xbm_uilog_detail {

struct Entry {
    UiLogLevel  level = UiLogLevel::Info;
    double      t     = 0.0;      // ImGui::GetTime() beim Eintreffen
    std::string text;
    int         wiederholt = 1;   // gleiche Meldung direkt hintereinander
};

struct State {
    std::deque<Entry> entries;
    std::size_t maxEntries = 2000;
    // Wie lange eine Einblendung stehen bleibt.
    float toastSeconds = 6.0f;
    bool  showInfoToasts = false;   // Info blendet NICHT ein, nur Warn/Fehler
    bool  windowOpen = false;
    bool  windowVisible = false;    // im zuletzt gezeichneten Frame sichtbar
    bool  autoScroll = true;
    char  filter[64] = {0};
    bool  showInfo = true, showWarn = true, showError = true;
    int   unseenWarn = 0, unseenError = 0;
};
inline State& S() { static State s; return s; }

// Stufe aus dem Text erraten. [Die bestehenden Aufrufe uebergeben keine
//  Stufe -- sie umzustellen hiesse, Dutzende Stellen anzufassen. Die
//  Schluesselwoerter reichen fuer den Zweck: es geht darum, WELCHE Zeile
//  eingeblendet wird, nicht um eine Klassifizierung auf Punkt und Komma.]
inline UiLogLevel Raten(const char* t) {
    if (!t) return UiLogLevel::Info;
    std::string l(t);
    for (char& c : l) if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
    if (l.find("fehler")   != std::string::npos ||
        l.find("error")    != std::string::npos ||
        l.find("fehlgeschlagen") != std::string::npos ||
        l.find("failed")   != std::string::npos ||
        l.find("abbruch")  != std::string::npos ||
        l.find("nicht lesbar") != std::string::npos ||
        l.find("cannot")   != std::string::npos)   return UiLogLevel::Error;
    if (l.find("warnung")  != std::string::npos ||
        l.find("warning")  != std::string::npos ||
        l.find("kein modell") != std::string::npos ||
        l.find("nicht gefunden") != std::string::npos)
        return UiLogLevel::Warn;
    return UiLogLevel::Info;
}

inline ImU32 Farbe(UiLogLevel l) {
    switch (l) {
        case UiLogLevel::Error: return IM_COL32(235,  90,  80, 255);
        case UiLogLevel::Warn:  return IM_COL32(240, 190,  70, 255);
        default:                return IM_COL32(190, 195, 205, 255);
    }
}
inline const char* Marke(UiLogLevel l) {
    switch (l) {
        case UiLogLevel::Error: return "FEHLER";
        case UiLogLevel::Warn:  return "Warnung";
        default:                return "Info";
    }
}

}  // namespace xbm_uilog_detail

// --- Eintragen --------------------------------------------------------------
inline void UiLog_Add(UiLogLevel level, const std::string& text) {
    using namespace xbm_uilog_detail;
    if (text.empty()) return;
    State& s = S();
    // Dieselbe Meldung direkt hintereinander nur zaehlen, nicht haeufen.
    // [Ohne das ueberschwemmt eine Zeile aus der Zeichenschleife das
    //  Protokoll mit sechzig Eintraegen je Sekunde.]
    if (!s.entries.empty() && s.entries.back().text == text
        && s.entries.back().level == level) {
        s.entries.back().wiederholt++;
        s.entries.back().t = ImGui::GetCurrentContext() ? ImGui::GetTime() : 0.0;
        return;
    }
    Entry e;
    e.level = level;
    e.t     = ImGui::GetCurrentContext() ? ImGui::GetTime() : 0.0;
    e.text  = text;
    s.entries.push_back(std::move(e));
    while (s.entries.size() > s.maxEntries) s.entries.pop_front();
    if (level == UiLogLevel::Warn)  ++s.unseenWarn;
    if (level == UiLogLevel::Error) ++s.unseenError;
}

inline void UiLog_Add(const std::string& text) {
    UiLog_Add(xbm_uilog_detail::Raten(text.c_str()), text);
}

inline void UiLog_Printf(UiLogLevel level, const char* fmt, ...) {
    char buf[1024];
    va_list ap; va_start(ap, fmt);
#if defined(__GNUC__) || defined(__clang__)
    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wformat-nonliteral"
#endif
    const int n = std::vsnprintf(buf, sizeof(buf), fmt, ap);
#if defined(__GNUC__) || defined(__clang__)
    #pragma GCC diagnostic pop
#endif
    va_end(ap);
    if (n < 0) return;
    UiLog_Add(level, std::string(buf,
        (std::size_t)(n < (int)sizeof(buf) ? n : (int)sizeof(buf) - 1)));
}

inline void UiLog_Clear() {
    xbm_uilog_detail::S().entries.clear();
    xbm_uilog_detail::S().unseenWarn = xbm_uilog_detail::S().unseenError = 0;
}
inline std::size_t UiLog_Count() { return xbm_uilog_detail::S().entries.size(); }
inline int  UiLog_UnseenWarn()   { return xbm_uilog_detail::S().unseenWarn; }
inline int  UiLog_UnseenError()  { return xbm_uilog_detail::S().unseenError; }
inline bool& UiLog_WindowOpen()  { return xbm_uilog_detail::S().windowOpen; }
// War das Fenster im ZULETZT gezeichneten Frame zu sehen? Damit kann ein
// Knopf sich genau dann zeigen, wenn das Fenster gerade NICHT da ist.
inline bool UiLog_WindowVisible(){ return xbm_uilog_detail::S().windowVisible; }
inline float& UiLog_ToastSeconds(){ return xbm_uilog_detail::S().toastSeconds; }

// --- Einblendungen ----------------------------------------------------------
// Nach dem uebrigen Zeichnen aufrufen. Zeigt die juengsten Warnungen und
// Fehler oben rechts und blendet sie nach UiLog_ToastSeconds() aus.
inline void UiLog_DrawToasts() {
    using namespace xbm_uilog_detail;
    State& s = S();
    if (s.entries.empty()) return;
    ImGuiViewport* vp = ImGui::GetMainViewport();
    const double now = ImGui::GetTime();
    const float pad = 10.0f;
    float y = vp->WorkPos.y + pad;
    int gezeigt = 0;

    // Von hinten nach vorn: die neuesten zuerst, hoechstens vier.
    for (auto it = s.entries.rbegin(); it != s.entries.rend() && gezeigt < 4; ++it) {
        if (it->level == UiLogLevel::Info && !s.showInfoToasts) continue;
        const double alter = now - it->t;
        if (alter > (double)s.toastSeconds) break;   // aeltere erst recht

        // Letzte Sekunde ausblenden.
        float a = 1.0f;
        const double rest = (double)s.toastSeconds - alter;
        if (rest < 1.0) a = (float)rest;
        if (a < 0.0f) a = 0.0f;

        char txt[512];
        if (it->wiederholt > 1)
            std::snprintf(txt, sizeof(txt), "%s  (%dx)", it->text.c_str(),
                          it->wiederholt);
        else
            std::snprintf(txt, sizeof(txt), "%s", it->text.c_str());

        const float maxW = vp->WorkSize.x * 0.45f < 520.0f
                         ? vp->WorkSize.x * 0.45f : 520.0f;
        const ImVec2 ts = ImGui::CalcTextSize(txt, nullptr, false, maxW);
        const float w = ts.x + 20.0f, h = ts.y + 14.0f;
        const ImVec2 p0(vp->WorkPos.x + vp->WorkSize.x - w - pad, y);
        const ImVec2 p1(p0.x + w, p0.y + h);

        // Auf die VORDERGRUND-Zeichenliste, damit die Meldung ueber allem
        // liegt und keine Eingaben abfaengt. [Ein eigenes Fenster wuerde
        //  Klicks schlucken und sich in die Andock-Logik einmischen.]
        ImDrawList* dl = ImGui::GetForegroundDrawList();
        dl->AddRectFilled(p0, p1, IM_COL32(24, 26, 32, (int)(235 * a)), 5.0f);
        dl->AddRect(p0, p1,
                    (Farbe(it->level) & 0x00FFFFFF) | ((ImU32)(220 * a) << 24),
                    5.0f, 0, 2.0f);
        dl->AddText(nullptr, 0.0f, ImVec2(p0.x + 10.0f, p0.y + 7.0f),
                    (Farbe(it->level) & 0x00FFFFFF) | ((ImU32)(255 * a) << 24),
                    txt, nullptr, maxW);
        y += h + 6.0f;
        ++gezeigt;
    }
}

// --- Fenster ----------------------------------------------------------------
// Gewoehnliches ImGui-Fenster: laesst sich andocken wie jedes andere.
// extraFlags: die Flags des Seitensystems (UiWinFlags). [Ohne sie laeuft
// das Fenster am Seitensystem vorbei: es liesse sich zwar an die
// Navigationen heften, aber nicht in das DockSpace-Layout der Seite
// einfuegen, weil dort andere Regeln fuer Groesse und Andocken gelten.
// ui_log.h bindet ui_pages.h bewusst NICHT ein -- die Flags kommen von
// aussen herein, damit die Abhaengigkeit nur in eine Richtung zeigt.]
inline void UiLog_DrawWindow(const char* title = "Protokoll",
                             bool* open = nullptr,
                             ImGuiWindowFlags extraFlags = 0) {
    using namespace xbm_uilog_detail;
    State& s = S();
    bool* p_open = open ? open : &s.windowOpen;
    if (!*p_open) { s.windowVisible = false; return; }

    ImGui::SetNextWindowSize(ImVec2(720, 320), ImGuiCond_FirstUseEver);
    const bool sichtbar = ImGui::Begin(title, p_open, extraFlags);
    s.windowVisible = sichtbar;
    if (!sichtbar) { ImGui::End(); return; }

    // Gesehen: die Zaehler fuer den Knopf zuruecksetzen.
    s.unseenWarn = s.unseenError = 0;

    if (ImGui::Button("Leeren")) UiLog_Clear();
    ImGui::SameLine();
    if (ImGui::Button("Kopieren")) {
        std::string alles;
        for (const auto& e : s.entries) {
            alles += Marke(e.level); alles += "  "; alles += e.text;
            if (e.wiederholt > 1) alles += "  (" + std::to_string(e.wiederholt) + "x)";
            alles += "\n";
        }
        ImGui::SetClipboardText(alles.c_str());
    }
    ImGui::SameLine(); ImGui::Checkbox("Info",    &s.showInfo);
    ImGui::SameLine(); ImGui::Checkbox("Warn",    &s.showWarn);
    ImGui::SameLine(); ImGui::Checkbox("Fehler",  &s.showError);
    ImGui::SameLine(); ImGui::Checkbox("Mitlaufen", &s.autoScroll);
    ImGui::SameLine();
    ImGui::SetNextItemWidth(160.0f);
    ImGui::InputTextWithHint("##filter", "suchen...", s.filter, sizeof(s.filter));
    ImGui::Separator();

    ImGui::BeginChild("##liste", ImVec2(0, 0), false,
                      ImGuiWindowFlags_HorizontalScrollbar);
    for (const auto& e : s.entries) {
        if (e.level == UiLogLevel::Info  && !s.showInfo)  continue;
        if (e.level == UiLogLevel::Warn  && !s.showWarn)  continue;
        if (e.level == UiLogLevel::Error && !s.showError) continue;
        if (s.filter[0] && e.text.find(s.filter) == std::string::npos) continue;
        ImGui::PushStyleColor(ImGuiCol_Text, Farbe(e.level));
        if (e.wiederholt > 1)
            ImGui::Text("%-7s  %s   (%dx)", Marke(e.level), e.text.c_str(),
                        e.wiederholt);
        else
            ImGui::Text("%-7s  %s", Marke(e.level), e.text.c_str());
        ImGui::PopStyleColor();
    }
    if (s.autoScroll && ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 1.0f)
        ImGui::SetScrollHereY(1.0f);
    ImGui::EndChild();
    ImGui::End();
}

// --- Symbol fuer den Knopf in der rechten Leiste -----------------------------
inline void UiLogIcon(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col) {
    const float w = b.x - a.x, h = b.y - a.y;
    // Blatt mit Zeilen
    const ImVec2 p0(a.x + w * 0.26f, a.y + h * 0.18f);
    const ImVec2 p1(b.x - w * 0.26f, b.y - h * 0.18f);
    dl->AddRect(p0, p1, col, 2.0f, 0, ImMax(1.5f, w * 0.06f));
    for (int i = 0; i < 3; ++i) {
        const float y = p0.y + (p1.y - p0.y) * (0.28f + 0.22f * i);
        dl->AddLine(ImVec2(p0.x + w * 0.10f, y),
                    ImVec2(p1.x - w * 0.10f - (i == 2 ? w * 0.12f : 0.0f), y),
                    col, ImMax(1.0f, w * 0.05f));
    }
}

// --- Anschluss an UIP_LOGF ---------------------------------------------------
// EINMAL beim Start aufrufen (nach dem ImGui-Kontext). Danach landet jede
// UIP_LOGF-Zeile zusaetzlich im Protokollfenster.
inline void UiLog_Install() {
    xbm_log_detail::UipLogSink = [](const char* t, int n) {
        if (!t || n <= 0) return;
        UiLog_Add(std::string(t, (std::size_t)n));
    };
}
