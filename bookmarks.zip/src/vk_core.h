#pragma once
// vk_core.h -- P0 der Vulkan-Migration: Instance, Physical-Device-Auswahl,
// logisches Device + Graphics-Queue. Headless-tauglich (keine Surface
// noetig) -- P1 setzt Swapchain/ImGui-Backend obendrauf.
// Wird NUR bei -DRENDERER=VULKAN kompiliert.
#include <string>

struct VkCoreInfo {
    std::string gpuName;
    unsigned    apiVersion = 0;
    bool        ok = false;
};

// Initialisiert Instance+Device (einmalig), liefert GPU-Infos.
// validation=true aktiviert VK_LAYER_KHRONOS_validation falls vorhanden.
VkCoreInfo VkCore_Init(bool validation);
void       VkCore_Shutdown();
// P0-Verifikation: loggt GPU-Name/API-Version (stdout bzw. logcat).
void       VkCore_SelftestLog();
