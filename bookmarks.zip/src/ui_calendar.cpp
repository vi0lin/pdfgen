// ---------------------------------------------------------------------------
// ui_calendar.cpp -- siehe ui_calendar.h.
// ---------------------------------------------------------------------------
#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif
#include "ui_calendar.h"
#include "xbm_alarm.h"
#include "xbm_paths.h"
#include <ctime>
#include <filesystem>
#include <chrono>
#include <system_error>
#include "imgui_internal.h"
#include "xbm_sched.h"
#include "xbm_audio.h"
#include "ui_scrub.h"
#include "ui_log.h"
#include "xbm_model.h"

#include <algorithm>
#include <unordered_set>
#include <cmath>
#include <cfloat>
#include <cstdio>
#include <cstring>
#include <map>
#include <string>

#include <sys/stat.h>
#if defined(_WIN32)
    #include <direct.h>
#endif

#include <nlohmann/json.hpp>
#include "xbm_timeline_adapter.h"   // timeline ist die Quelle der Eintraege
#include "xbm_timeline_sync.h"      // Abgleich ueber das Netz anstossen
#include "ui_textstore.h"          // UiFlagGet/Set (Leiste kompakt/gross)
#include "ui_navi.h"               // Abschnitt-Rechtecke der Navi 1 (Drop-Ziele Papierkorb/Vorlagen)
#if !defined(_WIN32)
#include <unistd.h>                   // gethostname: Geraetename fuer den Abgleich
#endif
#include "misc/cpp/imgui_stdlib.h"   // InputText fuer std::string
using json = nlohmann::json;

// Einhaengepunkte (Voreinstellung: nicht gesetzt).
void (*UiCalendar_ClaimGesture)() = nullptr;
bool (*UiCalendar_ScrollPinpoint)() = nullptr;
void (*UiCalendar_NetzAbgleichJetzt)() = nullptr;
int  (*UiCalendar_GetTouches)(float*, int) = nullptr;

namespace {

// ---------------------------------------------------------------------------
// Zustand
// ---------------------------------------------------------------------------
struct DragState {
    std::uint64_t id = 0;
    bool  armed    = false;    // gedrueckt, aber Halte-Schwelle noch nicht erreicht
    bool  active   = false;    // Ziehen laeuft
    bool  resizing = false;    // untere Kante: Dauer aendern
    int   grip     = 0;        // 0=Koerper,1=Event-Start,2=Event-Ende,
                                // 3=Erinnerung-Verschieben,4=Erinnerung-Start,5=Erinnerung-Ende
    double pressTime = 0.0;
    ImVec2 pressPos{0, 0};
    std::int64_t origStart = 0;
    std::int32_t origDur   = 30;
    std::int64_t griffVersatzSek = 0;   // Zeit unter dem Finger minus Start beim Greifen: der Termin wandert aus dieser Stelle heraus
    // Nur bei grip 3/4/5 gesetzt: das EVENT, dem die gezogene Erinnerung
    // gehoert -- damit die zentrale Zugverarbeitung (siehe
    // AktivenZugImZeitraster) sie ohne Suche findet.
    std::uint64_t ownerEventId = 0;
};

struct CalState {
    std::string dir;
    std::string file;
    std::vector<CalEntry> entries;
    std::uint64_t nextId = 1;
    bool dirty = false;
    double lastSave = 0.0;

    CalView view = CalView::ThreeDay;   // Woche ist entfernt -- Standard jetzt n-Tage
    std::int64_t anchor = 0;         // lokale Mitternacht des ersten Tages
    // Welche Action/Erinnerung ist angefasst? [Getrennt von "selected":
    //  das Mutter-Event bleibt ausgewaehlt, waehrend man eine seiner
    //  Erinnerungen bearbeitet -- so wie du es beschrieben hast.]
    std::uint64_t actionSel = 0;
    float pxPerHour = 44.0f;
    bool  scrollInit = false;

    std::uint64_t selected = 0;
    std::uint64_t editing  = 0;
    // SERIEN-VORKOMMEN (virtuell). [Die Ansicht kannte nur Eintraege, deren
    //  start im Fenster liegt -- Wiederholungen erschienen nie. Jetzt liefert
    //  timeline::vorkommen() die Termine, und jedes bekommt hier eine
    //  Kopie des Serieneintrags mit verschobenem start und eigener, nicht
    //  persistenter Kennung (hoechstes Bit gesetzt). Die Kopien leben nur
    //  bis zum naechsten UiCalendar_Range().]
    std::vector<CalEntry> vork;
    struct VirtOcc { std::uint64_t vid, base; std::int64_t occStart; bool kind = false; /* tiefes Unter-Event: nur Anzeige */ std::uint64_t kindId = 0; };
    // AKTIV-MODUS: dieses Event (Wurzel oder Unterevent) ist Elternteil fuer
    // alles, was jetzt angelegt wird. Doppeltipp setzt es, nochmal Doppeltipp
    // oder "Beenden" hebt es auf.
    std::uint64_t aktivEltern = 0;
    // EXPLORER: schwebendes Baumfenster ueber dem Kalender (aus dem Editor
    // ausgefahren). explorerSel = Modell-Id des gewaehlten Knotens;
    // explorerHover = Knoten unter dem Finger waehrend eines Kalender-Zugs
    // (Drop-Ziel); explorerZu = eingeklappte Knoten.
    std::uint64_t gruppeOffen = 0;          // Doppeltipp auf eine Gruppe: Mitglieder einzeln verschiebbar
    std::uint64_t editingKind = 0;          // Modell-Id eines bearbeiteten Unter-Termins (Editor unten)
    bool editorEingefahren = false;         // Bearbeiten nach unten herausgewischt: bleibt zu, bis der Termin NOCH EINMAL getippt oder von unten hereingewischt wird
    bool sofortVerschieben = false;         // Navi 0: Termine ohne vorherige Auswahl verschieben (Vorgabe aus)
    // DRAG & DROP eines NICHT ausgewaehlten Termins: er bleibt im Kalender,
    // ein Symbol folgt dem Finger; ablegen im Baum (Unter-Termin), im
    // Papierkorb (loeschen) oder bei den Vorlagen (als Vorlage).
    struct Dnd { std::uint64_t id = 0; ImVec2 pressPos; bool aktiv = false; std::string titel; ImU32 farbe = 0; } dnd;
    std::vector<std::uint64_t> zwischenablage;   // Strg+C
    bool explorerOffen = false; std::uint64_t explorerSel = 0, explorerHover = 0, explorerWurzel = 0;
    std::set<std::uint64_t> explorerZu; float explorerH = 0.0f, explorerExtra = 0.0f; ImVec2 explorerRect0, explorerRect1;
    struct BarDrag { std::uint64_t id = 0; float x0 = 0; std::int64_t origStart = 0; bool bewegt = false; } barDrag;
    std::uint64_t barTippId = 0;            // Leiste gedrueckt (auch ohne Zugrecht)
    int   barGriff = 0;                     // 0 ganzer Balken, 1 Start-Griff, 2 Ende-Griff
    int   barOrigDur = 0;
    double barRandTick = 0.0;
    ImVec2 leisteRect0, leisteRect1;        // Rechteck der Mehrtagesleiste (Pinpoint bleibt dort aus)
    ImVec2 editorRect0, editorRect1;        // Rechteck des Bearbeitungsfensters unten (Pinpoint bleibt dort aus)
    float barTippX = 0, barTippY = 0;
    float navPinStartY = 0.0f;
    int   navPinAchse = 0;                  // 0 offen, 1 waagerecht (Datum), 2 senkrecht (Uhrzeit)
    float pinScrollV  = 0.0f;               // senkrechtes Pinpoint: px/s, im Raster angewandt
    float pinchNDays0 = 0.0f;               // waagerechter Pinch: Tage beim Aufsetzen
    // ZEIT-OVERLAY (<-> neben dem Titel): drei Spalten Start | Verschieben | Ende.
    std::int64_t zlOrigEnde = 0, zlOrigStart = 0; int zlOrigDur = 0; bool zlAktiv = false;
    // MITFUEHREN: der Kalenderausschnitt folgt dem bewegten Punkt (Start,
    // Termin oder Ende) -- nur, wenn er den Ausschnitt verlassen wuerde.
    std::int64_t folgeZeit = 0; bool folgeAn = false;
    std::vector<VirtOcc> vmap;
    std::int64_t dragVirtStart = 0;         // Zugposition eines virtuellen Vorkommens
    int          dragVirtDur   = 0;         // ... und seine Dauer waehrend eines Griff-Zugs
    struct SerienZug { bool offen = false; std::uint64_t base = 0; std::int64_t occStart = 0, neuStart = 0; int neuDur = 0; } serienZug;
    // n-Tage-Knopf: gedrueckt halten und waagerecht wischen (Pinpoint auf den Wert)
    bool  nZugAktiv = false; float nZugX0 = 0.0f; double nZugAkk = 0.0;
    // BEARBEITUNGSKOPIE eines Vorkommens: der Editor arbeitet darauf; beim
    // Schliessen entscheidet die Abfrage, wohin die Aenderung geht.
    CalEntry editKopie, editOriginal; bool editKopieAktiv = false;
    struct SerienFrage { bool offen = false; int art = 0; /* 1 = bearbeitet, 2 = loeschen */ std::uint64_t base = 0; std::int64_t occStart = 0; CalEntry kopie; } serienFrage;
    // slotSel ist der GELBE MARKER: Tag UND Uhrzeit der Auswahl in einem.
    // Der ausgewaehlte Tag ist damit XbmTime_LocalMidnight(slotSel).
    std::int64_t  slotSel  = 0;
    // Wie viele Tage zeigt die "n-Tage"-Ansicht? 1..8, wird gesichert.
    int           nDays    = 3;
    // Erster Tipp im Jahr waehlt nur aus, der zweite springt.
    std::int64_t  lastYearTap = 0;
    double        lastYearTapT = 0.0;

    DragState drag;

    // Pinch
    bool  pinching = false;
    float pinchMidStart = -1.0f;            // Mittelpunkt beim Aufsetzen (Zwei-Finger-Pinpoint)
    bool  zoomAn = true;                    // Lupe: Zeitachse zoombar (sonst passt der ganze Tag in den Ausschnitt)
    float pinchDist0 = 0.0f, pinchPph0 = 0.0f, pinchAnchorHour = 0.0f;
    float pinchMidY0 = 0.0f;   // Mitte der zwei Finger, fuer Zwei-Finger-Scroll

    // WAAGERECHTER PINCH -- ANSICHTSWECHSEL.
    // [Getrennter Zustand vom senkrechten Stunden-Pinch oben: beide
    //  koennen mit denselben zwei Fingern beginnen, die RICHTUNG
    //  entscheidet erst danach, wem die Geste gehoert.]
    bool  pinchHActive = false;
    float pinchHDist0  = 0.0f;

    // KANTEN-NAVIGATION (Scroll/Wisch bzw. Pinpoint an den Raendern).
    // [Siehe NavKanteFrame(): ein Finger, der WAAGERECHT durch den
    //  Kalender wischt (Vorgabe "scrollen"), oder ein Antippen der
    //  linken/rechten Kante (Vorgabe "pinpoint"), soll je nach globaler
    //  Einstellung UiScrollPinpoint() eine ganze Seite weiterblaettern.]
    bool   navWischArmed  = false;   // ein Finger unten, Richtung noch offen
    ImVec2 navWischStart{0, 0};
    double navWischStartZeit = 0.0;  // fuer die Geschwindigkeit des Wisches
    bool   navWischAusgeloest = false;   // schon eine Seite geschaltet in diesem Zug

    // PINPOINT AN DER KANTE -- FORTLAUFEND, NICHT EINMALIG.
    // [Erste Fassung: ein Tipp auf der Kante = EIN Sprung. Das war nicht
    //  gemeint -- "Pinpoint" heisst ueberall sonst in der App "halten und
    //  herausziehen wird schneller" (siehe NaviZeileZeichnen). Jetzt
    //  haelt man an der Kante und zieht INS Bild hinein; je weiter, desto
    //  schneller blaettert es, genau wie bei der Navigationszeile.]
    bool   navPinArmed = false;
    int    navPinRichtung = 0;       // -1 = zurueck (linke Kante), +1 = vor
    float  navPinStartX = 0.0f;
    double navPinLetzter = 0.0;

    // Memo
    bool memoActive = false;
    std::int64_t memoStart = 0;
    std::uint64_t memoEntry = 0;
    std::string memoStatus;
    bool wasVisible = false;

    // STIFTWERKZEUG / BULK-EDIT.
    // [Eine eigene Menge statt einer einzelnen id, weil hier -- anders
    //  als bei "selected" -- absichtlich MEHRERE Eintraege gleichzeitig
    //  gehalten werden sollen, um sie gemeinsam zu verschieben, einzu-
    //  faerben oder zu loeschen.]
    bool penActive = false;
    bool eraserActive = false;              // Radierer (Navi 0): Wischen ueber Koepfe loescht in den Papierkorb
    std::unordered_set<std::uint64_t> penSel;

    // STIFT: ZEITSPANNE ZEICHNEN.
    // [Zieht man mit aktivem Stift auf FREIER Flaeche (nicht auf einem
    //  vorhandenen Event), entsteht dort ein neues Event, das genau die
    //  gezogene Spanne umfasst -- vom Aufsetzpunkt bis zum Loslassen.]
    // STIFT: ZUG AUF FREIER FLAECHE.
    // [Zwei Ergebnisse, je nachdem, was der gezogene Bereich beim
    //  Loslassen UEBERDECKT:
    //    * ueberdeckt er MINDESTENS EIN vorhandenes Event -> Rechteck-
    //      Mehrfachauswahl: alle darunterliegenden Events werden der
    //      Bulk-Auswahl hinzugefuegt.
    //    * ueberdeckt er KEIN Event (leere Flaeche) -> es entsteht ein
    //      NEUES Event, das genau die gezogene Zeitspanne umfasst.
    //  Beginnt der Zug mit einem DOPPELTIPP/-KLICK, kehrt sich die erste
    //  Wirkung um: dann werden ueberdeckte Events aus der Auswahl
    //  ENTFERNT statt hinzugefuegt (der zweite Fall -- neues Event -- gilt
    //  dann nicht: ein Doppeltipp auf leerer Flaeche tut nichts).]
    bool         penZugAktiv    = false;
    ImVec2       penZugPressPx{0, 0};
    bool         penZugInvert   = false;

    // TASTATUR-MEHRFACHBEARBEITUNG: TITEL/NOTIZ ALLER AUSGEWAEHLTEN.
    // [Beim UEBERGANG von "nichts ausgewaehlt" zu "mindestens eines
    //  ausgewaehlt" wird der Fokus auf das Bulk-Titelfeld gelegt, damit
    //  ein sofortiger Tastendruck dort landet, statt ein neues Event
    //  anzulegen -- genau wie du es beschrieben hast.]
    int         penSelVorher      = 0;    // Auswahlgroesse des LETZTEN Frames
    // WELCHES Feld soll naechsten Frame den Fokus bekommen, und WIE?
    // [TitelVoll = Titel, komplett markiert (Uebergang 0->1, oder Tab
    //  aus der Notiz zurueck). TitelEnde = Titel, Cursor ans Ende, NICHTS
    //  markiert (Enter bei bestehender Auswahl -- der Titel soll
    //  ERHALTEN bleiben). NotizVoll = Notiz, komplett markiert (Tab bei
    //  bestehender Auswahl, oder Tab aus dem Titel).]
    enum class PenFokus { Keine, TitelVoll, TitelEnde, NotizVoll };
    PenFokus    penFokus = PenFokus::Keine;
    std::string penBulkTitel;
    std::string penBulkNotiz;

    bool         penZeichnetAktiv = false;
    std::int64_t penZeichnetStart = 0;   // fester Ankerpunkt (Aufsetzen)
    std::int64_t penZeichnetEnde  = 0;   // wandert mit dem Finger
    float editorMeasured = 0.0f;   // Hoehe des Editors im vorigen Frame

    std::function<void(const CalEntry&)> onRemind;
    std::map<std::uint64_t, XbmTaskId> reminders;

    // Bearbeitungspuffer (damit InputText nicht direkt auf dem Vektor
    // arbeitet -- der kann durch Add/Remove umziehen).
    std::string bufTitle;
    std::string bufNotes;
    std::uint64_t bufFor = 0;

    // Tastatur-Sofortanlage: das ausloesende Zeichen, das der neu
    // angelegte Eintrag noch ins Titelfeld bekommen soll.
    unsigned int pendingFirstChar = 0;
    // ... und alle WEITEREN Zeichen desselben Frames. [Bei schnellem
    // Tippen liefert ImGui mehrere Zeichen pro Frame; sie muessen
    // vollstaendig zwischengelagert werden, weil das Titelfeld erst im
    // naechsten Frame aktiv wird und die Warteschlange bis dahin geleert
    // ist.]
    std::string pendingFirstText;
    std::uint64_t pendingFirstCharFor = 0;
    // Tab statt eines Zeichens legt ebenfalls sofort ein Event an --
    // aber der Fokus geht direkt in die NOTIZ, nicht in den Titel.
    bool pendingFirstIstTab = false;
    // ERSETZEN statt ANHAENGEN: nur gesetzt, wenn ein BESTEHENDES Event
    // ausgewaehlt war und man zu tippen begann -- der Titel wird dann
    // komplett durch das erste Zeichen ersetzt (markiert+ueberschrieben),
    // statt (wie beim NEUANLEGEN) das Zeichen einfach anzuhaengen.
    bool pendingReplaceMode = false;

    // WELCHES Feld des EINZEL-Editors soll naechsten Frame den Fokus
    // bekommen, und WIE? Dieselbe Bedeutung wie PenFokus oben, nur fuer
    // DrawEditor() statt die Stift-Werkzeugleiste.
    enum class EdFokus { Keine, TitelVoll, TitelEnde, NotizVoll, NotizEnde };
    // ERZWUNGENES "CURSOR ANS ENDE, NICHTS MARKIERT" fuer die naechsten
    // N Frames des Titelfelds.
    // [Noetig, weil ImGui bei Fokus UEBER DIE TASTATUR (also alles, was
    //  ueber SetKeyboardFocusHere kommt) den Inhalt GRUNDSAETZLICH
    //  markiert -- unabhaengig davon, ob AutoSelectAll gesetzt ist. Beim
    //  Anlegen per Tastenschlag stand der erste Buchstabe damit markiert
    //  da, und der zweite ersetzte ihn: der Buchstabe wirkte wieder
    //  "verschluckt". Zwei Frames, weil der Fokus erst im Frame NACH
    //  SetKeyboardFocusHere wirksam wird.]
    int titelCursorAnsEnde = 0;
    // Wie viele Frames das Titelfeld schon AKTIV war, waehrend der
    // Rueckruf lief. [Siehe DrawEditor: der Rueckruf laeuft nicht mehr
    // eine geratene Zahl von Frames, sondern bis das Feld nachweislich
    // aktiv ist.]
    int titelCursorAktivFrames = 0;
    EdFokus edFokus = EdFokus::Keine;

    // DATUM/UHRZEIT-OVERLAY: PINCHEN MIT GESCHWINDIGKEIT.
    // [Haelt man einen Wert-Knopf gedrueckt und zieht nach oben/unten,
    //  laeuft der Wert FORTLAUFEND hoch/runter -- je weiter man zieht,
    //  desto schneller (dieselbe Auslenkungskurve wie ueberall sonst in
    //  der App beim Pinpoint-Halten). ozZiehtLetzterTick merkt sich, wann
    //  der letzte Schritt kam, damit die Geschwindigkeit ueber die Zeit
    //  gesteuert werden kann, nicht nur ueber die Strecke.]
    float  ozZiehtStartY      = 0.0f;
    int    ozZiehtStartWert   = 0;
    double ozZiehtLetzterTick = 0.0;

    // JAHR: WAAGERECHTER DOOMSCROLLER -- UND ZUSAETZLICH senkrechtes
    // Pinchen mit dem gleichen Geschwindigkeits-Prinzip wie die anderen
    // Felder ("in jedem Fall").
    float ozJahrStartX    = 0.0f;
    int   ozJahrStartWert = 0;

    // DREI KNOEPFE STATT EINEM: Start setzen, ganzes Event verschieben,
    // Ende setzen. Beim STARTEN wird das bisherige ENDE festgehalten
    // (Dauer passt sich an); beim ENDE-Setzen umgekehrt der bisherige
    // START. Diese beiden Bezugspunkte werden EINMAL beim Oeffnen des
    // jeweiligen Overlays festgehalten, nicht bei jeder Aenderung neu
    // berechnet -- sonst wuerde sich das Ziel waehrend des Einstellens
    // mitverschieben.
    std::int64_t ozStartOrigEnde  = 0;
    std::int64_t ozEndeOrigStart  = 0;
    std::int32_t ozStartOrigDur   = 30;
    std::int32_t ozEndeOrigDur    = 30;

    // AUTO-SCROLL WAEHREND EINES ZUGS: Taktung fuer das tageweise
    // Weiterschalten am Rand (senkrechtes Scrollen braucht keine eigene
    // Taktung, das laeuft kontinuierlich ueber die Bildschirmzeit).
    double autoScrollLetzterTick = 0.0;
    // RANDZONE ERST NACH EINEM ABSTECHER IN DIE MITTE FREIGEBEN.
    // [Packt man einen Greifer, der schon AM RAND liegt, blaetterte die
    //  Ansicht bisher sofort los -- noch bevor man ueberhaupt gezogen
    //  hatte. Jetzt gilt die Randzone fuer einen Zug erst dann, wenn der
    //  Zeiger sie in diesem Zug schon einmal VERLASSEN hat. Wer am Rand
    //  anpackt, muss also erst einmal Richtung Mitte und dann wieder
    //  hinein. Getrennt je Achse, weil man sonst beim waagerechten
    //  Anpacken am unteren Rand zugleich das senkrechte Scrollen
    //  ausloesen wuerde.]
    bool   randScharfH = false;
    bool   randScharfV = false;
    // Kennung des Zugs, fuer den die beiden Schalter gelten -- der
    // Zeitpunkt des Anpackens, weil der bei JEDEM Zug neu gesetzt wird,
    // auch wenn man dasselbe Event zweimal hintereinander zieht.
    double randScharfFuerZug = -1.0;

    // DREIFACH-TIPP LOESCHT EIN EVENT. [Ringpuffer der letzten drei
    // Klicks (Event-Kennung + Zeitpunkt) -- treffen alle drei
    // dieselbe Kennung innerhalb eines kurzen Fensters, gilt das als
    // Dreifach-Tipp.]
    std::uint64_t tripleTapId[3]   = {0, 0, 0};
    double        tripleTapZeit[3] = {0.0, 0.0, 0.0};
    std::uint64_t zuLoeschenNachSchleife = 0;

    // ERKENNUNG VON AENDERUNGEN VON AUSSEN (Netz-Abgleich).
    std::int64_t externeDateiZeit    = 0;    // zuletzt gesehener Schreibzeitpunkt
    double       letzterExternCheck  = 0.0;  // ImGui::GetTime() beim letzten Stat-Aufruf
};

CalState& C() { static CalState s; return s; }

// ---------------------------------------------------------------------------
// Farben: stabil aus der id abgeleitet, damit ein Eintrag seine Farbe
// behaelt, ohne dass sie gespeichert werden muss.
// ---------------------------------------------------------------------------
ImU32 EntryColor(const CalEntry& e) {
    if (e.color) return (ImU32)e.color;
    static const ImU32 pal[] = {
        IM_COL32( 66, 133, 244, 220), IM_COL32( 15, 157,  88, 220),
        IM_COL32(244, 160,   0, 220), IM_COL32(219,  68,  55, 220),
        IM_COL32(156,  39, 176, 220), IM_COL32(  0, 172, 193, 220),
        IM_COL32(255, 112,  67, 220), IM_COL32( 92, 107, 192, 220),
    };
    std::uint64_t h = e.id * 2654435761u;
    return pal[(h >> 8) % (sizeof(pal) / sizeof(pal[0]))];
}

ImU32 Darken(ImU32 c, float f) {
    ImVec4 v = ImGui::ColorConvertU32ToFloat4(c);
    v.x *= f; v.y *= f; v.z *= f;
    return ImGui::ColorConvertFloat4ToU32(v);
}

// ---------------------------------------------------------------------------
// Persistenz
// ---------------------------------------------------------------------------
std::string JoinPath(const std::string& a, const std::string& b) {
    if (a.empty()) return b;
    char last = a[a.size() - 1];
    if (last == '/' || last == '\\') return a + b;
    return a + "/" + b;
}

// Ordner anlegen (alle Ebenen). Bewusst OHNE system(): ein Shell-Aufruf
// waere auf Android unzuverlaessig, langsam und wuerde bei Leerzeichen im
// Pfad an der Zitierung scheitern.
void MakeDir(const std::string& p) {
    if (p.empty()) return;
    std::string cur;
    for (std::size_t i = 0; i <= p.size(); ++i) {
        if (i == p.size() || p[i] == '/' || p[i] == '\\') {
            if (cur.size() > 1 || (cur.size() == 1 && cur[0] != '.')) {
#if defined(_WIN32)
                _mkdir(cur.c_str());
#else
                ::mkdir(cur.c_str(), 0775);
#endif
            }
        }
        if (i < p.size()) cur += p[i];
    }
}

void ScheduleReminders();

void SaveNow() {
    if (C().file.empty()) return;
    json j;
    j["version"] = 2;   // 2 = Memos als Liste, Wiederholung, remindOn
    j["nextId"]  = C().nextId;
    // Ansichtszustand mitsichern -- beim naechsten Start steht der
    // Kalender wieder so da, wie man ihn verlassen hat.
    j["view"]    = (int)C().view;
    j["nDays"]   = C().nDays;
    j["slotSel"] = C().slotSel;
    j["anchor"]  = C().anchor;
    j["pxPerHour"] = C().pxPerHour;
    json arr = json::array();
    for (const auto& e : C().entries) {
        json o;
        o["id"] = e.id;  o["start"] = e.start;  o["durMin"] = e.durMin;
        o["title"] = e.title;  o["notes"] = e.notes;
        // MEMOS ALS LISTE. [Das alte Feld "audio" wird weiter
        //  GESCHRIEBEN, solange es genau eine Memo gibt -- dann kann eine
        //  aeltere Fassung der App die Datei noch lesen. Mit mehreren
        //  Memos bleibt es leer; das ist der Punkt, ab dem das neue
        //  Format gilt.]
        json ma = json::array();
        for (const auto& m : e.memos) {
            json mo;
            mo["audio"] = m.audio;
            mo["transkript"] = m.transkript;
            mo["aufgenommen"] = m.aufgenommen;
            mo["dauerMs"] = m.dauerMs;
            ma.push_back(std::move(mo));
        }
        o["memos"] = std::move(ma);
        o["audio"] = (e.memos.size() == 1) ? e.memos[0].audio : std::string();
        o["color"] = e.color;  o["allDay"] = e.allDay;
        o["remindMin"] = e.remindMin;
        o["remindOn"]  = e.remindOn;
        o["wdh"]       = (int)e.wdh;
        o["wdhJede"]   = e.wdhJede;
        o["wdhBis"]    = e.wdhBis;
        json aa = json::array();
        for (const auto& a : e.actions) {
            json ao;
            ao["id"] = a.id;  ao["art"] = (int)a.art;
            ao["start"] = a.start;  ao["durMin"] = a.durMin;
            ao["ton"] = a.ton;  ao["text"] = a.text;  ao["ziel"] = a.ziel;
            ao["aktiv"] = a.aktiv;  ao["getan"] = a.getan;
            ao["statisch"] = a.statisch;
            aa.push_back(std::move(ao));
        }
        o["actions"] = std::move(aa);
        o["created"] = e.created;  o["modified"] = e.modified;
        o["source"] = e.source;
        arr.push_back(std::move(o));
    }
    j["entries"] = std::move(arr);

    // TIMELINE ZUERST: Aenderungen der Oberflaeche uebernehmen (nur, was
    // sich geaendert hat) und timeline.json schreiben.
    if (xbm_tl::Geladen()) {
        if (xbm_tl::Uebernehmen(C().entries, XbmTime_NowUtc()) > 0) xbm_tls::Anstossen();   // gleich verteilen
        xbm_tl::Speichern();
    }
    // Erst in eine Nebendatei, dann umbenennen: ein Absturz mitten im
    // Schreiben darf nie den ganzen Kalender zerstoeren.
    const std::string tmp = C().file + ".tmp";
    if (std::FILE* f = std::fopen(tmp.c_str(), "wb")) {
        const std::string s = j.dump(1, '\t');
        std::fwrite(s.data(), 1, s.size(), f);
        std::fclose(f);
        std::remove(C().file.c_str());
        std::rename(tmp.c_str(), C().file.c_str());
    }
    C().dirty = false;
    ScheduleReminders();
}

void LoadNow() {
    // NICHT MEHR SOFORT LOESCHEN.
    // [Vorher stand "C().entries.clear()" HIER, ganz am Anfang -- vor
    //  jedem Erfolgsnachweis. Schlug "fopen" fehl (Datei kurzzeitig
    //  nicht da/gesperrt) ODER warf json::parse() eine Ausnahme (Datei
    //  war GERADE MITTEN IM SCHREIBEN durch den Netz-Abgleich, also
    //  unvollstaendiges JSON), blieb C().entries fuer immer LEER -- der
    //  gesamte Kalender war im Speicher weg, obwohl auf der Platte
    //  laengst wieder eine gueltige Datei lag. Seit der automatische
    //  Neulade-Mechanismus (voriger Abschnitt) die Datei viel oefter
    //  anfasst als frueher (nur einmal beim Start), trifft genau dieses
    //  Zeitfenster deutlich haeufiger -- das war sehr wahrscheinlich die
    //  Ursache fuer die gemeldeten Abstuerze rund um den Netz-Abgleich:
    //  ein Callback (Transkription, Erinnerungs-Ergebnis) hielt sich
    //  vermutlich noch einen ZEIGER auf einen inzwischen durch clear()
    //  entwerteten CalEntry, und griff spaeter darauf zu -- klassischer
    //  Use-after-free, der als Speicherzugriffsfehler endet.
    //  Jetzt wird ALLES ERST in ein lokales Ergebnis geparst; C().entries
    //  wird nur EIN EINZIGES MAL, ganz am Ende, und NUR bei vollem
    //  Erfolg ersetzt. Schlaegt irgendetwas fehl, bleibt der bisherige
    //  Bestand VOLLSTAENDIG unangetastet.]
    std::FILE* f = std::fopen(C().file.c_str(), "rb");
    if (!f) return;                 // Datei (noch) nicht da -- nichts aendern
    std::string buf;
    char tmp[4096];
    std::size_t n;
    while ((n = std::fread(tmp, 1, sizeof(tmp), f)) > 0) buf.append(tmp, n);
    std::fclose(f);
    try {
        json j = json::parse(buf);

        // Alles zunaechst in LOKALE Werte -- committet wird erst am Ende.
        std::uint64_t nextIdNeu   = j.value("nextId", (std::uint64_t)1);
        CalView       viewNeu     = (CalView)j.value("view", (int)CalView::ThreeDay);
        int           nDaysNeu    = j.value("nDays", 3);
        if (nDaysNeu < 1) nDaysNeu = 1;
        if (nDaysNeu > 15) nDaysNeu = 15;
        std::int64_t  slotSelNeu  = j.value("slotSel", (std::int64_t)0);
        std::int64_t  anchorNeu   = j.value("anchor",  (std::int64_t)0);
        float         pphNeu      = j.value("pxPerHour", 44.0f);
        if (pphNeu < 10.0f || pphNeu > 260.0f) pphNeu = 44.0f;

        std::vector<CalEntry> entriesNeu;
        entriesNeu.reserve(j.value("entries", json::array()).size());
        for (const auto& o : j.value("entries", json::array())) {
            CalEntry e;
            e.id        = o.value("id", (std::uint64_t)0);
            e.start     = o.value("start", (std::int64_t)0);
            e.durMin    = o.value("durMin", 30);
            e.title     = o.value("title", std::string());
            e.notes     = o.value("notes", std::string());
            e.audio     = o.value("audio", std::string());
            // MEMOS LESEN -- UND ALTES FORMAT UMWANDELN.
            // [Fassung 1 hatte ein Feld "audio" und das Transkript in
            //  "notes". Damit nichts verlorengeht: gibt es keine
            //  "memos"-Liste, aber ein "audio", wird daraus die erste
            //  Memo -- und "notes" wandert als deren Transkript mit,
            //  weil es dort das Transkript WAR. Eintraege ohne Audio
            //  behalten ihre Notiz unangetastet.]
            if (o.contains("memos") && o["memos"].is_array()) {
                for (const auto& mo : o["memos"]) {
                    CalMemo m;
                    m.audio       = mo.value("audio", std::string());
                    m.transkript  = mo.value("transkript", std::string());
                    m.aufgenommen = mo.value("aufgenommen", (std::int64_t)0);
                    m.dauerMs     = mo.value("dauerMs", 0);
                    if (!m.audio.empty()) e.memos.push_back(std::move(m));
                }
            } else if (!e.audio.empty()) {
                CalMemo m;
                m.audio      = e.audio;
                m.transkript = e.notes;      // dort lag es in Fassung 1
                m.aufgenommen = o.value("created", (std::int64_t)0);
                e.memos.push_back(std::move(m));
                e.notes.clear();             // jetzt wieder freie Notiz
            }
            e.color     = o.value("color", (std::uint32_t)0);
            e.allDay    = o.value("allDay", false);
            e.remindMin = o.value("remindMin", -1);
            // remindOn gab es nicht: eine gesetzte Minutenzahl bedeutete
            // "Erinnerung an". So bleibt das Verhalten gleich.
            e.remindOn  = o.value("remindOn", e.remindMin >= 0);
            e.wdh       = (CalWiederholung)o.value("wdh", 0);
            e.wdhJede   = o.value("wdhJede", 1);
            if (e.wdhJede < 1) e.wdhJede = 1;
            e.wdhBis    = o.value("wdhBis", (std::int64_t)0);
            // ACTIONS LESEN -- oder aus der einfachen Erinnerung bauen.
            // [Wer bisher "15 min vorher" eingestellt hat, soll das nach
            //  dem Umstieg genauso wiederfinden: daraus wird eine Action
            //  mit art = Alarm. remindMin/remindOn bleiben als einfacher
            //  Weg bestehen, damit nicht jeder Eintrag eine Liste braucht.]
            if (o.contains("actions") && o["actions"].is_array()) {
                for (const auto& ao : o["actions"]) {
                    CalAction a;
                    a.id     = ao.value("id", (std::uint64_t)0);
                    a.art    = (CalActionArt)ao.value("art", 0);
                    a.start  = ao.value("start", (std::int64_t)0);
                    a.durMin = ao.value("durMin", 0);
                    a.ton    = ao.value("ton", std::string());
                    a.text   = ao.value("text", std::string());
                    a.ziel   = ao.value("ziel", std::string());
                    a.aktiv  = ao.value("aktiv", true);
                    a.statisch = ao.value("statisch", false);
                    a.getan  = ao.value("getan", false);
                    if (a.id == 0) a.id = nextIdNeu++;
                    if (a.id >= nextIdNeu) nextIdNeu = a.id + 1;
                    e.actions.push_back(std::move(a));
                }
            } else if (e.remindOn && e.remindMin >= 0) {
                CalAction a;
                a.id    = nextIdNeu++;
                a.art   = CalActionArt::Alarm;
                a.start = e.start - (std::int64_t)e.remindMin * 60;
                e.actions.push_back(std::move(a));
            }
            e.created   = o.value("created", (std::int64_t)0);
            e.modified  = o.value("modified", (std::int64_t)0);
            e.source    = o.value("source", std::string());
            if (e.id == 0) e.id = nextIdNeu++;
            if (e.id >= nextIdNeu) nextIdNeu = e.id + 1;
            entriesNeu.push_back(std::move(e));
        }
        // ALTLAST AUFRAEUMEN: frueher wurde der Zustand fest in die Notiz
        // geschrieben. Solche Saetze sind keine Notizen, sondern Muell aus
        // einer alten Programmfassung -- und sie bleiben stehen, auch wenn
        // whisper laengst einkompiliert ist. Sie werden hier entfernt,
        // damit das Feld wieder dem Nutzer gehoert.
        for (auto& en : entriesNeu) {
            if (en.notes == "(wird transkribiert...)" ||
                en.notes == "(Transkription nicht einkompiliert)")
                en.notes.clear();
        }
        std::sort(entriesNeu.begin(), entriesNeu.end(),
                  [](const CalEntry& a, const CalEntry& b) { return a.start < b.start; });

        // ALLES HAT GEKLAPPT -- JETZT ERST UEBERNEHMEN.
        // EINTRAEGE AUS TIMELINE. [Die "entries" der calendar.json sind nur
        //  noch eine Sicherheitskopie fuer aeltere App-Fassungen; massgeblich
        //  ist die Projektion aus timeline. Ids duerfen nicht kollidieren:
        //  nextId liegt ueber beidem.]
        if (xbm_tl::Geladen()) {
            entriesNeu = xbm_tl::Projizieren();
            if (xbm_tl::Speicher().naechsteId > nextIdNeu) nextIdNeu = xbm_tl::Speicher().naechsteId;
            for (const CalEntry& e : entriesNeu) { if (e.id >= nextIdNeu) nextIdNeu = e.id + 1;
                for (const CalAction& a : e.actions) if (a.id >= nextIdNeu) nextIdNeu = a.id + 1; }
        }
        C().entries   = std::move(entriesNeu);
        C().nextId    = nextIdNeu;
        // ALTE, INZWISCHEN ENTFERNTE ANSICHTEN (Tag/Woche) UMWANDELN.
        // [Eine vor der Entfernung von T/W gespeicherte Datei kann noch
        //  view=Day oder view=Week enthalten -- ohne diese Umwandlung
        //  wuerde genau DAS beim naechsten Start wieder auftauchen,
        //  obwohl die Knoepfe dafuer laengst weg sind. Tag wird zu einem
        //  Tag in der n-Tage-Ansicht, Woche zu sieben.]
        if (viewNeu == CalView::Day)       { viewNeu = CalView::ThreeDay; nDaysNeu = 1; }
        else if (viewNeu == CalView::Week) { viewNeu = CalView::ThreeDay; nDaysNeu = 7; }
        C().view      = viewNeu;
        C().nDays     = nDaysNeu;
        C().slotSel   = slotSelNeu;
        C().anchor    = anchorNeu;
        C().pxPerHour = pphNeu;
    } catch (const std::exception& ex) {
        std::fprintf(stderr, "[kalender] calendar.json unlesbar: %s -- "
                     "bisheriger Bestand bleibt unangetastet\n", ex.what());
    }
}

// ---------------------------------------------------------------------------
// Erinnerungen
// ---------------------------------------------------------------------------
void ScheduleReminders() {
    for (auto& kv : C().reminders) XbmSched_Cancel(kv.second);
    C().reminders.clear();
    if (!C().onRemind) return;
    const std::int64_t now = XbmTime_NowUtc();
    for (const auto& e : C().entries) {
        if (e.remindMin < 0) continue;
        const std::int64_t at = e.start - (std::int64_t)e.remindMin * 60;
        if (at <= now) continue;
        const std::uint64_t id = e.id;
        // WANDUHR-Termin: ein Kalendereintrag soll um 09:00 erinnern, auch
        // wenn das Geraet zwischendurch geschlafen hat oder die Uhr per NTP
        // korrigiert wurde.
        auto tp = std::chrono::system_clock::from_time_t((std::time_t)at);
        C().reminders[id] = XbmSched_AtWall(tp, [id] {
            if (CalEntry* p = UiCalendar_Find(id))
                if (C().onRemind) C().onRemind(*p);
        }, XbmRun::Ui);
    }
}

// ---------------------------------------------------------------------------
// Zeit-Hilfen fuer die Ansicht
// ---------------------------------------------------------------------------
std::int64_t WeekStart(std::int64_t t) {
    const XbmLocalTime l = XbmTime_ToLocal(t);
    // Montag als Wochenanfang (deutsche Konvention; tm_wday: 0 = Sonntag).
    const int back = (l.weekday + 6) % 7;
    return XbmTime_LocalMidnight(XbmTime_AddDays(t, -back));
}

int DaysInView(CalView v) {
    switch (v) {
        case CalView::Day:      return 1;
        case CalView::ThreeDay: return C().nDays;   // einstellbar 1..8
        case CalView::Week:     return 7;
        default:                return 0;
    }
}

// ---------------------------------------------------------------------------
// KNOPF MIT HALTE-WIEDERHOLUNG.
// ImGuis PushButtonRepeat liefert die Wiederholung frei Haus (Verzoegerung
// und Takt kommen aus io.KeyRepeatDelay/-Rate). Waehrend gehalten wird,
// blenden wir ein Schildchen mit dem aktuellen Datum ein -- sonst weiss
// man beim Durchlaufen nicht, wo man gerade ist.
// ---------------------------------------------------------------------------
// EINHEITSGROESSE der Knoepfe unter dem Kalender: so gross wie die Symbole
// der Tab-Navigation (Navi-Leiste), damit man sie mit dem Finger trifft.
static float Einheit() { return ImMax(44.0f, ImGui::GetFrameHeight() * 1.8f); }
bool HoldButton(const char* label, const char* schild, const ImVec2& size) {
    ImGui::PushButtonRepeat(true);
    const bool hit = ImGui::Button(label, size);
    ImGui::PopButtonRepeat();
    if (ImGui::IsItemActive() && schild && schild[0])
        ImGui::SetTooltip("%s", schild);
    return hit;
}

// Wurde der Knopf LANG gedrueckt (ohne dass die Wiederholung zaehlt)?
// Fuer "halten oeffnet die Auswahl".
[[maybe_unused]] bool HeldLong(double seconds = 0.45) {   // (seit dem n-Tage-Wischen ohne Aufrufer; bleibt fuer kuenftige Langdruck-Gesten)
    return ImGui::IsItemActive()
        && ImGui::GetIO().MouseDownDuration[0] > (float)seconds;
}

bool IsTimeGrid(CalView v) {
    return v == CalView::Day || v == CalView::ThreeDay || v == CalView::Week;
}

const char* const kWeekdayShort[7] = { "Mo", "Di", "Mi", "Do", "Fr", "Sa", "So" };
const char* const kMonthName[12] = {
    "Januar", "Februar", "Maerz", "April", "Mai", "Juni",
    "Juli", "August", "September", "Oktober", "November", "Dezember"
};

// Anfang des Tages als Index 0..n-1 relativ zum Anker.
int DayIndexOf(std::int64_t t, std::int64_t anchor, int days) {
    for (int i = 0; i < days; ++i) {
        const std::int64_t d0 = XbmTime_AddDays(anchor, i);
        const std::int64_t d1 = XbmTime_AddDays(anchor, i + 1);
        if (t >= d0 && t < d1) return i;
    }
    return -1;
}

double SecondsIntoLocalDay(std::int64_t t) {
    return (double)(t - XbmTime_LocalMidnight(t));
}

}  // namespace

// ---------------------------------------------------------------------------
// Oeffentliche Datenschnittstelle
// ---------------------------------------------------------------------------
void UiCalendar_Init(const std::string& dataDir) {
    C().dir  = dataDir;
    C().file = JoinPath(dataDir, "calendar.json");
    MakeDir(dataDir);
    MakeDir(JoinPath(dataDir, "memos"));
        // KALENDER IN DEN ABGLEICHORDNER HOLEN.
    // [Der Kalender lag unter IniFolderLocation(AppUserConfigFolder) --
    //  der Netzabgleich sieht aber nur XbmPaths_DataRoot(). Zwei
    //  verschiedene Orte: deshalb wurde calendar.json NIE uebertragen.
    //  Der Abgleich arbeitete richtig, er sah die Datei bloss nicht.
    //
    //  Statt den Abgleich zu erweitern, zieht der Kalender um: er gehoert
    //  zu den Daten, nicht zur Konfiguration. Eine vorhandene Datei am
    //  alten Ort wird EINMAL mitgenommen -- und die alte bleibt als
    //  Sicherung liegen, damit nichts verlorengeht.]
    {
        std::error_code ec;
        namespace fs = std::filesystem;
        const std::string ziel = XbmPaths_Sub("kalender");
        fs::create_directories(ziel, ec);
        const std::string zielDatei = ziel + "/calendar.json";
        const std::string altDatei  = C().dir + "/calendar.json";
        const bool zielDa = fs::exists(zielDatei, ec);
        const bool altDa  = (C().dir != ziel) && fs::exists(altDatei, ec);
        // WELCHE DATEI IST DIE AKTUELLE?
        // [Hier lag ein Fehler: C().file wurde oben auf den ALTEN Ort
        //  gesetzt und nach dem Umzug nie angepasst. Gespeichert und
        //  geladen wurde also weiter am alten Ort -- der neue enthielt nur
        //  die einmalige Kopie vom ersten Umzug und veraltete danach. Der
        //  Netzabgleich uebertrug genau diese veraltete Kopie, und was von
        //  einem anderen Geraet kam, landete am neuen Ort, den niemand las.
        //  Einfach auf den neuen Ort umzuschalten haette die NEUESTEN
        //  Eintraege durch diesen alten Stand ersetzt. Deshalb gewinnt die
        //  zuletzt geaenderte Datei; die unterlegene bleibt als .bak liegen.]
        bool altUebernehmen = false;
        if (altDa && !zielDa) {
            altUebernehmen = true;
        } else if (altDa && zielDa) {
            const auto tAlt  = fs::last_write_time(altDatei, ec);
            const auto tZiel = fs::last_write_time(zielDatei, ec);
            if (!ec && tAlt > tZiel) altUebernehmen = true;
        }
        if (altUebernehmen) {
            std::error_code e2;
            if (zielDa)
                fs::copy_file(zielDatei, zielDatei + ".bak",
                              fs::copy_options::overwrite_existing, e2);
            fs::copy_file(altDatei, zielDatei, fs::copy_options::overwrite_existing, e2);
            // Die Memos mit -- ohne sie waere ein Eintrag ohne Ton.
            if (fs::exists(C().dir + "/memos", e2))
                fs::copy(C().dir + "/memos", ziel + "/memos",
                    fs::copy_options::recursive | fs::copy_options::overwrite_existing, e2);
            std::fprintf(stderr, "[kalender] aktuellen Stand von %s uebernommen\n",
                         altDatei.c_str());
        }
        // Der alte Ort bleibt unangetastet als Sicherung liegen.
        C().dir  = ziel;
        C().file = zielDatei;   // AB JETZT laden UND speichern hier
    }
    // TIMELINE LADEN -- oder calendar.json einmalig migrieren. [Die
    //  Eintraege leben ab jetzt in timeline.json (Modell, Abgleich,
    //  Startvermerke); calendar.json haelt nur noch den Ansichtszustand.]
    {
        char host[128] = "geraet";
#if !defined(_WIN32)
        gethostname(host, sizeof(host)); host[sizeof(host) - 1] = 0;
#endif
        xbm_tl::Laden(C().dir, host, xbm_tl::LokaleZeitzone());
    }
    LoadNow();
    // ALARME BEIM START ANMELDEN.
    // [Nach einem Neustart des Geraets sind ALLE Alarme weg -- so
    //  arbeitet Android. Hier werden sie aus der geladenen Datei neu
    //  gesetzt; das deckt auch den Fall ab, dass die App laenger nicht
    //  offen war.]
    UiCalendar_AlarmeNeuSetzen();
    if (C().anchor == 0) C().anchor = WeekStart(XbmTime_NowUtc());
    ScheduleReminders();
    std::fprintf(stderr, "[kalender] %zu Eintraege aus %s\n",
                 C().entries.size(), C().file.c_str());
}

// ---------------------------------------------------------------------------
// WIEDERHOLUNGEN UND ERINNERUNGEN
// ---------------------------------------------------------------------------
std::int64_t UiCalendar_NaechsterTermin(const CalEntry& e, std::int64_t ab) {
    if (e.wdh == CalWiederholung::Nie)
        return (e.start >= ab) ? e.start : 0;
    if (e.wdhBis > 0 && ab > e.wdhBis) return 0;
    const std::int32_t jede = e.wdhJede > 0 ? e.wdhJede : 1;

    std::int64_t t = e.start;
    // [Rueckwaerts denken waere schneller, aber Monate und Jahre haben
    //  keine feste Laenge -- also vorwaerts zaehlen, mit einer harten
    //  Obergrenze, damit eine kaputte Angabe nicht zur Endlosschleife
    //  wird. 4000 Schritte reichen fuer ueber zehn Jahre taeglich.]
    for (int i = 0; i < 4000 && t < ab; ++i) {
        switch (e.wdh) {
            case CalWiederholung::Taeglich:
                t += (std::int64_t)86400 * jede; break;
            case CalWiederholung::Wochentags: {
                do { t += 86400; } while (([&]{
                    std::time_t tt = (std::time_t)t; std::tm lt{};
                    #if defined(_WIN32)
                        localtime_s(&lt, &tt);
                    #else
                        localtime_r(&tt, &lt);
                    #endif
                    return lt.tm_wday == 0 || lt.tm_wday == 6;   // So/Sa
                })());
                break;
            }
            case CalWiederholung::Woechentlich:
                t += (std::int64_t)604800 * jede; break;
            case CalWiederholung::Monatlich:
            case CalWiederholung::Jaehrlich: {
                std::time_t tt = (std::time_t)t; std::tm lt{};
                #if defined(_WIN32)
                    localtime_s(&lt, &tt);
                #else
                    localtime_r(&tt, &lt);
                #endif
                if (e.wdh == CalWiederholung::Monatlich) lt.tm_mon += jede;
                else                                     lt.tm_year += jede;
                lt.tm_isdst = -1;
                std::time_t nt = std::mktime(&lt);
                if (nt == (std::time_t)-1) return 0;
                t = (std::int64_t)nt;
                break;
            }
            default: return 0;
        }
        if (e.wdhBis > 0 && t > e.wdhBis) return 0;
    }
    return (t >= ab) ? t : 0;
}

std::vector<std::uint32_t>& UiCalendar_Palette() {
    static std::vector<std::uint32_t> p = {
        0xFF4FC3F7, 0xFF81C784, 0xFFFFD54F, 0xFFFF8A65,
        0xFFBA68C8, 0xFF4DB6AC, 0xFFE57373, 0xFF90A4AE
    };
    return p;
}

void UiCalendar_PaletteMerken(std::uint32_t farbe) {
    auto& p = UiCalendar_Palette();
    for (auto f : p) if (f == farbe) return;       // schon drin
    p.push_back(farbe);
    if (p.size() > 24) p.erase(p.begin());         // nicht unbegrenzt wachsen
}

std::uint64_t UiCalendar_ActionNeu(std::uint64_t eventId, CalActionArt art,
                                   std::int64_t start, std::int32_t durMin) {
    for (auto& e : C().entries) {
        if (e.id != eventId) continue;
        CalAction a;
        a.id = C().nextId++;
        a.art = art; a.start = start; a.durMin = durMin;
        e.actions.push_back(a);
        C().dirty = true;
        return a.id;
    }
    return 0;
}

void UiCalendar_ActionLoeschen(std::uint64_t eventId, std::uint64_t actionId) {
    for (auto& e : C().entries) {
        if (e.id != eventId) continue;
        for (size_t i = 0; i < e.actions.size(); ++i)
            if (e.actions[i].id == actionId) {
                XbmAlarm_Loeschen(actionId);       // auch beim System weg
                e.actions.erase(e.actions.begin() + (long)i);
                C().dirty = true;
                return;
            }
    }
}

CalAction* UiCalendar_ActionFinden(std::uint64_t eventId, std::uint64_t actionId) {
    for (auto& e : C().entries) {
        if (e.id != eventId) continue;
        for (auto& a : e.actions) if (a.id == actionId) return &a;
    }
    return nullptr;
}

// AENDERUNGEN VON AUSSEN (Netz-Abgleich) UEBERNEHMEN, OHNE DEN
// AKTUELLEN BLICK ZU VERLIEREN.
// [LoadNow() liest auch Ansicht/Zoom/Auswahl aus derselben Datei --
//  sinnvoll beim App-Start, aber NICHT waehrend man schon offen im
//  Kalender sitzt: ein von einem anderen Geraet eintreffender Abgleich
//  wuerde sonst mitten in der Bedienung die Ansicht verspringen lassen.
//  Deshalb hier: neu laden, aber Ansicht/Zoom/Auswahl SICHERN und
//  danach wiederherstellen -- nur die EINTRAEGE selbst kommen aus der
//  frischen Datei.]
void ReloadEntriesOnly() {
    const CalView       altView     = C().view;
    const int           altNDays    = C().nDays;
    const std::int64_t  altSlotSel  = C().slotSel;
    const std::int64_t  altAnchor   = C().anchor;
    const float         altPph      = C().pxPerHour;
    const std::uint64_t altSelected = C().selected;
    const std::uint64_t altEditing  = C().editing;

    LoadNow();

    C().view = altView; C().nDays = altNDays; C().slotSel = altSlotSel;
    C().anchor = altAnchor; C().pxPerHour = altPph;
    // Auswahl nur behalten, wenn der Eintrag nach dem Neuladen noch da
    // ist -- sonst haette er evtl. auf einem anderen Geraet geloescht
    // worden sein koennen.
    C().selected = UiCalendar_Find(altSelected) ? altSelected : 0;
    C().editing  = UiCalendar_Find(altEditing)  ? altEditing  : 0;
}

std::int64_t DateiZeitSekunden(const std::string& pfad) {
    std::error_code ec;
    auto tp = std::filesystem::last_write_time(pfad, ec);
    if (ec) return 0;
    return (std::int64_t)std::chrono::duration_cast<std::chrono::seconds>(
        tp.time_since_epoch()).count();
}

// EINMAL JE FRAME AUFGERUFEN (gedrosselt): erkennt, wenn die
// Kalenderdatei sich VON AUSSEN geaendert hat -- typischerweise, weil
// der Netz-Abgleich gerade eine neuere Fassung von einem anderen
// Geraet hereingeholt hat -- und laedt dann automatisch neu.
// [Das war der eigentliche Grund fuer "Kalenderdaten werden beim
//  Abgleich nicht abgeglichen" UND "man muss neu einlesen, um aktuelle
//  Daten zu sehen": die DATEI wurde vom Abgleich durchaus aktualisiert,
//  aber die schon laufende App hatte sie nur EIN EINZIGES Mal beim
//  Start gelesen und danach nie wieder nachgesehen. Der Abgleich
//  selbst hat also funktioniert -- er kam nur nie im Bild an.]
void UiCalendar_PollExterneAenderung() {
    const double jetzt = ImGui::GetTime();
    if (jetzt - C().letzterExternCheck < 1.0) return;   // hoechstens 1x/Sek. nachsehen
    C().letzterExternCheck = jetzt;

    const std::int64_t z = DateiZeitSekunden(C().file);
    if (z == 0) return;                        // Datei (noch) nicht da
    if (C().externeDateiZeit == 0) { C().externeDateiZeit = z; return; }  // erster Blick
    if (z == C().externeDateiZeit) return;      // unveraendert
    C().externeDateiZeit = z;

    // WAEHREND MAN GERADE SELBST MITTEN IN EINER AENDERUNG IST, NICHT
    // NEU LADEN -- sonst gingen ungespeicherte Eingaben verloren. Der
    // naechste Blick in einer Sekunde holt es nach.
    if (C().dirty || C().drag.active || C().penZugAktiv) return;

    ReloadEntriesOnly();
    UiCalendar_AlarmeNeuSetzen();   // von aussen geaenderte Erinnerungen
                                    // muessen beim System neu ankommen
}

static std::uint64_t VirtId(std::uint64_t base, std::int64_t occStart);
void UiCalendar_AlarmeNeuSetzen() {
    // [Alle alten Anmeldungen loeschen und neu setzen. Einzeln zu
    //  verfolgen, was sich geaendert hat, waere fehleranfaellig -- und
    //  der AlarmManager nimmt ein Neusetzen unter derselben Kennung
    //  ohnehin als Ersetzen.]
    const std::int64_t jetzt = (std::int64_t)std::time(nullptr);
    for (const auto& e : C().entries) {
        XbmAlarm_Loeschen(e.id);
        // JEDE Action einzeln anmelden -- jede hat ihre eigene Kennung,
        // damit sich mehrere Erinnerungen am selben Event nicht
        // gegenseitig ersetzen.
        for (const auto& a : e.actions) {
            XbmAlarm_Loeschen(a.id);
            if (!a.aktiv || a.getan) continue;
            if (a.art != CalActionArt::Alarm && a.art != CalActionArt::Ton)
                continue;                          // andere Arten: spaeter
            std::int64_t weck = a.start;
            if (e.wdh != CalWiederholung::Nie) {
                // Bei Wiederholung liegt die Action relativ zum Termin.
                std::int64_t versatz = a.start - e.start;
                std::int64_t t = UiCalendar_NaechsterTermin(e, jetzt - versatz);
                if (t <= 0) continue;
                weck = t + versatz;
            }
            if (weck <= jetzt) continue;
            std::string ton = a.ton;
            if (ton.empty() && !e.memos.empty() && !e.memos[0].audio.empty())
                ton = UiCalendar_DataDir() + "/memos/" + e.memos[0].audio;
            else if (!ton.empty())
                ton = UiCalendar_DataDir() + "/memos/" + ton;
            std::string txt = !a.text.empty() ? a.text
                            : (e.title.empty() ? std::string("Erinnerung") : e.title);
            XbmAlarm_Planen(a.id, weck, txt, ton);
        }
    }
    // ERINNERUNGEN IN DER TIEFE (Unter-Termin einer Gruppe mit eigener
    // Erinnerung, Erinnerung an einer Erinnerung ...): die kennt nur das
    // Modell. Alle Vorkommen der naechsten 30 Tage, Art Benachrichtigung,
    // Elternteil nicht die Wurzel -> Wecker. [Bisher wurden nur die
    //  Aktionszeilen erster Ebene geplant; tiefere Erinnerungen feuerten nie.]
    if (xbm_tl::Geladen()) {
        const timeline::Speicher& sp = xbm_tl::Speicher();
        static std::vector<std::uint64_t> tiefeIds; for (std::uint64_t id : tiefeIds) XbmAlarm_Loeschen(id); tiefeIds.clear();
        for (const timeline::Vorkommen& v : timeline::vorkommen(sp, jetzt, jetzt + 30 * 86400, xbm_tl::LokaleZeitzone())) {
            const timeline::Event* k = sp.finde(v.event);
            if (!k || !k->eltern) continue;
            if (!k->zusatz.empty()) { nlohmann::json z = nlohmann::json::parse(k->zusatz, nullptr, false); if (z.is_object() && !z.value("aktiv", true)) continue; }
            std::string txt = timeline::wTitel(sp, *k); if (txt.empty()) { const timeline::Event* el = sp.finde(k->eltern); txt = el ? timeline::wTitel(sp, *el) : "Erinnerung"; }
            // a) Erinnerungs-Events ab Ebene 2 (Ebene 1 sind die Aktionszeilen, oben geplant)
            if (k->art == timeline::Art::Benachrichtigung && k->eltern != v.serie && v.start > jetzt) {
                const std::uint64_t id = VirtId(k->id, v.start);
                XbmAlarm_Planen(id, v.start, txt, ""); tiefeIds.push_back(id);
            }
            // b) "Erinnerung ... min vorher" eines Unter-Termins (Feld im Unter-Termin-Editor)
            if (k->art == timeline::Art::Normal && k->erinnernMin.gesetzt && k->erinnernMin.wert >= 0) {
                const std::int64_t weck = v.start - (std::int64_t)k->erinnernMin.wert * 60;
                if (weck > jetzt) { const std::uint64_t id = VirtId(k->id, v.start) ^ 0x5a5a5a5aULL; XbmAlarm_Planen(id, weck, txt, ""); tiefeIds.push_back(id); }
            }
        }
    }
}


void UiCalendar_Save() {
    SaveNow();
    // [Nach jedem Speichern neu anmelden: eine geaenderte Zeit oder eine
    //  abgeschaltete Erinnerung muss beim System ankommen, nicht nur in
    //  der Datei.]
    UiCalendar_AlarmeNeuSetzen();
    // UND: so schnell wie moeglich an andere Geraete weiterreichen,
    // statt bis zu 3 Sekunden auf den naechsten automatischen Blick des
    // Netz-Abgleichs zu warten. [Bleibt der Zeiger null (Netzwerk nicht
    //  gestartet), passiert einfach nichts -- harmlos.]
    if (UiCalendar_NetzAbgleichJetzt) UiCalendar_NetzAbgleichJetzt();
}
void UiCalendar_Edit(std::uint64_t id) {
    C().editing  = id;
    if (id) C().selected = id;
}
// AUS TIMELINE NEU LADEN -- nach einem Abgleich ueber das Netz. [Eigene,
//  noch nicht gespeicherte Aenderungen werden ZUERST uebernommen (sonst
//  ueberschriebe die Projektion sie); danach zeigt die Oberflaeche den
//  zusammengefuehrten Stand. Auswahl und Bearbeitung bleiben, wenn es die
//  Eintraege noch gibt.]
void UiCalendar_TimelineNeuLaden() {
    if (!xbm_tl::Geladen()) return;
    if (C().dirty) xbm_tl::Uebernehmen(C().entries, XbmTime_NowUtc());
    C().entries = xbm_tl::Projizieren();
    for (const CalEntry& e : C().entries) { if (e.id >= C().nextId) C().nextId = e.id + 1;
        for (const CalAction& a : e.actions) if (a.id >= C().nextId) C().nextId = a.id + 1; }
    // Unter-Termin im Editor: seine Kennung ist eine Modell-Id, kein Eintrag --
    // nicht wegraeumen, solange es ihn im Modell gibt. [Sonst schloss sich der
    //  Unter-Termin-Editor nach jeder eigenen Aenderung.]
    if (C().editingKind) {
        if (!xbm_tl::Speicher().finde(C().editingKind)) { C().editingKind = 0; C().editing = 0; C().selected = 0; }
    } else {
        if (C().selected && !UiCalendar_Find(C().selected)) C().selected = 0;
        if (C().editing  && !UiCalendar_Find(C().editing))  C().editing  = 0;
    }
    C().dirty = false;
    ScheduleReminders();
    UiCalendar_AlarmeNeuSetzen();
}

void UiCalendar_Shutdown() { if (C().dirty) SaveNow(); }
std::string UiCalendar_DataDir() { return C().dir; }

void UiCalendar_SaveIfDirty() {
    if (!C().dirty) return;
    // Sammelschreiben: waehrend eines Ziehens aendert sich der Eintrag in
    // JEDEM Frame -- ohne diese Bremse schriebe die App 60 Dateien je
    // Sekunde. Zwei Sekunden Ruhe genuegen.
    const double now = ImGui::GetTime();
    if (now - C().lastSave < 2.0) return;
    C().lastSave = now;
    SaveNow();
    if (UiCalendar_NetzAbgleichJetzt) UiCalendar_NetzAbgleichJetzt();
}

std::vector<CalEntry>& UiCalendar_All() { return C().entries; }

static const std::uint64_t kVirtBit = 1ULL << 63;
static bool IstVirtuell(std::uint64_t id) { return (id & kVirtBit) != 0; }
static const CalState::VirtOcc* VirtOccFuer(std::uint64_t vid) {
    for (const auto& v : C().vmap) if (v.vid == vid) return &v;
    return nullptr;
}
// Kennung eines Vorkommens: Serien-Id und Startzeit, stabil ueber Frames.
static std::uint64_t VirtId(std::uint64_t base, std::int64_t occStart) {
    std::uint64_t h = base * 0x9E3779B97F4A7C15ULL ^ (std::uint64_t)occStart * 0xC2B2AE3D27D4EB4FULL;
    h ^= h >> 29; return h | kVirtBit;
}
CalEntry* UiCalendar_Find(std::uint64_t id) {
    if (IstVirtuell(id)) {
        if (C().editKopieAktiv && C().editKopie.id == id) return &C().editKopie;
        for (auto& e : C().vork) if (e.id == id) return &e;
        return nullptr;
    }
    for (auto& e : C().entries) if (e.id == id) return &e;
    return nullptr;
}
// EDITOR OEFFNEN. Bei einem Vorkommen auf einer Kopie -- siehe SerienFrage.
static void EditorOeffnen(std::uint64_t id) {
    // EINGEFAHRENER EDITOR bleibt zu: der erste Tipp waehlt den Termin nur aus,
    // ein zweiter Tipp auf denselben Termin faehrt den Editor wieder aus.
    if (C().editorEingefahren) {
        const bool schonGewaehlt = (C().selected == id) && (C().editing == id || C().editing == 0);
        if (!schonGewaehlt) { C().selected = id; C().editing = id; if (IstVirtuell(id)) { if (const CalState::VirtOcc* vo = VirtOccFuer(id)) if (vo->kind) C().editingKind = vo->kindId; } return; }
        C().editorEingefahren = false;
    }
    if (IstVirtuell(id)) {
        if (const CalState::VirtOcc* vo = VirtOccFuer(id)) if (vo->kind) { C().editing = id; C().selected = id; C().editingKind = vo->kindId; return; }   // Unter-Termin: Editor unten
        const CalEntry* v = UiCalendar_Find(id); if (!v) return;
        C().editKopie = *v; C().editOriginal = *v; C().editKopieAktiv = true;
    }
    C().editing = id; C().selected = id;
}
// ---------------------------------------------------------------------------
// VORLAGEN IN NAVI 1. Tippen legt einen Termin aus der Vorlage an -- an der
// gelben Zeitauswahl, sonst zur naechsten vollen Stunde -- und oeffnet ihn.
// "x" loescht die Vorlage; ihre Werte wandern vorher in die Instanzen (R2).
// ---------------------------------------------------------------------------
void UiCalendar_VorlagenNavi() {
    if (!xbm_tl::Geladen()) { ImGui::TextDisabled("Vorlagen: Kalender nicht geladen"); return; }
    ImGui::TextDisabled("Vorlagen");
    std::vector<xbm_tl::VorlageInfo> vs = xbm_tl::Vorlagen();
    if (vs.empty()) { ImGui::TextWrapped("Noch keine. Im Editor eines Termins: \"Als Vorlage ablegen\"."); return; }
    const std::int64_t jetzt = XbmTime_NowUtc();
    for (const xbm_tl::VorlageInfo& v : vs) {
        ImGui::PushID((int)(v.id & 0x7fffffff));
        char lb[160]; std::snprintf(lb, sizeof(lb), "%s  (%d min%s)", v.titel.empty() ? "(ohne Titel)" : v.titel.c_str(), v.durMin, v.kinder ? ", mit Unter-Events" : "");
        if (ImGui::Button(lb, ImVec2(-ImGui::GetFrameHeight() * 3.4f, 0))) {
            std::int64_t start = C().slotSel ? C().slotSel : ((jetzt / 3600) + 1) * 3600;
            const std::uint64_t id = xbm_tl::AusVorlage(v.id, start, jetzt);
            if (id) { xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); xbm_tls::Anstossen(); C().dirty = true; C().selected = id; C().editing = id; UiCalendar_GoTo(start); }
        }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Termin aus dieser Vorlage anlegen (an der gelben Zeitauswahl, sonst naechste volle Stunde) -- oder in den Explorer-Baum ziehen");
        if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)) {
            const std::uint64_t vid = v.id; ImGui::SetDragDropPayload("XBM_VORLAGE", &vid, sizeof(vid));
            ImGui::Text("Vorlage: %s", v.titel.c_str()); ImGui::EndDragDropSource();
        }
        ImGui::SameLine();
        // VORLAGE BEARBEITEN (Stift): Titel, Notizen, Dauer, Farbe im Popup;
        // der Baum der Vorlage ueber den Explorer (Unter-Termine, Jobs ...).
        if (ImGui::SmallButton("/")) ImGui::OpenPopup("##vorlage_edit");
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Vorlage bearbeiten");
        if (ImGui::BeginPopup("##vorlage_edit")) {
            timeline::Event* ve = xbm_tl::Speicher().finde(v.id);
            if (ve) {
                static std::map<std::uint64_t, std::string> tp, np; std::string& t = tp[v.id]; std::string& nz = np[v.id];
                const std::string tm = timeline::wTitel(xbm_tl::Speicher(), *ve), nm = timeline::wNotizen(xbm_tl::Speicher(), *ve);
                if (!ImGui::IsAnyItemActive()) { if (t != tm) t = tm; if (nz != nm) nz = nm; }
                bool ge = false;
                ImGui::SetNextItemWidth(ImGui::GetFontSize() * 14.0f);
                if (ImGui::InputText("Titel", &t) ) { ve->titel = t; ge = true; }
                if (ImGui::InputTextMultiline("Notizen", &nz, ImVec2(ImGui::GetFontSize() * 14.0f, ImGui::GetTextLineHeight() * 3.0f))) { ve->notizen = nz; ge = true; }
                int d = ve->durMin; ImGui::SetNextItemWidth(ImGui::GetFontSize() * 5.0f);
                if (ImGui::InputInt("Dauer (min)", &d, 5, 60)) { if (d > 0) { ve->durMin = d; ge = true; } }
                { bool ad = ve->allDay; if (ImGui::Checkbox("ganztaegig", &ad)) { ve->allDay = ad; ge = true; } }
                ImGui::SameLine();
                { ImVec4 c = ImGui::ColorConvertU32ToFloat4(ve->farbe.gesetzt ? (ImU32)ve->farbe.wert : IM_COL32(120, 160, 220, 255));
                  if (ImGui::ColorEdit3("Farbe", &c.x, ImGuiColorEditFlags_NoInputs)) { ve->farbe = (std::uint32_t)ImGui::ColorConvertFloat4ToU32(c); ge = true; } }
                if (ge) { xbm_tl::Speicher().geaendert(*ve, jetzt); xbm_tl::Speichern(); }
                if (ImGui::Button("Baum der Vorlage")) { C().explorerOffen = true; C().explorerWurzel = v.id; C().explorerSel = v.id; ImGui::CloseCurrentPopup(); }
                if (ImGui::IsItemHovered()) ImGui::SetTooltip("Unter-Termine, Erinnerungen und Jobs der Vorlage im Explorer bearbeiten (Editor unten)");
                ImGui::SameLine(); if (ImGui::Button("Schliessen")) ImGui::CloseCurrentPopup();
            }
            ImGui::EndPopup();
        }
        ImGui::SameLine();
        if (ImGui::SmallButton("x")) { xbm_tl::VorlageLoeschen(v.id, jetzt); xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); xbm_tls::Anstossen(); ImGui::PopID(); break; }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Vorlage loeschen -- bestehende Termine behalten ihre Werte");
        ImGui::PopID();
    }
}
// UNTER-TERMIN FESTSCHREIBEN: Lage (Versatz zum Elternteil) und Dauer aus dem
// Zug ins Modell. Liefert true, wenn es ein Unter-Termin war.
static bool UnterTerminFestschreiben(std::uint64_t vid, std::int64_t start, int durMin) {
    const CalState::VirtOcc* v = VirtOccFuer(vid); if (!v || !v->kind) return false;
    const timeline::Event* k = xbm_tl::Speicher().finde(v->kindId); if (!k) return false;
    const std::int64_t versatz = start - xbm_tl::AbsoluterStart(k->eltern);
    xbm_tl::KindAendern(v->kindId, timeline::wTitel(xbm_tl::Speicher(), *k), versatz, durMin < 5 ? 5 : durMin, XbmTime_NowUtc());
    xbm_tl::Speichern(); xbm_tls::Anstossen();
    return true;
}
static std::uint64_t ModellId(std::uint64_t id);
// ---------------------------------------------------------------------------
// MEHRFACHAUSWAHL, GRUPPEN, DUPLIZIEREN (rechte Leiste, Strg+C/V)
// ---------------------------------------------------------------------------
static std::vector<std::uint64_t> AuswahlModellIds() {
    std::vector<std::uint64_t> ids;
    for (std::uint64_t id : C().penSel) { const std::uint64_t m = ModellId(id); if (m && std::find(ids.begin(), ids.end(), m) == ids.end()) ids.push_back(m); }
    if (C().selected) { const std::uint64_t m = ModellId(C().selected); if (m && std::find(ids.begin(), ids.end(), m) == ids.end()) ids.push_back(m); }
    return ids;
}
int UiCalendar_AuswahlAnzahl() { return (int)AuswahlModellIds().size(); }
bool UiCalendar_GruppeAusgewaehlt() {
    if (!xbm_tl::Geladen() || !C().selected) return false;
    const std::uint64_t m = ModellId(C().selected); if (!m) return false;
    if (xbm_tl::IstGruppe(m)) return true;
    const timeline::Event* e = xbm_tl::Speicher().finde(m); return e && e->eltern && xbm_tl::IstGruppe(e->eltern);
}
void UiCalendar_Gruppieren() {
    if (!xbm_tl::Geladen()) return;
    std::vector<std::uint64_t> ids = AuswahlModellIds(); if (ids.size() < 2) return;
    SaveNow();
    const std::uint64_t g = xbm_tl::GruppeBilden(ids, XbmTime_NowUtc());
    if (!g) return;
    xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); xbm_tls::Anstossen();
    C().penSel.clear(); C().selected = g; C().editing = 0; C().dirty = true; SaveNow();
}
void UiCalendar_Ungruppieren() {
    if (!xbm_tl::Geladen() || !C().selected) return;
    std::uint64_t m = ModellId(C().selected); const timeline::Event* e = xbm_tl::Speicher().finde(m);
    if (e && !xbm_tl::IstGruppe(m) && e->eltern && xbm_tl::IstGruppe(e->eltern)) m = e->eltern;
    if (!xbm_tl::IstGruppe(m)) return;
    SaveNow();
    if (xbm_tl::Ungruppieren(m, XbmTime_NowUtc())) { xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); xbm_tls::Anstossen(); C().selected = 0; C().editing = 0; if (C().gruppeOffen == m) C().gruppeOffen = 0; C().dirty = true; SaveNow(); }
}
// Kopien der Ids ab <ziel>, relative Abstaende bleiben.
static void KopienAnlegen(const std::vector<std::uint64_t>& ids, std::int64_t ziel) {
    if (ids.empty()) return;
    std::int64_t anker = 0; bool erst = true;
    for (std::uint64_t id : ids) { const std::int64_t a = xbm_tl::AbsoluterStart(id); if (erst || a < anker) { anker = a; erst = false; } }
    const std::int64_t jetzt = XbmTime_NowUtc(); std::uint64_t letzte = 0;
    for (std::uint64_t id : ids) { const std::uint64_t n = xbm_tl::Duplizieren(id, ziel + (xbm_tl::AbsoluterStart(id) - anker), jetzt); if (n) letzte = n; }
    xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); xbm_tls::Anstossen();
    if (letzte) C().selected = letzte;
    C().dirty = true; SaveNow();
}
void UiCalendar_Duplizieren() {
    if (!xbm_tl::Geladen()) return;
    std::vector<std::uint64_t> ids = AuswahlModellIds(); if (ids.empty()) return;
    SaveNow();
    std::int64_t anker = xbm_tl::AbsoluterStart(ids[0]); for (std::uint64_t id : ids) anker = std::min(anker, xbm_tl::AbsoluterStart(id));
    KopienAnlegen(ids, C().slotSel ? C().slotSel : XbmTime_AddDays(anker, 1));
}
// Serien-Id hinter einer (evtl. virtuellen) Kennung -- fuer Bearbeiten/Loeschen.
std::uint64_t UiCalendar_BasisId(std::uint64_t id) {
    if (!IstVirtuell(id)) return id;
    const CalState::VirtOcc* v = VirtOccFuer(id); return v ? v->base : 0;
}

std::uint64_t UiCalendar_Add(CalEntry e) {
    // AKTIV-MODUS: neues Event wird UNTEREVENT des aktiven Elternteils --
    // mit Versatz zu dessen (absolutem) Start, so dass es mitwandert.
    if (C().aktivEltern && xbm_tl::Geladen() && xbm_tl::Speicher().finde(C().aktivEltern)) {
        const std::int64_t now = XbmTime_NowUtc();
        const std::int64_t versatz = e.start - xbm_tl::AbsoluterStart(C().aktivEltern);
        const std::uint64_t kid = xbm_tl::KindAnlegen(C().aktivEltern, e.title, versatz, e.durMin, now, /*termin=*/true);
        if (kid) { xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); xbm_tls::Anstossen(); C().dirty = true; return kid; }
    }
    if (e.id == 0) e.id = C().nextId++;
    if (e.id >= C().nextId) C().nextId = e.id + 1;
    const std::int64_t now = XbmTime_NowUtc();
    if (!e.created)  e.created = now;
    e.modified = now;
    const std::uint64_t id = e.id;   // VOR dem move sichern
    C().entries.push_back(std::move(e));
    // Nach Startzeit sortiert halten: alle Ansichten iterieren linear und
    // profitieren davon, und der Editor zeigt eine stabile Reihenfolge.
    std::sort(C().entries.begin(), C().entries.end(),
              [](const CalEntry& a, const CalEntry& b) { return a.start < b.start; });
    C().dirty = true;
    return id;
}

bool UiCalendar_Remove(std::uint64_t id) {
    // Ein Vorkommen loeschen: nur diesen / ab hier / ganze Serie -- fragen.
    if (IstVirtuell(id)) {
        const CalState::VirtOcc* v = VirtOccFuer(id); if (!v) return false;
        if (v->kind) return false;              // Unter-Event-Block: im Editor des Wurzeltermins loeschen
        C().serienFrage = {}; C().serienFrage.offen = true; C().serienFrage.art = 2;
        C().serienFrage.base = v->base; C().serienFrage.occStart = v->occStart;
        return true;
    }
    for (auto it = C().entries.begin(); it != C().entries.end(); ++it) {
        if (it->id == id) {
            C().entries.erase(it);
            C().dirty = true;
            if (C().selected == id) C().selected = 0;
            if (C().editing  == id) C().editing  = 0;
            return true;
        }
    }
    return false;
}

void UiCalendar_Touch(std::uint64_t id) {
    if (CalEntry* e = UiCalendar_Find(id)) {
        e->modified = XbmTime_NowUtc();
        C().dirty = true;
    }
}

// EVENT-START AENDERN UND NICHT-STATISCHE ERINNERUNGEN MITZIEHEN.
// [Wie gewuenscht: Erinnerungen wandern standardmaessig RELATIV zum
//  Event mit -- derselbe Abstand bleibt erhalten. Nur wenn eine
//  Erinnerung explizit als "statisch" markiert ist, bleibt sie an ihrer
//  Uhrzeit stehen. Gilt fuer echtes VERSCHIEBEN (Koerper-Zug, Start-
//  Griff) -- eine reine Dauer-Aenderung ueber den Ende-Griff ruehrt die
//  Erinnerungen nicht an, da sich dabei der Start gar nicht bewegt.]
void UiCalendar_EventStartSetzen(CalEntry& e, std::int64_t neuerStart) {
    const std::int64_t delta = neuerStart - e.start;
    e.start = neuerStart;
    if (delta == 0) return;
    for (auto& a : e.actions) {
        if (a.statisch) continue;
        a.start += delta;
    }
}

// Ist ein Unterevent im Raster zu zeigen? (Regel des Elternteils UND des Kindes)
static bool KindSichtbar(std::uint64_t kindId, std::uint64_t wurzel) {
    const timeline::Event* k = xbm_tl::Speicher().finde(kindId); if (!k) return false;
    const bool aktivImStamm      = C().aktivEltern && xbm_tl::IstNachfahre(C().aktivEltern, wurzel);
    const bool bearbeitetImStamm = C().editing && UiCalendar_BasisId(C().editing) == wurzel;
    const bool ausgewaehlt       = C().selected && UiCalendar_BasisId(C().selected) == wurzel;
    const int ks = xbm_tl::KinderSicht(k->eltern), ss = xbm_tl::Sicht(kindId);
    const bool eltern = ks == 0 || (ks == 1 && (ausgewaehlt || aktivImStamm || bearbeitetImStamm)) || (ks == 2 && (aktivImStamm || bearbeitetImStamm));
    const bool kind   = ss == 0 || (ss == 1 && (ausgewaehlt || aktivImStamm || bearbeitetImStamm)) || (ss == 2 && (aktivImStamm || bearbeitetImStamm));
    return eltern && kind;
}
static std::uint64_t ModellId(std::uint64_t id);
// DECKKRAFT: 1.0 ausgewaehlt (oder Gruppe des Ausgewaehlten samt Mitgliedern),
// 0.8 gleicher Baum, 0.6 alle anderen.
static float DeckkraftStufe(std::uint64_t id) {
    if (!C().selected) return 0.6f;
    if (id == C().selected) return 1.0f;
    const std::uint64_t sel = ModellId(C().selected), mich = ModellId(id);
    if (!sel || !mich) return 0.6f;
    if (sel == mich) return 1.0f;
    if (!xbm_tl::Geladen()) return 0.6f;
    const timeline::Event* se = xbm_tl::Speicher().finde(sel); const timeline::Event* me = xbm_tl::Speicher().finde(mich);
    if (!se || !me) return 0.6f;
    std::uint64_t gruppe = 0;                                     // Gruppe des Ausgewaehlten (Container oder Mitglied)
    if (xbm_tl::IstGruppe(sel)) gruppe = sel; else if (se->eltern && xbm_tl::IstGruppe(se->eltern)) gruppe = se->eltern;
    if (gruppe && (mich == gruppe || me->eltern == gruppe)) return 1.0f;
    if (xbm_tl::Wurzel(sel) == xbm_tl::Wurzel(mich)) return 0.8f;
    return 0.6f;
}
// SCHRAFFUR: leichte schraege Striche (45 Grad, 6 px Abstand) in einem Rechteck.
static void Schraffur(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 farbe) {
    if (b.x <= a.x || b.y <= a.y) return;
    dl->PushClipRect(a, b, true);
    const float h = b.y - a.y, schritt = 6.0f;
    for (float x = a.x - h; x < b.x; x += schritt) dl->AddLine(ImVec2(x, b.y), ImVec2(x + h, a.y), farbe, 1.0f);
    dl->PopClipRect();
}
// Welches Modell-Event steckt hinter einer Kennung (Unterevent-Block: das Kind)?
static std::uint64_t ModellId(std::uint64_t id) {
    if (!IstVirtuell(id)) return id;
    const CalState::VirtOcc* v = VirtOccFuer(id); if (!v) return 0;
    return v->kind ? v->kindId : v->base;
}
std::vector<CalEntry*> UiCalendar_Range(std::int64_t from, std::int64_t to) {
    std::vector<CalEntry*> out;
    for (auto& e : C().entries) {
        if (e.wdh != CalWiederholung::Nie && xbm_tl::Geladen()) continue;   // kommt als Vorkommen
        if (e.end() > from && e.start < to) out.push_back(&e);
    }
    // SERIEN ALS VORKOMMEN. [Zugposition: waehrend ein virtuelles Vorkommen
    //  gezogen wird, wuerde es hier jeden Frame an seinen Platz
    //  zurueckspringen -- deshalb uebernimmt es die Zugposition.]
    C().vork.clear(); C().vmap.clear();
    if (!xbm_tl::Geladen()) return out;
    const timeline::Speicher& sp = xbm_tl::Speicher();
    // Fenster um die Laenge des laengsten Eintrags erweitern, damit Mehrtages-Termine am Rand erscheinen
    std::int64_t vorlauf = 0; for (const auto& e : C().entries) if (e.wdh != CalWiederholung::Nie) vorlauf = std::max<std::int64_t>(vorlauf, (std::int64_t)e.durMin * 60);
    std::vector<timeline::Vorkommen> vs = timeline::vorkommen(sp, from - vorlauf, to, xbm_tl::LokaleZeitzone());
    C().vork.reserve(vs.size());
    for (const timeline::Vorkommen& v : vs) {
        // TIEFE UNTER-EVENTS (ab Ebene 2) ALS EIGENE BLOECKE. [Ebene 1 sind
        //  die Aktionen und werden am Termin gezeichnet; alles darunter
        //  kennt nur das Modell. Hier: kleiner Block mit Titel des Kindes,
        //  Farbe des Wurzeltermins; Tippen oeffnet den Wurzeltermin,
        //  Ziehen ist (noch) ohne Wirkung.]
        if (v.event != v.serie) {
            const timeline::Event* k = sp.finde(v.event);
            if (!k || !k->eltern) continue;
            if (k->eltern == v.serie && k->art != timeline::Art::Normal) continue;   // Ebene-1-Erinnerung: steckt im Termin
            const CalEntry* wurzel = nullptr;
            for (const auto& e : C().entries) if (e.id == v.serie) { wurzel = &e; break; }
            if (!wurzel) continue;
            CalEntry kk; kk.id = VirtId(v.event, v.start); kk.start = v.start; kk.durMin = k->durMin > 0 ? k->durMin : 15;
            // MITBEWEGEN WAEHREND DES ZUGS: der Wurzeltermin wird in der
            // Oberflaeche verschoben (CalEntry), das Modell erst beim Loslassen
            // geschrieben -- die Kinder folgen hier sofort dem Unterschied.
            if (const timeline::Event* wurzelEv = sp.finde(v.serie)) {
                if (v.ursprungStart == wurzelEv->start) kk.start += wurzel->start - wurzelEv->start;                       // Basis-Vorkommen
                else if (C().drag.id == VirtId(v.serie, v.ursprungStart)) kk.start += C().dragVirtStart - v.ursprungStart; // gezogenes Serien-Vorkommen
            }
            if (C().drag.id == kk.id) { kk.start = C().dragVirtStart; if (C().dragVirtDur > 0) kk.durMin = C().dragVirtDur; }   // waehrend eines Zugs
            kk.title = timeline::wTitel(sp, *k); if (kk.title.empty()) kk.title = "Unter-Event";
            kk.color = k->farbe.gesetzt ? (ImU32)k->farbe.wert : wurzel->color; kk.remindOn = false; kk.source = "unter-event";
            if (xbm_tl::IstGruppe(k->eltern)) {   // Mitglied einer Gruppe: Abstufung derselben Farbe
                int rang = 0; for (const timeline::Event* g : sp.kinder(k->eltern)) if (g->versatz < k->versatz) ++rang;
                kk.color = Darken(wurzel->color ? wurzel->color : EntryColor(*wurzel), 0.65f + 0.12f * (float)(rang % 4));
                kk.source = "gruppe-mitglied";
            }
            if (kk.end() <= from || kk.start >= to) continue;
            if (!KindSichtbar(v.event, wurzel->id)) continue;
            C().vmap.push_back({ kk.id, wurzel->id, v.start, true, v.event });
            C().vork.push_back(std::move(kk));
            continue;
        }
        const CalEntry* base = nullptr;
        for (const auto& e : C().entries) if (e.id == v.serie && e.wdh != CalWiederholung::Nie) { base = &e; break; }
        if (!base) continue;                     // Einzeltermine sind schon oben drin
        CalEntry k = *base;
        k.id = VirtId(base->id, v.start);
        if (C().editKopieAktiv && C().editKopie.id == k.id) {   // wird gerade bearbeitet: Kopie zeigen
            C().vmap.push_back({ k.id, base->id, v.start });
            C().vork.push_back(C().editKopie);
            continue;
        }
        const std::int64_t delta = v.start - base->start;
        k.start = (C().drag.id == k.id) ? C().dragVirtStart : v.start;
        if (C().drag.id == k.id && C().dragVirtDur > 0) k.durMin = C().dragVirtDur;
        for (auto& a : k.actions) a.start += (k.start - base->start);
        (void)delta;
        if (k.end() <= from || k.start >= to) continue;
        C().vmap.push_back({ k.id, base->id, v.start });
        C().vork.push_back(std::move(k));
    }
    for (auto& k : C().vork) out.push_back(&k);
    return out;
}

std::uint64_t UiCalendar_QuickAdd(const std::string& title, std::int64_t when,
                                  int durMin, const std::string& source) {
    CalEntry e;
    e.start  = when;
    e.durMin = durMin;
    e.title  = title;
    e.source = source;
    return UiCalendar_Add(std::move(e));
}

void    UiCalendar_SetView(CalView v) { C().view = v; }
CalView UiCalendar_GetView()          { return C().view; }

// ANKER AENDERN. [War kurzzeitig mit einem Gleit-Uebergang versehen --
//  wieder entfernt, wie gewuenscht: der Uebergang loeste ungewollt
//  auch bei Goto und der Datumsauswahl unten (DrawDateNav) aus, nicht
//  nur beim eigentlichen Blaettern. Wieder die einfache, direkte
//  Zuweisung wie zuvor.]
void KalenderAnchorSetzen(std::int64_t neuerAnchor) {
    C().anchor = neuerAnchor;
    C().dirty = true;
}

void UiCalendar_GoTo(std::int64_t utc) {
    std::int64_t neu;
    switch (C().view) {
        case CalView::Week:  neu = WeekStart(utc); break;
        case CalView::Month: neu = XbmTime_LocalMidnight(utc); break;
        case CalView::Year:  neu = XbmTime_LocalMidnight(utc); break;
        default:             neu = XbmTime_LocalMidnight(utc); break;
    }
    KalenderAnchorSetzen(neu);
}
void UiCalendar_GoToday() { UiCalendar_GoTo(XbmTime_NowUtc()); }

void UiCalendar_SetReminderHandler(std::function<void(const CalEntry&)> fn) {
    C().onRemind = std::move(fn);
    ScheduleReminders();
}

// ---------------------------------------------------------------------------
// Sprachmemo
// ---------------------------------------------------------------------------
bool UiCalendar_MemoActive() { return C().memoActive; }

// Wird in UiCalendar_Draw() gesetzt. Absichtlich der Stand des LETZTEN
// Frames: die Knopfleiste wird typischerweise vor dem Kalender gezeichnet
// und braucht die Antwort, bevor der Kalender dieses Frames existiert.
bool UiCalendar_IsVisible() { return C().wasVisible; }

// --- Einfaches Event (ohne Memo) --------------------------------------
std::uint64_t UiCalendar_QuickAdd() {
    // GLEICHES MUSTER WIE BEIM MEMO (UiCalendar_MemoBegin): an der
    // gelben Auswahl, sonst zur aktuellen Sekunde. So verhaelt sich der
    // Knopf "Notiz+" genau wie der Mikrofon-Knopf, nur ohne Aufnahme.
    CalEntry e;
    e.start = C().slotSel ? C().slotSel : XbmTime_NowUtc();
    e.title = "";
    e.notes = "";
    const std::uint64_t id = UiCalendar_Add(std::move(e));
    // KEIN UiCalendar_GoTo() MEHR HIER. [Sprang bisher IMMER zur Uhrzeit
    //  des neuen Eintrags -- "das soll kein Feature sein", wie du
    //  gesagt hast. Wer per Tastaturschlag anlegt, schaut sich meist
    //  ohnehin schon den richtigen Ausschnitt an oder hat die Uhrzeit
    //  vorher bewusst per gelber Auswahl gesetzt.]
    UiCalendar_Edit(id);          // Editor sofort oeffnen, wie gewuenscht
    C().selected = id;
    return id;
}

// --- Gelbe Zeitauswahl --------------------------------------------------
void UiCalendar_ClearSelectedTime() {
    C().slotSel = 0;
    C().dirty = true;             // Zustand aendert sich, soll gemerkt werden
}
bool UiCalendar_HasSelectedTime() { return C().slotSel != 0; }

// --- Tastatur-Sofortanlage ------------------------------------------------
// [Ein Tastendruck IM Kalender, wenn KEIN Editor offen ist, legt sofort
//  einen Eintrag an und schickt das Zeichen weiter ins Titelfeld. Ohne
//  diese Weiche haette das erste Zeichen der Absicht ("ich will jetzt
//  schreiben") nirgendwo hingekonnt.]
// Setzt den Cursor ans Textende und hebt jede Markierung auf.
// [Wird als ImGuiInputTextFlags_CallbackAlways eingehaengt. ImGui
//  markiert beim Fokus-Gewinn ueber die Tastatur den ganzen Inhalt; das
//  laesst sich von aussen nur ueber diesen Rueckruf wieder geradeziehen,
//  weil er als EINZIGER Zugriff auf CursorPos/SelectionStart/-End im
//  laufenden Zustand des Feldes hat.]
static int XbmCursorAnsEnde(ImGuiInputTextCallbackData* d) {
    d->CursorPos      = d->BufTextLen;
    d->SelectionStart = d->CursorPos;
    d->SelectionEnd   = d->CursorPos;
    return 0;
}

// Einen Unicode-Codepunkt als UTF-8 an eine Zeichenkette anhaengen.
// [Eigene kleine Fassung statt ImGuis interner Helfer -- die sind nicht
//  oeffentlich, und mehr als das hier wird nicht gebraucht.]
static void XbmUtf8Anhaengen(std::string& ziel, unsigned int cp) {
    if (cp < 0x80) {
        ziel += (char)cp;
    } else if (cp < 0x800) {
        ziel += (char)(0xC0 | (cp >> 6));
        ziel += (char)(0x80 | (cp & 0x3F));
    } else if (cp < 0x10000) {
        ziel += (char)(0xE0 | (cp >> 12));
        ziel += (char)(0x80 | ((cp >> 6) & 0x3F));
        ziel += (char)(0x80 | (cp & 0x3F));
    } else {
        ziel += (char)(0xF0 | (cp >> 18));
        ziel += (char)(0x80 | ((cp >> 12) & 0x3F));
        ziel += (char)(0x80 | ((cp >> 6) & 0x3F));
        ziel += (char)(0x80 | (cp & 0x3F));
    }
}

// Ein weiteres Zeichen desselben Frames nachtragen (siehe Aufrufer).
void UiCalendar_AppendPendingChar(unsigned int codepoint) {
    if (codepoint < 0x20 || codepoint == 0x7f) return;
    XbmUtf8Anhaengen(C().pendingFirstText, codepoint);
}

bool UiCalendar_TypeToCreate(unsigned int codepoint) {
    if (C().editing) return false;               // schon ein Editor offen
    // Steuerzeichen/Nichtdruckbares nicht als Anlass nehmen -- sonst
    // legt z.B. ein Pfeiltastendruck ungewollt einen Eintrag an.
    if (codepoint < 0x20 || codepoint == 0x7f) return false;
    std::uint64_t id = UiCalendar_QuickAdd();
    if (!id) return false;
    // DAS ZEICHEN MUSS GEMERKT WERDEN -- die Warteschlange traegt es
    // NICHT bis zum Titelfeld.
    // [Der vorherige Versuch liess das Zeichen absichtlich in
    //  io.InputQueueCharacters stehen, in der Annahme, das frisch
    //  fokussierte InputText werde es "ganz normal" selbst verarbeiten.
    //  Das kann zeitlich nicht aufgehen:
    //    Frame N   -- das Zeichen steht in der Warteschlange, das Event
    //                 wird angelegt, und das Titelfeld ruft
    //                 SetKeyboardFocusHere() auf. Der Fokus wird damit
    //                 aber erst ZUM NAECHSTEN Frame wirksam; in Frame N
    //                 ist das Feld noch nicht aktiv und liest die
    //                 Warteschlange gar nicht.
    //    Frame N+1 -- ImGui hat die Warteschlange inzwischen geleert.
    //                 Das Feld ist jetzt aktiv, aber das Zeichen ist weg.
    //  Genau das ist der "verschluckte erste Buchstabe". Deshalb wird es
    //  hier gemerkt und beim Oeffnen des Editors direkt in den Puffer
    //  geschrieben.]
    C().pendingFirstChar    = codepoint;
    C().pendingFirstText.clear();
    XbmUtf8Anhaengen(C().pendingFirstText, codepoint);
    C().pendingFirstCharFor = id;
    return true;
}

// --- Stiftwerkzeug / Bulk-Edit ------------------------------------------
void UiCalendar_PapierkorbNavi() {
    if (!xbm_tl::Geladen()) { ImGui::TextDisabled("(kein Modell)"); return; }
    std::vector<xbm_tl::PapierkorbEintrag> pk = xbm_tl::Papierkorb();
    if (pk.empty()) { ImGui::TextDisabled("leer"); return; }
    const std::int64_t jetzt = XbmTime_NowUtc(); bool ge = false;
    for (const auto& e : pk) {
        ImGui::PushID((int)(e.id & 0x7fffffff));
        char lb[160]; std::snprintf(lb, sizeof(lb), "%s  (%s)", e.titel.empty() ? "(ohne Titel)" : e.titel.c_str(), XbmTime_Format(e.start, "%d.%m.").c_str());
        if (ImGui::SmallButton("<")) { if (xbm_tl::Wiederherstellen(e.id, jetzt)) ge = true; }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Wiederherstellen (samt Unter-Terminen)");
        ImGui::SameLine(); ImGui::TextUnformatted(lb);
        ImGui::PopID();
    }
    ImGui::Separator();
    if (ImGui::SmallButton("Papierkorb leeren")) { xbm_tl::PapierkorbLeeren(jetzt); ge = true; }
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Endgueltig -- die Termine lassen sich danach nicht mehr wiederherstellen");
    if (ge) { xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); xbm_tls::Anstossen(); }
}
void UiCalendar_SofortVerschiebenSet(bool an) { C().sofortVerschieben = an; }
bool UiCalendar_SofortVerschieben() { return C().sofortVerschieben; }
void UiCalendar_EraserSet(bool aktiv) { C().eraserActive = aktiv; if (aktiv) { C().penActive = false; C().penSel.clear(); } }
bool UiCalendar_EraserActive() { return C().eraserActive; }
void UiCalendar_PenToolSet(bool aktiv) {
    C().penActive = aktiv;
    if (!aktiv) C().penSel.clear();
}
bool UiCalendar_PenToolActive() { return C().penActive; }

void UiCalendar_PenToggle(std::uint64_t id) {
    if (!id) return;
    auto it = C().penSel.find(id);
    if (it != C().penSel.end()) C().penSel.erase(it);
    else                        C().penSel.insert(id);
}
bool UiCalendar_PenIsSelected(std::uint64_t id) {
    return C().penSel.find(id) != C().penSel.end();
}
int UiCalendar_PenSelectedCount() { return (int)C().penSel.size(); }

void UiCalendar_PenShiftSelected(std::int64_t deltaSekunden) {
    if (deltaSekunden == 0) return;
    for (auto id : C().penSel) {
        CalEntry* e = UiCalendar_Find(id);
        if (!e) continue;
        e->start += deltaSekunden;
        UiCalendar_Touch(id);
    }
    SaveNow();
}

void UiCalendar_PenDeleteSelected() {
    // In eine Liste kopieren -- UiCalendar_Remove aendert C().entries
    // waehrend des Laufs, direkt aus der Menge zu loeschen waere ein
    // Iterator-auf-veraendertem-Container-Fehler.
    std::vector<std::uint64_t> ids(C().penSel.begin(), C().penSel.end());
    for (auto id : ids) UiCalendar_Remove(id);
    C().penSel.clear();
}

void UiCalendar_PenClearSelection(bool auchDeaktivieren) {
    C().penSel.clear();
    if (auchDeaktivieren) C().penActive = false;
}

void UiCalendar_MemoBegin() {
    if (C().memoActive) return;
    // Zeitstempel SOFORT festhalten -- der Eintrag gehoert an den Moment des
    // Knopfdrucks, nicht an den des Loslassens.
    C().memoStart = C().slotSel ? C().slotSel : XbmTime_NowUtc();
    if (!XbmAudio_RecordStart()) {
        C().memoStatus = std::string("Aufnahme nicht moeglich: ")
                       + XbmAudio_LastError();
        return;
    }
    C().memoActive = true;
    C().memoStatus = "Aufnahme laeuft...";
}

std::uint64_t UiCalendar_MemoEnd() {
    if (!C().memoActive) return 0;
    C().memoActive = false;
    XbmClip clip = XbmAudio_RecordStop();
    if (clip.empty()) { C().memoStatus = "nichts aufgenommen"; return 0; }

    // MESSEN, NICHT VERWERFEN.
    // [Hier wurde die Aufnahme frueher weggeworfen, wenn eine feste
    //  Pegelschwelle nicht erreicht war -- der Grund, warum Sprachmemos
    //  auf allen drei Plattformen "nicht funktionierten". Ein leises Memo
    //  ist immer noch ein Memo. Der Eintrag entsteht jetzt IMMER; die
    //  Messwerte landen in der Statuszeile, damit man "Mikrofon liefert
    //  nichts" von "leise, aber da" unterscheiden kann.]
    const XbmClipStats st = XbmAudio_Analyse(clip);
    XbmAudio_TrimSilence(clip);
    const bool speech = XbmAudio_HasSpeech(clip);

    char pegel[128];
    std::snprintf(pegel, sizeof(pegel),
                  "Spitze %.3f, Rauschen %.4f, Stimme %d ms",
                  (double)st.peak, (double)st.noiseFloor, st.voicedMs);
    if (st.peak < 1.0e-3f) {
        // Praktisch Nulllinie: das Geraet hat nichts geliefert. Das ist
        // kein Erkennungsproblem, sondern Rechte/Geraet/Stummschaltung.
        C().memoStatus = std::string("Mikrofon liefert kein Signal (")
                       + pegel + ") -- Berechtigung, Geraet oder stumm?";
    } else if (!speech) {
        C().memoStatus = std::string("aufgenommen, keine Sprache erkannt (")
                       + pegel + ")";
    } else {
        C().memoStatus = std::string("aufgenommen (") + pegel + ")";
    }

    CalEntry e;
    e.start  = C().memoStart;
    e.durMin = (std::int32_t)std::max(5.0, std::ceil(clip.seconds() / 60.0) * 5.0);
    e.title  = "Memo " + XbmTime_Format(e.start, "%H:%M");
    e.source = "memo";
    // KEIN ZUSTANDSTEXT IN DIE NOTIZ.
    // [Hier stand fest "(wird transkribiert...)" bzw.
    //  "(Transkription nicht einkompiliert)". Das ist der GEMERKTE
    //  Zustand vom Aufnahmezeitpunkt: ein Memo, das ohne whisper entstand,
    //  trug den Satz fuer immer weiter -- auch nachdem whisper laengst
    //  einkompiliert war. Und beim Transkribieren wurde er ueberschrieben,
    //  also war es nie eine echte Notiz. Das Feld gehoert dem Nutzer; der
    //  Zustand gehoert in die Statuszeile.]
    e.notes.clear();

    char fname[128];
    std::snprintf(fname, sizeof(fname), "memo_%lld_%llu.wav",
                  (long long)e.start, (unsigned long long)C().nextId);
    e.audio = fname;
    XbmAudio_WriteWav(JoinPath(JoinPath(C().dir, "memos"), fname), clip);

    const std::uint64_t id = UiCalendar_Add(std::move(e));
    C().memoEntry = id;
    C().selected  = id;
    C().editing   = id;
    SaveNow();

    if (XbmStt_Compiled()) {
        C().memoStatus = "Transkription laeuft...";
        XbmStt_Submit(std::move(clip), [id](std::string text, bool ok) {
            // Laeuft im UI-Thread (XbmSched_PostUi) -- Zugriff auf den
            // Vektor ist hier gefahrlos.
            CalEntry* p = UiCalendar_Find(id);
            if (!p) return;
            if (ok && !text.empty()) {
                p->notes = text;
                // Erste Zeile als Titel: macht die Wochenansicht lesbar.
                std::string t = text.substr(0, text.find('\n'));
                if (t.size() > 48) t = t.substr(0, 45) + "...";
                if (!t.empty()) p->title = t;
                C().memoStatus = "Transkript uebernommen";
            } else {
                p->notes = std::string("(Transkription fehlgeschlagen: ")
                         + XbmStt_Status() + ")";
                C().memoStatus = "Transkription fehlgeschlagen";
            }
            // Puffer der offenen Bearbeitung nachziehen, sonst ueberschreibt
            // der alte Inhalt das frische Transkript beim naechsten Tippen.
            if (C().bufFor == id) { C().bufTitle = p->title; C().bufNotes = p->notes; }
            std::printf("[stt] 7 in die Notiz geschrieben: %zu Zeichen\n",
                        p->notes.size());
            std::fflush(stdout);
            C().dirty = true;
        });
    } else {
        std::printf("[stt] ABBRUCH: nicht einkompiliert -- kein Submit\n");
        std::fflush(stdout);
        // GRUND nennen, nicht nur die Tatsache.
        C().memoStatus = std::string("gespeichert, aber nicht transkribiert: ")
                       + XbmStt_Status();
    }
    return id;
}

// ===========================================================================
// ZEICHNEN
// ===========================================================================
namespace {

constexpr float kMinPph = 10.0f;    // Jahres-artig gestaucht
constexpr float kMaxPph = 260.0f;   // Minutenraster gut treffbar
constexpr double kHoldSec = 0.30;   // Halte-Schwelle fuer Drag&Drop
constexpr float kHoldSlop = 12.0f;  // Wackeln waehrend des Haltens erlaubt

void Claim() { if (UiCalendar_ClaimGesture) UiCalendar_ClaimGesture(); }

// Rastermass fuer das Verschieben: fein zoomen -> fein rasten.
int SnapMinutes() {
    const float p = C().pxPerHour;
    if (p >= 140.0f) return 5;
    if (p >= 70.0f)  return 10;
    if (p >= 34.0f)  return 15;
    return 30;
}

std::int64_t SnapTime(std::int64_t t) {
    const int step = SnapMinutes() * 60;
    const std::int64_t mid = XbmTime_LocalMidnight(t);
    std::int64_t off = t - mid;
    off = ((off + step / 2) / step) * step;
    return mid + off;
}

// Wie viele Finger sind gerade unten? (0 auf dem Schreibtisch mit Maus
// zaehlt als "hoechstens 1" -- die Maus liefert dort keine Touch-Punkte.)
int FingerCount() {
    if (!UiCalendar_GetTouches) return ImGui::GetIO().MouseDown[0] ? 1 : 0;
    float xy[8];
    return UiCalendar_GetTouches(xy, 4);
}

// Pinch-Abstand aus den Beruehrpunkten. Liefert <0, wenn kein Pinch laeuft.
float PinchDistance() {
    if (!UiCalendar_GetTouches) return -1.0f;
    float xy[8];
    const int n = UiCalendar_GetTouches(xy, 4);
    if (n < 2) return -1.0f;
    const float dx = xy[2] - xy[0], dy = xy[3] - xy[1];
    // NUR UEBERWIEGEND SENKRECHT -- sonst wuerde ein WAAGERECHTER Pinch
    // (der jetzt den Ansichtswechsel bedient, siehe PinchHorizontal)
    // gleichzeitig auch noch die Stundenhoehe verstellen. Beide Gesten
    // teilen sich dieselben zwei Finger; die Richtung entscheidet, wem
    // sie gehoeren.
    if (fabsf(dx) > fabsf(dy) * 1.0f) return -1.0f;
    return std::sqrt(dx * dx + dy * dy);
}

// Mitte (Y) der zwei Finger -- fuer das Zwei-Finger-Scrollen waehrend
// des senkrechten Pinch. Nur sinnvoll aufgerufen, wenn PinchDistance()
// bereits > 0 war (also mindestens zwei, ueberwiegend senkrecht
// gehaltene Finger vorliegen).
float PinchMidY() {
    if (!UiCalendar_GetTouches) return -1.0f;
    float xy[8];
    const int n = UiCalendar_GetTouches(xy, 4);
    if (n < 2) return -1.0f;
    return (xy[1] + xy[3]) * 0.5f;
}

// Fingerabstand OHNE Winkelpruefung -- fuer eine Geste, deren Besitzer
// beim Aufsetzen bereits feststeht. [PinchDistance() lehnt alles ueber
// 45 Grad ab; das ist nur fuer die ERSTE Entscheidung richtig. Liefe der
// laufende Stundenzoom weiter ueber PinchDistance(), fiele er beim
// kleinsten Verkippen der Hand aus -- und in genau diesem Moment konnte
// der waagerechte Ansichtswechsel die Geste uebernehmen. Die Geste
// wechselte mitten in der Bewegung den Besitzer.]
float PinchRohDistanz() {
    if (!UiCalendar_GetTouches) return -1.0f;
    float xy[8];
    const int n = UiCalendar_GetTouches(xy, 4);
    if (n < 2) return -1.0f;
    const float dx = xy[2] - xy[0], dy = xy[3] - xy[1];
    return std::sqrt(dx * dx + dy * dy);
}

// WAAGERECHTER Pinch -- fuer den Ansichtswechsel (Tag <-> Jahr).
// [Liefert nur dann eine Distanz, wenn die zwei Finger UEBERWIEGEND
//  nebeneinander liegen (|dx| deutlich groesser als |dy|) -- sonst
//  wuerde ein normaler, senkrecht ausgerichteter Zwei-Finger-Zoom (der
//  bestehende Stunden-Zoom) sofort auch den Ansichtswechsel ausloesen.
//  Beide Gesten sollen nebeneinander funktionieren, nicht gegeneinander.]
float PinchHorizontal() {
    if (!UiCalendar_GetTouches) return -1.0f;
    float xy[8];
    const int n = UiCalendar_GetTouches(xy, 4);
    if (n < 2) return -1.0f;
    const float dx = xy[2] - xy[0], dy = xy[3] - xy[1];
    if (fabsf(dy) > fabsf(dx) * 1.0f) return -1.0f;   // zu schraeg/senkrecht
    return fabsf(dx);
}

// ---------------------------------------------------------------------------
// DAS ANSICHTSBAND -- JETZT DURCHGEHEND: 1 Tag .. 15 Tage -- Monat -- Jahr.
// [Tag (T) und Woche (W) als EIGENE Ansichten sind entfernt -- die 1-n-
//  Tage-Ansicht deckt beide Faelle ab (1 Tag = fruehere Tagesansicht,
//  7 Tage = fruehere Wochenansicht), nur mit frei waehlbarer Anzahl.
//  Eine einzige POSITION 1..17 fasst jetzt beides zusammen: 1..15 sind
//  die Tagesanzahl der n-Tage-Ansicht, 16 ist Monat, 17 ist Jahr. Damit
//  navigiert EIN Pinch ohne Bruch von 1 Tag bis zur Jahresuebersicht --
//  "man muss mit einer Pinch-Bewegung immer ueber alle Ansichten
//  navigieren koennen, egal wo man sich gerade befindet".
//  Auswaerts pinchen (Finger gehen auseinander) verringert die Position
//  -- weniger Tage, bis hin zu 1. Einwaerts pinchen erhoeht sie -- mehr
//  Tage, dann Monat, dann Jahr.]
// ---------------------------------------------------------------------------
constexpr int kAnsichtMin = 1;    // 1 Tag
constexpr int kAnsichtMonat = 16;
constexpr int kAnsichtJahr  = 17;

int AnsichtsPosition() {
    switch (C().view) {
        case CalView::Month: return kAnsichtMonat;
        case CalView::Year:  return kAnsichtJahr;
        default: {
            // Day/ThreeDay/Week (Week nur noch als Altlast aus alten
            // Speicherstaenden moeglich) -- alle ueber ihre Tagesanzahl.
            int n = (C().view == CalView::Week) ? 7
                  : (C().view == CalView::Day)  ? 1
                  : C().nDays;
            if (n < 1) n = 1;
            if (n > 15) n = 15;
            return n;
        }
    }
}

void AnsichtPositionSetzen(int pos) {
    if (pos < kAnsichtMin) pos = kAnsichtMin;
    if (pos > kAnsichtJahr) pos = kAnsichtJahr;
    if (pos == kAnsichtMonat) {
        C().view = CalView::Month;
    } else if (pos == kAnsichtJahr) {
        C().view = CalView::Year;
    } else {
        C().view  = CalView::ThreeDay;
        C().nDays = pos;
    }
}

// EINEN SCHRITT im Ansichtsband. richtung > 0 = einwaerts (mehr Tage,
// dann Monat, dann Jahr), richtung < 0 = auswaerts (weniger Tage, bis
// hin zu 1). Anker und Auswahl wandern mit, damit man nach dem Wechsel
// noch denselben Tag vor sich hat.
void AnsichtSchritt(int richtung) {
    int pos = AnsichtsPosition() + (richtung > 0 ? 1 : -1);
    if (pos < kAnsichtMin) pos = kAnsichtMin;
    if (pos > kAnsichtJahr) pos = kAnsichtJahr;
    const CalView altView = C().view;
    const int altNDays = C().nDays;
    AnsichtPositionSetzen(pos);
    if (C().view == altView && C().nDays == altNDays) return;
    // Der bisher angeschaute Tag soll sichtbar bleiben -- derselbe
    // Ausdruck wie NaviDatum() (die Funktion steht erst weiter unten,
    // daher hier direkt): gelber Marker, sonst der Anker.
    UiCalendar_GoTo(C().slotSel ? C().slotSel : C().anchor);
    C().dirty = true;
}

// Waagerechten Ansichts-Pinch auswerten. Ein SCHRITT je ueberschrittener
// Schwelle -- nicht kontinuierlich, denn das Ansichtsband hat nur fuenf
// diskrete Stufen. Zieht man weiter, ohne loszulassen, wird die Schwelle
// nach jedem Schritt neu ab der AKTUELLEN Distanz gemessen, sodass ein
// langer Zug mehrere Stufen hintereinander schalten kann.
void PinchAnsichtswechselFrame() {
    // NEU: Winkel entscheidet nur EINMALIG beim Aufsetzen, ob dieser
    // Pinch ueberhaupt dem Ansichtswechsel gehoert (nicht dem
    // Stundenzoom). Danach bleibt es dabei, bis die Finger loslassen --
    // AUCH wenn sich der Winkel waehrend der Bewegung etwas verschiebt.
    // [Das war die eigentliche Ursache fuer "reagiert fast nie, springt
    //  dann ploetzlich": vorher wurde bei JEDER kleinen Winkelschwankung
    //  (PinchHorizontal() faellt schon bei knapp ueber 45 Grad auf -1
    //  zurueck) die GESAMTE Verfolgung samt Ausgangsdistanz verworfen.
    //  Kaum eine echte Zugbewegung ist perfekt winkeltreu -- die Folge
    //  war, dass sich kaum je genug Bewegung ohne Unterbrechung
    //  ansammelte, um die 35%-Schwelle zu erreichen. Sammelte sich dann
    //  doch mal genug an (nach einer laengeren stoerungsfreien Strecke),
    //  war die Differenz zur (oft laengst veralteten) Ausgangsdistanz
    //  ploetzlich riesig -- das ergab den Eindruck eines ploetzlichen
    //  Sprungs ueber mehrere Stufen.]
    if (!UiCalendar_GetTouches) { C().pinchHActive = false; return; }
    float xy[8];
    const int n = UiCalendar_GetTouches(xy, 4);
    if (n < 2) { C().pinchHActive = false; return; }
    // WAEHREND der Stundenzoom (senkrecht) schon laeuft, NICHT
    // gleichzeitig auch noch den Ansichtswechsel fuer dieselben zwei
    // Finger armen -- sonst koennten beide Gesten um dieselbe Bewegung
    // konkurrieren.
    if (C().pinching) { C().pinchHActive = false; return; }
    const float dx = xy[2] - xy[0], dy = xy[3] - xy[1];
    const float dist = std::sqrt(dx * dx + dy * dy);

    if (!C().pinchHActive) {
        C().pinchNDays0 = (float)AnsichtsPosition();
        // IN MONAT UND JAHR GEHOERT JEDER PINCH DEM ANSICHTSWECHSEL.
        // [Dort gibt es kein Stundenraster und damit keinen senkrechten
        //  Stundenzoom, der den Pinch fuer sich beanspruchen koennte. Die
        //  Winkelpruefung lehnte trotzdem jeden steilen Pinch ab -- auf
        //  einem hochkant gehaltenen Handy pinchen die meisten aber
        //  senkrecht oder schraeg, und dann geschah schlicht NICHTS. Aus
        //  Monat oder Jahr kam man per Pinch praktisch nicht mehr heraus.
        //  Nur wo es den Stundenzoom WIRKLICH gibt, trennt der Winkel die
        //  beiden Gesten.]
        const bool ohneStundenraster =
            (C().view == CalView::Month || C().view == CalView::Year);
        if (!ohneStundenraster && fabsf(dy) > fabsf(dx))
            return;   // Ausgangslage zu steil -- gehoert dem Stundenzoom
        C().pinchHActive = true;
        C().pinchHDist0  = dist;
        Claim();
        return;
    }
    Claim();
    if (C().pinchHDist0 < 1.0f) { C().pinchHDist0 = dist; return; }
    const float verhaeltnis = dist / C().pinchHDist0;
    // IN DEN TAGESANSICHTEN KONTINUIERLICH, wie der n-Tage-Knopf: Finger
    // auseinander = weniger Tage, zusammen = mehr -- die Tageszahl folgt dem
    // Abstandsverhaeltnis, 1 bis 15, OHNE in Monat oder Jahr zu springen.
    if (C().view != CalView::Month && C().view != CalView::Year) {
        // Linear im Logarithmus des Abstandsverhaeltnisses: jede Verdopplung
        // des Fingerabstands = 5 Tage weniger, jede Halbierung = 5 Tage mehr.
        // [Tage0 / Verhaeltnis war unbrauchbar: von 3 auf 15 Tage haette der
        //  Abstand auf ein Fuenftel schrumpfen muessen.]
        int n = (int)std::lround(C().pinchNDays0 - 5.0f * std::log2(verhaeltnis));
        if (n < 1) n = 1;
        if (n > 15) n = 15;
        if (n != C().nDays || C().view != CalView::ThreeDay) {
            const std::int64_t halt = C().slotSel ? C().slotSel : C().anchor;
            C().view = CalView::ThreeDay; C().nDays = n; C().dirty = true;
            UiCalendar_GoTo(halt);
        }
        return;
    }
    // 8% je Schritt. [Mit 35% waren 16 Stufen (1 Tag bis Jahr) 1,35^16 = 120-
    //  fache Distanz -- unerreichbar; praktisch kam man nie weiter als ein,
    //  zwei Stufen. Mit 8% reicht eine Verdreifachung des Fingerabstands fuer
    //  das ganze Band, und kleine Bewegungen schalten trotzdem einzeln.]
    const float kSchwelle = 1.08f;
    // RICHTUNG: auswaerts (Finger gehen auseinander) verringert die
    // Position -- weniger Tage, bis hin zu 1. Einwaerts (zusammen)
    // erhoeht sie -- mehr Tage, dann Monat, dann Jahr. Eine einzige
    // durchgehende Bewegung deckt damit ALLE Ansichten ab, ohne Bruch.
    if (verhaeltnis > kSchwelle) {
        AnsichtSchritt(-1);            // auseinander -> weniger Tage
        C().pinchHDist0 = dist;        // ab hier neu messen
    } else if (verhaeltnis < 1.0f / kSchwelle) {
        AnsichtSchritt(+1);            // zusammen -> mehr Tage/Monat/Jahr
        C().pinchHDist0 = dist;
    }
}

// Zoom um einen Ankerpunkt: die Uhrzeit unter dem Finger/Zeiger bleibt
// stehen. Ohne das "rutscht" beim Zoomen der ganze Tag weg und man verliert
// sofort die Orientierung.
// [gridH: die gerade verfuegbare Hoehe des Rasters. Die UNTERGRENZE fuer
//  pxPerHour ist NICHT mehr fest (kMinPph allein) -- 24 Stunden duerfen
//  nie KLEINER sein als der sichtbare Platz, sonst bliebe unten oder
//  oben eine leere, nicht zugehoerige Flaeche stehen. Nach OBEN (mehr
//  hineinzoomen) bleibt weiterhin nur kMaxPph als Grenze.]
void ZoomAround(float newPph, float anchorScreenY, float gridTopY, float gridH) {
    const float minPph = ImMax(kMinPph, gridH / 24.0f);
    newPph = ImClamp(newPph, minPph, kMaxPph);
    const float oldPph = C().pxPerHour;
    if (newPph == oldPph) return;
    const float scroll = ImGui::GetScrollY();
    const float hourAt = (scroll + (anchorScreenY - gridTopY)) / oldPph;
    C().pxPerHour = newPph;
    float ns = hourAt * newPph - (anchorScreenY - gridTopY);
    if (ns < 0) ns = 0;
    ImGui::SetScrollY(ns);
}

// ---------------------------------------------------------------------------
// Werkzeugleiste
// ---------------------------------------------------------------------------
// Bezugsdatum der Navigationsleiste: der ausgewaehlte Tag (gelber Marker),
// sonst der Anker der Ansicht.
std::int64_t NaviDatum() {
    return C().slotSel ? C().slotSel : C().anchor;
}
// Bezugsdatum setzen: Anker UND Marker mitziehen, damit Ansicht und
// Auswahl nicht auseinanderlaufen.
void SetzeNaviDatum(std::int64_t t) {
    // NICHT MEHR C().slotSel aendern. [Bisher wurde die gelbe Auswahl bei
    //  JEDEM Blaettern (Pinpoint, Wischen) auf den neuen Tag verschoben
    //  -- das sollte kein Feature sein, wie du gesagt hast. Sie bleibt
    //  jetzt genau dort stehen, wo sie zuletzt bewusst gesetzt wurde,
    //  auch wenn dieser Tag gerade nicht mehr sichtbar ist. Nur die
    //  ANSICHT wandert.]
    UiCalendar_GoTo(t);
    C().dirty = true;
}

// ---------------------------------------------------------------------------
// PINPOINT-NAVIGATIONSZEILE (unten im Kalender)
//
// [Die Zeile ist in VIER gleich breite Startfelder geteilt. Wo der
//  Finger AUFSETZT, bestimmt die Schrittweite -- nicht wohin er wandert.
//  Das ist der Kniff: man muss nicht erst eine Ansicht wechseln, um
//  monatsweise zu blaettern.
//
//      Feld 1  wie die aktuelle Ansicht
//              Tag / 1-5 Tage -> tageweise, W -> wochenweise,
//              M -> monatsweise, J -> jahresweise
//      Feld 2  immer tageweise
//      Feld 3  immer monatsweise
//      Feld 4  immer jahresweise
//
//  Die Geschwindigkeit kommt aus der AUSLENKUNG, wie beim Pinpoint
//  ueberall in der App: weit gezogen = schnell, kurz = langsam. Die
//  Schritte kommen zeitgesteuert, nicht je Frame -- sonst haengt die
//  Geschwindigkeit an der Bildrate.]
// ---------------------------------------------------------------------------
namespace {

enum class NaviSchritt { Tag, Woche, Monat, Jahr };

const char* SchrittName(NaviSchritt s) {
    switch (s) {
        case NaviSchritt::Tag:   return "Tag";
        case NaviSchritt::Woche: return "Woche";
        case NaviSchritt::Monat: return "Monat";
        default:                 return "Jahr";
    }
}

std::int64_t SchrittAnwenden(std::int64_t t, NaviSchritt s, int n) {
    switch (s) {
        case NaviSchritt::Tag:   return XbmTime_AddDays(t, n);
        case NaviSchritt::Woche: return XbmTime_AddDays(t, n * 7);
        case NaviSchritt::Monat: return XbmTime_AddMonths(t, n);
        default:                 return XbmTime_AddMonths(t, n * 12);
    }
}

// Feld 1 folgt der Ansicht.
NaviSchritt SchrittDerAnsicht() {
    switch (C().view) {
        case CalView::Day:
        case CalView::ThreeDay: return NaviSchritt::Tag;
        case CalView::Week:     return NaviSchritt::Woche;
        case CalView::Month:    return NaviSchritt::Monat;
        default:                return NaviSchritt::Jahr;
    }
}

// ---------------------------------------------------------------------------
// KANTEN-NAVIGATION IM KALENDERRASTER.
//
// [Zwei Vorgaben aus den Globalen Einstellungen, UiScrollPinpoint():
//   false ("scrollen/wischen")
//     Ein Finger, der WAAGERECHT ueber den Kalender wischt, blaettert
//     die AKTIVE ANSICHT komplett weiter (eine Woche, ein Monat, ...) --
//     wie ein Buch umblaettern. Senkrechtes Wischen bleibt normales
//     Scrollen (Stunden), das ruehrt diese Funktion nicht an.
//   true ("pinpoint")
//     Ein Antippen der LINKEN oder RECHTEN Kante des Kalenders
//     blaettert sofort eine ganze Seite in diese Richtung -- dieselbe
//     Regel wie beim Ein-Tipp-scrollt-die-Seite-Pinpoint ueberall in
//     der App, nur hier auf den Kalenderinhalt bezogen.
// Ein Bildlauf pro Wisch/Tipp: erst wenn der Finger komplett losgelassen
// und neu aufgesetzt wird, kann der naechste ausgeloest werden.]
// ---------------------------------------------------------------------------
void NavKanteFrame(float breite, float hoehe, ImVec2 fensterPos) {
    ImGuiIO& io = ImGui::GetIO();
    const bool down = io.MouseDown[ImGuiMouseButton_Left];
    // Klick INNERHALB des Kalenderinhalts? [Direkt per Rechteck geprueft,
    //  NICHT mehr ueber ImGui::IsWindowHovered() von aussen. Das war
    //  vermutlich der Grund, warum Scrollen/Pinpoint nach links/rechts
    //  "schlicht nicht moeglich" war: IsWindowHovered() liefert ohne das
    //  Flag AllowWhenBlockedByActiveItem false, sobald IRGENDEIN Widget
    //  gerade die Maus haelt -- und genau WAEHREND des eigenen Zugs (das
    //  Kalenderraster faengt den Druck ja selbst fuer sein senkrechtes
    //  Scrollen ab) war das staendig der Fall. Die Kanten-Navigation
    //  bekam den Druck dadurch nie zu Gesicht. Jetzt wird nur noch beim
    //  AUFSETZEN direkt gegen das Fensterrechteck geprueft -- das ist
    //  unabhaengig davon, was sonst gerade als "aktiv" gilt.]
    const bool klickImFenster = io.MousePos.x >= fensterPos.x
                             && io.MousePos.x <= fensterPos.x + breite
                             && io.MousePos.y >= fensterPos.y
                             && io.MousePos.y <= fensterPos.y + hoehe;

    // Vorgabe "wischen" (false), wenn nichts verdrahtet ist.
    // WAEHREND EIN TERMIN, GRIFF, BALKEN ODER FELD GEZOGEN WIRD, navigiert
    // der Pinpoint NICHT -- das uebernehmen die Randzonen der Ansicht.
    if (C().drag.id != 0 || C().barDrag.id != 0 || C().nZugAktiv || C().zlAktiv || C().pinching || C().pinchHActive) {
        C().navPinArmed = false; C().navPinAchse = 0; C().pinScrollV = 0.0f; return;
    }
    const bool pinpoint = UiCalendar_ScrollPinpoint && UiCalendar_ScrollPinpoint();
    if (pinpoint) {
        // --- PINPOINT: VON DER GANZEN FREIEN FLAECHE AUS, NICHT MEHR NUR
        //     VOM RAND. -------------------------------------------------
        // [Vorher musste der Zug INNERHALB einer schmalen Randzone
        //  beginnen (24 px bzw. 8% der Breite) -- das war umstaendlich
        //  und leicht zu verfehlen. Jetzt zaehlt JEDER Aufsetzpunkt auf
        //  der freien Flaeche; die RICHTUNG ergibt sich aus der ersten
        //  Zugbewegung (nach RECHTS = vorwaerts, nach LINKS = rueckwaerts
        //  -- wie beim Blaettern eines Buchs nach vorn), und die
        //  Geschwindigkeit steigt mit der Auslenkung genau wie zuvor --
        //  nur "beschleunigt" (kuerzere Taktabstaende), weil man ja
        //  jetzt ueberall aufsetzen kann und nicht erst zum Rand wandern
        //  muss.]
        if (!down) { C().navPinArmed = false; C().navPinAchse = 0; C().pinScrollV = 0.0f; return; }
        if (ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
            const bool inLeiste = io.MousePos.x >= C().leisteRect0.x && io.MousePos.x <= C().leisteRect1.x
                               && io.MousePos.y >= C().leisteRect0.y && io.MousePos.y <= C().leisteRect1.y;
            // IM BEARBEITUNGSFENSTER UNTEN (und im Explorer darueber) bewaffnet
            // ein Druck den Pinpoint NICHT -- weder seitlich (Datum) noch
            // senkrecht (Uhrzeit): dort wird bedient, nicht navigiert.
            const bool inEditor = C().editing && io.MousePos.x >= C().editorRect0.x && io.MousePos.x <= C().editorRect1.x
                               && io.MousePos.y >= C().editorRect0.y && io.MousePos.y <= C().editorRect1.y;
            const bool inExplorer = C().explorerOffen && io.MousePos.x >= C().explorerRect0.x && io.MousePos.x <= C().explorerRect1.x
                                 && io.MousePos.y >= C().explorerRect0.y && io.MousePos.y <= C().explorerRect1.y;
            C().navPinArmed = klickImFenster && !inLeiste && !inEditor && !inExplorer;
            C().navPinStartX = io.MousePos.x;
            C().navPinStartY = io.MousePos.y;
            C().navPinAchse = 0; C().pinScrollV = 0.0f;
            C().navPinLetzter = ImGui::GetTime();
        }
        if (!C().navPinArmed) return;
        const float dx = io.MousePos.x - C().navPinStartX;
        const float dy = io.MousePos.y - C().navPinStartY;
        const float tot = 12.0f;
        // ACHSE: beim ersten Ausschlag ueber die Totzone entscheidet die
        // groessere Komponente -- danach bleibt es dabei, bis losgelassen wird.
        if (C().navPinAchse == 0 && (fabsf(dx) > tot || fabsf(dy) > tot))
            C().navPinAchse = (fabsf(dy) > fabsf(dx)) ? 2 : 1;
        if (C().navPinAchse == 2) {
            // SENKRECHT: zu anderen Uhrzeiten -- Geschwindigkeit nach Abstand,
            // wie waagerecht; angewandt wird sie im Raster (pinScrollV).
            // Geschwindigkeit waechst stark mit dem Abstand: nahe 200 px/s,
            // bei zwei Zeichenhoehen Abstand ~1500, weiter draussen bis 4000.
            const float ausV = fabsf(dy);
            float w = (ausV - tot) / 160.0f; if (w < 0.0f) w = 0.0f; if (w > 1.5f) w = 1.5f;
            C().pinScrollV = (ausV > tot ? (dy > 0 ? 1.0f : -1.0f) : 0.0f) * (200.0f + 1700.0f * w * w);
            return;
        }
        const int richtung = (dx > 0.0f) ? 1 : (dx < 0.0f ? -1 : 0);
        const float ausl = fabsf(dx);
        if (richtung != 0 && ausl > tot) {
            const float w = (ausl - tot) / 220.0f;
            const float wv = w > 1.0f ? 1.0f : w;
            // Kuerzere Taktabstaende als vorher (0.55 statt 0.70 Basis) --
            // "beschleunigt", da kein Randweg mehr noetig ist.
            const double abstand = 0.55 - 0.50 * (double)powf(wv, 0.75f);
            const double jetzt = ImGui::GetTime();
            if (jetzt - C().navPinLetzter >= abstand) {
                C().navPinLetzter = jetzt;
                SetzeNaviDatum(SchrittAnwenden(C().anchor, SchrittDerAnsicht(), richtung));
            }
        }
        return;
    }

    // --- SCROLLEN/WISCHEN: eine waagerechte Wischgeste blaettert um. ------
    if (!down) {
        C().navWischArmed = false;
        C().navWischAusgeloest = false;
        return;
    }
    if (ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
        C().navWischArmed = klickImFenster;
        C().navWischAusgeloest = false;
        C().navWischStart = io.MousePos;
        C().navWischStartZeit = ImGui::GetTime();
    }
    if (!C().navWischArmed || C().navWischAusgeloest) return;

    const float dx = io.MousePos.x - C().navWischStart.x;
    const float dy = io.MousePos.y - C().navWischStart.y;
    const float kSchwelle = 46.0f;      // ab hier gilt es als Wisch, nicht Zittern
    // WAAGERECHT MUSS DEUTLICH UEBERWIEGEN, sonst wuerde jedes schraege
    // Scrollen versehentlich auch noch die Seite umblaettern.
    if (fabsf(dx) > kSchwelle && fabsf(dx) > fabsf(dy) * 1.6f) {
        // GESCHWINDIGKEIT DES WISCHES ZAEHLT: ein schneller Flick blaettert
        // mehrere Schritte auf einmal um, ein langsamer Zug nur einen.
        // [Gemessen wird die Zeit von der ersten Beruehrung bis zum
        //  Ueberschreiten der Schwelle -- je kuerzer, desto schneller war
        //  die Bewegung.]
        const double dauer = ImGui::GetTime() - C().navWischStartZeit;
        int schritte = 1;
        if (dauer < 0.08) schritte = 3;
        else if (dauer < 0.18) schritte = 2;
        SetzeNaviDatum(SchrittAnwenden(C().anchor, SchrittDerAnsicht(),
                                       (dx > 0.0f ? -1 : 1) * schritte));
        C().navWischAusgeloest = true;   // erst beim naechsten Aufsetzen wieder
    }
}

void NaviZeileZeichnen() {
    ImGuiIO& io = ImGui::GetIO();
    const float h = ImGui::GetFrameHeight() * 1.25f;
    ImVec2 p0 = ImGui::GetCursorScreenPos();
    const float breite = ImGui::GetContentRegionAvail().x;
    if (breite < 40.0f) return;

    ImGui::InvisibleButton("##navizeile", ImVec2(breite, h));
    const bool ueber = ImGui::IsItemHovered();
    const bool aktiv = ImGui::IsItemActive();

    static bool        laeuft   = false;
    static int         feld     = 0;
    static NaviSchritt schritt  = NaviSchritt::Tag;
    static float       startX   = 0.0f;
    static double      letzter  = 0.0;

    const float feldB = breite * 0.25f;
    if (ueber && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
        feld = (int)((io.MousePos.x - p0.x) / feldB);
        if (feld < 0) feld = 0; if (feld > 3) feld = 3;
        switch (feld) {
            case 0: schritt = SchrittDerAnsicht(); break;
            case 1: schritt = NaviSchritt::Tag;    break;
            case 2: schritt = NaviSchritt::Monat;  break;
            default: schritt = NaviSchritt::Jahr;  break;
        }
        startX  = io.MousePos.x;
        letzter = ImGui::GetTime();
        laeuft  = true;
    }
    if (laeuft && !io.MouseDown[0]) laeuft = false;

    // --- Schritte ausloesen ------------------------------------------------
    if (laeuft && aktiv) {
        const float aus = io.MousePos.x - startX;          // Auslenkung
        const float tot = 12.0f;                            // Ruhezone
        if (fabsf(aus) > tot) {
            // Weit gezogen = kurzer Abstand zwischen den Schritten.
            // [Von 0,45 s bei geringer Auslenkung bis 0,04 s bei 300 px.
            //  Bewusst nicht linear: die ersten Pixel sollen fein
            //  steuerbar bleiben.]
            // [Erst quadratisch versucht -- da blieb es bis 200 px fast
            //  gleich langsam (2,2 -> 3,5 Schritte/s) und sprang dann.
            //  Mit der Wurzel steigt es gleichmaessig: 20 px 2,5/s,
            //  100 px 6/s, 300 px 25/s. Fein steuerbar bleibt es durch
            //  die Ruhezone, nicht durch eine flache Kurve.]
            const float w = (fabsf(aus) - tot) / 260.0f;    // 0 .. ~1
            const float wv = w > 1.0f ? 1.0f : w;
            // [Zwei Versuche vorher: quadratisch blieb bis 200 px zu
            //  langsam und sprang dann; die Wurzel war direkt hinter der
            //  Ruhezone schon bei 5 Schritten/s -- fuer Monatssprünge
            //  unbrauchbar. Diese Kurve beginnt bei 1,4/s (ein Schritt
            //  ist einzeln steuerbar) und erreicht bei 260 px 20/s.]
            const double abstand = 0.70 - 0.65 * (double)powf(wv, 0.75f);
            const double jetzt = ImGui::GetTime();
            if (jetzt - letzter >= abstand) {
                letzter = jetzt;
                SetzeNaviDatum(SchrittAnwenden(C().anchor, schritt,
                                               aus > 0 ? 1 : -1));
            }
        }
    }

    // --- Zeichnen ----------------------------------------------------------
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 p1(p0.x + breite, p0.y + h);
    dl->AddRectFilled(p0, p1, ImGui::GetColorU32(ImGuiCol_FrameBg), 4.0f);
    const char* namen[4] = { "Ansicht", "Tag", "Monat", "Jahr" };
    for (int i = 0; i < 4; ++i) {
        float x0 = p0.x + feldB * i, x1 = x0 + feldB;
        if (i) dl->AddLine(ImVec2(x0, p0.y + 3), ImVec2(x0, p1.y - 3),
                           ImGui::GetColorU32(ImGuiCol_Separator));
        bool dieses = laeuft && feld == i;
        if (dieses)
            dl->AddRectFilled(ImVec2(x0 + 1, p0.y + 1), ImVec2(x1 - 1, p1.y - 1),
                              ImGui::GetColorU32(ImGuiCol_ButtonActive), 3.0f);
        // Feld 1 zeigt, was es gerade bedeutet.
        char txt[32];
        if (i == 0) ImFormatString(txt, sizeof(txt), "%s", SchrittName(SchrittDerAnsicht()));
        else        ImFormatString(txt, sizeof(txt), "%s", namen[i]);
        ImVec2 ts = ImGui::CalcTextSize(txt);
        dl->AddText(ImVec2((x0 + x1) * 0.5f - ts.x * 0.5f,
                           (p0.y + p1.y) * 0.5f - ts.y * 0.5f),
                    ImGui::GetColorU32(dieses ? ImGuiCol_Text : ImGuiCol_TextDisabled),
                    txt);
    }
    // Waehrend des Zugs: Strich vom Aufsetzpunkt zum Finger, wie beim
    // Feinjustieren -- man sieht die Auslenkung, die die Geschwindigkeit
    // macht.
    if (laeuft && aktiv) {
        float y = (p0.y + p1.y) * 0.5f;
        dl->AddLine(ImVec2(startX, y), ImVec2(io.MousePos.x, y),
                    ImGui::GetColorU32(ImGuiCol_SliderGrabActive), 3.0f);
        dl->AddCircleFilled(ImVec2(startX, y), 4.0f,
                            ImGui::GetColorU32(ImGuiCol_SliderGrabActive));
    }
    if (ueber && !laeuft)
        ImGui::SetTooltip("Ziehen: vor und zurueck. Wo du aufsetzt, "
                          "bestimmt die Schrittweite -- weiter ziehen = schneller.");
}

} // namespace

// ---------------------------------------------------------------------------
// DATUMS-NAVIGATION:  < 25 >  < 08 >  < 2026 >
// Pfeile mit Halte-Wiederholung, die Zahl in der Mitte oeffnet eine
// Auswahl. Bezugsgroesse ist der ausgewaehlte Tag.
// ---------------------------------------------------------------------------
void DrawDateNav() {
    const std::int64_t t = NaviDatum();
    const XbmLocalTime l = XbmTime_ToLocal(t);
    const float fh = Einheit();              // Einheitsgroesse (siehe DrawToolbar)
    const ImVec2 pfeil(fh, fh);
    char schild[64];
    std::snprintf(schild, sizeof(schild), "%02d.%02d.%04d",
                  l.day, l.month, l.year);

    struct Feld { const char* id; int wert; int breite; };

    // ---- Tag ----
    ImGui::PushID("tag");
    if (HoldButton("<", schild, pfeil)) SetzeNaviDatum(XbmTime_AddDays(t, -1));
    ImGui::SameLine(0.0f, 2.0f);
    char btag[8]; std::snprintf(btag, sizeof(btag), "%02d", l.day);
    if (ImGui::Button(btag, ImVec2(fh, fh))) ImGui::OpenPopup("##ptag");
    ImGui::SetItemTooltip("Tag waehlen");
    if (ImGui::BeginPopup("##ptag")) {
        // Wie viele Tage hat DIESER Monat?
        static const int md[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
        int maxd = md[l.month - 1];
        if (l.month == 2 && ((l.year % 4 == 0 && l.year % 100 != 0)
                             || l.year % 400 == 0)) maxd = 29;
        for (int d = 1; d <= maxd; ++d) {
            char lb[8]; std::snprintf(lb, sizeof(lb), "%02d", d);
            if (ImGui::Selectable(lb, d == l.day, 0, ImVec2(fh * 1.4f, 0))) {
                SetzeNaviDatum(XbmTime_FromLocal(l.year, l.month, d,
                                                 l.hour, l.minute, 0));
                ImGui::CloseCurrentPopup();
            }
            if (d % 7 != 0 && d < maxd) ImGui::SameLine();
        }
        ImGui::EndPopup();
    }
    ImGui::SameLine(0.0f, 2.0f);
    if (HoldButton(">", schild, pfeil)) SetzeNaviDatum(XbmTime_AddDays(t, 1));
    ImGui::PopID();

    // ---- Monat ----
    ImGui::SameLine(0.0f, 8.0f);
    ImGui::PushID("monat");
    if (HoldButton("<", schild, pfeil)) SetzeNaviDatum(XbmTime_AddMonths(t, -1));
    ImGui::SameLine(0.0f, 2.0f);
    char bmon[8]; std::snprintf(bmon, sizeof(bmon), "%02d", l.month);
    if (ImGui::Button(bmon, ImVec2(fh, fh))) ImGui::OpenPopup("##pmon");
    ImGui::SetItemTooltip("Monat waehlen");
    if (ImGui::BeginPopup("##pmon")) {
        for (int m = 1; m <= 12; ++m) {
            char lb[16]; std::snprintf(lb, sizeof(lb), "%02d %.3s",
                                       m, kMonthName[m - 1]);
            if (ImGui::Selectable(lb, m == l.month)) {
                SetzeNaviDatum(XbmTime_FromLocal(l.year, m, l.day,
                                                 l.hour, l.minute, 0));
                ImGui::CloseCurrentPopup();
            }
        }
        ImGui::EndPopup();
    }
    ImGui::SameLine(0.0f, 2.0f);
    if (HoldButton(">", schild, pfeil)) SetzeNaviDatum(XbmTime_AddMonths(t, 1));
    ImGui::PopID();

    // ---- Jahr ----
    ImGui::SameLine(0.0f, 8.0f);
    ImGui::PushID("jahr");
    if (HoldButton("<", schild, pfeil)) SetzeNaviDatum(XbmTime_AddMonths(t, -12));
    ImGui::SameLine(0.0f, 2.0f);
    char bjahr[8]; std::snprintf(bjahr, sizeof(bjahr), "%04d", l.year);
    if (ImGui::Button(bjahr, ImVec2(fh * 1.6f, fh))) ImGui::OpenPopup("##pjahr");
    ImGui::SetItemTooltip("Jahr waehlen");
    if (ImGui::BeginPopup("##pjahr")) {
        for (int y = l.year - 6; y <= l.year + 6; ++y) {
            char lb[8]; std::snprintf(lb, sizeof(lb), "%04d", y);
            if (ImGui::Selectable(lb, y == l.year)) {
                SetzeNaviDatum(XbmTime_FromLocal(y, l.month, l.day,
                                                 l.hour, l.minute, 0));
                ImGui::CloseCurrentPopup();
            }
        }
        ImGui::EndPopup();
    }
    ImGui::SameLine(0.0f, 2.0f);
    if (HoldButton(">", schild, pfeil)) SetzeNaviDatum(XbmTime_AddMonths(t, 12));
    ImGui::PopID();
    {   // ZEIT X rechtsbuendig, zweite Zeile
        ImGui::SameLine();
        const float breite = ImMax(fh, ImGui::CalcTextSize("Zeit x").x + ImGui::GetStyle().FramePadding.x * 2.0f);
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x - breite);
        ImGui::BeginDisabled(!UiCalendar_HasSelectedTime());
        if (ImGui::Button("Zeit x", ImVec2(breite, fh))) UiCalendar_ClearSelectedTime();
        ImGui::EndDisabled();
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Zeitauswahl (gelber Strich) aufheben -- neue\nEintraege entstehen dann zur aktuellen Sekunde.");
    }
}

// TEXT HINTER DEN T/1-n/W/M/J-KNOEPFEN -- JETZT DER FENSTERTITEL.
// [Stand vorher als TextUnformatted() in der Werkzeugleiste, direkt nach
//  den Ansichts-Knoepfen, OHNE eigenen Zeilenumbruch davor -- die Zeile
//  wurde dadurch auf schmalen Fenstern breiter als der verfuegbare Platz
//  und erzeugte einen waagrechten Bildlauf, der bei jeder Wischgeste die
//  Seite mitzog (genau das Problem, das mehrere Runden zuvor schon beim
//  eigentlichen Bedienhinweis geloest wurde -- diesmal war es das Datum
//  selbst). Jetzt steht der Text im FENSTERTITEL, wo ohnehin Platz ist
//  und wo er sich nicht mit den Knoepfen um dieselbe Zeile streitet.]
std::string AnsichtsCaption() {
    std::string caption;
    const XbmLocalTime a = XbmTime_ToLocal(C().anchor);
    switch (C().view) {
        case CalView::Day:
            caption = std::string(kWeekdayShort[(a.weekday + 6) % 7]) + "., "
                    + std::to_string(a.day) + " "
                    + std::string(kMonthName[a.month - 1]).substr(0, 3) + ".";
            break;
        case CalView::ThreeDay:
        case CalView::Week: {
            const int n = DaysInView(C().view);
            const std::int64_t last = XbmTime_AddDays(C().anchor, n - 1);
            caption = XbmTime_Format(C().anchor, "%d.%m.") + " - "
                    + XbmTime_Format(last, "%d.%m.");
            break;
        }
        case CalView::Month:
            caption = std::string(kMonthName[a.month - 1]) + " " + std::to_string(a.year);
            break;
        case CalView::Year:
            caption = std::to_string(a.year);
            break;
    }
    return caption;
}

void DrawToolbar() {
    // AKTIV-MODUS: keine Textzeile mehr -- der aktive Termin traegt eine
    // dezente Umrandung im Raster, und der Editor zeigt links neben <-> ein
    // "x" in derselben Farbe zum Beenden.
    if (C().aktivEltern && xbm_tl::Geladen() && !xbm_tl::Speicher().finde(C().aktivEltern)) C().aktivEltern = 0;
    // DrawDateNav() (die "< Tag > < Monat > < Jahr >"-Zeile) steht jetzt
    // NICHT mehr hier oben, sondern ganz unten, NACH dem Kalenderinhalt
    // -- siehe UiCalendar_Draw().
    const float fh = ImGui::GetFrameHeight();
    const float E = Einheit();

    // Pfeile: in den Tagesansichten JE EIN TAG (Nutzerwunsch) -- vorher
    // sprang die "3" um drei und die Woche um sieben Tage.
    if (HoldButton("<", XbmTime_Format(NaviDatum(), "%d.%m.%Y").c_str(),
                   ImVec2(E, E))) {
        switch (C().view) {
            case CalView::Day:
            case CalView::ThreeDay:
            case CalView::Week:
                KalenderAnchorSetzen(XbmTime_AddDays(C().anchor, -1)); break;
            case CalView::Month: C().anchor = XbmTime_AddMonths(C().anchor, -1);
                                  C().dirty = true; break;
            case CalView::Year:  C().anchor = XbmTime_AddMonths(C().anchor, -12);
                                  C().dirty = true; break;
        }
    }
    ImGui::SameLine();
    if (ImGui::Button("Heute", ImVec2(0, E))) UiCalendar_GoToday();
    ImGui::SameLine();
    if (HoldButton(">", XbmTime_Format(NaviDatum(), "%d.%m.%Y").c_str(),
                   ImVec2(E, E))) {
        switch (C().view) {
            case CalView::Day:
            case CalView::ThreeDay:
            case CalView::Week:
                KalenderAnchorSetzen(XbmTime_AddDays(C().anchor, 1)); break;
            case CalView::Month: C().anchor = XbmTime_AddMonths(C().anchor, 1);
                                  C().dirty = true; break;
            case CalView::Year:  C().anchor = XbmTime_AddMonths(C().anchor, 12);
                                  C().dirty = true; break;
        }
    }

    ImGui::SameLine();
    // EINBUCHSTABIG. Auf schmalen Fenstern (und auf dem Handy sowieso)
    // frassen "3 Tage" und "Woche" den Platz, den die Pfeile und der
    // Titel brauchen.
    // [Tag (T) und Woche (W) sind ENTFERNT -- nicht mehr gebraucht. Die
    //  1-n-Tage-Ansicht deckt jetzt 1 bis 15 Tage ab und uebernimmt
    //  damit beide Faelle: eine Ziffer fuer einen einzelnen Tag ist
    //  dasselbe wie die fruehere Tagesansicht, sieben Tage dasselbe wie
    //  die fruehere Wochenansicht -- nur eben mit frei waehlbarer
    //  Anzahl statt zwei fest verdrahteten Sonderfaellen.]
    struct VB { const char* label; CalView v; const char* tip; };
    static const VB tabs[] = {
        { "3", CalView::ThreeDay, "n Tage" },   // Text wird ersetzt
        { "M", CalView::Month,    "Monat" },
        { "J", CalView::Year,     "Jahr" },
    };
    for (const VB& b : tabs) {
        const bool sel = (C().view == b.v);
        char nlab[8];
        const char* label = b.label;
        if (b.v == CalView::ThreeDay) {
            std::snprintf(nlab, sizeof(nlab), "%d", C().nDays);
            label = nlab;
        }
        if (sel) ImGui::PushStyleColor(ImGuiCol_Button,
                                       ImGui::GetStyleColorVec4(ImGuiCol_ButtonActive));
        ImGui::Button(label, ImVec2(E, E));
        // BEI BERUEHRUNG WECHSELN, NICHT ERST BEIM LOSLASSEN -- wie bei
        // der Reiter-Navigation der App. IsItemActivated() feuert schon
        // beim Aufsetzen (Maus-runter/Finger-runter), nicht erst beim
        // regulaeren "Klick" (der erst beim Loslassen ueber demselben
        // Knopf zaehlt).
        if (ImGui::IsItemActivated()) {
            // Beim Wechsel den Bezugstag beibehalten -- sonst springt man
            // aus der Wochenansicht in einen fremden Monat.
            const std::int64_t keep = C().anchor;
            C().view = b.v;
            C().anchor = XbmTime_LocalMidnight(keep);
            // OHNE DAS blieb die Ansicht nur im Speicher: nach einem
            // Neustart war wieder die zuletzt GESPEICHERTE (oft laengst
            // veraltete) Ansicht da, nie die zuletzt tatsaechlich
            // benutzte.
            C().dirty = true;
        }
        if (sel) ImGui::PopStyleColor();
        // n-TAGE: GEDRUECKT HALTEN UND WAAGERECHT WISCHEN -- PINPOINT AUF
        // DEN WERT. [Das Popup "Tage anzeigen" mit 15 Feldern ist weg. Der
        //  Aufsetzpunkt ist der Nullpunkt; der ABSTAND dazu bestimmt die
        //  Geschwindigkeit (nahe = langsam, weit = schnell), die RICHTUNG das
        //  Vorzeichen: links bis 1 herunter, rechts bis 15 hinauf. Kurzes
        //  Tippen ohne Wischen wechselt wie bisher nur die Ansicht.]
        if (b.v == CalView::ThreeDay) {
            ImGuiIO& nio = ImGui::GetIO();
            // EIGENER ZUGZUSTAND. [Mit IsItemActive() kam nur EIN Schritt:
            //  sobald der Finger die Totzone verliess, griff die globale
            //  Wisch-Geste, der Knopf verlor die Aktivierung, der Zug war
            //  vorbei. Jetzt gehoert der Druck ab dem ersten Frame uns
            //  (Claim), und der Zug laeuft, solange der Finger unten ist.]
            if (ImGui::IsItemActivated()) { C().nZugAktiv = true; C().nZugX0 = nio.MousePos.x; C().nZugAkk = 0.0; }
            if (C().nZugAktiv && nio.MouseDown[ImGuiMouseButton_Left]) {
                Claim();
                const float dx  = nio.MousePos.x - C().nZugX0;
                const float tot = fh * 0.6f;                       // Totzone: Tippen bleibt Tippen
                if (std::fabs(dx) > tot) {
                    Claim();
                    const float d = (std::fabs(dx) - tot) / (fh * 3.0f);   // 1.0 = drei Zeichenhoehen weit
                    const double rate = 1.5 + d * 4.0 + d * d * 10.0;      // Werte je Sekunde
                    C().nZugAkk += (dx > 0 ? 1.0 : -1.0) * rate * nio.DeltaTime;
                    const int schritt = (int)C().nZugAkk;
                    if (schritt != 0) {
                        C().nZugAkk -= schritt;
                        const int neu = std::max(1, std::min(15, C().nDays + schritt));
                        if (neu != C().nDays) { C().nDays = neu; C().view = CalView::ThreeDay; C().dirty = true; }
                        else C().nZugAkk = 0.0;                     // am Anschlag nichts aufstauen
                    }
                }
            } else if (C().nZugAktiv) {
                C().nZugAktiv = false;
            }
            char tip[64];
            std::snprintf(tip, sizeof(tip),
                          "%d Tage  (halten und waagerecht wischen: 1 bis 15)",
                          C().nDays);
            ImGui::SetItemTooltip("%s", tip);
        } else {
            ImGui::SetItemTooltip("%s", b.tip);
        }
        ImGui::SameLine();
    }

    // "GOTO" UND "ZEIT X" -- IN DERSELBEN ZEILE WIE < HEUTE > 3 M J,
    // RECHTSBUENDIG, GOTO LINKS DAVON. [Goto springt im Kalender auf die
    //  gelbe Zeitauswahl -- praktisch, wenn man sie vor einer Weile
    //  gesetzt hat und sich inzwischen wo anders hin bewegt hat.]
    {   // GOTO rechtsbuendig (Zeit x steht in der zweiten Zeile, siehe DrawDateNav)
        const float breiteGoto = ImMax(E, ImGui::CalcTextSize("goto").x + ImGui::GetStyle().FramePadding.x * 2.0f);
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x - breiteGoto);
        ImGui::BeginDisabled(!UiCalendar_HasSelectedTime());
        if (ImGui::Button("goto", ImVec2(breiteGoto, E))) UiCalendar_GoTo(C().slotSel);
        ImGui::EndDisabled();
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Zur gelben Zeitauswahl springen");
    }

    // Der Memo-Knopf sass hier zusammen mit einem "|"-Trenner. Beides ist
    // entfernt: er gehoert als Mikrofon-Symbol in die rechte Knopfleiste
    // der App und soll nur erscheinen, wenn das Kalenderfenster sichtbar
    // ist. Die Anbindung dafuer steht unten (UiCalendar_IsVisible und
    // UiCalendar_MemoBegin/-End); der Zustand wird weiterhin hier
    // gefuehrt, damit die Aufnahme auch per Geste oder Sensor ausloesbar
    // bleibt.
    if (C().memoActive) {
        ImGui::SameLine();
        const float lvl = ImClamp(XbmAudio_Level() * 4.0f, 0.0f, 1.0f);
        ImGui::ProgressBar(lvl, ImVec2(90, fh), "");
        ImGui::SameLine();
        ImGui::Text("%.1fs", XbmAudio_RecordSeconds());
    }
    // [Die Statusmeldung stand hier als Text hinter den Knoepfen und
    //  verschob die ganze Leiste, sobald sie laenger wurde. Sie geht jetzt
    //  ins Protokoll und erscheint bei Warnungen und Fehlern zusaetzlich
    //  kurz als Einblendung.]
    if (!C().memoStatus.empty()) {
        UiLog_Add(C().memoStatus);
        C().memoStatus.clear();
    }

    // ---- Titelzeile: ENTFERNT -- steht jetzt im Fenstertitel selbst. ------
    // [Der Text hinter den T/1-n/W/M/J-Knoepfen ("12.09. - 18.09." usw.)
    //  stand hier OHNE eigenen Zeilenumbruch davor und sprengte auf
    //  schmalen Fenstern die Zeile -- das erzeugte einen waagrechten
    //  Bildlauf, der bei jeder Wischgeste die Seite mitzog. Er wird jetzt
    //  in UiCalendar_Draw() VOR dem eigentlichen Begin() berechnet
    //  (AnsichtsCaption()) und als Fenstertitel gesetzt -- der Platz
    //  hinter den Knoepfen ist damit frei.]
    ImGui::NewLine();

    // ---- STIFTWERKZEUG / BULK-EDIT-LEISTE --------------------------------
    // [Erscheint nur, wenn das Werkzeug aktiv ist -- keine dauerhafte
    //  zweite Zeile, die im Normalbetrieb Platz wegnimmt. Verschieben in
    //  Tagesschritten deckt den haeufigsten Fall ("eine Woche
    //  verschieben") ab, ohne ein eigenes Datumsfeld zu brauchen.]
    if (C().penActive) {
        ImGui::Separator();
        const int n = UiCalendar_PenSelectedCount();
        ImGui::TextColored(ImVec4(1.0f, 0.86f, 0.24f, 1.0f),
                           "Stift: %d ausgewaehlt", n);
        ImGui::SameLine();
        ImGui::BeginDisabled(n == 0);
        if (ImGui::SmallButton("-1 Tag"))
            UiCalendar_PenShiftSelected(-86400);
        ImGui::SameLine();
        if (ImGui::SmallButton("+1 Tag"))
            UiCalendar_PenShiftSelected(86400);
        ImGui::SameLine();
        if (ImGui::SmallButton("-1 Std"))
            UiCalendar_PenShiftSelected(-3600);
        ImGui::SameLine();
        if (ImGui::SmallButton("+1 Std"))
            UiCalendar_PenShiftSelected(3600);
        ImGui::SameLine();
        if (ImGui::SmallButton("Loeschen")) {
            UiCalendar_PenDeleteSelected();
        }
        ImGui::EndDisabled();
        ImGui::SameLine();
        if (ImGui::SmallButton("Auswahl leeren"))
            UiCalendar_PenClearSelection(false);
        ImGui::SameLine();
        if (ImGui::SmallButton("Fertig (Esc)"))
            UiCalendar_PenToolSet(false);

        // TITEL UND NOTIZ ALLER AUSGEWAEHLTEN EVENTS GEMEINSAM BEARBEITEN.
        // [Der Fokus-Wunsch kommt entweder von oben (der Tastaturblock in
        //  UiCalendar_Draw, fuer den UEBERGANG "nichts -> ausgewaehlt" und
        //  fuer Tab/Enter OHNE bereits aktives Feld) oder wird HIER LOKAL
        //  gesetzt, wenn man WAEHREND des Tippens in einem der beiden
        //  Felder Tab drueckt -- dieselbe Zirkulation wie im Einzel-
        //  Editor: Titel->Tab->Notiz, Notiz->Tab->Titel, beides mit
        //  komplett markiertem Inhalt. Der Wunsch wirkt erst NAECHSTEN
        //  Frame (SetKeyboardFocusHere muss VOR dem betroffenen Widget
        //  stehen -- ein Wechsel INNERHALB desselben Frames, nachdem das
        //  Feld schon gezeichnet ist, kommt zu spaet).]
        if (n > 0) {
            using PF = CalState::PenFokus;
            ImGuiInputTextFlags titelFlags = 0;
            if (C().penFokus == PF::TitelVoll) {
                ImGui::SetKeyboardFocusHere();
                titelFlags |= ImGuiInputTextFlags_AutoSelectAll;
                C().penFokus = PF::Keine;
            } else if (C().penFokus == PF::TitelEnde) {
                ImGui::SetKeyboardFocusHere();   // ohne AutoSelectAll: Cursor ans Ende
                C().penFokus = PF::Keine;
            }
            ImGui::SetNextItemWidth(-1.0f);
            if (ImGui::InputText("##penBulkTitel", &C().penBulkTitel, titelFlags)) {
                for (auto id : C().penSel)
                    if (CalEntry* be = UiCalendar_Find(id)) {
                        be->title = C().penBulkTitel;
                        UiCalendar_Touch(id);
                    }
            }
            if (ImGui::IsItemFocused() && ImGui::IsKeyPressed(ImGuiKey_Tab, false))
                C().penFokus = PF::NotizVoll;   // naechster Frame: Notiz, markiert
            if (ImGui::IsItemHovered() || ImGui::IsItemActive())
                ImGui::SetItemTooltip("Titel -- gilt fuer alle %d ausgewaehlten Events", n);

            ImGuiInputTextFlags notizFlags = 0;
            if (C().penFokus == PF::NotizVoll) {
                ImGui::SetKeyboardFocusHere();
                notizFlags |= ImGuiInputTextFlags_AutoSelectAll;
                C().penFokus = PF::Keine;
            }
            ImGui::SetNextItemWidth(-1.0f);
            if (ImGui::InputTextMultiline("##penBulkNotiz", &C().penBulkNotiz,
                                          ImVec2(0, ImGui::GetFrameHeight() * 2.2f),
                                          notizFlags)) {
                for (auto id : C().penSel)
                    if (CalEntry* be = UiCalendar_Find(id)) {
                        be->notes = C().penBulkNotiz;
                        UiCalendar_Touch(id);
                    }
            }
            if (ImGui::IsItemFocused() && ImGui::IsKeyPressed(ImGuiKey_Tab, false))
                C().penFokus = PF::TitelVoll;   // naechster Frame: zurueck zum Titel, markiert
        }
    }
}

// ---------------------------------------------------------------------------
// Zeitraster-Ansichten (Tag / 3 Tage / Woche)
// ---------------------------------------------------------------------------
// ZENTRALE ZUG-VERARBEITUNG -- UNABHAENGIG VOM WIDGET-REDRAW.
//
// [Das war die eigentliche Ursache fuer "nur ein Feld, dann bricht es
//  ab": die bisherige Logik aktualisierte das Ziel NUR, solange das
//  jeweilige InvisibleButton (Koerper oder Griff) IN GENAU DIESEM FRAME
//  gezeichnet UND von ImGui als "aktiv" erkannt wurde. Sobald sich beim
//  Segment-Aufbau irgendetwas verschob -- ein anderer Tag wurde zum
//  "ersten Tag", eine Staffelung aenderte sich, oder das Segment landete
//  kurzzeitig ausserhalb des sichtbaren Bereichs -- konnte es einen
//  einzelnen Frame lang UNTERBLEIBEN, dass genau dieses Widget
//  gezeichnet wurde. Genau EIN uebersprungener Frame reicht: ImGui
//  vergisst seinen "aktiven" Zustand fuer dieses Widget sofort, und der
//  Zug bricht ab, ohne dass irgendetwas ihn wieder aufnimmt. Das erklaert
//  auch das GEMELDETE MUSTER "manchmal nur ein Feld" -- es passiert
//  GENAU DANN, wenn der Uebergang zwischen zwei Tagen zufaellig mit
//  einem solchen Frame zusammenfaellt, und auf Touch (schnellere,
//  gröbere Bewegungen pro Frame) haeufiger als mit der Maus.
//
//  Die Loesung: die eigentliche ZIELBERECHNUNG UND DAS SPEICHERN BEIM
//  LOSLASSEN laufen jetzt HIER, EINMAL PRO FRAME, komplett unabhaengig
//  davon, ob irgendein Widget diesen Frame gezeichnet wird. Die
//  einzelnen Griffe/der Koerper uebernehmen nur noch das AUSLOESEN
//  (Aufsetzen startet den Zug) und die reine DARSTELLUNG.]
void AktivenZugImZeitraster(ImVec2 org, float gutter, float colW, int days) {
    if (C().drag.id == 0) return;
    ImGuiIO& io = ImGui::GetIO();

    // GRIP 0 (KOERPER): Halten-oder-Bewegen-Uebergang. [Auch DAS lief
    //  bisher im Widget selbst -- lag der Uebergang genau in einem
    //  uebersprungenen Frame, blieb der Zug fuer immer bei "armed"
    //  haengen und wurde nie "aktiv".]
    if (C().drag.grip == 0 && C().drag.armed && !C().drag.active) {
        const float moved = ImLengthSqr(ImVec2(io.MousePos.x - C().drag.pressPos.x,
                                               io.MousePos.y - C().drag.pressPos.y));
        const double heldT = ImGui::GetTime() - C().drag.pressTime;
        if (moved >= kHoldSlop * kHoldSlop || heldT >= kHoldSec) {
            C().drag.armed = false;
            C().drag.active = true;
        }
    }

    if (!io.MouseDown[ImGuiMouseButton_Left]) {
        // LOSGELASSEN -- unabhaengig davon, ob das ausloesende Widget
        // heute ueberhaupt noch existiert oder gezeichnet wurde.
        if (C().drag.grip == 0) {
            if (C().drag.active && C().explorerOffen && C().explorerHover) {
                // AUF EINEN BAUMKNOTEN GEZOGEN: einhaengen, Lage zurueck.
                const std::uint64_t mid = ModellId(C().drag.id);
                if (CalEntry* e = UiCalendar_Find(C().drag.id)) if (!IstVirtuell(e->id)) UiCalendar_EventStartSetzen(*e, C().drag.origStart);
                if (mid && xbm_tl::Einhaengen(mid, C().explorerHover, XbmTime_NowUtc())) { C().dirty = true; SaveNow(); xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); xbm_tls::Anstossen(); C().explorerSel = mid; }
            } else if (C().drag.active) {
                if (IstVirtuell(C().drag.id)) {
                    if (const CalState::VirtOcc* v = VirtOccFuer(C().drag.id)) {
                        if (v->kind) {
                            const timeline::Event* kev = xbm_tl::Speicher().finde(v->kindId);
                            if (kev && xbm_tl::IstGruppe(kev->eltern) && C().gruppeOffen != kev->eltern) {
                                // MITGLIED EINER (geschlossenen) GRUPPE: die ganze Gruppe wandert.
                                const std::int64_t delta = C().dragVirtStart - v->occStart;
                                if (delta != 0) if (CalEntry* g = UiCalendar_Find(kev->eltern)) { UiCalendar_EventStartSetzen(*g, g->start + delta); UiCalendar_Touch(g->id); UiCalendar_Save(); }
                            } else if (C().dragVirtStart != v->occStart) {
                                // UNTER-TERMIN VERSCHOBEN: Versatz ins Modell.
                                UnterTerminFestschreiben(C().drag.id, C().dragVirtStart, C().dragVirtDur); UiCalendar_TimelineNeuLaden();
                            }
                        } else if (C().dragVirtStart != v->occStart) {
                            // SERIENTERMIN VERSCHOBEN: erst fragen, dann ins Modell.
                            C().serienZug = { true, v->base, v->occStart, C().dragVirtStart };
                        }
                    }
                } else if (CalEntry* e = UiCalendar_Find(C().drag.id)) {
                    UiCalendar_Touch(e->id);
                    UiCalendar_Save();
                }
            } else if (C().drag.armed && io.MouseDragMaxDistanceSqr[0] < 36.0f) {
                EditorOeffnen(C().drag.id);      // kurzer Tipp = oeffnen (Vorkommen: auf Kopie)
            }
        } else if (C().drag.grip <= 2) {
            if (CalEntry* e = UiCalendar_Find(C().drag.id)) {
                if (IstVirtuell(e->id)) {
                    if (UnterTerminFestschreiben(e->id, e->start, e->durMin)) UiCalendar_TimelineNeuLaden();
                    else if (const CalState::VirtOcc* v = VirtOccFuer(e->id)) {
                        // SERIEN-VORKOMMEN per Griff veraendert: Start und/oder Dauer -> Frage
                        if (!v->kind && (e->start != v->occStart || e->durMin != C().drag.origDur)) C().serienZug = { true, v->base, v->occStart, e->start, e->durMin };
                    }
                } else { UiCalendar_Touch(e->id); UiCalendar_Save(); }
            }
        } else {
            if (CalEntry* e = UiCalendar_Find(C().drag.ownerEventId)) {
                UiCalendar_Touch(e->id);
                UiCalendar_Save();
            }
        }
        C().drag = DragState{};
        return;
    }

    if (C().drag.grip == 0 && !C().drag.active) return;   // noch "armed"

    const ImVec2 mp = io.MousePos;
    const int ndi = (int)std::floor((mp.x - org.x - gutter) / colW);
    const double hourNow = (mp.y - org.y) / C().pxPerHour;
    const std::int64_t tag = XbmTime_AddDays(C().anchor, ndi);
    // Koerper-Zug: der Griffpunkt bleibt unter dem Finger (Versatz abziehen).
    const std::int64_t zielZeit = SnapTime(tag + (std::int64_t)(hourNow * 3600.0) - (C().drag.grip == 0 ? C().drag.griffVersatzSek : 0));

    if (C().drag.grip == 0) {
        // KOERPER: das ganze Event/die ganze Erinnerung folgt dem Finger,
        // Dauer bleibt erhalten.
        if (CalEntry* e = UiCalendar_Find(C().drag.id)) {
            // Ganztaegig: nur der Tag wandert, die Uhrzeit bleibt
            UiCalendar_EventStartSetzen(*e, e->allDay ? XbmTime_LocalMidnight(zielZeit) + SecondsIntoLocalDay(C().drag.origStart) : zielZeit);
            if (IstVirtuell(e->id)) C().dragVirtStart = e->start;   // Vorkommen: nur merken, Modell erst nach der Frage
            else C().dirty = true;
        }
    } else if (C().drag.grip == 1) {
        // EVENT-START (Ende springt mit, wenn ueberschritten -- siehe
        // fruehere Begruendung).
        if (CalEntry* e = UiCalendar_Find(C().drag.id)) {
            const std::int64_t origEnde = C().drag.origStart
                                        + (std::int64_t)C().drag.origDur * 60;
            UiCalendar_EventStartSetzen(*e, zielZeit);
            if (zielZeit < origEnde - 300) e->durMin = (int)((origEnde - zielZeit) / 60);
            else                           e->durMin = C().drag.origDur < 5 ? 5 : C().drag.origDur;
            C().dirty = true;
        }
    } else if (C().drag.grip == 2) {
        // EVENT-ENDE (Start weicht zurueck, wenn unterschritten).
        if (CalEntry* e = UiCalendar_Find(C().drag.id)) {
            const std::int64_t origStart  = C().drag.origStart;
            const std::int64_t origDurSek = (std::int64_t)C().drag.origDur * 60;
            if (zielZeit > origStart + 300) {
                if (e->start != origStart) UiCalendar_EventStartSetzen(*e, origStart);
                e->durMin = (int)((zielZeit - origStart) / 60);
            } else {
                UiCalendar_EventStartSetzen(*e, zielZeit - origDurSek);
                e->durMin = C().drag.origDur < 5 ? 5 : C().drag.origDur;
            }
            C().dirty = true;
        }
    } else if (C().drag.grip == 3) {
        // ERINNERUNG VERSCHIEBEN.
        if (CalEntry* e = UiCalendar_Find(C().drag.ownerEventId)) {
            for (auto& a : e->actions) if (a.id == C().drag.id) { a.start = zielZeit; break; }
            UiCalendar_Touch(e->id);
        }
    } else if (C().drag.grip == 4) {
        // ERINNERUNG-START.
        if (CalEntry* e = UiCalendar_Find(C().drag.ownerEventId)) {
            for (auto& a : e->actions) {
                if (a.id != C().drag.id) continue;
                const std::int64_t origEnde = C().drag.origStart
                                            + (std::int64_t)C().drag.origDur * 60;
                if (zielZeit < origEnde - 300) {
                    a.start = zielZeit; a.durMin = (int)((origEnde - zielZeit) / 60);
                } else {
                    a.start = zielZeit;
                    a.durMin = C().drag.origDur < 5 ? 5 : C().drag.origDur;
                }
                break;
            }
            UiCalendar_Touch(e->id);
        }
    } else if (C().drag.grip == 5) {
        // ERINNERUNG-ENDE.
        if (CalEntry* e = UiCalendar_Find(C().drag.ownerEventId)) {
            for (auto& a : e->actions) {
                if (a.id != C().drag.id) continue;
                const std::int64_t origStart  = C().drag.origStart;
                const std::int64_t origDurSek = (std::int64_t)C().drag.origDur * 60;
                if (zielZeit > origStart + 300) {
                    if (a.start != origStart) a.start = origStart;
                    a.durMin = (int)((zielZeit - origStart) / 60);
                } else {
                    a.start = zielZeit - origDurSek;
                    a.durMin = C().drag.origDur < 5 ? 5 : C().drag.origDur;
                }
                break;
            }
            UiCalendar_Touch(e->id);
        }
    }
}

// AUTO-SCROLL WAEHREND EINES ZUGS -- ZU DEN SEITEN UND NACH OBEN/UNTEN.
// [Zieht man ein Event (oder einen Griff) an den Rand des sichtbaren
//  Bereichs, muss man auf nicht sichtbare Tage bzw. Uhrzeiten ziehen
//  koennen, OHNE den Zug loszulassen. Geschwindigkeit haengt von der
//  Eindringtiefe in die Randzone ab -- weiter am Rand ist schneller,
//  knapp am Rand langsamer, zur Feinjustierung. Senkrecht (Stunden)
//  laeuft kontinuierlich ueber ImGui::SetScrollY(); waagerecht (Tage)
//  sind es diskrete Schritte -- Tage lassen sich nicht "ein bisschen"
//  verschieben, deshalb Taktung wie beim Pinpoint-Halten.]
// DARF DIE RANDZONE IN DIESEM ZUG SCHON WIRKEN?
// <imRand>  steht der Zeiger JETZT in der Randzone dieser Achse?
// <scharf>  der Schalter dieser Achse (randScharfH oder randScharfV).
// [Beim ersten Aufruf eines neuen Zugs werden beide Achsen entschaerft.
//  Sobald der Zeiger die Zone einmal verlassen hat, wird die Achse
//  scharf -- ab dann blaettert bzw. scrollt der Rand ganz normal.]
static bool RandZoneFreigegeben(bool imRand, bool& scharf) {
    if (C().drag.pressTime != C().randScharfFuerZug) {
        C().randScharfFuerZug = C().drag.pressTime;
        C().randScharfH = false;
        C().randScharfV = false;
    }
    if (!imRand) scharf = true;
    return imRand && scharf;
}

void AutoScrollWaehrendZug(ImVec2 org, float gutter, float colW, int days,
                          float gridH) {
    if (C().drag.id == 0) return;    // kein Zug aktiv -- nichts zu tun
    ImGuiIO& io = ImGui::GetIO();
    const ImVec2 mp = io.MousePos;

    // --- SENKRECHT: Rand des Scrollbereichs (##calgrid) -----------------
    ImGuiWindow* win = ImGui::GetCurrentWindow();
    const float oben = win->Pos.y;
    const float unten = win->Pos.y + gridH;
    const float randZoneV = 44.0f;
    float geschwindV = 0.0f;   // Pixel pro Sekunde, negativ = nach oben
    const bool inZoneOben  = (mp.y < oben + randZoneV && mp.y >= oben - 20.0f);
    const bool inZoneUnten = (mp.y > unten - randZoneV && mp.y <= unten + 20.0f);
    const bool vFrei = RandZoneFreigegeben(inZoneOben || inZoneUnten, C().randScharfV);
    if (vFrei && inZoneOben) {
        float tiefe = (oben + randZoneV - mp.y) / randZoneV;
        if (tiefe > 1.0f) tiefe = 1.0f;
        geschwindV = -(80.0f + tiefe * 700.0f);
    } else if (vFrei && inZoneUnten) {
        float tiefe = (mp.y - (unten - randZoneV)) / randZoneV;
        if (tiefe > 1.0f) tiefe = 1.0f;
        geschwindV = 80.0f + tiefe * 700.0f;
    }
    if (geschwindV != 0.0f) {
        float neu = ImGui::GetScrollY() + geschwindV * io.DeltaTime;
        if (neu < 0.0f) neu = 0.0f;
        const float maxScroll = ImGui::GetScrollMaxY();
        if (neu > maxScroll) neu = maxScroll;
        ImGui::SetScrollY(neu);
    }

    // --- WAAGERECHT: Rand des Tagesrasters -- Anker tageweise schieben --
    const float linksRand  = org.x + gutter;
    const float rechtsRand = org.x + gutter + colW * days;
    const float randZoneH  = 48.0f;
    int richtung = 0;
    float tiefeH = 0.0f;
    const bool inZoneLinks  = (mp.x < linksRand + randZoneH);
    const bool inZoneRechts = (mp.x > rechtsRand - randZoneH);
    const bool hFrei = RandZoneFreigegeben(inZoneLinks || inZoneRechts, C().randScharfH);
    if (hFrei && inZoneLinks) {
        richtung = -1;
        tiefeH = (linksRand + randZoneH - mp.x) / randZoneH;
    } else if (hFrei && inZoneRechts) {
        richtung = 1;
        tiefeH = (mp.x - (rechtsRand - randZoneH)) / randZoneH;
    }
    if (richtung != 0) {
        if (tiefeH > 1.0f) tiefeH = 1.0f;
        if (tiefeH < 0.0f) tiefeH = 0.0f;
        // Dieselbe Kurve wie beim Pinpoint-Halten: 0,55 s am Rand der
        // Zone (gerade eben eingedrungen), bis zu 0,05 s ganz aussen.
        const double abstand = 0.55 - 0.50 * std::pow((double)tiefeH, 0.75);
        const double jetzt = ImGui::GetTime();
        if (jetzt - C().autoScrollLetzterTick >= abstand) {
            C().autoScrollLetzterTick = jetzt;
            C().anchor = XbmTime_AddDays(C().anchor, richtung);
            C().dirty = true;
        }
    }
}


// ---------------------------------------------------------------------------
// MEHRTAGESLEISTE: ein Termin ueber mehrere Tage ist OBEN ein durchgehender
// Balken (ohne Luecken zwischen den Tagesspalten), mit dem Titel genau
// einmal; Tippen waehlt/oeffnet (von jedem Tag aus), Ziehen verschiebt um
// ganze Tage -- aber NUR, wenn der Zug auf dem ERSTEN Tag des Termins
// beginnt. Im Raster darunter stehen nur noch die Klammern an Anfang und Ende.
// ---------------------------------------------------------------------------
static void MehrtagesLeiste(float px0, float gutter, float colW, int days, float lineH) {
    const std::int64_t von = C().anchor, bis = XbmTime_AddDays(C().anchor, days);
    struct Bar { CalEntry* e; int di0, di1; bool anfangDrin, endeDrin; int bahn; };
    std::vector<Bar> bars;
    for (CalEntry* e : UiCalendar_Range(von, bis)) {
        const std::int64_t ende = e->end();
        const std::int64_t t0 = XbmTime_LocalMidnight(e->start), t1 = XbmTime_LocalMidnight(ende > e->start ? ende - 1 : e->start);
        if (t0 == t1 && !e->allDay) continue;                    // eintaegig mit Uhrzeit: bleibt im Raster; ganztaegig: Balken
        int di0 = DayIndexOf(t0, C().anchor, days), di1 = DayIndexOf(t1, C().anchor, days);
        const bool a = di0 >= 0, z = di1 >= 0;
        if (!a) di0 = 0;
        if (!z) di1 = days - 1;
        bars.push_back({ e, di0, di1, a, z, 0 });
    }
    C().leisteRect0 = C().leisteRect1 = ImVec2(0, 0);
    if (bars.empty()) return;
    // PLATZSPAREND: EINE Zeile fester Hoehe. Ueberlappende Termine teilen sie
    // sich als duenne Bahnen (bis vier); der Titel steht nur, wenn die Bahn
    // hoch genug ist, sonst beim ausgewaehlten Termin als Schild darueber.
    // Ausgewaehlt wird durch Tippen, verschoben durch Ziehen am ersten Tag --
    // beides mit einer Geste, wie bisher.
    std::vector<std::pair<int,int>> belegt[4];
    int bahnen = 1;
    for (Bar& b : bars) {
        b.bahn = -1;
        for (int r = 0; r < 4 && b.bahn < 0; ++r) {
            bool frei = true;
            for (auto& o : belegt[r]) if (b.di0 <= o.second && b.di1 >= o.first) { frei = false; break; }
            if (frei) { b.bahn = r; belegt[r].push_back({ b.di0, b.di1 }); }
        }
        if (b.bahn < 0) b.bahn = 3;                               // mehr als vier: die letzte Bahn teilen
        if (b.bahn + 1 > bahnen) bahnen = b.bahn + 1;
    }
    // KOMPAKT ODER GROSS: Knopf links in der Rinne schaltet um (gespeichert).
    // Kompakt = eine Zeile fester Hoehe, Bahnen teilen sie sich; gross = je
    // Bahn eine Zeile mit Titel.
    static int leisteGross = -1;
    if (leisteGross < 0) leisteGross = UiFlagGet("kalender.leisteGross", false) ? 1 : 0;
    const float kbKnopf = ImMin(gutter - 4.0f, lineH * 2.0f);     // quadratisch, buendig mit der Lupe im Kopf
    const float bahnH = leisteGross ? lineH + 4.0f : ImMax(lineH + 2.0f, kbKnopf - 2.0f) / (float)bahnen;
    const float h = leisteGross ? ImMax(bahnen * bahnH + 4.0f, kbKnopf + 2.0f) : ImMax(lineH + 6.0f, kbKnopf + 2.0f);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 p0 = ImGui::GetCursorScreenPos();
    ImGuiIO& io = ImGui::GetIO();
    {
        const float kb = kbKnopf;
        ImGui::SetCursorScreenPos(ImVec2(px0 + 2.0f, p0.y + 1.0f));
        if (ImGui::Button(leisteGross ? "-" : "+", ImVec2(kb, kb))) { leisteGross = !leisteGross; UiFlagSet("kalender.leisteGross", leisteGross != 0); }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(leisteGross ? "Mehrtaegige Termine kompakt zeigen" : "Mehrtaegige Termine gross mit Titel zeigen");
    }
    CalEntry* schildFuer = nullptr; float schildX0 = 0, schildX1 = 0;
    for (const Bar& b : bars) {
        CalEntry* e = b.e;
        const float y0 = p0.y + 2.0f + b.bahn * bahnH, y1 = y0 + bahnH - 1.0f;
        const float x0 = px0 + gutter + colW * b.di0 + (b.anfangDrin ? 2.0f : 0.0f);
        const float x1 = px0 + gutter + colW * (b.di1 + 1) - (b.endeDrin ? 2.0f : 0.0f);
        ImGui::PushID((int)((e->id & 0x1fffffff) * 7 + 3));
        const bool selectedVorher = (C().selected == e->id);
        ImGui::SetCursorScreenPos(ImVec2(x0, y0));
        ImGui::InvisibleButton("##bar", ImVec2(std::max(10.0f, x1 - x0), std::max(6.0f, y1 - y0)));
        const bool hov = ImGui::IsItemHovered();
        if (ImGui::IsItemActivated()) {
            C().selected = e->id;
            // Zug von JEDEM Tag aus (relativ zum Druckpunkt); an den Enden
            // eines ausgewaehlten Balkens greifen die Griffe Start bzw. Ende.
            C().barDrag = CalState::BarDrag{};
            C().barDrag.id = e->id; C().barDrag.x0 = io.MousePos.x; C().barDrag.origStart = e->start; C().barDrag.bewegt = false;
            C().barOrigDur = e->durMin; C().barGriff = 0;
            if (selectedVorher) {
                const float gz = ImMax(10.0f, colW * 0.25f);
                if (b.anfangDrin && io.MousePos.x < x0 + gz) C().barGriff = 1;
                else if (b.endeDrin && io.MousePos.x > x1 - gz) C().barGriff = 2;
            }
            if (IstVirtuell(e->id)) C().dragVirtStart = e->start;
            C().barTippId = e->id; C().barTippX = io.MousePos.x; C().barTippY = io.MousePos.y;
            Claim();                                               // ab dem Druck: keine fremde Geste
        }
        // EIGENER ZUGZUSTAND, nicht IsItemActive(): sonst nimmt die globale
        // Wischgeste den Finger nach ein paar Pixeln, und der Balken bleibt stehen.
        if (C().barDrag.id == e->id && io.MouseDown[ImGuiMouseButton_Left]) {
            Claim();
            // RANDZONEN: am linken/rechten Rand blaettert die Ansicht weiter,
            // waehrend der Zug laeuft (wie im Raster). Der Druckpunkt wandert
            // mit, damit die Rechnung relativ bleibt.
            {
                const float randZone = 30.0f; const double jetztT = ImGui::GetTime();
                int richtung = 0;
                if (io.MousePos.x < px0 + gutter + randZone) richtung = -1; else if (io.MousePos.x > px0 + gutter + colW * days - randZone) richtung = 1;
                if (richtung && jetztT - C().barRandTick >= 0.35) { C().barRandTick = jetztT; C().anchor = XbmTime_AddDays(C().anchor, richtung); C().barDrag.x0 -= richtung * colW; C().dirty = true; }
            }
            const int dTage = (int)std::floor((io.MousePos.x - C().barDrag.x0) / colW + 0.5f);
            if (C().barGriff == 1) {            // START-GRIFF: Ende bleibt
                const std::int64_t ende = C().barDrag.origStart + (std::int64_t)C().barOrigDur * 60;
                std::int64_t neu = XbmTime_AddDays(C().barDrag.origStart, dTage);
                if (neu > ende - 3600) neu = ende - 3600;
                if (neu != e->start) { UiCalendar_EventStartSetzen(*e, neu); e->durMin = (int)((ende - neu) / 60); C().barDrag.bewegt = true; if (IstVirtuell(e->id)) { C().dragVirtStart = neu; C().dragVirtDur = e->durMin; } else C().dirty = true; }
            } else if (C().barGriff == 2) {     // ENDE-GRIFF: Start bleibt
                int neuDur = C().barOrigDur + dTage * 1440; if (neuDur < 60) neuDur = 60;
                if (neuDur != e->durMin) { e->durMin = neuDur; C().barDrag.bewegt = true; if (IstVirtuell(e->id)) C().dragVirtDur = neuDur; else C().dirty = true; }
            } else {
                const std::int64_t neu = XbmTime_AddDays(C().barDrag.origStart, dTage);
                if (neu != e->start) {
                    UiCalendar_EventStartSetzen(*e, neu); C().barDrag.bewegt = true;
                    if (IstVirtuell(e->id)) C().dragVirtStart = neu; else C().dirty = true;
                }
            }
        }
        if (C().barTippId == e->id && !io.MouseDown[ImGuiMouseButton_Left]) {
            const float wx = io.MousePos.x - C().barTippX, wy = io.MousePos.y - C().barTippY;
            if (C().barDrag.id == e->id && C().barDrag.bewegt) {
                if (IstVirtuell(e->id)) {
                    if (const CalState::VirtOcc* v = VirtOccFuer(e->id)) {
                        if (v->kind) { if (UnterTerminFestschreiben(e->id, e->start, e->durMin)) UiCalendar_TimelineNeuLaden(); }
                        else if (C().dragVirtStart != v->occStart || e->durMin != C().barOrigDur) C().serienZug = { true, v->base, v->occStart, e->start, e->durMin };
                    }
                } else { UiCalendar_Touch(e->id); UiCalendar_Save(); }
            } else if (wx * wx + wy * wy < 36.0f) {
                EditorOeffnen(e->id);                              // Tipp: von jedem Tag aus
            }
            C().barDrag = CalState::BarDrag{}; C().barTippId = 0;
        }
        const bool selected = (C().selected == e->id);
        ImU32 col = EntryColor(*e); if (hov || selected) col = Darken(col, 1.15f);
        col = (col & 0x00ffffff) | ((ImU32)(255.0f * DeckkraftStufe(e->id) + 0.5f) << 24);   // dieselben drei Stufen wie im Raster
        ImDrawFlags ecken = ImDrawFlags_RoundCornersNone;
        if (b.anfangDrin) ecken |= ImDrawFlags_RoundCornersLeft;
        if (b.endeDrin)   ecken |= ImDrawFlags_RoundCornersRight;
        if (ecken != ImDrawFlags_RoundCornersNone) ecken &= ~ImDrawFlags_RoundCornersNone;
        dl->AddRectFilled(ImVec2(x0, y0), ImVec2(x1, y1), col, 3.0f, ecken);
        if (selected) {
            dl->AddRect(ImVec2(x0, y0), ImVec2(x1, y1), IM_COL32(255, 255, 255, 200), 3.0f, ecken, 1.5f);
            const float gz = ImMax(10.0f, colW * 0.25f), gm = (y0 + y1) * 0.5f;   // Griffe: Start links, Ende rechts
            if (b.anfangDrin) { dl->AddRectFilled(ImVec2(x0, y0), ImVec2(x0 + gz, y1), IM_COL32(255, 255, 255, 60)); dl->AddCircleFilled(ImVec2(x0 + gz * 0.5f, gm), 3.0f, IM_COL32(255, 255, 255, 230)); }
            if (b.endeDrin)   { dl->AddRectFilled(ImVec2(x1 - gz, y0), ImVec2(x1, y1), IM_COL32(255, 255, 255, 60)); dl->AddCircleFilled(ImVec2(x1 - gz * 0.5f, gm), 3.0f, IM_COL32(255, 255, 255, 230)); }
        }
        if (C().aktivEltern && ModellId(e->id) == C().aktivEltern) dl->AddRect(ImVec2(x0 - 1, y0 - 1), ImVec2(x1 + 1, y1 + 1), IM_COL32(255, 200, 60, 240), 3.0f, ecken, 2.0f);
        const char* t = e->title.empty() ? "(ohne Titel)" : e->title.c_str();
        if (leisteGross || bahnH >= lineH * 0.95f) {               // Platz fuer den Titel in der Bahn
            ImVec4 clip(x0 + 3, y0, x1 - 3, y1);
            dl->AddText(nullptr, 0.0f, ImVec2(x0 + 5.0f, y0 + (bahnH - lineH) * 0.5f), IM_COL32(255, 255, 255, 240), t, nullptr, 0.0f, &clip);
        } else if (selected) { schildFuer = e; schildX0 = x0; schildX1 = x1; }
        ImGui::PopID();
    }
    if (schildFuer) {                                              // Titel des ausgewaehlten als Schild ueber der Leiste
        const char* t = schildFuer->title.empty() ? "(ohne Titel)" : schildFuer->title.c_str();
        const ImVec2 ts = ImGui::CalcTextSize(t);
        const float sx0 = ImMax(px0 + gutter, ImMin(schildX0, schildX1 - ts.x - 8.0f)), sy0 = p0.y - lineH - 4.0f;
        dl->AddRectFilled(ImVec2(sx0, sy0), ImVec2(sx0 + ts.x + 8.0f, sy0 + lineH + 2.0f), IM_COL32(20, 20, 24, 230), 3.0f);
        dl->AddText(ImVec2(sx0 + 4.0f, sy0 + 1.0f), IM_COL32(255, 255, 255, 245), t);
    }
    ImGui::SetCursorScreenPos(p0);
    C().leisteRect0 = ImVec2(px0, p0.y); C().leisteRect1 = ImVec2(px0 + gutter + colW * days, p0.y + h);
    ImGui::Dummy(ImVec2(ImGui::GetContentRegionAvail().x, h));
}
void DrawTimeGrid(float bottomReserve) {
    const int days = DaysInView(C().view);
    const float gutter = ImGui::CalcTextSize("00:00").x + 14.0f;
    ImDrawList* dl = ImGui::GetWindowDrawList();

    const float avail = ImGui::GetContentRegionAvail().x;
    const float colW = (avail - gutter) / (float)days;
    const std::int64_t today0 = XbmTime_LocalMidnight(XbmTime_NowUtc());

    // ---- Kopfzeile: Datum oben, Wochentag DARUNTER ----------------------
    // [Vorher stand beides in EINER Zeile ("Mo 25.8."). Im Hochformat war
    //  eine Spalte schmaler als dieser Text, und die Koepfe benachbarter
    //  Tage ueberlappten sichtbar. Zwei Zeilen in derselben Zelle loesen
    //  das, ohne Platz zu verschenken.]
    const std::int64_t selDay = C().slotSel
                              ? XbmTime_LocalMidnight(C().slotSel) : 0;
    {
        const float lineH = ImGui::GetTextLineHeight();
        // KOMPAKTE KOPFZEILE (1-15 Tage): oben eine schmale Zeile fuer Monat
        // und KW (nur dort, wo sie beginnen), darunter Tagesnummer und
        // Wochentag; das Jahr steht einmal links in der Ecke ueber den
        // Uhrzeiten, ein Jahreswechsel dort, wo er beginnt. Schrift schrumpft,
        // wenn die Spalte schmaler ist als der Text.
        const float klein = lineH * 0.8f;
        const float headH = klein + lineH * 2.0f + 8.0f;
        const ImVec2 p0 = ImGui::GetCursorScreenPos();
        auto textPassend = [&](ImVec2 pos, float breiteMax, ImU32 farbe, const char* txt, float groesse) {
            float g = groesse; ImVec2 ts = ImGui::GetFont()->CalcTextSizeA(g, FLT_MAX, 0.0f, txt);
            if (ts.x > breiteMax - 2.0f) { g = groesse * (breiteMax - 2.0f) / ts.x; if (g < groesse * 0.55f) g = groesse * 0.55f; ts = ImGui::GetFont()->CalcTextSizeA(g, FLT_MAX, 0.0f, txt); }
            dl->AddText(ImGui::GetFont(), g, ImVec2(pos.x + (breiteMax - ts.x) * 0.5f, pos.y), farbe, txt);
        };
        auto kalenderwoche = [](const XbmLocalTime& l) {   // ISO 8601
            auto wochenImJahr = [](int y) { auto p = [](int j) { return (j + j / 4 - j / 100 + j / 400) % 7; }; return (p(y) == 4 || p(y - 1) == 3) ? 53 : 52; };
            const int wdIso = (l.weekday + 6) % 7 + 1;         // 1 = Montag ... 7 = Sonntag
            const int ordinal = l.yday + 1;                     // yday ist 0-basiert
            int w = (ordinal - wdIso + 10) / 7;
            if (w < 1) w = wochenImJahr(l.year - 1);
            else if (w > wochenImJahr(l.year)) w = 1;
            return w;
        };
        {   // Jahr in der Ecke (ueber den Uhrzeiten) -- darunter die LUPE (Zoom an/aus),
            // quadratisch und buendig mit dem +/- Knopf der Mehrtagesleiste.
            const XbmLocalTime l0 = XbmTime_ToLocal(C().anchor);
            char jb[8]; std::snprintf(jb, sizeof(jb), "%d", l0.year);
            dl->AddText(ImGui::GetFont(), klein, ImVec2(p0.x + 2.0f, p0.y + 1.0f), ImGui::GetColorU32(ImGuiCol_TextDisabled), jb);
            const float kb = ImMin(gutter - 4.0f, lineH * 2.0f);
            ImGui::SetCursorScreenPos(ImVec2(p0.x + 2.0f, p0.y + klein + 3.0f));
            if (C().zoomAn) ImGui::PushStyleColor(ImGuiCol_Button, ImGui::GetStyleColorVec4(ImGuiCol_ButtonActive));
            if (ImGui::Button("##lupe", ImVec2(kb, kb))) { C().zoomAn = !C().zoomAn; if (C().zoomAn && C().pxPerHour < 20.0f) C().pxPerHour = 48.0f; }
            if (C().zoomAn) ImGui::PopStyleColor();
            if (ImGui::IsItemHovered()) ImGui::SetTooltip(C().zoomAn ? "Zoom an: Zeitachse zoombar (Pinch), Ausschnitt scrollt" : "Zoom aus: der ganze Tag passt in den Ausschnitt");
            {   // Lupen-Symbol
                const ImVec2 r0 = ImGui::GetItemRectMin(); const float w = kb, cx = r0.x + w * 0.44f, cy = r0.y + w * 0.44f, rr = w * 0.22f;
                const ImU32 lc = ImGui::GetColorU32(ImGuiCol_Text);
                dl->AddCircle(ImVec2(cx, cy), rr, lc, 16, ImMax(1.5f, w * 0.07f));
                dl->AddLine(ImVec2(cx + rr * 0.7f, cy + rr * 0.7f), ImVec2(r0.x + w * 0.8f, r0.y + w * 0.8f), lc, ImMax(1.5f, w * 0.09f));
                if (!C().zoomAn) dl->AddLine(ImVec2(r0.x + w * 0.2f, r0.y + w * 0.8f), ImVec2(r0.x + w * 0.8f, r0.y + w * 0.2f), lc, ImMax(1.5f, w * 0.07f));
            }
        }
        int letzterMonat = -1, letzteKW = -1, letztesJahr = XbmTime_ToLocal(C().anchor).year;
        for (int d = 0; d < days; ++d) {
            const std::int64_t day = XbmTime_AddDays(C().anchor, d);
            const XbmLocalTime l = XbmTime_ToLocal(day);
            const float x0 = p0.x + gutter + colW * d;
            const bool isToday = (day == today0);
            const bool isSel   = (selDay != 0 && day == selDay);

            // AUSGEWAEHLTER TAG DUNKLER als der heutige -- so sind beide
            // gleichzeitig erkennbar.
            if (isSel)
                dl->AddRectFilled(ImVec2(x0, p0.y),
                                  ImVec2(x0 + colW, p0.y + headH),
                                  IM_COL32(30, 55, 95, 220), 4.0f);
            else if (isToday)
                dl->AddRectFilled(ImVec2(x0, p0.y),
                                  ImVec2(x0 + colW, p0.y + headH),
                                  IM_COL32(70, 110, 180, 60), 4.0f);

            char dat[8], wt[8];
            std::snprintf(dat, sizeof(dat), "%d", l.day);
            std::snprintf(wt,  sizeof(wt),  "%s", kWeekdayShort[(l.weekday + 6) % 7]);
            const ImU32 col = ImGui::GetColorU32(
                (isToday || isSel) ? ImGuiCol_Text : ImGuiCol_TextDisabled);
            // Obere Zeile: Monat, KW, Jahreswechsel -- nur dort, wo sie beginnen
            {
                const int kw = kalenderwoche(l);
                char ob[24] = ""; const ImU32 cm = IM_COL32(230, 200, 120, 220);
                if (l.year != letztesJahr) { std::snprintf(ob, sizeof(ob), "%d", l.year); letztesJahr = l.year; dl->AddLine(ImVec2(x0, p0.y), ImVec2(x0, p0.y + headH), cm, 2.0f); }
                else if (l.month != letzterMonat) std::snprintf(ob, sizeof(ob), "%d.", l.month);
                if (kw != letzteKW) {
                    if (d > 0) dl->AddLine(ImVec2(x0, p0.y), ImVec2(x0, p0.y + klein + 2.0f), IM_COL32(180, 180, 180, 160), 1.0f);
                    if (ob[0] == 0 || d == 0 || l.day == 1) { char kb[16]; std::snprintf(kb, sizeof(kb), "%s%sKW%d", ob, ob[0] ? " " : "", kw); std::snprintf(ob, sizeof(ob), "%s", kb); }
                }
                if (ob[0]) textPassend(ImVec2(x0, p0.y + 1.0f), colW * (d + 1 < days ? 2.0f : 1.0f) - 2.0f, cm, ob, klein);
                letzterMonat = l.month; letzteKW = kw;
            }
            textPassend(ImVec2(x0, p0.y + klein + 3.0f), colW, col, dat, lineH * 1.05f);
            textPassend(ImVec2(x0, p0.y + klein + 3.0f + lineH), colW, col, wt, lineH * 0.9f);

            // KLICK AUF DEN SPALTENKOPF WAEHLT DEN TAG -- danach zeigt "T"
            // genau diesen.
            ImGui::SetCursorScreenPos(ImVec2(x0, p0.y));
            ImGui::PushID(2000 + d);
            ImGui::InvisibleButton("##kopf", ImVec2(colW, headH));
            if (ImGui::IsItemDeactivated()
                && ImGui::GetIO().MouseDragMaxDistanceSqr[0] < 36.0f) {
                const std::int64_t uhr = C().slotSel
                    ? (std::int64_t)SecondsIntoLocalDay(C().slotSel) : 9 * 3600;
                C().slotSel = day + uhr;
                C().dirty = true;
            }
            ImGui::PopID();

            // Ganztaegige Eintraege als schmale Baender unten in der Zelle.
            // (ganztaegige Termine stehen als Balken in der Mehrtagesleiste)
        }
        ImGui::SetCursorScreenPos(p0);
        ImGui::Dummy(ImVec2(avail, headH));
        MehrtagesLeiste(p0.x, gutter, colW, days, lineH);   // [fehlte: Funktion war da, Aufruf nicht]
    }

    // ---- Scrollbereich ---------------------------------------------------
    // Hoehe absichern: BeginChild mit 0 bedeutet "automatisch" und negative
    // Werte sind schlicht ungueltig -- in einem knapp bemessenen oder
    // gerade selbst-anpassenden Fenster faellt GetContentRegionAvail().y
    // sonst unter den reservierten Editorplatz und das Gitter entgleist.
    float gridH = ImGui::GetContentRegionAvail().y - bottomReserve;
    if (gridH < 80.0f) gridH = 80.0f;
    // LUPE AUS: die ganze Tageszeit erstreckt sich ueber den Ausschnitt,
    // kein Zoom, kein senkrechtes Scrollen -- 24 Stunden auf gridH.
    if (!C().zoomAn) C().pxPerHour = ImMax(4.0f, (gridH - 2.0f) / 24.0f);
    const ImVec2 gridSize(avail, gridH);
    ImGui::BeginChild("##calgrid", gridSize, false,
                      ImGuiWindowFlags_NoScrollbar |
                      ImGuiWindowFlags_NoScrollWithMouse);

    if (!C().scrollInit) {
        // Erststart: 7 Uhr oben statt Mitternacht -- niemand plant nachts.
        ImGui::SetScrollY(7.0f * C().pxPerHour);
        C().scrollInit = true;
    }
    // SENKRECHTES PINPOINT: Scrollgeschwindigkeit aus NavKanteFrame anwenden.
    if (C().pinScrollV != 0.0f) {
        const float neu = ImGui::GetScrollY() + C().pinScrollV * ImGui::GetIO().DeltaTime;
        ImGui::SetScrollY(ImMax(0.0f, neu));
    }
    // MITFUEHREN (Zeitleiste): der Ausschnitt folgt dem bewegten Punkt --
    // senkrecht ueber den Scroll, waagerecht ueber den Anker -- aber NUR,
    // wenn er sonst aus dem Bild liefe. Kein gewoehnlicher Seitenscroll.
    if (C().folgeAn) {
        C().folgeAn = false;
        const std::int64_t tag = XbmTime_LocalMidnight(C().folgeZeit);
        if (DayIndexOf(tag, C().anchor, days) < 0) {
            // waagerecht: Tagsprung. Links hinaus -> der Tag wird erster;
            // rechts hinaus -> der Tag wird letzter Tag des Ausschnitts.
            std::int64_t neu = tag < C().anchor ? tag : XbmTime_AddDays(tag, -(days - 1));
            if (C().view == CalView::Week) neu = WeekStart(C().folgeZeit);
            KalenderAnchorSetzen(neu);
        }
        const float y = (float)(SecondsIntoLocalDay(C().folgeZeit) / 3600.0) * C().pxPerHour;
        const float oben = ImGui::GetScrollY(), unten = oben + gridSize.y;
        const float rand = ImGui::GetTextLineHeight() * 2.0f;
        if (y < oben + rand)        ImGui::SetScrollY(ImMax(0.0f, y - gridSize.y * 0.33f));
        else if (y > unten - rand)  ImGui::SetScrollY(ImMax(0.0f, y - gridSize.y * 0.66f));
    }

    dl = ImGui::GetWindowDrawList();
    const ImVec2 org = ImGui::GetCursorScreenPos();      // Inhalt (0 Uhr)
    const float gridTop = ImGui::GetWindowPos().y;
    const float totalH = 24.0f * C().pxPerHour;
    const bool hoverGrid = ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows);

    // ZENTRALE ZUG-VERARBEITUNG -- siehe ausfuehrliche Begruendung bei
    // AktivenZugImZeitraster(). Muss VOR dem Segment-Aufbau laufen, damit
    // die Aktualisierung noch in DIESEM Frame sichtbar wird.
    AktivenZugImZeitraster(org, gutter, colW, days);
    AutoScrollWaehrendZug(org, gutter, colW, days, gridH);

    // --- Zoom: Strg+Rad (Desktop) ---
    if (hoverGrid && ImGui::GetIO().KeyCtrl) {
        const float w = ImGui::GetIO().MouseWheel;
        if (w != 0.0f)
            ZoomAround(C().pxPerHour * (w > 0 ? 1.15f : 1.0f / 1.15f),
                       ImGui::GetIO().MousePos.y, gridTop, gridSize.y);
    } else if (hoverGrid) {
        const float w = ImGui::GetIO().MouseWheel;
        if (w != 0.0f) ImGui::SetScrollY(ImGui::GetScrollY() - w * 60.0f);
    }

    // --- Zoom UND Scrollen: Pinch (Android) ---
    // [Zwei Finger sollen BEIDES koennen: der ABSTAND zwischen ihnen
    //  steuert den Zoom (wie bisher), die BEWEGUNG ihrer MITTE steuert
    //  das Scrollen -- genau wie ein Ein-Finger-Scroll, nur mit zwei
    //  Fingern gleichzeitig. Vorher reagierte diese Geste NUR auf die
    //  Abstands-AENDERUNG: eine reine Verschiebung beider Finger (der
    //  Abstand blieb dabei etwa gleich) loeste GAR NICHTS aus -- man
    //  konnte mit zwei Fingern nicht zur gewuenschten Tagesuhrzeit
    //  scrollen. Das war das gemeldete Zusammenspiel-Problem.]
    {
        // BESITZ STEHT BEIM AUFSETZEN FEST. [Beim Aufsetzen entscheidet
        //  der Winkel (PinchDistance: nur ueberwiegend senkrecht). Laeuft
        //  der Stundenzoom aber schon, wird winkelunabhaengig
        //  weitergemessen -- sonst fiel er beim kleinsten Verkippen aus,
        //  und der waagerechte Ansichtswechsel konnte uebernehmen.]
        float d = -1.0f;
        if (!C().pinchHActive)
            d = C().pinching ? PinchRohDistanz() : PinchDistance();
        if (d > 0.0f) {
            Claim();
            const float midY = PinchMidY();
            if (!C().pinching) {
                C().pinching   = true;
                C().pinchDist0 = d;
                C().pinchPph0  = C().pxPerHour;
                C().pinchMidY0 = midY;
                C().pinchMidStart = midY;
            } else {
                // ZWEI-FINGER-PINPOINT: wandern beide Finger gemeinsam nach oben
                // oder unten, scrollt die Zeit mit abstandsabhaengiger
                // Geschwindigkeit (wie das Ein-Finger-Pinpoint), nicht 1:1.
                if (midY > 0.0f && C().pinchMidStart > 0.0f) {
                    const float dy = midY - C().pinchMidStart, tot = 12.0f, ausV = fabsf(dy);
                    if (ausV > tot) {
                        float w = (ausV - tot) / 160.0f; if (w > 1.5f) w = 1.5f;
                        const float v = (dy > 0 ? -1.0f : 1.0f) * (200.0f + 1700.0f * w * w);   // Finger nach unten = Zeit nach oben (wie Scrollen)
                        ImGui::SetScrollY(ImMax(0.0f, ImGui::GetScrollY() + v * ImGui::GetIO().DeltaTime));
                    }
                }
                C().pinchMidY0 = midY;
                if (C().pinchDist0 > 1.0f && C().zoomAn) {
                    ZoomAround(C().pinchPph0 * (d / C().pinchDist0),
                               ImGui::GetWindowPos().y + gridSize.y * 0.5f,
                               gridTop, gridSize.y);
                }
            }
        } else {
            C().pinching = false; C().pinchMidStart = -1.0f;
        }
    }

    // --- Ansichtswechsel: waagerechter Pinch (Android) siehe
    //     UiCalendar_Draw() -- dort zentral fuer ALLE Ansichten, nicht
    //     nur das Zeitraster. [Frueher lief die Kanten-Navigation
    //     (Pinpoint/Wischen) NUR hier -- Monat und Jahr hatten also gar
    //     keine. Jetzt zentral, einmal fuer alle vier Ansichten.]

    // --- Stundenlinien und Beschriftung ---
    const ImU32 colLine  = ImGui::GetColorU32(ImGuiCol_Separator, 0.55f);
    const ImU32 colLineH = ImGui::GetColorU32(ImGuiCol_Separator, 0.22f);
    const int hourStep = C().pxPerHour < 22.0f ? 3 : (C().pxPerHour < 40.0f ? 2 : 1);
    for (int h = 0; h <= 24; ++h) {
        const float y = org.y + h * C().pxPerHour;
        dl->AddLine(ImVec2(org.x + gutter, y), ImVec2(org.x + avail, y), colLine);
        if (C().pxPerHour >= 56.0f && h < 24)   // Halbstundenlinie
            dl->AddLine(ImVec2(org.x + gutter, y + C().pxPerHour * 0.5f),
                        ImVec2(org.x + avail, y + C().pxPerHour * 0.5f), colLineH);
        if (h < 24 && (h % hourStep) == 0) {
            char buf[8];
            std::snprintf(buf, sizeof(buf), "%02d:00", h);
            dl->AddText(ImVec2(org.x + 4, y + 1),
                        ImGui::GetColorU32(ImGuiCol_TextDisabled), buf);
        }
    }
    // Spaltentrenner
    for (int d = 0; d <= days; ++d) {
        const float x = org.x + gutter + colW * d;
        dl->AddLine(ImVec2(x, org.y), ImVec2(x, org.y + totalH), colLine);
    }

    // --- Jetzt-Linie ---
    {
        const std::int64_t now = XbmTime_NowUtc();
        const int di = DayIndexOf(now, C().anchor, days);
        if (di >= 0) {
            const float y = org.y + (float)(SecondsIntoLocalDay(now) / 3600.0) * C().pxPerHour;
            const float x0 = org.x + gutter + colW * di;
            dl->AddLine(ImVec2(x0, y), ImVec2(x0 + colW, y), IM_COL32(230, 70, 60, 230), 2.0f);
            dl->AddCircleFilled(ImVec2(x0 + 3, y), 4.0f, IM_COL32(230, 70, 60, 230));
        }
    }

    // Ausgewaehlter leerer Zeitpunkt: als Marke zeichnen (dorthin legt der
    // Memo-Knopf seinen Eintrag).
    if (C().slotSel) {
        const int di = DayIndexOf(C().slotSel, C().anchor, days);
        if (di >= 0) {
            const float y = org.y + (float)(SecondsIntoLocalDay(C().slotSel) / 3600.0)
                                    * C().pxPerHour;
            const float x0 = org.x + gutter + colW * di;
            dl->AddRectFilled(ImVec2(x0 + 1, y), ImVec2(x0 + colW - 1, y + 3),
                              IM_COL32(255, 200, 60, 200));
        }
    }

    // --- Eintraege ---
    const std::int64_t viewFrom = C().anchor;
    const std::int64_t viewTo   = XbmTime_AddDays(C().anchor, days);
    std::vector<CalEntry*> vis = UiCalendar_Range(viewFrom, viewTo);

    // TAGUEBERGREIFENDE EVENTS: EIN SEGMENT JE BERUEHRTEM TAG.
    // [Vorher wurde ein Event NUR in der Spalte seines STARTTAGS
    //  gezeichnet -- reichte die Dauer ueber Mitternacht hinaus, lief die
    //  Flaeche unten aus dem 24-Stunden-Raster heraus, und am FOLGENDEN
    //  Tag erschien vom Event ueberhaupt nichts. Jetzt bekommt jeder Tag,
    //  den ein Event beruehrt, sein eigenes Segment, zugeschnitten auf
    //  dessen 0:00-24:00.]
    struct Segment {
        CalEntry* e;
        int di;
        int tagVersatz;         // 0,1,2... relativ zum EIGENEN Start des
                                 // Events -- bleibt beim Verschieben gleich
        float y0, y1;          // volle Dauer DIESES Tagesabschnitts
        bool ersterTag, letzterTag;
        bool mehrtaegig;        // Termin reicht ueber Mitternacht: Balken oben, Umrandung hier
        float eventY0, eventY1; // Start-/Endhoehe des GANZEN Termins (fuer die Umrandung)
        int   tageGesamt;       // Zahl der Tage des Termins
    };
    std::vector<Segment> segmente;
    for (CalEntry* e : vis) {
        // GANZTAEGIG: wie ein mehrtaegiger Termin ueber den ganzen Tag -- mit
        // Flaeche, Umrandung, Label und Balken oben; auswaehlbar und ziehbar.
        const std::int64_t eStart = e->allDay ? XbmTime_LocalMidnight(e->start) : e->start;
        const std::int64_t eEnde  = e->allDay ? XbmTime_AddDays(XbmTime_LocalMidnight(e->end() > e->start ? e->end() - 1 : e->start), 1) : e->end();
        const std::int64_t tagStart = XbmTime_LocalMidnight(e->start);
        const std::int64_t tagEndeLetzter =
            XbmTime_LocalMidnight(eEnde > e->start ? eEnde - 1 : e->start);
        int tagVersatz = 0;
        for (std::int64_t tag = tagStart; tag <= tagEndeLetzter;
             tag = XbmTime_AddDays(tag, 1), ++tagVersatz) {
            int di = DayIndexOf(tag, C().anchor, days);
            if (di < 0) {
                // WAEHREND EIN GRIFF/KOERPER DIESES EVENTS GERADE GEZOGEN
                // WIRD: nicht ueberspringen, sondern an den sichtbaren
                // Rand klemmen. [Das war der eigentliche Grund fuer
                // "Greifer verliert beim Ziehen den Fokus und blockt":
                // zog man einen Griff weit genug, wanderte sein Tag
                // ausserhalb des sichtbaren Fensters (di<0) -- das
                // Segment wurde dann fuer DIESEN Frame GAR NICHT
                // gezeichnet. Ein Widget, das einen Frame lang nicht
                // gezeichnet wird, verliert bei ImGui zwangslaeufig
                // seinen aktiven Zustand; der Zug endete damit abrupt,
                // ohne dass irgendetwas es weiter verfolgte. Waehrend
                // des Ziehens bleibt das Segment jetzt sichtbar, nur
                // optisch an den Rand gepinnt -- die eigentliche
                // Zielberechnung in den Griffen selbst liest ohnehin
                // direkt die Mausposition, nicht diese geklemmte
                // Anzeige-Spalte.]
                // NICHT auf Spalte 0 bzw. (days-1) klemmen -- das kann
                // mit einem ANDEREN, bereits echt sichtbaren Segment
                // DESSELBEN Events kollidieren, wenn ein mehrtaegiges
                // Event (etwa durch Ueberschreiten beim Ziehen
                // entstanden) TEILWEISE sichtbar ist: ein Tag ausserhalb
                // links, der naechste bereits bei Spalte 0 -- beide
                // landeten dann auf DERSELBEN Spalte und das Event
                // erschien "wiederholt in derselben Zeile". Stattdessen
                // knapp AUSSERHALB des sichtbaren Rasters klemmen (-1
                // bzw. genau dahinter) -- fuer ImGui reicht das, um das
                // Widget am Leben zu halten, kollidiert aber nie mit
                // einer echten Spalte.
                // WEIT AUSSERHALB klemmen (nicht nur eine Spalte
                // dahinter). [Bei einer Ansicht mit vielen, schmalen
                // Spalten (etwa 15 Tage) konnte "-1" bzw. "days" IMMER
                // NOCH innerhalb der Uhrzeiten-Spalte links landen, wenn
                // die Spaltenbreite kleiner als deren Breite (gutter)
                // war (org.x + gutter - colW liegt dann NOCH in der
                // Uhrzeiten-Anzeige) -- genau das erzeugte die
                // gemeldeten "Eventeintraege in der Uhrzeiten-Spalte".
                // Ein Vielfaches der Spaltenzahl reicht garantiert aus,
                // unabhaengig von der Spaltenbreite.]
                if (C().drag.id == e->id) {
                    di = (tag < C().anchor) ? -(days + 10) : (days * 2 + 10);
                } else {
                    continue;
                }
            }
            const std::int64_t tagNaechster = XbmTime_AddDays(tag, 1);
            const std::int64_t segStart = eStart > tag ? eStart : tag;
            const std::int64_t segEnde  = eEnde < tagNaechster ? eEnde : tagNaechster;
            const double h0 = (double)(segStart - tag) / 3600.0;
            const double h1 = (double)(segEnde  - tag) / 3600.0;
            float sy0 = org.y + (float)h0 * C().pxPerHour;
            float sy1 = org.y + (float)h1 * C().pxPerHour;
            if (sy1 - sy0 < 16.0f) sy1 = sy0 + 16.0f;
            const float evY0 = org.y + (float)((double)(eStart - tagStart) / 3600.0) * C().pxPerHour;
            const float evY1 = org.y + (float)((double)(eEnde - tagEndeLetzter) / 3600.0) * C().pxPerHour;
            segmente.push_back({e, di, tagVersatz, sy0, sy1,
                               tag == tagStart, tag == tagEndeLetzter,
                               tagStart != tagEndeLetzter || e->allDay, evY0, evY1,
                               (int)((tagEndeLetzter - tagStart) / 86400) + 1});
        }
    }
    // Nach Spalte, dann nach Starthoehe sortiert -- Grundlage der
    // Ueberlappungs-Staffelung (dieselbe Idee wie in der Monatsansicht:
    // der Versatz zaehlt, wie viele ZEITLICH ueberlappende Segmente schon
    // in dieser Spalte gezeichnet wurden -- ein Schritt je Overlap, kein
    // Sprung aufs Aeusserste).
    std::sort(segmente.begin(), segmente.end(), [](const Segment& a, const Segment& b) {
        if (a.di != b.di) return a.di < b.di;
        return a.y0 < b.y0;
    });

    std::vector<float> belegtY0, belegtY1;
    int letzterDi = -1;
    // GESTAFFELTER ABSTAND, JETZT MIT OBERGRENZE. [Vorher wuchs der
        // Abstand ungebremst mit der Spaltenbreite (14% von colW) --
        // auf einer breiten Ansicht (wenige Tage, viel Platz je Spalte)
        // wurde der Versatz dadurch riesig und liess nur noch wenige
        // Ueberlappungen nebeneinander Platz finden. Jetzt nach oben
        // gedeckelt: bei schmalen Spalten wie zuvor, bei breiten bleibt
        // der Abstand moderat -- so passen deutlich mehr gestaffelte
        // Elemente auf dieselbe Flaeche und bleiben trotzdem gut zu
        // treffen.]
        const float indentPx = ImClamp(colW * 0.09f, 8.0f, 18.0f);
    // KOPF-HOEHE: fest, genug fuer Uhrzeit + Titel + ein Stueck Notiz.
    // [Das Event ist NICHT mehr ueber die ganze Dauer ausgefuellt -- nur
    //  dieser Kopf ist gefuellt UND antippbar/ziehbar; der Rest der
    //  Dauer wird als duenner, GLEICHFARBIGER STRICH LINKSBUENDIG zum
    //  Versatz gezeichnet, bis zum tatsaechlichen Ende. So bleibt das
    //  Raster darunter frei fuer eigene Tipps -- Zeitmarken setzen oder
    //  mit dem Stift zeichnen -- statt von einem riesigen Block verdeckt
    //  zu werden.]
    const float kopfH = ImGui::GetTextLineHeight() * 3.3f;

    // ZWEI ZEICHEN-KANAELE: Kanal 0 fuer alle Event-/Erinnerungskoerper,
    // Kanal 1 NUR fuer Griffe. ChannelsMerge() am Ende fuegt Kanal 1
    // IMMER NACH Kanal 0 wieder zusammen -- Griffe landen dadurch
    // garantiert ÜBER JEDEM Koerper, unabhaengig von der
    // Zeichenreihenfolge der einzelnen Segmente.
    // [Das war der Grund fuer "ein nahliegendes Event verdeckt die
    //  Griffe": beides landete bisher im selben Kanal, in genau der
    //  Reihenfolge, in der die Segmente durchlaufen wurden -- ein
    //  SPAETER gezeichnetes Event konnte die Griffe eines FRUEHER
    //  gezeichneten, aber ausgewaehlten Events optisch ueberdecken.]
    dl->ChannelsSplit(2);
    dl->ChannelsSetCurrent(0);
    struct TitelLabel { std::string text; float x0, x1, y0, y1; ImU32 farbe; float stufe; std::uint64_t id; };
    std::vector<TitelLabel> labels;
    std::set<std::uint64_t> beschriftet;      // mehrtaegige, die schon einen Titel haben

    for (const Segment& seg : segmente) {
        CalEntry* e = seg.e;
        const int di = seg.di;
        if (di != letzterDi) { belegtY0.clear(); belegtY1.clear(); letzterDi = di; }
        // EINRUECKEN NUR, WENN SICH DIE KOEPFE UEBERSCHNEIDEN. [Vorher zaehlte
        //  die ganze Dauer: ein Termin, der innerhalb eines laengeren lag,
        //  wurde eingerueckt, obwohl der Kopf des laengeren laengst vorbei
        //  war. Jetzt zaehlt nur der Kopfbereich (y0 .. y0+kopfH); alles
        //  darunter ist Rand, den man ueberdecken darf -- der Termin bekommt
        //  die groesste zulaessige Breite.]
        const float kopfEnde = ImMin(seg.y0 + kopfH, seg.y1);
        int indent = 0;
        for (size_t k = 0; k < belegtY0.size(); ++k)
            if (seg.y0 < belegtY1[k] && kopfEnde > belegtY0[k]) ++indent;
        belegtY0.push_back(seg.y0); belegtY1.push_back(kopfEnde);

        const float spaltenX0 = org.x + gutter + colW * di + 2.0f;
        const float spaltenX1 = org.x + gutter + colW * (di + 1) - 6.0f;
        float x0 = spaltenX0 + indent * indentPx;
        float x1 = spaltenX1;
        if (x1 - x0 < 14.0f) x0 = x1 - 14.0f;   // nie ganz verschwinden
        if (seg.mehrtaegig) {
            // MEHRTAEGIG: die Umrandung liegt GENAU auf den Spaltenkanten --
            // ohne Innenabstand und ohne die Einrueckung fuer Ueberlappungen,
            // sonst sass sie je nach Nachbartermin anders und mit Luecken
            // zwischen den Tagen. (Die Luecke rechts gehoert der Scrollleiste.)
            x0 = std::floor(org.x + gutter + colW * di) + 1.0f;
            x1 = std::floor(org.x + gutter + colW * (di + 1)) - 1.0f;
        }
        const float y0 = seg.y0, y1 = seg.y1;
        // Mehrtaegig: kein Kopf im Raster (der sitzt als Balken oben) --
        // nur ein schmaler Streifen bleibt tippbar, die Griffe funktionieren.
        // Mehrtaegig: Kopf nur am ERSTEN Tag (dort beginnt der Termin); an den
        // Folgetagen bleibt ein schmaler tippbarer Streifen.
        const bool kopfHier = !e->allDay && (!seg.mehrtaegig || seg.ersterTag);
        const float kopfY1 = kopfHier ? ImMin(y0 + kopfH, y1) : ImMin(y0 + 10.0f, y1);

        ImGui::SetCursorScreenPos(ImVec2(x0, y0));
        // ID je EVENT UND TAG eindeutig -- ein mehrtaegiges Event hat
        // mehrere Segmente, jedes braucht eine eigene ImGui-ID.
        ImGui::PushID((int)((e->id & 0x1fffffff) * 40 + seg.tagVersatz));
        ImGui::InvisibleButton("##ent", ImVec2(x1 - x0, kopfY1 - y0));
        const bool hov = ImGui::IsItemHovered();
        const bool act = ImGui::IsItemActive();


        // RECHTSKLICK (Desktop): in den Papierkorb. RADIERER: Wischen ueber
        // den Kopf loescht ebenfalls (Papierkorb, wiederherstellbar).
        if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(ImGuiMouseButton_Right)) C().zuLoeschenNachSchleife = e->id;
        if (C().eraserActive && ImGui::IsItemHovered() && ImGui::GetIO().MouseDown[ImGuiMouseButton_Left]) { C().zuLoeschenNachSchleife = e->id; Claim(); }
        if (C().eraserActive && ImGui::IsItemActivated()) { ImGui::PopID(); continue; }   // Radierer: kein Auswaehlen, kein Zug
        // --- Halten-und-Ziehen -------------------------------------------
        if (ImGui::IsItemActivated()) {
            // DREIFACH-TIPP LOESCHT DAS EVENT. [Ringpuffer der letzten
            // drei Klicks: treffen alle drei dasselbe Event innerhalb
            // von 0,8 s, gilt das als Dreifach-Tipp. Die eigentliche
            // Loeschung passiert NICHT hier, sondern erst NACH der
            // Schleife (siehe dort) -- UiCalendar_Remove aendert den
            // Vektor, aus dem diese Schleife gerade noch liest.]
            C().tripleTapId[0]   = C().tripleTapId[1];
            C().tripleTapId[1]   = C().tripleTapId[2];
            C().tripleTapId[2]   = e->id;
            C().tripleTapZeit[0] = C().tripleTapZeit[1];
            C().tripleTapZeit[1] = C().tripleTapZeit[2];
            C().tripleTapZeit[2] = ImGui::GetTime();
            // (Dreifach-Tipp loescht NICHT mehr: Loeschen geht per Radierer
            //  in Navi 0 oder am Desktop per Rechtsklick -- in den Papierkorb.)
            // DOPPELTIPP: dieses Event wird "aktiv" -- Elternteil fuer alles,
            // was ab jetzt angelegt wird (auch ein Unterevent kann aktiv sein).
            if (C().tripleTapId[1] == e->id && C().tripleTapZeit[2] - C().tripleTapZeit[1] < 0.4) {
                const std::uint64_t mid = ModellId(e->id);
                if (xbm_tl::Geladen() && xbm_tl::IstGruppe(mid)) C().gruppeOffen = (C().gruppeOffen == mid) ? 0 : mid;   // Gruppe: Mitglieder einzeln
                else C().aktivEltern = (C().aktivEltern == mid) ? 0 : mid;
            }
            // STIFTWERKZEUG AKTIV: Klick waehlt fuer den Bulk-Modus aus/ab,
            // startet aber KEIN Ziehen und OEFFNET NICHT den Editor. So
            // laesst sich eine Gruppe von Events zusammenstellen, ohne
            // versehentlich eines zu verschieben.
            if (C().penActive || ImGui::GetIO().KeyShift) {   // Shift+Tipp: Mehrfachauswahl wie das Stiftwerkzeug
                UiCalendar_PenToggle(e->id);
                ImGui::PopID();
                continue;
            }
            // NICHT AUSGEWAEHLT (und "sofort verschieben" aus): kein Zug im
            // Kalender, sondern Drag & Drop mit Symbol -- siehe DndFrame().
            if (C().selected != e->id && !C().sofortVerschieben) {
                C().dnd = CalState::Dnd{}; C().dnd.id = e->id; C().dnd.pressPos = ImGui::GetIO().MousePos;
                C().dnd.titel = e->title.empty() ? "(ohne Titel)" : e->title; C().dnd.farbe = EntryColor(*e);
                C().selected = e->id; C().slotSel = 0; Claim();
                ImGui::PopID();
                continue;
            }
            C().drag.id        = e->id;
            C().drag.armed     = true;
            C().drag.active    = false;
            C().drag.pressTime = ImGui::GetTime();
            C().drag.pressPos  = ImGui::GetIO().MousePos;
            C().drag.origStart = e->start;
            C().drag.origDur   = e->durMin;
            {   // GRIFFVERSATZ: wo im Termin wurde gegriffen? [Vorher sprang
                //  der Start unter den Finger -- ein Griff im unteren Teil des
                //  Kopfes rueckte den Termin sofort um die Griffhoehe nach oben.]
                const ImVec2 mp0 = ImGui::GetIO().MousePos;
                const std::int64_t tagP = XbmTime_AddDays(C().anchor, di);
                const std::int64_t unterFinger = tagP + (std::int64_t)((mp0.y - org.y) / C().pxPerHour * 3600.0);
                C().drag.griffVersatzSek = unterFinger - e->start;
            }
            C().dragVirtStart  = e->start;      // virtuelles Vorkommen: bleibt stehen, bis gezogen wird
            C().dragVirtDur    = e->durMin;     // [fehlte: der Block sprang vor der ersten Bewegung auf 1970]
            // SOFORT BEANSPRUCHEN, nicht erst wenn die Haltezeit
            // abgelaufen ist. [Das war der Grund fuer "auf Android laesst
            // sich ein Event nicht per Touch&Move bewegen": Claim() lief
            // bisher nur INNERHALB von "if (C().drag.active)" -- also
            // erst NACH den 0,3 s Haltezeit. In diesem Fenster gehoerte
            // der Finger noch niemandem, und die globale Scroll-Geste der
            // App (die auf Touch aktiv ueberwacht, wer ein Ziehen fuer
            // sich beansprucht) konnte ihn sich in der Zwischenzeit
            // greifen -- auf dem Desktop faellt das nie auf, weil es dort
            // keine konkurrierende Touch-Scroll-Geste gibt. Jetzt wird der
            // Finger schon beim ERSTEN Beruehren dieses Events reserviert.]
            Claim();
            // KEIN automatisches "untere Kante = Groesse aendern" mehr --
            // die zwei GRIFFE (Start/Ende) sind jetzt groesser, praeziser
            // und immer sichtbar; der Koerper bedeutet nur noch "verschieben".
            C().drag.resizing = false;
            C().selected = e->id;
            C().slotSel  = 0;
        }
        if (act && C().drag.id == e->id && C().drag.grip == 0) {
            const ImVec2 mp = ImGui::GetIO().MousePos;
            const float moved = ImLengthSqr(mp - C().drag.pressPos);
            const double heldT = ImGui::GetTime() - C().drag.pressTime;
            // BEWEGUNG STARTET DAS ZIEHEN SOFORT -- "Tap und Move".
            // [Hier lag der eigentliche Fehler, warum sich Events auf
            //  Android ueberhaupt nicht verschieben liessen -- UNABHAENGIG
            //  von Claim()/der globalen Geste. Die Regel lautete bisher:
            //      bewegt, BEVOR die 0,3 s Haltezeit um sind
            //      -> "zu frueh bewegt", ABBRECHEN (drag.id = 0)
            //  Genau DAS ist aber exakt die Geste "Finger auf das Event,
            //  sofort bewegen" -- sie wurde also aktiv AUSGESCHLOSSEN statt
            //  erkannt. Man musste den Finger perfekt stillhalten, bis die
            //  0,3 s um waren, und DANACH erst bewegen -- kontraintuitiv
            //  und auf einem Touchscreen kaum zu treffen.
            //  Jetzt gilt: Bewegung UEBER die Toleranz hinaus startet das
            //  Ziehen SOFORT, in JEDEM Fall. Der Finger sitzt bereits
            //  direkt auf dem Event (dieser Button IST schon aktiv) --
            //  es gibt keinen Grund mehr, das als Scrollgeste
            //  durchzureichen. Stillhalten fuer kHoldSec bleibt als
            //  ZWEITER Weg bestehen, falls man ohne jede Bewegung ziehen
            //  moechte (z.B. mit der Maus erst greifen, dann fein
            //  positionieren).]
            if (C().drag.armed && moved >= kHoldSlop * kHoldSlop) {
                C().drag.armed  = false;
                C().drag.active = true;
            } else if (C().drag.armed && heldT >= kHoldSec) {
                C().drag.armed  = false;
                C().drag.active = true;
            }
            if (C().drag.active) {
                Claim();
                // DAS EVENT FOLGT DIREKT DEM FINGER/ZEIGER --
                // Tag UND Uhrzeit werden aus der aktuellen Mausposition
                // gelesen, nicht aus einem Delta zum Druckpunkt. Gilt
                // unveraendert bei einem mehrtaegigen Event: es ist
                // voellig gleich, welches TAGES-SEGMENT man dabei anfasst
                // -- das Event bekommt in jedem Fall die Zeit UNTER DEM
                // FINGER als neuen Start, Dauer bleibt erhalten.
                int ndi = (int)((mp.x - org.x - gutter) / colW);
                if (ndi < 0) ndi = 0; if (ndi >= days) ndi = days - 1;
                const double hourNow = (mp.y - org.y) / C().pxPerHour;
                const std::int64_t tag = XbmTime_AddDays(C().anchor, ndi);
                std::int64_t ns = tag + (std::int64_t)(hourNow * 3600.0);
                UiCalendar_EventStartSetzen(*e, SnapTime(ns));
                C().dirty = true;
            }
        }
        if (ImGui::IsItemDeactivated() && C().drag.id == e->id
            && C().drag.grip == 0) {
            if (C().drag.active) {
                UiCalendar_Touch(e->id);
                SaveNow();
            } else if (C().drag.armed &&
                       ImGui::GetIO().MouseDragMaxDistanceSqr[0] < 36.0f) {
                EditorOeffnen(e->id);      // kurzer Tipp = oeffnen
            }
            C().drag.armed = C().drag.active = C().drag.resizing = false;
            C().drag.id = 0;
        }

        // --- Darstellung: KOPF (gefuellt, fest hoch) + STRICH (Restdauer) --
        const bool selected = (C().selected == e->id);
        const bool moving   = (C().drag.active && C().drag.id == e->id);
        const bool penSel   = UiCalendar_PenIsSelected(e->id);
        // DREI DECKKRAFTSTUFEN: das ausgewaehlte Element 100 % (bei einer
        // Gruppe alle ihre Mitglieder), alles aus demselben Baum bis zur
        // Wurzel 80 %, alle uebrigen 60 %. Farbe bleibt die Terminfarbe.
        const ImU32 basis = EntryColor(*e);
        const float stufe = DeckkraftStufe(e->id);
        auto mitA = [&](ImU32 c, unsigned a) { return (c & 0x00ffffff) | ((ImU32)(a * stufe + 0.5f) << 24); };
        ImU32 col = hov ? Darken(basis, 1.1f) : basis;
        const bool istAktiv = C().aktivEltern && ModellId(e->id) == C().aktivEltern;
        // FLAECHE: die ganze Dauer stark transparent in der Terminfarbe --
        // Ueberschneidungen (auch ueber Tage) mischen sich sichtbar.
        if (!e->gruppe) dl->AddRectFilled(ImVec2(x0, y0), ImVec2(x1, y1), mitA(basis, 46), seg.mehrtaegig ? 0.0f : 4.0f);
        if (e->gruppe) {   // GRUPPE: durchscheinende Huelle ueber die ganze Dauer, Mitglieder liegen darin
            const ImU32 huelle = (col & 0x00ffffff) | (ImU32)((C().gruppeOffen == e->id ? 70 : 45) << 24);
            dl->AddRectFilled(ImVec2(x0, y0), ImVec2(x1, y1), huelle, 4.0f);
            const float dn = 6.0f; ImVec2 pA(x0, y0), pB(x1, y1);
            for (float xx = pA.x; xx < pB.x; xx += dn * 2) { dl->AddLine(ImVec2(xx, pA.y), ImVec2(ImMin(xx + dn, pB.x), pA.y), col, 1.5f); dl->AddLine(ImVec2(xx, pB.y), ImVec2(ImMin(xx + dn, pB.x), pB.y), col, 1.5f); }
            for (float yy = pA.y; yy < pB.y; yy += dn * 2) { dl->AddLine(ImVec2(pA.x, yy), ImVec2(pA.x, ImMin(yy + dn, pB.y)), col, 1.5f); dl->AddLine(ImVec2(pB.x, yy), ImVec2(pB.x, ImMin(yy + dn, pB.y)), col, 1.5f); }
            if (selected) dl->AddRect(ImVec2(x0, y0), ImVec2(x1, y1), Darken(col, 1.45f), 4.0f, 0, 2.0f);
            if (istAktiv) dl->AddRect(ImVec2(x0 - 2, y0 - 2), ImVec2(x1 + 2, y1 + 2), IM_COL32(255, 200, 60, 110), 4.0f, 0, 2.0f);
            dl->PushClipRect(ImVec2(x0 + 2, y0), ImVec2(x1 - 2, y1), true);
            dl->AddText(ImVec2(x0 + 5, y0 + 2), IM_COL32(255, 255, 255, 200), e->title.empty() ? "Gruppe" : e->title.c_str());
            if (C().gruppeOffen == e->id) dl->AddText(ImVec2(x0 + 5, y0 + 2 + ImGui::GetTextLineHeight()), IM_COL32(255, 220, 120, 220), "geoeffnet");
            dl->PopClipRect();
            ImGui::PopID();
            continue;
        }
        if (seg.mehrtaegig && kopfHier) {
            // KOPF am ersten Tag wie bei eintaegigen Terminen (schraffiert)
            Schraffur(dl, ImVec2(x0, y0), ImVec2(x1, kopfY1), mitA(col, 150));
        }
        if (seg.mehrtaegig) {
            // KLAMMERN STATT STRICH. [Der Rand folgt der Form des Termins:
            //  am ersten Tag die Oberkante am Start und der linke Rand bis
            //  Mitternacht ("["), an Zwischentagen beide Raender, am letzten
            //  Tag der rechte Rand bis zum Ende und die Unterkante ("]").
            //  Titel und Kopf stehen genau einmal im Balken oben.]
            // UMRANDUNG DER GANZEN FORM: Linien nur dort, wo der Termin an
            // Leere grenzt. Oben und unten jedes Tagesstuecks immer; links
            // nur am ersten Tag in voller Hoehe, am zweiten Tag von oben bis
            // zur Starthoehe des ersten (darunter grenzt er an den ersten);
            // rechts nur am letzten Tag in voller Hoehe, am vorletzten von
            // der Endhoehe des letzten bis unten. Zwischen zwei vollen
            // Tagen: keine Linie -- das waere Inneres.
            // AUSWAHL DEZENT: die Umrandung selbst wird heller und etwas
            // staerker -- kein zweiter Rahmen je Tagesspalte mehr.
            const float d = (selected || moving) ? 3.0f : 2.0f;
            const ImU32 rc = mitA((selected || moving) ? Darken(col, 1.45f) : col, 255);
            // Pixelgenau: Linien auf halbe Pixel setzen und an den Ecken um die
            // halbe Dicke verlaengern, damit Ober-/Unterkante und Seiten
            // luecken los aneinander stossen. Unterkante um die Dicke nach
            // innen, sonst liegt sie auf der Rasterkante und wird geschnitten.
            const float h = d * 0.5f;
            const float ya = std::floor(y0) + 0.5f, yb = std::floor(y1) - h;
            const float xa = std::floor(x0) + 0.5f, xb = std::floor(x1) - 0.5f;
            const bool obenKante  = seg.ersterTag;                       // echter Start -> Oberkante
            const bool untenKante = seg.letzterTag;                      // echtes Ende  -> Unterkante
            const bool tagDanach  = !seg.letzterTag;                     // das Stueck geht in den naechsten Tag
            const bool tagDavor   = !seg.ersterTag;
            if (obenKante)  dl->AddLine(ImVec2(xa - h, ya), ImVec2(xb + h, ya), rc, d);
            if (untenKante) dl->AddLine(ImVec2(xa - h, yb), ImVec2(xb + h, yb), rc, d);
            // Zwischen Mitternachten (Tagesstueck laeuft oben/unten weiter): die
            // Kante am Rasterrand ist eine Grenze des Termins -> ebenfalls Linie.
            if (tagDavor)   dl->AddLine(ImVec2(xa - h, ya), ImVec2(xb + h, ya), rc, d);
            if (tagDanach)  dl->AddLine(ImVec2(xa - h, yb), ImVec2(xb + h, yb), rc, d);
            // Seiten: links nur am ersten Tag ganz, am zweiten bis zur Starthoehe;
            // rechts nur am letzten Tag ganz, am vorletzten ab der Endhoehe.
            if (seg.ersterTag)            dl->AddLine(ImVec2(xa, ya - h), ImVec2(xa, yb + h), rc, d);
            else if (seg.tagVersatz == 1) dl->AddLine(ImVec2(xa, ya - h), ImVec2(xa, ImMin(std::floor(seg.eventY0) + 0.5f, yb) + h), rc, d);
            if (seg.letzterTag)                            dl->AddLine(ImVec2(xb, ya - h), ImVec2(xb, yb + h), rc, d);
            else if (seg.tagVersatz == seg.tageGesamt - 2) dl->AddLine(ImVec2(xb, ImMax(std::floor(seg.eventY1) + 0.5f, ya) - h), ImVec2(xb, yb + h), rc, d);
            if (istAktiv) {   // dezent, nur um die FORM: Seiten nur an echtem Anfang/Ende
                const ImU32 ak = IM_COL32(255, 200, 60, 110);
                dl->AddLine(ImVec2(x0 - 2, y0 - 2), ImVec2(x1 + 2, y0 - 2), ak, 2.0f);
                dl->AddLine(ImVec2(x0 - 2, y1 + 2), ImVec2(x1 + 2, y1 + 2), ak, 2.0f);
                if (seg.ersterTag)  dl->AddLine(ImVec2(x0 - 2, y0 - 2), ImVec2(x0 - 2, y1 + 2), ak, 2.0f);
                if (seg.letzterTag) dl->AddLine(ImVec2(x1 + 2, y0 - 2), ImVec2(x1 + 2, y1 + 2), ak, 2.0f);
            }
        } else {
            // Kopf SCHRAFFIERT (leichte schraege Striche in der Terminfarbe)
            // statt gefuellt; der Rand bleibt.
            Schraffur(dl, ImVec2(x0, y0), ImVec2(x1, kopfY1), mitA(col, 150));
            // RAND UM DIE GANZE DAUER statt des linksbuendigen Strichs; bei
            // Auswahl heller und staerker -- kein weisser Rahmen um den Kopf mehr.
            const ImU32 rr = mitA((selected || moving) ? Darken(col, 1.45f) : col, 255);
            dl->AddRect(ImVec2(x0, y0), ImVec2(x1, y1), rr, 4.0f, 0, (selected || moving) ? 3.0f : 2.0f);
            if (istAktiv) dl->AddRect(ImVec2(x0 - 2, y0 - 2), ImVec2(x1 + 2, y1 + 2), IM_COL32(255, 200, 60, 110), 4.0f, 0, 2.0f);   // dezent, um den ganzen Termin
        }
        // STIFTWERKZEUG: eigene Farbe (gelb), damit man Bulk-Auswahl und
        // normale Auswahl (weiss) auf einen Blick unterscheidet.
        if (penSel)
            dl->AddRect(ImVec2(x0 - 1.0f, y0 - 1.0f), ImVec2(x1 + 1.0f, kopfY1 + 1.0f),
                        IM_COL32(255, 220, 60, 230), 4.0f, 0, 3.0f);
        // STRICH: reicht die Dauer ueber den Kopf hinaus, zieht sich ein
        // GLEICHFARBIGER, LINKSBUENDIGER Strich (auf Hoehe des Versatzes)
        // bis zum tatsaechlichen Ende dieses Tagesabschnitts. [Vorher war
        // das GANZE Event ein ausgefuellter Block ueber die volle Dauer
        // -- das verdeckte das Raster darunter komplett und machte es
        // unmoeglich, dort noch eine Zeitmarke zu setzen oder mit dem
        // Stift zu zeichnen. Jetzt bleibt nur der Kopf blockierend, der
        // Rest ist ein duenner Strich, der das Raster daneben frei laesst.]
        // (der fruehere Strich unter dem Kopf ist durch den Rand ersetzt)

        // Zug an einem VIRTUELLEN Eintrag: Lage und Dauer fuer den naechsten
    // Frame merken (Range() baut die Kopie jeden Frame neu).
    if (C().drag.id && IstVirtuell(C().drag.id)) if (CalEntry* ve = UiCalendar_Find(C().drag.id)) { C().dragVirtStart = ve->start; C().dragVirtDur = ve->durMin; }
    // ZWEI PUNKT-GREIFER FUER DAS AUSGEWAEHLTE EVENT.
        // [Ein Punkt VOR dem Event setzt den START, ein Punkt NACH dem
        //  Event setzt das ENDE. GETRENNTE Bedingungen jetzt: der
        //  Start-Griff erscheint NUR am ERSTEN Tagessegment (dort liegt
        //  sein echter y0), der Ende-Griff NUR am LETZTEN (dort liegt
        //  sein echtes y1). Vorher erschienen -- wenn ein Termin ueber
        //  einem anderen lag -- die Griffe manchmal am FALSCHEN Event,
        //  weil beide Griffe an JEDEM Segment haengen wollten; durch die
        //  Staffelung UND diese Trennung ist jetzt jedes Segment
        //  eindeutig einem Event zugeordnet.]
        const float gr = ImMax(14.0f, ImGui::GetFrameHeight() * 0.42f);
        if (selected && seg.ersterTag) {
            const ImVec2 gs((x0 + x1) * 0.5f, y0 - gr * 1.9f - 3.0f);     // mit Abstand: der Rand bleibt sichtbar
            ImGui::SetCursorScreenPos(ImVec2(gs.x - gr, gs.y - gr));
            ImGui::InvisibleButton("##grip_s", ImVec2(gr * 2, gr * 2));
            const bool gsAct = ImGui::IsItemActive();
            if (ImGui::IsItemActivated()) {
                C().drag.id = e->id; C().drag.armed = false;
                C().drag.active = true; C().drag.resizing = false;
                C().drag.grip = 1;                     // 1 = Start-Griff
                C().drag.origStart = e->start; C().drag.origDur = e->durMin;
                C().selected = e->id;
                Claim();
            }
            if (gsAct && C().drag.id == e->id && C().drag.grip == 1) {
                Claim();
                // TAG *UND* UHRZEIT AUS DER ZEIGERPOSITION -- UNBEGRENZT,
                // auch taguebergreifend (siehe fruehere Begruendung).
                const ImVec2 mpS = ImGui::GetIO().MousePos;
                const int ndiS = (int)std::floor((mpS.x - org.x - gutter) / colW);
                const double hS = (mpS.y - org.y) / C().pxPerHour;
                std::int64_t neuerStart = SnapTime(
                    XbmTime_AddDays(C().anchor, ndiS) + (std::int64_t)(hS * 3600.0));
                const std::int64_t origEnde = C().drag.origStart
                                            + (std::int64_t)C().drag.origDur * 60;
                UiCalendar_EventStartSetzen(*e, neuerStart);
                if (neuerStart < origEnde - 300) {
                    // Normaler Fall: Ende bleibt fest, Dauer passt sich an.
                    e->durMin = (int)((origEnde - neuerStart) / 60);
                } else {
                    // START UEBER DAS (URSPRUENGLICHE) ENDE HINAUS GEZOGEN:
                    // das Ende "springt mit", behaelt aber die
                    // URSPRUENGLICHE Dauer -- so wie du es beschrieben
                    // hast ("mit der gleichen Dauer, wie es vorher
                    // hatte"). [Vorher wurde die Aktualisierung hier
                    // einfach BLOCKIERT (if (neuerStart < ende-300)),
                    // solange man ueber diesen Punkt hinauszog -- der
                    // Griff blieb optisch stehen, obwohl der Finger
                    // weiterzog. Das war das gemeldete "es stockt bei
                    // einer gewissen Dauer". Jetzt wird IMMER
                    // aktualisiert, nur das VERHALTEN wechselt an diesem
                    // Punkt von "Dauer aendern" zu "ganzes Event
                    // verschieben".]
                    e->durMin = C().drag.origDur < 5 ? 5 : C().drag.origDur;
                }
                C().dirty = true;
            }
            if (ImGui::IsItemDeactivated() && C().drag.id == e->id
                && C().drag.grip == 1) {
                if (IstVirtuell(e->id)) {
                    if (UnterTerminFestschreiben(e->id, e->start, e->durMin)) UiCalendar_TimelineNeuLaden();
                    else if (const CalState::VirtOcc* v = VirtOccFuer(e->id)) { if (!v->kind && (e->start != v->occStart || e->durMin != C().drag.origDur)) C().serienZug = { true, v->base, v->occStart, e->start, e->durMin }; }
                }
                else { UiCalendar_Touch(e->id); SaveNow(); }
                C().drag = DragState{};
            }
            // NICHT waehrend eines Tipps/Drucks anzeigen -- auf Touch
            // faellt "hover" mit dem Aufsetzen des Fingers zusammen, das
            // Overlay poppte also bei JEDEM Antippen auf und store die
            // Bedienung. Nur bei echtem Hover OHNE gehaltene Maustaste.
            if (ImGui::IsItemHovered() && !ImGui::GetIO().MouseDown[0])
                ImGui::SetTooltip("Start ziehen -- auch auf andere Tage");
            dl->ChannelsSetCurrent(1);
            dl->AddCircleFilled(gs, gr, IM_COL32(255, 255, 255, 235));
            dl->AddCircle(gs, gr, Darken(EntryColor(*e), 0.6f), 12, 2.0f);
            dl->ChannelsSetCurrent(0);
        }
        if (selected && seg.letzterTag) {
            const ImVec2 ge((x0 + x1) * 0.5f, y1 + gr * 1.9f + 3.0f);
            ImGui::SetCursorScreenPos(ImVec2(ge.x - gr, ge.y - gr));
            ImGui::InvisibleButton("##grip_e", ImVec2(gr * 2, gr * 2));
            const bool geAct = ImGui::IsItemActive();
            if (ImGui::IsItemActivated()) {
                C().drag.id = e->id; C().drag.armed = false;
                C().drag.active = true; C().drag.resizing = false;
                C().drag.grip = 2;                     // 2 = Ende-Griff
                C().drag.origStart = e->start; C().drag.origDur = e->durMin;
                C().selected = e->id;
                Claim();
            }
            if (geAct && C().drag.id == e->id && C().drag.grip == 2) {
                Claim();
                // Dieselbe unbegrenzte Spalten+Stunden-Rechnung wie beim
                // Start-Griff -- siehe dessen Begruendung weiter oben.
                const ImVec2 mpE = ImGui::GetIO().MousePos;
                const int ndiE = (int)std::floor((mpE.x - org.x - gutter) / colW);
                const double hE = (mpE.y - org.y) / C().pxPerHour;
                std::int64_t neuesEnde = SnapTime(
                    XbmTime_AddDays(C().anchor, ndiE) + (std::int64_t)(hE * 3600.0));
                const std::int64_t origStart = C().drag.origStart;
                const std::int64_t origDurSek = (std::int64_t)C().drag.origDur * 60;
                if (neuesEnde > origStart + 300) {
                    // Normaler Fall: Ende aendert die Dauer, Start bleibt
                    // am URSPRUENGLICHEN Wert -- nicht am aktuellen, damit
                    // ein Zug, der vorher schon einmal ueber den Start
                    // hinausging (siehe unten) sauber zurueckspringt,
                    // sobald man wieder in den Normalbereich zieht.
                    if (e->start != origStart) UiCalendar_EventStartSetzen(*e, origStart);
                    e->durMin = (int)((neuesEnde - origStart) / 60);
                } else {
                    // ENDE VOR DEN URSPRUENGLICHEN START GEZOGEN: der
                    // Start wird ZURUECKGEDRAENGT (in die Vergangenheit),
                    // behaelt dabei die URSPRUENGLICHE Dauer -- das Ende
                    // folgt weiterhin genau dem Finger. Genau symmetrisch
                    // zum Start-Griff, der beim Ueberschreiten des Endes
                    // dasselbe umgekehrt tut.
                    UiCalendar_EventStartSetzen(*e, neuesEnde - origDurSek);
                    e->durMin = C().drag.origDur < 5 ? 5 : C().drag.origDur;
                }
                C().dirty = true;
            }
            if (ImGui::IsItemDeactivated() && C().drag.id == e->id
                && C().drag.grip == 2) {
                if (IstVirtuell(e->id)) {
                    if (UnterTerminFestschreiben(e->id, e->start, e->durMin)) UiCalendar_TimelineNeuLaden();
                    else if (const CalState::VirtOcc* v = VirtOccFuer(e->id)) { if (!v->kind && (e->start != v->occStart || e->durMin != C().drag.origDur)) C().serienZug = { true, v->base, v->occStart, e->start, e->durMin }; }
                }
                else { UiCalendar_Touch(e->id); SaveNow(); }
                C().drag = DragState{};
            }
            if (ImGui::IsItemHovered() && !ImGui::GetIO().MouseDown[0])
                ImGui::SetTooltip("Ende ziehen -- auch auf andere Tage");
            dl->ChannelsSetCurrent(1);
            dl->AddCircleFilled(ge, gr, IM_COL32(255, 255, 255, 235));
            dl->AddCircle(ge, gr, Darken(EntryColor(*e), 0.6f), 12, 2.0f);
            dl->ChannelsSetCurrent(0);
        }

        // KEINE UHRZEIT IM KOPF (die steht links in der Spalte). Passt der
        // Titel in EINE Zeile in den Kopf, steht er dort; sonst wird er ein
        // freischwebendes LABEL (siehe nach der Schleife): nur Orientierung,
        // keine Geste, darf ueber den Kopf hinausragen, ausweichen und
        // umbrechen. Mehrtaegig: Titel steht im Balken oben.
        // Mehrtaegig ohne sichtbaren Start: das erste sichtbare Stueck traegt
        // den Titel als Label oben links.
        const bool erstesSichtbar = seg.mehrtaegig && (!seg.ersterTag || e->allDay) && !beschriftet.count(e->id)
                                    && [&]{ for (const Segment& o : segmente) if (o.e == e && o.tagVersatz < seg.tagVersatz) return false; return true; }();
        const bool textHier = kopfHier;
        if (seg.mehrtaegig) beschriftet.insert(e->id);
        if (erstesSichtbar && !e->title.empty()) {
            // Label an der SICHTBAREN Oberkante (ganztaegig beginnt um 0:00, das liegt meist ausserhalb)
            const float ly = ImMax(y0, ImGui::GetWindowPos().y + 2.0f);
            labels.push_back({ e->title, x0, x1, ly, ly + 2.0f, EntryColor(*e), stufe, e->id });
        }
        dl->PushClipRect(ImVec2(x0 + 4, y0 + 1), ImVec2(x1 - 2, textHier ? kopfY1 - 1 : y0 + 1), true);
        const float verf = (x1 - 2) - (x0 + 6);
        const float lineHpx = ImGui::GetTextLineHeight();
        float curY = y0 + 2;
        if (textHier && !e->title.empty()) {
            const float tb = ImGui::CalcTextSize(e->title.c_str()).x;
            if (tb <= verf && curY + lineHpx <= kopfY1 - 1) {
                dl->AddText(ImVec2(x0 + 6, curY), IM_COL32(255, 255, 255, (int)(245 * stufe)), e->title.c_str());
                curY += lineHpx;
            } else {
                labels.push_back({ e->title, x0, x1, y0, kopfY1, EntryColor(*e), stufe, e->id });
            }
        }
        if (textHier && !e->notes.empty() && curY + lineHpx <= kopfY1 - 1)
            dl->AddText(ImVec2(x0 + 6, curY), IM_COL32(255, 255, 255, 175), e->notes.c_str());
        if (!e->audio.empty())
            dl->AddCircleFilled(ImVec2(x1 - 8, y0 + 8), 3.5f,
                                IM_COL32(255, 255, 255, 200));
        dl->PopClipRect();

        // NICHT anzeigen, waehrend gerade getippt/gedrueckt wird -- das
        // war das gemeldete "Overlay stoert bei jedem Tap": auf Touch
        // faellt "hover" mit dem Aufsetzen des Fingers zusammen, das
        // Infofenster ploppte also bei JEDEM blossen Antippen auf, noch
        // bevor irgendetwas anderes passierte.
        if (hov && !moving && !ImGui::GetIO().MouseDown[0]) {
            ImGui::SetTooltip("%s\n%s - %s  (%d min)%s",
                e->title.empty() ? "(ohne Titel)" : e->title.c_str(),
                XbmTime_Format(e->start, "%a %d.%m. %H:%M").c_str(),
                XbmTime_Format(e->end(), "%H:%M").c_str(),
                e->durMin,
                e->notes.empty() ? "" : ("\n" + e->notes).c_str());
        }
        ImGui::PopID();

        // ---- ACTIONS / ERINNERUNGEN DES AUSGEWAEHLTEN EVENTS ----------
        // [Nur beim ausgewaehlten Event, halbdurchsichtig in seiner
        //  Farbe -- so wie du es beschrieben hast. Das Mutter-Event
        //  bleibt ausgewaehlt, waehrend man eine Action anfasst: das
        //  Anklicken setzt nur C().actionSel, nicht C().selected.]
        // Nur EINMAL je Event -- am ERSTEN Tagessegment -- sonst wuerden
        // die Erinnerungen eines mehrtaegigen Events an JEDEM Tag, den es
        // beruehrt, ein weiteres Mal gezeichnet.
        if (seg.ersterTag && C().selected == e->id && !e->actions.empty()) {
            // UEBERLAPPUNGS-STAFFELUNG AUCH FUER ERINNERUNGEN.
            // [Liegen zwei Erinnerungen zeitlich ineinander, lagen ihre
            //  Flaechen bisher exakt uebereinander -- die weiter unten
            //  (spaeter gezeichnete) gewann jeden Druck, die andere war
            //  mit ihren Griffen nicht mehr zu erreichen. Derselbe
            //  Versatz-Trick wie bei den Events: ein Schritt nach rechts
            //  pro zusaetzlicher zeitlicher Ueberlappung.]
            std::vector<float> aBelegtY0, aBelegtY1;
            for (size_t ai = 0; ai < e->actions.size(); ++ai) {
                CalAction& a = e->actions[ai];
                const int adi = DayIndexOf(a.start, C().anchor, days);
                if (adi < 0) continue;                 // liegt nicht im Blick
                const std::int64_t tag0 = XbmTime_AddDays(C().anchor, adi);
                const double ah0 = (double)(a.start - tag0) / 3600.0;
                const double ah1 = ah0 + (a.durMin > 0 ? a.durMin / 60.0 : 0.0);
                float ay0 = org.y + (float)ah0 * C().pxPerHour;
                float ay1 = org.y + (float)ah1 * C().pxPerHour;
                if (ay1 - ay0 < 12.0f) ay1 = ay0 + 12.0f;   // antippbar

                int aIndent = 0;
                for (size_t k = 0; k < aBelegtY0.size(); ++k)
                    if (ay0 < aBelegtY1[k] && ay1 > aBelegtY0[k]) ++aIndent;
                aBelegtY0.push_back(ay0); aBelegtY1.push_back(ay1);
                const float aIndentPx = ImClamp(colW * 0.07f, 6.0f, 14.0f);   // gedeckelt, wie oben
                const float ax0 = org.x + gutter + colW * adi + 2.0f + aIndent * aIndentPx;
                float ax1 = ax0 + colW * 0.55f;
                const float spaltenRand = org.x + gutter + colW * (adi + 1) - 6.0f;
                if (ax1 > spaltenRand) ax1 = spaltenRand;
                if (ax1 - ax0 < 12.0f) ax1 = ax0 + 12.0f;   // nie ganz verschwinden

                ImGui::SetCursorScreenPos(ImVec2(ax0, ay0));
                ImGui::PushID((int)(a.id & 0x7fffffff));
                ImGui::InvisibleButton("##act", ImVec2(ax1 - ax0, ay1 - ay0));
                const bool ahov = ImGui::IsItemHovered();

                // KEIN Ziehen mehr auf dem Koerper selbst -- der Koerper
                // WAEHLT nur noch aus. [Das war der gemeldete Fehler
                // "ziehen zum verschieben geht nicht": MouseDelta-basiertes
                // Ziehen auf derselben Flaeche wie das Anklicken ist auf
                // Touch unzuverlaessig UND kollidierte mit den Griffen des
                // EVENTS, die oft in unmittelbarer Naehe liegen. Jetzt gibt
                // es dafuer drei EIGENE, weiter rechts liegende Griffe --
                // siehe unten -- die nie mit den Event-Griffen ueberlappen.]
                if (ImGui::IsItemClicked()) C().actionSel = a.id;
                if (ImGui::IsItemDeactivated() && !ahov) UiCalendar_Save();

                // Farbe des Events, halb durchsichtig.
                const ImU32 voll = EntryColor(*e);   // heisst so, nicht EventColor
                ImU32 halb = (voll & 0x00FFFFFFu)
                           | ((ImU32)(((voll >> 24) & 0xFF) / 2) << 24);
                ImDrawList* dl2 = ImGui::GetWindowDrawList();
                dl2->AddRectFilled(ImVec2(ax0, ay0), ImVec2(ax1, ay1), halb, 3.0f);
                const bool gewaehlt = (C().actionSel == a.id);
                dl2->AddRect(ImVec2(ax0, ay0), ImVec2(ax1, ay1),
                             gewaehlt ? IM_COL32(255, 255, 255, 230)
                                      : (ahov ? IM_COL32(255, 255, 255, 140)
                                              : (voll & 0x00FFFFFFu) | 0x80000000u),
                             3.0f, 0, gewaehlt ? 2.0f : 1.0f);

                // BESCHRIFTUNG: Glocke + entweder ein lebender COUNTDOWN
                // (bis zum Start) bzw. COUNTER (seit dem Start, waehrend
                // der Zeitspanne aktiv), oder -- ausserhalb beider
                // Zeitfenster -- wie bisher der feste Abstand.
                // [Erinnerungen haben jetzt eine Zeitspanne wie ein Event
                //  (CalAction::durMin) -- "aktiv" heisst: die aktuelle
                //  Uhrzeit liegt zwischen Start und Start+Dauer.]
                const std::int64_t jetztUtc = XbmTime_NowUtc();
                char at[64];
                if (jetztUtc < a.start) {
                    long bisStart = (long)(a.start - jetztUtc);
                    ImFormatString(at, sizeof(at), "%s in %ldm %02lds",
                                   a.art == CalActionArt::Alarm ? "\xf0\x9f\x94\x94" : "\xe2\x96\xb6",
                                   bisStart / 60, bisStart % 60);
                } else if (a.durMin > 0 && jetztUtc < a.end()) {
                    long seitStart = (long)(jetztUtc - a.start);
                    ImFormatString(at, sizeof(at), "%s laeuft %ldm %02lds",
                                   a.art == CalActionArt::Alarm ? "\xf0\x9f\x94\x94" : "\xe2\x96\xb6",
                                   seitStart / 60, seitStart % 60);
                } else {
                    long vm = (long)((e->start - a.start) / 60);
                    ImFormatString(at, sizeof(at), "%s %ld min",
                                   a.art == CalActionArt::Alarm ? "\xf0\x9f\x94\x94" : "\xe2\x96\xb6",
                                   vm >= 0 ? vm : -vm);
                }
                dl2->AddText(ImVec2(ax0 + 4.0f, ay0 + 1.0f),
                             IM_COL32(255, 255, 255, 220), at);
                if (ahov && !ImGui::GetIO().MouseDown[0])
                    ImGui::SetTooltip("Erinnerung -- rechts: Griffe zum "
                                      "Verschieben/Start/Ende, anklicken zum Bearbeiten");

                // DREI GRIFFE, WEITER RECHTS -- VERSCHIEBEN, START, ENDE.
                // [Damit man beim Veraendern der Erinnerung nicht aus
                //  Versehen die Griffe des EVENTS erwischt (die sitzen
                //  mittig ueber/unter dessen Kopf und liegen oft in
                //  unmittelbarer Naehe): alle drei Griffe der Erinnerung
                //  liegen rechts DANEBEN, nicht darueber/darunter am
                //  selben Punkt. Der Verschiebe-Griff sitzt am naechsten
                //  (ueber der Erinnerung), Start und Ende noch weiter
                //  rechts, jeweils ueber bzw. unter ihr -- so trifft man
                //  nie zwei Griffe gleichzeitig.]
                if (gewaehlt) {
                    const float grA = ImMax(11.0f, ImGui::GetFrameHeight() * 0.34f);
                    const float spalte1 = ax1 + grA * 1.4f;
                    const float spalte2 = ax1 + grA * 3.4f;

                    // GRIFF 1: VERSCHIEBEN (Position). Rechts, ueber der
                    // Erinnerung. Folgt direkt dem Finger -- Tag UND
                    // Uhrzeit aus der Zeigerposition, wie beim Event.
                    const ImVec2 gm(spalte1, ay0 - grA - 1.0f);
                    ImGui::SetCursorScreenPos(ImVec2(gm.x - grA, gm.y - grA));
                    ImGui::InvisibleButton("##agrip_m", ImVec2(grA * 2, grA * 2));
                    if (ImGui::IsItemActivated()) {
                        C().drag.id = a.id; C().drag.grip = 3;   // 3 = Erinnerung verschieben
                        C().drag.ownerEventId = e->id;
                        C().drag.origStart = a.start; C().drag.origDur = a.durMin;
                        C().actionSel = a.id;
                        Claim();
                    }
                    if (ImGui::IsItemActive() && C().drag.id == a.id && C().drag.grip == 3) {
                        Claim();
                        const ImVec2 mpM = ImGui::GetIO().MousePos;
                        const int ndiM = (int)std::floor((mpM.x - org.x - gutter) / colW);
                        const double hM = (mpM.y - org.y) / C().pxPerHour;
                        a.start = SnapTime(XbmTime_AddDays(C().anchor, ndiM)
                                          + (std::int64_t)(hM * 3600.0));
                        UiCalendar_Touch(e->id);
                    }
                    if (ImGui::IsItemDeactivated() && C().drag.id == a.id
                        && C().drag.grip == 3) {
                        UiCalendar_Save();
                        C().drag = DragState{};
                    }
                    if (ImGui::IsItemHovered() && !ImGui::GetIO().MouseDown[0])
                        ImGui::SetTooltip("Erinnerung verschieben");
                    dl2->ChannelsSetCurrent(1);
                    dl2->AddCircleFilled(gm, grA, IM_COL32(255, 255, 255, 235));
                    dl2->AddCircle(gm, grA, Darken(voll, 0.6f), 12, 2.0f);
                    dl2->ChannelsSetCurrent(0);

                    // GRIFF 2: START. Noch weiter rechts, ueber der
                    // Erinnerung. Ende bleibt fest, Dauer passt sich an.
                    const ImVec2 gs(spalte2, ay0 - grA - 1.0f);
                    ImGui::SetCursorScreenPos(ImVec2(gs.x - grA, gs.y - grA));
                    ImGui::InvisibleButton("##agrip_s", ImVec2(grA * 2, grA * 2));
                    if (ImGui::IsItemActivated()) {
                        C().drag.id = a.id; C().drag.grip = 4;   // 4 = Erinnerung-Start
                        C().drag.ownerEventId = e->id;
                        C().drag.origStart = a.start; C().drag.origDur = a.durMin;
                        C().actionSel = a.id;
                        Claim();
                    }
                    if (ImGui::IsItemActive() && C().drag.id == a.id && C().drag.grip == 4) {
                        Claim();
                        const ImVec2 mpS = ImGui::GetIO().MousePos;
                        const int ndiS = (int)std::floor((mpS.x - org.x - gutter) / colW);
                        const double hS = (mpS.y - org.y) / C().pxPerHour;
                        std::int64_t neuerStart = SnapTime(
                            XbmTime_AddDays(C().anchor, ndiS) + (std::int64_t)(hS * 3600.0));
                        const std::int64_t origEnde = C().drag.origStart
                                                    + (std::int64_t)C().drag.origDur * 60;
                        a.start = neuerStart;
                        if (neuerStart < origEnde - 300) {
                            a.durMin = (int)((origEnde - neuerStart) / 60);
                        } else {
                            // Dieselbe Regel wie beim Event: Ende springt
                            // mit der urspruenglichen Dauer mit, statt zu
                            // blockieren.
                            a.durMin = C().drag.origDur < 5 ? 5 : C().drag.origDur;
                        }
                        UiCalendar_Touch(e->id);
                    }
                    if (ImGui::IsItemDeactivated() && C().drag.id == a.id
                        && C().drag.grip == 4) {
                        UiCalendar_Save();
                        C().drag = DragState{};
                    }
                    if (ImGui::IsItemHovered() && !ImGui::GetIO().MouseDown[0])
                        ImGui::SetTooltip("Start der Erinnerung ziehen");
                    dl2->ChannelsSetCurrent(1);
                    dl2->AddCircleFilled(gs, grA, IM_COL32(255, 255, 255, 235));
                    dl2->AddCircle(gs, grA, Darken(voll, 0.6f), 12, 2.0f);
                    dl2->ChannelsSetCurrent(0);

                    // GRIFF 3: ENDE. Noch weiter rechts, UNTER der
                    // Erinnerung. Start bleibt fest, Dauer passt sich an
                    // -- damit haben Erinnerungen jetzt eine echte
                    // Zeitspanne, genau wie ein Event.
                    const ImVec2 ge(spalte2, ay1 + grA + 1.0f);
                    ImGui::SetCursorScreenPos(ImVec2(ge.x - grA, ge.y - grA));
                    ImGui::InvisibleButton("##agrip_e", ImVec2(grA * 2, grA * 2));
                    if (ImGui::IsItemActivated()) {
                        C().drag.id = a.id; C().drag.grip = 5;   // 5 = Erinnerung-Ende
                        C().drag.ownerEventId = e->id;
                        C().drag.origStart = a.start; C().drag.origDur = a.durMin;
                        C().actionSel = a.id;
                        Claim();
                    }
                    if (ImGui::IsItemActive() && C().drag.id == a.id && C().drag.grip == 5) {
                        Claim();
                        const ImVec2 mpE = ImGui::GetIO().MousePos;
                        const int ndiE = (int)std::floor((mpE.x - org.x - gutter) / colW);
                        const double hE = (mpE.y - org.y) / C().pxPerHour;
                        std::int64_t neuesEnde = SnapTime(
                            XbmTime_AddDays(C().anchor, ndiE) + (std::int64_t)(hE * 3600.0));
                        const std::int64_t origStart = C().drag.origStart;
                        const std::int64_t origDurSek = (std::int64_t)C().drag.origDur * 60;
                        if (neuesEnde > origStart + 300) {
                            if (a.start != origStart) a.start = origStart;
                            a.durMin = (int)((neuesEnde - origStart) / 60);
                        } else {
                            // Dieselbe Rueckdraengung wie beim Event: der
                            // Start weicht in die Vergangenheit, behaelt
                            // die urspruengliche Dauer.
                            a.start = neuesEnde - origDurSek;
                            a.durMin = C().drag.origDur < 5 ? 5 : C().drag.origDur;
                        }
                        UiCalendar_Touch(e->id);
                    }
                    if (ImGui::IsItemDeactivated() && C().drag.id == a.id
                        && C().drag.grip == 5) {
                        UiCalendar_Save();
                        C().drag = DragState{};
                    }
                    if (ImGui::IsItemHovered() && !ImGui::GetIO().MouseDown[0])
                        ImGui::SetTooltip("Ende der Erinnerung ziehen");
                    dl2->ChannelsSetCurrent(1);
                    dl2->AddCircleFilled(ge, grA, IM_COL32(255, 255, 255, 235));
                    dl2->AddCircle(ge, grA, Darken(voll, 0.6f), 12, 2.0f);
                    dl2->ChannelsSetCurrent(0);
                }

                ImGui::PopID();
            }
        }
    }

    // FEHLTE BISHER: ChannelsMerge() -- ohne diesen Aufruf blieb der
    // Drawlist in aufgeteiltem Zustand haengen. Kanal 1 (die Griffe)
    // wurde dadurch entweder gar nicht zuverlaessig eingefuegt oder es
    // blieb ein offener Aufteilungs-Zustand fuer den Rest des Frames
    // bestehen, der sich auf NACHFOLGEND gezeichnete UI-Elemente
    // auswirken konnte -- das erklaert vermutlich auch "manchmal
    // tauchen die Greifer vom umschliessenden Element auf". Jetzt wird
    // sauber zusammengefuehrt: Kanal 1 (Griffe) landet garantiert NACH
    // Kanal 0 (alle Koerper), unabhaengig von der Zeichenreihenfolge.
    // ---- FREISCHWEBENDE TITEL-LABELS ------------------------------------
    // [Ein Label beginnt am Kopf (links oben) und darf nach rechts ueber
    //  den Kopf hinausragen. Erreicht es den rechten Rand des Rasters,
    //  wird es nach links geschoben; reicht auch der linke Rand nicht,
    //  bricht es in mehrere Zeilen um. Ueberdeckt es ein schon gesetztes
    //  Label, rueckt es zeilenweise nach unten. Liegt es nicht mehr ueber
    //  seinem Kopf, zeigt ein duenner Strich auf den Kopf. Gezeichnet auf
    //  Kanal 1 (ueber allen Bloecken), ohne eigenes Item -- keine Geste.]
    if (!labels.empty()) {
        dl->ChannelsSetCurrent(1);
        const float lh = ImGui::GetTextLineHeight();
        const float rasterL = org.x + gutter + 2.0f, rasterR = org.x + gutter + colW * days - 4.0f;
        struct Belegt { float x0, y0, x1, y1; };
        std::vector<Belegt> belegt;
        auto frei = [&](float ax0, float ay0, float ax1, float ay1) {
            for (const Belegt& b : belegt) if (ax0 < b.x1 && ax1 > b.x0 && ay0 < b.y1 && ay1 > b.y0) return false;
            return true;
        };
        for (const TitelLabel& L : labels) {
            std::vector<std::string> zeilen;
            const float maxB = rasterR - rasterL - 8.0f;
            std::string rest = L.text;
            while (!rest.empty() && zeilen.size() < 4) {
                if (ImGui::CalcTextSize(rest.c_str()).x <= maxB) { zeilen.push_back(rest); break; }
                size_t brk = rest.size();
                for (size_t i = 1; i <= rest.size(); ++i) if (ImGui::CalcTextSize(rest.substr(0, i).c_str()).x > maxB) { brk = i - 1; break; }
                if (brk == 0) brk = 1;
                size_t sp = rest.rfind(' ', brk); if (sp != std::string::npos && sp > 0) brk = sp + 1;
                zeilen.push_back(rest.substr(0, brk)); rest = rest.substr(brk);
            }
            float breite = 0; for (auto& z2 : zeilen) breite = ImMax(breite, ImGui::CalcTextSize(z2.c_str()).x);
            const float hoehe = lh * (float)zeilen.size();
            float lx = L.x0 + 4.0f, ly = L.y0 + 2.0f;
            if (lx + breite + 6.0f > rasterR) lx = rasterR - breite - 6.0f;   // rechts: nach links ausweichen
            if (lx < rasterL) lx = rasterL;
            for (int versuch = 0; versuch < 8 && !frei(lx - 2, ly - 1, lx + breite + 4, ly + hoehe + 1); ++versuch) ly += lh;   // ueberdeckt: nach unten
            belegt.push_back({ lx - 2, ly - 1, lx + breite + 4, ly + hoehe + 1 });
            const bool ueberKopf = (lx + breite * 0.5f >= L.x0 && lx + breite * 0.5f <= L.x1 && ly < L.y1);
            if (!ueberKopf) {   // Verweisstrich vom Label zum Kopf
                const ImVec2 von(lx + ImMin(breite, 12.0f), ly + hoehe * 0.5f);
                const ImVec2 zu(ImClamp(von.x, L.x0 + 3.0f, L.x1 - 3.0f), L.y0 + 3.0f);
                dl->AddLine(von, zu, IM_COL32(230, 230, 230, 120), 1.0f);
            }
            // LABEL-HINTERGRUND wie die Terminflaeche: gleiche Farbe, gleiche
            // starke Transparenz, einfach obenauf -- ueber dem Kopf addiert es
            // sich bewusst ein zweites Mal. Die Schrift in der Terminfarbe.
            dl->AddRectFilled(ImVec2(lx - 2, ly - 1), ImVec2(lx + breite + 4, ly + hoehe + 1), (L.farbe & 0x00ffffff) | ((ImU32)(46 * L.stufe + 0.5f) << 24), 3.0f);
            const ImU32 schrift = (L.farbe & 0x00ffffff) | ((ImU32)(255 * L.stufe + 0.5f) << 24);
            float zy = ly; for (auto& z2 : zeilen) { dl->AddText(ImVec2(lx + 2.0f, zy), schrift, z2.c_str()); zy += lh; }
            // TIPP AUF DAS LABEL waehlt den Termin aus und oeffnet den Editor
            // (nur ein Tipp -- kein Zug, keine Geste; der Druck wird nicht beansprucht).
            {
                ImGui::SetCursorScreenPos(ImVec2(lx - 2, ly - 1)); ImGui::PushID((int)(L.id & 0x7fffffff) ^ 0x3c3c);
                ImGui::InvisibleButton("##label", ImVec2(breite + 6.0f, hoehe + 2.0f));
                if (ImGui::IsItemClicked() && !C().drag.id) { C().selected = L.id; EditorOeffnen(L.id); }
                ImGui::PopID();
            }
        }
        dl->ChannelsSetCurrent(0);
    }
    dl->ChannelsMerge();

    // AUFGESCHOBENES LOESCHEN NACH DREIFACH-TIPP.
    // [NICHT mitten in der obigen Schleife loeschen: UiCalendar_Remove
    //  aendert C().entries, und die Schleife haelt noch rohe Zeiger auf
    //  Eintraege in genau diesem Vektor -- ein Loeschen waehrenddessen
    //  waere ein klassischer Iterator-auf-veraendertem-Container-Fehler
    //  (Absturzrisiko fuer den Rest dieses Frames). Deshalb wird nur
    //  eine Kennung VORGEMERKT (siehe die Klick-Behandlung oben) und
    //  hier, NACH der Schleife, sicher geloescht.]
    if (C().zuLoeschenNachSchleife != 0) {
        UiCalendar_Remove(C().zuLoeschenNachSchleife);
        C().zuLoeschenNachSchleife = 0;
        C().tripleTapId[0] = C().tripleTapId[1] = C().tripleTapId[2] = 0;
    }

    // --- Leere Flaeche: antippen waehlt einen Zeitpunkt, Ziehen scrollt ---
    //
    // REIHENFOLGE IST HIER ENTSCHEIDEND und der Grund, warum dieser Block
    // NACH den Eintraegen steht: Bei zwei ueberlappenden Items im selben
    // ImGui-Fenster bekommt das ZUERST submittete den Druck (das spaetere
    // scheitert in ItemHoverable an "g.ActiveId != 0"). Stuende dieser
    // bildschirmfuellende Button vor den Eintraegen, waere KEIN einziger
    // Termin mehr anklickbar oder ziehbar -- der Hintergrund fraesse jeden
    // Druck. Zuletzt submittet bekommt er nur, was kein Eintrag beansprucht.
    ImGui::SetCursorScreenPos(org);
    ImGui::InvisibleButton("##calbg", ImVec2(avail, totalH),
                           ImGuiButtonFlags_MouseButtonLeft);

    // STIFT AKTIV: Ziehen auf freier Flaeche zeichnet eine Zeitspanne
    // und legt beim Loslassen ein neues Event genau darueber an.
    // [Eigener Zweig VOR dem normalen Scroll-Verhalten -- mit
    //  aktiviertem Stift soll ein Zug auf leerer Flaeche NIE scrollen,
    //  sondern immer zeichnen. Die Spalte (der Tag) wird vom AUFSETZ-
    //  PUNKT festgehalten: zieht der Finger in eine andere Spalte, zaehlt
    //  trotzdem die Startspalte, damit aus einem leicht schraegen Zug
    //  kein Eintrag entsteht, der ueber mehrere Tage "hin- und
    //  herspringt". Nur die senkrechte Position bestimmt das Ende.]
    if (C().penActive) {
        if (ImGui::IsItemActivated()) {
            const ImVec2 mp = ImGui::GetIO().MousePos;
            // DOPPELTIPP/-KLICK, DER DIESEN ZUG STARTET, KEHRT DIE
            // WIRKUNG UM. [IsMouseDoubleClicked ist genau in dem Frame
            //  wahr, in dem der zweite Klick registriert wird -- also
            //  demselben Frame, in dem IsItemActivated fuer diesen
            //  zweiten Klick ebenfalls feuert.]
            C().penZugAktiv  = true;
            C().penZugPressPx = mp;
            C().penZugInvert = ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left);

            int di = (int)((mp.x - org.x - gutter) / colW);
            if (di < 0) di = 0; if (di >= days) di = days - 1;
            const std::int64_t day = XbmTime_AddDays(C().anchor, di);
            const double hours = (mp.y - org.y) / C().pxPerHour;
            const std::int64_t t = SnapTime(day + (std::int64_t)(hours * 3600.0));
            C().penZeichnetAktiv = true;
            C().penZeichnetStart = t;
            C().penZeichnetEnde  = t;
        }
        if (ImGui::IsItemActive() && C().penZugAktiv) {
            Claim();
            const ImVec2 mp = ImGui::GetIO().MousePos;
            int di = (int)((mp.x - org.x - gutter) / colW);
            if (di < 0) di = 0; if (di >= days) di = days - 1;
            // Feste Startspalte fuer die Zeitspannen-Vorschau -- siehe
            // Begruendung in der vorigen Runde. Bei der Rechteck-Auswahl
            // spielt die Spalte ohnehin keine Rolle, dort zaehlt nur das
            // Bildschirm-Rechteck (weiter unten bei IsItemDeactivated).
            const std::int64_t startDay = XbmTime_LocalMidnight(C().penZeichnetStart);
            const double hours = (mp.y - org.y) / C().pxPerHour;
            C().penZeichnetEnde = SnapTime(startDay + (std::int64_t)(hours * 3600.0));
        }
        if (ImGui::IsItemDeactivated() && C().penZugAktiv) {
            C().penZugAktiv = false;
            C().penZeichnetAktiv = false;
            const ImVec2 mpEnd = ImGui::GetIO().MousePos;

            // UEBERDECKT DER GEZOGENE BEREICH VORHANDENE EVENTS?
            // [Dieselbe Geometrieformel wie beim Zeichnen der Events
            //  weiter oben (x0/x1/y0/y1) -- so stimmt die Ueberdeckung
            //  exakt mit dem ueberein, was der Nutzer auf dem Schirm
            //  sieht.]
            const float rx0 = std::min(C().penZugPressPx.x, mpEnd.x);
            const float rx1 = std::max(C().penZugPressPx.x, mpEnd.x);
            const float ry0 = std::min(C().penZugPressPx.y, mpEnd.y);
            const float ry1 = std::max(C().penZugPressPx.y, mpEnd.y);
            std::vector<std::uint64_t> getroffen;
            for (CalEntry* e : vis) {
                if (e->allDay) continue;
                const int edi = DayIndexOf(e->start, C().anchor, days);
                if (edi < 0) continue;
                const double eh0 = SecondsIntoLocalDay(e->start) / 3600.0;
                const double eh1 = eh0 + (double)e->durMin / 60.0;
                float ey0 = org.y + (float)eh0 * C().pxPerHour;
                float ey1 = org.y + (float)eh1 * C().pxPerHour;
                if (ey1 - ey0 < 16.0f) ey1 = ey0 + 16.0f;
                const float ex0 = org.x + gutter + colW * edi + 2.0f;
                const float ex1 = ex0 + colW - 6.0f;
                if (rx0 < ex1 && rx1 > ex0 && ry0 < ey1 && ry1 > ey0)
                    getroffen.push_back(e->id);
            }

            if (!getroffen.empty()) {
                // RECHTECK-MEHRFACHAUSWAHL. [Direkt insert/erase statt
                //  UiCalendar_PenToggle -- ein Toggle wuerde bei einem
                //  Event, das schon ausgewaehlt war, es beim Ueberstreichen
                //  versehentlich WIEDER abwaehlen. Hinzufuegen soll immer
                //  hinzufuegen, Entfernen immer entfernen, unabhaengig vom
                //  bisherigen Zustand jedes einzelnen Events.]
                for (auto id : getroffen) {
                    if (C().penZugInvert) C().penSel.erase(id);
                    else                  C().penSel.insert(id);
                }
            } else if (!C().penZugInvert) {
                // LEERE FLAECHE, KEIN DOPPELTIPP: neues Event ueber die
                // gezogene Zeitspanne -- wie in der vorigen Runde.
                std::int64_t von = std::min(C().penZeichnetStart, C().penZeichnetEnde);
                std::int64_t bis = std::max(C().penZeichnetStart, C().penZeichnetEnde);
                int durMin = (int)((bis - von) / 60);
                if (durMin < 5) durMin = 30;   // blosser Tipp -- Mindestmass
                CalEntry e;
                e.start  = von;
                e.durMin = durMin;
                const std::uint64_t id = UiCalendar_Add(std::move(e));
                if (id) UiCalendar_PenToggle(id);
            }
            // Doppeltipp auf leerer Flaeche (invert, nichts getroffen):
            // absichtlich wirkungslos -- ein neues Event "abzuwaehlen"
            // ergibt keinen Sinn.
            SaveNow();
        }
        // Waehrend des Zeichnens: normales Scrollen/Tippen unterdruecken.
        // Vorschau-Zeichnung folgt weiter unten, NACH dem Stundenraster.
    } else {
        // SENKRECHT SCROLLEN NUR PER PINPOINT. [Der Ein-Finger-Zug auf der
        //  freien Flaeche scrollte zusaetzlich -- jede Beruehrung auf dem
        //  Raster verschob die Ansicht, bevor eine andere Geste greifen
        //  konnte. Ist die globale Pinpoint-Geste verdrahtet, scrollt
        //  ausschliesslich sie; der Zug hier bleibt nur, wenn die Einstellung
        //  auf "wischen" steht oder nichts verdrahtet ist.]
        const bool pinpointDa = UiCalendar_ScrollPinpoint && UiCalendar_ScrollPinpoint();
        if (!pinpointDa && ImGui::IsItemActive() && !C().drag.active) {
            const ImVec2 dmv = ImGui::GetIO().MouseDelta;
            if (dmv.y != 0.0f) {
                ImGui::SetScrollY(ImGui::GetScrollY() - dmv.y);
                Claim();
            }
        }
        if (ImGui::IsItemDeactivated() && !C().drag.active &&
            ImGui::GetIO().MouseDragMaxDistanceSqr[0] < 36.0f) {
            const ImVec2 mp = ImGui::GetIO().MousePos;
            const int di = (int)((mp.x - org.x - gutter) / colW);
            if (di >= 0 && di < days) {
                const std::int64_t day = XbmTime_AddDays(C().anchor, di);
                const double hours = (mp.y - org.y) / C().pxPerHour;
                C().slotSel = SnapTime(day + (std::int64_t)(hours * 3600.0));
                C().selected = 0;
            }
        }
    }

    // VORSCHAU WAEHREND DES STIFT-ZUGS.
    // [Das ECHTE Bildschirm-Rechteck vom Aufsetzpunkt zum Finger -- so
    //  sieht man schon waehrend des Ziehens, welche Events erfasst wuerden
    //  (heller Rahmen um jedes getroffene Event) bzw., falls keines
    //  getroffen wird, die entstehende Zeitspanne mit ihrer Dauer.
    //  Doppeltipp-Start (Invertieren) zeigt Rot statt Gelb, damit der
    //  Unterschied schon waehrend des Ziehens sichtbar ist.]
    if (C().penZugAktiv) {
        const ImVec2 mpNow = ImGui::GetIO().MousePos;
        const float rx0 = std::min(C().penZugPressPx.x, mpNow.x);
        const float rx1 = std::max(C().penZugPressPx.x, mpNow.x);
        const float ry0 = std::min(C().penZugPressPx.y, mpNow.y);
        const float ry1 = std::max(C().penZugPressPx.y, mpNow.y);
        const ImU32 farbe = C().penZugInvert ? IM_COL32(230, 90, 70, 220)
                                             : IM_COL32(255, 220, 60, 220);
        const ImU32 farbeFuellung = C().penZugInvert ? IM_COL32(230, 90, 70, 60)
                                                     : IM_COL32(255, 220, 60, 60);

        int treffer = 0;
        for (CalEntry* e : vis) {
            if (e->allDay) continue;
            const int edi = DayIndexOf(e->start, C().anchor, days);
            if (edi < 0) continue;
            const double eh0 = SecondsIntoLocalDay(e->start) / 3600.0;
            const double eh1 = eh0 + (double)e->durMin / 60.0;
            float ey0 = org.y + (float)eh0 * C().pxPerHour;
            float ey1 = org.y + (float)eh1 * C().pxPerHour;
            if (ey1 - ey0 < 16.0f) ey1 = ey0 + 16.0f;
            const float ex0 = org.x + gutter + colW * edi + 2.0f;
            const float ex1 = ex0 + colW - 6.0f;
            if (rx0 < ex1 && rx1 > ex0 && ry0 < ey1 && ry1 > ey0) {
                ++treffer;
                dl->AddRect(ImVec2(ex0 - 1.5f, ey0 - 1.5f), ImVec2(ex1 + 1.5f, ey1 + 1.5f),
                           farbe, 3.0f, 0, 2.5f);
            }
        }

        dl->AddRectFilled(ImVec2(rx0, ry0), ImVec2(rx1, ry1), farbeFuellung, 2.0f);
        dl->AddRect(ImVec2(rx0, ry0), ImVec2(rx1, ry1), farbe, 2.0f, 0, 1.5f);

        char lbl[48];
        if (treffer > 0) {
            std::snprintf(lbl, sizeof(lbl), C().penZugInvert ? "-%d Event(s)" : "+%d Event(s)",
                         treffer);
        } else if (!C().penZugInvert) {
            std::int64_t von = std::min(C().penZeichnetStart, C().penZeichnetEnde);
            std::int64_t bis = std::max(C().penZeichnetStart, C().penZeichnetEnde);
            int mins = (int)((bis - von) / 60);
            std::snprintf(lbl, sizeof(lbl), "neu: %d min", mins);
        } else {
            std::snprintf(lbl, sizeof(lbl), "(nichts)");
        }
        dl->AddText(ImVec2(rx0 + 3.0f, ry0 - ImGui::GetTextLineHeight() - 2.0f),
                   IM_COL32(255, 255, 255, 240), lbl);
    }

    ImGui::SetCursorScreenPos(ImVec2(org.x, org.y + totalH));
    ImGui::Dummy(ImVec2(1, 1));      // Scrollhoehe festlegen
    ImGui::EndChild();
}

// ---------------------------------------------------------------------------
// Monatsansicht -- 6x7 Zellen, Eintraege als Chips, Ziehen zwischen Tagen
// ---------------------------------------------------------------------------
void DrawMonth(float bottomReserve) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const XbmLocalTime a = XbmTime_ToLocal(C().anchor);
    const std::int64_t first = XbmTime_FromLocal(a.year, a.month, 1, 0, 0, 0);
    const std::int64_t gridStart = WeekStart(first);        // Montag davor
    const std::int64_t today0 = XbmTime_LocalMidnight(XbmTime_NowUtc());

    ImVec2 avail(ImGui::GetContentRegionAvail().x,
                 ImGui::GetContentRegionAvail().y - bottomReserve);
    if (avail.y < 120.0f) avail.y = 120.0f;   // s. Kommentar im Zeitraster
    if (avail.x < 140.0f) avail.x = 140.0f;
    const float headH = ImGui::GetTextLineHeight() + 6.0f;
    const float cw = avail.x / 7.0f;
    const float ch = (avail.y - headH) / 6.0f;
    const ImVec2 org = ImGui::GetCursorScreenPos();
    const float lineH = ImGui::GetTextLineHeight();
    const ImU32 colLine = ImGui::GetColorU32(ImGuiCol_Separator, 0.55f);

    auto cellRect = [&](int idx, ImVec2& p0, ImVec2& p1) {
        const int row = idx / 7, col = idx % 7;
        p0 = ImVec2(org.x + cw * col, org.y + headH + ch * row);
        p1 = ImVec2(p0.x + cw, p0.y + ch);
    };
    // Aus einer Bildschirmposition die Tageszelle bestimmen -- so laesst
    // sich ein Chip ablegen, ohne dass die Zelle selbst das aktive Item
    // sein muss (waehrend eines Zuges ist immer der CHIP aktiv).
    auto cellAt = [&](ImVec2 pos, std::int64_t& dayOut) -> bool {
        const float rx = pos.x - org.x, ry = pos.y - org.y - headH;
        if (rx < 0 || ry < 0 || rx >= avail.x || ry >= ch * 6.0f) return false;
        const int col = (int)(rx / cw), row = (int)(ry / ch);
        if (col < 0 || col > 6 || row < 0 || row > 5) return false;
        dayOut = XbmTime_AddDays(gridStart, row * 7 + col);
        return true;
    };

    // ---- Kopfzeile ------------------------------------------------------
    for (int d = 0; d < 7; ++d) {
        const ImVec2 ts = ImGui::CalcTextSize(kWeekdayShort[d]);
        dl->AddText(ImVec2(org.x + cw * d + (cw - ts.x) * 0.5f, org.y + 2),
                    ImGui::GetColorU32(ImGuiCol_TextDisabled), kWeekdayShort[d]);
    }

    // ---- DURCHGANG 1: nur ZEICHNEN (Zellen, Rahmen, Tageszahlen) --------
    std::int64_t hoverDay = 0;
    const bool dragging = C().drag.active && C().drag.id != 0;
    const bool haveHover = dragging && cellAt(ImGui::GetIO().MousePos, hoverDay);
    for (int idx = 0; idx < 42; ++idx) {
        ImVec2 p0, p1; cellRect(idx, p0, p1);
        const std::int64_t day = XbmTime_AddDays(gridStart, idx);
        const XbmLocalTime dlt = XbmTime_ToLocal(day);
        const bool inMonth = (dlt.month == a.month);
        if (day == today0)
            dl->AddRectFilled(p0, p1, IM_COL32(70, 110, 180, 55));
        else if (!inMonth)
            dl->AddRectFilled(p0, p1, ImGui::GetColorU32(ImGuiCol_WindowBg, 0.55f));
        dl->AddRect(p0, p1, colLine);
        if (haveHover && day == hoverDay)
            dl->AddRect(p0, p1, IM_COL32(255, 210, 90, 230), 0, 0, 2.5f);
        // GELBER UHRZEIT-MARKER auch im Monat: waagrechter Strich auf
        // der Hoehe, die der gewaehlten Uhrzeit entspricht.
        if (C().slotSel != 0
            && XbmTime_LocalMidnight(C().slotSel) == day) {
            dl->AddRectFilled(p0, p1, IM_COL32(25, 45, 80, 110));
            const float rel = (float)(SecondsIntoLocalDay(C().slotSel)
                                      / 86400.0);
            const float my = p0.y + rel * (p1.y - p0.y);
            dl->AddLine(ImVec2(p0.x + 1, my), ImVec2(p1.x - 1, my),
                        IM_COL32(255, 200, 60, 230), 2.0f);
            dl->AddCircleFilled(ImVec2(p0.x + 4, my), 3.0f,
                                IM_COL32(255, 200, 60, 230));
        }
        char db[8];
        std::snprintf(db, sizeof(db), "%d", dlt.day);
        dl->AddText(ImVec2(p0.x + 4, p0.y + 2),
                    ImGui::GetColorU32(inMonth ? ImGuiCol_Text : ImGuiCol_TextDisabled),
                    db);
    }

    // ---- DURCHGANG 2: EIN ZUSAMMENHAENGENDER BALKEN JE EVENT UND ZEILE --
    // Reihenfolge wie im Zeitraster: das zuerst submittete Item gewinnt den
    // Druck. Die Balken muessen also vor den grossen Zellflaechen kommen,
    // sonst liesse sich nie ein einzelner Termin greifen.
    //
    // [VORHER: jedes Event wurde PRO TAG, den es beruehrt, als EIGENER
    //  Chip mit identischer PushID(e->id) gezeichnet -- bei einem
    //  mehrtaegigen Event fuehrte das zu MEHREREN Items mit derselben
    //  Kennung im selben Frame ("MESSAGE FROM DEAR IMGUI: ... visible
    //  items with conflicting ID"). Jetzt wird jedes Event nur EINMAL
    //  JE ZEILE (Kalenderwoche), die es beruehrt, als ein zusammen-
    //  haengender Balken ueber alle seine Spalten in dieser Zeile
    //  gezeichnet -- Titel und Uhrzeit stehen dabei nur auf dem
    //  ALLERERSTEN sichtbaren Segment, nicht auf jedem Tag neu.]
    const float chipH = ImMax(lineH * 0.85f, 12.0f);
    struct MSeg { CalEntry* e; int zeile, col0, col1; bool erste, letzte; double relStart; };
    std::vector<MSeg> segs;
    {
        const std::int64_t gridEndeExkl = XbmTime_AddDays(gridStart, 42);
        std::vector<CalEntry*> alle = UiCalendar_Range(gridStart, gridEndeExkl);
        std::sort(alle.begin(), alle.end(),
                  [](CalEntry* x, CalEntry* y) { return x->start < y->start; });
        for (CalEntry* e : alle) {
            const std::int64_t evTagStart = XbmTime_LocalMidnight(e->start);
            const std::int64_t evEndeExkl = e->end() > e->start ? e->end() : e->start + 1;
            const std::int64_t evTagEndeLetzter = XbmTime_LocalMidnight(evEndeExkl - 1);
            const std::int64_t sichtStart = evTagStart < gridStart ? gridStart : evTagStart;
            const std::int64_t sichtEndeLetzter = evTagEndeLetzter >= gridEndeExkl
                ? XbmTime_AddDays(gridEndeExkl, -1) : evTagEndeLetzter;
            if (sichtStart > sichtEndeLetzter) continue;
            const double relStart = (double)SecondsIntoLocalDay(e->start) / 86400.0;
            bool erste = true;
            std::int64_t tag = sichtStart;
            while (tag <= sichtEndeLetzter) {
                const int idx = (int)((tag - gridStart) / 86400);
                const int zeile = idx / 7, col0 = idx % 7;
                const std::int64_t zeilenEndeTag = XbmTime_AddDays(gridStart, zeile * 7 + 6);
                const std::int64_t segEnde = sichtEndeLetzter < zeilenEndeTag
                                            ? sichtEndeLetzter : zeilenEndeTag;
                const int col1 = col0 + (int)((segEnde - tag) / 86400);
                const bool letzte = (segEnde == sichtEndeLetzter);
                segs.push_back({e, zeile, col0, col1, erste, letzte, relStart});
                erste = false;
                tag = XbmTime_AddDays(segEnde, 1);
            }
        }
    }

    // Ueberlappungs-Staffelung JE ZEILE: ein Schritt nach rechts je
    // zusaetzlicher zeitlicher UND spaltenmaessiger Ueberlappung.
    std::vector<float> belegtY0[6], belegtY1[6];
    std::vector<int>   belegtC0[6], belegtC1[6];
    for (const MSeg& sg : segs) {
        ImVec2 rp0, rp1; cellRect(sg.zeile * 7, rp0, rp1);
        ImVec2 rEndp0, rEndp1; cellRect(sg.zeile * 7 + sg.col1, rEndp0, rEndp1);
        const float innerTop = rp0.y + lineH + 2.0f;
        const float innerH   = (rp0.y + ch - innerTop) - 2.0f;
        if (innerH < chipH) continue;

        float cy0 = innerTop + (float)(sg.relStart * innerH);
        float cy1 = cy0 + chipH;
        if (cy1 > rp0.y + ch - 2.0f) { cy1 = rp0.y + ch - 2.0f; cy0 = cy1 - chipH; }
        if (cy0 < innerTop) cy0 = innerTop;

        int indent = 0;
        auto& bY0 = belegtY0[sg.zeile]; auto& bY1 = belegtY1[sg.zeile];
        auto& bC0 = belegtC0[sg.zeile]; auto& bC1 = belegtC1[sg.zeile];
        for (size_t k = 0; k < bY0.size(); ++k)
            if (cy0 < bY1[k] && cy1 > bY0[k] && sg.col0 <= bC1[k] && sg.col1 >= bC0[k])
                ++indent;
        bY0.push_back(cy0); bY1.push_back(cy1); bC0.push_back(sg.col0); bC1.push_back(sg.col1);

        const float indentPx = ImClamp(cw * 0.08f, 5.0f, 11.0f);
        float cx0 = rp0.x + 2.0f + indent * indentPx;
        float cx1 = rEndp1.x - 2.0f;
        if (cx1 - cx0 < 10.0f) cx0 = cx1 - 10.0f;
        const ImVec2 c0(cx0, cy0), c1(cx1, cy1);

        ImGui::SetCursorScreenPos(c0);
        // ID ueber Event UND Zeile -- ein und dasselbe Event kann in
        // MEHREREN Zeilen je ein eigenes Segment haben (Wochenumbruch),
        // jedes braucht eine eigene, aber STABILE Kennung.
        ImGui::PushID((int)((sg.e->id & 0x1fffffff) * 10 + sg.zeile));
        ImGui::InvisibleButton("##chip", ImVec2(c1.x - c0.x, c1.y - c0.y));
        CalEntry* e = sg.e;
        const bool act = ImGui::IsItemActive();
        if (ImGui::IsItemActivated()) {
            if (C().penActive || ImGui::GetIO().KeyShift) {   // Shift+Tipp: Mehrfachauswahl wie das Stiftwerkzeug
                UiCalendar_PenToggle(e->id);
                ImGui::PopID();
                continue;
            }
            C().drag.id        = e->id;
            C().drag.armed     = true;
            C().drag.active    = false;
            C().drag.pressTime = ImGui::GetTime();
            C().drag.pressPos  = ImGui::GetIO().MousePos;
            C().drag.origStart = e->start;
            {   // GRIFFVERSATZ in Tagen: auf welchem Tag des Termins wurde gegriffen?
                std::int64_t tagP = 0;
                if (cellAt(ImGui::GetIO().MousePos, tagP)) C().drag.griffVersatzSek = tagP - XbmTime_LocalMidnight(e->start);
                else C().drag.griffVersatzSek = 0;
            }
            C().selected       = e->id;
            // SOFORT BEANSPRUCHEN -- derselbe Grund wie im Zeitraster:
            // sonst greift auf Android die globale Scroll-Geste
            // waehrend der 0,3 s Haltezeit zuerst zu, und "Verschieben
            // in der Monatsansicht" wirkt scheinbar gar nicht.
            Claim();
        }
        if (act && C().drag.id == e->id) {
            const ImVec2 mpNow = ImGui::GetIO().MousePos;
            const float moved = ImLengthSqr(mpNow - C().drag.pressPos);
            const double heldT = ImGui::GetTime() - C().drag.pressTime;
            // BEWEGUNG STARTET SOFORT -- dieselbe Korrektur wie im
            // Zeitraster (siehe dortige ausfuehrliche Begruendung).
            if (C().drag.armed && moved >= kHoldSlop * kHoldSlop) {
                C().drag.armed = false; C().drag.active = true;
            } else if (C().drag.armed && heldT >= kHoldSec) {
                C().drag.armed = false; C().drag.active = true;
            }
            if (C().drag.active) {
                Claim();
                // KANTEN-UEBERGANG: in den vorigen/naechsten Monat
                // weiterziehen. [Genau wie in der 1-n-Tage-Ansicht: zieht
                // man ueber den linken/rechten Rand des Rasters hinaus,
                // schaltet die Ansicht kontinuierlich weiter, waehrend
                // der Zug laeuft -- so laesst sich auf einen Tag in
                // einem anderen Monat verschieben, ohne loszulassen.]
                const ImVec2 mp = ImGui::GetIO().MousePos;
                const float randZone = 36.0f;
                const bool mLinks  = (mp.x < org.x + randZone);
                const bool mRechts = (mp.x > org.x + avail.x - randZone);
                // Erst nach einem Abstecher in die Mitte (siehe
                // RandZoneFreigegeben) -- sonst blaetterte ein am Rand
                // angepackter Greifer sofort in den Nachbarmonat.
                const bool mFrei = RandZoneFreigegeben(mLinks || mRechts, C().randScharfH);
                int monatRichtung = 0;
                if (mFrei && mLinks) monatRichtung = -1;
                else if (mFrei && mRechts) monatRichtung = 1;
                if (monatRichtung != 0) {
                    const double jetzt = ImGui::GetTime();
                    if (jetzt - C().autoScrollLetzterTick >= 0.45) {
                        C().autoScrollLetzterTick = jetzt;
                        C().anchor = XbmTime_AddMonths(C().anchor, monatRichtung);
                        C().dirty = true;
                    }
                }
                // NUR DER TAG aus der Zeigerposition -- die Uhrzeit bleibt.
                // [Die stuendliche Verschiebung ueber die Hoehe in der Zelle
                //  ist gestrichen: in der Monatsansicht verschiebt man Tage.]
                std::int64_t target = 0;
                if (cellAt(mp, target)) {
                    // Der GEGRIFFENE Tag bleibt unter dem Finger: Versatz abziehen.
                    const std::int64_t uhr = SecondsIntoLocalDay(C().drag.origStart ? C().drag.origStart : e->start);
                    const std::int64_t neu = XbmTime_AddDays(target, (int)(-C().drag.griffVersatzSek / 86400)) + uhr;
                    if (neu != e->start) { UiCalendar_EventStartSetzen(*e, neu); C().dirty = true; }
                }
            }
        }
        if (ImGui::IsItemDeactivated() && C().drag.id == e->id) {
            if (C().drag.active) {
                UiCalendar_Touch(e->id);
                SaveNow();
            } else if (ImGui::GetIO().MouseDragMaxDistanceSqr[0] < 36.0f) {
                EditorOeffnen(e->id);            // kurzer Tipp = oeffnen
            }
            C().drag.armed = C().drag.active = false;
            C().drag.id = 0;
        }

        const bool moving = (C().drag.active && C().drag.id == e->id);
        const bool penSelM = UiCalendar_PenIsSelected(e->id);
        const bool gewaehltM = (C().selected == e->id);
        const ImU32 col = EntryColor(*e);
        dl->AddRectFilled(c0, c1, moving ? Darken(col, 1.35f) : col, 3.0f);
        if (penSelM)
            dl->AddRect(ImVec2(c0.x - 1, c0.y - 1), ImVec2(c1.x + 1, c1.y + 1),
                       IM_COL32(255, 220, 60, 230), 3.0f, 0, 2.0f);
        // TITEL/UHRZEIT NUR AUF DEM ALLERERSTEN SICHTBAREN SEGMENT --
        // sonst stuende derselbe Text auf jedem Zeilenabschnitt neu.
        if (sg.erste) {
            dl->PushClipRect(c0, c1, true);
            const std::string t = XbmTime_Format(e->start, "%H:%M ") + e->title;
            dl->AddText(ImVec2(c0.x + 3, c0.y), IM_COL32(255, 255, 255, 240), t.c_str());
            dl->PopClipRect();
        }

        // GRIFFE FUER DAS AUSGEWAEHLTE EVENT -- Start VOR dem allerersten,
        // Ende NACH dem allerletzten Segment. [Bewegen Tag-weise, nicht
        // auf die Minute -- ein Datum, keine Uhrzeit.]
        const float grM = ImMax(9.0f, ch * 0.16f);
        const bool istErstesSegmentInsgesamt = sg.erste;
        const bool istLetztesSegmentInsgesamt = sg.letzte;
        if (gewaehltM && istErstesSegmentInsgesamt) {
            const ImVec2 gs(c0.x - grM - 2.0f, (c0.y + c1.y) * 0.5f);
            ImGui::SetCursorScreenPos(ImVec2(gs.x - grM, gs.y - grM));
            ImGui::InvisibleButton("##mgrip_s", ImVec2(grM * 2, grM * 2));
            if (ImGui::IsItemActivated()) {
                C().drag.id = e->id; C().drag.grip = 1;
                C().drag.origStart = e->start; C().drag.origDur = e->durMin;
            }
            if (ImGui::IsItemActive() && C().drag.id == e->id && C().drag.grip == 1) {
                Claim();
                std::int64_t tagZiel = 0;
                if (cellAt(ImGui::GetIO().MousePos, tagZiel)) {
                    const std::int64_t origEnde = C().drag.origStart
                                                + (std::int64_t)C().drag.origDur * 60;
                    const std::int64_t uhr = SecondsIntoLocalDay(C().drag.origStart);
                    const std::int64_t neuerStart = tagZiel + uhr;
                    UiCalendar_EventStartSetzen(*e, neuerStart);
                    if (neuerStart < origEnde - 300)
                        e->durMin = (int)((origEnde - neuerStart) / 60);
                    else
                        e->durMin = C().drag.origDur < 5 ? 5 : C().drag.origDur;
                    C().dirty = true;
                }
            }
            if (ImGui::IsItemDeactivated() && C().drag.id == e->id && C().drag.grip == 1) {
                UiCalendar_Touch(e->id); SaveNow(); C().drag = DragState{};
            }
            if (ImGui::IsItemHovered() && !ImGui::GetIO().MouseDown[0])
                ImGui::SetTooltip("Startdatum ziehen");
            dl->AddCircleFilled(gs, grM, IM_COL32(255, 255, 255, 235));
            dl->AddCircle(gs, grM, Darken(col, 0.6f), 12, 2.0f);
        }
        if (gewaehltM && istLetztesSegmentInsgesamt) {
            const ImVec2 ge(c1.x + grM + 2.0f, (c0.y + c1.y) * 0.5f);
            ImGui::SetCursorScreenPos(ImVec2(ge.x - grM, ge.y - grM));
            ImGui::InvisibleButton("##mgrip_e", ImVec2(grM * 2, grM * 2));
            if (ImGui::IsItemActivated()) {
                C().drag.id = e->id; C().drag.grip = 2;
                C().drag.origStart = e->start; C().drag.origDur = e->durMin;
            }
            if (ImGui::IsItemActive() && C().drag.id == e->id && C().drag.grip == 2) {
                Claim();
                std::int64_t tagZiel = 0;
                if (cellAt(ImGui::GetIO().MousePos, tagZiel)) {
                    const std::int64_t origStart = C().drag.origStart;
                    const std::int64_t uhr = SecondsIntoLocalDay(
                        origStart + (std::int64_t)C().drag.origDur * 60);
                    const std::int64_t neuesEnde = tagZiel + uhr;
                    if (neuesEnde > origStart + 300) {
                        if (e->start != origStart) UiCalendar_EventStartSetzen(*e, origStart);
                        e->durMin = (int)((neuesEnde - origStart) / 60);
                    } else {
                        e->durMin = C().drag.origDur < 5 ? 5 : C().drag.origDur;
                    }
                    C().dirty = true;
                }
            }
            if (ImGui::IsItemDeactivated() && C().drag.id == e->id && C().drag.grip == 2) {
                UiCalendar_Touch(e->id); SaveNow(); C().drag = DragState{};
            }
            if (ImGui::IsItemHovered() && !ImGui::GetIO().MouseDown[0])
                ImGui::SetTooltip("Enddatum ziehen");
            dl->AddCircleFilled(ge, grM, IM_COL32(255, 255, 255, 235));
            dl->AddCircle(ge, grM, Darken(col, 0.6f), 12, 2.0f);
        }

        ImGui::PopID();
    }

    // ---- DURCHGANG 3: ZELLEN als Items (zuletzt -> nur freie Flaeche) ---
    for (int idx = 0; idx < 42; ++idx) {
        ImVec2 p0, p1; cellRect(idx, p0, p1);
        const std::int64_t day = XbmTime_AddDays(gridStart, idx);
        ImGui::SetCursorScreenPos(p0);
        ImGui::PushID(idx + 7000);
        ImGui::InvisibleButton("##cell", ImVec2(cw, ch));
        if (ImGui::IsItemDeactivated() &&
            ImGui::GetIO().MouseDragMaxDistanceSqr[0] < 36.0f) {
            // UHRZEIT AUS DER KLICKHOEHE: oben in der Zelle ist 00:00,
            // unten 24:00. So setzt ein Tipp Tag UND Uhrzeit in einem.
            const float rel = (ImGui::GetIO().MousePos.y - p0.y)
                            / (ch > 1.0f ? ch : 1.0f);
            const float relC = rel < 0.0f ? 0.0f : (rel > 1.0f ? 1.0f : rel);
            std::int64_t sek = (std::int64_t)(relC * 24.0f * 3600.0f);
            sek = (sek / (15 * 60)) * (15 * 60);      // auf 15 min runden
            C().slotSel = day + sek;
            C().dirty = true;
        }
        if (ImGui::IsItemHovered() &&
            ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) {
            // NICHT MEHR CalView::Day setzen -- die gibt es in der
            // Oberflaeche nicht mehr (T-Knopf entfernt). Stattdessen die
            // n-Tage-Ansicht mit genau EINEM Tag -- das ist ihr
            // Aequivalent im neuen, durchgehenden Ansichtsband.
            C().anchor = day;
            C().view   = CalView::ThreeDay;
            C().nDays  = 1;
            C().dirty = true;
        }
        ImGui::PopID();
    }

    // Zug ausserhalb jeder Zelle losgelassen: Zustand sauber aufraeumen.
    if (C().drag.active && !ImGui::GetIO().MouseDown[0]) {
        C().drag.active = C().drag.armed = false;
        C().drag.id = 0;
    }
    ImGui::SetCursorScreenPos(ImVec2(org.x, org.y + avail.y));
    ImGui::Dummy(ImVec2(1, 1));
}

// ---------------------------------------------------------------------------
// Jahresansicht -- 12 Mini-Monate mit Belegungspunkten
// ---------------------------------------------------------------------------
void DrawYear(float bottomReserve) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const XbmLocalTime a = XbmTime_ToLocal(C().anchor);
    const std::int64_t today0 = XbmTime_LocalMidnight(XbmTime_NowUtc());

    ImVec2 avail(ImGui::GetContentRegionAvail().x,
                 ImGui::GetContentRegionAvail().y - bottomReserve);
    if (avail.y < 160.0f) avail.y = 160.0f;
    if (avail.x < 200.0f) avail.x = 200.0f;
    // ---- SPALTENZAHL AUS DEM PLATZ RECHNEN, nicht aus festen Schwellen.
    // [Vorher entschieden feste Breiten-Schwellen (>1100 -> 6 Spalten
    //  usw.). Auf dem Handy im Hochformat ergab das 2 Spalten mit sehr
    //  breiten, aber flachen Mini-Monaten: die Tageszellen wurden dadurch
    //  gedrueckt und die Zahlen klebten aneinander. Jetzt wird jede
    //  moegliche Aufteilung durchprobiert und die genommen, bei der die
    //  Tageszelle am groessten wird -- so nutzt das Raster den Platz
    //  unabhaengig vom Seitenverhaeltnis.]
    int cols = 3, rows = 4;
    {
        const float lh   = ImGui::GetTextLineHeight();
        float bestCell = -1.0f;
        for (int c = 1; c <= 12; ++c) {
            const int r = (12 + c - 1) / c;
            const float mw0 = avail.x / (float)c;
            const float mh0 = avail.y / (float)r;
            // Je Mini-Monat: 7 Spalten, 6 Zeilen plus eine Titelzeile.
            const float cw0 = (mw0 - 8.0f) / 7.0f;
            const float chh = (mh0 - lh - 6.0f) / 6.0f;
            const float cell = cw0 < chh ? cw0 : chh;   // quadratisch denken
            if (cell > bestCell) { bestCell = cell; cols = c; rows = r; }
        }
    }
    const float mw = avail.x / cols;
    const float mh = avail.y / rows;
    const ImVec2 org = ImGui::GetCursorScreenPos();
    const float lineH = ImGui::GetTextLineHeight();

    // BELEGUNG EINMAL VORRECHNEN statt 504-mal die Eintragsliste abzusuchen.
    // [Die erste Fassung rief pro Tageszelle UiCalendar_Range() -- bei 2000
    //  Eintraegen sind das ueber eine Million Vergleiche pro Frame, gemessen
    //  1,63 ms. Auf der schwachen iGPU, die hier ohnehin schon knapp ist,
    //  waere das ein spuerbarer Anteil des Frame-Budgets. Ein einziger
    //  Durchgang ueber die Eintraege genuegt.]
    bool dayHas[400] = { false };
    for (const auto& en : C().entries) {
        const XbmLocalTime el = XbmTime_ToLocal(en.start);
        if (el.year != a.year) continue;
        if (el.yday >= 0 && el.yday < 400) dayHas[el.yday] = true;
    }

    for (int m = 0; m < 12; ++m) {
        const int cx = m % cols, cy = m / cols;
        const ImVec2 p0(org.x + mw * cx + 4, org.y + mh * cy + 2);
        // Quadratische Tageszellen und im Mini-Monat zentriert -- so
        // stehen die Zahlen gleichmaessig und beruehren sich nicht.
        const float innerW = mw - 8.0f;
        const float cwRaw  = innerW / 7.0f;
        const float chRaw  = (mh - lineH - 6.0f) / 6.0f;
        const float cellW  = cwRaw < chRaw ? cwRaw : chRaw;
        const float cellH  = cellW;
        const float offX   = (innerW - cellW * 7.0f) * 0.5f;

        char cap[32];
        std::snprintf(cap, sizeof(cap), "%.3s %d", kMonthName[m], a.year);
        dl->AddText(p0, ImGui::GetColorU32(ImGuiCol_Text), cap);

        const std::int64_t first = XbmTime_FromLocal(a.year, m + 1, 1, 0, 0, 0);
        const std::int64_t gs = WeekStart(first);
        for (int i = 0; i < 42; ++i) {
            const std::int64_t day = XbmTime_AddDays(gs, i);
            const XbmLocalTime l = XbmTime_ToLocal(day);
            if (l.month != m + 1) continue;
            const int row = i / 7, col = i % 7;
            const ImVec2 d0(p0.x + offX + cellW * col,
                            p0.y + lineH + 2 + cellH * row);
            const ImVec2 d1(d0.x + cellW - 1, d0.y + cellH - 1);

            const bool hasEntries = (l.yday >= 0 && l.yday < 400)
                                  && dayHas[l.yday];
            if (C().slotSel != 0
                && XbmTime_LocalMidnight(C().slotSel) == day)
                dl->AddRectFilled(d0, d1, IM_COL32(30, 55, 95, 235), 2.0f);
            else if (day == today0)
                dl->AddRectFilled(d0, d1, IM_COL32(70, 110, 180, 110), 2.0f);
            else if (hasEntries)
                dl->AddRectFilled(d0, d1, IM_COL32(90, 150, 110, 80), 2.0f);

            char db[4];
            std::snprintf(db, sizeof(db), "%d", l.day);
            // ZAHL IMMER ZEICHNEN, notfalls verkleinert.
            // [Vorher stand hier eine Bedingung "nur zeichnen, wenn der
            //  Text in die Zelle passt". Auf Android ist die Schrift
            //  gegenueber den winzigen Mini-Monatszellen deutlich groesser
            //  -- die Bedingung war nie erfuellt und die Tageszahlen
            //  blieben KOMPLETT unsichtbar. Dass der Doppelklick trotzdem
            //  funktionierte, passt dazu: die Schaltflaeche lag ja da, nur
            //  die Beschriftung fehlte.]
            const float baseSz = ImGui::GetFontSize();
            const ImVec2 ts0 = ImGui::CalcTextSize(db);
            float sz = baseSz;
            if (ts0.x > cellW - 2.0f && ts0.x > 0.0f)
                sz = baseSz * (cellW - 2.0f) / ts0.x;
            if (sz > cellH - 1.0f) sz = cellH - 1.0f;
            if (sz < 6.0f) sz = 6.0f;          // darunter ist nichts mehr lesbar
            const float scale = sz / baseSz;
            const ImVec2 ts(ts0.x * scale, ts0.y * scale);
            dl->AddText(ImGui::GetFont(), sz,
                        ImVec2(d0.x + (cellW - ts.x) * 0.5f,
                               d0.y + (cellH - ts.y) * 0.5f),
                        ImGui::GetColorU32(hasEntries ? ImGuiCol_Text
                                                      : ImGuiCol_TextDisabled), db);
            ImGui::SetCursorScreenPos(d0);
            ImGui::PushID(m * 64 + i);
            if (ImGui::InvisibleButton("##yd", ImVec2(cellW, cellH))) {
                // ERSTER TIPP WAEHLT NUR AUS, der zweite springt.
                // [Vorher sprang schon der erste in die Tagesansicht --
                //  man konnte im Jahr nichts markieren, ohne die Ansicht
                //  zu verlieren.]
                const std::int64_t uhr = C().slotSel
                    ? (std::int64_t)SecondsIntoLocalDay(C().slotSel)
                    : 9 * 3600;
                const bool nochmal = (C().lastYearTap == day)
                    && (ImGui::GetTime() - C().lastYearTapT < 1.2);
                C().slotSel = day + uhr;
                C().dirty = true;
                if (nochmal) {
                    C().anchor = day;
                    C().view = CalView::Day;
                    C().lastYearTap = 0;
                } else {
                    C().lastYearTap = day;
                    C().lastYearTapT = ImGui::GetTime();
                }
            }
            ImGui::PopID();
        }
    }
    ImGui::SetCursorScreenPos(ImVec2(org.x, org.y + avail.y));
    ImGui::Dummy(ImVec2(1, 1));
}

// ---------------------------------------------------------------------------
// Bearbeitungsflaeche (unten angedockt statt Popup -- auf dem Handy deutlich
// bedienbarer und ohne Z-Ordnungs-Streit mit dem Docking der App)
// ---------------------------------------------------------------------------
float EditorHeight() {
    if (!C().editing || C().editorEingefahren) return 0.0f;
    // GEMESSEN statt geraten.
    // [Hier stand eine feste Formel. Der Editor ist seither gewachsen --
    //  Abspieler-Knoepfe, Praezisions-Regler, Zeitanzeige -- und der
    //  Inhalt passte nicht mehr in die reservierte Hoehe. Ergebnis: ein
    //  senkrechter Bildlauf mitten in der Bedienflaeche, der jedes Ziehen
    //  am Regler zum Gluecksspiel macht. Die Hoehe des VORIGEN Frames ist
    //  ein verlaesslicher Wert und passt sich von selbst an, wenn Knoepfe
    //  dazukommen oder wegfallen -- etwa wenn ein Eintrag keine Aufnahme
    //  hat.]
    const float minimum = ImGui::GetFrameHeightWithSpacing() * 3.0f
                        + ImGui::GetTextLineHeight() * 5.0f + 24.0f;
    float h = C().editorMeasured > minimum ? C().editorMeasured : minimum;
    // Nie mehr als zwei Drittel des Fensters -- sonst bliebe vom Kalender
    // nichts uebrig, wenn eine Notiz lang wird.
    const float deckel = ImGui::GetWindowHeight() * 0.66f;
    if (h > deckel) h = deckel;
    return h;
}

// ---------------------------------------------------------------------------
// DATUM/UHRZEIT-OVERLAY -- DREI ZEILEN statt fuenf nebeneinandergequetschter
// Spalten.
//
// [Fuenf Spalten NEBENEINANDER liessen auf schmalen Bildschirmen jede
//  einzelne so schmal werden, dass die Knoepfe abgeschnitten und die
//  Zahlen unleserlich wurden. Jetzt: Jahr allein in Zeile 1 (als
//  durchgehende Wischleiste, kein Knopfraster -- siehe unten), Monat und
//  Tag zusammen in Zeile 2, Stunde und Minute zusammen in Zeile 3. Jede
//  Spalte bekommt dadurch die halbe (oder bei Jahr die volle) Breite
//  statt eines Fuenftels.
//  Schliesst weiterhin von selbst beim Antippen ausserhalb -- ImGuis
//  eingebautes Popup-Verhalten, dafuer ist hier nichts extra zu tun.]
// ---------------------------------------------------------------------------
inline int TageImMonat(int jahr, int monat) {
    static const int tage[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
    int t = tage[(monat - 1 + 12) % 12];
    bool schalt = (jahr % 4 == 0 && jahr % 100 != 0) || (jahr % 400 == 0);
    if (monat == 2 && schalt) t = 29;
    return t;
}

// Liefert true, wenn sich t durch eine Auswahl geaendert hat.
// Liefert true, wenn sich t durch eine Auswahl geaendert hat.
//
// [KOMPLETT NEU: fuenf GLEICHARTIGE PinPoint-Zeilen (Jahr, Monat, Tag,
//  Stunde, Minute) statt einer Mischung aus Wischleiste und Knopfraster.
//  Jede Zeile arbeitet DIREKT auf dem Zeitpunkt "t" ueber eine einzige
//  "wende N Schritte an"-Funktion (XbmTime_AddMonths/-Days bzw. einfache
//  Sekundenarithmetik fuer Stunde/Minute) -- Uebertrag/Rollover (Monat
//  13 -> naechstes Jahr, Tag 32 -> naechster Monat, Stunde 24 -> naechster
//  Tag) passiert dadurch GANZ VON SELBST, echte Kalenderarithmetik statt
//  Handrechnung mit y/mo/d/hh/mi getrennt.
//  Jede Zeile: Ziehen/Pinpoint aendert den Wert KONTINUIERLICH, mit
//  Geschwindigkeit (kurze Auslenkung = langsam, lange = schnell), RECHTS
//  = vorwaerts, LINKS = rueckwaerts. Ein kurzer Tipp OHNE nennenswerte
//  Bewegung springt direkt auf den angetippten Nachbarwert -- falls man
//  ihn per Wischen mal nicht getroffen hat.]
// EINE SENKRECHTE PINPOINT-ZEILE (Jahr, Monat, ...): halten und waagerecht
// ziehen aendert den Wert mit abstandsabhaengiger Geschwindigkeit, Tippen
// auf einen Nachbarwert springt dorthin. Unveraendert aus dem Overlay --
// nur als Funktion, damit drei Spalten sie teilen koennen.
static bool PinPointZeile(const char* titel, bool zweistellig, std::int64_t& t, float breite,
                      int (*feldWert)(std::int64_t),
                      std::int64_t (*schrittAnwenden)(std::int64_t, int)) {
bool changed = false;
constexpr int kJahrMin = 1902, kJahrMax = 2099;
        ImGui::PushID(titel);
        ImGui::TextDisabled("%s", titel);
        const float hoehe  = ImGui::GetFrameHeight() * 1.6f;
        const ImVec2 p0 = ImGui::GetCursorScreenPos();
        ImGui::InvisibleButton("##scrub", ImVec2(breite, hoehe));
        if (ImGui::IsItemActivated()) {
            C().ozJahrStartX       = ImGui::GetIO().MousePos.x;
            C().ozZiehtLetzterTick = ImGui::GetTime();
        }
        if (ImGui::IsItemActive()) {
            const float dx = ImGui::GetIO().MousePos.x - C().ozJahrStartX;
            const float ausl = std::fabs(dx);
            const float tot = 10.0f;
            if (ausl > tot) {
                float w = (ausl - tot) / 220.0f;
                if (w > 1.0f) w = 1.0f;
                // GESCHWINDIGKEIT: kurze Auslenkung -> langer Takt
                // (langsam), lange Auslenkung -> kurzer Takt (schnell).
                const double abstand = 0.45 - 0.40 * std::pow((double)w, 0.75);
                const double jetzt = ImGui::GetTime();
                if (jetzt - C().ozZiehtLetzterTick >= abstand) {
                    C().ozZiehtLetzterTick = jetzt;
                    // RECHTS = vorwaerts, LINKS = rueckwaerts.
                    const int schritt = (dx > 0.0f) ? 1 : -1;
                    std::int64_t neu = schrittAnwenden(t, schritt);
                    const XbmLocalTime nl = XbmTime_ToLocal(neu);
                    if (nl.year >= kJahrMin && nl.year <= kJahrMax) {
                        t = neu;
                        changed = true;
                    }
                }
            }
        }

        // TEXTBREITE DES GROESSTEN (mittleren) WERTES BESTIMMEN --
        // GENAU DAS fehlte beim Jahr und verursachte die
        // Ueberlappung: der Pixelabstand zwischen den Zahlen war
        // FEST (62 px), unabhaengig davon, wie breit die groess
        // dargestellte Zahl tatsaechlich war.
        char mitteBuf[8];
        const int mitteWert = feldWert(t);
        if (zweistellig) std::snprintf(mitteBuf, sizeof(mitteBuf), "%02d", mitteWert);
        else             std::snprintf(mitteBuf, sizeof(mitteBuf), "%d", mitteWert);
        const float mitteGroesse = ImGui::GetFontSize() * 1.35f;
        const ImVec2 mitteTs = ImGui::GetFont()->CalcTextSizeA(
            mitteGroesse, FLT_MAX, 0.0f, mitteBuf);
        const float schrittPx = ImMax(ImMin(56.0f, breite * 0.3f), mitteTs.x + 10.0f);

        ImDrawList* dl = ImGui::GetWindowDrawList();
        const float midX = p0.x + breite * 0.5f;
        const float midY = p0.y + hoehe * 0.5f;
        // NUR SO VIELE NACHBARWERTE, WIE IN DIE BREITE PASSEN. [Drei Spalten
    //  nebeneinander: mit festen +-3 ueberlappten die Zahlen.]
    int maxOff = (int)((breite * 0.5f - mitteTs.x * 0.5f - 6.0f) / schrittPx);
    if (maxOff > 3) maxOff = 3;
    if (maxOff < 1) maxOff = 1;
    for (int off = -maxOff; off <= maxOff; ++off) {
            const std::int64_t tOff = schrittAnwenden(t, off);
            const int wert = feldWert(tOff);
            char buf[8];
            if (zweistellig) std::snprintf(buf, sizeof(buf), "%02d", wert);
            else             std::snprintf(buf, sizeof(buf), "%d", wert);
            const bool mitte = (off == 0);
            const float groesse = ImGui::GetFontSize() * (mitte ? 1.35f : 1.0f);
            const ImVec2 ts = ImGui::GetFont()->CalcTextSizeA(
                groesse, FLT_MAX, 0.0f, buf);
            const int alphaWert = mitte ? 255 : ImMax(60, 210 - std::abs(off) * 45);
            const ImU32 farbe = mitte
                ? IM_COL32(255, 255, 255, 255)
                : IM_COL32(200, 200, 200, alphaWert);
            dl->AddText(ImGui::GetFont(), groesse,
                       ImVec2(midX + off * schrittPx - ts.x * 0.5f,
                              midY - ts.y * 0.5f),
                       farbe, buf);
        }
        dl->AddLine(ImVec2(midX - 14.0f, p0.y + hoehe - 2.0f),
                   ImVec2(midX + 14.0f, p0.y + hoehe - 2.0f),
                   IM_COL32(255, 220, 60, 220), 2.0f);

        // KURZER TIPP OHNE NENNENSWERTE BEWEGUNG: welchen Nachbarwert
        // hat man getroffen? Springt direkt dorthin -- praktisch,
        // wenn man das gewuenschte Jahr/Monat/... per Wischen mal
        // nicht exakt getroffen hat.
        if (ImGui::IsItemDeactivated()
            && ImGui::GetIO().MouseDragMaxDistanceSqr[0] < 36.0f) {
            const float relX = ImGui::GetIO().MousePos.x - midX;
            const int off = (int)std::lround((double)relX / schrittPx);
            if (off != 0) {
                std::int64_t neu = schrittAnwenden(t, off);
                const XbmLocalTime nl = XbmTime_ToLocal(neu);
                if (nl.year >= kJahrMin && nl.year <= kJahrMax) {
                    t = neu;
                    changed = true;
                }
            }
        }
        ImGui::PopID();
return changed;
}

bool DatumZeitOverlay(const char* popupId, std::int64_t& t) {
    bool changed = false;

    // NICHT UNTER DIE ANDROID-NAVIGATIONSLEISTE GEZOGEN: das Popup haengt
    // sich unten an den sicheren Arbeitsbereich (AndroidInsets::Apply()
    // hat WorkPos/WorkSize schon um Status-/Navigationsleiste verkleinert)
    // und waechst von dort aus NACH OBEN, waagerecht zentriert -- genau so
    // viel Hoehe, wie der Inhalt braucht.
    {
        ImGuiViewport* vp = ImGui::GetMainViewport();
        const float randAbstand = 10.0f;
        const ImVec2 anker(vp->WorkPos.x + vp->WorkSize.x * 0.5f,
                           vp->WorkPos.y + vp->WorkSize.y - randAbstand);
        ImGui::SetNextWindowPos(anker, ImGuiCond_Always, ImVec2(0.5f, 1.0f));
    }

    if (ImGui::BeginPopup(popupId)) {

        // Eine PinPoint-Zeile. "feldWert" liest den Anzeigewert dieses
        // Feldes aus einem Zeitpunkt; "schrittAnwenden" wendet EINEN
        // (positiven oder negativen) Schritt auf einen Zeitpunkt an und
        // liefert den neuen Zeitpunkt -- dort steckt die eigentliche
        // Kalenderarithmetik samt Uebertrag, hier wird sie nur benutzt.

        changed |= PinPointZeile("Jahr", false, t, ImGui::GetContentRegionAvail().x,
            [](std::int64_t z) { return XbmTime_ToLocal(z).year; },
            [](std::int64_t z, int n) { return XbmTime_AddMonths(z, n * 12); });
        changed |= PinPointZeile("Monat", true, t, ImGui::GetContentRegionAvail().x,
            [](std::int64_t z) { return XbmTime_ToLocal(z).month; },
            [](std::int64_t z, int n) { return XbmTime_AddMonths(z, n); });
        changed |= PinPointZeile("Tag", true, t, ImGui::GetContentRegionAvail().x,
            [](std::int64_t z) { return XbmTime_ToLocal(z).day; },
            [](std::int64_t z, int n) { return XbmTime_AddDays(z, n); });
        changed |= PinPointZeile("Stunde", true, t, ImGui::GetContentRegionAvail().x,
            [](std::int64_t z) { return XbmTime_ToLocal(z).hour; },
            [](std::int64_t z, int n) { return z + (std::int64_t)n * 3600; });
        changed |= PinPointZeile("Minute", true, t, ImGui::GetContentRegionAvail().x,
            [](std::int64_t z) { return XbmTime_ToLocal(z).minute; },
            [](std::int64_t z, int n) { return z + (std::int64_t)n * 60; });

        ImGui::EndPopup();
    }
    return changed;
}

// Baum der Unter-Events unter einem Elternteil. nurTermine: auf Ebene 1 nur
// Unter-TERMINE (Erinnerungen stehen als Aktionszeilen). Liefert true, wenn
// das Modell geaendert wurde (Aufrufer muss seine Zeiger aufgeben).
static bool UnterEventsZeichnen(std::uint64_t eltern, bool nurTermine = false) {
    std::vector<xbm_tl::Knoten> baum = xbm_tl::Unterbaum(eltern);
    if (nurTermine) {
        std::vector<xbm_tl::Knoten> gefiltert; bool weg = false;
        for (const xbm_tl::Knoten& k : baum) { if (k.tiefe == 1) weg = !k.termin; if (!weg) gefiltert.push_back(k); }
        baum.swap(gefiltert);
    }
    const float einzug = ImGui::GetFontSize() * 1.2f;
    bool geaendert = false;
    const std::int64_t jetzt = XbmTime_NowUtc();
    ImGui::Indent(einzug);
    for (xbm_tl::Knoten& k : baum) {
        ImGui::PushID((int)(k.id & 0x7fffffff));
        ImGui::Indent(einzug * (float)(k.tiefe - 1));
        ImGui::TextDisabled("%s", k.tiefe > 1 ? "\u2514" : "\u2514"); ImGui::SameLine();
        // Titel
        static std::map<std::uint64_t, std::string> puffer;
        std::string& t = puffer[k.id]; if (!ImGui::IsItemActive() && t.empty()) t = k.titel;
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 9.0f);
        if (ImGui::InputText("##ut", &t, ImGuiInputTextFlags_EnterReturnsTrue) || (ImGui::IsItemDeactivatedAfterEdit())) {
            if (t != k.titel) { xbm_tl::KindAendern(k.id, t, k.versatzSek, k.durMin, jetzt); geaendert = true; }
        }
        ImGui::SameLine();
        // Versatz zum Elternteil in Minuten (negativ = davor)
        int vMin = (int)(k.versatzSek / 60);
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 4.5f);
        if (ImGui::InputInt("min", &vMin, 0, 0, ImGuiInputTextFlags_EnterReturnsTrue) || ImGui::IsItemDeactivatedAfterEdit()) {
            if ((std::int64_t)vMin * 60 != k.versatzSek) { xbm_tl::KindAendern(k.id, k.titel, (std::int64_t)vMin * 60, k.durMin, jetzt); geaendert = true; }
        }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Versatz zum uebergeordneten Termin: negativ = davor, positiv = danach");
        ImGui::SameLine();
        int d = k.durMin;
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 4.0f);
        if (ImGui::InputInt("Dauer", &d, 0, 0, ImGuiInputTextFlags_EnterReturnsTrue) || ImGui::IsItemDeactivatedAfterEdit()) {
            if (d != k.durMin && d >= 0) { xbm_tl::KindAendern(k.id, k.titel, k.versatzSek, d, jetzt); geaendert = true; }
        }
        ImGui::SameLine();
        {
            int sm = xbm_tl::Sicht(k.id);
            ImGui::SetNextItemWidth(ImGui::GetFontSize() * 7.5f);
            if (ImGui::Combo("##sicht", &sm, "immer\0nur ausgewaehlt\0nur aktiv\0")) { xbm_tl::SichtSetzen(k.id, sm, jetzt); geaendert = true; }
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Im Raster zeigen: immer / nur bei ausgewaehltem Obertermin / nur im Aktiv- oder Bearbeiten-Modus des Stammes");
        }
        ImGui::SameLine();
        if (ImGui::SmallButton(C().aktivEltern == k.id ? "aktiv!" : "aktiv")) { C().aktivEltern = (C().aktivEltern == k.id) ? 0 : k.id; }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Dieses Unter-Event als Elternteil fuer neue Termine");
        ImGui::SameLine();
        if (ImGui::SmallButton("+")) { xbm_tl::KindAnlegen(k.id, "", -600, 0, jetzt); geaendert = true; }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Unter-Event darunter anlegen (10 min davor)");
        ImGui::SameLine();
        if (ImGui::SmallButton("x")) { xbm_tl::KindLoeschen(k.id, jetzt); puffer.erase(k.id); geaendert = true; }
        ImGui::Unindent(einzug * (float)(k.tiefe - 1));
        ImGui::PopID();
        if (geaendert) break;
    }
    if (!geaendert) {
        ImGui::PushID((int)(eltern & 0x7fffffff));
        if (ImGui::SmallButton(nurTermine ? "+ Unter-Termin" : "+ Unter-Event")) { xbm_tl::KindAnlegen(eltern, "", nurTermine ? 3600 : -600, nurTermine ? 30 : 0, jetzt, nurTermine); geaendert = true; }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip(nurTermine ? "Ein eigener Termin, der an diesem haengt und mit ihm wandert (eigener Block im Raster)" : "Ein Termin, der an dieser Erinnerung haengt und mit ihr wandert");
        ImGui::PopID();
    }
    ImGui::Unindent(einzug);
    if (geaendert) { xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); xbm_tls::Anstossen(); }
    return geaendert;
}

// ---------------------------------------------------------------------------
// ZEIT-OVERLAY MIT DREI SPALTEN: links Start, Mitte Verschieben, rechts Ende
// -- jede Spalte die fuenf senkrechten Pinpoint-Zeilen (Jahr Monat Tag Std
// Min). Wirkung wie die Griffe im Raster; der Kalender fuehrt den bewegten
// Punkt mit (folgeZeit). Oeffnet sich per <-> neben dem Titel.
// ---------------------------------------------------------------------------
static void ZeitOverlay3(CalEntry* e) {
    auto& C_ = C();
    {
        ImGuiViewport* vp = ImGui::GetMainViewport();
        const float randAbstand = 10.0f;
        ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x + vp->WorkSize.x * 0.5f, vp->WorkPos.y + vp->WorkSize.y - randAbstand), ImGuiCond_Always, ImVec2(0.5f, 1.0f));
        ImGui::SetNextWindowSize(ImVec2(vp->WorkSize.x - 2 * randAbstand, 0.0f));
    }
    if (!ImGui::BeginPopup("##zeit3")) return;
    if (C_.zlOrigDur == 0) { C_.zlOrigEnde = e->end(); C_.zlOrigStart = e->start; C_.zlOrigDur = e->durMin; }
    const float abstand = ImGui::GetStyle().ItemSpacing.x;
    const float spalte = (ImGui::GetContentRegionAvail().x - 2.0f * abstand) / 3.0f;
    const char* titel[3] = { "Start", "Verschieben", "Ende" };
    for (int m = 0; m < 3; ++m) {
        if (m) ImGui::SameLine();
        ImGui::BeginGroup();
        ImGui::PushID(m);
        const ImVec2 tt = ImGui::CalcTextSize(titel[m]);
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + (spalte - tt.x) * 0.5f);
        ImGui::TextUnformatted(titel[m]);
        std::int64_t t = (m == 2) ? e->end() : e->start;
        bool ge = false;
        ge |= PinPointZeile("Jahr",   false, t, spalte, [](std::int64_t z) { return XbmTime_ToLocal(z).year; },   [](std::int64_t z, int n) { return XbmTime_AddMonths(z, n * 12); });
        ge |= PinPointZeile("Monat",  true,  t, spalte, [](std::int64_t z) { return XbmTime_ToLocal(z).month; },  [](std::int64_t z, int n) { return XbmTime_AddMonths(z, n); });
        ge |= PinPointZeile("Tag",    true,  t, spalte, [](std::int64_t z) { return XbmTime_ToLocal(z).day; },    [](std::int64_t z, int n) { return XbmTime_AddDays(z, n); });
        ge |= PinPointZeile("Stunde", true,  t, spalte, [](std::int64_t z) { return XbmTime_ToLocal(z).hour; },   [](std::int64_t z, int n) { return z + (std::int64_t)n * 3600; });
        ge |= PinPointZeile("Minute", true,  t, spalte, [](std::int64_t z) { return XbmTime_ToLocal(z).minute; }, [](std::int64_t z, int n) { return z + (std::int64_t)n * 60; });
        ImGui::PopID();
        ImGui::EndGroup();
        if (!ge) continue;
        C_.zlAktiv = true;
        switch (m) {
            case 0: {   // START: Ende bleibt, Dauer passt sich an
                const std::int64_t origEnde = C_.zlOrigEnde;
                UiCalendar_EventStartSetzen(*e, t);
                if (t < origEnde - 300) e->durMin = (int)((origEnde - t) / 60);
                else e->durMin = C_.zlOrigDur < 5 ? 5 : C_.zlOrigDur;
                C_.folgeZeit = e->start; break; }
            case 1:     // VERSCHIEBEN: Dauer bleibt
                UiCalendar_EventStartSetzen(*e, t); C_.zlOrigEnde = e->end(); C_.zlOrigStart = e->start; C_.folgeZeit = e->start; break;
            default: {  // ENDE: Start bleibt
                const std::int64_t origStart = C_.zlOrigStart;
                if (t > origStart + 300) { if (e->start != origStart) UiCalendar_EventStartSetzen(*e, origStart); e->durMin = (int)((t - origStart) / 60); }
                else { UiCalendar_EventStartSetzen(*e, t - (std::int64_t)C_.zlOrigDur * 60); e->durMin = C_.zlOrigDur < 5 ? 5 : C_.zlOrigDur; }
                C_.folgeZeit = e->end(); break; }
        }
        C_.folgeAn = true;
        UiCalendar_Touch(e->id);
    }
    if (!ImGui::GetIO().MouseDown[ImGuiMouseButton_Left]) C_.zlAktiv = false;
    ImGui::EndPopup();
}
// ---------------------------------------------------------------------------
// EXPLORER: faehrt aus dem Editor nach oben heraus und schwebt ueber dem
// Kalender. Baum vom obersten Elternteil des gewaehlten Termins, nach Lage
// im Kalender sortiert, einklappbar. Auswahl eines Knotens oeffnet unten im
// Fenster sein Bearbeitungsfeld (Termin / Erinnerung / Job). Drop-Ziel fuer
// Kalender-Termine (eigener Zug, siehe AktivenZugImZeitraster) und fuer
// Vorlagen aus Navi 1 (ImGui-Drag&Drop).
// ---------------------------------------------------------------------------
static void BaumWischen();
static void RandWischen();
static void DndFrame();
// HOEHE DES BAUM-BEREICHS (zwischen Kalender und Editor angedockt; der untere
// Rand des Kalenders klebt an seiner Oberkante). Animiert aus- und einfahren.
static float ExplorerHeight() {
    auto& C_ = C();
    const float lh = ImGui::GetTextLineHeightWithSpacing();
    const bool offen = C_.explorerOffen && xbm_tl::Geladen() && xbm_tl::Speicher().finde(C_.explorerWurzel);
    const float ziel = offen ? ImMin(ImGui::GetWindowSize().y * 0.6f, lh * 14.0f + C_.explorerExtra) : 0.0f;
    C_.explorerH += (ziel - C_.explorerH) * ImMin(1.0f, ImGui::GetIO().DeltaTime * 12.0f);
    if (!offen && C_.explorerH < 1.0f) C_.explorerH = 0.0f;
    return C_.explorerH;
}
static void ExplorerBereich() {
    auto& C_ = C();
    const float h = ExplorerHeight();
    if (h <= 0.0f) { C_.explorerHover = 0; return; }
    if (!xbm_tl::Speicher().finde(C_.explorerWurzel)) { C_.explorerOffen = false; return; }
    C_.explorerRect0 = ImGui::GetCursorScreenPos(); C_.explorerRect1 = ImVec2(C_.explorerRect0.x + ImGui::GetContentRegionAvail().x, C_.explorerRect0.y + h);
    ImGui::BeginChild("##cal_explorer", ImVec2(0, h), true, ImGuiWindowFlags_NoScrollbar);
    BaumWischen();
    const std::int64_t jetzt = XbmTime_NowUtc();
    std::vector<xbm_tl::BaumKnoten> baum = xbm_tl::Baum(C_.explorerWurzel);
    // Kopf
    ImGui::TextDisabled("Baum");
    ImGui::SameLine(); if (ImGui::SmallButton("Einfahren")) { C_.explorerOffen = false; C_.explorerExtra = 0; ImGui::EndChild(); return; }
    ImGui::SameLine(); if (ImGui::SmallButton("alles auf")) C_.explorerZu.clear();
    ImGui::SameLine(); if (ImGui::SmallButton("alles zu")) for (auto& n : baum) if (n.tiefe > 0) C_.explorerZu.insert(n.eltern);
    ImGui::Separator();
    // Baum (obere Haelfte, scrollbar)
    std::uint64_t hover = 0; bool geaendert = false;
    ImGui::BeginChild("##exp_baum", ImVec2(0, 0), false);
    const float einzug = ImGui::GetFontSize() * 1.3f;
    std::set<std::uint64_t> versteckt;   // Nachfahren eingeklappter Knoten
    for (const xbm_tl::BaumKnoten& n : baum) {
        if (versteckt.count(n.eltern) || C_.explorerZu.count(n.eltern)) { versteckt.insert(n.id); continue; }
        ImGui::PushID((int)(n.id & 0x7fffffff));
        if (n.tiefe > 0) ImGui::Indent(einzug * n.tiefe);   // [Indent(0) rueckt um die VORGABE ein -- die Wurzel stand damit weit rechts]
        bool hatKinder = false; for (const auto& m : baum) if (m.eltern == n.id) { hatKinder = true; break; }
        if (hatKinder) { if (ImGui::SmallButton(C_.explorerZu.count(n.id) ? ">" : "v")) { if (C_.explorerZu.count(n.id)) C_.explorerZu.erase(n.id); else C_.explorerZu.insert(n.id); } }
        else ImGui::TextDisabled(" .");
        ImGui::SameLine();
        const char* art = n.art == 2 ? "[Job]" : (n.art == 1 ? "[Erinnerung]" : "[Termin]");
        std::string serie;   // Wurzel: Serie? abgeloestes Vorkommen?
        if (n.tiefe == 0) if (const timeline::Event* we = xbm_tl::Speicher().finde(n.id)) {
            if (we->regel.aktiv()) serie = " (Serie)";
            else if (we->abgeloestVon) serie = " (abgeloestes Vorkommen)";
        }
        char zeit[16]; { const XbmLocalTime l = XbmTime_ToLocal(n.start); std::snprintf(zeit, sizeof(zeit), "%02d:%02d %02d.%02d.", l.hour, l.minute, l.day, l.month); }
        char lb[256]; std::snprintf(lb, sizeof(lb), "%s %s%s  %s%s###n", n.titel.empty() ? "(ohne Titel)" : n.titel.c_str(), art, serie.c_str(), zeit, n.aktiv ? "" : "  (aus)");
        if (ImGui::Selectable(lb, C_.explorerSel == n.id, ImGuiSelectableFlags_AllowOverlap)) {
            // AUSWAHL BEARBEITET UNTEN: Wurzel im Termin-Editor, alles andere im Unter-Termin-Editor
            C_.explorerSel = n.id;
            if (n.tiefe == 0) { C_.editingKind = 0; C_.editing = n.id; C_.selected = n.id; }
            else { C_.editingKind = n.id; C_.editing = n.id; C_.selected = n.id; }
        }
        if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem)) hover = n.id;
        // UMHAENGEN IM BAUM: Knoten ziehen und auf einem anderen loslassen ->
        // wird dessen Kind (Lage bleibt, Versatz wird neu gerechnet); auf der
        // Wurzel loslassen = direkt unter die Wurzel. Zyklen lehnt Einhaengen ab.
        if (n.tiefe > 0 && ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)) {
            const std::uint64_t kid = n.id; ImGui::SetDragDropPayload("XBM_KNOTEN", &kid, sizeof(kid));
            ImGui::Text("%s", n.titel.empty() ? "(ohne Titel)" : n.titel.c_str()); ImGui::EndDragDropSource();
        }
        if (ImGui::BeginDragDropTarget()) {
            if (const ImGuiPayload* pl = ImGui::AcceptDragDropPayload("XBM_VORLAGE")) { const std::uint64_t vid = *(const std::uint64_t*)pl->Data; if (xbm_tl::AusVorlageAlsKind(vid, n.id, 3600, jetzt)) geaendert = true; }
            if (const ImGuiPayload* pl = ImGui::AcceptDragDropPayload("XBM_KNOTEN")) { const std::uint64_t kid = *(const std::uint64_t*)pl->Data; if (kid != n.id && xbm_tl::Einhaengen(kid, n.id, jetzt)) { geaendert = true; C_.explorerSel = kid; } }
            ImGui::EndDragDropTarget();
        }
        if (n.tiefe > 0) ImGui::Unindent(einzug * n.tiefe);
        ImGui::PopID();
    }
    ImGui::EndChild();
    C_.explorerHover = hover;
    if ((C_.drag.id || C_.dnd.aktiv) && hover) { ImGui::SetTooltip("Loslassen: unter '%s' einhaengen", [&]{ for (auto& n : baum) if (n.id == hover) return n.titel.c_str(); return ""; }()); }
    ImGui::EndChild();
    if (geaendert) { xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); xbm_tls::Anstossen(); }
}
static void EditorKopieAbschliessen();
// WISCHEN AUF FREIER FLAECHE DES BEARBEITUNGSFENSTERS: nach unten schliesst
// den Editor (wie eine Navi herausgewischt wird), nach oben zieht den Baum
// (Explorer) weiter heraus -- oeffnet ihn, wenn er zu ist. Nur auf freier
// Flaeche: ueber einem Eingabefeld oder Knopf greift die Geste nicht.
static void EditorWischen() {
    ImGuiIO& io = ImGui::GetIO();
    static bool bewaffnet = false; static ImVec2 start;
    const bool imFenster = ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows | ImGuiHoveredFlags_AllowWhenBlockedByActiveItem);
    if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) && imFenster && !ImGui::IsAnyItemHovered() && !ImGui::IsAnyItemActive()) { bewaffnet = true; start = io.MousePos; }
    if (!io.MouseDown[ImGuiMouseButton_Left]) { bewaffnet = false; return; }
    if (!bewaffnet) return;
    const float dy = io.MousePos.y - start.y, dx = io.MousePos.x - start.x;
    if (fabsf(dy) < 40.0f || fabsf(dy) < fabsf(dx) * 1.5f) return;
    Claim(); bewaffnet = false;
    if (dy > 0) { C().editorEingefahren = true; SaveNow(); }
    else { C().explorerOffen = true; if (!C().explorerWurzel && C().editing) C().explorerWurzel = xbm_tl::Wurzel(ModellId(C().editing)); C().explorerExtra += ImGui::GetTextLineHeightWithSpacing() * 6.0f; }
}
// WISCHEN IM BAUM auf freier Flaeche: nach unten faehrt den Baum ein, nach
// oben faehrt das Bearbeitungsfenster aus (wenn es eingefahren war) --
// Dock-Kante unten: Kalender | Baum | Bearbeiten, wie die Navis an den Seiten.
static void BaumWischen() {
    ImGuiIO& io = ImGui::GetIO();
    static bool bewaffnet = false; static ImVec2 start;
    const bool imFenster = ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows | ImGuiHoveredFlags_AllowWhenBlockedByActiveItem);
    if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) && imFenster && !ImGui::IsAnyItemHovered() && !ImGui::IsAnyItemActive()) { bewaffnet = true; start = io.MousePos; }
    if (!io.MouseDown[ImGuiMouseButton_Left]) { bewaffnet = false; return; }
    if (!bewaffnet) return;
    const float dy = io.MousePos.y - start.y, dx = io.MousePos.x - start.x;
    if (fabsf(dy) < 40.0f || fabsf(dy) < fabsf(dx) * 1.5f) return;
    Claim(); bewaffnet = false;
    if (dy > 0) { C().explorerOffen = false; C().explorerExtra = 0; }
    else if (C().editing && C().editorEingefahren) C().editorEingefahren = false;
    else C().explorerExtra += ImGui::GetTextLineHeightWithSpacing() * 6.0f;
}
// VON UNTEN HEREINWISCHEN (unterer Fensterrand, Zug nach oben): faehrt das
// eingefahrene Bearbeitungsfenster aus, sonst den Baum des ausgewaehlten
// Termins -- das senkrechte Gegenstueck zu den Navis an den Seiten.
static void RandWischen() {
    ImGuiIO& io = ImGui::GetIO();
    static bool bewaffnet = false; static ImVec2 start;
    const ImVec2 wp = ImGui::GetWindowPos(), ws = ImGui::GetWindowSize();
    const bool amRand = io.MousePos.x >= wp.x && io.MousePos.x <= wp.x + ws.x && io.MousePos.y >= wp.y + ws.y - 28.0f && io.MousePos.y <= wp.y + ws.y;
    if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) && amRand && !ImGui::IsAnyItemActive() && !C().drag.id && !C().dnd.id) { bewaffnet = true; start = io.MousePos; }
    if (!io.MouseDown[ImGuiMouseButton_Left]) { bewaffnet = false; return; }
    if (!bewaffnet) return;
    const float dy = io.MousePos.y - start.y, dx = io.MousePos.x - start.x;
    if (dy > -40.0f || fabsf(dy) < fabsf(dx) * 1.5f) return;
    Claim(); bewaffnet = false;
    if (C().editing && C().editorEingefahren) { C().editorEingefahren = false; return; }
    if (C().selected && !C().editing) { C().editorEingefahren = false; EditorOeffnen(C().selected); return; }
    if (C().selected && xbm_tl::Geladen() && !C().explorerOffen) { C().explorerWurzel = xbm_tl::Wurzel(ModellId(C().selected)); C().explorerSel = ModellId(C().selected); C().explorerOffen = true; }
}
// DRAG & DROP eines nicht ausgewaehlten Termins: ab 12 px Bewegung folgt ein
// Symbol (Titel in Terminfarbe) dem Finger; der Termin bleibt im Kalender.
// Loslassen auf einem Baumknoten = Unter-Termin davon, im Abschnitt
// "Papierkorb" der Navi 1 = loeschen, im Abschnitt "Vorlagen" = als Vorlage.
// Ohne Bewegung ist es ein Tipp (Auswahl / Editor wie bisher).
static void DndFrame() {
    auto& D = C().dnd; if (!D.id) return;
    ImGuiIO& io = ImGui::GetIO();
    const ImVec2 mp = io.MousePos;
    if (!D.aktiv) {
        const float dx = mp.x - D.pressPos.x, dy = mp.y - D.pressPos.y;
        if (dx * dx + dy * dy > 144.0f) D.aktiv = true;
    }
    if (D.aktiv) {
        Claim();
        ImDrawList* fg = ImGui::GetForegroundDrawList();
        const ImVec2 ts = ImGui::CalcTextSize(D.titel.c_str());
        const ImVec2 a(mp.x + 14.0f, mp.y - ts.y * 0.5f - 4.0f), b(mp.x + 14.0f + ts.x + 12.0f, mp.y + ts.y * 0.5f + 4.0f);
        fg->AddRectFilled(a, b, (D.farbe & 0x00ffffff) | (220u << 24), 4.0f);
        fg->AddRect(a, b, IM_COL32(255, 255, 255, 180), 4.0f);
        fg->AddText(ImVec2(a.x + 6.0f, a.y + 4.0f), IM_COL32(255, 255, 255, 240), D.titel.c_str());
        fg->AddCircleFilled(mp, 5.0f, (D.farbe & 0x00ffffff) | (255u << 24));
    }
    if (io.MouseDown[ImGuiMouseButton_Left]) return;
    // LOSLASSEN
    const std::uint64_t id = D.id; const bool bewegt = D.aktiv; D = CalState::Dnd{};
    if (!bewegt) { EditorOeffnen(id); return; }
    const std::int64_t jetzt = XbmTime_NowUtc();
    const std::uint64_t mid = ModellId(id);
    auto in = [&](const std::pair<ImVec2, ImVec2>& r) { return mp.x >= r.first.x && mp.x <= r.second.x && mp.y >= r.first.y && mp.y <= r.second.y; };
    if (C().explorerHover && xbm_tl::Geladen() && mid) {
        if (xbm_tl::Einhaengen(mid, C().explorerHover, jetzt)) { xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); xbm_tls::Anstossen(); C().explorerSel = mid; }
        return;
    }
    auto& rects = UiNavi::AbschnittRects();
    if (rects.count("Papierkorb") && in(rects["Papierkorb"])) { UiCalendar_Remove(id); SaveNow(); return; }
    if (rects.count("Vorlagen") && in(rects["Vorlagen"]) && xbm_tl::Geladen() && mid) { xbm_tl::AlsVorlage(mid, jetzt); xbm_tl::Speichern(); xbm_tls::Anstossen(); return; }
}
// Editor einer Kopie geschlossen: hat sich etwas geaendert, fragen.
static void EditorKopieAbschliessen() {
    if (!C().editKopieAktiv) return;
    C().editKopieAktiv = false;
    const CalEntry& k = C().editKopie; const CalEntry& o = C().editOriginal;
    const bool gleich = k.title == o.title && k.notes == o.notes && k.start == o.start && k.durMin == o.durMin && k.allDay == o.allDay
                     && k.color == o.color && k.remindOn == o.remindOn && k.remindMin == o.remindMin && k.actions.size() == o.actions.size()
                     && k.memos.size() == o.memos.size();
    bool aktGleich = gleich;
    if (gleich) for (std::size_t i = 0; i < k.actions.size(); ++i) { const auto& a = k.actions[i]; const auto& b = o.actions[i];
        if (a.art != b.art || a.start != b.start || a.durMin != b.durMin || a.text != b.text || a.ziel != b.ziel || a.ton != b.ton || a.aktiv != b.aktiv || a.getan != b.getan) { aktGleich = false; break; } }
    if (gleich && aktGleich) return;
    const CalState::VirtOcc* v = VirtOccFuer(k.id); if (!v) return;
    C().serienFrage = {}; C().serienFrage.offen = true; C().serienFrage.art = 1;
    C().serienFrage.base = v->base; C().serienFrage.occStart = v->occStart; C().serienFrage.kopie = k;
}
// Felder der Kopie auf ein (neu projiziertes) Event uebertragen; Aktionen
// nach Position, weil das Ziel eigene Kind-Ids hat.
static void KopieAnwenden(CalEntry& ziel, const CalEntry& kopie, std::int64_t neuerStart) {
    const std::uint64_t id = ziel.id; const CalWiederholung wdh = ziel.wdh; const std::int64_t bis = ziel.wdhBis; const int jede = ziel.wdhJede;
    std::vector<CalAction> alt = ziel.actions;
    ziel = kopie; ziel.id = id; ziel.wdh = wdh; ziel.wdhBis = bis; ziel.wdhJede = jede;
    const std::int64_t delta = neuerStart - kopie.start; ziel.start = neuerStart;
    for (std::size_t i = 0; i < ziel.actions.size(); ++i) { ziel.actions[i].id = i < alt.size() ? alt[i].id : 0; ziel.actions[i].start += delta; }
}
static void SerienFrageAbfrage() {
    auto& f = C().serienFrage;
    if (!f.offen) return;
    const char* titel = f.art == 2 ? "Serientermin loeschen" : "Serientermin geaendert";
    if (!ImGui::IsPopupOpen(titel)) ImGui::OpenPopup(titel);
    if (ImGui::BeginPopupModal(titel, nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextUnformatted(f.art == 2 ? "Loeschen:" : "Aenderung gilt fuer:");
        ImGui::Spacing();
        const float b = ImGui::GetFontSize() * 14.0f; int wahl = -1;
        if (ImGui::Button("Nur diesen Termin", ImVec2(b, 0))) wahl = 0;
        if (ImGui::Button("Ab hier", ImVec2(b, 0))) wahl = 1;
        if (ImGui::Button("Ganze Serie", ImVec2(b, 0))) wahl = 2;
        ImGui::Spacing();
        if (ImGui::Button("Abbrechen", ImVec2(b, 0))) wahl = 3;
        if (wahl >= 0) {
            const std::int64_t jetzt = XbmTime_NowUtc();
            if (wahl != 3) {
                if (f.art == 2) {
                    if (wahl == 0) { std::uint64_t r = xbm_tl::NurDiesen(f.base, f.occStart, f.occStart, jetzt); xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); if (r) UiCalendar_Remove(r); }
                    else if (wahl == 1) { if (CalEntry* e = UiCalendar_Find(f.base)) { if (f.occStart <= e->start) UiCalendar_Remove(e->id); else { e->wdhBis = f.occStart - 1; UiCalendar_Touch(e->id); } } }
                    else UiCalendar_Remove(f.base);
                } else {
                    if (wahl == 0 || wahl == 1) {
                        std::uint64_t z = wahl == 0 ? xbm_tl::NurDiesen(f.base, f.occStart, f.kopie.start, jetzt) : xbm_tl::AbHier(f.base, f.occStart, f.kopie.start, jetzt);
                        xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden();
                        if (CalEntry* e = UiCalendar_Find(z)) { KopieAnwenden(*e, f.kopie, f.kopie.start); UiCalendar_Touch(e->id); }
                    } else if (CalEntry* e = UiCalendar_Find(f.base)) {
                        KopieAnwenden(*e, f.kopie, e->start + (f.kopie.start - f.occStart)); UiCalendar_Touch(e->id);
                    }
                }
                C().dirty = true; UiCalendar_Save();
            }
            f = CalState::SerienFrage{};
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }
}
// ---------------------------------------------------------------------------
// EDITOR FUER EINEN UNTER-TERMIN -- derselbe Platz unten wie beim Termin,
// dieselben Elemente: Titel mit <-> (Versatz/Dauer) und Baum, Notizen, Art,
// Versatz, Dauer, Farbe, ganztaegig, Erinnerung, Job-Befehl, Sichtbarkeit,
// aktiv, eigene Unter-Termine, herausloesen, loeschen. Was ein Unter-Termin
// nicht hat: eine eigene Wiederholung (er folgt dem Elternteil).
// ---------------------------------------------------------------------------
static bool KindEditor(std::uint64_t kindId) {
    const std::int64_t jetzt = XbmTime_NowUtc();
    timeline::Event* k = xbm_tl::Speicher().finde(kindId);
    if (!k) return false;
    bool ge = false;
    const std::uint64_t w = xbm_tl::Wurzel(kindId);
    C().editorRect0 = ImGui::GetCursorScreenPos(); C().editorRect1 = ImVec2(C().editorRect0.x + ImGui::GetContentRegionAvail().x, C().editorRect0.y + EditorHeight());
    ImGui::BeginChild("##kindedit", ImVec2(0, EditorHeight()), false);
    EditorWischen();
    const float knopfB = ImGui::GetFrameHeight() * 1.6f;
    // Titel + <-> + Baum (eine Zeile)
    static std::map<std::uint64_t, std::string> puffer; std::string& t = puffer[kindId];
    const std::string titelModell = timeline::wTitel(xbm_tl::Speicher(), *k);
    if (!ImGui::IsAnyItemActive() && t != titelModell) t = titelModell;
    const bool aktivX = C().aktivEltern != 0;
    ImGui::SetNextItemWidth(-(2.0f * knopfB + 2.0f * ImGui::GetStyle().ItemSpacing.x + (aktivX ? ImGui::GetFrameHeight() + ImGui::GetStyle().ItemSpacing.x : 0.0f)));
    if (ImGui::InputText("##ktitel", &t, ImGuiInputTextFlags_EnterReturnsTrue) || ImGui::IsItemDeactivatedAfterEdit()) { if (t != titelModell) { xbm_tl::KindAendern(kindId, t, k->versatz, k->durMin, jetzt); ge = true; } }
    ImGui::SameLine();
    if (aktivX) {
        ImGui::PushStyleColor(ImGuiCol_Button, IM_COL32(255, 200, 60, 70)); ImGui::PushStyleColor(ImGuiCol_ButtonHovered, IM_COL32(255, 200, 60, 120)); ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(255, 200, 60, 230));
        if (ImGui::Button("x", ImVec2(ImGui::GetFrameHeight(), 0))) C().aktivEltern = 0;
        ImGui::PopStyleColor(3);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Unter-Termine anlegen beenden");
        ImGui::SameLine();
    }
    if (ImGui::Button("<->", ImVec2(knopfB, 0))) ImGui::OpenPopup("##kzeit");
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Versatz zum Elternteil und Dauer");
    ImGui::SameLine();
    if (C().explorerOffen) ImGui::PushStyleColor(ImGuiCol_Button, ImGui::GetStyleColorVec4(ImGuiCol_ButtonActive));
    if (ImGui::Button("Baum", ImVec2(knopfB, 0))) { C().explorerOffen = !C().explorerOffen; if (C().explorerOffen) { C().explorerWurzel = w; C().explorerSel = kindId; } }
    if (C().explorerOffen) ImGui::PopStyleColor();
    if (ImGui::BeginPopup("##kzeit")) {
        int vMin = (int)(k->versatz / 60), d = k->durMin;
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 5.0f);
        if (ImGui::InputInt("min nach Start des Elternteils", &vMin, 5, 60)) { xbm_tl::KindAendern(kindId, t, (std::int64_t)vMin * 60, k->durMin, jetzt); ge = true; }
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 5.0f);
        if (ImGui::InputInt("Dauer (min)", &d, 5, 60)) { if (d >= 0) { xbm_tl::KindAendern(kindId, t, k->versatz, d, jetzt); ge = true; } }
        ImGui::EndPopup();
    }
    {   // Pfad
        const timeline::Event* we = xbm_tl::Speicher().finde(w);
        ImGui::TextDisabled("Unter-Termin von: %s", we ? timeline::wTitel(xbm_tl::Speicher(), *we).c_str() : "?");
        ImGui::SameLine(); if (ImGui::SmallButton("oeffnen")) { C().editingKind = 0; C().editing = w; C().selected = w; ImGui::EndChild(); return false; }
    }
    // Notizen
    {
        static std::map<std::uint64_t, std::string> npuffer; std::string& nz = npuffer[kindId];
        const std::string nModell = timeline::wNotizen(xbm_tl::Speicher(), *k);
        if (!ImGui::IsAnyItemActive() && nz != nModell) nz = nModell;
        ImGui::SetNextItemWidth(-1.0f);
        if (ImGui::InputTextMultiline("##knotizen", &nz, ImVec2(-1.0f, ImGui::GetTextLineHeight() * 2.5f)) || ImGui::IsItemDeactivatedAfterEdit()) {
            if (nz != nModell) { k->notizen = nz; xbm_tl::Speicher().geaendert(*k, jetzt); ge = true; }
        }
    }
    // Art, Farbe, ganztaegig
    int art = k->art == timeline::Art::Aktion ? 2 : (k->art == timeline::Art::Benachrichtigung ? 1 : 0);
    ImGui::SetNextItemWidth(ImGui::GetFontSize() * 7.0f);
    if (ImGui::Combo("##kart", &art, "Termin\0Erinnerung\0Job\0")) { xbm_tl::KindArtSetzen(kindId, art, jetzt); ge = true; }
    ImGui::SameLine();
    {
        bool eigene = k->farbe.gesetzt; const ImU32 f = eigene ? (ImU32)k->farbe.wert : 0;
        if (ImGui::Checkbox("eigene Farbe", &eigene)) {
            if (eigene) { const CalEntry* we = UiCalendar_Find(w); k->farbe = (std::uint32_t)(we ? EntryColor(*we) : IM_COL32(120, 160, 220, 255)); }
            else k->farbe = timeline::Opt<std::uint32_t>{};
            xbm_tl::Speicher().geaendert(*k, jetzt); ge = true;
        }
        if (eigene) {
            ImGui::SameLine(); ImVec4 c = ImGui::ColorConvertU32ToFloat4(f);
            if (ImGui::ColorEdit3("##kfarbe", &c.x, ImGuiColorEditFlags_NoInputs)) { k->farbe = (std::uint32_t)ImGui::ColorConvertFloat4ToU32(c); xbm_tl::Speicher().geaendert(*k, jetzt); ge = true; }
        }
    }
    ImGui::SameLine();
    { bool ad = k->allDay; if (ImGui::Checkbox("ganztaegig", &ad)) { k->allDay = ad; xbm_tl::Speicher().geaendert(*k, jetzt); ge = true; } }
    // Erinnerung
    {
        bool an = k->erinnernMin.gesetzt; int min = an ? k->erinnernMin.wert : 10;
        if (ImGui::Checkbox("Erinnerung", &an)) { if (an) k->erinnernMin = min; else k->erinnernMin = timeline::Opt<int>{}; xbm_tl::Speicher().geaendert(*k, jetzt); ge = true; }
        if (an) { ImGui::SameLine(); ImGui::SetNextItemWidth(ImGui::GetFontSize() * 4.0f); if (ImGui::InputInt("min vorher", &min, 0, 0, ImGuiInputTextFlags_EnterReturnsTrue) || ImGui::IsItemDeactivatedAfterEdit()) { if (min >= 0) { k->erinnernMin = min; xbm_tl::Speicher().geaendert(*k, jetzt); ge = true; } } }
    }
    // Job
    if (art == 2) {
        timeline::Aktion a = k->aktion.gesetzt ? k->aktion.wert : timeline::Aktion{};
        std::string befehl = a.befehl;
        ImGui::SetNextItemWidth(-1.0f);
        if (ImGui::InputText("Befehl / queue:<id>", &befehl, ImGuiInputTextFlags_EnterReturnsTrue) || ImGui::IsItemDeactivatedAfterEdit()) { if (befehl != a.befehl) { a.befehl = befehl; k->aktion = a; xbm_tl::Speicher().geaendert(*k, jetzt); ge = true; } }
    }
    // Sicht, aktiv, Unter-Termine
    int sm = xbm_tl::Sicht(kindId); ImGui::SetNextItemWidth(ImGui::GetFontSize() * 8.0f);
    if (ImGui::Combo("im Raster", &sm, "immer\0nur ausgewaehlt\0nur aktiv\0")) { xbm_tl::SichtSetzen(kindId, sm, jetzt); ge = true; }
    ImGui::SameLine(); int ks = xbm_tl::KinderSicht(kindId); ImGui::SetNextItemWidth(ImGui::GetFontSize() * 8.0f);
    if (ImGui::Combo("Kinder", &ks, "immer\0nur ausgewaehlt\0nur aktiv\0")) { xbm_tl::KinderSichtSetzen(kindId, ks, jetzt); ge = true; }
    ImGui::SameLine(); if (ImGui::SmallButton(C().aktivEltern == kindId ? "aktiv!" : "aktiv")) C().aktivEltern = (C().aktivEltern == kindId) ? 0 : kindId;
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Neue Termine werden Unter-Termine von diesem");
    ImGui::TextDisabled("Unter-Termine");
    if (UnterEventsZeichnen(kindId, /*nurTermine=*/true)) ge = true;
    if (ImGui::Button("Schliessen")) { C().editingKind = 0; C().editing = 0; }
    ImGui::SameLine(); if (ImGui::Button("herausloesen")) { if (xbm_tl::Einhaengen(kindId, 0, jetzt)) { ge = true; C().editingKind = 0; C().editing = 0; C().selected = 0; } }
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Wird eigenstaendiger Termin an seiner Lage");
    ImGui::SameLine(); if (ImGui::Button("Loeschen")) { xbm_tl::KindLoeschen(kindId, jetzt); ge = true; C().editingKind = 0; C().editing = 0; C().selected = 0; }
    C().editorMeasured = ImGui::GetCursorPosY() + ImGui::GetStyle().WindowPadding.y;
    ImGui::EndChild();
    return ge;
}

void DrawEditor() {
    // Hoehe dieses Frames merken -- EditorHeight() reserviert damit im
    // naechsten Frame genau so viel Platz, wie der Inhalt braucht.
    // (Gemessen wird weiter unten, INNERHALB des Kindfensters.)
    if (!C().editing) { C().editingKind = 0; return; }
    if (C().editorEingefahren && C().selected) return;   // bleibt eingefahren, Auswahl und Zustand erhalten
    // KEIN EVENT MEHR AUSGEWAEHLT -> EDITOR VERSCHWINDET AUCH.
    // [C().selected wird an mehreren Stellen auf 0 gesetzt (Klick auf
    //  leere Flaeche, Spaltenkopf...), OHNE dass C().editing dort mit
    //  zurueckgesetzt wurde -- der Editor zeigte danach weiter den
    //  zuletzt bearbeiteten, inzwischen abgewaehlten Eintrag an. Beide
    //  Zustaende muessen hier uebereinstimmen.]
    if (C().selected == 0) { C().editing = 0; C().editingKind = 0; return; }
    if (C().editingKind) {   // UNTER-TERMIN: derselbe Editorplatz unten
        if (!xbm_tl::Speicher().finde(C().editingKind)) { C().editingKind = 0; C().editing = 0; return; }
        if (KindEditor(C().editingKind)) { xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); xbm_tls::Anstossen(); }
        return;
    }
    CalEntry* e = UiCalendar_Find(C().editing);
    if (!e) { C().editing = 0; return; }

    // Puffer bei Wechsel des bearbeiteten Eintrags fuellen.
    if (C().bufFor != e->id) {
        C().bufFor   = e->id;
        C().bufTitle = e->title;
        C().bufNotes = e->notes;
    }
    // TASTATUR-SOFORTANLAGE: nur noch die FOKUS-WEICHE.
    // [UiCalendar_TypeToCreate/das Tab-Anlegen haben den Eintrag angelegt
    //  und hier vorgemerkt. Das AUSLOESENDE ZEICHEN selbst wird NICHT
    //  MEHR von Hand eingefuegt -- es steht (falls kein Tab war) noch in
    //  ImGuis eigener Zeichen-Warteschlange und wird gleich, sobald das
    //  Titelfeld unten den Fokus bekommt, ganz normal von ImGui selbst
    //  verarbeitet. Nur einmal: pendingFirstCharFor wird danach auf 0
    //  gesetzt.]
    using EF = CalState::EdFokus;
    if (C().pendingFirstCharFor == e->id) {
        if (C().pendingFirstIstTab) {
            // TAB STATT EINES ZEICHENS BEI DER NEUANLAGE: der Fokus geht
            // sofort in die Notiz -- OHNE Markierung, das Feld ist ja
            // ohnehin leer, und es soll "einfach sofort" losgeschrieben
            // werden koennen.
            C().edFokus = EF::NotizEnde;
        } else {
            // DAS AUSLOESENDE ZEICHEN (und alles, was im selben Frame
            // noch hinterherkam) JETZT EINSETZEN.
            // [Es kann NICHT aus der Zeichen-Warteschlange kommen --
            //  Begruendung siehe UiCalendar_TypeToCreate.]
            if (!C().pendingFirstText.empty()) {
                if (C().pendingReplaceMode) {
                    // BESTEHENDES EVENT WAR AUSGEWAEHLT: der bisherige
                    // Titel wird KOMPLETT ERSETZT. [Steht hier und nicht
                    //  schon beim Tippen, weil der Puffer weiter oben
                    //  gerade erst aus e->title neu befuellt worden sein
                    //  koennte -- ein Leeren davor waere damit wirkungslos
                    //  gewesen.]
                    C().bufTitle = C().pendingFirstText;
                } else {
                    // NEU ANGELEGTES EVENT: der Titel ist leer, das
                    // Zeichen wird einfach angehaengt.
                    C().bufTitle += C().pendingFirstText;
                }
                e->title = C().bufTitle;
                C().dirty = true;
            }
            // CURSOR ANS ENDE -- ausdruecklich NICHT TitelVoll.
            // [TitelVoll setzt AutoSelectAll. Das markiert beim
            //  Fokus-Gewinn den GESAMTEN Inhalt -- also genau das eben
            //  eingesetzte erste Zeichen. Der naechste Tastendruck
            //  ersetzt eine Markierung, womit das erste Zeichen wieder
            //  verschwunden waere: dasselbe Schadensbild ("erster
            //  Buchstabe verschluckt"), nur eine Stufe spaeter.
            //  ABER: TitelEnde allein genuegt NICHT. ImGui markiert bei
            //  Fokus ueber die TASTATUR auch ohne AutoSelectAll alles.
            //  Deshalb zusaetzlich der Rueckruf, der Markierung und
            //  Cursor fuer die naechsten Frames ausdruecklich setzt.]
            C().edFokus = EF::TitelEnde;
            C().titelCursorAnsEnde = 30;   // nur Obergrenze, siehe DrawEditor
            C().titelCursorAktivFrames = 0;
        }
        C().pendingFirstChar    = 0;
        C().pendingFirstText.clear();
        C().pendingFirstIstTab  = false;
        C().pendingReplaceMode  = false;
        C().pendingFirstCharFor = 0;
    }

    ImGui::Separator();
    C().editorRect0 = ImGui::GetCursorScreenPos(); C().editorRect1 = ImVec2(C().editorRect0.x + ImGui::GetContentRegionAvail().x, C().editorRect0.y + EditorHeight());
    ImGui::BeginChild("##caledit", ImVec2(0, EditorHeight()), false);
    EditorWischen();
    const float zeitKnopfB = ImGui::GetFrameHeight() * 1.6f;   // <-> rechts neben dem Titel, keine eigene Zeile

    // TITELFELD -- mit derselben Zirkulation wie die Bulk-Felder:
    // Tab springt in die Notiz (komplett markiert), von dort zurueck in
    // den Titel (ebenfalls komplett markiert).
    ImGuiInputTextFlags titelFlags = 0;
    if (C().edFokus == EF::TitelVoll) {
        ImGui::SetKeyboardFocusHere();
        titelFlags |= ImGuiInputTextFlags_AutoSelectAll;
        C().edFokus = EF::Keine;
    } else if (C().edFokus == EF::TitelEnde) {
        ImGui::SetKeyboardFocusHere();   // ohne AutoSelectAll: Cursor ans Ende
        C().edFokus = EF::Keine;
    }
    // MARKIERUNG AUSDRUECKLICH AUFHEBEN, bis das Feld WIRKLICH aktiv ist.
    // [Vorher lief der Rueckruf fest zwei Frames -- geraten aus der
    //  Annahme, der Fokus greife im Frame NACH SetKeyboardFocusHere.
    //  Greift er aber einen Frame spaeter (etwa weil dieser Editor erst
    //  im Frame NACH dem Tastenschlag gezeichnet wird), lief der
    //  Rueckruf genau im entscheidenden Frame schon nicht mehr -- und
    //  ImGui markierte das erste Zeichen doch wieder. Jetzt: der
    //  Rueckruf bleibt eingehaengt, bis IsItemActive() bestaetigt, dass
    //  das Feld den Fokus hat, und laeuft dann noch zwei aktive Frames
    //  weiter. titelCursorAnsEnde dient nur noch als Obergrenze, damit
    //  er nicht ewig laeuft, falls das Feld den Fokus nie bekommt.]
    const bool cursorErzwingen = (C().titelCursorAnsEnde > 0);
    if (cursorErzwingen) titelFlags |= ImGuiInputTextFlags_CallbackAlways;
    const bool baumMoeglich = !IstVirtuell(e->id) && xbm_tl::Geladen();
    const bool aktivX = C().aktivEltern != 0;
    ImGui::SetNextItemWidth(-((baumMoeglich ? 2.0f : 1.0f) * (zeitKnopfB + ImGui::GetStyle().ItemSpacing.x) + (aktivX ? ImGui::GetFrameHeight() + ImGui::GetStyle().ItemSpacing.x : 0.0f)));
    if (ImGui::InputText("##titel", &C().bufTitle, titelFlags,
                         cursorErzwingen ? XbmCursorAnsEnde : nullptr)) {
        e->title = C().bufTitle;
        C().dirty = true;
    }
    ImGui::SameLine();
    if (aktivX) {   // AKTIV-MODUS BEENDEN: "x" in der Farbe der Umrandung
        ImGui::PushStyleColor(ImGuiCol_Button, IM_COL32(255, 200, 60, 70)); ImGui::PushStyleColor(ImGuiCol_ButtonHovered, IM_COL32(255, 200, 60, 120)); ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(255, 200, 60, 230));
        if (ImGui::Button("x", ImVec2(ImGui::GetFrameHeight(), 0))) C().aktivEltern = 0;
        ImGui::PopStyleColor(3);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Unter-Termine anlegen beenden");
        ImGui::SameLine();
    }
    if (ImGui::Button("<->", ImVec2(zeitKnopfB, 0))) { C().zlOrigDur = 0; ImGui::OpenPopup("##zeit3"); }
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Zeiten setzen: Start | Verschieben | Ende");
    ZeitOverlay3(e);
    if (baumMoeglich) {   // BAUM: oben neben <-> -- ein Baumfenster je Baum, Auswahl bearbeitet unten
        ImGui::SameLine();
        if (C().explorerOffen) ImGui::PushStyleColor(ImGuiCol_Button, ImGui::GetStyleColorVec4(ImGuiCol_ButtonActive));
        if (ImGui::Button("Baum", ImVec2(zeitKnopfB, 0))) { C().explorerOffen = !C().explorerOffen; if (C().explorerOffen) { C().explorerWurzel = xbm_tl::Wurzel(e->id); C().explorerSel = e->id; } }
        if (C().explorerOffen) ImGui::PopStyleColor();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Explorer: der ganze Baum dieses Termins ueber dem Kalender; was dort gewaehlt wird, bearbeitet man hier unten");
    }
    if (cursorErzwingen) {
        if (ImGui::IsItemActive()) {
            if (++C().titelCursorAktivFrames >= 2) {
                C().titelCursorAnsEnde     = 0;
                C().titelCursorAktivFrames = 0;
            }
        } else if (--C().titelCursorAnsEnde <= 0) {
            C().titelCursorAnsEnde     = 0;   // Obergrenze erreicht
            C().titelCursorAktivFrames = 0;
        }
    }
    if (ImGui::IsItemFocused() && ImGui::IsKeyPressed(ImGuiKey_Tab, false))
        C().edFokus = EF::NotizVoll;   // naechster Frame: Notiz, komplett markiert

    // (Start/Verschieben/Ende: siehe Zeitleiste oben im Editor -- Symbol <->)

    for (size_t ai = 0; ai < e->actions.size(); ++ai) {
        CalAction& a = e->actions[ai];
        ImGui::PushID((int)(a.id & 0x7fffffff));

        if (ImGui::Checkbox("##aktiv", &a.aktiv)) {
            // UiCalendar_Save() statt nur SaveNow() -- WICHTIG.
            // [SaveNow() schreibt nur die Datei; das Anmelden beim
            //  Android-AlarmManager passiert NUR in
            //  UiCalendar_AlarmeNeuSetzen(), das UiCalendar_Save() extra
            //  aufruft. Bisher wurde hier nur SaveNow() gerufen -- die
            //  Aenderung stand zwar in der Datei, aber der schon
            //  GEPLANTE Alarm blieb unveraendert (weiter aktiv, mit dem
            //  ALTEN Ton) bis zum naechsten App-Start. Genau das faellt
            //  als "Ton laesst sich nicht auswaehlen" bzw. "Erinnerung
            //  laesst sich nicht abschalten" auf -- die Aenderung WIRKTE
            //  einfach noch nicht.]
            UiCalendar_Touch(e->id); UiCalendar_Save();
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip(a.aktiv ? "Erinnerung ist aktiv" : "Erinnerung ist stummgeschaltet");
        ImGui::SameLine();

        // STATISCH: bleibt an ihrer Uhrzeit, wenn das Event verschoben
        // wird -- sonst wandert sie standardmaessig relativ mit.
        if (ImGui::Checkbox("statisch", &a.statisch)) {
            UiCalendar_Touch(e->id); UiCalendar_Save();
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip(a.statisch
                ? "Bleibt an ihrer Uhrzeit stehen, auch wenn das Event verschoben wird"
                : "Wandert mit -- derselbe Abstand zum Event bleibt beim Verschieben erhalten");
        ImGui::SameLine();

        // Abstand zum Termin, IMMER aus dem aktuellen Stand gerechnet --
        // nur noch als Anzeige, der Knopf oeffnet das Datum/Uhrzeit-Overlay.
        long vorMin = (long)((e->start - a.start) / 60);
        char schild[64];
        if (vorMin >= 0) ImFormatString(schild, sizeof(schild), "%ld min vorher", vorMin);
        else             ImFormatString(schild, sizeof(schild), "%ld min danach", -vorMin);
        if (ImGui::SmallButton(schild)) {
            char pid[16]; std::snprintf(pid, sizeof(pid), "##azeit%zu", ai);
            ImGui::OpenPopup(pid);
        }
        {
            char pid[16]; std::snprintf(pid, sizeof(pid), "##azeit%zu", ai);
            if (DatumZeitOverlay(pid, a.start)) { UiCalendar_Touch(e->id); UiCalendar_Save(); }
        }
        // ALARMTON WAEHLEN: die Memos des Events, oder der Standardton.
        // [Mehr Auswahl braucht einen Dateiwaehler; die Memos sind das,
        //  was hier ohnehin liegt -- und du wolltest sie als Ton.]
        ImGui::SameLine();
        {
            const char* jetzt = a.ton.empty() ? "Standardton" : a.ton.c_str();
            ImGui::SetNextItemWidth(150.0f);
            if (ImGui::BeginCombo("##ton", jetzt)) {
                if (ImGui::Selectable("Standardton", a.ton.empty())) {
                    a.ton.clear(); UiCalendar_Touch(e->id); UiCalendar_Save();
                }
                for (const auto& m : e->memos) {
                    if (m.audio.empty()) continue;
                    bool sel = (a.ton == m.audio);
                    if (ImGui::Selectable(m.audio.c_str(), sel)) {
                        a.ton = m.audio; UiCalendar_Touch(e->id); UiCalendar_Save();
                    }
                }
                if (e->memos.empty())
                    ImGui::TextDisabled("(keine Memo an diesem Event)");
                ImGui::EndCombo();
            }
        }
        ImGui::SameLine();
        if (ImGui::SmallButton("x")) {
            UiCalendar_ActionLoeschen(e->id, a.id);
            UiCalendar_Touch(e->id); UiCalendar_Save();
            ImGui::PopID();
            break;               // Liste hat sich geaendert
        }
        // UNTER-EVENTS BELIEBIG TIEF. [Die Aktion ist ein Kind erster Ebene;
        //  alles darunter lebt nur in timeline. Jede Aenderung geht direkt
        //  ins Modell, danach wird neu projiziert -- e ist dann ungueltig,
        //  deshalb break.]
        if (!IstVirtuell(e->id) && xbm_tl::Geladen()) {
            bool geaendert = UnterEventsZeichnen(a.id);
            if (geaendert) { ImGui::PopID(); break; }
        }
        ImGui::PopID();
    }
    ImGui::SameLine();
    if (ImGui::Checkbox("ganztaegig", &e->allDay)) UiCalendar_Touch(e->id);
    // ---- WIEDERHOLUNG (Termine und Gruppen; Unter-Termine folgen) -------------
    if (!IstVirtuell(e->id)) {
        ImGui::TextDisabled("Wiederholung");
        int w = (int)e->wdh;
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 9.0f);
        if (ImGui::Combo("##wdh", &w, "nie\0taeglich\0wochentags (Mo-Fr)\0woechentlich\0monatlich\0jaehrlich\0")) {
            e->wdh = (CalWiederholung)w;
            if (e->wdh == CalWiederholung::Woechentlich && e->wdhTage == 0) { const XbmLocalTime l = XbmTime_ToLocal(e->start); e->wdhTage = (std::uint8_t)(1u << ((l.weekday + 6) % 7)); }
            if (e->wdhJede < 1) e->wdhJede = 1;
            UiCalendar_Touch(e->id);
        }
        if (e->wdh != CalWiederholung::Nie) {
            ImGui::SameLine(); ImGui::TextDisabled("jede"); ImGui::SameLine();
            int jede = e->wdhJede < 1 ? 1 : e->wdhJede; ImGui::SetNextItemWidth(ImGui::GetFontSize() * 3.5f);
            if (ImGui::InputInt("##jede", &jede, 0, 0)) { e->wdhJede = jede < 1 ? 1 : jede; UiCalendar_Touch(e->id); }
            ImGui::SameLine(); ImGui::TextDisabled(e->wdh == CalWiederholung::Taeglich ? "Tag(e)" : e->wdh == CalWiederholung::Monatlich ? "Monat(e)" : e->wdh == CalWiederholung::Jaehrlich ? "Jahr(e)" : "Woche(n)");
            if (e->wdh == CalWiederholung::Woechentlich) {
                static const char* tage[7] = { "Mo", "Di", "Mi", "Do", "Fr", "Sa", "So" };
                for (int t = 0; t < 7; ++t) {
                    bool an = (e->wdhTage >> t) & 1; ImGui::PushID(t);
                    if (ImGui::Checkbox(tage[t], &an)) { if (an) e->wdhTage |= (1u << t); else e->wdhTage &= ~(1u << t); if (e->wdhTage == 0) e->wdhTage = (1u << t); UiCalendar_Touch(e->id); }
                    ImGui::PopID(); if (t < 6) ImGui::SameLine();
                }
            }
            // Ende: bis Datum oder Anzahl
            char bisLb[48];
            if (e->wdhBis) std::snprintf(bisLb, sizeof(bisLb), "bis %s", XbmTime_Format(e->wdhBis, "%d.%m.%Y").c_str());
            else std::snprintf(bisLb, sizeof(bisLb), "%s", "ohne Ende");
            if (ImGui::Button(bisLb)) ImGui::OpenPopup("##wdhBis");
            { std::int64_t tmp = e->wdhBis ? e->wdhBis : XbmTime_AddDays(e->start, 30); if (DatumZeitOverlay("##wdhBis", tmp)) { e->wdhBis = XbmTime_LocalMidnight(tmp) + 86399; UiCalendar_Touch(e->id); } }
            if (e->wdhBis) { ImGui::SameLine(); if (ImGui::SmallButton("x##bis")) { e->wdhBis = 0; UiCalendar_Touch(e->id); } }
            ImGui::SameLine(); ImGui::TextDisabled("oder"); ImGui::SameLine();
            int anz = e->wdhAnzahl; ImGui::SetNextItemWidth(ImGui::GetFontSize() * 3.5f);
            if (ImGui::InputInt("mal", &anz, 0, 0)) { e->wdhAnzahl = anz < 0 ? 0 : anz; UiCalendar_Touch(e->id); }
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("0 = unbegrenzt");
            // Ausnahmen (nur diesen / geloeschte Vorkommen)
            if (xbm_tl::Geladen()) {
                std::vector<std::int64_t> aus = xbm_tl::Ausnahmen(e->id);
                if (!aus.empty()) {
                    ImGui::TextDisabled("Ausnahmen (%d):", (int)aus.size()); ImGui::SameLine();
                    int n = 0;
                    for (std::int64_t a : aus) {
                        if (n++ >= 6) { ImGui::TextDisabled("..."); break; }
                        ImGui::PushID((int)(a & 0x7fffffff));
                        if (ImGui::SmallButton(XbmTime_Format(a, "%d.%m.").c_str())) { xbm_tl::AusnahmeAufheben(e->id, a, XbmTime_NowUtc()); xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); xbm_tls::Anstossen(); ImGui::PopID(); ImGui::EndChild(); return; }
                        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Ausnahme aufheben: das regulaere Vorkommen kommt zurueck");
                        ImGui::PopID(); ImGui::SameLine();
                    }
                    ImGui::NewLine();
                }
            }
        }
    }
    if (!IstVirtuell(e->id) && xbm_tl::Geladen()) {
        ImGui::TextDisabled("Unter-Termine");
        if (UnterEventsZeichnen(e->id, /*nurTermine=*/true)) { ImGui::EndChild(); return; }   // Modell geaendert: e ungueltig
        int ks = xbm_tl::KinderSicht(e->id);
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 13.0f);
        if (ImGui::Combo("Unter-Events zeigen", &ks, "immer\0nur wenn dieser Termin aktiv/bearbeitet wird\0")) {
            xbm_tl::KinderSichtSetzen(e->id, ks, XbmTime_NowUtc()); xbm_tl::Speichern(); xbm_tls::Anstossen();
        }
    }

    // Notizen -- hier landet das Transkript, frei nachbearbeitbar.
    ImGui::TextDisabled("Notiz / Transkript");
    // std::string-Ueberladung aus imgui_stdlib: waechst von selbst, also
    // keine feste Obergrenze fuer ein langes Transkript.
    ImGuiInputTextFlags notizFlags = 0;
    if (C().edFokus == EF::NotizVoll) {
        ImGui::SetKeyboardFocusHere();
        notizFlags |= ImGuiInputTextFlags_AutoSelectAll;
        C().edFokus = EF::Keine;
    } else if (C().edFokus == EF::NotizEnde) {
        ImGui::SetKeyboardFocusHere();   // ohne AutoSelectAll -- keine Markierung
        C().edFokus = EF::Keine;
    }
    if (ImGui::InputTextMultiline("##notes", &C().bufNotes,
                                  ImVec2(-1, ImGui::GetTextLineHeight() * 4.0f),
                                  notizFlags)) {
        e->notes = C().bufNotes;
        C().dirty = true;
    }
    if (ImGui::IsItemFocused() && ImGui::IsKeyPressed(ImGuiKey_Tab, false))
        C().edFokus = EF::TitelVoll;   // naechster Frame: zurueck zum Titel, markiert

    if (!e->audio.empty()) {
        // ---- ABSPIELER ------------------------------------------------
        // Position, Wiedergabe, Pause, Stop, Transkript, Loeschen.
        // Der Regler ist der Praezisions-Scrubber aus ui_scrub.h: waagrecht
        // ziehen laeuft durch die ganze Aufnahme, mit dem Finger nach oben
        // wird die Uebersetzung feiner (1:4, 1:20, 1:100, 1:500), damit man
        // eine bestimmte Stelle genau trifft. Die Position springt beim
        // Umschalten der Stufe NICHT -- er rechnet inkrementell.
        const std::string wavPfad =
            JoinPath(JoinPath(C().dir, "memos"), e->audio);
        const bool diesGeladen = (XbmAudio_PlayName() == e->audio);

        ImGui::TextDisabled("Aufnahme: %s", e->audio.c_str());

        const float fh = ImGui::GetFrameHeight();
        if (ImGui::Button(diesGeladen && XbmAudio_IsPlaying() ? "||" : ">",
                          ImVec2(fh * 1.6f, fh))) {
            if (!diesGeladen) {
                if (!XbmAudio_PlayFile(wavPfad))
                    C().memoStatus = XbmAudio_LastError();
            } else {
                XbmAudio_PlayPause();
            }
        }
        ImGui::SetItemTooltip(diesGeladen && XbmAudio_IsPlaying()
                              ? "Pause" : "Wiedergabe");
        ImGui::SameLine();
        if (ImGui::Button("#", ImVec2(fh * 1.6f, fh))) XbmAudio_PlayStop();
        ImGui::SetItemTooltip("Stop (zurueck an den Anfang)");

        // [Hier stand der STT-Zustand als Text zwischen den Knoepfen. Er
        //  rutschte je nach Fensterbreite an unvorhersehbare Stellen und
        //  schob die Knopfreihe um. Solche Meldungen gehoeren ins
        //  Protokoll, nicht in die Werkzeugleiste -- dort stehen sie
        //  dauerhaft, sind durchsuchbar und stoeren das Layout nicht.]

        if (XbmStt_Compiled()) {
            ImGui::SameLine();
            if (ImGui::Button("Transkript", ImVec2(0, fh))) {
                XbmClip clip;
                if (XbmAudio_ReadWav(wavPfad, clip)) {
                    const std::uint64_t id = e->id;
                    C().memoStatus = "Transkription laeuft...";
                    XbmStt_Submit(std::move(clip), [id](std::string t, bool ok) {
                        if (CalEntry* q = UiCalendar_Find(id)) {
                            q->notes = ok ? t : std::string("(fehlgeschlagen)");
                            if (C().bufFor == id) C().bufNotes = q->notes;
                            C().dirty = true;
                        }
                        C().memoStatus = ok ? "Transkript uebernommen"
                                            : "Transkription fehlgeschlagen";
                    });
                } else {
                    C().memoStatus = "WAV nicht lesbar";
                }
            }
        } else {
            ImGui::SameLine();
            ImGui::TextDisabled("(ohne whisper gebaut)");
        }

        // MODELLE -- IMMER erreichbar.
        // [Vorher erschien der Knopf nur, solange KEIN Modell vorlag, und
        //  verschwand nach dem ersten Download. Damit liess sich weder ein
        //  zweites Modell laden noch zwischen ihnen wechseln noch eines
        //  entfernen. Der Knopf zeigt jetzt zusaetzlich, welches Modell
        //  gerade benutzt wird.]
        if (XbmStt_Compiled()) {
            ImGui::SameLine();
            const std::string wahl = XbmStt_ChosenModel();
            char beschriftung[64];
            if (XbmModel_Busy())
                std::snprintf(beschriftung, sizeof(beschriftung),
                              "Modelle (%d%%)...",
                              (int)(XbmModel_Progress() * 100.0f));
            else if (!wahl.empty())
                std::snprintf(beschriftung, sizeof(beschriftung),
                              "Modell: %s", wahl.c_str());
            else
                std::snprintf(beschriftung, sizeof(beschriftung),
                              "Modell laden...");
            if (ImGui::Button(beschriftung, ImVec2(0, fh)))
                ImGui::OpenPopup("##modell");
        }
        if (ImGui::BeginPopup("##modell")) {
            XbmModel_DrawUi(XbmStt_ModelDir(), &XbmStt_HasModelFile,
                            XbmStt_ChosenModel(),
                            &XbmStt_ChooseModel, &XbmStt_DeleteModel);
            if (XbmModel_TakeFinished()) {
                XbmStt_RescanModel();
                UiLog_Add(UiLogLevel::Info,
                          "Sprachmodell geladen -- Transkription ist bereit");
            }
            ImGui::EndPopup();
        }
        ImGui::SameLine();
        if (ImGui::Button("Ton loeschen", ImVec2(0, fh))) {
            if (diesGeladen) XbmAudio_PlayStop();
            std::remove(wavPfad.c_str());
            e->audio.clear();
            UiCalendar_Touch(e->id);
            C().memoStatus = "Aufnahme geloescht";
        }
        ImGui::SetItemTooltip("Entfernt die WAV-Datei; der Eintrag bleibt");

        if (diesGeladen && XbmAudio_HasClip()) {
            double pos = XbmAudio_PlayPos();
            const double len = XbmAudio_PlayLen();
            XbmScrubOptions so;
            so.fps         = 100.0;      // Hundertstelsekunden als Raster
            so.snapToFrame = false;      // Ton braucht kein Bildraster
            so.height      = fh;
            XbmScrubInfo si;
            if (UiScrubber("##memo_scrub", &pos, 0.0, len > 0.01 ? len : 0.01,
                           so, &si))
                XbmAudio_PlaySeek(pos);
            // Pegel neben der Zeit -- zeigt, dass wirklich Ton laeuft.
            ImGui::TextDisabled("%s / %s",
                                UiScrub_FormatTime(XbmAudio_PlayPos()).c_str(),
                                UiScrub_FormatTime(len).c_str());
            if (XbmAudio_IsPlaying()) {
                ImGui::SameLine();
                ImGui::ProgressBar(ImClamp(XbmAudio_PlayLevel() * 2.0f, 0.0f, 1.0f),
                                   ImVec2(80, fh * 0.6f), "");
            }
        }
    }

    if (ImGui::Button("Schliessen")) { C().editing = 0; EditorKopieAbschliessen(); SaveNow(); }
    if (!IstVirtuell(e->id) && xbm_tl::Geladen()) {
        ImGui::SameLine();
        if (ImGui::Button("Als Vorlage ablegen")) {
            SaveNow();                                            // erst Oberflaechenstand ins Modell
            if (xbm_tl::AlsVorlage(e->id, XbmTime_NowUtc())) { xbm_tl::Speichern(); xbm_tls::Anstossen(); }
        }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Kopie samt Unter-Events als Vorlage in Navi 1 -- neue Termine daraus erben Titel, Notiz, Farbe, Erinnerung");
    }
    ImGui::SameLine();
    if (ImGui::Button("Loeschen")) {
        const std::uint64_t id = e->id;
        C().editing = 0;
        if (IstVirtuell(id)) { C().editKopieAktiv = false; }   // Loeschfrage statt Aenderungsfrage
        UiCalendar_Remove(id);
        SaveNow();
    }
    // INHALTSHOEHE MESSEN -- INNERHALB des Kindfensters, VOR EndChild.
    // [Vorher stand die Messung NACH EndChild. Dort ist der Schreibkopf um
    //  genau die RESERVIERTE Hoehe weitergerueckt, nicht um die des
    //  Inhalts. Die Messung lieferte also ihren eigenen Vorgabewert
    //  zurueck -- plus zweimal Zeilenabstand, den ich draufgeschlagen
    //  hatte. Damit wuchs der Editor Frame fuer Frame, bis der
    //  Zwei-Drittel-Deckel griff: das gemeldete "viel zu gross".
    //  Innerhalb des Kindfensters zaehlt GetCursorPosY() vom oberen Rand
    //  an mit, ist also die echte Inhaltshoehe.]
    C().editorMeasured = ImGui::GetCursorPosY()
                       + ImGui::GetStyle().WindowPadding.y;
    ImGui::EndChild();

}

}  // namespace

// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// SERIENTERMIN VERSCHOBEN: nur diesen / ab hier / ganze Serie.
// [Das Modell (timeline) kann alle drei -- R3: Ausnahme + abgeloestes
//  Vorkommen, Serie teilen, oder die Serie als Ganzes. Die Frage kommt nach
//  dem Loslassen; bis dahin folgt das Vorkommen dem Finger. Gezeichnet
//  INNERHALB des Kalenderfensters, damit das Modal dazugehoert.]
// ---------------------------------------------------------------------------
static void SerienZugAbfrage() {
    auto& z = C().serienZug;
    if (!z.offen) return;
    if (!ImGui::IsPopupOpen("Serientermin verschieben")) ImGui::OpenPopup("Serientermin verschieben");
    if (ImGui::BeginPopupModal("Serientermin verschieben", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        const std::int64_t delta = z.neuStart - z.occStart;
    (void)z.neuDur;
        const int min = (int)(delta / 60);
        ImGui::Text("Termin um %d:%02d h verschieben:", min / 60, std::abs(min % 60));
        ImGui::Spacing();
        const float b = ImGui::GetFontSize() * 14.0f;
        int wahl = -1;
        if (ImGui::Button("Nur diesen Termin", ImVec2(b, 0))) wahl = 0;
        if (ImGui::Button("Ab hier (Serie teilen)", ImVec2(b, 0))) wahl = 1;
        if (ImGui::Button("Ganze Serie", ImVec2(b, 0))) wahl = 2;
        ImGui::Spacing();
        if (ImGui::Button("Abbrechen", ImVec2(b, 0))) wahl = 3;
        if (wahl >= 0) {
            // Griff-Zug: neue Dauer gilt fuer das abgeloeste Vorkommen / die neue
            // Serie / die ganze Serie -- je nach Wahl.
            if (wahl == 0) { const std::uint64_t n = xbm_tl::NurDiesen(z.base, z.occStart, z.neuStart, XbmTime_NowUtc()); if (n && z.neuDur > 0) if (timeline::Event* ne = xbm_tl::Speicher().finde(n)) { ne->durMin = z.neuDur; xbm_tl::Speicher().geaendert(*ne, XbmTime_NowUtc()); } }
            else if (wahl == 1) { const std::uint64_t n = xbm_tl::AbHier(z.base, z.occStart, z.neuStart, XbmTime_NowUtc()); if (n && z.neuDur > 0) if (timeline::Event* ne = xbm_tl::Speicher().finde(n)) { ne->durMin = z.neuDur; xbm_tl::Speicher().geaendert(*ne, XbmTime_NowUtc()); } }
            else if (wahl == 2) { if (CalEntry* e = UiCalendar_Find(z.base)) { UiCalendar_EventStartSetzen(*e, e->start + delta); if (z.neuDur > 0) e->durMin = z.neuDur; UiCalendar_Touch(e->id); } }
            if (wahl != 3) {
                if (wahl != 2) { xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); }
                UiCalendar_Save();
            }
            z = CalState::SerienZug{};
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }
}

void UiCalendar_Draw(const char* title, bool* open, ImGuiWindowFlags flags) {
    if (C().anchor == 0) C().anchor = WeekStart(XbmTime_NowUtc());
    // NACHSEHEN, OB DIE DATEI SICH VON AUSSEN GEAENDERT HAT (Netz-
    // Abgleich) -- gedrosselt auf hoechstens 1x/Sekunde in der Funktion
    // selbst. Ohne das blieb ein erfolgreich abgeglichener Kalender in
    // der bereits laufenden App unsichtbar, bis man sie neu startete.
    UiCalendar_PollExterneAenderung();
    // ERGEBNISSE AUS HINTERGRUNDFAEDEN ABHOLEN.
    // [XbmStt_Submit und die Erinnerungen reichen ihr Ergebnis ueber
    //  XbmSched_PostUi weiter. Das landet in einer Warteschlange, die
    //  jemand LEEREN muss -- bisher tat das ausschliesslich die
    //  Hauptschleife in main.cpp. Fehlt dieser eine Aufruf dort, laeuft
    //  whisper zwar durch, aber der Rueckruf wird nie ausgefuehrt: das
    //  Transkript-Feld bleibt LEER, und zwar ohne jede Fehlermeldung,
    //  weil auch die Statusmeldung ueber denselben Weg kaeme.
    //
    //  Der Kalender holt die Warteschlange jetzt selbst ab. Doppeltes
    //  Abholen schadet nicht -- DrainUi nimmt sich nur, was da ist, und
    //  hat ein Zeitbudget. Damit haengt die Transkription nicht mehr
    //  daran, ob eine fremde Datei die Zeile enthaelt.]
    XbmSched_DrainUi();

    // FENSTERTITEL = DIE ANSICHTS-BESCHRIFTUNG ("12.09. - 18.09." usw.)
    // STATT DES FESTEN "Kalender".
    // [WICHTIG: die ID des Fensters (fuer Docking, Layout-Speicherung,
    //  Palette) darf sich dabei NICHT aendern, auch wenn der ANGEZEIGTE
    //  Text taeglich anders lautet. ImGui trennt beides ueber "###": der
    //  Teil VOR "###" ist nur die sichtbare Beschriftung, der Teil AB
    //  "###" bestimmt allein die ID. "title" kommt hier als z.B.
    //  "Kalender" oder "Kalender##Seite1" herein (UiPageWindow) -- dieser
    //  Teil MUSS als ID erhalten bleiben. Enthaelt er schon "##", wird
    //  alles ab dort uebernommen (das zaehlt zur ID, zeigt aber nichts
    //  an); fehlt es, wird "###" plus der komplette bisherige Titel als
    //  ID angehaengt.]
    std::string fenstertitel;
    {
        const std::string kennung(title);
        const size_t hashPos = kennung.find("##");
        const std::string idTeil = (hashPos != std::string::npos)
                                  ? kennung.substr(hashPos)         // "##Seite1" (o.ae.)
                                  : ("###" + kennung);               // "###Kalender"
        fenstertitel = AnsichtsCaption() + idTeil;
    }

    const bool vis = ImGui::Begin(fenstertitel.c_str(), open, flags);
    C().wasVisible = vis;
    if (!vis) { ImGui::End(); return; }
    // STRG+C / STRG+V: Auswahl merken, an der gelben Zeitauswahl (sonst jetzt) einfuegen
    if (ImGui::IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows) && ImGui::GetIO().KeyCtrl && !ImGui::IsAnyItemActive()) {
        if (ImGui::IsKeyPressed(ImGuiKey_C, false)) { C().zwischenablage = AuswahlModellIds(); }
        if (ImGui::IsKeyPressed(ImGuiKey_V, false) && !C().zwischenablage.empty() && xbm_tl::Geladen()) {
            SaveNow(); KopienAnlegen(C().zwischenablage, C().slotSel ? C().slotSel : ((XbmTime_NowUtc() / 3600) + 1) * 3600);
        }
    }
    SerienZugAbfrage();
    SerienFrageAbfrage();
    // Editor einer Kopie anderweitig verlassen (Abwahl, anderer Eintrag) -> fragen
    if (C().editKopieAktiv && C().editing != C().editKopie.id) EditorKopieAbschliessen();

    // TASTATUR-SOFORTANLAGE.
    // [Nur wirksam, wenn das Kalenderfenster den Fokus haelt UND kein
    //  Editor bereits offen ist -- sonst wuerde ein Zeichen doppelt
    //  verbraucht: einmal hier, einmal vom InputText des Editors. Escape
    //  und reine Steuertasten filtert UiCalendar_TypeToCreate schon
    //  selbst heraus.]
    if (!C().editing && ImGui::IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows)) {
        ImGuiIO& kio = ImGui::GetIO();
        using PF = CalState::PenFokus;
        using EF = CalState::EdFokus;

        // TASTATUR-MEHRFACHBEARBEITUNG DER STIFT-AUSWAHL.
        // [Bisher gab es das NICHT: ein Tastendruck legte IMMER ein neues
        //  Event an, egal ob gerade eine Bulk-Auswahl bestand -- die
        //  Auswahl liess sich nur mit der Maus (den Knoepfen in der
        //  Werkzeugleiste) verschieben oder loeschen.
        //  Jetzt: besteht eine Stift-Auswahl, greifen zuerst diese
        //  Tasten, und das Anlegen per Zeichen bleibt fuer den Fall
        //  reserviert, dass NICHTS ausgewaehlt ist -- so blockiert die
        //  Auswahl nicht das gewohnte Sofort-Anlegen, wenn man sie gar
        //  nicht benutzt.]
        const int aktCount = C().penActive ? UiCalendar_PenSelectedCount() : 0;
        const bool hatAuswahl = aktCount > 0;
        // UEBERGANG "nichts" -> "mind. eines": Titelfeld anfordern und
        // mit dem Titel des ERSTEN ausgewaehlten Events fuellen ("Wenn
        // Events 1 oder n selektiert sind, soll sofort der Titel
        // komplett markiert werden").
        if (hatAuswahl && C().penSelVorher == 0) {
            std::uint64_t anker = *std::min_element(C().penSel.begin(), C().penSel.end());
            if (CalEntry* ae = UiCalendar_Find(anker)) {
                C().penBulkTitel = ae->title;
                C().penBulkNotiz = ae->notes;
            }
            C().penFokus = PF::TitelVoll;
        }
        C().penSelVorher = aktCount;

        if (hatAuswahl) {
            const int64_t tag = 86400, stunde = 3600, fuenfMin = 300;
            if (ImGui::IsKeyPressed(ImGuiKey_LeftArrow))
                UiCalendar_PenShiftSelected(-tag);
            else if (ImGui::IsKeyPressed(ImGuiKey_RightArrow))
                UiCalendar_PenShiftSelected(tag);
            else if (ImGui::IsKeyPressed(ImGuiKey_UpArrow))
                UiCalendar_PenShiftSelected(kio.KeyShift ? -fuenfMin : -stunde);
            else if (ImGui::IsKeyPressed(ImGuiKey_DownArrow))
                UiCalendar_PenShiftSelected(kio.KeyShift ? fuenfMin : stunde);
            else if (ImGui::IsKeyPressed(ImGuiKey_Delete)
                  || ImGui::IsKeyPressed(ImGuiKey_Backspace))
                UiCalendar_PenDeleteSelected();
        }

        // TAB/ENTER OHNE BEREITS AKTIVES EINGABEFELD: springen direkt in
        // die Notiz bzw. den Titel der jeweils zutreffenden Auswahl.
        // [IsAnyItemActive() erkennt, ob gerade schon irgendwo getippt
        //  wird -- WAEHREND des Tippens uebernimmt die lokale Zirkulation
        //  in DrawToolbar/DrawEditor selbst (Titel<->Notiz), dieser Block
        //  ist nur fuer den ERSTEN Sprung OHNE aktives Feld zustaendig.]
        const bool eingabeAktiv = ImGui::IsAnyItemActive();
        if (hatAuswahl && !eingabeAktiv) {
            if (ImGui::IsKeyPressed(ImGuiKey_Tab, false))
                C().penFokus = PF::NotizVoll;
            else if (ImGui::IsKeyPressed(ImGuiKey_Enter, false)
                  || ImGui::IsKeyPressed(ImGuiKey_KeypadEnter, false))
                C().penFokus = PF::TitelEnde;
        } else if (!hatAuswahl && C().selected != 0 && !eingabeAktiv) {
            // EIN EINZELNES Event ist ausgewaehlt (keine Bulk-Auswahl):
            // Enter oeffnet den Editor und markiert den Titel komplett
            // (schnelles Umbenennen). Tab oeffnet ihn ebenso, springt
            // aber in die Notiz -- komplett markiert, damit ein
            // Tastendruck sie sofort ersetzen wuerde, man den
            // Markiervorgang aber noch mit der Tastatur abbrechen kann
            // (z.B. mit einer Pfeiltaste, die die Markierung ganz normal
            // aufhebt, ohne etwas zu loeschen). Ein einfaches Zeichen
            // OHNE Tab/Enter geht direkt in die -- dafuer GELEERTE --
            // Notiz, ohne jede Markierung.
            if (ImGui::IsKeyPressed(ImGuiKey_Enter, false)
             || ImGui::IsKeyPressed(ImGuiKey_KeypadEnter, false)) {
                UiCalendar_Edit(C().selected);
                C().edFokus = EF::TitelVoll;
            } else if (ImGui::IsKeyPressed(ImGuiKey_Tab, false)) {
                UiCalendar_Edit(C().selected);
                C().edFokus = EF::NotizVoll;
            } else {
                // EIN ZEICHEN GETIPPT, WAEHREND EIN EVENT AUSGEWAEHLT
                // IST (noch nicht im Editor): der TITEL wird KOMPLETT
                // ERSETZT -- das getippte Zeichen steht danach als
                // einziges da, der Cursor dahinter, und es laesst sich
                // sofort weiterschreiben.
                // [Vorher landete die Eingabe in der NOTIZ und der Titel
                //  blieb stehen. Gewuenscht ist das Verhalten, das man
                //  von Dateiverwaltungen kennt: ausgewaehlt + tippen =
                //  umbenennen.]
                std::string getippt;
                for (int ci = 0; ci < kio.InputQueueCharacters.Size; ++ci) {
                    unsigned int cp = (unsigned int)kio.InputQueueCharacters[ci];
                    if (cp < 0x20 || cp == 0x7f) continue;
                    XbmUtf8Anhaengen(getippt, cp);
                }
                if (!getippt.empty()) {
                    UiCalendar_Edit(C().selected);
                    // Die Zeichen NICHT in der Warteschlange lassen --
                    // dieselbe Begruendung wie bei der Neuanlage: das
                    // Titelfeld wird erst im naechsten Frame aktiv, bis
                    // dahin ist die Warteschlange geleert.
                    kio.InputQueueCharacters.resize(0);
                    C().pendingFirstText    = getippt;
                    C().pendingReplaceMode  = true;   // ERSETZEN, nicht anhaengen
                    C().pendingFirstIstTab  = false;
                    C().pendingFirstCharFor = C().selected;
                    // Cursor hinter das Zeichen, NICHTS markiert (siehe
                    // titelCursorAnsEnde -- ImGui markiert bei
                    // Tastatur-Fokus sonst von sich aus alles).
                    C().edFokus            = EF::TitelEnde;
                    C().titelCursorAnsEnde = 30;   // nur Obergrenze, siehe DrawEditor
            C().titelCursorAktivFrames = 0;
                }
            }
        }

        // TASTATUR-SOFORTANLAGE: nur, wenn NICHTS ausgewaehlt ist. [Waere
        // eine Bulk-Auswahl oder eine Einzelauswahl aktiv, wuerde jeder
        // Tastendruck sonst ein NEUES Event anlegen, statt in eines der
        // obigen Felder zu gelangen.]
        if (!hatAuswahl && C().selected == 0) {
            // TAB LEGT EBENFALLS EIN EVENT AN -- aber mit Fokus auf die
            // NOTIZ statt den Titel ("erstellt er auch ein neues Event,
            // bearbeitet aber sofort das Notizfeld"). Tab kommt nicht ueber
            // die Zeichen-Warteschlange (es ist ein Steuerzeichen < 0x20,
            // das UiCalendar_TypeToCreate absichtlich herausfiltert),
            // sondern wird hier als eigene Taste erkannt.
            if (ImGui::IsKeyPressed(ImGuiKey_Tab, false)) {
                std::uint64_t id = UiCalendar_QuickAdd();
                if (id) {
                    C().pendingFirstIstTab = true;
                    C().pendingFirstCharFor = id;
                }
            } else {
                for (int ci = 0; ci < kio.InputQueueCharacters.Size; ++ci) {
                    unsigned int cp = (unsigned int)kio.InputQueueCharacters[ci];
                    if (UiCalendar_TypeToCreate(cp)) {
                        // WEITERE ZEICHEN DESSELBEN FRAMES MITNEHMEN.
                        // [Wer schnell tippt, erzeugt leicht zwei oder
                        //  drei Zeichen in EINEM Frame. Die stehen hinter
                        //  dem ausloesenden in derselben Warteschlange --
                        //  und waeren genauso verloren wie das erste,
                        //  weil das Titelfeld erst im naechsten Frame
                        //  aktiv wird, die Warteschlange bis dahin aber
                        //  geleert ist. Sie werden deshalb gleich hier an
                        //  den Titel angehaengt.]
                        for (int cj = ci + 1; cj < kio.InputQueueCharacters.Size; ++cj) {
                            unsigned int c2 = (unsigned int)kio.InputQueueCharacters[cj];
                            if (c2 < 0x20 || c2 == 0x7f) continue;
                            UiCalendar_AppendPendingChar(c2);
                        }
                        // Warteschlange leeren: alles daraus ist jetzt
                        // verbucht. [Sonst koennte ein spaeter im Frame
                        // gezeichnetes, bereits aktives Feld dieselben
                        // Zeichen EIN ZWEITES MAL bekommen.]
                        kio.InputQueueCharacters.resize(0);
                        break;
                    }
                }
            }
        }
        // ESC waehlt das Stiftwerkzeug ab -- wie du es beschrieben hast
        // ("Mit Esc wird der Stift abgewaehlt").
        if (C().penActive && ImGui::IsKeyPressed(ImGuiKey_Escape))
            UiCalendar_PenToolSet(false);
    }

    // (DrawToolbar steht jetzt UNTER dem Kalender -- zwei Zeilen am unteren Rand)
    ImGui::Separator();

    // ANSICHTSWECHSEL: waagerechter Pinch, fuer JEDE Ansicht gleich.
    // [Zentral hier statt in jeder einzelnen Zeichenfunktion -- Tag,
    //  Woche, Monat und Jahr sollen sich alle gleich anfuehlen. Im
    //  Zeitraster schliesst sich die Geste per Fingerrichtung mit dem
    //  bestehenden Stunden-Pinch aus (siehe PinchHorizontal()); in
    //  Monat/Jahr gibt es keinen konkurrierenden Pinch.]
    if (ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows))
        PinchAnsichtswechselFrame();

    // KANTEN-NAVIGATION (Pinpoint/Wischen) FUER ALLE ANSICHTEN.
    // [Die untere Leiste mit den vier Reitern ist ENTFERNT -- sie war
    //  fehleranfaellig (leicht daneben getroffen, verwechselbare
    //  Schrittweiten je Reiter). Stattdessen gilt jetzt ueberall
    //  dieselbe Regel wie in den Globalen Einstellungen festgelegt
    //  (Pinpoint/Normal): Pinpoint haelt man am Rand und zieht hinein,
    //  Wischen zieht waagerecht irgendwo im Kalenderinhalt -- BEIDES
    //  bewegt sich um GENAU EINEN Schritt der aktuellen Ansicht: Tag/
    //  n-Tage tageweise, Woche wochenweise, Monat monatsweise, Jahr
    //  jahresweise (SchrittDerAnsicht() liefert das automatisch anhand
    //  von C().view).
    //  Vorher lief das nur INNERHALB von DrawTimeGrid, also nur fuer
    //  Tag/n-Tage/Woche -- Monat und Jahr hatten ueberhaupt keine
    //  Pinpoint/Wisch-Navigation. Jetzt zentral hier, EINMAL fuer alle
    //  vier Ansichten. NavKanteFrame liest nur globalen Mauszustand und
    //  erzeugt selbst kein Item -- das Aufrufen hier stiehlt also
    //  keinem anderen Widget (Events, Chips, ...) den Druck.
    //
    //  KEINE IsWindowHovered()-Bedingung mehr davor: das war vermutlich
    //  der Grund, warum die Geste "schlicht nicht moeglich" war -- ohne
    //  ImGuiHoveredFlags_AllowWhenBlockedByActiveItem liefert
    //  IsWindowHovered() false, sobald irgendein Widget (z.B. das
    //  Kalenderraster selbst, das den Druck fuer sein eigenes
    //  senkrechtes Scrollen abfaengt) gerade aktiv ist -- und genau
    //  WAEHREND eines Zugs ist das praktisch immer der Fall. NavKanteFrame
    //  prueft die Fenstergrenzen jetzt selbst, direkt per Rechteck, beim
    //  Aufsetzen (siehe dort) -- das ist von "aktiven Widgets" unabhaengig.]
    if (!C().drag.active && !C().penActive && !C().pinching
        && !C().pinchHActive && FingerCount() <= 1) {
        NavKanteFrame(ImGui::GetContentRegionAvail().x,
                     ImGui::GetContentRegionAvail().y,
                     ImGui::GetCursorScreenPos());
    }

    // Platz fuer die "< Tag > < Monat > < Jahr >"-Zeile GANZ UNTEN
    // miteinrechnen -- sonst wuerde das Raster darunter zeichnen und die
    // Zeile halb verdecken.
    // Zwei Zeilen unter dem Kalender in Einheitsgroesse: < Heute > 15 M J ... goto  /  < 14 > < 10 > < 2026 > ... Zeit x
    const float dateNavH = 2.0f * (Einheit() + ImGui::GetStyle().ItemSpacing.y);
    const float reserve = EditorHeight() + ExplorerHeight() + dateNavH
                        + (C().editing ? ImGui::GetFrameHeight() : 0.0f);
    switch (C().view) {
        case CalView::Day:
        case CalView::ThreeDay:
        case CalView::Week:  DrawTimeGrid(reserve); break;
        case CalView::Month: DrawMonth(reserve);    break;
        case CalView::Year:  DrawYear(reserve);     break;
    }
    // EXPLORER OHNE OFFENEN EDITOR (z.B. "Baum der Vorlage" aus Navi 1):
    // am unteren Fensterrand, bis ein Knoten gewaehlt und unten bearbeitet wird.
    ExplorerBereich();          // angedockt: Kalender | Baum | Bearbeiten
    DrawEditor();
    RandWischen();              // von unten hereinwischen: Bearbeiten / Baum ausfahren
    DndFrame();                 // Ziehen eines nicht ausgewaehlten Termins: Symbol folgt dem Finger

    // "< Tag > < Monat > < Jahr >" -- jetzt UNTER dem Kalenderinhalt
    // statt oben in der Werkzeugleiste.
    DrawToolbar();
    DrawDateNav();

    UiCalendar_SaveIfDirty();
    ImGui::End();
}
