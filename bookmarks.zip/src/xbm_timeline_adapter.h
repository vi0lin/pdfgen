#pragma once
// ===========================================================================
// xbm_timeline_adapter -- der Kalender der App lebt auf timeline.
//
// timeline (external/general_c/external/timeline) ist die QUELLE der
// Eintraege: Modell, Datei (timeline.json), Migration aus calendar.json,
// Abgleich und Startvermerke. Die Oberflaeche (ui_calendar) arbeitet
// unveraendert mit CalEntry/CalAction; dieser Adapter projiziert
//
//     timeline::Event (Wurzel)         -> CalEntry
//     timeline::Event (Kind, 1. Ebene) -> CalAction  (Versatz -> absolute Zeit)
//
// und schreibt Aenderungen der Oberflaeche zurueck (nur was sich geaendert
// hat -- sonst fuellte jeder Speichervorgang das Abgleich-Journal). Alles,
// was CalEntry nicht kennt (tiefere Kinder, Vorlagen, Ausnahmen, abgeloeste
// Vorkommen), bleibt in timeline unangetastet.
//
// Ablauf: UiCalendar_Init -> Laden(dir) [migriert calendar.json einmalig]
//         LoadNow          -> Projizieren()   (statt "entries" aus calendar.json)
//         SaveNow          -> Uebernehmen(entries) + Speichern()
// calendar.json wird weiterhin geschrieben (Ansichtszustand; die Eintraege
// darin sind nur noch eine Sicherheitskopie fuer aeltere App-Fassungen).
// ===========================================================================
#include "ui_calendar.h"
#include "model.h"
#include <string>
#include <vector>

namespace xbm_tl {

timeline::Speicher& Speicher();
// timeline.json aus <dir> laden; gibt es sie nicht, aber calendar.json,
// wird migriert (calendar.json bleibt als calendar.json.v2 erhalten).
bool Laden(const std::string& dir, const std::string& geraet, timeline::Zeit tzSekunden);
bool Speichern();
std::string Datei();
bool Geladen();

std::vector<CalEntry> Projizieren();
// Aenderungen der Oberflaeche uebernehmen; liefert die Zahl geaenderter Events.
int Uebernehmen(const std::vector<CalEntry>& entries, std::int64_t jetzt);

// Zeitzone (Sekunden oestlich UTC) der Maschine -- fuer Wochentage/Monate.
timeline::Zeit LokaleZeitzone();

// SERIENTERMIN VERSCHIEBEN (R3). Beide liefern die Id des Events, das den
// verschobenen Termin traegt (abgeloestes Vorkommen bzw. neue Serie), 0 bei
// Fehler. Danach: Speichern() + UiCalendar_TimelineNeuLaden().
std::uint64_t NurDiesen(std::uint64_t serie, std::int64_t vorkommenStart, std::int64_t neuerStart, std::int64_t jetzt);
std::uint64_t AbHier  (std::uint64_t serie, std::int64_t vorkommenStart, std::int64_t neuerStart, std::int64_t jetzt);


// UNTER-EVENTS BELIEBIG TIEF (R7). Die erste Ebene zeigt die Oberflaeche als
// Aktionen (CalAction); alles darunter laeuft ueber diese Funktionen direkt
// im Modell. Versatz ist relativ zum ELTERNTEIL (Sekunden).
struct Knoten { std::uint64_t id = 0, eltern = 0; std::string titel; std::int64_t versatzSek = 0; int durMin = 0; int tiefe = 1; bool aktion = false; bool termin = false; };
std::vector<Knoten> Unterbaum(std::uint64_t eltern);                     // alle Nachfahren, Tiefensuche, tiefe ab 1
// termin = true: ein UNTER-TERMIN (erscheint als eigener Block im Raster, nicht als Erinnerung)
std::uint64_t KindAnlegen(std::uint64_t eltern, const std::string& titel, std::int64_t versatzSek, int durMin, std::int64_t jetzt, bool termin = false);
bool KindAendern(std::uint64_t id, const std::string& titel, std::int64_t versatzSek, int durMin, std::int64_t jetzt);
bool KindLoeschen(std::uint64_t id, std::int64_t jetzt);                 // samt Teilbaum (Grabsteine)


// SICHTBARKEIT (im zusatz-JSON des Events, wird abgeglichen).
//   Elternteil, Schluessel "kinderSicht": 0 = Kinder immer einblenden,
//                                         1 = nur, wenn das Elternteil aktiv/bearbeitet wird
//   Kind,       Schluessel "sicht":       0 = immer, 1 = nur bei ausgewaehltem Oberevent,
//                                         2 = nur im Aktiv/Bearbeiten-Modus des Stammes
int  KinderSicht(std::uint64_t eltern);
void KinderSichtSetzen(std::uint64_t eltern, int modus, std::int64_t jetzt);
int  Sicht(std::uint64_t kind);
void SichtSetzen(std::uint64_t kind, int modus, std::int64_t jetzt);
// Wurzel und absoluter Start eines (Unter-)Events: Wurzelstart + Versaetze.
std::uint64_t Wurzel(std::uint64_t id);
std::int64_t  AbsoluterStart(std::uint64_t id);
bool IstNachfahre(std::uint64_t id, std::uint64_t vorfahr);   // id == vorfahr zaehlt auch


// VORLAGEN (R1/R2): ein Event als Vorlage ablegen (tiefe Kopie, erscheint nie
// im Kalender), daraus neue Events anlegen (Felder fallen auf die Vorlage
// zurueck, Kinder werden kopiert), Vorlagen loeschen (Werte in Instanzen
// aufgeloest, nichts geht verloren).
struct VorlageInfo { std::uint64_t id = 0; std::string titel; int durMin = 0; int kinder = 0; };
std::vector<VorlageInfo> Vorlagen();
std::uint64_t AlsVorlage(std::uint64_t eventId, std::int64_t jetzt);
std::uint64_t AusVorlage(std::uint64_t vorlageId, std::int64_t start, std::int64_t jetzt);
bool VorlageLoeschen(std::uint64_t vorlageId, std::int64_t jetzt);


// EXPLORER: Baum unter einer Wurzel, sortiert nach Lage im Kalender; Umhaengen
// per Drag & Drop. Einhaengen(id, eltern): ein Wurzel-Termin wird Kind (Versatz
// aus seiner absoluten Lage), ein Kind wechselt das Elternteil; eltern = 0
// loest ein Kind heraus und macht es zum Wurzel-Termin an seiner Lage.
struct BaumKnoten { std::uint64_t id = 0, eltern = 0; std::string titel; std::int64_t start = 0; int durMin = 0; int tiefe = 0; int art = 0; /* 0 Termin, 1 Erinnerung, 2 Aktion */ bool aktiv = true; };
std::vector<BaumKnoten> Baum(std::uint64_t wurzel);                       // Wurzel + alle Nachfahren, Kinder nach Start sortiert
bool Einhaengen(std::uint64_t id, std::uint64_t eltern, std::int64_t jetzt);
std::uint64_t AusVorlageAlsKind(std::uint64_t vorlageId, std::uint64_t eltern, std::int64_t versatzSek, std::int64_t jetzt);
bool KindArtSetzen(std::uint64_t id, int art, std::int64_t jetzt);


// GRUPPEN: ein Container-Event (zusatz "gruppe": true) mit den Mitgliedern als
// Kindern; so gross wie alle zusammen, verschiebbar als Ganzes, als Serie
// moeglich, in den Baum ziehbar. Ungruppieren loest die Kinder an ihrer Lage.
bool IstGruppe(std::uint64_t id);
std::uint64_t GruppeBilden(const std::vector<std::uint64_t>& ids, std::int64_t jetzt);
bool Ungruppieren(std::uint64_t gruppe, std::int64_t jetzt);
void GruppeGroesseAnpassen(std::uint64_t gruppe, std::int64_t jetzt);   // Start/Dauer = Huelle der Mitglieder
// DUPLIZIEREN: tiefe Kopie (Kinder inklusive) als neuer Wurzel-Termin bei start.
std::uint64_t Duplizieren(std::uint64_t id, std::int64_t start, std::int64_t jetzt);


// AUSNAHMEN einer Serie: uebersprungene oder abgeloeste Vorkommen (Startzeit
// laut Regel). Aufheben stellt das regulaere Vorkommen wieder her.
std::vector<std::int64_t> Ausnahmen(std::uint64_t serie);
bool AusnahmeAufheben(std::uint64_t serie, std::int64_t start, std::int64_t jetzt);


// QUEUE-VORLAGEN (jobflow) IN DER TIMELINE: je Queue ein Vorlagen-Event mit
// zusatz {"queue": <Queue-JSON>}. Damit wandern die Queues mit dem Abgleich
// auf alle Geraete, und "queue:<id>" meint ueberall dieselbe Vorlage (id =
// Event-Id). Die Kalender-Vorlagenliste blendet diese Events aus.
struct QueueVorlage { std::uint64_t id = 0; std::string name; std::string json; };
std::vector<QueueVorlage> QueueVorlagen();
std::uint64_t QueueAnlegen(const std::string& name, const std::string& json, std::int64_t jetzt);
bool QueueSpeichern(std::uint64_t id, const std::string& name, const std::string& json, std::int64_t jetzt);
bool QueueLoeschen(std::uint64_t id, std::int64_t jetzt);


// PAPIERKORB: geloeschte Wurzel-Termine (Soft-Delete im Modell) auflisten,
// wiederherstellen (samt Kindern) oder endgueltig vergessen.
struct PapierkorbEintrag { std::uint64_t id = 0; std::string titel; std::int64_t start = 0; std::int64_t geloeschtAm = 0; };
std::vector<PapierkorbEintrag> Papierkorb();
bool Wiederherstellen(std::uint64_t id, std::int64_t jetzt);
int  PapierkorbLeeren(std::int64_t jetzt);         // entfernt die geloeschten Events aus dem Speicher

} // namespace xbm_tl
