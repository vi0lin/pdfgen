#import <Cocoa/Cocoa.h>
@interface ClickThroughHitTestView : NSView
@property (nonatomic) std::vector<NSRect> hitRects; // requires #include <vector> + libc++
@end
@implementation ClickThroughHitTestView
- (NSView *)hitTest:(NSPoint)point {
    NSPoint local = [self convertPoint:point fromView:nil];
    for (const NSRect& r : _hitRects) {
        if (NSPointInRect(local, r))
            return [super hitTest:point];
    }
    return nil; // pass click through to whatever is behind
}
@end
extern "C" void macos_InitClickThroughWindow(void* nsWindowHandle) {
    NSWindow* window = (__bridge NSWindow*)nsWindowHandle;
    window.opaque = NO;
    window.backgroundColor = [NSColor clearColor];
    window.hasShadow = NO;
    ClickThroughHitTestView* view = [[ClickThroughHitTestView alloc]
        initWithFrame:window.contentView.frame];
    view.hitRects = {};
    // Replace content view's hit-testing without breaking the existing
    // GL/Metal-backed render view: insert this as a transparent overlay view
    // ABOVE the render view, sized to match, just for hit-testing.
    // In practice it's simpler to subclass the existing content view's
    // -hitTest: directly if you control that class.
    [window.contentView addSubview:view];
}
extern "C" void macos_UpdateClickThroughRegion(void* nsWindowHandle,
                                                 const float* rectsXYWH,
                                                 int rectCount) {
    NSWindow* window = (__bridge NSWindow*)nsWindowHandle;
    ClickThroughHitTestView* view = nil;
    for (NSView* v in window.contentView.subviews) {
        if ([v isKindOfClass:[ClickThroughHitTestView class]]) {
            view = (ClickThroughHitTestView*)v;
            break;
        }
    }
    if (!view) return;
    std::vector<NSRect> rects;
    NSRect frame = window.contentView.frame;
    for (int i = 0; i < rectCount; i++) {
        float x = rectsXYWH[i*4+0];
        float y = rectsXYWH[i*4+1];
        float w = rectsXYWH[i*4+2];
        float h = rectsXYWH[i*4+3];
        // Flip Y: ImGui/GLFW origin is top-left, AppKit is bottom-left
        rects.push_back(NSMakeRect(x, frame.size.height - y - h, w, h));
    }
    view.hitRects = rects;
}
