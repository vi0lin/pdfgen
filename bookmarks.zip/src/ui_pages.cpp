// ui_pages.cpp -- ausgelagerte Rumpfe aus ui_pages.h.
//
// WARUM: ui_pages.h wird von jeder groesseren Uebersetzungseinheit
// eingebunden. Solange die Rumpfe im Header standen, wurden sie in
// JEDER dieser Dateien neu geparst und uebersetzt; jede Aenderung
// stiess den Neubau ALLER Nutzer an. Hier stehen sie genau einmal.
// Standardargumente stehen NUR in den Header-Deklarationen.
#include "ui_pages.h"
#include "xbm_ui_flags.h"
#include "ui_wingestures.h"
#include "ui_alerts.h"
#include <cmath>   // std::isfinite -- Absicherung gespeicherter Fenstergeometrie
// [g_layout und LayoutNode liegen in namespace ui_pages_detail (ui_pages.h,
//  Zeile 80 ff.). Die Funktionen dieser Datei holen sie sich per
//  "using namespace" IM Rumpf. Eine Funktion auf Dateiebene sieht sie
//  ohne das nicht -- daher "g_layout was not declared". Also gehoert
//  diese Funktion IN den Namensraum; der Aufruf weiter unten steht in
//  einer Funktion mit using-Direktive und findet sie dort.]
namespace ui_pages_detail {
// EIN NEUES FENSTER UNTEN AN DAS GESPEICHERTE LAYOUT ANHAENGEN.
// [Bei leerem Layout stapelt der Erststart alle Fenster untereinander.
//  Ist aber schon ein Layout gespeichert (xbm.ini), gilt jedes darin
//  fehlende Fenster als "bewusst abgedockt" und schwebt. Ein Fenster,
//  das es beim Speichern noch gar nicht GAB -- Reddit, Facebook --
//  wuerde damit fuer immer schweben. Diese Funktion baut die Wurzel um:
//  neue Wurzel (Achse Y), oben der bisherige Baum, unten das neue Blatt.
//  Alle Indizes des alten Baums verschieben sich um 1; die Wurzel
//  bleibt Index 0, wie RebuildFromLayout es verlangt.]
static void LayoutAppendBelow(const std::string& pageName, const std::string& win,
                              float anteilNeu) {
    auto& recs = g_layout[pageName];
    if (recs.empty()) return;
    std::vector<LayoutNode> neu;
    neu.reserve(recs.size() + 2);
    LayoutNode wurzel; wurzel.parent = -1; wurzel.axis = 1;
    wurzel.ratio = 1.0f - anteilNeu;          // Anteil des OBEREN Kindes
    neu.push_back(wurzel);
    for (auto n : recs) {                     // alter Baum, Indizes +1
        n.parent = (n.parent < 0) ? 0 : n.parent + 1;
        neu.push_back(n);
    }
    LayoutNode blatt; blatt.parent = 0; blatt.axis = -1;
    blatt.windows.push_back(win);
    neu.push_back(blatt);
    recs.swap(neu);
}
} // namespace ui_pages_detail


#include "ui_condbuttons.h"
#include "ui_log.h"
#include "ui_calendar.h"
#include "xbm_paths.h"   // Prototype liest/schreibt in UserData/pdfgen
#include "xbm_projekt_push.h"

void UiDrawBewerbenUI(const char* t, bool* open) {
    if (open && !*open) return;
    // ERSTER START: ins Dock der Seite einhaengen. FirstUseEver heisst,
    // dass ein spaeter vom Nutzer gewaehlter Platz (aus xbm.ini) NIE
    // ueberschrieben wird -- die Zeile wirkt nur bei leerem Zustand.
    if (ImGuiID dock = UiPageDockId())
        ImGui::SetNextWindowDockID(dock, ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(300, 260), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowCollapsed(false, ImGuiCond_FirstUseEver);
    // if (ImGui::Begin("Prototype", open,
    //                  UiWinFlags("Prototype"))) {
    if (ImGui::Begin(t, nullptr, UiFullscreenFlags("Prototype"))) {
        if (!ImGui::IsWindowDocked()) {
            ImGuiViewport* vp = ImGui::GetMainViewport();
            ImVec2 p = ImGui::GetWindowPos();
            bool out = p.x > vp->WorkPos.x + vp->WorkSize.x - 40.0f
                    || p.y > vp->WorkPos.y + vp->WorkSize.y - 40.0f
                    || p.x + ImGui::GetWindowWidth() < vp->WorkPos.x + 40.0f
                    || p.y < vp->WorkPos.y;
            if (out)
                ImGui::SetWindowPos(ImVec2(
                    vp->WorkPos.x + vp->WorkSize.x - 320.0f,
                    vp->WorkPos.y + vp->WorkSize.y * 0.15f), ImGuiCond_Always);
        }
        ImGui::TextDisabled("Email Versand");

        // ---- DATEI-LEISTE ueber der Textflaeche --------------------
        // Auswahl aller *.txt im Stammverzeichnis; die Auswahl LAEDT die
        // Datei in die Textflaeche. Daneben der Dateiname, mit dem
        // gespeichert wird, und ganz rechts das Loeschen.
        {
            static std::vector<std::string> s_files;
            static bool s_scanned = false;
            // AUS data/pdfgen, NICHT aus dem Arbeitsverzeichnis.
            // [Vorher lief hier UiListFiles(".txt") ueber das Stamm-
            //  verzeichnis. Auf dem Desktop ist das der BUILD-Ordner --
            //  die Auswahl zeigte deshalb Dateien aus dem Bauwerk statt
            //  der mitgelieferten Vorlagen. Jetzt genau ein Ort, auf
            //  allen drei Plattformen derselbe.]
            if (!s_scanned) {
                s_files = XbmPaths_ListFiles(XbmPaths_Pdfgen(), ".txt");
                s_scanned = true;
            }


            std::string cur = UiTextGet("prototype.file");
            ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x * 0.55f);
            if (ImGui::BeginCombo("##dateiwahl",
                                  cur.empty() ? "(Datei waehlen)"
                                              : cur.c_str())) {
                if (s_files.empty()) ImGui::TextDisabled("(keine .txt-Dateien)");
                for (const std::string& f : s_files) {
                    bool sel = (f == cur);
                    if (ImGui::Selectable(f.c_str(), sel)) {
                        std::string inhalt;
                        if (UiReadFile(XbmPaths_Pdfgen() + "/" + f, inhalt)) {
                            UiTextSet("prototype.source", inhalt);
                            UiTextSet("prototype.file", f);
                            UiTextSet("prototype.status", "geladen: " + f);
                        } else {
                            UiTextSet("prototype.status",
                                      "konnte nicht gelesen werden: " + f);
                        }
                    }
                    if (sel) ImGui::SetItemDefaultFocus();
                }
                ImGui::EndCombo();
            }
            ImGui::SameLine();
            if (ImGui::SmallButton("Neu einlesen")) s_scanned = false;
            ImGui::SetItemTooltip("Vorlagenordner:\n%s",
                                  XbmPaths_Pdfgen().c_str());

            // Dateiname + Speichern; Loeschen rechtsbuendig am Rand.
            float delW = ImGui::CalcTextSize("Loeschen").x
                       + ImGui::GetStyle().FramePadding.x * 2.0f;
            float saveW = ImGui::CalcTextSize("Speichern").x
                        + ImGui::GetStyle().FramePadding.x * 2.0f;
            float avail = ImGui::GetContentRegionAvail().x;
            float nameW = avail - saveW - delW
                        - ImGui::GetStyle().ItemSpacing.x * 3.0f;
            if (nameW < 80.0f) nameW = 80.0f;
            ImGui::SetNextItemWidth(nameW);
            UiInputText("##dateiname", "prototype.file");
            ImGui::SameLine();
            if (ImGui::Button("Speichern")) {
                std::string fn = UiTextGet("prototype.file");
                if (fn.empty()) {
                    UiTextSet("prototype.status", "kein Dateiname gesetzt");
                } else if (UiWriteFile(XbmPaths_Pdfgen() + "/" + fn,
                                       UiTextGet("prototype.source"))) {
                    UiTextSet("prototype.status", "gespeichert: " + fn);
                    s_scanned = false;               // Liste auffrischen
                } else {
                    UiTextSet("prototype.status",
                              "Speichern fehlgeschlagen: " + fn);
                }
            }
            // Rechtsbuendig: Cursor ans rechte Ende setzen.
            ImGui::SameLine(ImGui::GetCursorPosX()
                            + ImGui::GetContentRegionAvail().x - delW);
            if (ImGui::Button("Loeschen")) ImGui::OpenPopup("##del_confirm");
            if (ImGui::BeginPopup("##del_confirm")) {
                std::string fn = UiTextGet("prototype.file");
                ImGui::Text("'%s' wirklich loeschen?", fn.c_str());
                if (ImGui::Button("Ja, loeschen")) {
                    if (UiDeleteFile((XbmPaths_Pdfgen() + "/" + fn).c_str())) {
                        UiTextSet("prototype.status", "geloescht: " + fn);
                        UiTextSet("prototype.file", "");
                        s_scanned = false;
                    } else {
                        UiTextSet("prototype.status",
                                  "Loeschen fehlgeschlagen: " + fn);
                    }
                    ImGui::CloseCurrentPopup();
                }
                ImGui::SameLine();
                if (ImGui::Button("Abbrechen")) ImGui::CloseCurrentPopup();
                ImGui::EndPopup();
            }
            std::string st = UiTextGet("prototype.status");
            if (!st.empty()) ImGui::TextDisabled("%s", st.c_str());

            // ===============================================================
            // DATEIEN IM PDFGEN-ORDNER: sichten, oeffnen, ins Projekt pushen
            // ===============================================================
            if (ImGui::CollapsingHeader("Dateien in pdfgen")) {
                static std::vector<std::string> s_alle;
                static std::vector<std::string> s_ordner;
                static bool s_alleGescannt = false;
                static std::string s_unterordner;   // "" = pdfgen selbst
                const std::string basis = XbmPaths_Pdfgen()
                    + (s_unterordner.empty() ? "" : "/" + s_unterordner);
                if (!s_alleGescannt) {
                    s_alle   = XbmPaths_ListFiles(basis);
                    s_ordner = XbmPaths_ListDirs(basis);
                    s_alleGescannt = true;
                }
                ImGui::TextDisabled("%s", basis.c_str());
                if (ImGui::SmallButton("Neu einlesen##alle")) s_alleGescannt = false;
                ImGui::SameLine();
                if (ImGui::SmallButton("Ordner im Dateimanager oeffnen")) {
                    if (!XbmPaths_OeffnenExtern(basis))
                        UiTextSet("prototype.status", "Oeffnen nicht moeglich: " + basis);
                }
                if (!s_unterordner.empty()) {
                    ImGui::SameLine();
                    if (ImGui::SmallButton("<- zurueck")) {
                        s_unterordner.clear(); s_alleGescannt = false;
                    }
                }
                // Unterordner zuerst, dann Dateien -- je Zeile ein "Oeffnen".
                for (const std::string& d : s_ordner) {
                    ImGui::PushID(d.c_str());
                    if (ImGui::Selectable(("[" + d + "]").c_str())) {
                        s_unterordner = s_unterordner.empty() ? d : s_unterordner + "/" + d;
                        s_alleGescannt = false;
                    }
                    ImGui::PopID();
                }
                if (s_alle.empty() && s_ordner.empty())
                    ImGui::TextDisabled("(leer)");
                for (const std::string& f : s_alle) {
                    ImGui::PushID(f.c_str());
                    const float bw = ImGui::CalcTextSize("Oeffnen").x
                                   + ImGui::GetStyle().FramePadding.x * 2.0f;
                    // ZEILE ALS SELECTABLE: hebt sich unter dem Zeiger hervor,
                    // Doppelklick oeffnet. [Reiner Text gab keinerlei
                    //  Rueckmeldung, auf welcher Zeile man gerade ist.]
                    ImGui::Selectable(f.c_str(), false,
                                      ImGuiSelectableFlags_AllowDoubleClick
                                    | ImGuiSelectableFlags_AllowOverlap,
                                      ImVec2(ImGui::GetContentRegionAvail().x - bw
                                             - ImGui::GetStyle().ItemSpacing.x, 0));
                    if (ImGui::IsItemHovered() && ImGui::IsMouseDoubleClicked(0))
                        XbmPaths_OeffnenExtern(basis + "/" + f);
                    ImGui::SameLine(ImGui::GetCursorPosX()
                                    + ImGui::GetContentRegionAvail().x - bw);
                    if (ImGui::SmallButton("Oeffnen")) {
                        // PDF im Betrachter, .txt im Editor -- was das System
                        // fuer die Endung eingestellt hat.
                        if (!XbmPaths_OeffnenExtern(basis + "/" + f))
                            UiTextSet("prototype.status", "Oeffnen nicht moeglich: " + f);
                    }
                    ImGui::PopID();
                }

                ImGui::Separator();
                // --- PUSH: Benutzerdaten -> Projekt -> Git ----------------
                // [Nur auf Knopfdruck. Nimmt pdfgen UND scripts mit, damit
                //  auch Netzwerk-Scripts (siehe Netzwerk-Seite) auf alle
                //  Geraete gelangen.]
                static bool s_pushLaeuft = false;
                const bool pushMoeglich = XbmProjektPush_Moeglich();
                ImGui::BeginDisabled(!pushMoeglich || s_pushLaeuft);
                if (ImGui::Button(s_pushLaeuft ? "Push laeuft ..." : "Push ins Projekt (Git)")) {
                    s_pushLaeuft = true;
                    XbmProjektPush_Async({"pdfgen", "scripts"},
                        "pdfgen/scripts aus der App aktualisiert",
                        [](const XbmProjektPushErgebnis& e) {
                            s_pushLaeuft = false;
                            UiAlertZeigen("projekt_push", e.meldung,
                                          e.ok ? UiAlertArt::Info : UiAlertArt::Fehler);
                        });
                }
                ImGui::EndDisabled();
                if (!pushMoeglich) {
                    ImGui::SameLine(); ImGui::TextDisabled("(?)");
                    if (ImGui::IsItemHovered())
                        ImGui::SetTooltip(
#if defined(__ANDROID__)
                            "Auf Android gibt es kein Git.\n"
                            "Weg: Netzwerk-Seite -> 'Alle abgleichen' zum Desktop,\n"
                            "dort 'Push ins Projekt' druecken."
#else
                            "Kein Projektordner gefunden -- die App laeuft nicht\n"
                            "aus einem Bauordner (builds/...) mit .git und data/shared."
#endif
                        );
                } else {
                    ImGui::SameLine();
                    ImGui::TextDisabled("-> %s/data/shared", XbmPaths_ProjektRoot().c_str());
                }
            }
        }

        UiInputText("Emails", "prototype.emails");
        std::vector<std::string_view> sources, mailNames;
        // HALTESPEICHER FUER ZUSAMMENGESETZTE PFADE.
        // [sources ist ein vector<string_view> -- es SCHAUT auf Zeichen,
        //  besitzt sie nicht. Bei
        //      sources.push_back(XbmPaths_Pdfgen() + "/source_file.txt");
        //  entsteht rechts ein TEMPORAERER String, der am Ende der Zeile
        //  stirbt. Der string_view zeigt danach ins Leere, und
        //  UiMailSender bekommt Muell -- je nach Laune der Bibliothek ein
        //  leerer Name, ein falscher Pfad oder ein Absturz. Genau davor
        //  warnt der Compiler mit -Wdangling-capture.
        //  Die Zeichenketten leben jetzt hier, so lange wie die views.]
        static std::vector<std::string> quellHalter;
        auto quellPfad = [&](const std::string& p) -> std::string_view {
            quellHalter.push_back(p);
            return quellHalter.back();
        };
        bool mailMode = false;
        // "Testlauf" ist ein GESPEICHERTER Schalter. [Vorher stand hier
        // ein frame-lokales 'bool v = true' -- das wurde jeden Frame neu
        // auf true gesetzt, liess sich also gar nicht umschalten, und
        // sein Wert ueberlebte keinen Neustart.]
        bool mailTest = UiFlagGet("prototype.testlauf", false);
        // ---- TEXTFLAECHE ------------------------------------------
        // Sie fuellt IMMER den gesamten Rest des Fensters -- auch wenn
        // kein Text drin steht. Der Deckel ist der SICHTBARE Bereich:
        // Faehrt die Android-Tastatur aus, schrumpft er entsprechend,
        // und die Flaeche wird kleiner statt hinter der Tastatur zu
        // verschwinden.
        float wantTA;
        {
            // WICHTIG: aus dem VERFUEGBAREN PLATZ im Fenster rechnen,
            // NICHT aus Bildschirmkoordinaten. [Vorher stand hier
            // GetCursorScreenPos().y gegen UiVisBottom() -- beim
            // Scrollen der Seite aenderte sich diese Bildschirmposition,
            // und die Textflaeche wurde beim Scrollen groesser/kleiner.
            // GetContentRegionAvail() ist scroll-unabhaengig.]
            // Was UNTER der Textflaeche steht (Checkbox, zwei Knoepfe,
            // Trenner, Rand), wird nicht mehr GESCHAETZT, sondern aus
            // dem letzten Frame gemessen: Eine zu knappe Schaetzung
            // machte das Fenster ein paar Pixel zu hoch -- und schon
            // scrollte die Seite. Der erste Frame nutzt einen Startwert,
            // ab dem zweiten stimmt es auf das Pixel.
            wantTA = ImGui::GetContentRegionAvail().y - UiChromeBelow();

            if (!ImGui::IsWindowDocked()) {
                // FREIES Fenster: auf die sichtbare Hoehe bringen, damit
                // es vollstaendig in den Viewport passt (Tastatur!).
                float top  = ImGui::GetWindowPos().y;
                float maxH = UiVisBottom() - top;
                if (maxH < 160.0f) maxH = 160.0f;
                ImVec2 sz = ImGui::GetWindowSize();
                if (sz.y > maxH + 1.0f)
                    ImGui::SetWindowSize(ImVec2(sz.x, maxH), ImGuiCond_Always);
            }
            if (wantTA < 60.0f) wantTA = 60.0f;   // Mindesthoehe
        }
        {
            UiTextSelPre();          // Griff-Zug: Maus vor dem Feld weg
            UiInputTextMultiline("##source", "prototype.source",
                                 ImVec2(-FLT_MIN, wantTA));
            UiTextSelPost(ImGui::GetItemID(), ImGui::GetItemRectMin(),
                          ImGui::GetItemRectMax());
        }
        float yAfterTA = ImGui::GetCursorPosY();   // Messpunkt
        if (ImGui::Checkbox("Testlauf", &mailTest))
            UiFlagSet("prototype.testlauf", mailTest);   // sofort sichern
        // DIE GEWAEHLTE DATEI IST DIE QUELLE -- NICHT IMMER source_file.txt.
        // [Vorher schrieben beide Knoepfe den Editorinhalt fest nach
        //  source_file.txt und erzeugten source_file.pdf, egal welche
        //  Datei oben ausgewaehlt war. Wer Lebenslauf2.txt bearbeitete,
        //  bekam trotzdem source_file.pdf -- und source_file.txt wurde
        //  dabei nebenbei ueberschrieben. Jetzt: der Name aus der Auswahl
        //  ("prototype.file"); nur wenn keiner gesetzt ist, faellt es auf
        //  source_file.txt zurueck. Die PDF heisst dann wie die Quelle.]
        auto quellDatei = [&]() -> std::string {
            std::string fn = UiTextGet("prototype.file");
            if (fn.empty()) fn = "source_file.txt";
            return XbmPaths_Pdfgen() + "/" + fn;
        };
        if (ImGui::Button("Pdfgen")) {
          mailMode = false;
          const std::string quelle = quellDatei();
          UiWriteFile(quelle, UiTextGet("prototype.source"));
          sources.push_back(quellPfad(quelle));
          UiTextSet("prototype.status", "Pdfgen: " + quelle);
          if (UiMailSender()){ 
            UIP_LOGF("UiMailSender ui_pages.h");
            UiMailSender()(sources, mailNames, mailMode, mailTest);
          }
          else
            UIP_LOGF("UiMailSender ui_pages.h failed");
        }
        if (ImGui::Button("Pdfgen & Senden")) {
          mailMode = true;
          auto emails=split_by_comma_or_space(UiText("prototype.emails"));
          for (std::string_view email : emails) {
            mailNames.push_back(email);
            // if (UiMailSender()) UiMailSender()(sources, mailNames, mailMode, mailTest);
          }
          const std::string quelle = quellDatei();
          UiWriteFile(quelle, UiTextGet("prototype.source"));
          sources.push_back(quellPfad(quelle));
          UiTextSet("prototype.status", "Pdfgen & Senden: " + quelle);
          if (UiMailSender()){ 
            UIP_LOGF("UiMailSender ui_pages.h");
            UiMailSender()(sources, mailNames, mailMode, mailTest);
          }
          else
            UIP_LOGF("UiMailSender ui_pages.h failed");
        }
        {
          // UiNetInit(); // einmal beim App-Start
          // UiNetDownload("https://…/datei.zip", "datei.zip");

          // // pro Frame im UI:
          // const UiNetJob& j = UiNetStatus();
          // if (j.running) { ImGui::ProgressBar(j.Progress()); if (ImGui::Button("Abbrechen")) UiNetCancel(); }
        }
        // [Der frueher hier stehende Separator ist entfernt: Nach ihm
        //  kam nichts mehr, er trennte also nichts -- kostete aber
        //  Hoehe und schob den Fensterinhalt ueber den DockSpace.]
        // Gemessene Hoehe alles Nachfolgenden fuer den naechsten Frame
        // merken. KEIN zusaetzliches WindowPadding aufschlagen:
        // GetContentRegionAvail() rechnet den unteren Rand bereits
        // heraus -- ein zweiter Aufschlag verschob die Bilanz.
        UiChromeBelow() = ImGui::GetCursorPosY() - yAfterTA;
    }
    ImGui::End();
}


// ---------------------------------------------------------------------------
// SEITEN-SYMBOLE -- gezeichnet, nicht aus einer Schrift.
// [Das ImGui-Standardfont hat keine Symbole, und eine Symbolschrift
//  einzubinden ist ein eigener Umbau (Laden, Zusammenfuehren, Groessen
//  je Plattform). Gezeichnete Glyphen brauchen nichts davon -- das
//  Zahnrad in der Navi ist schon genau so gemacht. Unbekannte Seiten
//  bekommen ihren Anfangsbuchstaben.]
// ---------------------------------------------------------------------------
static void DrawPageGlyph(const std::string& page, ImVec2 mn, ImVec2 mx,
                          ImU32 col) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    float w = mx.x - mn.x, h = mx.y - mn.y;
    float pad = w * 0.18f;
    ImVec2 a(mn.x + pad, mn.y + pad), b(mx.x - pad, mx.y - pad);
    float cw = b.x - a.x, ch = b.y - a.y;
    ImVec2 c((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f);
    float t = (w > 24.0f) ? 2.0f : 1.5f;
    if (page == "Haupt") {                      // Haus
        dl->AddTriangle(ImVec2(a.x, c.y), ImVec2(c.x, a.y), ImVec2(b.x, c.y), col, t);
        dl->AddRect(ImVec2(a.x + cw*0.15f, c.y), ImVec2(b.x - cw*0.15f, b.y), col, 0, 0, t);
    } else if (page == "Effekte") {             // Funke
        dl->AddLine(ImVec2(c.x, a.y), ImVec2(c.x, b.y), col, t);
        dl->AddLine(ImVec2(a.x, c.y), ImVec2(b.x, c.y), col, t);
        dl->AddLine(ImVec2(a.x+cw*0.2f, a.y+ch*0.2f), ImVec2(b.x-cw*0.2f, b.y-ch*0.2f), col, t*0.7f);
        dl->AddLine(ImVec2(b.x-cw*0.2f, a.y+ch*0.2f), ImVec2(a.x+cw*0.2f, b.y-ch*0.2f), col, t*0.7f);
    } else if (page == "Bewerben") {            // Aktenkoffer
        dl->AddRect(ImVec2(a.x, a.y + ch*0.25f), b, col, 2.0f, 0, t);
        dl->AddRect(ImVec2(c.x - cw*0.2f, a.y), ImVec2(c.x + cw*0.2f, a.y + ch*0.25f), col, 0, 0, t);
        dl->AddLine(ImVec2(a.x, c.y + ch*0.05f), ImVec2(b.x, c.y + ch*0.05f), col, t*0.7f);
    } else if (page == "Kalender") {            // Kalenderblatt
        dl->AddRect(a, b, col, 2.0f, 0, t);
        dl->AddLine(ImVec2(a.x, a.y + ch*0.3f), ImVec2(b.x, a.y + ch*0.3f), col, t);
        dl->AddLine(ImVec2(a.x+cw*0.3f, a.y - ch*0.1f), ImVec2(a.x+cw*0.3f, a.y+ch*0.15f), col, t);
        dl->AddLine(ImVec2(b.x-cw*0.3f, a.y - ch*0.1f), ImVec2(b.x-cw*0.3f, a.y+ch*0.15f), col, t);
    } else if (page == "Netzwerk") {            // drei Knoten, verbunden
        float r = w * 0.09f;
        ImVec2 p1(c.x, a.y + r), p2(a.x + r, b.y - r), p3(b.x - r, b.y - r);
        dl->AddLine(p1, p2, col, t*0.8f); dl->AddLine(p1, p3, col, t*0.8f);
        dl->AddLine(p2, p3, col, t*0.8f);
        dl->AddCircleFilled(p1, r, col); dl->AddCircleFilled(p2, r, col);
        dl->AddCircleFilled(p3, r, col);
    } else {                                    // Anfangsbuchstabe
        char buf[2] = { page.empty() ? '?' : page[0], 0 };
        ImVec2 ts = ImGui::CalcTextSize(buf);
        dl->AddText(ImVec2(c.x - ts.x*0.5f, c.y - ts.y*0.5f), col, buf);
    }
}

void UiPagesFrame(bool touchMode) {
    // SICHTBARER BEREICH -- DESKTOP-RUECKFALL.
    // main_android setzt UiVisTop/Bottom jeden Frame (Viewport minus
    // Tastatur). Auf dem Desktop setzte sie NIEMAND: beide standen auf
    // 0, UiVisHeight() war damit 1 -- und der Hoehen-Deckel in
    // UiLeafWantY klemmte JEDES Fenster auf sein 120px-Minimum. Die
    // Folgen: uebereinandergelegte Knoepfe, wirres Resizing, beim
    // Verschieben "verschwindende" (weil zusammengestauchte) Fenster.
    {
        // OFFSCREEN-RETTUNG: Ein freies Fenster, das komplett ausserhalb
        // des Viewports liegt (z.B. durch eine alte gespeicherte
        // Position aus einer anderen Aufloesung), waere unerreichbar --
        // fuer den Nutzer "verschwunden". Zurueck an den Rand holen.
        ImGuiViewport* rvp = ImGui::GetMainViewport();
        ImVec2 vmin = rvp->WorkPos;
        ImVec2 vmax(rvp->WorkPos.x + rvp->WorkSize.x,
                    rvp->WorkPos.y + rvp->WorkSize.y);
        ImGuiContext* rg = ImGui::GetCurrentContext();
        if (rg) for (ImGuiWindow* w : rg->Windows) {
            if (!w->WasActive || w->Hidden || w->DockIsActive) continue;
            if (w->Flags & (ImGuiWindowFlags_ChildWindow
                          | ImGuiWindowFlags_Tooltip
                          | ImGuiWindowFlags_Popup)) continue;
            bool off = (w->Pos.x + w->Size.x < vmin.x + 24.0f)
                    || (w->Pos.y + w->Size.y < vmin.y + 24.0f)
                    || (w->Pos.x > vmax.x - 24.0f)
                    || (w->Pos.y > vmax.y - 24.0f);
            if (!off) continue;
            ImVec2 np(w->Pos.x, w->Pos.y);
            if (np.x + w->Size.x < vmin.x + 24.0f) np.x = vmin.x;
            if (np.y + w->Size.y < vmin.y + 24.0f) np.y = vmin.y;
            if (np.x > vmax.x - 24.0f) np.x = vmax.x - w->Size.x;
            if (np.y > vmax.y - 24.0f) np.y = vmax.y - w->Size.y;
            ImGui::SetWindowPos(w, np, ImGuiCond_Always);
        }
    }
    if (UiVisBottom() <= UiVisTop() + 0.5f) {
        ImGuiViewport* fvp = ImGui::GetMainViewport();
        UiVisTop()    = fvp->WorkPos.y;
        UiVisBottom() = fvp->WorkPos.y + fvp->WorkSize.y;
    }
    // [UiFixedHeightPreFrame() bewusst NICHT mehr aufgerufen: Ein
    //  Vorziehen der Hoehe erzeugte eine Rueckkopplung mit der Messung
    //  am Frame-Ende -- der Monitor ruckelte wild und riss ueber den
    //  gemeinsamen Baum alle Nachbarn mit. Der Balken wird stattdessen
    //  ueber Fenster-Flags unterdrueckt, s. UiWinFlags.]
    // Sperre FRUEH: faengt den Tab-/Fenster-Zug, bevor ImGui ihn im
    // selben Frame in ein Undock verwandelt.
    UiLayoutLockEnforce();
    UiLayoutLockRedock();
    using namespace ui_pages_detail;
    auto& pages = UiPages();
    if (pages.empty()) return;
    ImGuiViewport* vp = ImGui::GetMainViewport();

    // Vorgemerkte Frei-Positionen anwenden, sobald das jeweilige Fenster
    // tatsaechlich frei (nicht mehr gedockt) ist.
    for (auto it = g_pendingFree.begin(); it != g_pendingFree.end(); ) {
        // Schutz: gehoert das Fenster zur AKTIVEN Kompakt-Seite, ist seine
        // Position Sache des Layout-Baums -- Altlast-Pendings verwerfen,
        // statt es im Undock-Zwischenzustand herauszupositionieren.
        if (UiPage* ap = UiActivePage()) {
            if (ap->compact && LayoutHasWindow(ap->name, it->first)) {
                it = g_pendingFree.erase(it);   // layout-verwaltet
                continue;
            }
        }
        ImGuiWindow* w = ImGui::FindWindowByName(it->first.c_str());
        if (w && !w->DockIsActive) {
            // GEGEN DEN AKTUELLEN BILDSCHIRM ABSICHERN, bevor eine
            // gespeicherte Position/Groesse angewendet wird.
            // [Ohne diese Pruefung wird ein einmal SCHLECHT gespeicherter
            //  Wert -- etwa waehrend eines Aufloesungswechsels, mitten in
            //  einem EGL-Kontextverlust, oder aus einer aelteren Fassung
            //  mit anderer Skalierung gespeichert -- bei JEDEM kuenftigen
            //  Start wieder genauso ungeprueft uebernommen. Genau das
            //  faellt als "manchmal ist nach dem Neustart alles ploetzlich
            //  viel groesser" auf: nicht die Skalierung selbst ist
            //  falsch, sondern ein einzelner verunglueckter gespeicherter
            //  Schnappschuss wird stur wiederholt.
            //  NaN/Inf werden hier ebenfalls abgefangen -- ein Vergleich
            //  mit NaN ist immer falsch, "> 1.0f" liesse eine solche
            //  Groesse also unbemerkt durch, wenn man nur nach oben
            //  begrenzt.]
            ImVec2 pos = it->second.pos, size = it->second.size;
            const bool posGueltig  = std::isfinite(pos.x) && std::isfinite(pos.y);
            const bool sizeGueltig = std::isfinite(size.x) && std::isfinite(size.y);
            const float minSeite = 80.0f;   // kleiner als das ist kein brauchbares Fenster
            const float maxB = vp->WorkSize.x, maxH = vp->WorkSize.y;
            if (!posGueltig || pos.x < vp->WorkPos.x - size.x + 40.0f
                            || pos.x > vp->WorkPos.x + maxB - 40.0f
                            || pos.y < vp->WorkPos.y
                            || pos.y > vp->WorkPos.y + maxH - 40.0f) {
                // Ausserhalb des sichtbaren Bereichs (oder ungueltig) --
                // an eine sichere Stelle zuruecksetzen statt off-screen
                // oder mit Phantomwerten wieder aufzumachen.
                pos = ImVec2(vp->WorkPos.x + 40.0f, vp->WorkPos.y + 40.0f);
            }
            if (!sizeGueltig || size.x > 1.0f) {
                if (!sizeGueltig || size.x < minSeite || size.y < minSeite
                                 || size.x > maxB || size.y > maxH) {
                    // Unsinnig klein, unsinnig gross oder ungueltig --
                    // auf eine vernuenftige Grundgroesse zurueckfallen,
                    // GEDECKELT auf das, was der Bildschirm hergibt.
                    size = ImVec2(ImMin(300.0f, maxB), ImMin(260.0f, maxH));
                }
            }
            ImGui::SetWindowPos(w, pos, ImGuiCond_Always);
            if (size.x > 1.0f)   // 0 = Groesse unangetastet
                ImGui::SetWindowSize(w, size, ImGuiCond_Always);
            it = g_pendingFree.erase(it);
        } else ++it;
    }

    // ---- Uebergang 1: Tab-Wechsel ----
    if (g_lastActive != g_active) {
        if (g_lastActive == -1) {
            // Boot: KEIN Apply -- imgui.ini hat die Fenster bereits im
            // Zustand des letzten Beendens wiederhergestellt; ein Apply
            // gegen (noch) leere Maps wuerde nur ausdocken und Standard-
            // Positionen erzeugen.
            g_lastActive = g_active;
        } else {
            if (g_lastActive >= 0 && g_lastActive < (int)pages.size())
                SavePageState(pages[g_lastActive], /*force=*/true);
            UiPagesPersist();
            if (g_active >= 0 && g_active < (int)pages.size())
                ApplyPageState(pages[g_active]);
            g_lastActive = g_active;
        }
    }

    // Auto-Snapshot: Zustand der aktiven Seite alle 2 s in die Maps
    // uebernehmen, damit die Persistenz (xbm.ini) stets frische Daten
    // schreibt -- nicht nur die von der letzten Transition.
    {
        static double lastAuto = 0;
        if (ImGui::GetTime() - lastAuto > 2.0) {
            lastAuto = ImGui::GetTime();
            if (UiPage* ap = UiActivePage()) SavePageState(*ap);
        }
    }

    // ---- Drawer-Griff (Fallback-Knopf; der WISCH von der Kante ist
    // jetzt der Hauptweg -- der Knopf bleibt fuer Entdeckbarkeit) ----
    ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x, vp->WorkPos.y));
    ImGui::Begin("##drawer_grip", nullptr,
        ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize
        | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings
        | ImGuiWindowFlags_NoDocking);
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
    if (ImGui::Button(UiNavi::Left().openX > 4.0f ? "<" : "=")) {
        if (UiNavi::Left().openX > 4.0f) UiNavi::RequestClose(UiNavi::Left());
        else UiNavi::RequestOpen(UiNavi::Left(),
                                 UiNavi::TotalW(UiNavi::Left()));
    }
    ImGui::PopStyleColor();
    g_gripW = ImGui::GetWindowSize().x;          // fuer buendige Tab-Leiste
    float gripH = ImGui::GetWindowSize().y;
    ImGui::End();

    // ---- Rand-Navigationen (Finger-Engine, s. ui_navi.h) ----
    {
        UiNavi::EnsureDefaults(vp->WorkSize.x);
        // VORLAGEN in Navi 1 RECHTS (Abschnitt unter "Fenster", gleich hoch).
        // [Inhalt per Callback, damit ui_navi den Kalender nicht kennt.]
        if (!UiNavi::VorlagenInhalt()) UiNavi::VorlagenInhalt() = []{ UiCalendar_VorlagenNavi(); };
        if (!UiNavi::PapierkorbInhalt()) UiNavi::PapierkorbInhalt() = []{ UiCalendar_PapierkorbNavi(); };
        UiCondButtons_SetActivePage(UiActivePage() ? UiActivePage()->name : "");
        // BEDINGTE KNOEPFE der rechten Leiste. Einmalig anmelden; die
        // Leiste (UiNavi::RightRailContent) zeichnet danach nur noch,
        // was gerade zutrifft. Der Mikrofon-Knopf erscheint also genau
        // dann, wenn das Kalenderfenster auf der aktiven Seite sichtbar
        // ist -- ohne dass die Leiste den Kalender kennen muesste.
        static bool s_condOnce = false;
        if (!s_condOnce) {
            s_condOnce = true;
            UiCondButtons_ClaimGesture = [] { UiDragHandledThisFrame() = true; };

            // NOTIZ+ -- SIMPLES EVENT OHNE MEMO.
            // [VOR dem Mikrofon registriert: UiCondButtons_DrawColumn
            //  stapelt in Registrierreihenfolge, und du wolltest den
            //  Knopf UEBER dem Mikrofonsymbol.]
            UiCondButton note;
            note.id      = "kalender.note";
            note.tooltip = "Neue Notiz anlegen (zum ausgewaehlten Datum)";
            note.kind    = UiCondKind::WindowShown;
            note.target  = "Kalender";
            note.icon    = UiCondIcon_Note;
            note.onClick = [] { UiCalendar_QuickAdd(); };
            UiCondButtons_Register(note);

            // GRUPPEN (Kalender): erscheinen nur, wenn die Auswahl es hergibt.
            {
                auto kalSichtbar = [] { return UiActivePage() && UiActivePage()->name == "Kalender"; };
                UiCondButton gr;
                gr.id = "kalender.gruppieren"; gr.tooltip = "Ausgewaehlte Termine gruppieren (Shift+Tipp waehlt mehrere)";
                gr.kind = UiCondKind::Custom; gr.target = "Kalender";
                gr.custom = [kalSichtbar] { return kalSichtbar() && UiCalendar_AuswahlAnzahl() >= 2; };
                gr.icon = [](ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col) {   // zwei Kaestchen in einer Klammer
                    const float w = b.x - a.x, p = w * 0.2f, t = ImMax(1.5f, w * 0.07f);
                    dl->AddRect(ImVec2(a.x + p, a.y + p), ImVec2(b.x - p, b.y - p), col, w * 0.08f, 0, t);
                    dl->AddRectFilled(ImVec2(a.x + p * 1.7f, a.y + p * 1.7f), ImVec2(a.x + w * 0.48f, b.y - p * 1.7f), col);
                    dl->AddRectFilled(ImVec2(b.x - w * 0.48f, a.y + p * 1.7f), ImVec2(b.x - p * 1.7f, b.y - p * 1.7f), col);
                };
                gr.onClick = [] { UiCalendar_Gruppieren(); };
                UiCondButtons_Register(gr);
                UiCondButton ug;
                ug.id = "kalender.ungruppieren"; ug.tooltip = "Gruppe aufloesen (Mitglieder bleiben an ihrer Lage)";
                ug.kind = UiCondKind::Custom; ug.target = "Kalender";
                ug.custom = [kalSichtbar] { return kalSichtbar() && UiCalendar_GruppeAusgewaehlt(); };
                ug.icon = [](ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col) {   // zwei Kaestchen, Klammer durchgestrichen
                    const float w = b.x - a.x, p = w * 0.2f, t = ImMax(1.5f, w * 0.07f);
                    dl->AddRectFilled(ImVec2(a.x + p, a.y + p * 1.7f), ImVec2(a.x + w * 0.42f, b.y - p * 1.7f), col);
                    dl->AddRectFilled(ImVec2(b.x - w * 0.42f, a.y + p * 1.7f), ImVec2(b.x - p, b.y - p * 1.7f), col);
                    dl->AddLine(ImVec2(a.x + p, b.y - p), ImVec2(b.x - p, a.y + p), col, t);
                };
                ug.onClick = [] { UiCalendar_Ungruppieren(); };
                UiCondButtons_Register(ug);
                UiCondButton du;
                du.id = "kalender.duplizieren"; du.tooltip = "Auswahl duplizieren (an die gelbe Zeitauswahl, sonst einen Tag spaeter); Strg+C / Strg+V geht auch";
                du.kind = UiCondKind::Custom; du.target = "Kalender";
                du.custom = [kalSichtbar] { return kalSichtbar() && UiCalendar_AuswahlAnzahl() >= 1; };
                du.icon = [](ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col) {   // zwei versetzte Blaetter
                    const float w = b.x - a.x, p = w * 0.18f, t = ImMax(1.5f, w * 0.07f);
                    dl->AddRect(ImVec2(a.x + p, a.y + p), ImVec2(b.x - p * 2.2f, b.y - p * 2.2f), col, w * 0.06f, 0, t);
                    dl->AddRect(ImVec2(a.x + p * 2.2f, a.y + p * 2.2f), ImVec2(b.x - p, b.y - p), col, w * 0.06f, 0, t);
                };
                du.onClick = [] { UiCalendar_Duplizieren(); };
                UiCondButtons_Register(du);
            }
            UiCondButton mic;
            mic.id      = "kalender.memo";
            mic.tooltip = "Sprachmemo aufnehmen (gedrueckt halten)";
            mic.kind    = UiCondKind::WindowShown;
            mic.target  = "Kalender";
            mic.icon    = UiCondIcon_Mic;
            mic.onHold  = [](bool held) {
                if ( held && !UiCalendar_MemoActive()) UiCalendar_MemoBegin();
                if (!held &&  UiCalendar_MemoActive()) UiCalendar_MemoEnd();
            };
            mic.lit     = [] { return UiCalendar_MemoActive(); };
            UiCondButtons_Register(mic);

            // STIFTWERKZEUG -- Bulk-Auswahl von Events zum gemeinsamen
            // Bearbeiten. "lit" zeigt, wenn es gerade aktiv ist.
            UiCondButton pen;
            pen.id      = "kalender.pen";
            pen.tooltip = "Mehrere Events auswaehlen und gemeinsam bearbeiten";
            pen.kind    = UiCondKind::WindowShown;
            pen.target  = "Kalender";
            pen.icon    = UiCondIcon_Pen;
            pen.onClick = [] { UiCalendar_PenToolSet(!UiCalendar_PenToolActive()); };
            pen.lit     = [] { return UiCalendar_PenToolActive(); };
            UiCondButtons_Register(pen);

            // RADIERER: Wischen ueber Terminkoepfe loescht (in den Papierkorb).
            UiCondButton er;
            er.id      = "kalender.radierer";
            er.tooltip = "Radierer: ueber Terminkoepfe wischen loescht sie in den Papierkorb (Navi 1 rechts, wiederherstellbar)";
            er.kind    = UiCondKind::WindowShown;
            er.target  = "Kalender";
            er.icon    = [](ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col) {   // schraeger Radiergummi
                const float w = b.x - a.x, t = ImMax(1.5f, w * 0.07f);
                const ImVec2 p0(a.x + w * 0.22f, b.y - w * 0.3f), p1(a.x + w * 0.5f, a.y + w * 0.25f), p2(b.x - w * 0.18f, a.y + w * 0.5f), p3(a.x + w * 0.52f, b.y - w * 0.12f);
                dl->AddQuad(p0, p1, p2, p3, col, t);
                dl->AddLine(ImVec2(a.x + w * 0.36f, b.y - w * 0.21f), ImVec2(a.x + w * 0.66f, a.y + w * 0.44f), col, t);
            };
            er.onClick = [] { UiCalendar_EraserSet(!UiCalendar_EraserActive()); };
            er.lit     = [] { return UiCalendar_EraserActive(); };
            UiCondButtons_Register(er);

            // SOFORT VERSCHIEBEN (Schalter): Termine ohne vorherige Auswahl ziehen.
            UiCondButton sv;
            sv.id      = "kalender.sofort";
            sv.tooltip = "Sofort verschieben: Termine ohne vorherige Auswahl ziehen (sonst: erst auswaehlen; ein Zug am nicht ausgewaehlten Termin ist Drag & Drop in Baum, Papierkorb oder Vorlagen)";
            sv.kind    = UiCondKind::WindowShown;
            sv.target  = "Kalender";
            sv.icon    = [](ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col) {   // Kaestchen mit Pfeil nach rechts, Haken-Rahmen
                const float w = b.x - a.x, t = ImMax(1.5f, w * 0.07f);
                dl->AddRect(ImVec2(a.x + w * 0.18f, a.y + w * 0.3f), ImVec2(a.x + w * 0.5f, b.y - w * 0.3f), col, w * 0.05f, 0, t);
                dl->AddLine(ImVec2(a.x + w * 0.56f, (a.y + b.y) * 0.5f), ImVec2(b.x - w * 0.18f, (a.y + b.y) * 0.5f), col, t);
                dl->AddLine(ImVec2(b.x - w * 0.3f, (a.y + b.y) * 0.5f - w * 0.12f), ImVec2(b.x - w * 0.18f, (a.y + b.y) * 0.5f), col, t);
                dl->AddLine(ImVec2(b.x - w * 0.3f, (a.y + b.y) * 0.5f + w * 0.12f), ImVec2(b.x - w * 0.18f, (a.y + b.y) * 0.5f), col, t);
            };
            sv.onClick = [] { UiCalendar_SofortVerschiebenSet(!UiCalendar_SofortVerschieben()); };
            sv.lit     = [] { return UiCalendar_SofortVerschieben(); };
            UiCondButtons_Register(sv);

            // PROTOKOLL-KNOPF in der rechten Leiste.
            // Bedingung: nur zeigen, wenn das Protokollfenster auf der
            // aktuellen Seite NICHT zu sehen ist -- dann holt man es damit
            // hervor. Ist es sichtbar, waere der Knopf ueberfluessig.
            UiCondButton lg;
            lg.id      = "app.log";
            lg.tooltip = "Protokoll oeffnen";
            lg.kind    = UiCondKind::Custom;
            lg.custom  = [] { return !UiLog_WindowVisible(); };
            lg.icon    = UiLogIcon;
            lg.onClick = [] { UiLog_WindowOpen() = true; };
            // Leuchtet, solange ungesehene Fehler anstehen.
            lg.lit     = [] { return UiLog_UnseenError() > 0; };
            UiCondButtons_Register(lg);
        }
        // App-Einstellungen zeigen den Inhalt der frueheren
        // Effekt-Einstellungen (deren Fenster ist abgeschafft).
        if (!UiNavi::AppSettingsContent())
            UiNavi::AppSettingsContent() = []() {
                EffectsGl_SettingsContent();
            };
        UiNavi::EdgeState& NL = UiNavi::Left();
        UiNavi::EdgeState& NR = UiNavi::Right();
        // Navi 0-Kopfinhalt: Seitenliste + Kompakt-Schalter. Beides
        // faehrt die Navi automatisch ein (Seitenwechsel wie gehabt,
        // Kompakt-Klick NEU auf Wunsch).
        NL.panels[0].content = [&pages]() {
            ImGui::TextUnformatted("Seiten"); ImGui::Separator();
            for (int i = 0; i < (int)pages.size(); ++i) {
                // Dasselbe Symbol wie oben, dann der Name.
                float gh = ImGui::GetTextLineHeight();
                ImVec2 gmin = ImGui::GetCursorScreenPos();
                ImGui::Dummy(ImVec2(gh, gh));
                DrawPageGlyph(pages[i].name, gmin,
                              ImVec2(gmin.x + gh, gmin.y + gh),
                              ImGui::GetColorU32(ImGuiCol_Text));
                ImGui::SameLine();
                if (ImGui::Selectable(pages[i].name.c_str(),
                                      i == g_active))
                    { g_active = i; UiNavi::RequestClose(UiNavi::Left()); }
            }
            ImGui::Separator();
            // ["Kompakt-Layout dieser Seite" ist hier ersatzlos entfallen.
            //  Der Knopf war bereits ausgebaut, uebrig blieb toter Code:
            //      bool prev = pg->compact;
            //      if (pg->compact != prev) { ... }
            //  Die Bedingung vergleicht eine Kopie mit ihrem Original und
            //  ist damit IMMER falsch -- der Block konnte nie laufen.
            //  Kompakt ist jetzt ohnehin fest an (siehe app_settings.h),
            //  also faellt auch die Umschaltlogik weg.]
        };
        float topY = vp->WorkPos.y + g_barH;
        float botY = vp->WorkPos.y + vp->WorkSize.y;
        std::string ap = UiActivePage() ? UiActivePage()->name : "";
        UiNavi::UpdateDrag(NL, vp->WorkPos.x,
                           vp->WorkPos.x + vp->WorkSize.x, topY, botY);
        UiNavi::UpdateDrag(NR, vp->WorkPos.x,
                           vp->WorkPos.x + vp->WorkSize.x, topY, botY);
        UiNavi::DrawPanels(NL, vp->WorkPos.x,
                           vp->WorkPos.x + vp->WorkSize.x, topY, botY, ap);
        UiNavi::DrawPanels(NR, vp->WorkPos.x,
                           vp->WorkPos.x + vp->WorkSize.x, topY, botY, ap);
        // ERST JETZT die Stapelreihenfolge festlegen: zuletzt angefasstes
        // Element ganz nach vorn. Muss NACH beiden Kanten laufen, sonst
        // gewinnt schlicht die spaeter gezeichnete (so lag das
        // Einstellungsblatt immer hinter der rechten Navi).
        UiNavi::ApplyZOrder();

        // PROTOKOLLFENSTER und Einblendungen.
        // Das Fenster ist ein gewoehnliches ImGui-Fenster und laesst sich
        // deshalb auf jeder Seite andocken. Die Einblendungen liegen auf
        // der Vordergrund-Zeichenliste -- sie fangen keine Klicks ab.
        // UEBER DAS SEITENSYSTEM zeichnen, wie jedes andere Fenster auch.
        // [Vorher stand hier ein blosses UiLog_DrawWindow("Protokoll", ...).
        //  Damit war es ein Fenster ausserhalb jeder Seite: an die
        //  Navigationen liess es sich heften, in das DockSpace-Layout der
        //  Seite aber nicht. UiPageWindow() vergibt den seitenbezogenen
        //  Titel, UiWinFlags() die Flags, die alle Seitenfenster haben --
        //  damit verhaelt es sich wie das Kalender- oder Prototype-Fenster.]
        if (const char* tLog = UiPageWindow("Protokoll"))
            UiLog_DrawWindow(tLog, &UiLog_WindowOpen(), UiWinFlags(tLog));
        UiLog_DrawToasts();
        // Waehrend eine Navi am Finger klebt, deutet der Pinpoint den
        // Zug nicht zusaetzlich als Scroll.
        if (NL.dragging || NR.dragging) UiDragHandledThisFrame() = true;
        if (UiNavi::ConsumedClick()) {
            UiDragHandledThisFrame() = true;   // Sheet-Schliess-Klick
            UiNavi::ConsumedClick() = false;   // verpufft folgenlos
        }
        g_drawerT = NL.openX > 0.5f ? 1.0f : 0.0f;   // Altlast-Leser
        g_drawer  = NL.openX > 0.5f;
    }

    // ---- Tab-Leiste ----
    // BUENDIG: Tab-Leiste startet exakt an der rechten Griff-Kante --
    // die frueheren festen 44 px ueberlappten je nach Touch-Skalierung.
    ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x + g_gripW, vp->WorkPos.y));
    ImGui::SetNextWindowSize(ImVec2(vp->WorkSize.x - g_gripW, 0));
    // KEIN BALKEN AM ELTERNFENSTER.
    // [Hier stand ImGuiWindowFlags_HorizontalScrollbar. Das Kindfenster
    //  mit den Symbolen hatte laengst NoScrollbar -- aber ragt in der
    //  Leiste irgendetwas ein Pixel ueber (Zahnrad, Abstand), zeichnet
    //  das ELTERNFENSTER seinen eigenen Balken, und der deckt in einer
    //  30 px hohen Leiste alles ab. Deshalb blieb der Balken trotz der
    //  Aenderung am Kind. Beide Fenster: NoScrollbar. Gescrollt wird im
    //  Kind durch Ziehen und Mausrad.]
    // KEIN INNENABSTAND: die Knoepfe beginnen am linken Rand und fuellen
    // die Hoehe. Die Leiste ist dadurch genau so hoch wie ein Knopf.
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.0f, 0.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,   ImVec2(0.0f, 0.0f));
    ImGui::Begin("##page_tabs", nullptr,
        ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove
        | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoDocking
        | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    ImGui::PopStyleVar(2);
    // TABS IN EINEM SCROLLBAREN BEREICH, DER VOR DEM ZAHNRAD ENDET.
    // [Vorher lagen die Knoepfe direkt in der Leiste. Mit mehr Seiten
    //  liefen sie ueber die Bildschirmbreite hinaus und UEBER das
    //  Zahnrad rechts -- das war dann nicht mehr zu treffen. Ein
    //  Kindfenster mit fester Breite loest beides: es scrollt seitlich,
    //  und das Zahnrad steht immer daneben.]
    {
        // QUADRATISCHE KNOEPFE IN VOLLER LEISTENHOEHE.
        // [Die Kante ist das 1,6-fache einer Zeilenhoehe -- gross genug fuer
        //  den Finger, und da die Leiste keinen Innenabstand mehr hat,
        //  fuellen die Knoepfe sie vom linken Rand bis zu den rechten
        //  Knoepfen.]
        float gear = ImGui::GetFrameHeight() * 1.6f;
        // RECHTS STEHEN ZWEI KNOEPFE: Tastatur und Zahnrad. [Vorher wurde
        //  nur EINE Knopfbreite abgezogen -- mit dem Tastaturknopf daneben
        //  waere die Tab-Leiste genau eine Knopfbreite zu breit geworden
        //  und haette ihn ueberlappt, sodass er nicht mehr zu treffen
        //  gewesen waere.]
        const float rechteKnoepfe = gear * 2.0f;
        float tabW = ImGui::GetContentRegionAvail().x - rechteKnoepfe;
        if (tabW < gear) tabW = gear;
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.0f, 0.0f));
        // KEIN SICHTBARER BALKEN. Gescrollt wird durch Ziehen auf der
        // Leiste und mit dem Mausrad -- der Balken haette in einer 30 px
        // hohen Leiste ohnehin keinen Platz.
        ImGui::BeginChild("##page_tabs_scroll", ImVec2(tabW, gear), false,
                          ImGuiWindowFlags_NoScrollbar
                        | ImGuiWindowFlags_NoScrollWithMouse);
        {
            // Ziehen: Finger/Maus auf der Leiste verschiebt sie.
            // [Nur, wenn KEIN Knopf den Klick beansprucht -- sonst wuerde
            //  ein Tipp auf ein Symbol schon als Ziehen gelten. Die
            //  Knoepfe setzen ActiveId; ist keine gesetzt, ist es die
            //  freie Flaeche.]
            static bool ziehe = false;
            static float zieheX0 = 0.0f, zieheScroll0 = 0.0f;
            ImGuiIO& tio = ImGui::GetIO();
            bool ueber = ImGui::IsWindowHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem);
            if (ueber && ImGui::IsMouseClicked(0)) {
                ziehe = true; zieheX0 = tio.MousePos.x;
                zieheScroll0 = ImGui::GetScrollX();
            }
            if (ziehe && tio.MouseDown[0]) {
                float dx = tio.MousePos.x - zieheX0;
                // Erst ab ein paar Pixeln -- darunter ist es ein Tipp.
                if (fabsf(dx) > 6.0f) {
                    if (UiScrollPinpoint()) {
                        // PINPOINT auch hier: Auslenkung vom Aufsetzpunkt =
                        // Geschwindigkeit, wie im Rest der App.
                        float v = (fabsf(dx) - 6.0f) * 6.0f * (dx < 0 ? 1.0f : -1.0f);
                        ImGui::SetScrollX(ImGui::GetScrollX() + v * tio.DeltaTime);
                    } else {
                        ImGui::SetScrollX(zieheScroll0 - dx);
                    }
                    ImGui::ClearActiveID();     // dem Knopf den Klick nehmen
                }
            }
            if (!tio.MouseDown[0]) ziehe = false;
            // Mausrad (beide Achsen) verschiebt seitlich.
            if (ueber) {
                float rad = tio.MouseWheelH != 0.0f ? tio.MouseWheelH : tio.MouseWheel;
                if (rad != 0.0f)
                    ImGui::SetScrollX(ImGui::GetScrollX() - rad * gear * 2.0f);
            }
        }
        // QUADRATISCH UND LUECKENLOS: kein Abstand zwischen den Knoepfen,
        // damit ein Tipp "dazwischen" nicht ins Leere geht.
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0.0f, 0.0f));
        ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 0.0f);
        for (int i = 0; i < (int)pages.size(); ++i) {
            if (i) ImGui::SameLine();
            bool sel = (i == g_active);
            ImVec2 bmin = ImGui::GetCursorScreenPos();
            // SYMBOL STATT TEXT -- der Name bleibt als Tooltip und im
            // Knopf-Kennzeichen (##), damit ImGui ihn eindeutig haelt.
            std::string id = "##tab_" + pages[i].name;
            // BERUEHRUNG GENUEGT -- kein Loslassen noetig.
            // [ImGui::Button feuert erst beim LOSLASSEN ueber DEMSELBEN
            //  Knopf. Wischt der Finger weiter, feuert er nie: der Knopf
            //  sah gedrueckt aus, die Seite wechselte aber nicht. Und ein
            //  Wisch ueber die Leiste tat gar nichts.
            //  InvisibleButton mit MouseButtonLeft zeichnet nichts selbst
            //  (Flaeche und Symbol malen wir ohnehin) und laesst uns
            //  waehlen, WANN wir reagieren: sobald der Finger DRUECKT und
            //  ueber dem Knopf ist -- auch wenn er von nebenan kommt.]
            ImGui::InvisibleButton(id.c_str(), ImVec2(gear, gear));
            bool ueber = ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem);
            bool gedrueckt = ImGui::IsMouseDown(ImGuiMouseButton_Left);
            if (ueber && gedrueckt && g_active != i) {
                g_active = i;
                // Punkt 7: Seitenwahl faehrt die linke Navi ein -- wie
                // beim Klick auf die Seitenliste IN der Navi.
                UiNavi::RequestClose(UiNavi::Left());
                // Auf Wunsch auch die Einstellungsblaetter schliessen
                // (Vorgabe: an; Schalter in den Globalen Einstellungen).
                if (UiSheetCloseOnTab()) {
                    g_pageSheet = false;
                    UiNavi::AppSettingsOpen() = false;
                }
            }
            // Flaeche selbst zeichnen: aktiv = blau, darunter der Finger =
            // angedeutet, sonst durchsichtig.
            {
                ImU32 bg = sel
                    ? ImGui::GetColorU32(ImGuiCol_ButtonActive)
                    : (ueber && gedrueckt ? ImGui::GetColorU32(ImGuiCol_ButtonHovered)
                                          : 0);
                if (bg)
                    ImGui::GetWindowDrawList()->AddRectFilled(
                        bmin, ImVec2(bmin.x + gear, bmin.y + gear), bg);
            }
            if (ueber && !gedrueckt)
                ImGui::SetTooltip("%s", pages[i].name.c_str());
            // Aktiven Tab beim Wechsel in den sichtbaren Bereich holen.
            if (sel && ImGui::IsWindowAppearing()) ImGui::SetScrollHereX();
            DrawPageGlyph(pages[i].name, bmin,
                          ImVec2(bmin.x + gear, bmin.y + gear),
                          ImGui::GetColorU32(ImGuiCol_Text));
        }
        ImGui::PopStyleVar(2);
        ImGui::EndChild();
        ImGui::PopStyleVar();          // WindowPadding des Kindfensters
    }
    // SEITEN-EINSTELLUNGEN: Zahnrad GANZ RECHTS in der Tab-Leiste --
    // gleicher Knopf-Stil wie der Navi-Griff links (der bleibt als
    // Fallback fuer die Wisch-Geste erhalten). Oeffnet fuer die AKTIVE
    // Tabpage eine von OBEN angedockte Einstellungsflaeche (ohne
    // Animation, so hoch wie ihr Inhalt); Klick woanders schliesst.
    {
        // Dieselbe Kante wie die Tab-Knoepfe, buendig am rechten Rand.
        const float gearK = ImGui::GetFrameHeight() * 1.6f;
        ImGui::SameLine(ImGui::GetWindowWidth() - gearK);
        ImVec2 bmin = ImGui::GetCursorScreenPos();
        ImGui::PushStyleColor(ImGuiCol_Button,
            g_pageSheet ? ImGui::GetStyleColorVec4(ImGuiCol_ButtonActive)
                        : ImVec4(0, 0, 0, 0));
        if (ImGui::Button("##pgsheet_btn", ImVec2(gearK, gearK))) {
            g_pageSheet = !g_pageSheet;
            // [Diese Zeile hing vorher NICHT am if -- ohne Klammern lief
            //  ZTouch jeden Frame, solange das Blatt offen war, und hielt
            //  es dauerhaft "zuletzt angefasst".]
            if (g_pageSheet) UiNavi::ZTouch(UiNavi::ZElem::Settings);
        }
        ImGui::PopStyleColor();
        UiNavi::DrawGearGlyph(bmin,
            ImVec2(bmin.x + gearK, bmin.y + gearK));

        // TASTATURKNOPF -- LINKS NEBEN DEM ZAHNRAD.
        // Spiegelt UiAndroidTastaturVerwenden() -- GENAU den Schalter, den
        // auch der Umschalter in der Navi ("Tast.") und die Automatik in
        // main_android.cpp benutzen. [Bewusst NICHT UiKeyboardEnabled():
        //  das ist ein zweiter, unabhaengiger Schalter. Beide blockieren
        //  die Tastatur zwar gleichermassen (main_android.cpp prueft
        //  nacheinander beide), aber die automatische Abschaltung bei
        //  einem Anschlag auf einer physischen Tastatur setzt
        //  UiAndroidTastaturVerwenden. Spiegelte der Knopf den anderen
        //  Schalter, bliebe er nach so einer Abschaltung faelschlich "an"
        //  stehen, obwohl die Tastatur aus ist.]
        ImGui::SameLine(ImGui::GetWindowWidth() - gearK * 2.0f);
        ImVec2 kmin = ImGui::GetCursorScreenPos();
        const bool kbAn = UiAndroidTastaturVerwenden();
        ImGui::PushStyleColor(ImGuiCol_Button,
            kbAn ? ImGui::GetStyleColorVec4(ImGuiCol_ButtonActive)
                 : ImVec4(0, 0, 0, 0));
        if (ImGui::Button("##kbtoggle_btn", ImVec2(gearK, gearK))) {
            UiAndroidTastaturVerwenden() = !kbAn;
            // Beim Abschalten SOFORT einfahren, nicht erst beim naechsten
            // Fokuswechsel -- sonst bliebe die Tastatur stehen, obwohl der
            // Knopf schon aus ist.
            if (!UiAndroidTastaturVerwenden()) UiRequestHideKeyboard() = true;
        }
        ImGui::PopStyleColor();
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip(kbAn ? "Android-Tastatur verwenden (an)"
                                   : "Android-Tastatur verwenden (aus)");
        UiNavi::DrawKeyboardGlyph(kmin,
            ImVec2(kmin.x + gearK, kmin.y + gearK), kbAn);
    }
    g_tabsH = ImGui::GetWindowSize().y;
    ImGui::End();
    g_barH = (g_tabsH > gripH ? g_tabsH : gripH);
    // ALERT-LEISTE: faehrt UNMITTELBAR unter der Tab-Leiste herab, ueber
    // die volle Arbeitsflaechenbreite. [Bewusst KEIN Overlay -- die
    // zurueckgelieferte Hoehe fliesst unten in "topbar" ein, der
    // DockSpace weicht der Leiste also aus, statt von ihr verdeckt zu
    // werden. Gilt fuer JEDEN Alert einheitlich (Update-Hinweis,
    // Netzwerkfehler, was immer spaeter dazukommt) -- die Leiste selbst
    // weiss nichts von der Bedeutung ihrer Eintraege.]
    const float alertsH = UiAlertsZeichnen(vp->WorkPos.x, vp->WorkPos.y + g_tabsH,
                                           vp->WorkSize.x);
    g_barH += alertsH;   // Frei-Fenster-Klemme (weiter oben) beruecksichtigt sie mit
    // ---- SEITEN-EINSTELLUNGSFLAECHE (von oben, ohne Animation) ----
    if (g_pageSheet) {
        UiPage* pg = UiActivePage();
        if (!pg) g_pageSheet = false;
        else {
            ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x,
                                           vp->WorkPos.y + g_barH));
            ImGui::SetNextWindowSize(ImVec2(vp->WorkSize.x, 0));
            ImGui::Begin("##page_sheet", nullptr,
                ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove
                | ImGuiWindowFlags_AlwaysAutoResize
                | ImGuiWindowFlags_NoSavedSettings
                | ImGuiWindowFlags_NoDocking);
            bool tabsOk = ImGui::BeginTabBar("##pgsheet_tabs");
            bool pageTab = true;
            if (tabsOk) {
                if (ImGui::BeginTabItem("Globale Einstellungen")) {
                    // SCROLLMODUS -- wirkt auf die Gesten der ganzen App.
                    {
                        int modus = UiScrollPinpoint() ? 0 : 1;
                        ImGui::TextUnformatted("Scrollen");
                        if (ImGui::RadioButton("Pinpoint (Auslenkung = Geschwindigkeit)", modus == 0)) modus = 0;
                        if (ImGui::RadioButton("Normal (Inhalt folgt dem Finger)", modus == 1)) modus = 1;
                        // Nur den Wert setzen -- gespeichert wird ohnehin.
                        // [AppSettings::Save() hier zu rufen ging nicht:
                        //  app_settings.h bindet ui_pages.h ein, der
                        //  Rueckweg waere ein Zirkel ("AppSettings has
                        //  not been declared"). Noetig ist es auch nicht:
                        //  AppSettings::Periodic() schreibt alle drei
                        //  Sekunden den kompletten Stand, genau wie bei
                        //  allen anderen Einstellungen.]
                        UiScrollPinpoint() = (modus == 0);
                        if (modus == 0) {
                            bool ot = UiOneTapDockspace();
                            if (ImGui::Checkbox("Ein Tipp scrollt immer die Seite", &ot))
                                UiOneTapDockspace() = ot;
                            ImGui::SameLine(); ImGui::TextDisabled("(?)");
                            if (ImGui::IsItemHovered())
                                ImGui::SetTooltip("Doppeltipp: das Fenster unter dem Finger, sofort.\n"
                                                  "Halten: nach der Haltezeit das Fenster unter dem Finger.");
                            float hs = UiHoldSeconds();
                            ImGui::SetNextItemWidth(160.0f);
                            if (ImGui::SliderFloat("Haltezeit (s)", &hs, 0.3f, 2.0f, "%.1f"))
                                UiHoldSeconds() = hs;
                        }
                        ImGui::Separator();
                    }
                    {
                        bool zu = UiSheetCloseOnTab();
                        if (ImGui::Checkbox("Einstellungen beim Seitenwechsel schliessen", &zu))
                            UiSheetCloseOnTab() = zu;
                        ImGui::SameLine();
                        ImGui::TextDisabled("(?)");
                        if (ImGui::IsItemHovered())
                            ImGui::SetTooltip("Ein Klick auf ein Symbol in der Tab-Leiste\n"
                                              "schliesst dieses Blatt und die App-Einstellungen.");
                        ImGui::Separator();
                    }
                    // Inhalt der frueheren "Effekt-Einstellungen" --
                    // deren Fenster ist abgeschafft, hier ist ihr Ort.
                    EffectsGl_SettingsContent();
                    ImGui::EndTabItem();
                }
                pageTab = ImGui::BeginTabItem("Seiten-Einstellungen");
            }
            if (pageTab) {
            ImGui::Text("Seite: %s", pg->name.c_str());
            ImGui::Separator();
            {   // Dock-Kanten dieser Seite an die Navis kleben
                bool ch = false;
                ch |= ImGui::Checkbox("Dock-Kante links an Navi",
                                      &pg->stickL);
                ch |= ImGui::Checkbox("Dock-Kante rechts an Leiste",
                                      &pg->stickR);
                if (UiDockStickAll())
                    ImGui::TextDisabled("(globales Override aktiv)");
                if (ch && UiPagesPersistHook) UiPagesPersistHook();
            }
            ImGui::Separator();
            bool prev = pg->compact;
            ImGui::Checkbox("Kompakt-Layout dieser Seite", &pg->compact);
            if (pg->compact != prev) {
                bool now = pg->compact;
                pg->compact = prev;
                SavePageState(*pg, /*force=*/true);
                UiPagesPersist();
                pg->compact = now;   ApplyPageState(*pg);
            }
            ImGui::TextUnformatted("Fenster dieser Seite:");
            for (auto& n : pg->windows) {
                bool v = UiPropsFor(n.c_str()).fixHeight;
                std::string lbl = "Hoehe fixieren: " + n;
                if (ImGui::Checkbox(lbl.c_str(), &v)) {
                    UiWinProps& wpn = UiPropsFor(n.c_str());
                    wpn.fixHeight = v;
                    if (v) UiCaptureLockedH(UiPropsKey(n.c_str()));
                    wpn.adaptive = false; wpn.growStreak = 0;
                    wpn.streakFrame = -1; wpn.lastWant = -1.0f;
                    UiPagesPersist();
                }
            }
            // ZUSATZEINSTELLUNGEN DIESER SEITE (siehe UiPageSettingsExtras).
            {
                auto& extras = UiPageSettingsExtras();
                auto ex = extras.find(pg->name);
                if (ex != extras.end() && ex->second) {
                    ImGui::Separator();
                    ImGui::PushID("pgsheet_extras");
                    ex->second();
                    ImGui::PopID();
                }
            }
            if (tabsOk) ImGui::EndTabItem();
            }
            if (tabsOk) ImGui::EndTabBar();
            ImVec2 smin = ImGui::GetWindowPos();
            ImVec2 smax(smin.x + ImGui::GetWindowSize().x,
                        smin.y + ImGui::GetWindowSize().y);
            // VOR DIE NAVIGATION.
            // [Das Blatt lag hinter einer herausgefahrenen Navi, weil es
            //  nicht am Z-System teilnahm -- die Navis holen sich per
            //  ApplyZOrder nach vorn, das Blatt tat es nicht. Es traegt
            //  sich jetzt als ZElem::Settings ein; beim Oeffnen zaehlt es
            //  als "zuletzt angefasst" und liegt damit obenauf.]
            UiNavi::ZCollect(UiNavi::ZElem::Settings, ImGui::GetCurrentWindow());
            ImGui::End();
            // Klick irgendwo ANDERS (auch nicht aufs Zahnrad, das
            // togglet selbst) schliesst die Flaeche.
            if (ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
                ImVec2 mp = ImGui::GetIO().MousePos;
                bool inSheet = mp.x >= smin.x && mp.x <= smax.x
                            && mp.y >= smin.y && mp.y <= smax.y;
                bool inBar = mp.y < vp->WorkPos.y + g_barH;
                if (!inSheet && !inBar) g_pageSheet = false;
            }
        }
    }
    ImGui::XbmDockClampTopInset = g_barH;   // Bruecke zum Dock-Guides-Patch
    ImGui::XbmLayoutLocked =
        EffectsGl_Settings().lockLayout ? 1 : 0;

    // ---- SPERRZONE Leiste: KEIN Fenster darf ueber Griff/Tabs liegen ----
    // Jedes freie Fenster wird jeden Frame (auch WAEHREND des Ziehens und
    // beim Nach-oben-Vergroessern) unter die Leisten-Unterkante geklemmt.
    // Grund: Fenster ueber der Leiste verdecken die Navigation, und das
    // Herunterschieben von dort triggert Androids Von-oben-Wisch-Gesten
    // (Schnelleinstellungen) -- unkonform. Gedockte Fenster betrifft das
    // nicht (der Host beginnt ohnehin unterhalb der Leiste).
    {
        float barBottom = vp->WorkPos.y + g_barH;
        ImGuiContext* gc = ImGui::GetCurrentContext();
        for (ImGuiWindow* w : gc->Windows) {
            if (!w->WasActive || w->DockIsActive) continue;
            if (w->Flags & (ImGuiWindowFlags_ChildWindow
                            | ImGuiWindowFlags_Tooltip
                            | ImGuiWindowFlags_Popup)) continue;
            if (strncmp(w->Name, "##page_", 7) == 0) continue;
            if (strncmp(w->Name, "##drawer", 8) == 0) continue;
            if (strncmp(w->Name, "##nodegrab", 10) == 0) continue;
            if (strcmp(w->Name, "Navigation") == 0) continue;
            if (w->Pos.y < barBottom)
                ImGui::SetWindowPos(w, ImVec2(w->Pos.x, barBottom),
                                    ImGuiCond_Always);
        }
    }

    // ---- Kompakt-Host der aktiven Seite ----
    UiPage* pg = UiActivePage();
    if (!(pg && pg->compact)) return;
    // SEITENWECHSEL: kurz einschwingen lassen. [Beim Wechsel werden die
    //  Fenster der Seite nach einer Pause wieder gezeichnet; ihre Hoehen
    //  werden erst am Frame-Ende neu vermessen und durchgesetzt. Ohne das
    //  sah man in "Effekte" jedes Mal den Sprung. Zwei unsichtbare Frames
    //  (~33 ms) reichen; ein Neuaufbau setzt unten ohnehin 3.]
    // KEIN EINSCHWINGEN MEHR BEIM SEITENWECHSEL. [Die zwei unsichtbaren
    //  Frames WAREN das "einmal kurz aufflackern": zwei Frames lang stand
    //  die Seite leer da, dann sprang der Inhalt herein. Die Fensterhoehen
    //  stammen aus der letzten Vermessung und werden am Frame-Ende
    //  durchgesetzt -- ein sichtbarer erster Frame ist besser als ein
    //  leerer. Nur ein echter Neuaufbau (unten) bekommt noch EINEN Frame.]
    {
        static std::string s_letzteSeite;
        if (s_letzteSeite != pg->name) { s_letzteSeite = pg->name; if (ui_pages_detail::g_warmFrames < 2) ui_pages_detail::g_warmFrames = 2; }
    }
    // Sicherheitsnetz: ohne Docking-Flag sind saemtliche DockBuilder-
    // Operationen wirkungslos bis gefaehrlich (AddNode -> NULL). Frame
    // ueberspringen; needLayout/needRebuild bleiben stehen und greifen,
    // sobald das Flag wieder da ist.
    if (!(ImGui::GetIO().ConfigFlags & ImGuiConfigFlags_DockingEnable))
        return;

    float topbar = g_tabsH + 6.0f + alertsH;
    // KANTEN AN DIE NAVIS KLEBEN (pro Seite oder global): Der Host --
    // und damit DockSpace samt aller angedockten Fenster -- beginnt
    // rechts NEBEN der linken Navi und endet an der rechten Leiste.
    // Es zaehlt die ANIMIERTE Ist-Breite (openX): waehrend die Navi
    // auf- oder zufaehrt, gleitet die Dock-Kante fluessig mit.
    float hostX = vp->WorkPos.x;
    float hostW = vp->WorkSize.x;
    {
        bool sl = UiDockStickAll() || pg->stickL;
        bool sr = UiDockStickAll() || pg->stickR;
        if (sl) {
            float lw = UiNavi::Left().openX;
            hostX += lw; hostW -= lw;
        }
        if (sr) hostW -= UiNavi::Right().openX;
        if (hostW < 120.0f) hostW = 120.0f;
    }
    ImGui::SetNextWindowPos(ImVec2(hostX, vp->WorkPos.y + topbar));
    ImGui::SetNextWindowSize(ImVec2(hostW, vp->WorkSize.y - topbar));
    std::string hostName = std::string("##page_host_") + pg->name;
    // VOLLBILD-SEITE: Der Host darf gar nicht erst scrollen. Das ist
    // die Absicherung gegen jeden verbliebenen Rundungsrest -- passt
    // etwas doch nicht, wird es beschnitten statt scrollbar zu machen.
    // KEINE Scrollsperre mehr: Sobald ein Fenster UNTER dem Vollbild-
    // Fenster angedockt ist, muss die Seite sehr wohl scrollen koennen.
    ImGuiWindowFlags hostExtra = 0;
    // KOMPAKT-LAYOUT UNSICHTBAR: Der Host und die leere DockSpace-
    // Flaeche zeichnen KEINEN Hintergrund -- das Layout darf nicht
    // auffallen; sichtbar sind nur die Fenster selbst. (Das Durchklicken
    // regeln die Plattformpfade: GLFW_MOUSE_PASSTHROUGH auf Linux,
    // SetWindowRgn auf Windows, Android ist Vollflaechen-App.)
    ImGui::PushStyleColor(ImGuiCol_WindowBg,     ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_DockingEmptyBg, ImVec4(0, 0, 0, 0));
    ImGui::Begin(hostName.c_str(), nullptr, hostExtra |
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse
        | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove
        | ImGuiWindowFlags_NoSavedSettings
        | ImGuiWindowFlags_NoBringToFrontOnFocus
        | ImGuiWindowFlags_NoDocking
        // KEIN sichtbarer Scrollbalken am HOST: gescrollt wird per
        // Geste/Edge-Auto-Scroll (SetScrollY) -- der Balken hatte keine
        // Funktion, blitzte aber am rechten Rand auf, sobald der Inhalt
        // waechst und die Sichthoehe fuer einen Frame ueberschreitet
        // (genau der Effekt beim Tippen im Eingabe-Monitor).
        | ImGuiWindowFlags_NoScrollbar);

    // Tastaturhoehe abziehen: Das Systemfenster wird dank
    // adjustNothing NICHT mehr umskaliert (das war die Quelle des
    // Nachzieh-Ruckelns), die Oberflaeche zieht ihren nutzbaren Bereich
    // stattdessen selbst und WEICH nach (g_imeH ist gedaempft).
    // KEIN nochmaliger Abzug der Tastaturhoehe! main_android verkleinert
    // vp->WorkSize.y bereits um die (geglaettete) Tastaturhoehe. Der
    // fruehere zusaetzliche Abzug von g_imeH zog sie ein ZWEITES Mal ab:
    // dockH war damit um genau diese Hoehe kleiner als der sichtbare
    // Bereich, das Vollbild-Blatt rechnete aber mit dem sichtbaren
    // Bereich -- die Differenz blieb als scrollbarer Rest uebrig.
    float workH = vp->WorkSize.y;
    if (workH < 120.0f) workH = 120.0f;
    // HOEHE = INHALT, MINDESTENS ARBEITSFLAECHE: Das Kompakt-Layout-
    // Fenster passt sich der Groesse seines Inhalts an (g_pageExtra
    // waechst/schrumpft mit der Kaskade, s.u.) und ist nie kleiner als
    // die sichtbare Flaeche unter der Leiste. Der fruehere Fixfaktor
    // (0.45 * Fensterzahl) war beides nicht.
    static std::map<std::string, float> g_pageExtra;
    {   // Nutzerwert hat Vorrang (Bodengriff).
        auto itU = g_pageExtraUser.find(pg->name);
        if (itU != g_pageExtraUser.end()) g_pageExtra[pg->name] = itU->second;
    }
    float extraH = g_pageExtra[pg->name];
    float fitH   = workH - g_barH - 6.0f;      // exakt die Seitenhoehe
    float dockH  = fitH + extraH;
    // VOLLBILD: Die Seite ist genau so hoch wie der sichtbare Bereich --
    // WEDER der Zuschlag (g_pageExtra) NOCH das Bedarfswachstum
    // (needNow2 weiter unten) duerfen sie groesser machen. [Genau diese
    // beiden Quellen liessen die Seite trotz "passendem" Fenster noch
    // ein Stueck scrollen.]
    // (Kein Festnageln mehr: Ein Vollbild-Fenster ist genau so hoch wie
    //  der Viewport, der DockSpace darf trotzdem darueber hinauswachsen,
    //  sobald weitere Fenster darunter angedockt sind.)
    {
        // BEDARF SOFORT aus dem LEBENDEN Baum (nicht aus dem Wert vom
        // Vorframe): Die Durchsetzung laeuft am Frame-ENDE, dockH las
        // ihren Wert also immer eine Generation zu spaet. Am unteren
        // Anschlag hiess das: der Inhalt ist gewachsen, die Scroll-
        // Grenze kennt ihn noch nicht -- neue Zeilen blieben
        // unerreichbar abgeschnitten.
        // dockId wird erst weiter unten deklariert -- ID hier direkt
        // aus der Seite bilden (derselbe Helfer wie ueberall sonst).
        if (ImGuiDockNode* rtNow =
                ImGui::DockBuilderGetNode(PageDockId(*pg)))
            if (UiHasFixed(rtNow)) {
                float needNow2 = UiNeedY(rtNow, true);
                if (needNow2 > dockH) dockH = needNow2;
                g_pageNeed[pg->name] = needNow2;
            }
        auto itN = g_pageNeed.find(pg->name);
        if (itN != g_pageNeed.end() && itN->second > dockH)
            dockH = itN->second;   // Kompakt-Layout exakt so hoch wie
                                   // der Inhalt es verlangt -- nie mehr
    }
    // UNTERGRENZE = SICHTBARE FLAECHE unter der Leiste. [Frueher stand
    // hier workH * 1.25f: Der DockSpace wurde ZWANGSWEISE 25% hoeher als
    // der Bildschirm gemacht -- und weil die Blaetter eines Stapels die
    // Containerhoehe exakt aufsummieren muessen, wurde dieses Polster
    // komplett auf dem UNTERSTEN Fenster geparkt: das "riesige letzte
    // Fenster". Jetzt fuellt der Stapel genau den Schirm; braucht der
    // Inhalt mehr, waechst dockH ueber die Bedarfsrechnung (needNow2)
    // von selbst darueber hinaus und bleibt scrollbar.]
    {
        float minDockH = workH - g_barH - 6.0f;
        if (dockH < minDockH) dockH = minDockH;
    }
    ImGuiID dockId = PageDockId(*pg);

    // Grundstapel: nur wenn kein Baum existiert; wartet auf Fenster
    bool builtNow = false;
    // DROSSEL JE SEITE. [g_lastRebuild war global: hatte irgendeine
    //  Seite gerade neu aufgebaut, musste die naechste 300 ms warten --
    //  beim Tab-Wechsel sah man deshalb erst den alten, dann den neuen
    //  Zustand. Die eigene Seite darf sich weiterhin nicht im Sekundentakt
    //  neu bauen; eine andere Seite hat damit aber nichts zu tun.]
    if (pg->needLayout && ImGui::GetTime() - pg->lastRebuild > 0.3) {
        g_lastRebuild = pg->lastRebuild = ImGui::GetTime();
        RebuildFromLayout(pg->name, dockId, ImVec2(vp->WorkSize.x, dockH),
                          pg->windows);
        if (ImGui::DockBuilderGetNode(dockId)) {
            pg->needLayout = false;
            builtNow = true;
        }   // sonst: needLayout bleibt -> naechster Frame erneut
    }
    // ERSTSTART: ohne persistierte Layout-Records wuerden alle Fenster
    // im Wurzelknoten landen (= Tabs). Einmalig den vertikalen Aufbau
    // anfordern, damit sie untereinander stehen.
    {
        static std::map<std::string, bool> s_firstDone;
        if (!s_firstDone[pg->name] && g_layout[pg->name].empty()) {
            s_firstDone[pg->name] = true;
            pg->needRebuild = true;
        }
    }
    if (!builtNow && pg->needRebuild
        && ImGui::GetTime() - pg->lastRebuild > 0.3) {
        // ALLE REGISTRIERTEN FENSTER, NICHT NUR DIE SCHON GEZEICHNETEN.
        // [Hier stand "nur, was FindWindowByName findet". Beim ERSTEN
        //  Anzeigen einer Seite gibt es die Fenster noch nicht: der Aufbau
        //  fand nichts, die Fenster erschienen frei schwebend in 300x260,
        //  und der naechste Versuch kam erst nach der 300-ms-Drossel --
        //  dann sprangen sie ins Dock. Genau das war das Ruckeln beim
        //  ersten Tab-Wechsel. DockBuilderDockWindow braucht das Fenster
        //  nicht: es merkt sich die Zuordnung am Namen, und Begin() dockt
        //  beim ersten Aufruf sofort ein -- noch im selben Frame, weil die
        //  Fenster NACH UiPagesFrame() gezeichnet werden.]
        std::vector<std::string> present;
        for (const auto& nm : pg->windows) {
            if (UserFreed(pg->name, nm)) continue;     // freigestellte auslassen
            // Geschlossene auslassen: sie bekaemen einen leeren Knoten, den
            // ImGui im Folgeframe entfernt -- ein weiteres Neulayout.
            if (!UiWinOpen(ui_pages_detail::UiPropsKey(nm.c_str()))) continue;
            present.push_back(nm);
        }
        // ERSTSTART-REIHENFOLGE (untereinander, nicht in Tabs):
        // "Effekt-Einstellungen" immer ZUERST, "Eingabe-Monitor" immer
        // ZULETZT; alles andere behaelt seine Registrierungsfolge.
        {
            std::stable_sort(present.begin(), present.end(),
                [](const std::string& a, const std::string& b) {
                    auto rank = [](const std::string& n) {
                        if (n.rfind("Effekt-Einstellungen", 0) == 0)
                            return 0;
                        if (n.rfind("Eingabe-Monitor", 0) == 0) return 2;
                        return 1;
                    };
                    return rank(a) < rank(b);
                });
        }
        if (!present.empty()) {
            g_lastRebuild = pg->lastRebuild = ImGui::GetTime();
            pg->needRebuild = false;
            ImGui::DockBuilderRemoveNode(dockId);
            ImGui::DockBuilderAddNode(dockId, ImGuiDockNodeFlags_DockSpace);
            if (ImGui::DockBuilderGetNode(dockId) == nullptr) {
                pg->needRebuild = true;   // null-sicher: naechster Versuch
            } else {
            ImGui::DockBuilderSetNodeSize(dockId,
                ImVec2(vp->WorkSize.x, dockH));
            ImGuiID rest = dockId;
            int n = (int)present.size();
            for (int i = 0; i < n; ++i) {
                if (i == n - 1) {
                    ImGui::DockBuilderDockWindow(present[i].c_str(), rest);
                } else {
                    ImGuiID top = 0, bottom = 0;
                    ImGui::DockBuilderSplitNode(rest, ImGuiDir_Up,
                        1.0f / (float)(n - i), &top, &bottom);
                    ImGui::DockBuilderDockWindow(present[i].c_str(), top);
                    rest = bottom;
                }
            }
            ImGui::DockBuilderFinish(dockId);
            builtNow = true;
            }   // else: AddNode lieferte einen Knoten (null-sicherer Pfad)
        }
    }

    // NACH EINEM AUFBAU EINSCHWINGEN LASSEN (siehe UiPage::settle) --
    // ein einziger Frame, mehr sieht man als Flackern.
    if (builtNow) { pg->settle = 0; if (ui_pages_detail::g_warmFrames < 2) ui_pages_detail::g_warmFrames = 2; }

    // AM BODEN MITWANDERN: Stand die Ansicht am unteren Anschlag,
    // bleibt sie dort, wenn der Inhalt waechst -- sonst "haengt" der
    // Blick oberhalb der neuen Zeilen fest.
    {
        ImGuiWindow* hw2 = ImGui::GetCurrentWindow();
        static std::map<std::string, bool>  s_atBottom;
        static std::map<std::string, float> s_lastMax;
        bool  wasBottom = s_atBottom[pg->name];
        float maxNow    = hw2->ScrollMax.y;
        float grew      = maxNow - s_lastMax[pg->name];
        // NUR bei echtem Zuwachs (>1px) und NICHT waehrend einer Geste
        // nachfuehren -- und dann nur um den Zuwachs, statt hart auf das
        // Maximum zu springen. Das harte Setzen jeden Frame kaempfte mit
        // der minimal schwankenden Hoehe: sichtbares Wackeln.
        if (wasBottom && grew > 1.0f && !ImGui::GetIO().MouseDown[0])
            ImGui::SetScrollY(hw2, hw2->Scroll.y + grew);
        s_lastMax[pg->name] = maxNow;
        s_atBottom[pg->name] =
            (maxNow <= 0.5f) || (hw2->Scroll.y >= maxNow - 2.0f);
    }
    // GANZE PIXEL: Subpixel-Schwankungen der Hoehe (Rundung in der
    // Bedarfsrechnung) veraendern ScrollMax minimal in JEDEM Frame --
    // am unteren Anschlag wurde das als Wackeln des ganzen Kompakt-
    // Layouts sichtbar.
    dockH = floorf(dockH);
    // HYSTERESE gegen Rest-Schwingen: Die Hoehe darf zwischen zwei
    // benachbarten Werten pendeln (jede Aenderung erzeugt im Folgeframe
    // die Bedingung fuer die Gegenaenderung) -- sichtbar als langsameres
    // Wackeln. Ein neuer Wert wird daher nur uebernommen, wenn er sich
    // DEUTLICH unterscheidet (>3px) ODER mehrere Frames stabil anliegt.
    {
        static std::map<std::string, float> s_heldH;
        static std::map<std::string, float> s_candH;
        static std::map<std::string, int>   s_candN;
        float held = s_heldH.count(pg->name) ? s_heldH[pg->name] : dockH;
        // WAEHREND eines Grenz-Zugs (Fenster im DockSpace skalieren)
        // ist die Hysterese AUS. [Sie war die Ursache der Asymmetrie:
        // Nach UNTEN waechst der Bedarf -- dockH wollte sofort mit,
        // wurde aber gehalten, weil sich der Kandidat unter dem
        // wandernden Finger nie 8 Frames stabilisierte: der Zug fuehlte
        // sich zaeh an. Nach OBEN schrumpft der Bedarf, die gehaltene
        // (zu grosse) Hoehe blieb stehen, es gab keinerlei Gegendruck
        // und die Verteilung schoss durch: "fast exponentiell".]
        if (UiSplitterGrabActive()) {
            s_heldH[pg->name] = dockH;
            s_candN[pg->name] = 0;
            held = dockH;
        }
        // Schwelle DEUTLICH ueber der beobachteten Schwingung (Log:
        // 2755/2743/2731, Amplitude 24): Mit 3px lag sie darunter, also
        // wurde JEDER Zyklusschritt als "echter Sprung" uebernommen und
        // die Hysterese war wirkungslos.
        if (fabsf(dockH - held) > 48.0f) {
            held = dockH;                       // echter Sprung
            s_candN[pg->name] = 0;
        } else if (fabsf(dockH - held) > 0.5f) {
            if (fabsf(dockH - s_candH[pg->name]) <= 0.5f) {
                if (++s_candN[pg->name] >= 8) { // 8 Frames stabil
                    held = dockH;
                    s_candN[pg->name] = 0;
                }
            } else {
                s_candH[pg->name] = dockH;
                s_candN[pg->name] = 1;
            }
        } else {
            s_candN[pg->name] = 0;
        }
        if (fabsf(held - (s_heldH.count(pg->name) ? s_heldH[pg->name]
                                                   : held)) > 0.5f)
            UIP_LOGF("C[%s]: dockH -> %.0f", pg->name.c_str(), held);
        s_heldH[pg->name] = held;
        dockH = held;
    }
    g_activeDockId = dockId;
    ImGuiDockNodeFlags dsFlags = ImGuiDockNodeFlags_None;
    // KEIN FENSTERMENUE-KNOPF in den Tab-Leisten der Dock-Knoten.
    // [Das ist der kleine Pfeil links, dessen Menue nur "Hide tab bar"
    //  anbietet -- nie gebraucht, aber er nimmt Platz und faengt Tipps
    //  ab. Das Flag vererbt sich vom DockSpace auf alle Knoten darin.]
    dsFlags |= ImGuiDockNodeFlags_NoWindowMenuButton;
    if (EffectsGl_Settings().lockLayout)
        dsFlags |= ImGuiDockNodeFlags_NoResize
                 | ImGuiDockNodeFlags_NoSplit;
    {
        // GRUNDMASS IST IMMER DER GEMESSENE PLATZ -- fuer JEDE Seite,
        // nicht nur fuer Vollbild-Seiten. [Die Rechnung aus der
        // Viewport-Hoehe (fitH) lag um Fensterrand und Leistendifferenz
        // darueber; deshalb war der DockSpace selbst dann ein paar
        // Pixel zu hoch und scrollbar, wenn ueberhaupt kein Fenster
        // darin stand.]
        //
        // Was ueber dem Grundmass angefordert wurde -- Bodengriff
        // (g_pageExtra) oder echter Platzbedarf gestapelter Fenster
        // (needNow2) -- bleibt als ZUSCHLAG erhalten. Nur so scrollt die
        // Seite weiterhin, wenn wirklich mehr Inhalt da ist.
        float avail = ImGui::GetContentRegionAvail().y;
        if (avail > 1.0f) {
            UiPageViewportH() = avail;          // Mass fuer Vollbild
            float over = dockH - fitH;          // angeforderter Zuschlag
            if (over < 0.0f) over = 0.0f;
            // AUCH bei Vollbild: Haengt ein weiteres Fenster darunter,
            // meldet die Bedarfsrechnung dessen Hoehe als Zuschlag --
            // der DockSpace waechst und die Seite wird scrollbar. Das
            // Vollbild-Fenster selbst behaelt dabei exakt 'avail'.
            dockH = avail + over;
        }
    }
    ImVec2 dsTopLeft = ImGui::GetCursorScreenPos();
    // --- FENSTERPALETTE IN navi1 ANMELDEN (einmal) --------------------
    // [ui_navi.h kennt die Seitenverwaltung nicht -- wir reichen ihr drei
    //  Haken: was fehlt, wie man es oeffnet, wie sein Symbol aussieht.]
    {
        static bool angemeldet = false;
        if (!angemeldet) {
            angemeldet = true;
            UiNavi::WinPaletteQuelle() = []() {
                std::vector<UiNavi::WinPaletteEintrag> aus;
                UiPage* p = UiActivePage();
                if (!p) return aus;
                for (const auto& nm : p->windows) {
                    // DER SCHALTER IST DER MASSSTAB, NICHT "WasActive".
                    // [Vorher: !w || !w->WasActive. Ein gerade geoeffnetes
                    //  Fenster ist im SELBEN Frame noch nicht gezeichnet
                    //  -- es blieb also in der Liste stehen, obwohl es
                    //  schon da war. Und ein Fenster, das ImGui aus
                    //  anderen Gruenden einen Frame auslaesst (Tab nicht
                    //  vorn, Knoten eingeklappt), tauchte fehlerhaft auf.
                    //  UiWinOpen ist der Zustand, den auch UiPageWindow
                    //  liest: eine Wahrheit, kein Ratespiel.]
                    // ZWEI WEGE ZUM "GESCHLOSSEN".
                    // [UiWinOpen deckt alles ab, was ueber unser X oder
                    //  das Menue geht. Manche Fenster haben aber ein
                    //  EIGENES Sichtbarkeits-Flag (der Eingabe-Monitor
                    //  etwa: static bool showInputDbg) -- wird es ueber
                    //  ImGuis natives X ausgeschaltet, bleibt UiWinOpen
                    //  true, und die Palette hielt das Fenster fuer
                    //  offen. Deshalb zusaetzlich: wird es seit mehreren
                    //  Frames nicht gezeichnet, ist es weg -- egal
                    //  welcher Weg es geschlossen hat.
                    //  Mehrere Frames, weil ein Fenster auch mal einen
                    //  Frame auslaesst (Tab nicht vorn, Knoten neu
                    //  aufgebaut) -- ein einzelner Frame waere zu
                    //  nervoes.]
                    bool zu = !UiWinOpen(nm);
                    if (!zu) {
                        static std::map<std::string, int> stumm;
                        ImGuiWindow* w = ImGui::FindWindowByName(nm.c_str());
                        if (!w) {
                            std::string sc = nm + "##" + p->name;
                            w = ImGui::FindWindowByName(sc.c_str());
                        }
                        int& n = stumm[nm];
                        if (w && w->WasActive) n = 0; else if (n < 100) ++n;
                        if (n > 3) zu = true;
                    }
                    if (zu) aus.push_back({nm});
                }
                return aus;
            };
            UiNavi::WinPaletteOeffnen() = [](const std::string& nm) {
                UiPage* p = UiActivePage();
                if (!p) return;
                // SCHALTER SOFORT SETZEN -- nicht nur wuenschen.
                // [Als Wunsch wirkte es erst, wenn UiPageWindow(nm) das
                //  naechste Mal lief. Bis dahin stand der Eintrag noch in
                //  der Palette und das Fenster war noch nicht da: ein
                //  Frame mit falschem Bild. Der Wunsch bleibt zusaetzlich
                //  drin, damit Zeichenstellen mit eigenem Flag (Android)
                //  ihn ebenfalls bekommen.]
                UiWinOpen(nm) = true;
                UiOpenRequests().push_back(nm);
                UserFreeSet(p->name, nm, false);   // wieder ins Layout
                p->needLayout = true;
            };
            UiNavi::WinPaletteGlyph() = [](const std::string& nm, ImVec2 a,
                                           ImVec2 b, ImU32 col) {
                DrawPageGlyph(nm, a, b, col);
            };
        }
    }

    ImVec2 dsMin = ImGui::GetCursorScreenPos();
    ImGui::DockSpace(dockId, ImVec2(0, dockH), dsFlags);
    // FALLENLASSEN AUS navi1 -- OHNE BeginDragDropTarget.
    // [Das war der Fehler: BeginDragDropTarget() bezieht sich auf das
    //  LETZTE ITEM, und ImGui::DockSpace() ist keines. Das Ziel wurde
    //  also nie angemeldet, und das Ziehen aus der Navi lief ins Leere.
    //  Die Nutzlast laesst sich aber direkt aus dem Zustand lesen: liegt
    //  eine XBM_WIN-Nutzlast vor und die Maus im DockSpace-Rechteck, ist
    //  das unser Fall -- unabhaengig von ImGuis Item-Kette.]
    {
        ImVec2 dsMax(dsMin.x + ImGui::GetContentRegionAvail().x,
                     dsMin.y + dockH);
        // Der Zug kommt aus der Palette und wird DORT gefuehrt -- hier
        // nur das Ablegen. [Kein ImGui-DragDrop mehr; siehe ui_navi.h.]
        UiNavi::WinZug& zug = UiNavi::WinPaletteZug();
        const ImVec2 mp = ImGui::GetIO().MousePos;
        bool drin  = mp.x >= dsMin.x && mp.x <= dsMax.x
                  && mp.y >= dsMin.y && mp.y <= dsMax.y;
        if (zug.aktiv && !zug.name.empty() && drin) {
            ImDrawList* fdl = ImGui::GetForegroundDrawList();
            fdl->AddRect(dsMin, dsMax, IM_COL32(255, 255, 255, 180), 4.0f, 0, 2.0f);
            const char* txt = "hier ablegen = oeffnen";
            ImVec2 ts = ImGui::CalcTextSize(txt);
            fdl->AddText(ImVec2((dsMin.x + dsMax.x) * 0.5f - ts.x * 0.5f,
                                dsMin.y + 10.0f),
                         IM_COL32(255, 255, 255, 220), txt);
            if (ImGui::IsMouseReleased(ImGuiMouseButton_Left)) {
                if (UiNavi::WinPaletteOeffnen())
                    UiNavi::WinPaletteOeffnen()(zug.name);
                zug.aktiv = false; zug.name.clear();
                UiDragHandledThisFrame() = true;
            }
        }
        // Losgelassen, egal wo: Zug beenden.
        if (zug.aktiv && !ImGui::GetIO().MouseDown[0]) {
            zug.aktiv = false; zug.name.clear();
        }
    }
    {
        // ZIEHKANTE UNTEN: Der DockSpace hat unten keinen Splitter --
        // das letzte Fenster bzw. der letzte Zusammenschluss liess sich
        // daher nach unten nicht skalieren. Dieser Griff verlaengert
        // den DockSpace SELBST (g_pageExtra): der Stapel waechst nach
        // unten, die DockPage zieht mit und bleibt scrollbar.
        // GROSSZUEGIG (32px) und NICHT am Systemrand: Liegt die
        // DockSpace-Unterkante nahe am unteren Bildschirmrand, wandert
        // der Griff nach OBEN in den Inhalt -- dort trifft man ihn,
        // ohne Androids Gestenzone am Rand auszuloesen.
        // KEIN Extra-Abstand mehr: Der Griff liegt vollstaendig
        // INNERHALB des DockSpace (Unterkante buendig) und wird auch
        // nicht mehr nach oben gezogen. [Vorher sass er mittig AUF der
        // Kante und wurde bis zu 96px hochgeschoben -- beides ragte
        // unter den DockSpace und blaehte den Seiteninhalt auf: genau
        // der Abstand, der unten uebrig blieb. Der Cursor wird nach dem
        // Griff wieder auf die Kante gesetzt, damit er dem Fenster
        // keine zusaetzliche Hoehe meldet.]
        const float gripH = 24.0f;
        float edgeY  = dsTopLeft.y + dockH;
        ImVec2 gmin(dsTopLeft.x, edgeY - gripH);
        ImVec2 gmax(dsTopLeft.x + ImGui::GetContentRegionAvail().x,
                    edgeY);
        // NICHT die aktuelle Cursorposition merken! Nach dem DockSpace
        // steht der Cursor bereits um ItemSpacing.y TIEFER als dessen
        // Unterkante. Ein Element an dieser Stelle (unser Dummy weiter
        // unten) verlaengert den Fensterinhalt um genau diesen Abstand
        // -- das waren die letzten "paar Pixel zu viel", die den
        // DockSpace scrollen liessen. Wir kehren stattdessen exakt zur
        // DockSpace-Unterkante zurueck.
        ImVec2 curKeep(dsTopLeft.x, edgeY);
        ImGui::SetCursorScreenPos(gmin);
        ImGui::InvisibleButton("##dockspace_bottom_grip",
                               ImVec2(gmax.x - gmin.x, gripH));
        bool act = ImGui::IsItemActive();
        if (ImGui::IsItemHovered() || act) {
            ImGui::SetMouseCursor(ImGuiMouseCursor_ResizeNS);
            ImU32 c = ImGui::GetColorU32(act ? ImGuiCol_SeparatorActive
                                             : ImGuiCol_SeparatorHovered);
            ImGui::GetWindowDrawList()->AddRectFilled(
                ImVec2(gmin.x, gmin.y + gripH * 0.35f),
                ImVec2(gmax.x, gmin.y + gripH * 0.65f), c, 2.0f);
        }
        // Cursor zurueck auf die DockSpace-Kante. ImGui verlangt nach
        // einem SetCursor* ein abgeschicktes Element, sonst kann es die
        // Ausdehnung des Fensters nicht bestaetigen ("Please submit an
        // item e.g. Dummy()"). Ein Dummy der Groesse 0 tut genau das,
        // ohne Platz zu verbrauchen.
        ImGui::SetCursorScreenPos(curKeep);
        ImGui::Dummy(ImVec2(0.0f, 0.0f));
        if (act) {
            UiSplitterGrabActive() = true;   // Pinpoint haelt sich raus
            float d = ImGui::GetIO().MouseDelta.y;
            if (d != 0.0f) {
                float e = g_pageExtra[pg->name] + d;
                if (e < 0.0f) e = 0.0f;
                g_pageExtra[pg->name]     = e;
                g_pageExtraUser[pg->name] = e;   // gilt ab jetzt fest
            }
        }
    }
    if (ImGuiDockNode* rootN2 = ImGui::DockBuilderGetNode(dockId)) {
        if (rootN2->IsCentralNode())
            rootN2->SetLocalFlags(rootN2->LocalFlags
                                  & ~ImGuiDockNodeFlags_CentralNode);
        UiFreezeStaticSplitters(rootN2);   // kein Griff, kein Zucken
    }
    // EDGE-AUTO-SCROLL beim DOCK-DRAG: Waehrend ein Fenster/Tab als
    // Payload gezogen wird, scrollt der Host automatisch, sobald der
    // Finger sich dem oberen/unteren Bildschirmrand naehert -- so werden
    // auch Dock-Ziele erreichbar, die komplett ausserhalb des sichtbaren
    // Bereichs liegen (Komplement zur Anker-Klemmung im ImGui-Patch).
    {
        ImGuiContext* gc = ImGui::GetCurrentContext();
        // Auch bei einfachem Ziehen IM Kompakt-Layout: Die Automatik
        // gehoert genauso in die Kompakt-Box wie in die Fenster darin --
        // Kanten sind hier die des Hosts selbst.
        // Laeuft in einem Fenster/einer Liste bereits ein Edge-Auto-
        // Scroll, bleibt der Host still -- sonst scrollen zwei Ebenen
        // gleichzeitig.
        // Einfaches Ziehen behandelt jetzt die globale Pin-Point-
        // Regelung (sie erreicht den Host ueber die Kette). Hier bleibt
        // nur die Automatik fuer DOCK-DRAG und SPLITTER-Griff.
        bool plainDrag = false;
        if ((gc->DragDropActive || UiSplitterGrabActive() || plainDrag)
            && ImGui::GetIO().MouseDown[0]) {
            ImGuiWindow* hw = ImGui::GetCurrentWindow();
            if (hw->ScrollMax.y > 0.5f) {
                // Eigene Kanten des Hosts (nicht der Bildschirm), Zone
                // wie ueberall 18% (24..90px), zeitbasiertes Tempo.
                float top = hw->InnerRect.Min.y;
                float bot = hw->InnerRect.Max.y;
                {   // an den sichtbaren Bereich klemmen
                    float vT = vp->WorkPos.y + g_barH;
                    float vB = vp->WorkPos.y + vp->WorkSize.y;
                    if (top < vT) top = vT;
                    if (bot > vB) bot = vB;
                    if (bot - top < 80.0f) { top = vT; bot = vB; }
                }
                float zone = (bot - top) * 0.45f;
                if (zone > 380.0f) zone = 380.0f;
                if (zone < 140.0f) zone = 140.0f;
                float my = ImGui::GetIO().MousePos.y;
                float v = 0.0f;
                if (my > bot - zone)      v =  (my - (bot - zone)) / zone;
                else if (my < top + zone) v = -((top + zone) - my) / zone;
                if (v >  1.0f) v =  1.0f;
                if (v < -1.0f) v = -1.0f;
                // Beim reinen Ziehen nur, wenn der Finger ruht oder die
                // Kante ueberschreitet (sonst ueberlagert es die Geste).
                if (plainDrag && !gc->DragDropActive
                    && !UiSplitterGrabActive()) {
                    // sofort aktiv, ohne Wartezeit
                }
                // Dock-Drag/Splitter: Blickrichtung folgt dem Finger
                // (nach unten ziehen = weiter nach unten schauen).
                // Reines Ziehen: Inhalt folgt dem Finger -> umgekehrt.
                float sgn = (gc->DragDropActive || UiSplitterGrabActive())
                          ? 1.0f : -1.0f;
                float mulH = UiEdgeSpeedMul(ImGui::GetIO().MousePos.x,
                                           hw->InnerRect.Min.x,
                                           hw->InnerRect.Max.x);
                float sp = sgn * (v < 0.0f ? -1.0f : 1.0f) * v * v
                         * 2600.0f * mulH * ImGui::GetIO().DeltaTime;
                if (sp != 0.0f)
                    ImGui::SetScrollY(hw, hw->Scroll.y + sp);
            }
        }
    }
    // WICHTIG -- NACH DockSpace(): DockSpace fuehrt Layoutrechnung UND
    // Splitter aus; liefe die Kaskade davor, wuerde ImGui unsere
    // Verteilung im selben Frame ueberschreiben (genau das machte alle
    // bisherigen Kaskaden-Fassungen unsichtbar). Post-Layout gewinnt
    // den Frame; SizeRef traegt in den naechsten.
    // "Resize Affects Neighbors" (KASKADE): Beim Ziehen eines Splitters
    // folgt die Grenze dem Finger; erreicht die gequetschte Seite ihr
    // Minimum, wird der Ueberschuss REKURSIV weitergegeben -- die
    // dahinterliegenden Fenster verschieben sich mit (in beide
    // Richtungen, fuer beide Achsen). Erst am Container-Ende
    // komprimieren die letzten Fenster bis zur Mindestgroesse.
    // Mechanik: pro Frame wird gemessen, wie viel der Fingerbewegung
    // ImGui NICHT anwenden konnte (Klemm-Ueberschuss); genau dieser
    // Betrag wird ueber Size/SizeRef der DockNodes in die Kette
    // gedrueckt. Ohne Checkbox: Original-Verhalten (Splitter stoppt).
    {
        // Griff-ERKENNUNG laeuft IMMER (unabhaengig von der Checkbox):
        // Der Dock-Splitter laeuft NICHT im Host-Fensterkontext (Befund
        // Sonde A) -- die 12-px-Scroll-Uebernahme hielt ihn daher fuer
        // ein gewoehnliches Item im Inhaltsbereich und erschoss ihn per
        // ClearActiveID nach 12 Pixeln: Grenze kurz beweglich, dann
        // FEST, Checkbox scheinbar wirkungslos. Der Griff-Zustand
        // versiegelt Scroll UND Uebernahme; die Checkbox entscheidet
        // nur noch, WER faehrt: aus = ImGuis nativer Splitter
        // (unangetastet), an = unsere Kaskade.
        bool cascadeOn = EffectsGl_Settings().resizeAffectsNeighbors
                      && !EffectsGl_Settings().lockLayout;
        // LAYOUT GESPERRT -> Grenzen sind funktionslos und sollen sich
        // wie normaler Hintergrund verhalten: Die geometrische Griff-
        // ERKENNUNG (die sonst unabhaengig von der Checkbox laeuft und
        // den Scroll versiegelt) wird komplett uebersprungen, damit die
        // Beruehrung ungehindert an die Scroll-Geste geht.
        if (EffectsGl_Settings().lockLayout) UiSplitterGrabActive() = false;
        if (!EffectsGl_Settings().lockLayout) {
        ImGuiContext* gg = ImGui::GetCurrentContext();
        ImGuiWindow* hostW = ImGui::GetCurrentWindow();
        static ImGuiID sNode = 0; static int sAxis = 0;
        static ImGuiID s0Id = 0, s1Id = 0;
        static ImGuiID runRootId = 0;   // oberster gleichachsiger Vorfahr
        static float grabMouse = 0.0f;
        static float grabScrollY = 0.0f;   // Host-Scroll beim Griff
        static bool  grabEngaged = false;   // erst nach echter Bewegung
        static float prevFirst = 0.0f; static bool wasActive = false;
        // ERKENNUNG REIN GEOMETRISCH (Diagnose ergab: Sonde A feuerte,
        // B nie -> die Bedingung ActiveIdWindow==hostW trifft NIE zu,
        // weil ImGui den Dock-Splitter nicht im Kontext des Host-
        // Fensters fuehrt; die gesamte Kaskade sprang daher nie an).
        // Jetzt unabhaengig von ImGuis ActiveId-Eigentuemerschaft:
        // Beim Druck wird geprueft, ob der Druckpunkt nahe an einer
        // Splitter-Grenze UNSERES Baums liegt -- dann gehoert die Geste
        // der Kaskade. Fenster-Moves und Drag&Drop bleiben ausgenommen.
        bool interacting = ImGui::GetIO().MouseDown[0]
                        && !gg->MovingWindow && !gg->DragDropActive;
        bool splitterDrag = interacting && sNode != 0;
        {   // Sonde A: Zustand einmal pro Druck protokollieren
            static bool loggedPress = false;
            if (ImGui::GetIO().MouseDown[0] && !loggedPress) {
                loggedPress = true;
                UIP_LOGF("Kaskade A: down aid=%u aidWin=%s host=%s",
                        gg->ActiveId,
                        gg->ActiveIdWindow ? gg->ActiveIdWindow->Name : "-",
                        hostW ? hostW->Name : "-");
            }
            if (!ImGui::GetIO().MouseDown[0]) loggedPress = false;
        }

        struct C {
            static float Min(ImGuiDockNode* n, int ax) {
                float m = (ax == 0)
                    ? ImGui::GetStyle().WindowMinSize.x
                    : ImGui::GetStyle().WindowMinSize.y;
                if (!n->ChildNodes[0]) {
                    // Hoehenfixiert: Min = Ist-Hoehe -> inkompressibel,
                    // wird von der Treppe sofort DURCHGESCHOBEN.
                    if (ax == 1 && NodeHeightFixed(n))
                        return (&n->Size.x)[1];
                    return m;
                }
                float a = Min(n->ChildNodes[0], ax);
                float b = Min(n->ChildNodes[1], ax);
                int nax = (n->SplitAxis == ImGuiAxis_X) ? 0 : 1;
                return (nax == ax) ? a + b : (a > b ? a : b);
            }
            static void Set(ImGuiDockNode* n, int ax, float v) {
                (&n->Size.x)[ax] = v; (&n->SizeRef.x)[ax] = v;
            }
            // Reduziert die Ausdehnung von n entlang ax um bis zu amt;
            // nearFirst: die dem bewegten Splitter zugewandte Seite
            // zuerst quetschen (dadurch "verschieben" sich die Fenster,
            // statt gleichmaessig zu schrumpfen).
            // Eigenstaendige Ersetzung fuer das in diesem ImGui-Stand
            // nicht oeffentliche DockNodeTreeUpdatePosSize: setzt
            // Pos/Groesse eines Einheiten-Knotens und fuehrt INNERHALB
            // der Einheit die Kinder proportional zu ihren SizeRefs mit
            // (deren Innenleben verwalten wir bewusst nicht selbst).
            static void PlaceTree(ImGuiDockNode* nd, ImVec2 pos,
                                  ImVec2 size) {
                nd->Pos = pos; nd->Size = size; nd->SizeRef = size;
                if (!nd->ChildNodes[0] || !nd->ChildNodes[1]) return;
                int ax = (nd->SplitAxis == ImGuiAxis_X) ? 0 : 1;
                float total = (&size.x)[ax];
                float a0 = (&nd->ChildNodes[0]->SizeRef.x)[ax];
                float a1 = (&nd->ChildNodes[1]->SizeRef.x)[ax];
                float sum = a0 + a1;
                float s0 = (sum > 1.0f) ? total * (a0 / sum)
                                        : total * 0.5f;
                ImVec2 sz0 = size, sz1 = size, p1 = pos;
                (&sz0.x)[ax] = s0;
                (&sz1.x)[ax] = total - s0;
                (&p1.x)[ax] += s0;
                PlaceTree(nd->ChildNodes[0], pos, sz0);
                PlaceTree(nd->ChildNodes[1], p1,  sz1);
            }

            // Zwischensummen der Kette nach der Einheiten-Verteilung
            // konsistent nachziehen, damit ImGuis Ratio-Layout im
            // Folgeframe exakt die Zielgroessen reproduziert.
            static float FixSums(ImGuiDockNode* n, int ax) {
                if (!n) return 0.0f;
                int nax = (n->SplitAxis == ImGuiAxis_X) ? 0 : 1;
                if (!n->ChildNodes[0] || nax != ax)
                    return (&n->Size.x)[ax];
                float a = FixSums(n->ChildNodes[0], ax);
                float b = FixSums(n->ChildNodes[1], ax);
                Set(n, ax, a + b);
                return a + b;
            }
            static float Squeeze(ImGuiDockNode* n, int ax, float amt,
                                 bool nearFirst) {
                float can = (&n->Size.x)[ax] - Min(n, ax);
                float take = amt < can ? amt : can;
                if (take <= 0.0f) return 0.0f;
                if (!n->ChildNodes[0]) {
                    Set(n, ax, (&n->Size.x)[ax] - take);
                    return take;
                }
                int nax = (n->SplitAxis == ImGuiAxis_X) ? 0 : 1;
                if (nax == ax) {
                    ImGuiDockNode* a = nearFirst ? n->ChildNodes[0]
                                                 : n->ChildNodes[1];
                    ImGuiDockNode* b = nearFirst ? n->ChildNodes[1]
                                                 : n->ChildNodes[0];
                    float t = Squeeze(a, ax, take, nearFirst);
                    if (t < take) t += Squeeze(b, ax, take - t, nearFirst);
                    Set(n, ax, (&n->Size.x)[ax] - t);
                    return t;
                }
                // Quer-Split: beide Kinder teilen die Ausdehnung
                Squeeze(n->ChildNodes[0], ax, take, nearFirst);
                Squeeze(n->ChildNodes[1], ax, take, nearFirst);
                Set(n, ax, (&n->Size.x)[ax] - take);
                return take;
            }
            static void Grow(ImGuiDockNode* n, int ax, float amt,
                             bool nearFirst) {
                Set(n, ax, (&n->Size.x)[ax] + amt);
                if (!n->ChildNodes[0]) return;
                int nax = (n->SplitAxis == ImGuiAxis_X) ? 0 : 1;
                if (nax == ax) {
                    ImGuiDockNode* g1 = nearFirst ? n->ChildNodes[1]
                                                  : n->ChildNodes[0];
                    ImGuiDockNode* g2 = nearFirst ? n->ChildNodes[0]
                                                  : n->ChildNodes[1];
                    // Hoehenfixierte wachsen nie -- Wachstum eine Stufe
                    // weiterreichen.
                    if (ax == 1 && NodeHeightFixed(g1)) g1 = g2;
                    Grow(g1, ax, amt, nearFirst);
                }
                else {
                    Grow(n->ChildNodes[0], ax, amt, nearFirst);
                    Grow(n->ChildNodes[1], ax, amt, nearFirst);
                }
            }
            static ImGuiDockNode* Nearest(ImGuiDockNode* n, ImVec2 mp,
                                          float& best,
                                          int wantAxis = -1) {
                if (!n || !n->ChildNodes[0]) return nullptr;
                int ax = (n->SplitAxis == ImGuiAxis_X) ? 0 : 1;
                int cx = 1 - ax;              // Querachse
                // Der Druckpunkt muss IM Knoten liegen und quer zur
                // Splitter-Achse innerhalb seiner Ausdehnung sein --
                // sonst genuegte frueher eine zufaellig passende
                // Koordinate irgendwo im Fenster, und die Kaskade sprang
                // "ab der halben Fenstergroesse" an.
                float lo = (&n->Pos.x)[cx];
                float hi = lo + (&n->Size.x)[cx];
                bool inCross = ((&mp.x)[cx] >= lo && (&mp.x)[cx] <= hi);
                float aLo = (&n->Pos.x)[ax];
                float aHi = aLo + (&n->Size.x)[ax];
                bool inAxis = ((&mp.x)[ax] >= aLo - best
                            && (&mp.x)[ax] <= aHi + best);
                ImGuiDockNode* r = nullptr;
                if (inCross && inAxis) {
                    float boundary = (&n->ChildNodes[0]->Pos.x)[ax]
                                   + (&n->ChildNodes[0]->Size.x)[ax];
                    float d = fabsf((&mp.x)[ax] - boundary);
                    if (d < best) { best = d; r = n; }
                }
                if (ImGuiDockNode* c = Nearest(n->ChildNodes[0], mp,
                                               best, wantAxis)) r = c;
                if (ImGuiDockNode* c = Nearest(n->ChildNodes[1], mp,
                                               best, wantAxis)) r = c;
                return r;
            }
        };

        // Ketten-Einheiten: entlang der Splitter-Achse absteigen; jede
        // Stufe liefert eine Einheit (child0 bzw. Quer-Teilbaum), deren
        // STARTGROESSE beim Griff eingefroren wird.
        static std::vector<std::pair<ImGuiID, float>> uNear, uFar;
        struct U {
            static void Build(ImGuiDockNode* n, int ax,
                              std::vector<std::pair<ImGuiID, float>>& out) {
                // ECHTES ABFLACHEN: beide Kinder rekursiv entlang der
                // Achse aufloesen. Die fruehere Fassung stieg nur ueber
                // ChildNodes[1] ab -- haengt der gleichachsige Teilbaum
                // (durch manuelles Andocken voellig legitim) aber im
                // ERSTEN Kind, wurde er als EINE verschmolzene Einheit
                // behandelt, deren Minimum die SUMME mehrerer Fenster
                // ist. Genau das liess das Gleiten "bei
                // unterschiedlichen Fensterhoehen" starten und
                // blockierte je nach Nestung ganz.
                if (!n) return;
                int nax = (n->SplitAxis == ImGuiAxis_X) ? 0 : 1;
                if (!n->ChildNodes[0] || nax != ax) {
                    out.push_back({ n->ID, (&n->Size.x)[ax] });
                    return;
                }
                Build(n->ChildNodes[0], ax, out);
                Build(n->ChildNodes[1], ax, out);
            }
        };
        // GATE-KORREKTUR ("nur Kaskade A" im Log, nicht einmal die
        // KEIN-Splitter-Zeile): Der Aktivierungsblock wurde NIE betreten,
        // weil auf dem Splitter-Streifen nicht der Host gehovert ist --
        // die gedockten Fenster liegen kantenbuendig, der Streifen
        // ueberlappt ihre Raender, gehovert ist eines der beiden
        // ANGRENZENDEN Fenster. Deshalb: Aktivierung auch, wenn das
        // gehoverte Fenster im Dock-Baum DIESER Seite haengt -- aber nur
        // bei HoveredId==0 (kein Item unterm Finger: Tabs/Buttons
        // bleiben ausgeschlossen, kein Hijack) und enger Toleranz.
        bool hoverOk = false;
        bool hoverStrip = false;   // Grenzstreifen-Pfad (DockSpace-Kind)
        if (gg->HoveredWindow == hostW) { hoverOk = true; hoverStrip = true; }
        else if (gg->HoveredWindow
                 && gg->HoveredWindow->RootWindow == hostW)
            // LOG-BEWEIS (aidWin=##page_host_.../DockSpace_...): Der
            // DockSpace erzeugt ein KIND-Fenster des Hosts -- dort leben
            // Splitter und Hover auf dem Grenzstreifen. Seine RootWindow-
            // Kette fuehrt zum Host: das ist der legitime Grenz-Hover.
            { hoverOk = true; hoverStrip = true; }
        else if (gg->HoveredWindow && gg->HoveredWindow->DockNode
                 && gg->HoveredId == 0) {
            ImGuiDockNode* t = gg->HoveredWindow->DockNode;
            while (t->ParentNode) t = t->ParentNode;
            if (t->ID == dockId) hoverOk = true;
        }
        static ImVec2 grabPress = ImVec2(0, 0);
        // TAB-ABSICHTS-MODELL: Druck knapp unter einer horizontalen
        // Grenze trifft die TAB-LEISTE des unteren Fensters (HoveredId
        // != 0) -- der strenge Pfad lehnt zurecht ab (Hijack-Gefahr).
        // Stattdessen: Kandidat STILL vormerken; erst wenn die Bewegung
        // eindeutig QUER zur Tab-Leiste dominiert, uebernimmt die
        // Kaskade -- Tab-Tap und Tab-Ziehen bleiben unberuehrt.
        static ImGuiID pendNode = 0; static int pendAxis = 0;
        static ImVec2 pendPress = ImVec2(0, 0);
        // EINFRIEREN ALS WIEDERVERWENDBARE FUNKTION: wird von der
        // Aktivierung UND von der Um-Scharfschaltung (Achswechsel in der
        // Totzone) gerufen. In gemischten Anordnungen liegen an jeder
        // Kreuzung ZWEI Grenzen verschiedener Achsen nah beieinander --
        // erwischt der Druck die falsche, misst der Zug entlang dieser
        // Achse ~0 und die Totzone gaebe nie frei ("Overlay erscheint
        // nicht"). Die tatsaechliche Fingerbewegung entscheidet daher
        // notfalls neu.
        auto engage = [&](ImGuiDockNode* n, ImVec2 at) {
            uNear.clear(); uFar.clear();
            sNode = n->ID;
                    sAxis = (n->SplitAxis == ImGuiAxis_X) ? 0 : 1;
                    prevFirst = (&n->ChildNodes[0]->Size.x)[sAxis];
                    grabMouse = (&at.x)[sAxis];
                    grabScrollY = ImGui::GetCurrentWindow()->Scroll.y;
                    // near = Seite VOR der Grenze (child0, rueckwaerts
                    // gelesen: grenznah zuerst), far = Seite DAHINTER.
                    s0Id = n->ChildNodes[0]->ID;
                    s1Id = n->ChildNodes[1]->ID;
                    // LAUF-WURZEL: zum obersten Vorfahren mit GLEICHER
                    // Splitter-Achse aufsteigen. Nur aus dem Teilbaum des
                    // gegriffenen Knotens gebaut, sieht die Kaskade bei
                    // verschachtelten Staeplen nur einen TEIL der Fenster
                    // unter/ueber der Grenze -- der Rest haengt in
                    // Geschwister-AEsten der Vorfahren ("letzte
                    // Barriere", tote Mittelgrenzen). Der komplette Lauf
                    // wird abgeflacht und an der gegriffenen Grenze in
                    // oben/unten partitioniert -- korrekt fuer BELIEBIG
                    // viele Fenster und jede Nistung.
                    ImGuiDockNode* runRoot = n;
                    while (runRoot->ParentNode
                           && runRoot->ParentNode->ChildNodes[0]
                           && ((runRoot->ParentNode->SplitAxis
                                == ImGuiAxis_X) ? 0 : 1) == sAxis)
                        runRoot = runRoot->ParentNode;
                    runRootId = runRoot->ID;
                    float boundary =
                        (&n->ChildNodes[0]->Pos.x)[sAxis]
                        + (&n->ChildNodes[0]->Size.x)[sAxis];
                    std::vector<std::pair<ImGuiID, float>> all;
                    U::Build(runRoot, sAxis, all);
                    // Startsummen EINMALIG an die tatsaechliche Lauf-
                    // groesse angleichen (Rundungsdrift), statt pro Frame
                    // zu skalieren.
                    {
                        float ssum = 0.0f;
                        for (auto& u : all) ssum += u.second;
                        float rs = (&runRoot->Size.x)[sAxis];
                        if (ssum > 1.0f && fabsf(rs - ssum) > 0.5f) {
                            float k2 = rs / ssum;
                            for (auto& u : all) u.second *= k2;
                        }
                    }
                    for (auto& u : all) {
                        ImGuiDockNode* uu =
                            ImGui::DockBuilderGetNode(u.first);
                        if (!uu) continue;
                        float mid = (&uu->Pos.x)[sAxis]
                                  + 0.5f * (&uu->Size.x)[sAxis];
                        if (mid <= boundary) uNear.push_back(u);
                        else                 uFar.push_back(u);
                    }
                    std::reverse(uNear.begin(), uNear.end());
                    // ImGuis eigenen Splitter stilllegen: ab jetzt
                    // steuert AUSSCHLIESSLICH unsere absolute Verteilung
                    // die Grenze. Liefen beide parallel, addierten sich
                    // ihre Bewegungen (zu schnell nach oben) bzw. hoben
                    // sich teilweise auf (Blockaden, schiefes Schieben).
                    if (cascadeOn) ImGui::ClearActiveID();
                    UiSplitterGrabActive() = true;   // Scroll versiegeln
                    grabEngaged = false;             // Totzone aktiv
                    UIP_LOGF("Kaskade B: Splitter %u Achse=%d Lauf=%u "
                            "Einheiten near=%d far=%d",
                            sNode, sAxis, runRootId,
                            (int)uNear.size(), (int)uFar.size());
        };
        // WIEDERHOLUNGSFENSTER: Beim Android-Touch trifft die Finger-
        // position gelegentlich erst einen Frame NACH dem Down ein --
        // der Klick-Frame misst dann von der alten Position und verfehlt
        // die Grenze ("Overlay erscheint nicht immer"). Deshalb: die
        // ersten Frames eines Drucks versuchen die Aktivierung erneut,
        // jeweils mit der aktuellen Position.
        // AKTIVIERUNGSFENSTER AUS IMGUIS EIGENER UHR: Der fruehere
        // pressAge-Zaehler wurde INNERHALB dieser Sektion gepflegt --
        // nach jedem erfolgreichen Zug folgen aber Drop-Save->needLayout->
        // REBUILD-Frames, in denen die Host-Sektion frueh aussteigt.
        // Landete der NAECHSTE Druck auf so einem Frame (schnelles
        // Nachjustieren!), verpasste der Zaehler den Klick und blieb fuer
        // den gesamten Druck tot: "erneut aktivieren -> kein Overlay".
        // MouseDownDuration pflegt ImGui in JEDEM Frame.
        // Vormerkung fuer den Tab-Leisten-Fall
        if (cascadeOn && ImGui::GetIO().MouseDown[0]
            && ImGui::GetIO().MouseDownDuration[0] <= 0.12f
            && sNode == 0 && pendNode == 0
            && gg->HoveredWindow && gg->HoveredWindow->DockNode
            && gg->HoveredId != 0
            && !gg->MovingWindow && !gg->DragDropActive) {
            ImGuiDockNode* t = gg->HoveredWindow->DockNode;
            while (t->ParentNode) t = t->ParentNode;
            if (t->ID == dockId)
                if (ImGuiDockNode* rt = ImGui::DockBuilderGetNode(dockId)) {
                    float bp = 12.0f;
                    if (ImGuiDockNode* np = C::Nearest(
                            rt, ImGui::GetIO().MousePos, bp)) {
                        pendNode = np->ID;
                        pendAxis = (np->SplitAxis == ImGuiAxis_X) ? 0 : 1;
                        pendPress = ImGui::GetIO().MousePos;
                    }
                }
        }
        // Absichts-Entscheid: Querbewegung dominiert -> Kaskade uebernimmt
        if (!cascadeOn) pendNode = 0;
        if (sNode == 0 && pendNode != 0) {
            if (!ImGui::GetIO().MouseDown[0] || gg->DragDropActive
                || gg->MovingWindow) {
                pendNode = 0;   // Tap/Tab-Zug: Vormerkung verwerfen
            } else {
                float along = fabsf(
                    (&ImGui::GetIO().MousePos.x)[pendAxis]
                    - (&pendPress.x)[pendAxis]);
                float cross = fabsf(
                    (&ImGui::GetIO().MousePos.x)[1 - pendAxis]
                    - (&pendPress.x)[1 - pendAxis]);
                if (along >= 6.0f && along >= cross) {
                    if (ImGuiDockNode* np =
                            ImGui::DockBuilderGetNode(pendNode)) {
                        ImGui::ClearActiveID();   // Tab sanft entwaffnen
                        engage(np, pendPress);
                    }
                    pendNode = 0;
                }
            }
        }
        float held = ImGui::GetIO().MouseDownDuration[0];
        static bool pressLogged = false;
        if (!ImGui::GetIO().MouseDown[0] || held < 0.03f)
            pressLogged = false;
        if (ImGui::GetIO().MouseDown[0] && held >= 0.0f && held <= 0.12f
            && sNode == 0
            && !gg->MovingWindow && !gg->DragDropActive
            && hoverOk) {
            // NUR IM SPLITTER-ZWISCHENRAUM AKTIVIEREN: dort gehoert der
            // Hover dem HOST-Fenster. Ohne diese Pruefung sprang die
            // Kaskade bei JEDEM Klick an, sobald irgendeine Grenze in
            // Toleranznaehe lag -- also auch beim Druck auf Titel, Tabs
            // oder Inhalt gedockter Fenster (deren Kanten liegen
            // naturgemaess AN den Knoten-Grenzen!). Ergebnis: Anspringen
            // von wechselnden, ungewollten Grenzen ("verschiedene
            // Positionen/Mindestgroessen je Richtung") und totes
            // Blockieren, weil unser ClearActiveID die eigentlich
            // gemeinte Interaktion toetete.
            sNode = 0; uNear.clear(); uFar.clear();
            if (ImGuiDockNode* root = ImGui::DockBuilderGetNode(dockId)) {
                // Pfadabhaengige Toleranz: der Grenzstreifen (DockSpace-
                // Kind) wird NUR dort gehovert -- Hijack unmoeglich, also
                // fingerfreundlich grosszuegig. Der kantennahe Fenster-
                // Pfad bleibt streng.
                float best = hoverStrip ? 26.0f : 12.0f;
                if (ImGuiDockNode* n =
                        C::Nearest(root, ImGui::GetIO().MousePos, best)) {
                    grabPress = ImGui::GetIO().MousePos;
                    engage(n, grabPress);
                }
            }

            if (sNode == 0 && held > 0.10f && !pressLogged) {
                pressLogged = true;
                // UIP_LOGF("Kaskade B: KEIN Splitter in Toleranz "
                //         "(Maus %.0f/%.0f, hover=%s)",
                //         ImGui::GetIO().MousePos.x,
                //         ImGui::GetIO().MousePos.y,
                //         gg->HoveredWindow ? gg->HoveredWindow->Name : "-");
            }
        }
        splitterDrag = cascadeOn && interacting && sNode != 0;
        // VORFAHRT: solange die Kaskade zieht, darf der globale Drag-
        // Scroll (Frame-Ende) nicht zusaetzlich feuern -- sonst scrollte
        // das Kompakt-Layout waehrend des Schiebens mit.
        if (splitterDrag) UiDragHandledThisFrame() = true;
        if (splitterDrag) {
            if (ImGuiDockNode* n = ImGui::DockBuilderGetNode(sNode)) {
                if (n->ChildNodes[0] && n->ChildNodes[1]) { do {
                    // VERSCHIEBEN STATT SCHRUMPFEN: ImGui skaliert die
                    // gequetschte Seite proportional (alles schrumpft
                    // gemeinsam). Hier werden stattdessen die Einheiten
                    // auf ihre STARTGROESSEN gehalten und die Seiten-
                    // differenz gezielt verteilt: auf der schrumpfenden
                    // Seite absorbiert die GRENZFERNSTE Einheit zuerst
                    // (die nahen gleiten mit = Passthrough), auf der
                    // wachsenden die GRENZNAECHSTE (das gegriffene
                    // Fenster waechst).
                    auto apply = [&](std::vector<std::pair<ImGuiID,
                                        float>>& units,
                                     float curSize, bool absorbNear,
                                     std::vector<float>& targetsOut) {
                        // Mit den STARTgroessen initialisieren: jeder
                        // Sonderpfad (fehlgeschlagener Node-Lookup u.ae.)
                        // degradiert damit grazil zur Startgroesse statt
                        // eine Einheit auf NULL fallen zu lassen -- das
                        // rueckte die Nachfolger ueberlappend nach und
                        // liess Mehr-Einheiten-Uebertraege scheitern.
                        targetsOut.resize(units.size());
                        for (size_t z = 0; z < units.size(); ++z)
                            targetsOut[z] = units[z].second;
                        float startSum = 0.0f;
                        for (auto& u : units) startSum += u.second;
                        float diff = curSize - startSum;
                        int nU = (int)units.size();
                        for (int k = 0; k < nU; ++k) {
                            int idx = absorbNear ? k : (nU - 1 - k);
                            ImGuiDockNode* un =
                                ImGui::DockBuilderGetNode(units[idx].first);
                            if (!un) continue;
                            float mn = C::Min(un, sAxis);
                            float tgt = units[idx].second + diff;
                            if (tgt < mn) { diff = tgt - mn; tgt = mn; }
                            else            diff = 0.0f;
                            targetsOut[idx] = tgt;   // NUR rechnen --
                            // geschrieben wird ausschliesslich von der
                            // Cursor-Platzierung (EIN Schreiber).
                            if (diff == 0.0f) {
                                for (int r = k + 1; r < nU; ++r) {
                                    int i2 = absorbNear ? r : (nU - 1 - r);
                                    ImGuiDockNode* u2 =
                                        ImGui::DockBuilderGetNode(
                                            units[i2].first);
                                    targetsOut[i2] = units[i2].second;
                                }
                                break;
                            }
                        }
                    };
                    // ABSOLUTE VERTEILUNG (loest den Abbruch): Alle
                    // frueheren Fassungen rechneten INKREMENTELL aus dem,
                    // was ImGuis Splitter pro Frame zuliess -- klemmt
                    // ImGui am Minimum des ERSTBERUEHRTEN Nachbarn, faellt
                    // der Bezugspunkt weg und die Kette bekommt nichts
                    // mehr: der Splitter "bricht ab". Jetzt wird in jedem
                    // Frame aus dem beim GRIFF eingefrorenen Startzustand
                    // plus der GESAMTdistanz der Maus seit dem Griff neu
                    // verteilt -- ImGuis eigenes Klemmen ist dabei voellig
                    // gleichgueltig.
                    static int probeD = 0; bool logD = (probeD++ % 30) == 0;
                    if (logD) {
                        char buf[192]; int off = 0;
                        for (int k = 0; k < (int)uFar.size() && k < 4; ++k)
                            if (ImGuiDockNode* uu = ImGui::DockBuilderGetNode(
                                    uFar[k].first))
                                off += snprintf(buf + off,
                                    sizeof(buf) - off, "%.0f ",
                                    (&uu->Size.x)[sAxis]);
                        UIP_LOGF("Kaskade D-IST  far: %s", buf);
                    }
                    float total = (&ImGui::GetIO().MousePos.x)[sAxis]
                                - grabMouse;
                    // SCROLL-KOMPENSATION: scrollt der Host waehrend des
                    // Griffs (Edge-Auto-Scroll!), wandert der Inhalt
                    // unter dem stehenden Finger weiter -- der Zug misst
                    // in INHALTS-Koordinaten daher Maus-Delta PLUS
                    // Scroll-Delta.
                    bool vRoot = (sAxis == 1 && runRootId == dockId);
                    if (vRoot)
                        total += ImGui::GetCurrentWindow()->Scroll.y
                               - grabScrollY;
                    // TOTZONE: Ab dem Griff wird sonst JEDEN Frame die
                    // Platzierung geschrieben -- auch bei total=0. Die
                    // Kaskade rang dann im Stand mit ImGuis Layout um
                    // dieselben Knoten (komisches Touch-Verhalten), und
                    // jede Baseline-Abweichung entlud sich als sichtbarer
                    // Sprung ("Fenster daruberr gehen auf"). Deshalb:
                    // Scroll ist ab dem Griff versiegelt, geschrieben
                    // wird aber erst nach echter Bewegung -- ein blosser
                    // Druck/Tap auf die Grenze veraendert GAR NICHTS.
                    if (!grabEngaged) {
                        if (fabsf(total) < 4.0f) {
                            // UM-SCHARFSCHALTUNG: bewegt sich der Finger
                            // quer zur gewaehlten Achse, war an der
                            // Kreuzung die falsche Grenze gegriffen --
                            // auf den Kandidaten der ANDEREN Achse am
                            // urspruenglichen Druckpunkt umschwenken.
                            float cross = fabsf(
                                (&ImGui::GetIO().MousePos.x)[1 - sAxis]
                                - (&grabPress.x)[1 - sAxis]);
                            if (cross >= 6.0f) {
                                if (ImGuiDockNode* rt =
                                        ImGui::DockBuilderGetNode(dockId)) {
                                    float b2 = 26.0f;
                                    if (ImGuiDockNode* n2 = C::Nearest(
                                            rt, grabPress, b2, 1 - sAxis))
                                        engage(n2, grabPress);
                                }
                            }
                            prevFirst = (&n->ChildNodes[0]->Size.x)[sAxis];
                            break;   // Totzone: nichts schreiben
                        }
                        grabEngaged = true;
                    }
                    float sumNear = 0.0f, sumFar = 0.0f;
                    for (auto& u : uNear) sumNear += u.second;
                    for (auto& u : uFar)  sumFar  += u.second;
                    // SPAN AUS DER ECHTEN KNOTENGROESSE, nicht aus den
                    // eingefrorenen Startsummen: ImGui verteilt jeden
                    // Frame die TATSAECHLICHE Elterngroesse auf die
                    // Kinder. Weichen unsere Kindersummen davon auch nur
                    // um Pixel ab, renormalisiert ImGui PROPORTIONAL --
                    // und schmiert die sequenzielle Treppe (grenznah
                    // zuerst) Frame fuer Frame zu gleichmaessigem
                    // Zusammenschrumpfen breit. Mit exakter Summe hat
                    // diese Renormalisierung keinen Hebel mehr.
                    ImGuiDockNode* runRoot =
                        ImGui::DockBuilderGetNode(runRootId);
                    if (!runRoot) runRoot = n;   // Fallback: lokal statt tot
                    // WÄCHTER: leere Seite => Verteilung waere ein
                    // stiller No-Op (genau das Bild "funktioniert
                    // nirgendwo"). Loggen und aussteigen.
                    if (uNear.empty() || uFar.empty()) {
                        static int eGuard = 0;
                        if ((eGuard++ % 30) == 0)
                            UIP_LOGF("Kaskade E: LEERE SEITE near=%d far=%d"
                                    " (Partition fehlgeschlagen)",
                                    (int)uNear.size(), (int)uFar.size());
                        break;
                    }
                    static int probeE = 0;
                    if ((probeE++ % 30) == 0)
                        UIP_LOGF("Kaskade E: run=%u n=%u eng=%d "
                                "near=%d far=%d tot=%.0f",
                                runRoot->ID, n->ID, (int)grabEngaged,
                                (int)uNear.size(), (int)uFar.size(),
                                (&ImGui::GetIO().MousePos.x)[sAxis]
                                    - grabMouse);
                    float span    = (&runRoot->Size.x)[sAxis];
                    // KLEMME UND TREPPE AUS DERSELBEN QUELLE: Beide
                    // Minima werden aus den ABGEFLACHTEN Einheitenlisten
                    // summiert -- exakt den Einheiten, auf die auch die
                    // Treppen-Verteilung wirkt. Vorher nutzte die Klemme
                    // das rekursive Teilbaum-Minimum; wich das von den
                    // Einheiten-Minima ab (Quer-Teilbaeume, Nestung),
                    // stoppte die Grenze BEVOR die Treppe die tieferen
                    // Nachbarn erreichen durfte ("reicht nur teilweise
                    // durch"). Jetzt kann sie sich per Konstruktion genau
                    // so weit bewegen, bis das LETZTE Element am Minimum
                    // ist.
                    float minNear = 0.0f, minFar = 0.0f;
                    for (auto& u : uNear)
                        if (ImGuiDockNode* uu =
                                ImGui::DockBuilderGetNode(u.first))
                            minNear += C::Min(uu, sAxis);
                    for (auto& u : uFar)
                        if (ImGuiDockNode* uu =
                                ImGui::DockBuilderGetNode(u.first))
                            minFar += C::Min(uu, sAxis);
                    float c0 = sumNear + total;           // Ziel-Grenze
                    // CONTAINER-WACHSTUM als STETIGE FORMEL (nur
                    // vertikaler Dock-Root): Das Extra ergibt sich jeden
                    // Frame direkt aus dem Bedarf -- span selbst wird im
                    // Frame NICHT mutiert (dockH zieht im Folgeframe
                    // nach; 1 Frame Latenz, dafuer keine Rueckkopplung).
                    // [Die fruehere Branch-Fassung mutierte span sofort
                    // und kollidierte mit dem Startsummen-Rescale:
                    // Oszillation = "Zeitlupe", tote Richtungen.]
                    if (vRoot
                        && !g_pageExtraUser.count(pg->name)) {
                        float baseSpanV = span - g_pageExtra[pg->name];
                        float need = c0 + minFar - baseSpanV;
                        g_pageExtra[pg->name] = need > 0.0f ? need : 0.0f;
                    }
                    if (c0 < minNear)       c0 = minNear;
                    if (c0 > span - minFar) c0 = span - minFar;
                    float c1 = span - c0;
                    float d0 = c0 - sumNear;
                    // SEQUENZIELLE KETTE AB DER GRENZE (beide Seiten):
                    // Der direkt beruehrte Nachbar gibt zuerst Raum bzw.
                    // waechst zuerst; ist er am Minimum, uebernimmt der
                    // naechste, dann der uebernaechste -- die dahinter
                    // liegenden gleiten dabei unveraendert mit.
                    // (Vorher absorbierte beim Schrumpfen die grenz-
                    // FERNSTE Einheit zuerst. Nach oben ist das die
                    // oberste am Container-Rand: sie kann nicht
                    // ausweichen -> das gelegentliche Blockieren.)
                    std::vector<float> tNear, tFar;
                    apply(uNear, c0, /*absorbNear=*/ true, tNear);
                    apply(uFar,  c1, /*absorbNear=*/ true, tFar);
                    // WIR LEGEN DIE FENSTER SELBST: ein Cursor-Durchlauf
                    // platziert jede Einheit lueckenlos hintereinander --
                    // Position = kumulierte Summe der Treppen-Ziele.
                    // Ueberlappungen sind damit konstruktiv unmoeglich,
                    // Am-Minimum-Bloecke gleiten zwangslaeufig GEMEINSAM,
                    // und kein Nachbar aendert sich, bevor die Treppe ihn
                    // erreicht. ImGuis Layout wird nur noch PRO EINHEIT
                    // nach innen gerufen (fuer deren Innenleben), nicht
                    // mehr auf die Wurzel -- das hatte nach eigenen
                    // Regeln nachverteilt (vorzeitige Groessenaenderung,
                    // Verschmelzen).
                    {
                        float base = (&runRoot->Pos.x)[sAxis];
                        // uNear ist grenznah-zuerst gelistet -> fuer die
                        // raeumliche Reihenfolge rueckwaerts durchlaufen.
                        float cur = base;
                        for (int k = (int)uNear.size() - 1; k >= 0; --k) {
                            if (ImGuiDockNode* uu =
                                    ImGui::DockBuilderGetNode(
                                        uNear[k].first)) {
                                ImVec2 pp = uu->Pos, sz = uu->Size;
                                (&pp.x)[sAxis] = cur;
                                (&sz.x)[sAxis] = tNear[k];
                                C::PlaceTree(uu, pp, sz);
                            }
                            cur += tNear[k];
                        }
                        cur = base + c0;
                        for (int k = 0; k < (int)uFar.size(); ++k) {
                            if (ImGuiDockNode* uu =
                                    ImGui::DockBuilderGetNode(
                                        uFar[k].first)) {
                                ImVec2 pp = uu->Pos, sz = uu->Size;
                                (&pp.x)[sAxis] = cur;
                                (&sz.x)[sAxis] = tFar[k];
                                C::PlaceTree(uu, pp, sz);
                            }
                            cur += tFar[k];
                        }
                    }
                    if (logD) {
                        char buf[192]; int off = 0;
                        for (int k = 0; k < (int)uFar.size() && k < 4; ++k)
                            if (ImGuiDockNode* uu = ImGui::DockBuilderGetNode(
                                    uFar[k].first))
                                off += snprintf(buf + off,
                                    sizeof(buf) - off, "%.0f ",
                                    (&uu->Size.x)[sAxis]);
                        UIP_LOGF("Kaskade D-SOLL far: %s (c0=%.0f c1=%.0f "
                                "tot=%.0f)", buf, c0, c1, total);
                    }
                    static int probeC = 0;
                    if ((probeC++ % 30) == 0)
                        UIP_LOGF("Kaskade C: c0=%.0f c1=%.0f d0=%.1f "
                                "(inkl. Ueberschuss-Schub)", c0, c1, d0);
                    C::FixSums(runRoot, sAxis);   // ganzer Lauf konsistent
                    // POSITIONEN NACHZIEHEN: Wir schreiben NACH dem
                    // DockSpace-Aufruf, also laeuft ImGuis Layoutdurchgang
                    // (der aus den Knotengroessen die Knoten-POSITIONEN
                    // ableitet) in diesem Frame nicht mehr -- die Knoten
                    // behielten ihre alten Ursprünge und ueberlappten
                    // ("Elemente verschmelzen ineinander"). Deshalb
                    // ImGuis eigene Propagierung ueber den Baum selbst
                    // anstossen: Pos+Size wandern konsistent nach unten.
                    // (Wurzel-Layout entfernt: die Eigen-Platzierung oben
                    //  ersetzt es vollstaendig und ohne Nachverteilung.)
                    prevFirst = c0;
                    // BILDSCHIRM-DIAGNOSE (statt Logcat): waehrend des
                    // Griffs die Kernzahlen als Overlay zeichnen -- vom
                    // Geraet direkt ablesbar.
                    {
                        char dbg[160];
                        snprintf(dbg, sizeof(dbg),
                                 "KASKADE  near=%d far=%d  zug=%.0f  "
                                 "grenze=%.0f",
                                 (int)uNear.size(), (int)uFar.size(),
                                 total, c0);
                        char dbg2[160]; int off = 0;
                        off += snprintf(dbg2 + off, sizeof(dbg2) - off,
                                        "soll far: ");
                        for (int k2 = 0;
                             k2 < (int)tFar.size() && k2 < 4; ++k2)
                            off += snprintf(dbg2 + off,
                                            sizeof(dbg2) - off, "%.0f ",
                                            tFar[k2]);
                        ImDrawList* fdl = ImGui::GetForegroundDrawList();
                        ImVec2 dp = ImGui::GetMainViewport()->WorkPos;
                        dp.y += g_barH + 8.0f; dp.x += 8.0f;
                        fdl->AddRectFilled(dp,
                            ImVec2(dp.x + 360, dp.y + 44),
                            IM_COL32(0, 0, 0, 190));
                        fdl->AddText(ImVec2(dp.x + 6, dp.y + 4),
                                     IM_COL32(255, 255, 0, 255), dbg);
                        fdl->AddText(ImVec2(dp.x + 6, dp.y + 24),
                                     IM_COL32(0, 255, 128, 255), dbg2);
                    }
                } while (false); }
            }
        }
        if (!ImGui::GetIO().MouseDown[0]) {
            sNode = 0;
            grabEngaged = false;
            UiSplitterGrabActive() = false;          // Scroll wieder frei
        }
        wasActive = splitterDrag;
        }   // Ende Griff-ERKENNUNG (uebersprungen bei Layout-Sperre)
    }

    if (touchMode && ImGui::IsWindowHovered(
            ImGuiHoveredFlags_AllowWhenBlockedByActiveItem)
        && ImGui::GetIO().MouseDown[0] && !ImGui::IsAnyItemActive())
        ImGui::SetScrollY(ImGui::GetScrollY()
                          - ImGui::GetIO().MouseDelta.y);
    ImGui::End();
    ImGui::PopStyleColor(2);   // WindowBg + DockingEmptyBg (Host)

    // ---- [SECHS-PUNKTE-GRIFF IM TAB ENTFERNT] -------------------------
    // Hier entstand pro Dock-Blatt ein eigenes Fenster "##nodegrab_%08X"
    // mit einem Punktraster, positioniert auf
    //     leaf->Pos.x + FrameHeight + 6
    // also direkt rechts neben dem Menue-Pfeil und damit MITTEN IN DER
    // TAB-LEISTE. Genau die sechs Punkte, die dort stoerten: es lag ueber
    // den Tabs, war per BringWindowToDisplayFront immer obenauf und fing
    // Klicks ab, die dem Tab galten. Bei mehreren Blaettern erschien es
    // mehrfach.
    //
    // Ersatzlos entfallen -- der Verschiebe-Griff im Titelleisten-Cluster
    // rechts leistet dasselbe (er startet ebenfalls ImGuis eigene
    // Verschiebe-Maschinerie samt Dock-Vorschau) und sitzt dort, wo man
    // ihn erwartet.

    // ---- Durchsetzung: jedes Seitenfenster gehoert in den Host-Baum ----
    // Direkt nach frischem Stapelaufbau NICHT durchsetzen: die Fenster
    // tragen ihre neuen Zuordnungen, sind aber noch nicht gedockt (Begin
    // folgt erst) -- die Durchsetzung wuerde alle Zuordnungen sofort mit
    // dem ersten Leaf ueberschreiben (alles in einem Tab statt Stapel).
    if (builtNow) return;
    ImGuiContext* g = ImGui::GetCurrentContext();

    // INTERAKTIONS-PAUSE: Beim Herausreissen eines TABS setzt ImGui in
    // der ersten Phase noch KEIN MovingWindow (interner DragDrop-
    // Payload). Die fruehere MovingWindow-Pruefung sah daher ein "frei
    // gewordenes" Fenster ohne erkannten Drag und dockte es SOFORT
    // zurueck: Docking-Vorschau weg, Drag abgebrochen, Fenster springt
    // zurueck ("Bruchteil einer Sekunde"). Deshalb: pausieren, solange
    // IRGENDEINE Interaktion laeuft (Maustaste unten, DragDrop-Payload,
    // bewegtes Fenster) -- plus 3 Frames Gnadenfrist danach, damit
    // ImGuis gequeueter Dock-Vorgang landet, bevor geurteilt wird.
    {
        static int grace = 0;
        bool interacting = (g->MovingWindow != nullptr)
                        || g->DragDropActive
                        || ImGui::GetIO().MouseDown[0];
        if (interacting) grace = 3;
        else if (grace > 0) --grace;
        if (interacting || grace > 0) {
            // Drop-Save unten weiterlaufen lassen (eigene Verzoegerung),
            // aber keine Zwangs-Eindockung waehrend der Interaktion.
            goto after_enforcement;
        }
    }
    // BEWUSSTES ABDOCKEN: Der Uebergang "war im Baum -> ist es nicht
    // mehr" (ausserhalb von Rebuilds) ist die Nutzerabsicht. Ohne diese
    // Erkennung fand die Durchsetzung das noch existierende Wurzelblatt
    // als Ziel und dockte sofort zurueck -- das letzte Fenster liess
    // sich nie herausloesen.
    // Ohne Initialisierung deklarieren: ein goto darf keine Variablen-
    // Initialisierung ueberspringen (ill-formed) -- die Zuweisung folgt
    // getrennt, hinter dem Sprungziel-Pfad.
    static std::map<std::string, bool> s_wasDocked;
    bool rebuildPhase;
    rebuildPhase = pg->needLayout || pg->needRebuild
                || (ImGui::GetTime() - g_lastRebuild < 0.4);
    for (const auto& nm : pg->windows) {
        ImGuiWindow* w = ImGui::FindWindowByName(nm.c_str());
        if (!w || !w->WasActive) continue;
        bool inHost = false;
        if (w->DockNode) {
            ImGuiDockNode* node = w->DockNode;
            while (node->ParentNode) node = node->ParentNode;
            inHost = (node->ID == dockId);
        }
        if (inHost) {
            s_wasDocked[nm] = true;
            if (UserFreed(pg->name, nm)) {
                UserFreeSet(pg->name, nm, false);   // wieder angedockt
                UiPagesPersist();
            }
            continue;
        }
        if (UserFreed(pg->name, nm)) continue;      // bleibt frei
        if (s_wasDocked[nm] && !rebuildPhase) {
            // Nutzer hat es herausgezogen: als frei anerkennen.
            s_wasDocked[nm] = false;
            auto& lv = g_layout[pg->name];
            lv.erase(std::remove_if(lv.begin(), lv.end(),
                [&](const LayoutNode& n2) {
                    for (const auto& wn : n2.windows)
                        if (wn == nm) return true;
                    return false;
                }), lv.end());
            g_dock[pg->name].erase(nm);
            g_liveLeaf[pg->name].erase(nm);
            UserFreeSet(pg->name, nm, true);
            UiPagesPersist();
            continue;
        }
        // Bewusst abgedockt (nicht im serialisierten Layout): NICHT
        // zwangseindocken -- das Fenster lebt floatend mit eigenem
        // Frei-Zustand, bis der Nutzer es wieder andockt.
        if (!g_layout[pg->name].empty()
            && !LayoutHasWindow(pg->name, nm)) {
            // NIE GESEHEN oder BEWUSST ABGEDOCKT?
            // [Ein Fenster mit gespeichertem Frei-Zustand hat der Nutzer
            //  selbst herausgezogen -- das bleibt so. Eines OHNE jeden
            //  Frei-Zustand gab es beim Speichern noch nicht: das haengen
            //  wir unten an, damit es nicht fuer immer schwebt.]
            auto& fr = g_free[pg->name];
            if (fr.find(nm) == fr.end()) {
                LayoutAppendBelow(pg->name, nm, 0.30f);
                pg->needLayout = true;
                break;
            }
            continue;
        }
        ImGuiID tgt = 0;
        // 1) Zielgenau: das konkrete Blatt aus dem zuletzt errichteten
        //    Layout-Baum -- der Ausreisser kehrt EXAKT dorthin zurueck.
        auto& ll = g_liveLeaf[pg->name];
        auto lv = ll.find(nm);
        if (lv != ll.end() && ImGui::DockBuilderGetNode(lv->second))
            tgt = lv->second;
        // 2) Blatt tot, aber serialisierter Baum vorhanden: ganzen Baum
        //    neu errichten (Gruppierung erhalten statt verwaessern).
        if (!tgt && !g_layout[pg->name].empty()) {
            pg->needLayout = true;
            break;
        }
        // 3) Fallbacks: gemerkter Roh-Knoten, dann erstes Leaf
        auto& dm = g_dock[pg->name];
        auto sv = dm.find(nm);
        if (!tgt && sv != dm.end()
            && ImGui::DockBuilderGetNode(sv->second))
            tgt = sv->second;
        if (!tgt)
            if (ImGuiDockNode* root = ImGui::DockBuilderGetNode(dockId))
                if (ImGuiDockNode* leaf = FirstLeaf(root))
                    tgt = leaf->ID;
        if (tgt) { ImGui::DockBuilderDockWindow(nm.c_str(), tgt); continue; }
        // KEIN Ziel mehr vorhanden: Das kann nur heissen, dass der Baum
        // leer ist -- also wurde soeben das LETZTE Fenster bewusst
        // herausgeloest. Frueher wurde hier ein Rebuild angefordert und
        // das Fenster schnappte sofort zurueck ("nicht abdockbar").
        // Stattdessen: als frei anerkennen und aus dem Layout nehmen.
        {
            // "Leer" heisst: kein Blatt traegt noch ein FENSTER. Der
            // Wurzelknoten selbst existiert immer (DockSpace legt ihn
            // jeden Frame an) -- die alte Pruefung auf FirstLeaf() war
            // deshalb nie wahr, der Rebuild lief trotzdem und das
            // Fenster schnappte zurueck.
            bool treeEmpty = true;
            if (ImGuiDockNode* rt = ImGui::DockBuilderGetNode(dockId)) {
                struct W {
                    static bool AnyWin(ImGuiDockNode* n) {
                        if (!n) return false;
                        if (!n->ChildNodes[0]) return n->Windows.Size > 0;
                        return AnyWin(n->ChildNodes[0])
                            || AnyWin(n->ChildNodes[1]);
                    }
                };
                if (W::AnyWin(rt)) treeEmpty = false;
            }
            if (treeEmpty) {
                auto& lv = g_layout[pg->name];
                lv.erase(std::remove_if(lv.begin(), lv.end(),
                    [&](const LayoutNode& n2) {
                        for (const auto& wn : n2.windows)
                            if (wn == nm) return true;
                        return false;
                    }), lv.end());
                g_dock[pg->name].erase(nm);
                UiPagesPersist();
            } else {
                pg->needRebuild = true;   // Baum existiert, Ziel fehlt
            }
        }
    }

    after_enforcement:;
    // EREIGNIS-SICHERUNG mit DROP-VERZOEGERUNG: Beim Loslassen auf einem
    // Andock-Anker QUEUED ImGui den Dock-Vorgang nur -- ausgefuehrt wird
    // er erst im NewFrame des FOLGEframes. Eine Sicherung im Loslass-
    // Frame selbst serialisiert daher den Baum VOR dem neuen Split und
    // ueberschreibt juengere gute Schnappschuesse mit dem Vor-Drop-Stand
    // (Tab-Gruppen ueberlebten das oft, Nebeneinander/Uebereinander --
    // neue Split-Knoten -- nie). Deshalb: Loslassen erkennen, dann ZWEI
    // Frames warten, dann force-sichern.
    {
        static ImGuiWindow* prevMoving = nullptr;
        static int saveIn = -1;
        ImGuiWindow* nowMoving = g->MovingWindow;
        if (prevMoving && !nowMoving) {
            saveIn = 2;
            for (const auto& nm2 : pg->windows) {
                ImGuiWindow* w2 = ImGui::FindWindowByName(nm2.c_str());
                if (!w2 || !w2->WasActive) continue;
                bool inT = false;
                if (w2->DockNode) {
                    ImGuiDockNode* t2 = w2->DockNode;
                    while (t2->ParentNode) t2 = t2->ParentNode;
                    inT = (t2->ID == PageDockId(*pg));
                }
                if (!inT) {          // im Drop-Moment draussen = Absicht
                    UserFreeSet(pg->name, nm2, true);
                    auto& lv2 = g_layout[pg->name];
                    lv2.erase(std::remove_if(lv2.begin(), lv2.end(),
                        [&](const LayoutNode& n3) {
                            for (const auto& wn : n3.windows)
                                if (wn == nm2) return true;
                            return false;
                        }), lv2.end());
                    g_dock[pg->name].erase(nm2);
                }
            }
        }
        prevMoving = nowMoving;
        if (saveIn >= 0 && saveIn-- == 0) {
            SavePageState(*pg, /*force=*/true);
            UiPagesPersist();                 // SOFORT auf die Platte
            // Aus dem frisch BESCHNITTENEN Schnappschuss neu errichten:
            // nach einem Abdocken kollabiert so die entstandene Luecke,
            // und die verbleibenden Fenster spannen sich sofort wieder
            // auf die volle Breite/Hoehe auf.
            pg->needLayout = true;
        }
    }

    // EINSCHWINGEN: Seitenfenster fuer die naechsten Frames unsichtbar
    // zeichnen. [Alles, was NACH UiPagesFrame() bis UiFixedHeightEnforce()
    //  gezeichnet wird, sind die Seitenfenster -- Leisten und Navigation
    //  sind hier schon fertig. Layout und Vermessung laufen bei Alpha 0
    //  ganz normal; nur sehen tut man die Zwischenzustaende nicht.
    //  Der Pop steht in UiFixedHeightEnforce(), dem festen Frame-Ende.]
    if (pg && pg->settle > 0) {
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, 0.0f);
        ui_pages_detail::g_settleAlphaPushed = true;
        pg->settle--;
    }
}

void UiWindowPropsMenuFrame() {
    using namespace ui_pages_detail;
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g) return;
    // Unkonsumierte Schliess-Wuensche des Vorframes verfallen JETZT --
    // sonst sammelte der Vektor sie endlos (Konsumenten lesen waehrend
    // der Fenster-Submission, also vor diesem Pass).
    UiCloseRequests().clear();
    // TITELLEISTEN-CLUSTER RECHTS pro Fenster, von rechts nach links:
    //   [X] [Zahnrad] [Drei Punkte] [Move]
    //  * ALLES sitzt jetzt RECHTS: Der fruehere Verschiebe-Griff oben
    //    LINKS kollidierte mit dem Fenstertitel (Eingabe-Monitor) und
    //    lag ueber dem X. Links bleibt nur Natives (Einklapp-/Menue-
    //    Pfeil).
    //  * X: frei = das native Schliess-X (bleibt rechts aussen, wir
    //    zeichnen keins). Gedockt = EIGENES X ganz rechts auf der Tab-
    //    Leiste (das native sitzt im Tab und verschwindet bei langen
    //    Titeln); Klick setzt DockTabWantClose -- exakt der Mechanismus
    //    des Tab-X.
    //  //  * VERSCHIEBE-GRIFF: nur freie Fenster/Komplexe; startet ImGuis
    //    Verschiebe-Maschinerie (Dock-Vorschau + Andocken inklusive).
    static bool        s_dotsJustOpened = false;
    static std::string s_dotsFor;            // Punkte-Menue offen fuer
    static std::string s_menuFor;            // Zahnrad-Panel offen fuer
    static bool        s_menuJustOpened = false;
    ImGuiIO& io = g->IO;
    const float box = ImGui::GetFrameHeight();
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    const ImU32 colBg = ImGui::GetColorU32(ImGuiCol_Button, 0.92f);
    // Ein Klick darf genau EINEN Slot treffen -- vorher konnten sich
    // Cluster ueberlagernder Fenster (Tab-Fenster + sein Dock-Host,
    // Zielfenster + Einstellungs-Ueberlagerung) denselben Klick teilen:
    // Zahnrad hier oeffnete UND Zahnrad/Move dort feuerte gleichzeitig.
    bool clickFree = ImGui::IsMouseClicked(ImGuiMouseButton_Left);

    // Oberstes Fenster an einem Punkt (fuer die Klick-Freigabe der
    // Cluster: verdeckte Buttons duerfen nicht schalten).
    // [topWinAt entfernt -- es diente nur der alten Knopfleiste.]
    // ------------------------------------------------------------------
    // DIE KNOPFLEISTE IST ENTFERNT.
    // [Hier lagen 225 Zeilen: Verschiebe-Griff, drei Punkte, Zahnrad,
    //  Luecke und X -- selbstgezeichnet, in bzw. unter der Tab-Leiste.
    //  Sie haben mehr Aerger gemacht als geloest: Klicks kollidierten mit
    //  den Tabs, bei schmalen Fenstern ragten die Symbole heraus, und
    //  "nicht jedes Fenster liess sich schliessen" lag daran, dass jeder
    //  der drei Faelle (angedockt / frei mit Titelleiste / frei ohne)
    //  einen eigenen Zweig brauchte.
    //
    //  Ersetzt durch Mehrfinger-Gesten -- siehe UiWinGesturesFrame()
    //  weiter unten:
    //     ZWEI Finger tippen  -> Aktionen-Overlay (darin auch SCHLIESSEN)
    //     DREI Finger tippen  -> Einstellungen-Overlay
    //     DREI Finger ziehen  -> Fenster verschieben
    //  Das Overlay hat beliebig viel Platz, kollidiert mit nichts und
    //  gilt fuer JEDES Fenster gleich.]
    // ------------------------------------------------------------------


    // ---------- EIGENER MITTEL-ANKER fuer KOMPLEX-Drops ----------------
    // ImGui blendet beim Ziehen eines GETEILTEN Komplexes (Split-Baum)
    // den Mittel-Anker aus -- ein Baum laesst sich nicht 1:1 "tabben".
    // Wir zeichnen ihn selbst: Loslassen darauf sortiert ALLE Fenster
    // des Komplexes als TABS in das Ziel-Blatt ein.
    {
        static std::vector<std::string> ctrPayload;
        static ImGuiID ctrTarget = 0;
        static bool    ctrHot    = false;
        ImGuiWindow* mv = g->MovingWindow;
        if (mv && mv->DockNodeAsHost
            && mv->DockNodeAsHost->IsSplitNode()) {
            ctrPayload.clear();
            ImGuiDockNode* stack[32]; int sp = 0;
            stack[sp++] = mv->DockNodeAsHost;
            while (sp > 0 && sp < 31) {
                ImGuiDockNode* n = stack[--sp];
                for (int i = 0; i < n->Windows.Size; ++i)
                    ctrPayload.push_back(n->Windows[i]->Name);
                if (n->ChildNodes[0]) stack[sp++] = n->ChildNodes[0];
                if (n->ChildNodes[1]) stack[sp++] = n->ChildNodes[1];
            }
            ImGuiDockNode* tgt = nullptr;
            for (int wi = g->Windows.Size - 1; wi >= 0; --wi) {
                ImGuiWindow* w2 = g->Windows[wi];
                if (!w2->WasActive || w2->Hidden) continue;
                if (w2->RootWindowDockTree == mv) continue;  // Komplex selbst
                if (w2->Flags & (ImGuiWindowFlags_Tooltip
                                 | ImGuiWindowFlags_Popup)) continue;
                if (!w2->Rect().Contains(io.MousePos)) continue;
                if (w2->DockNode && !w2->DockNode->IsSplitNode())
                    { tgt = w2->DockNode; break; }
            }
            ctrTarget = tgt ? tgt->ID : 0;
            ctrHot = false;
            if (tgt) {
                ImVec2 c(tgt->Pos.x + tgt->Size.x * 0.5f,
                         tgt->Pos.y + tgt->Size.y * 0.5f);
                float h = box * 0.85f;
                ImRect anker(ImVec2(c.x - h, c.y - h),
                             ImVec2(c.x + h, c.y + h));
                ctrHot = anker.Contains(io.MousePos);
                ImU32 pv = ImGui::GetColorU32(ImGuiCol_DockingPreview,
                                              ctrHot ? 0.90f : 0.55f);
                dl->AddRectFilled(anker.Min, anker.Max, pv, 4.0f);
                dl->AddRect(anker.Min, anker.Max,
                            IM_COL32(255, 255, 255, 200), 4.0f, 0, 2.0f);
                if (ctrHot)   // Vorschau: Ziel wird als Ganzes markiert
                    dl->AddRectFilled(tgt->Pos,
                        ImVec2(tgt->Pos.x + tgt->Size.x,
                               tgt->Pos.y + tgt->Size.y),
                        ImGui::GetColorU32(ImGuiCol_DockingPreview, 0.30f));
            }
        } else {
            // Loslass-Frame: MovingWindow ist hier schon null. War der
            // Mittel-Anker im Vorframe heiss, JETZT alle gemerkten
            // Fenster als Tabs ins Ziel einsortieren.
            if (ctrHot && ctrTarget != 0
                && ImGui::IsMouseReleased(ImGuiMouseButton_Left)
                && ImGui::DockBuilderGetNode(ctrTarget)) {
                for (const auto& nm : ctrPayload)
                    ImGui::DockBuilderDockWindow(nm.c_str(), ctrTarget);
                UiDragHandledThisFrame() = true;
            }
            if (!io.MouseDown[0]) { ctrHot = false; ctrTarget = 0; }
        }
    }

    // ------------------------------------------------------------------
    // FENSTER IN DIE RECHTE NAVI ZIEHEN = SCHLIESSEN.
    // [Der Rueckweg zur Palette. Ein Fenster wird von ImGui nicht als
    //  DragDrop-Nutzlast gezogen, sondern ueber g->MovingWindow -- also
    //  dasselbe Muster wie der Mittel-Anker weiter unten: waehrend des
    //  Zugs die Namen sammeln und die Flaeche markieren, beim Loslassen
    //  handeln. Ein ganzer Komplex (Split-Host) wird komplett
    //  geschlossen: alle Fenster darin.]
    {
        static std::vector<std::string> naviPayload;
        static bool naviHot = false;
        const ImRect nr = UiNavi::RightRectLastFrame();
        bool naviOffen = nr.Max.x > nr.Min.x;
        ImGuiWindow* mv = g->MovingWindow;
        if (mv && naviOffen) {
            naviPayload.clear();
            if (mv->DockNodeAsHost) {
                // Ganzer Komplex: alle Fenster aller Blaetter.
                ImGuiDockNode* stack[32]; int sp = 0;
                stack[sp++] = mv->DockNodeAsHost;
                while (sp > 0 && sp < 31) {
                    ImGuiDockNode* n = stack[--sp];
                    for (int i = 0; i < n->Windows.Size; ++i)
                        naviPayload.push_back(n->Windows[i]->Name);
                    if (n->ChildNodes[0]) stack[sp++] = n->ChildNodes[0];
                    if (n->ChildNodes[1]) stack[sp++] = n->ChildNodes[1];
                }
            } else {
                naviPayload.push_back(mv->Name);
            }
            naviHot = nr.Contains(io.MousePos);
            if (naviHot) {
                // Rueckmeldung: Flaeche markieren und sagen, was passiert.
                ImDrawList* dl = ImGui::GetForegroundDrawList();
                dl->AddRectFilled(nr.Min, nr.Max,
                    ImGui::GetColorU32(ImGuiCol_DockingPreview, 0.35f), 4.0f);
                dl->AddRect(nr.Min, nr.Max, IM_COL32(255, 255, 255, 200),
                            4.0f, 0, 2.0f);
                const char* txt = naviPayload.size() > 1
                                ? "hier ablegen = alle schliessen"
                                : "hier ablegen = schliessen";
                ImVec2 ts = ImGui::CalcTextSize(txt);
                dl->AddText(ImVec2((nr.Min.x + nr.Max.x) * 0.5f - ts.x * 0.5f,
                                   nr.Min.y + 8.0f),
                            IM_COL32(255, 255, 255, 230), txt);
            }
        } else if (naviHot) {
            // Loslass-Frame: MovingWindow ist hier schon null.
            if (ImGui::IsMouseReleased(ImGuiMouseButton_Left)) {
                UiPage* pg2 = UiActivePage();
                for (const auto& nm : naviPayload) {
                    UiCloseRequests().push_back(UiPropsKey(nm.c_str()));
                    UiCloseRequests().push_back(nm);   // auch unter Rohname
                    if (ImGuiWindow* cw = ImGui::FindWindowByName(nm.c_str()))
                        cw->DockTabWantClose = true;
                    if (pg2) UserFreeSet(pg2->name, nm, false);
                }
                if (pg2) pg2->needLayout = true;
                UiDragHandledThisFrame() = true;
            }
            if (!io.MouseDown[0]) { naviHot = false; naviPayload.clear(); }
        }
    }

    // ------------------------------------------------------------------
    // EIN X FUER JEDES FENSTER -- AN DERSELBEN STELLE, IMMER.
    // [Seit die alte Knopfleiste weg ist, zeichnet nur noch ImGui selbst
    //  ein X -- und zwar allein bei Fenstern MIT Titelleiste, deren
    //  Begin() einen open-Zeiger bekommt. Beides trifft bei euren
    //  Fenstern haeufig nicht zu; daher "das X ist nicht ueberall da".
    //
    //  Dieses X ist EIN Element (nicht fuenf wie damals), sitzt in der
    //  rechten obereren Ecke des INHALTS, und sein Klick geht durch
    //  dieselbe Tuer wie alles andere: UiWinOpen. Damit gilt fuer jedes
    //  Fenster derselbe Weg -- kein Zweig, keine Ausnahme.]
    {
        ImGuiIO& xio = ImGui::GetIO();
        bool klick = ImGui::IsMouseClicked(ImGuiMouseButton_Left)
                  && !UiDragHandledThisFrame() && !g->MovingWindow
                  && !ImGui::IsDragDropActive();
        for (ImGuiWindow* w : g->Windows) {
            if (!w->WasActive || w->Hidden) continue;
            if (w->Flags & (ImGuiWindowFlags_Tooltip | ImGuiWindowFlags_Popup
                            | ImGuiWindowFlags_ChildWindow)) continue;
            // [NICHT nach NoSavedSettings aussortieren. Eigene
            //  Hilfsfenster tragen das Flag -- aber auch echte
            //  Seitenfenster, z.B. "X Login (Cookies)" auf Android.
            //  Die fielen damit durchs Raster: kein X, nicht
            //  schliessbar. Meine Hilfsfenster erkenne ich an ihrem
            //  Namen, das ist eindeutig.]
            if (strstr(w->Name, "###xbm_")) continue;
            // Angedockt: nur das sichtbare Tab-Fenster, sonst liegen
            // mehrere X uebereinander.
            if (w->DockNode && w->DockNode->VisibleWindow
                && w->DockNode->VisibleWindow != w) continue;
            // Nur registrierte Seitenfenster -- keine ImGui-Eigengewaechse.
            std::string basis = UiPropsKey(w->Name);   // Name ohne "##Seite"
            if (basis.empty()) continue;
            bool bekannt = false;
            for (const auto& pg4 : UiPages())
                for (const auto& n4 : pg4.windows)
                    if (UiPropsKey(n4.c_str()) == basis) bekannt = true;
            if (!bekannt) continue;

            const float kx = ImGui::GetFontSize() * 1.15f;
            ImVec2 a(w->InnerRect.Max.x - kx - 2.0f, w->InnerRect.Min.y + 2.0f);
            ImVec2 b(a.x + kx, a.y + kx);
            if (b.x <= a.x || b.y <= a.y) continue;
            ImVec2 mp = xio.MousePos;
            bool hov = mp.x >= a.x && mp.x <= b.x && mp.y >= a.y && mp.y <= b.y;
            ImDrawList* dl = (w->DockNode && w->DockNode->HostWindow)
                           ? w->DockNode->HostWindow->DrawList : w->DrawList;
            dl->PushClipRectFullScreen();
            if (hov)
                dl->AddRectFilled(a, b, ImGui::GetColorU32(ImGuiCol_ButtonHovered), 3.0f);
            float r = kx * 0.26f;
            ImVec2 c((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f);
            ImU32 col = ImGui::GetColorU32(ImGuiCol_Text);
            dl->AddLine(ImVec2(c.x - r, c.y - r), ImVec2(c.x + r, c.y + r), col, 2.0f);
            dl->AddLine(ImVec2(c.x - r, c.y + r), ImVec2(c.x + r, c.y - r), col, 2.0f);
            dl->PopClipRect();
            if (klick && hov) {
                UiWinOpen(basis) = false;          // wirkt sofort
                UiCloseRequests().push_back(basis);   // fuer eigene Flags
                w->DockTabWantClose = true;
                UiDragHandledThisFrame() = true;
                klick = false;
            }
        }
    }

    // ------------------------------------------------------------------
    // MEHRFINGER-GESTEN -> OVERLAYS
    // [Ersatz fuer die entfernte Knopfleiste. Das Overlay faehrt unter
    //  der Tab-Leiste herab, ist so breit wie der Bildschirm und hat
    //  damit Platz fuer klar beschriftete Eintraege -- statt fuenf
    //  Symbolen von je 20 Pixeln in einer Tab-Leiste.]
    {
        UiWinGestureErgebnis ge = UiWinGesturesFrame();
        if (ge.art == UiWinGesture::AktionenUmschalten) {
            // AUF/ZU mit derselben Geste. [Vorher nur "auf"; zu ging nur
            //  per Klick daneben oder "Zu".]
            if (s_dotsFor == ge.fenster) s_dotsFor.clear();
            else { s_dotsFor = ge.fenster; s_dotsJustOpened = true; }
        }
        else if (ge.art == UiWinGesture::Einstellungen) {
            s_dotsFor.clear();
            s_menuFor = UiPropsKey(ge.fenster.c_str());
            s_menuJustOpened = true;
        }
        else if (ge.art == UiWinGesture::HoeheAendern) {
            // ZWEI FINGER, 2x GETIPPT, DANN GEZOGEN: Hoehe in Zugrichtung.
            // [Wird zu "feste Dimensionen" mit angepasster lockedH -- die
            //  bestehende Durchsetzung setzt sie um. Untergrenze wie in
            //  UiLeafWantY, damit das Fenster nicht auf null zusammenfaellt.]
            const std::string key = UiPropsKey(ge.fenster.c_str());
            UiWinProps& wp = UiPropsFor(ge.fenster.c_str());
            ImGuiWindow* tw = ImGui::FindWindowByName(ge.fenster.c_str());
            if (tw && ge.delta != 0.0f) {
                if (wp.sizeMode != 1 || wp.lockedH <= 1.0f) {
                    wp.sizeMode = 1; wp.fixHeight = true;
                    UiCaptureLockedH(key);
                    if (wp.lockedH <= 1.0f) wp.lockedH = tw->Size.y;
                }
                const float boden = ImGui::GetFrameHeightWithSpacing() * 4.0f;
                wp.lockedH += ge.delta;
                if (wp.lockedH < boden) wp.lockedH = boden;
                wp.growStreak = 0; wp.streakFrame = -1;
                wp.baselineH = -1.0f; wp.lastWant = -1.0f;
                UiPagesPersist();
            }
        }
        else if (ge.art == UiWinGesture::ModusUmschalten) {
            // ZWEI FINGER, 3x GETIPPT: "inhaltsbasiert" <-> "frei skalierbar".
            const std::string key = UiPropsKey(ge.fenster.c_str());
            UiWinProps& wp = UiPropsFor(ge.fenster.c_str());
            const bool zuInhalt = (wp.sizeMode != 2);
            wp.sizeMode  = zuInhalt ? 2 : 0;
            wp.fixHeight = false;
            wp.adaptive  = false;
            wp.growStreak = 0; wp.streakFrame = -1;
            wp.baselineH = -1.0f; wp.lastWant = -1.0f;
            UiPagesPersist();
            char rein[96]; UiCleanWinName(ge.fenster.c_str(), rein, sizeof(rein));
            UiAlertZeigen("winmode", std::string(rein) + ": "
                          + (zuInhalt ? "Hoehe folgt dem Inhalt" : "frei skalierbar"),
                          UiAlertArt::Info);
            (void)key;
        }
    }

    // Klick irgendwo anders schliesst das offene Punkte-Menue.
    // [Ohne diesen Merker schloss der Klick, der das Menue OEFFNET, es im
    //  selben Frame wieder: "das Menue taucht nicht immer auf".]
    if (s_dotsJustOpened) { s_dotsJustOpened = false; clickFree = false; }
    if (!s_dotsFor.empty() && clickFree) {
        ImGuiWindow* dw = ImGui::FindWindowByName("Fenster###xbm_windots");
        if (!(dw && dw->WasActive && dw->Rect().Contains(io.MousePos)))
            s_dotsFor.clear();
    }
    if (!s_dotsFor.empty()) {
        ImGuiWindow* dtw = ImGui::FindWindowByName(s_dotsFor.c_str());
        if (!dtw || !dtw->WasActive) { s_dotsFor.clear(); }
        else {
            // OVERLAY: unter der Tab-Leiste, volle Breite.
            ImGuiViewport* ovp = ImGui::GetMainViewport();
            ImGui::SetNextWindowPos(ImVec2(ovp->WorkPos.x,
                                           ovp->WorkPos.y + g_barH),
                                    ImGuiCond_Always);
            ImGui::SetNextWindowSize(ImVec2(ovp->WorkSize.x, 0.0f),
                                     ImGuiCond_Always);
            ImGui::SetNextWindowFocus();
            ImGui::Begin("Fenster###xbm_windots", nullptr,
                         ImGuiWindowFlags_AlwaysAutoResize
                         | ImGuiWindowFlags_NoDocking
                         | ImGuiWindowFlags_NoCollapse
                         | ImGuiWindowFlags_NoTitleBar
                         | ImGuiWindowFlags_NoMove
                         | ImGuiWindowFlags_NoSavedSettings);
            {   // Kopf: welches Fenster, und der Weg heraus.
                char rein[96];
                UiCleanWinName(dtw->Name, rein, sizeof(rein));
                ImGui::TextDisabled("Aktionen fuer:");
                ImGui::SameLine(); ImGui::TextUnformatted(rein);
                ImGui::SameLine(ImGui::GetContentRegionAvail().x
                                - ImGui::CalcTextSize("Zu").x - 24.0f
                                + ImGui::GetCursorPosX());
                if (ImGui::SmallButton("Zu")) s_dotsFor.clear();
                ImGui::Separator();
            }
            // SCHLIESSEN -- FUER JEDES FENSTER, EIN WEG.
            // [Vorher drei Zweige (angedockt / frei mit Titelleiste /
            //  frei ohne) mit je eigener Logik -- deshalb liess sich
            //  nicht jedes Fenster schliessen. Hier beides zugleich:
            //  der Wunsch (wirkt immer) UND DockTabWantClose.]
            if (ImGui::Selectable("Fenster schliessen")) {
                // DIREKT setzen, nicht nur wuenschen -- ein Wunsch wirkt
                // erst, wenn UiPageWindow(name) das naechste Mal laeuft,
                // und bei einem Fenster mit eigenem Flag nie.
                UiWinOpen(UiPropsKey(dtw->Name)) = false;
                UiCloseRequests().push_back(UiPropsKey(dtw->Name));
                UiCloseRequests().push_back(dtw->Name);
                dtw->DockTabWantClose = true;
                if (UiPage* pg3 = UiActivePage())
                    UserFreeSet(pg3->name, dtw->Name, false);
                s_dotsFor.clear();
            }
            // EINKLAPPEN -- ANGEDOCKT WIE FREISCHWEBEND.
            // [Bisher stand hier  !dtw->DockIsActive : angedockt gab es
            //  den Eintrag gar nicht. Angedockt kann ImGui nicht
            //  einklappen (der Knoten hat feste Groesse), aber wir
            //  koennen: den Knoten auf Kopfzeilenhoehe setzen und den
            //  Zustand je KNOTEN merken -- damit klappen alle Fenster
            //  derselben Tab-Leiste zusammen, wie gewuenscht.]
            {
                // EINKLAPPEN -- MIT ECHTER HOEHENAENDERUNG.
                // [Vorher wurde nur ein Merker gesetzt und der Inhalt
                //  nicht gezeichnet: der Knoten behielt seine Hoehe, das
                //  Fenster war leer statt klein. Und der Eintrag wechselte
                //  nicht auf "Ausklappen", weil UiNodeCollapsed fuer
                //  FREIE Fenster w->Collapsed las, das wir nie setzten.
                //  Jetzt: frei -> ImGui klappt selbst ein (das kann es);
                //  angedockt -> die Knotenhoehe wird auf Kopfzeilenhoehe
                //  gesetzt und die alte gemerkt.]
                bool zu = dtw->DockNode
                        ? UiNodeCollapsed(dtw) : dtw->Collapsed;
                if (ImGui::Selectable(zu ? "Ausklappen" : "Einklappen")) {
                    if (dtw->DockNode && !dtw->DockNode->IsFloatingNode()) {
                        ImGuiID nid = dtw->DockNode->ID;
                        UiCollapsedNodes()[(unsigned int)nid] = !zu;
                        ImGuiDockNode* nd = dtw->DockNode;
                        if (!zu) {
                            UiCollapsedSizes()[(unsigned int)nid] = nd->Size;
                            float h = ImGui::GetFrameHeight() + 8.0f;
                            ImGui::DockBuilderSetNodeSize(nid, ImVec2(nd->Size.x, h));
                        } else {
                            auto it = UiCollapsedSizes().find((unsigned int)nid);
                            if (it != UiCollapsedSizes().end())
                                ImGui::DockBuilderSetNodeSize(nid, it->second);
                        }
                        // Wurzel abschliessen, nicht den Teilknoten --
                        // sonst wirkt die Groesse nicht.
                        ImGuiDockNode* root = nd;
                        while (root->ParentNode) root = root->ParentNode;
                        ImGui::DockBuilderFinish(root->ID);
                    } else {
                        ImGui::SetWindowCollapsed(dtw, !zu);
                    }
                    s_dotsFor.clear();
                }
            }
            for (auto& ex : UiWindowDotsExtras())
                if (ImGui::Selectable(ex.label.c_str()))
                    { if (ex.fn) ex.fn(dtw); s_dotsFor.clear(); }
            if (ImGui::Selectable("Abbrechen")) s_dotsFor.clear();
            ImGui::End();
        }
    }

    if (s_menuFor.empty()) return;
    if (g->MovingWindow) {
        // WAEHREND eines Fenster-Zugs blendet sich die Einstellungs-
        // seite aus: Als NoDocking-Fenster deckte sie das Ziel ab und
        // fing das Hover ab -- ImGui fand unter dem Cursor deshalb KEIN
        // Andock-Ziel ("mit offener Einstellungsseite nirgends andock-
        // bar, auch nicht per Move-Griff"). Nach dem Loslassen ist sie
        // unveraendert wieder da (s_menuFor bleibt bestehen).
        return;
    }
    auto itp = g_winProps.find(s_menuFor);
    ImGuiWindow* tw = UiFindWindowByPropsKey(s_menuFor);
    if (itp == g_winProps.end() || !tw || !tw->WasActive) {
        s_menuFor.clear(); return;
    }
    // OVERLAY: unter der Tab-Leiste herab, wie das Aktionen-Overlay.
    // [Vorher klebte die Seite an der Fensterposition -- bei einem
    //  Fenster am unteren Rand lief sie aus dem Bild, und als
    //  NoDocking-Fenster deckte sie Andockziele ab.]
    {
        ImGuiViewport* svp = ImGui::GetMainViewport();
        ImGui::SetNextWindowPos(ImVec2(svp->WorkPos.x,
                                       svp->WorkPos.y + g_barH),
                                ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(svp->WorkSize.x, 0.0f),
                                 ImGuiCond_Always);
    }
    // [Hier stand "SetNextWindowSize(tw->Size)": das ueberschrieb die eben
    //  gesetzte volle Breite mit der Groesse des ZIELfensters -- das Panel
    //  wurde so schmal wie das Fenster und wirkte wie ein Overlay darin.]
    // Fokus nur EINMAL beim Oeffnen -- der permanente SetNextWindowFocus
    // machte die Ueberlagerung zum Eingabe-Monopolisten ("kann nichts
    // anderes bedienen"). Obenauf bleibt sie per Display-Front, das
    // keine Eingaben umlenkt.
    if (s_menuJustOpened) { ImGui::SetNextWindowFocus();
                            s_menuJustOpened = false; }
    ImGui::Begin("Einstellungen###xbm_winprops", nullptr,
                 ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_NoResize
                 | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse
                 | ImGuiWindowFlags_NoSavedSettings);
    ImGui::TextDisabled("Einstellungen: %s", s_menuFor.c_str());
    ImGui::SameLine(ImGui::GetContentRegionAvail().x
                    - ImGui::CalcTextSize("Zurueck").x
                    + ImGui::GetCursorPosX()
                    - ImGui::GetStyle().FramePadding.x * 2);
    if (ImGui::SmallButton("Zurueck")) { s_menuFor.clear(); }
    ImGui::Separator();
    if (!s_menuFor.empty()) {
        UiWinProps& wp = itp->second;
        // Modus 0 = frei, 1 = feste Dimensionen, 2 = Hoehe folgt Inhalt.
        // (Der alte Ja/Nein-Schalter fixHeight bleibt intern die Quelle
        // fuer alle Durchsetzungs-Stellen und wird hier mitgefuehrt.)
        // VOLLBILD zuerst: Es setzt die Groessen-Modi ausser Kraft,
        // deshalb werden die darunter ausgegraut.
        bool fs = wp.fullscreen;
        if (ImGui::Checkbox("Vollbild Fenster", &fs)) {
            wp.fullscreen = fs;
            wp.growStreak = 0; wp.streakFrame = -1;
            wp.baselineH = -1.0f; wp.lastWant = -1.0f;
            UiPagesPersist();
        }
        ImGui::SameLine(); ImGui::TextDisabled("(?)");
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Nimmt immer die volle Hoehe des Seiten-\n"
                              "DockSpace ein -- auch bei ausgefahrener\n"
                              "Android-Tastatur. Andere Fenster lassen\n"
                              "sich weiterhin daneben andocken.");
        ImGui::Separator();
        if (wp.fullscreen) ImGui::BeginDisabled();

        if (wp.sizeMode == 0 && wp.fixHeight) wp.sizeMode = 1;
        int mode = wp.sizeMode;
        bool ch = false;
        ch |= ImGui::RadioButton("frei skalierbar", &mode, 0);
        ch |= ImGui::RadioButton("feste Dimensionen", &mode, 1);
        ImGui::SameLine(); ImGui::TextDisabled("(?)");
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Verhindert Vergroessern und Verkleinern.\n"
                              "Im DockSpace regelt die BREITE weiterhin\n"
                              "der Dock-Baum -- dort gilt nur die Hoehe.");
        ch |= ImGui::RadioButton("inhaltsgesteuerte Hoehe", &mode, 2);
        if (ch) {
            wp.sizeMode  = mode;
            wp.fixHeight = (mode == 1);
            if (mode == 1) UiCaptureLockedH(s_menuFor);
            wp.growStreak = 0; wp.streakFrame = -1;
            wp.baselineH = -1.0f; wp.lastWant = -1.0f;
            UiPagesPersist();
        }
        if (wp.sizeMode == 1) {
            ImGui::TextDisabled("eingefroren bei %.0f px",
                                wp.lockedH > 1.0f ? wp.lockedH : 0.0f);
            if (ImGui::SmallButton("aktuelle Groesse neu einfrieren"))
                UiCaptureLockedH(s_menuFor);
        } else if (wp.sizeMode == 2) {
            if (wp.adaptive) {
                // ERKENNUNG: 'adaptive' meldet genau die Fenster, deren
                // Inhalt die Flaeche AUSFUELLT (Kind-Region/Canvas) --
                // die haben keine eigene Inhaltshoehe, an der man sich
                // orientieren koennte. Fuer sie gibt es die Mindesthoehe.
                ImGui::TextDisabled("Inhalt fuellt das Fenster --\n"
                                    "es gilt die Mindesthoehe:");
                float mh = wp.minH;
                ImGui::SetNextItemWidth(140.0f);
                if (ImGui::DragFloat("##minh", &mh, 1.0f, 0.0f, 4000.0f,
                                     "%.0f px")) {
                    wp.minH = mh < 0.0f ? 0.0f : mh;
                    UiPagesPersist();
                }
                ImGui::SameLine();
                if (ImGui::SmallButton("= jetzige Hoehe")) {
                    wp.minH = tw->Size.y;
                    UiPagesPersist();
                }
            } else {
                ImGui::TextDisabled("Hoehe folgt dem Inhalt");
            }
        }
        if (wp.fullscreen) ImGui::EndDisabled();
    }
    ImGui::BringWindowToDisplayFront(ImGui::GetCurrentWindow());
    ImGui::End();
}

void UiFitWindowsToKeyboard() {
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g) return;
    struct Saved { ImVec2 pos, size; bool valid = false; };
    static std::map<ImGuiID, Saved> s_saved;
    static bool s_wasOpen = false;

    bool open = UiImeOpen();
    float visTop = UiVisTop(), visBot = UiVisBottom();

    if (!open) {
        if (s_wasOpen) {                       // Tastatur gerade zu
            for (auto& [id, sv] : s_saved) {
                if (!sv.valid) continue;
                if (ImGuiWindow* w = ImGui::FindWindowByID(id)) {
                    ImGui::SetWindowPos(w, sv.pos, ImGuiCond_Always);
                    ImGui::SetWindowSize(w, sv.size, ImGuiCond_Always);
                }
            }
            s_saved.clear();
        }
        s_wasOpen = false;
        return;
    }
    s_wasOpen = true;

    for (ImGuiWindow* w : g->Windows) {
        if (!w->WasActive || w->Hidden) continue;
        if (w->DockIsActive || w->ParentWindow) continue;   // Dock/Kinder
        if (w->Flags & (ImGuiWindowFlags_ChildWindow
                      | ImGuiWindowFlags_Popup
                      | ImGuiWindowFlags_Tooltip)) continue;
        if (w->Flags & ImGuiWindowFlags_NoResize) continue;
        if (strncmp(w->Name, "##", 2) == 0) continue;       // interne

        Saved& sv = s_saved[w->ID];
        if (!sv.valid) { sv.pos = w->Pos; sv.size = w->Size; sv.valid = true; }

        float bottom = w->Pos.y + w->Size.y;
        if (bottom <= visBot) continue;                     // passt schon

        float newH = visBot - w->Pos.y;
        const float minH = ImGui::GetFrameHeight() * 3.0f;
        if (newH < minH) {
            // Zu wenig Platz unterhalb: Fenster nach oben schieben.
            float newY = visBot - minH;
            if (newY < visTop) newY = visTop;
            ImGui::SetWindowPos(w, ImVec2(w->Pos.x, newY), ImGuiCond_Always);
            newH = visBot - newY;
            if (newH < minH) newH = minH;
        }
        ImGui::SetWindowSize(w, ImVec2(w->Size.x, newH), ImGuiCond_Always);
    }
}

void UiImeAvoidance(bool imeVisible, float visTop, float visBottom) {
    using namespace ui_pages_detail;
    static bool  prevVisible = false;
    static float pinnedY     = -1.0f;
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g) { prevVisible = imeVisible; return; }
    ImGuiWindow* host = nullptr;
    for (ImGuiWindow* w : g->Windows)
        if (w->WasActive && !w->Hidden
            && strncmp(w->Name, "##page_host_", 12) == 0)
            { host = w; break; }
    ImGuiPlatformImeData& ime = g->PlatformImeData;
    float caretY = ime.InputPos.y + ime.InputLineHeight * 0.5f;
    if (!imeVisible || !ime.WantVisible) {
        prevVisible = imeVisible; pinnedY = -1.0f; return;
    }
    // Traeger des Textfelds: gedockt -> Seiten-Host scrollen;
    // frei schwebend -> das Fenster selbst verschieben.
    ImGuiWindow* aw = g->ActiveIdWindow ? g->ActiveIdWindow
                                        : g->NavWindow;
    ImGuiWindow* freeWin = nullptr;
    if (aw) {
        ImGuiWindow* rt = aw->RootWindowDockTree;
        if (rt && rt != host && !rt->DockIsActive
            && strncmp(rt->Name, "##", 2) != 0)
            freeWin = rt;
    }
    float mid = (visTop + visBottom) * 0.5f;
    auto correct = [&](float dy) {
        if (freeWin) {
            ImGui::SetWindowPos(freeWin,
                ImVec2(freeWin->Pos.x, freeWin->Pos.y - dy),
                ImGuiCond_Always);
        } else if (host) {
            float ns = host->Scroll.y + dy;
            if (ns < 0.0f)              ns = 0.0f;
            if (ns > host->ScrollMax.y) ns = host->ScrollMax.y;
            if (ns != host->Scroll.y) ImGui::SetScrollY(host, ns);
        }
    };
    if (!prevVisible || pinnedY < 0.0f) {
        if (caretY > visBottom - 8.0f || caretY < visTop + 8.0f) {
            correct(caretY - mid);      // unverzoegert sichtbar machen
            pinnedY = mid;
        } else pinnedY = caretY;        // sichtbar: exakt dort halten
    } else if (UiScrollGestureActive()) {
        // Nutzer-Scroll: Nagel folgt -- ABER nur im sichtbaren Bereich.
        // [Sonst wanderte der Nagel beim Scrollen unter die Tastatur
        // und die Korrektur zog das Feld anschliessend dorthin: das
        // Textfeld "sprang aus dem Viewport".]
        pinnedY = caretY;
        if (pinnedY > visBottom - 8.0f) pinnedY = visBottom - 8.0f;
        if (pinnedY < visTop + 8.0f)    pinnedY = visTop + 8.0f;
    } else {
        // Nagel muss selbst im freien Bereich liegen (die Tastatur-
        // ANIMATION schiebt visBottom jeden Frame -- der Nagel wandert
        // dann mit in die Mitte, das Feld bleibt IMMER sichtbar).
        if (pinnedY > visBottom - 8.0f || pinnedY < visTop + 8.0f)
            pinnedY = mid;
        float dy = caretY - pinnedY;
        if (dy > 0.5f || dy < -0.5f) correct(dy);
    }
    // SICHERHEITSNETZ (immer, unabhaengig vom Nagel-Zustand): Liegt der
    // Caret trotz allem ausserhalb des freien Bereichs, wird er sofort
    // hineingezogen. Liegt er drin, passiert GARNICHTS -- dann sieht es
    // aus, als haette sich nichts verschoben.
    {
        float cNow = ime.InputPos.y + ime.InputLineHeight * 0.5f;
        if (cNow > visBottom - 4.0f) {
            correct(cNow - (visBottom - 8.0f));
            pinnedY = visBottom - 8.0f;
        } else if (cNow < visTop + 4.0f) {
            correct(cNow - (visTop + 8.0f));
            pinnedY = visTop + 8.0f;
        }
    }
    prevVisible = imeVisible;
}

bool UiPagesFrameNurWarm() {
    if (ui_pages_detail::g_warmFrames <= 0) return false;
    --ui_pages_detail::g_warmFrames;
    return true;
}
void UiFixedHeightEnforce() {
    using namespace ui_pages_detail;
    // Gegenstueck zum Alpha-Push am Ende von UiPagesFrame() -- IMMER
    // paarig, sonst bricht ImGui mit einer Assertion ab.
    if (g_settleAlphaPushed) {
        ImGui::PopStyleVar();
        g_settleAlphaPushed = false;
    }
    // Pfeil-Menue hier mitfahren lassen: laeuft damit auf ALLEN
    // Plattformen am Frame-Ende, ohne die main-Dateien anzufassen --
    // und das Panel liegt als letztes Submit obenauf.
    UiWindowPropsMenuFrame();
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g) return;
    float minY = ImGui::GetStyle().WindowMinSize.y;
    int found = 0, applied = 0;
    for (ImGuiWindow* w : g->Windows) {
        if (!w->WasActive) continue;
        if (w->Flags & (ImGuiWindowFlags_ChildWindow
                        | ImGuiWindowFlags_Tooltip
                        | ImGuiWindowFlags_Popup)) continue;
        auto it = g_winProps.find(UiPropsKey(w->Name));
        if (it == g_winProps.end() || !it->second.fixHeight) continue;
        ++found;
        // Y-RESIZE AN DER QUELLE ENTWAFFNEN: ImGui verarbeitet den
        // Rand-Drag im Begin (Frame-Anfang) -- der Frame-Ende-Schreiber
        // verliert waehrend des Zugs jede Runde. Haelt der Nutzer einen
        // Y-relevanten Griff (obere/untere Kante, Ecken), stirbt der
        // Zug hier sofort.
        if (g->ActiveId != 0 && g->ActiveIdWindow == w) {
            bool yGrip =
                g->ActiveId == ImGui::GetWindowResizeBorderID(
                                   w, ImGuiDir_Up)
             || g->ActiveId == ImGui::GetWindowResizeBorderID(
                                   w, ImGuiDir_Down);
            for (int c2 = 0; c2 < 4 && !yGrip; ++c2)
                if (g->ActiveId ==
                    ImGui::GetWindowResizeCornerID(w, c2))
                    yGrip = true;
            if (yGrip) ImGui::ClearActiveID();
        }
        // [Der gelbe "[fix]"-Marker stand hier als Debug-Nachweis der
        //  Durchsetzung. Entfernt: Er verdeckte die Kopfzeilen-Icons.]
        if (!w->DockIsActive) {
            // ImGuis EIGENE Auto-Fit-Rechnung (der Kern des nativen
            // AlwaysAutoResize): exakte Wunschgroesse INKLUSIVE aller
            // Dekorationen -- Kopfzeile, Padding, aufgeklappte Header.
            // Keine Handrechnung, keine verpassten Chrome-Anteile.
            if (w->SkipItems || w->ContentSizeIdeal.y < 1.0f) {
                if (it->second.goodWant > 1.0f)
                    ImGui::SetWindowSize(w,
                        ImVec2(w->Size.x, it->second.goodWant),
                        ImGuiCond_Always);
                continue;   // gecullt: letzte gueltige Hoehe halten
            }
            float want = ImGui::CalcWindowNextAutoFitSize(w).y;
            // TOTZONE: Bei Fenstern, deren Inhalt die Flaeche AUSFUELLT
            // (z.B. eine Liste in einem Child), ist want = Ist + Polster
            // -- ohne Totzone waechst das Fenster mit jedem Durchgang um
            // genau dieses Polster ("schrittweise immer groesser").
            if (w->ContentSizeIdeal.y >= w->InnerRect.GetHeight() - 2.0f
                && w->InnerRect.GetHeight() > 40.0f) {
                if (!it->second.adaptive) {
                    it->second.adaptive = true;
                    if (it->second.lockedH <= 1.0f)
                        it->second.lockedH = w->Size.y;
                    UIP_LOGF("FixH: '%s' fuellender Inhalt -> flexibel"
                            " (eingefroren bei %.0f)",
                            w->Name, it->second.lockedH);
                }
                continue;
            }
            float dvf = want - w->Size.y;
            if (fabsf(dvf) <= 24.0f) {
                it->second.goodWant = w->Size.y;   // gueltiger Ist-Wert
                continue;
            }
            it->second.goodWant = want;
            int fc = ImGui::GetFrameCount();
            if (it->second.streakFrame != fc) {
                it->second.streakFrame = fc;
                bool grows = it->second.lastWant > 0.0f
                          && want > it->second.lastWant + 1.0f;
                it->second.lastWant = want;
                if (grows) {
                    if (it->second.growStreak == 0)
                        it->second.baselineH = w->Size.y;
                    if (!it->second.adaptive
                        && ++it->second.growStreak >= 4) {
                        it->second.adaptive = true;
                        if (it->second.lockedH <= 1.0f)
                            it->second.lockedH =
                                it->second.baselineH > 1.0f
                                    ? it->second.baselineH : w->Size.y;
                        if (it->second.baselineH > 1.0f)
                            ImGui::SetWindowSize(w,
                                ImVec2(w->Size.x, it->second.baselineH),
                                ImGuiCond_Always);
                        UIP_LOGF("FixH: '%s' adaptiv -> flexibel "
                                "(Baseline %.0f)",
                                w->Name, it->second.baselineH);
                    }
                } else it->second.growStreak = 0;
            }
            if (!it->second.adaptive) {
                UIP_LOGF("W[%s]: frei %.0f -> %.0f",
                        w->Name, w->Size.y, want);
                ImGui::SetWindowSize(w, ImVec2(w->Size.x, want),
                                     ImGuiCond_Always);
            } else if (it->second.lockedH > 1.0f
                       && fabsf(w->Size.y - it->second.lockedH) > 0.5f) {
                // ADAPTIV + STATISCH = auf lockedH EINGEFROREN. [Vorher
                // tat die Durchsetzung fuer adaptive Fenster GAR nichts
                // -- die Statik-Checkbox war dort wirkungslos.]
                ImGui::SetWindowSize(w,
                    ImVec2(w->Size.x, it->second.lockedH),
                    ImGuiCond_Always);
            }
            continue;
        }
        ++applied;   // gedockt: unten im Baum-Pass behandelt
    }
    // BAUM-PAESSE: aktive Seite in ihrer Container-Hoehe verteilen;
    // schwebende Baeume mit Fixfenstern auf ihren Bedarf setzen.
    {
        ImVector<ImGuiID> seen;
        for (ImGuiWindow* w : g->Windows) {
            if (!w->WasActive || !w->DockIsActive || !w->DockNode)
                continue;
            ImGuiDockNode* top = w->DockNode;
            while (top->ParentNode) top = top->ParentNode;
            if (seen.contains(top->ID)) continue;
            seen.push_back(top->ID);
            if (top->ID == g_activeDockId) {
                UiPage* pg = UiActivePage();
                float needNow = UiNeedY(top, true);
                if (pg) g_pageNeed[pg->name] = needNow;
                // Ohne ein einziges statisches Fenster gibt es nichts
                // durchzusetzen -- dann gehoert das Layout ImGui allein
                // (jeder Pro-Frame-Schreiber waere nur Ratschen-Futter).
                if (UiHasFixed(top)
                    && UiMaxRigidDev(top, UiHasFlex(top)) > 3.0f) {
                    // SOFORT mit dem BEDARF verteilen statt mit der noch
                    // alten Containerhoehe: dockH zieht erst im naechsten
                    // Frame nach. In diesem Zwischenframe fehlte sonst
                    // Platz -> der flexible Nachbar wurde gequetscht und
                    // danach zurueckkorrigiert = Flimmern ("Doppler")
                    // plus das Vergreifen am Nachbarn.
                    float hUse = top->Size.y > needNow ? top->Size.y
                                                       : needNow;
                    UiAssignY(top, hUse);
                    // Zug an einer Grenze zwischen STATISCHEN Nachbarn
                    // stirbt sofort. STRENG GEZIELT: nur der DockSpace-
                    // Splitter selbst. [Die erste Fassung loeschte JEDE
                    // aktive Id, sobald eine Abweichung auftrat -- damit
                    // starben Buttons, Checkboxen, Slider und Tabs
                    // mitten im Klick.]
                    if (!UiHasFlex(top) && g->ActiveId != 0
                        && g->HoveredId == 0
                        && g->ActiveIdWindow
                        && g->ActiveIdWindow->RootWindow
                           && g->ActiveIdWindow->RootWindow->ID
                              != g->ActiveIdWindow->ID
                        && ImGui::IsMouseDragging(ImGuiMouseButton_Left,
                                                  0.0f)
                        && strstr(g->ActiveIdWindow->Name,
                                  "DockSpace") != nullptr)
                        ImGui::ClearActiveID();
                }
            } else if (!UiHasFlex(top)) {
                // Rein starrer Schwebe-Baum: exakt auf Bedarf setzen
                if (UiMaxRigidDev(top, false) <= 3.0f) continue;
                float need = UiNeedY(top, true);
                UiAssignY(top, need);
                if (top->HostWindow
                    && !(top->HostWindow->Flags
                         & ImGuiWindowFlags_ChildWindow))
                    ImGui::SetWindowSize(top->HostWindow,
                        ImVec2(top->HostWindow->Size.x,
                               need + top->HostWindow->TitleBarHeight),
                        ImGuiCond_Always);
            } else if (UiHasFixed(top)
                       && UiMaxRigidDev(top, true) > 3.0f) {
                // Schwebe-Baum MIT flexiblen Anteilen: Nutzergroesse
                // respektieren, nur die starren Blaetter exakt halten.
                UiAssignY(top, top->Size.y);
            }
        }
    }
    // SONDE J (Jitter): Pro Frame die Werte, die sich gegenseitig
    // treiben koennen -- Knotenhoehe, Sollhoehe, Inhaltshoehe,
    // Balkenzustand, Scrollbereich. Wechselt einer davon im Takt,
    // ist der Verursacher benannt.
    {
        static int jc = 0;
        if ((jc++ % 10) == 0) {
            ImGuiContext* gj = ImGui::GetCurrentContext();
            for (ImGuiWindow* w : gj->Windows) {
                if (!w->WasActive || !w->Name) continue;
                if (w->Flags & (ImGuiWindowFlags_ChildWindow
                                | ImGuiWindowFlags_Tooltip
                                | ImGuiWindowFlags_Popup)) continue;
                if (!strncmp(w->Name, "##", 2)) continue;
                float nodeH = (w->DockNode && !w->DockNode->ChildNodes[0])
                            ? w->DockNode->Size.y : -1.0f;
                auto itj = g_winProps.find(UiPropsKey(w->Name));
                UIP_LOGF("J[%s]: win=%.0f node=%.0f ideal=%.0f cont=%.0f "
                        "sbX=%d sbY=%.0f good=%.0f scrMax=%.0f",
                        w->Name, w->Size.y, nodeH, w->ContentSizeIdeal.y,
                        w->ContentSize.y, (int)w->ScrollbarX,
                        w->ScrollbarSizes.y,
                        itj != g_winProps.end() ? itj->second.goodWant : -1.0f,
                        w->ScrollMax.y);
            }
        }
    }
    // Sonde F: alle 2s -- werden Kandidaten ueberhaupt gefunden/gesetzt?
    static int fCnt = 0;
    if ((fCnt++ % 120) == 0 && found > 0)
        UIP_LOGF("FixH: %d fixiert, %d angewandt", found, applied);
}

void SavePageState(UiPage& pg, bool force) {
    using namespace ui_pages_detail;
    if (pg.compact) {
        // BERUHIGUNGSFENSTER: schuetzt den PERIODISCHEN Auto-Snap davor,
        // einen halb eingerasteten Baum zu fotografieren. Transitions-
        // Sicherungen (Tab-Wechsel, Toggle) MUESSEN dagegen immer
        // serialisieren (force) -- sonst geht genau die letzte Nutzer-
        // Umordnung beim Verlassen verloren.
        if (!force && ImGui::GetTime() - g_lastRebuild < 1.5) return;
        // Kompakt: den LIVE-Baum serialisieren (Splits, Verhaeltnisse,
        // Tab-Reihenfolge) -- nur wenn er existiert und Fenster traegt.
        if (ImGuiDockNode* root =
                ImGui::DockBuilderGetNode(PageDockId(pg))) {
            std::vector<LayoutNode> recs;
            SerializeNode(root, -1, recs);
            // SEITEN-FILTER: nur registrierte Fenster DIESER Seite in den
            // Baum aufnehmen. Fremde Fenster (z.B. historisch auf mehreren
            // Seiten registrierte) wuerden sonst in die Records der
            // falschen Seite wandern und bei jedem Wiederaufbau dort
            // eingedockt -- die "geteilten/korrumpierten" States.
            for (auto& r : recs) {
                std::vector<std::string> keep;
                for (auto& wn : r.windows)
                    for (auto& reg : pg.windows)
                        if (wn == reg) { keep.push_back(wn); break; }
                r.windows = std::move(keep);
            }
            bool any = false;
            for (auto& r : recs) if (!r.windows.empty()) any = true;
            if (any) {
                int next = 0;
                PruneNode* tree = BuildPrune(recs, 0, next);
                tree = Prune(tree);
                std::vector<LayoutNode> pruned;
                FlattenPrune(tree, -1, pruned);
                delete tree;
                // VERSTECKTE FENSTER BEWAHREN: Serialisiert wird nur der
                // LEBENDE Baum. Alles, was in diesem Frame nicht
                // gezeichnet wird (Shader-Canvas bei ausgeschaltetem
                // Fenster-Modus, Overlays, jedes gate-abhaengige
                // Fenster), fiel bisher ersatzlos aus den Records --
                // beim Zurueckwechseln war seine Dock-Position weg.
                // Deren alte Blatt-Eintraege werden daher uebernommen.
                {
                    auto& oldRecs = g_layout[pg.name];
                    for (const auto& orec : oldRecs) {
                        if (orec.axis != -1) continue;      // nur Blaetter
                        std::vector<std::string> keep;
                        for (const auto& wn : orec.windows) {
                            bool live = false;
                            for (const auto& pr : pruned)
                                for (const auto& w2 : pr.windows)
                                    if (w2 == wn) live = true;
                            if (live) continue;
                            ImGuiWindow* ww =
                                ImGui::FindWindowByName(wn.c_str());
                            bool drawn = ww && ww->WasActive;
                            bool reg = false;
                            for (const auto& r2 : pg.windows)
                                if (r2 == wn) reg = true;
                            if (reg && !drawn && !UserFreed(pg.name, wn))
                                keep.push_back(wn);   // versteckt: merken
                        }
                        if (!keep.empty()) {
                            // NIEMALS als zweite WURZEL anhaengen
                            // (parent = -1): RebuildFromLayout erwartet
                            // genau EINE Wurzel, das Waisen-Blatt bekam
                            // keine Knoten-ID und DockBuilderFinish lief
                            // in einen Null-Zugriff (SIGSEGV, Backtrace
                            // #00 DockBuilderFinish). Stattdessen an das
                            // ERSTE Blatt anhaengen -- das Fenster
                            // taucht damit im Verbund wieder auf statt
                            // heimatlos zu sein.
                            int leafIdx = -1;
                            for (int li = 0; li < (int)pruned.size(); ++li)
                                if (pruned[li].axis == -1
                                    && !pruned[li].windows.empty())
                                    { leafIdx = li; break; }
                            if (leafIdx >= 0)
                                for (auto& wn2 : keep)
                                    pruned[leafIdx].windows.push_back(wn2);
                        }
                    }
                }
                g_layout[pg.name] = std::move(pruned);
            }
        }
    }
    for (const auto& n : pg.windows) {
        ImGuiWindow* w = ImGui::FindWindowByName(n.c_str());
        if (!w) continue;
        if (w->DockIsActive) {
            if (w->DockNode) g_dock[pg.name][n] = w->DockNode->ID;
        } else {
            // Floatend -- AUCH im Kompakt-Modus sichern: ein bewusst
            // abgedocktes Fenster hatte sonst KEINEN Speicherort fuer
            // seine Position (imgui.ini ist abgeschaltet) und landete
            // nach jedem Neustart auf der Default-Position.
            // FREI-ZUSTAND SICHERN (pro Seite): Position + Groesse jedes
            // wirklich freien Fensters. [Dieser Zweig war durch einen
            // Refactoring-Fehler mit "else if (false)" stillgelegt --
            // seither wurden Frei-Daten NIE mehr erfasst; daher das nur
            // "teilweise" erhaltene State beim Tab-Wechsel.]
            // Dock-Guard: in Uebergangsframes noch gedockte Fenster nicht
            // erfassen (ihre Pos waere die Stapel-Koordinate).
            // ZUSAETZLICH: NIEMALS eine ungueltige Momentaufnahme sichern
            // (NaN/Inf, oder eine Groesse <= 0 -- kommt in genau dem
            // Uebergangsframe vor, in dem ein Fenster gerade erst entsteht
            // oder der EGL-Kontext kurz weg war). Eine SCHLECHTE
            // Momentaufnahme wuerde sonst dauerhaft in xbm.ini landen und
            // bei jedem kuenftigen Start erneut angewendet -- das war die
            // Wurzel von "manchmal nach dem Neustart alles ploetzlich viel
            // groesser".
            if (!w->DockIsActive
                && std::isfinite(w->Pos.x) && std::isfinite(w->Pos.y)
                && std::isfinite(w->Size.x) && std::isfinite(w->Size.y)
                && w->Size.x > 0.0f && w->Size.y > 0.0f)
                g_free[pg.name][n] = { w->Pos, w->Size };
        }
    }
}

void ApplyPageState(UiPage& pg) {
    using namespace ui_pages_detail;
    if (pg.compact) {
        // Kompakt einschalten: Die gemerkten Dock-Knoten sind nur brauchbar,
        // wenn sie ALLE noch existieren -- nach dem Ausschalten raeumt ImGui
        // leere Knoten weg, die gespeicherten IDs zeigen dann ins Nichts und
        // das Wieder-Eindocken verpufft (alle Fenster ausser dem direkt nach
        // der Durchsetzung gezeichneten Monitor blieben frei). In dem Fall:
        // Grundstapel-Aufbau erzwingen -- der Pfad, der zuverlaessig traegt.
        if (!g_layout[pg.name].empty()) {
            pg.needLayout = true;      // exakte Gruppierung wiedererrichten
            return;
        }
        bool allNodesAlive = !g_dock[pg.name].empty();
        for (const auto& n : pg.windows) {
            auto it = g_dock[pg.name].find(n);
            if (it == g_dock[pg.name].end()) continue;
            if (!ImGui::DockBuilderGetNode(it->second))
                { allNodesAlive = false; break; }
        }
        if (!allNodesAlive || !ImGui::DockBuilderGetNode(PageDockId(pg))) {
            g_dock[pg.name].clear();       // tote IDs verwerfen
            pg.needRebuild = true;         // frischer, garantierter Stapel
        }
    } else {
        auto& fm = g_free[pg.name];
        for (const auto& n : pg.windows) {
            ImGui::DockBuilderDockWindow(n.c_str(), 0);    // ausdocken
            auto it = fm.find(n);
            if (it != fm.end())
                g_pendingFree[n] = it->second;   // Anwendung folgt, sobald frei
        }
    }
}

void UiResizePushNeighbors(bool enabled) {
    using namespace ui_pages_detail;
    ImGuiContext* g = ImGui::GetCurrentContext();
    static ImGuiID pid = 0; static ImVec2 pPos, pSize;
    if (!enabled || !g) { pid = 0; return; }
    // Treiber bestimmen: bewegtes Fenster (Titel-Drag) ODER aktives
    // Resize ueber Rand-/Ecken-IDs.
    ImGuiWindow* w = nullptr;
    if (g->MovingWindow && !g->MovingWindow->DockIsActive)
        w = g->MovingWindow;
    if (!w && g->ActiveId != 0 && g->ActiveIdWindow
        && !g->ActiveIdWindow->DockIsActive) {
        ImGuiWindow* cand = g->ActiveIdWindow;
        bool isResize = false;
        for (int d = 0; d < 4 && !isResize; ++d)
            if (g->ActiveId ==
                ImGui::GetWindowResizeBorderID(cand, (ImGuiDir)d))
                isResize = true;
        for (int n = 0; n < 4 && !isResize; ++n)
            if (g->ActiveId == ImGui::GetWindowResizeCornerID(cand, n))
                isResize = true;
        if (isResize) w = cand;
    }
    if (!w) { pid = 0; return; }
    if (pid != w->ID) { pid = w->ID; pPos = w->Pos; pSize = w->Size; return; }

    float dR = (w->Pos.x + w->Size.x) - (pPos.x + pSize.x);
    float dB = (w->Pos.y + w->Size.y) - (pPos.y + pSize.y);
    float dL = pPos.x - w->Pos.x;
    float dT = pPos.y - w->Pos.y;
    pPos = w->Pos; pSize = w->Size;

    struct Push { ImGuiWindow* win; int dir; float amt; };
    std::vector<Push> q;
    auto enq = [&](ImGuiWindow* src, int dir, float amt) {
        if (amt > 0.5f) q.push_back({ src, dir, amt });
    };
    enq(w, 0, dR); enq(w, 1, dB); enq(w, 2, dL); enq(w, 3, dT);

    float barBottom = ImGui::GetMainViewport()->WorkPos.y + g_barH;
    int guard = 0;
    while (!q.empty() && guard++ < 64) {
        Push p = q.back(); q.pop_back();
        float sL = p.win->Pos.x, sT = p.win->Pos.y;
        float sR = sL + p.win->Size.x, sB = sT + p.win->Size.y;
        for (ImGuiWindow* o : g->Windows) {
            if (o == p.win || o == w || !o->WasActive || o->DockIsActive)
                continue;
            if (o->Flags & (ImGuiWindowFlags_ChildWindow
                            | ImGuiWindowFlags_Tooltip
                            | ImGuiWindowFlags_Popup)) continue;
            if (!strncmp(o->Name, "##page_", 7)) continue;
            if (!strncmp(o->Name, "##drawer", 8)) continue;
            if (!strncmp(o->Name, "##nodegrab", 10)) continue;
            if (!strcmp(o->Name, "Navigation")) continue;
            float oL = o->Pos.x, oT = o->Pos.y;
            float oR = oL + o->Size.x, oB = oT + o->Size.y;
            float shift = 0.0f; ImVec2 np = o->Pos;
            switch (p.dir) {
            case 1:   // Unterkante drueckt nach unten
                if (oR > sL + 2 && oL < sR - 2 && oT < sB && oB > sT
                    && oT >= sB - p.amt - 1.0f)
                    { shift = sB - oT; np.y += shift; }
                break;
            case 3:   // Oberkante drueckt nach oben
                if (oR > sL + 2 && oL < sR - 2 && oB > sT && oT < sB
                    && oB <= sT + p.amt + 1.0f) {
                    shift = oB - sT; np.y -= shift;
                    if (np.y < barBottom) {          // Leisten-Sperrzone
                        shift -= (barBottom - np.y);
                        np.y = barBottom;
                    }
                }
                break;
            case 0:   // rechte Kante drueckt nach rechts
                if (oB > sT + 2 && oT < sB - 2 && oL < sR && oR > sL
                    && oL >= sR - p.amt - 1.0f)
                    { shift = sR - oL; np.x += shift; }
                break;
            case 2:   // linke Kante drueckt nach links
                if (oB > sT + 2 && oT < sB - 2 && oR > sL && oL < sR
                    && oR <= sL + p.amt + 1.0f)
                    { shift = oR - sL; np.x -= shift; }
                break;
            }
            if (shift > 0.5f) {
                ImGui::SetWindowPos(o, np, ImGuiCond_Always);
                enq(o, p.dir, shift);   // Kaskade an DESSEN Nachbarn
            }
        }
    }
}

namespace ui_pages_detail {

float UiLeafWantY(ImGuiDockNode* n) {
    float want = 0.0f;
    for (int i = 0; i < n->Windows.Size; ++i) {
        ImGuiWindow* w = n->Windows[i];
        if (!w->DockTabIsVisible) continue;
        // Auto-Fit des Fensterinhalts + Tab-Leiste des Knotens (das
        // gedockte Fenster selbst traegt keine Titelzeile).
        // +2px RUNDUNGS-POLSTER: Die Ratio-Verteilung des Dock-
        // Layouts rundet Knotenhoehen ab -- ohne Polster fehlte dem
        // Inhalt 1px und die Scrollleiste erschien (und konnte am
        // Schwellwert flackernd Layout-Zuckungen ausloesen). Die
        // 2px Uebergroesse schluckt die Ueberschuss-Toleranz des
        // Ereignis-Gates lautlos.
        // + ScrollbarSizes.y: Ist die HORIZONTALE Leiste aktiv (lange
        // Zeilen, z.B. Eingabe-Monitor), konsumiert sie ~14px Hoehe --
        // CalcWindowNextAutoFitSize rechnet den Idealfall OHNE Quer-
        // balken, der reale Balken beschnitt den Inhalt und rief die
        // vertikale Leiste auf den Plan.
        // CULLING-SCHUTZ: Liegt das Fenster ausserhalb des sichtbaren
        // Scrollbereichs, ueberspringt ImGui seinen Inhalt (SkipItems)
        // -- ContentSizeIdeal bricht auf ~0 ein und die Hoehe wurde
        // faelschlich geschrumpft ("Zeilen abgeschnitten", waechst erst
        // beim Zurueckscrollen). Dann gilt die letzte GUELTIGE Messung.
        UiWinProps& wpc = UiPropsFor(w->Name);
        // ADAPTIV: keine Inhaltsmessung mehr -- entweder ist die Hoehe
        // EINGEFROREN (fixHeight -> lockedH gilt als Wunschhoehe) oder
        // das Blatt ist flexibel (UiLeafFixed liefert dann false und
        // dieser Rueckgabewert ist egal).
        if (wpc.sizeMode == 2 && !wpc.adaptive) {
            // INHALTSGESTEUERT: Messung unten entscheidet, lockedH wird
            // ignoriert.
        } else if (wpc.sizeMode == 2 && wpc.adaptive && wpc.minH > 1.0f) {
            // Fuellender Inhalt hat KEINE Inhaltshoehe -- hier gilt die
            // optionale Mindesthoehe.
            want = wpc.minH;
            continue;
        } else if (wpc.fixHeight && wpc.lockedH > 1.0f) {
            // STATISCH: Die vom NUTZER festgelegte Hoehe schlaegt jede
            // Inhaltsmessung -- in BEIDE Richtungen. [Vorher galt sie
            // nur fuer adaptive Fenster; sonst setzte die Messung
            // (bzw. der alte goodWant beim Culling-Rueckfall) eine
            // Untergrenze weit ueber dem echten Inhalt: vergroessern
            // ging, verkleinern ab dieser Grenze nicht mehr.] Zu wenig
            // Platz fuer den Inhalt ist erlaubt -- dann wird gescrollt.
            want = wpc.lockedH;
            continue;
        }
        if (wpc.adaptive) continue;
        if (w->SkipItems || w->ContentSizeIdeal.y < 1.0f) {
            if (wpc.goodWant > 1.0f) { want = wpc.goodWant; continue; }
        }
        want = ImGui::CalcWindowNextAutoFitSize(w).y
             + ImGui::GetFrameHeight() + w->ScrollbarSizes.y + 2.0f;
        // ANTI-AUFSCHAUKELN bei FUELLENDEM Inhalt (Liste/Canvas im
        // Child): Dort ist die Wunschhoehe = Ist + Chrome (Polster PLUS
        // eingerechnete Scrollleisten-Hoehe) -- also bis zu ~20px mehr,
        // und die alte 4px-Totzone griff nicht: Das Fenster stieg bei
        // jedem Auslauf eine Stufe hoeher. WACHSTUM innerhalb der
        // Chrome-Spanne wird daher ignoriert; SCHRUMPFEN (echter
        // Inhaltsverlust) bleibt ab 4px erlaubt.
        // FUELLENDER INHALT = keine echte Inhaltshoehe: Nutzt ein
        // Fenster eine Kindregion, die die Flaeche ausfuellt (Bookmark-
        // Liste, Canvas), ist seine "Wunschhoehe" immer Ist+Chrome. Als
        // statisch behandelt kriecht es und pendelt an den Totzonen-
        // grenzen. Solche Fenster gelten daher als FLEXIBEL.
        if (w->ContentSizeIdeal.y >= w->InnerRect.GetHeight() - 2.0f
            && w->InnerRect.GetHeight() > 40.0f) {
            if (!wpc.adaptive) {
                wpc.adaptive = true;
                if (wpc.lockedH <= 1.0f) wpc.lockedH = n->Size.y;
                UIP_LOGF("FixH: '%s' fuellender Inhalt -> flexibel"
                        " (eingefroren bei %.0f)", w->Name, wpc.lockedH);
            }
            continue;
        }
        // KAMPF-ERKENNUNG: Das Log zeigt "assign 908 -> 944" in Endlos-
        // schleife -- wir schreiben 944, ImGui setzt 908 zurueck, wir
        // schreiben erneut. Genau daraus entstehen Doppler und Zittern.
        // Bleibt unsere Schreibung mehrfach nicht stehen, ist die
        // Inhaltshoehe fuer dieses Fenster nicht durchsetzbar: Es gilt
        // ab dann als FLEXIBEL und wird in Ruhe gelassen.
        if (wpc.lastWrite > 1.0f
            && fabsf(n->Size.y - wpc.lastWrite) > 1.0f) {
            if (++wpc.fightCount >= 5) {
                wpc.adaptive = true;
                if (wpc.lockedH <= 1.0f) wpc.lockedH = n->Size.y;
                UIP_LOGF("FixH: '%s' nicht durchsetzbar -> flexibel "
                        "(soll %.0f, ist %.0f)",
                        w->Name, wpc.lastWrite, n->Size.y);
                continue;
            }
        } else wpc.fightCount = 0;

        // SYMMETRISCHE Totzone: Die fruehere asymmetrische Fassung
        // (Wachstum bis 24px ignorieren, Schrumpfen schon ab 4px
        // ausfuehren) WAR der Oszillator -- Sonde J zeigte den Zyklus
        // 893 -> 881 -> 869 -> 893 bei voellig konstantem Inhalt:
        // zweimal 12px schrumpfen, dann 24px zurueckspringen. Beide
        // Richtungen brauchen dieselbe Schwelle.
        float dv = want - n->Size.y;
        if (fabsf(dv) <= 24.0f) {
            want = n->Size.y;
            wpc.goodWant = want;   // NUR den tatsaechlich gueltigen Wert
            continue;              // merken -- der Vorab-Durchlauf wendet
        }                          // goodWant an: mit dem aufgeblaehten
        wpc.goodWant = want;       // "Ist+Chrome" waere er ein Motor fuer
                                   // staendiges Wachsen gewesen.
        UiWinProps& wp = UiPropsFor(w->Name);
        int fc = ImGui::GetFrameCount();
        if (wp.streakFrame != fc) {   // FRAME-GUARD: diese Funktion
            wp.streakFrame = fc;      // laeuft MEHRFACH pro Frame
            // ECHTE Rueckkopplungs-Signatur: der SOLLWERT SELBST waechst
            // von Frame zu Frame. "Soll > Ist" allein genuegt nicht --
            // beim Eingabe-Monitor ist das nach dem Scrollleisten-
            // Zuschlag dauerhaft wahr, ohne dass etwas eskaliert; er
            // wurde dadurch faelschlich als adaptiv abgestempelt,
            // verlor die Statik und bekam eine Scrollleiste.
            bool grows = wp.lastWant > 0.0f && want > wp.lastWant + 1.0f;
            wp.lastWant = want;
            if (grows) {
                if (wp.growStreak == 0) wp.baselineH = n->Size.y;
                if (!wp.adaptive && ++wp.growStreak >= 4) {
                    wp.adaptive = true;
                    if (wp.lockedH <= 1.0f)
                        wp.lockedH = wp.baselineH > 1.0f ? wp.baselineH
                                                         : n->Size.y;
                    // Angesammelten Fehl-Zuwachs zuruecknehmen
                    if (wp.baselineH > 1.0f) {
                        n->Size.y    = wp.baselineH;
                        n->SizeRef.y = wp.baselineH;
                    }
                    UIP_LOGF("FixH: '%s' adaptiv -> flexibel (Baseline "
                            "%.0f wiederhergestellt)",
                            w->Name, wp.baselineH);
                }
            } else wp.growStreak = 0;
        }
    }
    float minY = ImGui::GetStyle().WindowMinSize.y;
    if (want < minY) want = minY;
    // TASTATUR OFFEN: KEIN EINZELNES Fenster darf hoeher werden als der
    // sichtbare Bereich. [Der frueher hier versuchte Deckel auf dockH
    // war falsch: Er rechnete mit GetCursorScreenPos(), also einer
    // Bildschirmposition, die sich beim Scrollen der Seite mitbewegt --
    // dadurch wurde der Deckel beim Herunterscrollen groesser und die
    // Textflaeche wuchs mit. Hier greift die Grenze pro Fenster und
    // scroll-unabhaengig. Folgen WEITERE Fenster unter diesem, ist die
    // Summe groesser als der Schirm -- dann wird gescrollt, aber genau
    // dafuer und nicht wegen eines einzelnen zu hohen Fensters.]
    // VOLLBILD: exakt die Hoehe der Seite, nicht mehr und nicht weniger.
    for (int i = 0; i < n->Windows.Size; ++i) {
        ImGuiWindow* w = n->Windows[i];
        if (!w->DockTabIsVisible) continue;
        if (UiPropsFor(w->Name).fullscreen) {
            // GENAU die Hoehe, die der DockSpace bekommen hat -- keine
            // nachgebaute Formel. [Jede eigene Rechnung lag um Rand-
            // betraege daneben: der Host hat WindowPadding, die Leiste
            // ist mal g_tabsH und mal g_barH hoch. Genau diese paar
            // Pixel brachten die Seite zum Scrollen.]
            float full = UiPageViewportH();
            return full > 120.0f ? full : 120.0f;
        }
    }
    // KEIN EINZELNES Fenster hoeher als der sichtbare Bereich -- weder
    // mit noch ohne Tastatur. [Ohne diese Grenze war das Prototype-
    // Fenster ein paar Pixel zu hoch fuer die Seite, und die Seite
    // fing an zu scrollen, obwohl gar kein weiteres Fenster folgte.
    // Folgen WEITERE Fenster, ist die SUMME groesser als der Schirm --
    // dann wird gescrollt, aber eben deswegen.]
    // UNTERGRENZE: vier Zeilen. [Die Inhaltsmessung durfte ein Fenster
    //  beliebig klein machen -- "Login (Cookies)" wurde so niedrig, dass
    //  kein Griff mehr zu treffen war. Skaliert mit der Schrift, gilt
    //  damit auf dem Handy (3x) wie auf dem Desktop.]
    {
        const float boden = ImGui::GetFrameHeightWithSpacing() * 4.0f;
        if (want < boden) want = boden;
    }
    {
        float vis = UiVisHeight() - g_barH - ImGui::GetFrameHeightWithSpacing();
        if (vis < 120.0f) vis = 120.0f;
        if (want > vis)   want = vis;
    }
    return want;
}

void RebuildFromLayout(const std::string& pageName, ImGuiID dockId,
                              ImVec2 size,
                              const std::vector<std::string>& allowed) {
    auto it = g_layout.find(pageName);
    if (it == g_layout.end() || it->second.empty()) return;
    // SANITAETSPRUEFUNG: nur EIN Wurzelknoten (Index 0) ist zulaessig.
    // Zusaetzliche parent==-1-Eintraege wuerden zu Knoten ohne ID und
    // damit zum Null-Zugriff in DockBuilderFinish fuehren.
    {
        const auto& rr = it->second;
        for (size_t i = 1; i < rr.size(); ++i)
            if (rr[i].parent < 0) return;   // defekt: Aufbau ueberspringen
    }
    const auto& recs = it->second;
    ImGui::DockBuilderRemoveNode(dockId);
    const std::string& pgName = pageName;   // Parameter dieser Funktion
    ImGui::DockBuilderAddNode(dockId, ImGuiDockNodeFlags_DockSpace);
    // NULL-SICHER: liefert AddNode keinen Knoten (Docking-Flag fehlte in
    // diesem Frame o.ae.), Abbruch statt Absturz -- der Aufrufer laesst
    // needLayout stehen und wiederholt im naechsten Frame.
    if (ImGui::DockBuilderGetNode(dockId) == nullptr) return;
    ImGui::DockBuilderSetNodeSize(dockId, size);
    std::vector<ImGuiID> ids(recs.size(), 0);
    std::vector<int> childCount(recs.size(), 0);
    ids[0] = dockId;
    for (int i = 1; i < (int)recs.size(); ++i) {
        int par = recs[i].parent;
        bool first = (childCount[par]++ == 0);
        if (first) {
            // Beide Kinder des Elternknotens jetzt anlegen; zweites Kind
            // erhaelt seine ID beim Besuch (Serialisierung ist DFS: Kind 1
            // folgt nach dem kompletten Teilbaum von Kind 0).
            ImGuiID a = 0, b = 0;
            ImGuiDir dir = (recs[par].axis == 0) ? ImGuiDir_Left : ImGuiDir_Up;
            ImGui::DockBuilderSplitNode(ids[par], dir, recs[par].ratio,
                                        &a, &b);
            ids[i] = a;
            // b fuer das zweite Kind vormerken: wir speichern es im
            // Eltern-Slot um (ids[par] wird nicht mehr gebraucht).
            ids[par] = b;
        } else {
            ids[i] = ids[par];
        }
    }
    g_liveLeaf[pageName].clear();
    for (int i = 0; i < (int)recs.size(); ++i)
        if (recs[i].axis == -1)
            for (const auto& w : recs[i].windows) {
                bool reg = false;
                for (const auto& a : allowed)
                    if (a == w) { reg = true; break; }
                if (!reg) continue;   // fremde Records (Altdaten) ignorieren
                if (!UserFreed(pgName, w))
                    ImGui::DockBuilderDockWindow(w.c_str(), ids[i]);
                g_liveLeaf[pageName][w] = ids[i];
            }
    ImGui::DockBuilderFinish(dockId);
}

void UiAssignY(ImGuiDockNode* n, float h) {
    // KAMPF-ERKENNUNG IM VERTEILER: Das Log zeigt "assign 857 -> 893"
    // in Endlosschleife -- wir setzen 893, ImGui stellt 857 wieder her.
    // (Die frueher eingebaute Aufgeben-Logik sass im Durchsetzungs-Pfad,
    // der hier gar nicht beteiligt ist.) Bleibt die Zuweisung mehrfach
    // nicht stehen, ist die Inhaltshoehe nicht durchsetzbar: Das Blatt
    // gilt ab dann als FLEXIBEL und wird in Ruhe gelassen.
    if (!n->ChildNodes[0] && n->Windows.Size > 0) {
        static std::map<ImGuiID, std::pair<float,int>> s_fight;
        auto& fr = s_fight[n->ID];
        if (fr.first > 1.0f && fabsf(n->Size.y - fr.first) > 1.0f) {
            if (++fr.second >= 5) {
                for (int i = 0; i < n->Windows.Size; ++i) {
                    UiWinProps& wp = UiPropsFor(n->Windows[i]->Name);
                    if (!wp.adaptive) {
                        wp.adaptive = true;
                        if (wp.lockedH <= 1.0f) wp.lockedH = n->Size.y;
                        UIP_LOGF("FixH: '%s' nicht durchsetzbar -> "
                                "flexibel (soll %.0f, ist %.0f)",
                                n->Windows[i]->Name, fr.first, n->Size.y);
                    }
                }
                fr.second = 0;
                return;                 // nichts mehr erzwingen
            }
        } else fr.second = 0;
        fr.first = h;
        if (fabsf(n->Size.y - h) > 0.5f)
        {
            // UIP_LOGF("A[%s]: assign %.0f -> %.0f", n->Windows[0]->Name, n->Size.y, h);
        }
    }
    n->Size.y = h; n->SizeRef.y = h;
    if (!n->ChildNodes[0]) return;
    if (n->SplitAxis != ImGuiAxis_Y) {
        UiAssignY(n->ChildNodes[0], h);
        UiAssignY(n->ChildNodes[1], h);
        return;
    }
    float n0 = UiNeedY(n->ChildNodes[0], false);
    float n1 = UiNeedY(n->ChildNodes[1], false);
    float e  = h - n0 - n1;
    bool f0 = UiHasFlex(n->ChildNodes[0]);
    bool f1 = UiHasFlex(n->ChildNodes[1]);
    float h0 = n0, h1 = n1;
    // JEDES KIND BEKOMMT EXAKT SEINEN BEDARF. Ueberschuss wird NICHT
    // mehr an ein Geschwister verteilt -- er gehoert dem Container
    // (dockH waechst). Sonst wuchs beim Tippen der Nachbar (X Login) um
    // genau den Betrag, den der Monitor zulegte, und schrumpfte danach
    // wieder zurueck: Fenster aenderten ihre Maasse, weil sich der
    // INHALT EINES ANDEREN Fensters aenderte.
    if (e < 0.0f) {
        // Nur ein ZU KLEINER Container zwingt zum Kuerzen -- dann
        // zuerst die flexiblen Anteile, statische bleiben verschont.
        if (f0 && !f1)      h0 += e;
        else if (f1 && !f0) h1 += e;
        else {
            float wsum = n0 + n1;
            h0 += e * (wsum > 1.0f ? n0 / wsum : 0.5f);
            h1  = h - h0;
        }
        float minY = ImGui::GetStyle().WindowMinSize.y;
        if (h0 < minY) h0 = minY;
        if (h1 < minY) h1 = minY;
    }
    n->Size.y = h0 + h1; n->SizeRef.y = h0 + h1;
    UiAssignY(n->ChildNodes[0], h0);
    UiAssignY(n->ChildNodes[1], h1);
}

} // namespace ui_pages_detail
