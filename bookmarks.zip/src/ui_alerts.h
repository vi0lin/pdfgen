#pragma once
// ---------------------------------------------------------------------------
// ui_alerts.h -- allgemeine Alert-Leiste, GRUNDSAETZLICH fuer JEDE Art von
// Hinweis (Update verfuegbar, Netzwerkfehler, was immer spaeter dazukommt).
//
// [Vorgabe: Alerts erscheinen NICHT als Overlay ueber dem Inhalt, sondern
//  fahren von der oberen Tab-Leiste herab und VERSCHIEBEN den DockSpace um
//  ihre eigene Hoehe -- der Inhalt weicht ihnen also aus, statt verdeckt zu
//  werden. Das gilt fuer ALLE Alerts einheitlich, nicht nur fuer Updates:
//  darum eine eigene, von der Update-Logik unabhaengige Datei.]
//
// AUFRUF:
//   UiAlertZeigen("update", "Version 43 verfuegbar", "Installieren", []{...});
//   UiAlertSchliessen("update");
//   float hoehe = UiAlertsZeichnen(x, y, breite);   // einmal pro Frame, GANZ
//                                                    // OBEN, vor dem DockSpace
// "hoehe" ist die GESAMTE, gerade tatsaechlich verbrauchte Hoehe aller
// aktiven Alerts zusammen -- der Aufrufer addiert sie zu seinem "topbar"-
// Versatz, damit der DockSpace entsprechend weiter unten beginnt.
// ---------------------------------------------------------------------------
#include "imgui.h"
#include <string>
#include <vector>
#include <functional>
#include <algorithm>

enum class UiAlertArt { Info, Warnung, Fehler };

struct UiAlertEintrag {
    std::string id;             // eindeutig -- zweiter Aufruf mit derselben
                                 // id ERSETZT den bisherigen Text/Knopf,
                                 // statt eine zweite Zeile aufzumachen.
    std::string text;
    UiAlertArt  art = UiAlertArt::Info;
    std::string aktionsText;    // leer = kein Aktions-Knopf
    std::function<void()> aktion;
    bool schliessbar = true;
    // WEICHES EIN-/AUSBLENDEN statt hartem Sprung: eine neu erschienene
    // oder gerade geschlossene Zeile reisst sonst den DockSpace-Rand ruckig
    // mit -- bei einer Hoehenaenderung, die jeden Frame neu einfliesst,
    // faellt ein Sprung staerker auf als anderswo.
    float einblendT = 0.0f;     // 0..1
    bool  schliesstGerade = false;
};

inline std::vector<UiAlertEintrag> g_alerts;

// Zeigt einen Alert -- oder aktualisiert ihn, falls dieselbe id schon
// aktiv ist (Text/Knopf/Art werden ersetzt, die Ein-/Ausblend-Animation
// bleibt dabei unangetastet, damit ein wiederholtes "Update verfuegbar"
// nicht bei jedem Versions-Check neu aufblitzt).
inline void UiAlertZeigen(const std::string& id, const std::string& text,
                          UiAlertArt art = UiAlertArt::Info,
                          const std::string& aktionsText = "",
                          std::function<void()> aktion = nullptr,
                          bool schliessbar = true) {
    for (auto& a : g_alerts) {
        if (a.id == id) {
            a.text = text; a.art = art;
            a.aktionsText = aktionsText; a.aktion = std::move(aktion);
            a.schliessbar = schliessbar;
            a.schliesstGerade = false;   // falls gerade am Ausblenden war
            return;
        }
    }
    UiAlertEintrag e;
    e.id = id; e.text = text; e.art = art;
    e.aktionsText = aktionsText; e.aktion = std::move(aktion);
    e.schliessbar = schliessbar;
    g_alerts.push_back(std::move(e));
}

inline void UiAlertSchliessen(const std::string& id) {
    for (auto& a : g_alerts) if (a.id == id) a.schliesstGerade = true;
}

inline bool UiAlertVorhanden(const std::string& id) {
    for (const auto& a : g_alerts)
        if (a.id == id && !a.schliesstGerade) return true;
    return false;
}

// Farbe je Art -- angelehnt an die im Projekt sonst verwendete Palette
// (siehe EntryColor/Darken in ui_calendar.cpp), hier bewusst eigenstaendig
// gehalten, damit diese Datei ohne den Kalender einbindbar bleibt.
inline ImU32 UiAlertFarbe(UiAlertArt art) {
    switch (art) {
        case UiAlertArt::Warnung: return IM_COL32(120, 90, 20, 235);
        case UiAlertArt::Fehler:  return IM_COL32(120, 30, 30, 235);
        default:                 return IM_COL32(30, 70, 120, 235);
    }
}

// Zeichnet alle aktiven Alerts UNTEREINANDER, beginnend bei (x, y), ueber
// die volle angegebene Breite. Liefert die GESAMTE, in diesem Frame
// tatsaechlich verbrauchte Hoehe zurueck (inkl. laufender Ein-/Ausblend-
// Animation) -- der Aufrufer schiebt den DockSpace genau um diesen Betrag
// nach unten.
inline float UiAlertsZeichnen(float x, float y, float breite) {
    if (g_alerts.empty()) return 0.0f;

    ImDrawList* dl = ImGui::GetForegroundDrawList();
    ImGuiIO& io = ImGui::GetIO();
    const float zeilenH = ImGui::GetFrameHeight() * 1.8f;
    const float tempo = 8.0f;   // 1/Sekunden -- ca. 125ms Ein-/Ausblendzeit

    float laufendY = y;
    for (auto it = g_alerts.begin(); it != g_alerts.end(); ) {
        UiAlertEintrag& a = *it;
        // ANIMATION FORTSCHREIBEN.
        if (a.schliesstGerade) a.einblendT -= io.DeltaTime * tempo;
        else                   a.einblendT += io.DeltaTime * tempo;
        a.einblendT = a.einblendT < 0.0f ? 0.0f : (a.einblendT > 1.0f ? 1.0f : a.einblendT);
        if (a.schliesstGerade && a.einblendT <= 0.0f) {
            it = g_alerts.erase(it);
            continue;
        }

        const float h = zeilenH * a.einblendT;   // Hoehe folgt der Animation
        if (h > 0.5f) {
            const ImVec2 p0(x, laufendY), p1(x + breite, laufendY + h);
            dl->PushClipRect(p0, p1, true);
            dl->AddRectFilled(p0, p1, UiAlertFarbe(a.art));
            dl->AddLine(ImVec2(p0.x, p1.y - 1), ImVec2(p1.x, p1.y - 1),
                       IM_COL32(255, 255, 255, 40), 1.0f);

            // TEXT VERTIKAL MITTIG -- waehrend des Ein-/Ausblendens rutscht
            // er einfach mit der schrumpfenden Hoehe mit statt abgeschnitten
            // zu wirken.
            const float pad = 16.0f;
            ImGui::SetCursorScreenPos(ImVec2(p0.x + pad, p0.y));
            ImGui::PushID(a.id.c_str());
            ImGui::InvisibleButton("##alertzeile", ImVec2(breite - pad * 2, h));
            ImVec2 textSize = ImGui::CalcTextSize(a.text.c_str());
            float textY = p0.y + (h - textSize.y) * 0.5f;
            dl->AddText(ImVec2(p0.x + pad, textY),
                       IM_COL32(255, 255, 255, 255), a.text.c_str());

            // AKTIONS-KNOPF, rechtsbuendig vor dem Schliessen-Kreuz.
            float rechtsX = p1.x - pad;
            if (a.schliessbar) {
                const float xGr = h * 0.5f;
                rechtsX -= xGr;
                ImGui::SetCursorScreenPos(ImVec2(rechtsX - xGr * 0.5f,
                                                 p0.y + (h - xGr) * 0.5f));
                if (ImGui::InvisibleButton("##x", ImVec2(xGr, xGr))) {
                    a.schliesstGerade = true;
                }
                const ImVec2 c(rechtsX, p0.y + h * 0.5f);
                const float r = xGr * 0.28f;
                dl->AddLine(ImVec2(c.x - r, c.y - r), ImVec2(c.x + r, c.y + r),
                           IM_COL32(255, 255, 255, 220), 2.0f);
                dl->AddLine(ImVec2(c.x - r, c.y + r), ImVec2(c.x + r, c.y - r),
                           IM_COL32(255, 255, 255, 220), 2.0f);
                rechtsX -= xGr * 0.5f + pad;
            }
            if (!a.aktionsText.empty() && a.aktion) {
                ImVec2 bgroesse = ImGui::CalcTextSize(a.aktionsText.c_str());
                bgroesse.x += pad * 2; bgroesse.y = h * 0.7f;
                rechtsX -= bgroesse.x;
                ImGui::SetCursorScreenPos(ImVec2(rechtsX, p0.y + (h - bgroesse.y) * 0.5f));
                ImGui::PushStyleColor(ImGuiCol_Button, IM_COL32(255, 255, 255, 40));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, IM_COL32(255, 255, 255, 70));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, IM_COL32(255, 255, 255, 100));
                if (ImGui::Button(a.aktionsText.c_str(), bgroesse)) {
                    a.aktion();
                }
                ImGui::PopStyleColor(3);
            }
            ImGui::PopID();
            dl->PopClipRect();
        }
        laufendY += h;
        ++it;
    }
    return laufendY - y;
}
