#pragma once
// ui_textsel.h -- ziehbare AUSWAHLGRIFFE fuer InputTextMultiline.
//
// WARUM: Mit dem Finger laesst sich in ImGui zwar durch Ziehen markieren,
// aber die Auswahl danach an den Raendern zu VERAENDERN ist unmoeglich --
// jede neue Beruehrung setzt den Cursor und loescht die Markierung. Diese
// Datei zeichnet an Anfang und Ende der Auswahl je einen Griff, der sich
// ziehen laesst (wie in Android-Textfeldern).
//
// WIE ES SICH IN ImGui EINFUEGT: Waehrend ein Griff gezogen wird, darf das
// Textfeld die Maus NICHT sehen -- sonst setzt es den Cursor selbst. Der
// Trick ist die Reihenfolge: UiTextSelPre() laeuft VOR dem Feld und
// blendet in dem Fall den Mausknopf aus; UiTextSelPost() laeuft danach
// und zeichnet die Griffe.
//
// BENUTZUNG:
//     UiTextSelPre();                                  // vor dem Feld
//     UiInputTextMultiline("##source", "prototype.source", size);
//     UiTextSelPost(ImGui::GetItemID(),
//                   ImGui::GetItemRectMin(), ImGui::GetItemRectMax());
#include "imgui.h"
#include "imgui_internal.h"
#include "ui_helpers.h"   // UiDragHandledThisFrame
#include <string>

namespace ui_textsel_detail {

struct State {
    ImGuiID id        = 0;      // Feld, zu dem die Griffe gehoeren
    ImVec2  rmin, rmax;         // Feldrechteck (Bildschirm)
    ImVec2  hStart, hEnd;       // Griffpositionen (Bildschirm)
    bool    valid     = false;
    int     dragging  = 0;      // 0=nein, 1=Anfangsgriff, 2=Endgriff
};
inline State& S() { static State s; return s; }

inline float HandleR() {
    // FINGERTAUGLICH: Der Griff muss groesser sein als die Fingerkuppe
    // ihn treffen kann -- 0.55*Schriftgroesse war auf dem Handy zu klein.
    float r = ImGui::GetFontSize() * 0.75f;
    return r < 11.0f ? 11.0f : r;
}

// Byte-Index -> Bildschirmposition. InputTextMultiline bricht KEINE
// Zeilen um, deshalb genuegt: Zeile zaehlen, Breite des Zeilenanfangs
// messen.
inline ImVec2 PosOfIndex(const char* txt, int idx, const ImVec2& org,
                         float scrollX, float scrollY) {
    int line = 0;
    const char* lineStart = txt;
    for (int i = 0; i < idx && txt[i]; ++i)
        if (txt[i] == '\n') { ++line; lineStart = txt + i + 1; }
    const char* upTo = txt + idx;
    float w = ImGui::CalcTextSize(lineStart, upTo).x;
    return ImVec2(org.x + w - scrollX,
                  org.y + line * ImGui::GetTextLineHeight() - scrollY);
}

// Bildschirmposition -> Byte-Index (naechstliegend).
inline int IndexOfPos(const char* txt, const ImVec2& p, const ImVec2& org,
                      float scrollX, float scrollY) {
    float lineH = ImGui::GetTextLineHeight();
    int wantLine = (int)((p.y + scrollY - org.y) / (lineH > 1.0f ? lineH : 1.0f));
    if (wantLine < 0) wantLine = 0;
    int line = 0, i = 0, lineBegin = 0;
    for (; txt[i]; ++i) {
        if (txt[i] == '\n') {
            if (line == wantLine) break;
            ++line;
            lineBegin = i + 1;
        }
    }
    int lineEnd = i;                       // Zeilenende (oder Textende)
    if (line < wantLine) { lineBegin = lineEnd; }   // hinter letzter Zeile
    float targetX = p.x + scrollX - org.x;
    int best = lineBegin;
    float bestD = 1e9f;
    for (int k = lineBegin; k <= lineEnd; ++k) {
        // UTF-8: nur an Zeichengrenzen messen
        if (k > lineBegin && ((unsigned char)txt[k] & 0xC0) == 0x80) continue;
        float w = ImGui::CalcTextSize(txt + lineBegin, txt + k).x;
        float d = w - targetX;
        if (d < 0) d = -d;
        if (d < bestD) { bestD = d; best = k; }
    }
    return best;
}

} // namespace ui_textsel_detail

// VOR dem Textfeld aufrufen.
inline void UiTextSelPre() {
    using namespace ui_textsel_detail;
    State& s = S();
    ImGuiIO& io = ImGui::GetIO();
    if (!s.valid) return;

    // TREFFERZONE grosszuegig: auf dem Handy landet der Finger selten
    // exakt auf dem Kreis, und die Kuppe verdeckt ihn zudem.
    float r = HandleR() * 3.0f;
    if (s.dragging == 0 && io.MouseClicked[0]) {
        // Auf die PRESSPOSITION pruefen, nicht auf die aktuelle: bis
        // hierher ist der Finger oft schon ein Stueck gewandert.
        ImVec2 p = io.MouseClickedPos[0];
        // NICHT 'near' nennen! Unter Windows definiert windef.h die
        // 16-Bit-Altlasten 'near' und 'far' als LEERE MAKROS -- aus
        // "auto near = ..." wird "auto  = ...", und der Build bricht mit
        // "expected unqualified-id" ab. Gleiches gilt fuer 'far'.
        auto imGriff = [&](const ImVec2& h) {
            float dx = p.x - h.x, dy = p.y - h.y;
            return dx * dx + dy * dy <= r * r;
        };
        // Naeheren Griff nehmen, falls beide in Reichweite liegen
        // (kurze Auswahl: die Kreise ueberlappen sich dann).
        bool nS = imGriff(s.hStart), nE = imGriff(s.hEnd);
        if (nS && nE) {
            float dS = (p.x - s.hStart.x) * (p.x - s.hStart.x)
                     + (p.y - s.hStart.y) * (p.y - s.hStart.y);
            float dE = (p.x - s.hEnd.x) * (p.x - s.hEnd.x)
                     + (p.y - s.hEnd.y) * (p.y - s.hEnd.y);
            s.dragging = (dS <= dE) ? 1 : 2;
        } else if (nS) s.dragging = 1;
        else if (nE)   s.dragging = 2;
    }
    if (s.dragging != 0 && !io.MouseDown[0]) s.dragging = 0;

    if (s.dragging != 0) {
        // Die Pinpoint-Geste darf den Zug NICHT als Scrollen deuten --
        // sonst wandert das Fenster unter dem Finger weg.
        UiDragHandledThisFrame() = true;
        // Maus vor dem Feld verstecken: sonst setzt InputText den Cursor
        // und die Auswahl waere sofort wieder weg.
        io.MouseDown[0]    = false;
        io.MouseClicked[0] = false;
        io.MouseDownDuration[0] = -1.0f;
    }
}

// NACH dem Textfeld aufrufen (mit dessen ID und Rechteck).
inline void UiTextSelPost(ImGuiID id, const ImVec2& rmin, const ImVec2& rmax) {
    using namespace ui_textsel_detail;
    State& s = S();
    ImGuiInputTextState* st = ImGui::GetInputTextState(id);
    if (!st) { s.valid = false; s.dragging = 0; return; }

    const char* txt = st->GetText();
    int selA = st->GetSelectionStart();
    int selB = st->GetSelectionEnd();
    if (selA > selB) { int t = selA; selA = selB; selB = t; }

    ImGuiWindow* w = ImGui::GetCurrentWindow();
    ImVec2 org(rmin.x + ImGui::GetStyle().FramePadding.x,
               rmin.y + ImGui::GetStyle().FramePadding.y);
    float scrollX = st->Scroll.x, scrollY = st->Scroll.y;
    (void)w;

    s.id = id; s.rmin = rmin; s.rmax = rmax;

    // Ziehen wirkt auf die jeweilige Auswahlgrenze.
    if (s.dragging != 0) {
        ImGuiIO& io = ImGui::GetIO();
        int idx = IndexOfPos(txt, io.MousePos, org, scrollX, scrollY);
        if (s.dragging == 1) selA = idx; else selB = idx;
        if (selA > selB) { int t = selA; selA = selB; selB = t;
                           s.dragging = (s.dragging == 1 ? 2 : 1); }
        st->SetSelection(selA, selB);
        st->CursorAnimReset();
    }

    s.valid = (selB > selA);               // Griffe nur bei Auswahl
    if (!s.valid) return;

    s.hStart = PosOfIndex(txt, selA, org, scrollX, scrollY);
    s.hEnd   = PosOfIndex(txt, selB, org, scrollX, scrollY);
    float lineH = ImGui::GetTextLineHeight();
    // Deutlich UNTER die Zeile: sonst verdeckt die Fingerkuppe genau
    // die Textstelle, die man treffen will.
    s.hStart.y += lineH + HandleR() * 0.8f;
    s.hEnd.y   += lineH + HandleR() * 0.8f;

    // Nur zeichnen, wenn im sichtbaren Feldbereich.
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->PushClipRect(ImVec2(rmin.x - 20, rmin.y - 20),
                     ImVec2(rmax.x + 20, rmax.y + 20), true);
    ImU32 col = ImGui::GetColorU32(ImGuiCol_TextSelectedBg, 1.0f);
    ImU32 ring = ImGui::GetColorU32(ImGuiCol_Text);
    float rr = HandleR();
    for (int i = 0; i < 2; ++i) {
        ImVec2 h = i == 0 ? s.hStart : s.hEnd;
        if (h.y < rmin.y - 4 || h.y > rmax.y + rr) continue;
        dl->AddLine(ImVec2(h.x, h.y - lineH), h, ring, 1.5f);
        dl->AddCircleFilled(h, rr, col);
        dl->AddCircle(h, rr, ring, 0, 1.5f);
    }
    dl->PopClipRect();
}
