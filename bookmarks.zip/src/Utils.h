#pragma once
// ---------------------------------------------------------------------------
// Utils.h -- Protokollausgabe fuer alle Plattformen.
//
// WAS HIER FALSCH WAR (Android-Build brach damit ab):
//   #define UIP_LOGF(...) __android_log_print(ANDROID_LOG_INFO,"xbm",__VA_ARGS__)
//   inline void UIP_LOGF(std::string_view msg) { ... }
// Makro und Funktion trugen DENSELBEN NAMEN. Der Praeprozessor laeuft vor
// dem Compiler, also wurde die Funktionsdefinition selbst zur Makro-
// Aufrufstelle und expandierte zu
//   inline void __android_log_print(ANDROID_LOG_INFO,"xbm",std::string_view msg);
// Daher die Meldungen "variable has incomplete type 'void'",
// "expected '(' for function-style cast" und "expected unqualified-id".
// Ausserdem landeten dadurch alle UIP_LOGF("Text: "+string)-Aufrufe direkt
// bei __android_log_print, das an dritter Stelle einen  const char*  will --
// "no matching function for call to '__android_log_print'".
//
// Der Nicht-Android-Zweig hatte es bereits richtig geloest: benannte
// Ueberladungen (UipLog) und ein Makro, das nur WEITERLEITET. Genau das
// gilt jetzt fuer alle Plattformen; nur die Ausgabe selbst ist
// plattformabhaengig.
//
// Damit funktionieren weiterhin alle bisherigen Aufrufformen:
//   UIP_LOGF("fester Text")
//   UIP_LOGF("Pfad: " + std::string(p))     <-- ging auf Android vorher NICHT
//   UIP_LOGF(std::string_view{...})
//   UIP_LOGF("Wert %d von %s", n, s)
// ---------------------------------------------------------------------------

#ifdef __cplusplus

  #include <cstdarg>
  #include <cstdio>
  #include <string>
  #include <string_view>

  #ifdef __ANDROID__
    #include <android/log.h>
  #endif

namespace xbm_log_detail {

// EINZIGE Stelle, an der die Plattform eine Rolle spielt.
// %.*s mit ausdruecklicher Laenge: ein string_view ist NICHT
// nullterminiert, %s wuerde ueber das Ende hinauslesen.
// HAKEN FUER DAS PROTOKOLLFENSTER.
// [ui_log.h haengt sich hier ein, damit JEDE bestehende UIP_LOGF-Zeile
//  auch im Fenster landet -- ohne dass eine einzige Aufrufstelle geaendert
//  werden muss. Ein Funktionszeiger statt eines Includes, damit Utils.h
//  nichts ueber ImGui wissen muss und die Abhaengigkeit nur in eine
//  Richtung zeigt.]
inline void (*UipLogSink)(const char* text, int len) = nullptr;

inline void Emit(const char* data, int len) {
    if (UipLogSink && data) UipLogSink(data, len);
    if (!data) { data = "(null)"; len = 6; }
#ifdef __ANDROID__
    __android_log_print(ANDROID_LOG_INFO, "xbm", "%.*s", len, data);
#else
    std::printf("[xbm] %.*s\n", len, data);
#endif
}

}  // namespace xbm_log_detail

inline void UipLog(std::string_view s) {
    xbm_log_detail::Emit(s.data(), static_cast<int>(s.size()));
}
inline void UipLog(const std::string& s) {
    xbm_log_detail::Emit(s.c_str(), static_cast<int>(s.size()));
}
inline void UipLog(const char* s) {
    xbm_log_detail::Emit(s, s ? static_cast<int>(std::char_traits<char>::length(s)) : 0);
}

// printf-Stil: UIP_LOGF("Wert %d", n).
// Erst in einen Puffer formatieren, dann durch dieselbe Ausgabe schicken --
// so gilt auf Android dasselbe Ziel wie fuer alle anderen Formen, und die
// Zeile erscheint als EIN Protokolleintrag statt in Bruchstuecken.
template <class... A>
inline void UipLog(const char* fmt, A... a) {
    char buf[1024];
#if defined(__GNUC__) || defined(__clang__)
    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wformat-nonliteral"
#endif
    const int n = std::snprintf(buf, sizeof(buf), fmt, a...);
#if defined(__GNUC__) || defined(__clang__)
    #pragma GCC diagnostic pop
#endif
    if (n < 0) { UipLog("(Formatfehler)"); return; }
    // snprintf liefert die GEWUENSCHTE Laenge, nicht die geschriebene --
    // bei Ueberlauf sonst Lesen hinter dem Puffer.
    const int len = (n < static_cast<int>(sizeof(buf))) ? n
                                                        : static_cast<int>(sizeof(buf)) - 1;
    xbm_log_detail::Emit(buf, len);
}

// Das Makro leitet nur weiter -- es traegt bewusst NICHT den Namen einer
// Funktion, sonst beginnt das Spiel von vorn.
#define UIP_LOGF(...) UipLog(__VA_ARGS__)

#else  /* reines C */

  #include <stdio.h>
  #define UIP_LOGF(...) do { printf("[xbm] " __VA_ARGS__); printf("\n"); } while (0)

#endif  /* __cplusplus */

// Bewusst OHNE extern "C": die Definition in Utils.cpp ist C++ (sie fasst
// ImGui an). Ein extern "C" hier ergaebe unterschiedliche Bindungen und
// damit einen Linkfehler.
void BildschirmDiagnose(const char* format, ...);
