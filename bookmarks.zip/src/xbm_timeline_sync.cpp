#include "xbm_timeline_sync.h"
#include "xbm_timeline_adapter.h"
#include "xbm_netnode.h"
#include "xbm_cmdchan.h"
#include "fernausfuehrer.h"      // serverHaken: Fernauftraege der Jobs-Seite
#include <memory>
#include "sync.h"          // timeline
#include <map>

void UiCalendar_TimelineNeuLaden();   // ui_calendar.cpp

namespace xbm_tls {
namespace {
struct Z {
    XbmNetNode* node = nullptr;
    // Hub: eigene Verbindung
    std::string hubHost, hubGeheimnis; std::uint16_t hubPort = 0;
    std::unique_ptr<XbmCmdClient> hub; std::int64_t hubLetzterVersuchMs = 0;
    std::map<std::string, timeline::Partner> partner;   // Geraetename -> Stand
    std::int64_t naechsterLaufMs = 0;
    std::int64_t letzterEingangMs = 0;
    int empfangen = 0, gesendet = 0;
    bool angestossen = false;
};
Z& z() { static Z s; return s; }
const std::int64_t kTaktMs = 5000;

timeline::Partner& partnerFuer(const std::string& geraet) { timeline::Partner& p = z().partner[geraet]; p.geraet = geraet; return p; }

// Nachricht an einen Peer -- ueber netlink oder, beim Hub, ueber die eigene Verbindung.
bool senden(const std::string& peerId, const std::string& text, std::function<void(const std::string&)> cb) {
    if (peerId == "hub") { Z& s = z(); return s.hub && s.hub->GetStatus() == XbmCmdStatus::Bereit && s.hub->Nachricht(text, std::move(cb)); }
    return z().node && z().node->NachrichtAn(peerId, text, std::move(cb));
}
// Antwort eines Peers verarbeiten (Delta oder Bestaetigung) und ggf. weiterreden.
void antwort(const std::string& peerId, const std::string& text) {
    if (!xbm_tl::Geladen()) return;
    nlohmann::json ein = nlohmann::json::parse(text, nullptr, false); if (!ein.is_object()) return;
    const std::string von = ein.value("von", peerId);
    timeline::Partner& p = partnerFuer(von);
    const std::string typ = ein.value("typ", "");
    if (typ == "delta") {
        timeline::AbgleichErgebnis e = timeline::deltaAnwenden(xbm_tl::Speicher(), ein, p);
        z().empfangen += e.neu + e.uebernommen;
        if (e.neu + e.uebernommen > 0) { xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); }
        z().letzterEingangMs = XbmNetNode_JetztMs();
        // Bestaetigen, damit der Peer seinen Stand fortschreibt
        senden(peerId, timeline::bestaetigung(xbm_tl::Speicher(), p).dump(), [](const std::string&) {});
    } else if (typ == "bestaetigung") {
        timeline::bestaetigungAnwenden(ein, p);
    }
}
} // namespace

void Init(XbmNetNode& node) {
    z().node = &node;
    node.SetNachrichtenHaken([](const std::string& text, const std::string& adresse) -> std::string {
        nlohmann::json ein = nlohmann::json::parse(text, nullptr, false); if (!ein.is_object()) return "";
        const std::string typ = ein.value("typ", "");
        // FERNAUFTRAEGE (Jobs-Seite): "aktion" fuehrt der Fernausfuehrer hier aus.
        if (typ == "aktion") return netlink::serverHaken(text, adresse);
        if (!xbm_tl::Geladen()) return "";
        if (typ != "anfrage" && typ != "delta" && typ != "bestaetigung") return "";   // nicht unseres
        timeline::Partner& p = partnerFuer(ein.value("von", adresse));
        const std::size_t seqVorher = xbm_tl::Speicher().seq;
        nlohmann::json aus = timeline::verarbeiten(xbm_tl::Speicher(), ein, p);
        if (xbm_tl::Speicher().seq != seqVorher) { ++z().empfangen; xbm_tl::Speichern(); UiCalendar_TimelineNeuLaden(); z().letzterEingangMs = XbmNetNode_JetztMs(); }
        return aus.is_null() ? std::string() : aus.dump();
    });
}

void Anstossen() { z().angestossen = true; }

void Poll(std::int64_t jetztMs) {
    Z& s = z(); if (!xbm_tl::Geladen()) return;
    if (!s.node && s.hubHost.empty()) return;
    // HUB: eigene Verbindung pflegen (jeden Frame pollen, alle 30 s neu verbinden)
    if (!s.hubHost.empty()) {
        if (!s.hub) s.hub = std::make_unique<XbmCmdClient>();
        s.hub->Poll();
        const XbmCmdStatus st = s.hub->GetStatus();
        if (st != XbmCmdStatus::Bereit && st != XbmCmdStatus::Verbinde && jetztMs - s.hubLetzterVersuchMs > 30000) {
            s.hubLetzterVersuchMs = jetztMs; s.hub->Disconnect(); s.hub->Connect(s.hubHost, s.hubPort, s.hubGeheimnis);
        }
    }
    if (jetztMs < s.naechsterLaufMs && !s.angestossen) return;
    s.naechsterLaufMs = jetztMs + kTaktMs; s.angestossen = false;
    if (s.node) for (const XbmNetPeer& peer : s.node->Peers()) {
        if (jetztMs - peer.lastSeenMs > 60000) continue;             // lange nicht gesehen
        const std::string id = peer.id, name = peer.name;
        timeline::Partner& p = partnerFuer(name);
        // Erst fragen, was er hat ...
        senden(id, timeline::anfrage(xbm_tl::Speicher(), p).dump(), [id](const std::string& a) { antwort(id, a); });
        // ... dann schicken, was wir ihm schulden.
        if (timeline::ausstehend(xbm_tl::Speicher(), p) > 0) {
            ++s.gesendet;
            senden(id, timeline::delta(xbm_tl::Speicher(), p).dump(), [id](const std::string& a) { antwort(id, a); });
        }
    }
    if (s.hub && s.hub->GetStatus() == XbmCmdStatus::Bereit) {
        timeline::Partner& p = partnerFuer("hub"); const std::string id = "hub";
        senden(id, timeline::anfrage(xbm_tl::Speicher(), p).dump(), [id](const std::string& a) { antwort(id, a); });
        if (timeline::ausstehend(xbm_tl::Speicher(), p) > 0) { ++s.gesendet; senden(id, timeline::delta(xbm_tl::Speicher(), p).dump(), [id](const std::string& a) { antwort(id, a); }); }
    }
}

std::string Statuszeile() {
    Z& s = z(); std::string t = "Abgleich: " + std::to_string(s.partner.size()) + " Partner, " + std::to_string(s.empfangen) + " empfangen, " + std::to_string(s.gesendet) + " gesendet";
    if (!s.hubHost.empty()) t += std::string(", Hub ") + (HubVerbunden() ? "verbunden" : "nicht verbunden");
    if (s.letzterEingangMs) t += ", zuletzt vor " + std::to_string((XbmNetNode_JetztMs() - s.letzterEingangMs) / 1000) + " s";
    return t;
}

void HubSetzen(const std::string& host, std::uint16_t port, const std::string& geheimnis) {
    Z& s = z(); s.hubHost = host; s.hubPort = port; s.hubGeheimnis = geheimnis; s.hubLetzterVersuchMs = 0;
    if (host.empty() && s.hub) { s.hub->Disconnect(); s.hub.reset(); }
}
bool HubVerbunden() { Z& s = z(); return s.hub && s.hub->GetStatus() == XbmCmdStatus::Bereit; }

} // namespace xbm_tls
