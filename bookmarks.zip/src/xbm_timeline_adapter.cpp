#include "xbm_timeline_adapter.h"
#include "json.h"           // timeline: laden/speichern/migrieren
#include <cstdio>
#include <ctime>
#include <fstream>

namespace xbm_tl {
using timeline::Event; using timeline::Art; using timeline::Takt; using timeline::Aktion;
using json = nlohmann::json;
namespace { int zusatzInt(const timeline::Speicher& s, std::uint64_t id, const char* key); }

namespace {
struct Zustand { timeline::Speicher s; std::string datei; bool geladen = false; timeline::Zeit tz = 0; };
Zustand& Z() { static Zustand z; return z; }

bool dateiLesen(const std::string& p, std::string& aus) { std::ifstream f(p, std::ios::binary); if (!f) return false; aus.assign((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>()); return true; }
bool dateiSchreiben(const std::string& p, const std::string& s) { std::ofstream f(p + ".tmp", std::ios::binary); if (!f) return false; f << s; f.close(); std::remove(p.c_str()); return std::rename((p + ".tmp").c_str(), p.c_str()) == 0; }

// ---- Abbildung der Aktionsart ----
const char* artName(CalActionArt a) { static const char* n[] = { "alarm","ton","audio","pdf","mail","befehl" }; int i = (int)a; return (i >= 0 && i < 6) ? n[i] : "befehl"; }
CalActionArt artAusName(const std::string& n) {
    static const char* names[] = { "alarm","ton","audio","pdf","mail","befehl" };
    for (int i = 0; i < 6; ++i) if (n == names[i]) return (CalActionArt)i;
    return CalActionArt::Befehl;
}
} // namespace

timeline::Speicher& Speicher() { return Z().s; }
std::string Datei() { return Z().datei; }
bool Geladen() { return Z().geladen; }

timeline::Zeit LokaleZeitzone() {
    std::time_t t = std::time(nullptr); std::tm lt{}; std::tm gt{};
#if defined(_WIN32)
    localtime_s(&lt, &t); gmtime_s(&gt, &t);
#else
    localtime_r(&t, &lt); gmtime_r(&t, &gt);
#endif
    lt.tm_isdst = 0; gt.tm_isdst = 0;
    return (timeline::Zeit)(std::mktime(&lt) - std::mktime(&gt));
}

bool Laden(const std::string& dir, const std::string& geraet, timeline::Zeit tz) {
    Zustand& z = Z(); z.tz = tz; z.datei = dir + "/timeline.json"; z.s = timeline::Speicher(); z.s.geraet = geraet;
    std::string text;
    if (dateiLesen(z.datei, text)) {
        json j = json::parse(text, nullptr, false); std::string err;
        if (j.is_discarded() || !timeline::laden(z.s, j, &err)) { std::fprintf(stderr, "[timeline] %s: %s -- Kalender bleibt leer, Datei unangetastet\n", z.datei.c_str(), err.c_str()); return false; }
        z.s.geraet = geraet; z.geladen = true; return true;
    }
    // MIGRATION aus calendar.json (einmalig)
    const std::string alt = dir + "/calendar.json";
    if (dateiLesen(alt, text)) {
        json j = json::parse(text, nullptr, false);
        if (j.is_object()) {
            timeline::MigrationErgebnis me = timeline::migrierenAusCalendarJson(j, z.s, tz);
            std::fprintf(stderr, "[timeline] calendar.json migriert: %d Events, %d Kinder\n", me.events, me.kinder);
            if (Speichern()) { std::rename(alt.c_str(), (alt + ".v2").c_str()); }
        }
    }
    z.geladen = true; return true;
}

bool Speichern() {
    Zustand& z = Z(); if (z.datei.empty()) return false;
    return dateiSchreiben(z.datei, timeline::speichern(z.s).dump(1, '\t'));
}

// ---- timeline -> CalEntry ----
std::vector<CalEntry> Projizieren() {
    const timeline::Speicher& s = Z().s;
    std::vector<CalEntry> out;
    for (const auto& kv : s.events) {
        const Event& e = kv.second;
        // Abgeloeste Vorkommen ("nur diesen") sind sichtbare Einzeltermine.
        if (e.geloescht || e.istVorlage || e.eltern) continue;
        CalEntry c; c.id = e.id; c.start = e.start; c.durMin = e.durMin; c.allDay = e.allDay;
        c.gruppe = zusatzInt(s, e.id, "gruppe") != 0;
        c.title = timeline::wTitel(s, e); c.notes = timeline::wNotizen(s, e);
        c.color = timeline::wirksam<std::uint32_t>(s, e, [](const Event& x) -> const timeline::Opt<std::uint32_t>& { return x.farbe; }, 0u);
        const std::int32_t er = timeline::wErinnern(s, e); c.remindMin = er; c.remindOn = er >= 0;
        switch (e.regel.takt) {
            case Takt::Taeglich: c.wdh = CalWiederholung::Taeglich; break;
            case Takt::Woechentlich: c.wdh = (e.regel.wochentage == 0b0011111) ? CalWiederholung::Wochentags : CalWiederholung::Woechentlich; break;
            case Takt::Monatlich: c.wdh = CalWiederholung::Monatlich; break;
            case Takt::Jaehrlich: c.wdh = CalWiederholung::Jaehrlich; break;
            default: c.wdh = CalWiederholung::Nie; break;
        }
        c.wdhJede = e.regel.jede; c.wdhBis = e.regel.bis; c.wdhTage = e.regel.wochentage; c.wdhAnzahl = e.regel.anzahl;
        c.created = e.created; c.modified = e.stempel.modified; c.source = e.quelle;
        if (!e.zusatz.empty()) { json zu = json::parse(e.zusatz, nullptr, false);
            if (zu.is_object()) { c.audio = zu.value("audio", "");
                for (const auto& m : zu.value("memos", json::array())) { CalMemo mm; mm.audio = m.value("audio", ""); mm.transkript = m.value("transkript", ""); mm.aufgenommen = m.value("aufgenommen", (std::int64_t)0); mm.dauerMs = m.value("dauerMs", 0); c.memos.push_back(mm); } } }
        for (const Event* k : s.kinder(e.id)) {
            if (k->art == Art::Normal) continue;          // Unter-Termin: eigener Block, keine Erinnerung
            CalAction a; a.id = k->id; a.start = e.start + k->versatz; a.durMin = k->durMin; a.text = timeline::wTitel(s, *k);
            json p; timeline::Opt<Aktion> ak = timeline::wAktion(s, *k);
            if (k->art == Art::Aktion && ak.gesetzt) {
                // Aktionsname = Name im actionkit-Katalog ("befehl", "audio", "pdf", "mail");
                // der eigentliche Befehl/Pfad steht als Eingang "ziel" im Parameter.
                // [Vorher stand die Kommandozeile selbst als Aktionsname -- der
                //  Planer suchte dann eine Aktion mit diesem Namen und fand keine.]
                a.art = artAusName(ak.wert.befehl);
                p = json::parse(ak.wert.parameter, nullptr, false);
                if (a.art == CalActionArt::Befehl && ak.wert.befehl != "befehl" && ak.wert.befehl != "Befehl") a.ziel = ak.wert.befehl;   // alte Daten
            }
            else { a.art = CalActionArt::Alarm; p = json::parse(k->zusatz, nullptr, false); if (p.is_object() && p.value("art", "") == "ton") a.art = CalActionArt::Ton; }
            if (p.is_object()) { if (a.ziel.empty()) a.ziel = p.value("ziel", ""); a.ton = p.value("ton", ""); a.aktiv = p.value("aktiv", true); a.getan = p.value("getan", false); a.statisch = p.value("statisch", false); }
            c.actions.push_back(a);
        }
        out.push_back(c);
    }
    return out;
}

// ---- CalEntry -> timeline ----
namespace {
template <class T> bool setzeOpt(timeline::Opt<T>& o, const T& w, bool leerHeisstRueckfall) {
    if (leerHeisstRueckfall && w == T{}) {
        if (!o.gesetzt) return false;
        o.loeschen(); return true;
    }
    if (o.gesetzt && o.wert == w) return false;
    o = w; return true;
}
// Event mit VORGEGEBENER Id anlegen (die Oberflaeche vergibt Ids selbst);
// ist sie belegt oder 0, bekommt es eine neue.
Event& anlegenMitId(timeline::Speicher& s, timeline::Id id, std::int64_t jetzt) {
    if (!id || s.events.count(id)) return s.anlegen(jetzt);
    Event e; e.id = id; e.created = jetzt; e.stempel = { jetzt, s.geraet };
    s.events[id] = e; s.notiere(id);
    if (id >= s.naechsteId) s.naechsteId = id + 1;
    return s.events[id];
}
bool kindUebernehmen(timeline::Speicher& s, Event& e, const CalAction& a, std::int64_t jetzt) {
    Event* k = s.finde(a.id); bool neu = false;
    if (!k) { k = &anlegenMitId(s, a.id, jetzt); neu = true; s.zuordnen(e.id, k->id, jetzt); }
    bool ge = neu;
    const Art art = (a.art == CalActionArt::Alarm || a.art == CalActionArt::Ton) ? Art::Benachrichtigung : Art::Aktion;
    if (k->art != art) { k->art = art; ge = true; }
    const timeline::Zeit v = a.start - e.start; if (k->versatz != v) { k->versatz = v; ge = true; }
    if (k->durMin != a.durMin) { k->durMin = a.durMin; ge = true; }
    if (setzeOpt(k->titel, a.text, true)) ge = true;
    json p; p["ziel"] = a.ziel; p["ton"] = a.ton; p["aktiv"] = a.aktiv; p["getan"] = a.getan; p["statisch"] = a.statisch;
    if (art == Art::Aktion) {
        Aktion ak = k->aktion.gesetzt ? k->aktion.wert : Aktion{};
        const std::string befehl = std::string(artName(a.art));   // Katalogname; die Kommandozeile liegt im Parameter "ziel"
        const std::string param = p.dump();
        if (!k->aktion.gesetzt || ak.befehl != befehl || ak.parameter != param) { ak.befehl = befehl; ak.parameter = param; k->aktion = ak; ge = true; }
    } else {
        p["art"] = artName(a.art); const std::string zu = p.dump();
        if (k->zusatz != zu) { k->zusatz = zu; ge = true; }
    }
    if (ge) s.geaendert(*k, jetzt);
    return ge;
}
} // namespace

int Uebernehmen(const std::vector<CalEntry>& entries, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; int n = 0;
    std::set<timeline::Id> gesehen;
    for (const CalEntry& c : entries) {
        Event* e = s.finde(c.id); bool ge = false;
        if (!e) { e = &anlegenMitId(s, c.id, jetzt); e->created = c.created ? c.created : jetzt; ge = true; }
        gesehen.insert(e->id);
        if (e->start != c.start) { e->start = c.start; ge = true; }
        if (e->durMin != c.durMin) { e->durMin = c.durMin; ge = true; }
        if (e->allDay != c.allDay) { e->allDay = c.allDay; ge = true; }
        if (setzeOpt(e->titel, c.title, false)) ge = true;
        if (setzeOpt(e->notizen, c.notes, false)) ge = true;
        if (setzeOpt(e->farbe, c.color, true)) ge = true;
        { const std::int32_t er = c.remindOn ? c.remindMin : -1; bool soll = er >= 0;
          if (soll) { if (!e->erinnernMin.gesetzt || e->erinnernMin.wert != er) { e->erinnernMin = er; ge = true; } }
          else if (e->erinnernMin.gesetzt) { e->erinnernMin.loeschen(); ge = true; } }
        timeline::Regel r = e->regel;
        switch (c.wdh) {
            case CalWiederholung::Taeglich: r.takt = Takt::Taeglich; break;
            case CalWiederholung::Wochentags: r.takt = Takt::Woechentlich; r.wochentage = 0b0011111; break;
            case CalWiederholung::Woechentlich: r.takt = Takt::Woechentlich; r.wochentage = c.wdhTage ? c.wdhTage : (std::uint8_t)(1u << timeline::wochentag(timeline::lokal(c.start, Z().tz).tage)); if (r.wochentage == 0b0011111) r.wochentage = c.wdhTage; break;
            case CalWiederholung::Monatlich: r.takt = Takt::Monatlich; break;
            case CalWiederholung::Jaehrlich: r.takt = Takt::Jaehrlich; break;
            default: r.takt = Takt::Nie; break;
        }
        r.jede = c.wdhJede < 1 ? 1 : c.wdhJede; r.bis = c.wdhBis; r.anzahl = c.wdhAnzahl < 0 ? 0 : c.wdhAnzahl;
        if (r.takt != e->regel.takt || r.jede != e->regel.jede || r.bis != e->regel.bis || r.wochentage != e->regel.wochentage || r.anzahl != e->regel.anzahl) { e->regel = r; ge = true; }
        if (e->quelle != c.source) { e->quelle = c.source; ge = true; }
        // Memos/Audio -> zusatz (nur diese Schluessel, Rest bleibt)
        { json zu = json::parse(e->zusatz.empty() ? "{}" : e->zusatz, nullptr, false); if (!zu.is_object()) zu = json::object();
          json memos = json::array(); for (const CalMemo& m : c.memos) memos.push_back(json{{"audio", m.audio},{"transkript", m.transkript},{"aufgenommen", m.aufgenommen},{"dauerMs", m.dauerMs}});
          if (c.memos.empty()) zu.erase("memos"); else zu["memos"] = memos;
          if (c.audio.empty()) zu.erase("audio"); else zu["audio"] = c.audio;
          const std::string neu = zu.empty() ? std::string() : zu.dump();
          if (e->zusatz != neu) { e->zusatz = neu; ge = true; } }
        // Kinder der ersten Ebene
        std::set<timeline::Id> kinderGesehen;
        for (const CalAction& a : c.actions) { if (kindUebernehmen(s, *e, a, jetzt)) ge = true; if (a.id) kinderGesehen.insert(a.id); else for (const Event* k : s.kinder(e->id)) kinderGesehen.insert(k->id); }
        for (const Event* k : std::vector<const Event*>(s.kinder(e->id))) if (k->art != Art::Normal && !kinderGesehen.count(k->id)) { s.loeschen(k->id, jetzt); ge = true; }
        if (ge) { s.geaendert(*e, jetzt); ++n; }
    }
    // Von der Oberflaeche entfernte Wurzel-Events -> Grabstein
    for (auto& kv : s.events) { Event& e = kv.second; if (e.geloescht || e.istVorlage || e.eltern) continue; if (!gesehen.count(e.id)) { s.loeschen(e.id, jetzt); ++n; } }
    return n;
}


// ---- Serientermin verschieben ----
std::uint64_t NurDiesen(std::uint64_t serie, std::int64_t vorkommenStart, std::int64_t neuerStart, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; Event* e = s.finde(serie); if (!e || !e->regel.aktiv()) return 0;
    Event& r = timeline::nurDiesen(s, *e, vorkommenStart, jetzt);
    if (r.start != neuerStart) { r.start = neuerStart; s.geaendert(r, jetzt); }
    return r.id;
}
std::uint64_t AbHier(std::uint64_t serie, std::int64_t vorkommenStart, std::int64_t neuerStart, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; Event* e = s.finde(serie); if (!e || !e->regel.aktiv()) return 0;
    Event& n = timeline::abHier(s, *e, vorkommenStart, jetzt);
    if (n.start != neuerStart) { n.start = neuerStart; s.geaendert(n, jetzt); }
    return n.id;
}


// ---- Unter-Events beliebig tief ----
namespace {
void unterbaumSammeln(const timeline::Speicher& s, timeline::Id eltern, int tiefe, std::vector<Knoten>& aus) {
    if (tiefe > 32) return;
    for (const Event* k : s.kinder(eltern)) {
        Knoten n; n.id = k->id; n.eltern = eltern; n.titel = timeline::wTitel(s, *k); n.versatzSek = k->versatz; n.durMin = k->durMin; n.tiefe = tiefe; n.aktion = k->art == Art::Aktion; n.termin = k->art == Art::Normal;
        aus.push_back(n);
        unterbaumSammeln(s, k->id, tiefe + 1, aus);
    }
}
} // namespace
std::vector<Knoten> Unterbaum(std::uint64_t eltern) { std::vector<Knoten> v; unterbaumSammeln(Z().s, eltern, 1, v); return v; }
std::uint64_t KindAnlegen(std::uint64_t eltern, const std::string& titel, std::int64_t versatzSek, int durMin, std::int64_t jetzt, bool termin) {
    timeline::Speicher& s = Z().s; if (!s.finde(eltern)) return 0;
    Event& k = s.anlegen(jetzt); k.art = termin ? Art::Normal : Art::Benachrichtigung; k.versatz = versatzSek; k.durMin = durMin; if (!titel.empty()) k.titel = titel;
    const std::uint64_t id = k.id;
    if (!s.zuordnen(eltern, id, jetzt)) { s.loeschen(id, jetzt); return 0; }
    return id;
}
bool KindAendern(std::uint64_t id, const std::string& titel, std::int64_t versatzSek, int durMin, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; Event* k = s.finde(id); if (!k || !k->eltern) return false;
    bool ge = false;
    if (setzeOpt(k->titel, titel, true)) ge = true;
    if (k->versatz != versatzSek) { k->versatz = versatzSek; ge = true; }
    if (k->durMin != durMin) { k->durMin = durMin; ge = true; }
    if (ge) s.geaendert(*k, jetzt);
    return true;
}
bool KindLoeschen(std::uint64_t id, std::int64_t jetzt) { timeline::Speicher& s = Z().s; Event* k = s.finde(id); if (!k || !k->eltern) return false; s.loeschen(id, jetzt); return true; }


// ---- Sichtbarkeit / Baumhelfer ----
namespace {
int zusatzInt(const timeline::Speicher& s, std::uint64_t id, const char* key) {
    const Event* e = s.finde(id); if (!e || e->zusatz.empty()) return 0;
    json z = json::parse(e->zusatz, nullptr, false); return z.is_object() ? z.value(key, 0) : 0;
}
void zusatzIntSetzen(timeline::Speicher& s, std::uint64_t id, const char* key, int wert, std::int64_t jetzt) {
    Event* e = s.finde(id); if (!e) return;
    json z = json::parse(e->zusatz.empty() ? "{}" : e->zusatz, nullptr, false); if (!z.is_object()) z = json::object();
    if (z.value(key, 0) == wert) return;
    if (wert == 0) z.erase(key); else z[key] = wert;
    e->zusatz = z.empty() ? std::string() : z.dump(); s.geaendert(*e, jetzt);
}
}
int  KinderSicht(std::uint64_t eltern) { return zusatzInt(Z().s, eltern, "kinderSicht"); }
void KinderSichtSetzen(std::uint64_t eltern, int modus, std::int64_t jetzt) { zusatzIntSetzen(Z().s, eltern, "kinderSicht", modus, jetzt); }
int  Sicht(std::uint64_t kind) { return zusatzInt(Z().s, kind, "sicht"); }
void SichtSetzen(std::uint64_t kind, int modus, std::int64_t jetzt) { zusatzIntSetzen(Z().s, kind, "sicht", modus, jetzt); }
std::uint64_t Wurzel(std::uint64_t id) { const timeline::Speicher& s = Z().s; for (int i = 0; i < 64; ++i) { const Event* e = s.finde(id); if (!e || !e->eltern) return e ? id : 0; id = e->eltern; } return 0; }
std::int64_t AbsoluterStart(std::uint64_t id) { const timeline::Speicher& s = Z().s; std::int64_t v = 0; for (int i = 0; i < 64; ++i) { const Event* e = s.finde(id); if (!e) return 0; if (!e->eltern) return e->start + v; v += e->versatz; id = e->eltern; } return 0; }
bool IstNachfahre(std::uint64_t id, std::uint64_t vorfahr) { const timeline::Speicher& s = Z().s; for (int i = 0; id && i < 64; ++i) { if (id == vorfahr) return true; const Event* e = s.finde(id); if (!e) return false; id = e->eltern; } return false; }


// ---- Vorlagen ----
std::vector<VorlageInfo> Vorlagen() {
    const timeline::Speicher& s = Z().s; std::vector<VorlageInfo> v;
    for (const auto& kv : s.events) { const Event& e = kv.second; if (!e.istVorlage || e.geloescht || e.eltern) continue;
        if (!e.zusatz.empty() && e.zusatz.find("\"queue\"") != std::string::npos) continue;   // Queue-Vorlagen: Jobs-Seite
        VorlageInfo i; i.id = e.id; i.titel = timeline::wTitel(s, e); i.durMin = e.durMin; i.kinder = (int)s.kinder(e.id).size(); v.push_back(i); }
    std::sort(v.begin(), v.end(), [](const VorlageInfo& a, const VorlageInfo& b) { return a.titel < b.titel; });
    return v;
}
std::uint64_t AlsVorlage(std::uint64_t eventId, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; const Event* q = s.finde(eventId); if (!q || q->eltern) return 0;
    Event& v = s.anlegen(jetzt);
    v.istVorlage = true; v.start = q->start; v.durMin = q->durMin; v.allDay = q->allDay; v.art = q->art;
    v.titel = timeline::wTitel(s, *q); v.notizen = timeline::wNotizen(s, *q);
    if (q->farbe.gesetzt) v.farbe = q->farbe;
    if (q->erinnernMin.gesetzt) v.erinnernMin = q->erinnernMin;
    if (q->aktion.gesetzt) v.aktion = q->aktion;
    v.zusatz = q->zusatz;
    const std::uint64_t vid = v.id;
    std::map<timeline::Id, timeline::Id> altNeu; timeline::teilbaumKopieren(s, eventId, vid, jetzt, altNeu);
    s.geaendert(*s.finde(vid), jetzt);
    return vid;
}
std::uint64_t AusVorlage(std::uint64_t vorlageId, std::int64_t start, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; const Event* v = s.finde(vorlageId); if (!v || !v->istVorlage) return 0;
    Event& e = s.anlegen(jetzt);
    e.vorlage = vorlageId; e.start = start; e.durMin = v->durMin; e.allDay = v->allDay; e.art = v->art;
    // Titel, Notizen, Farbe, Erinnerung, Aktion: NICHT setzen -> Rueckfall auf die Vorlage (R1)
    const std::uint64_t id = e.id;
    std::map<timeline::Id, timeline::Id> altNeu; timeline::teilbaumKopieren(s, vorlageId, id, jetzt, altNeu);
    s.geaendert(*s.finde(id), jetzt);
    return id;
}
bool VorlageLoeschen(std::uint64_t vorlageId, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; Event* v = s.finde(vorlageId); if (!v || !v->istVorlage) return false;
    timeline::vorlageAufloesen(s, vorlageId, jetzt);    // R2: Werte in die Instanzen
    s.loeschen(vorlageId, jetzt); return true;
}


// ---- Explorer ----
namespace {
void baumSammeln(const timeline::Speicher& s, timeline::Id id, timeline::Id eltern, std::int64_t start, int tiefe, std::vector<BaumKnoten>& aus) {
    const Event* e = s.finde(id); if (!e || tiefe > 32) return;
    BaumKnoten n; n.id = id; n.eltern = eltern; n.titel = timeline::wTitel(s, *e); n.start = start; n.durMin = e->durMin; n.tiefe = tiefe;
    n.art = e->art == Art::Aktion ? 2 : (e->art == Art::Benachrichtigung ? 1 : 0);
    if (!e->zusatz.empty()) { json z = json::parse(e->zusatz, nullptr, false); if (z.is_object()) n.aktiv = z.value("aktiv", true); }
    aus.push_back(n);
    std::vector<const Event*> kinder = s.kinder(id);
    std::sort(kinder.begin(), kinder.end(), [](const Event* a, const Event* b) { return a->versatz < b->versatz; });
    for (const Event* k : kinder) baumSammeln(s, k->id, id, start + k->versatz, tiefe + 1, aus);
}
}
std::vector<BaumKnoten> Baum(std::uint64_t wurzel) {
    std::vector<BaumKnoten> v; const timeline::Speicher& s = Z().s; const Event* w = s.finde(wurzel); if (!w) return v;
    baumSammeln(s, wurzel, 0, w->eltern ? AbsoluterStart(wurzel) : w->start, 0, v); return v;
}
bool Einhaengen(std::uint64_t id, std::uint64_t eltern, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; Event* e = s.finde(id); if (!e || id == eltern || e->istVorlage) return false;
    if (eltern && (!s.finde(eltern) || IstNachfahre(eltern, id))) return false;   // kein Zyklus
    const std::int64_t abs = e->eltern ? AbsoluterStart(id) : e->start;
    if (e->eltern) s.loesen(id, jetzt);
    if (!eltern) { e = s.finde(id); if (!e) return false; e->start = abs; s.geaendert(*e, jetzt); return true; }
    e = s.finde(id); if (!e) return false;
    e->versatz = abs - AbsoluterStart(eltern);
    if (!s.zuordnen(eltern, id, jetzt)) return false;
    if (e->art == Art::Normal && e->regel.aktiv()) { e->regel = timeline::Regel{}; }   // Kinder haben keine eigene Serie
    s.geaendert(*e, jetzt); return true;
}
std::uint64_t AusVorlageAlsKind(std::uint64_t vorlageId, std::uint64_t eltern, std::int64_t versatzSek, std::int64_t jetzt) {
    const std::uint64_t id = AusVorlage(vorlageId, AbsoluterStart(eltern) + versatzSek, jetzt);
    if (id && !Einhaengen(id, eltern, jetzt)) return 0;
    return id;
}
bool KindArtSetzen(std::uint64_t id, int art, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; Event* e = s.finde(id); if (!e) return false;
    const Art a = art == 2 ? Art::Aktion : (art == 1 ? Art::Benachrichtigung : Art::Normal);
    if (e->art == a) return true;
    e->art = a;
    if (a == Art::Aktion && !e->aktion.gesetzt) e->aktion = timeline::Aktion{};
    s.geaendert(*e, jetzt); return true;
}


// ---- Gruppen / Duplizieren ----
bool IstGruppe(std::uint64_t id) { return zusatzInt(Z().s, id, "gruppe") != 0; }
void GruppeGroesseAnpassen(std::uint64_t gruppe, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; Event* g = s.finde(gruppe); if (!g) return;
    std::vector<const Event*> k = s.kinder(gruppe); if (k.empty()) return;
    std::int64_t minV = k[0]->versatz, maxE = k[0]->versatz + (std::int64_t)k[0]->durMin * 60;
    for (const Event* c : k) { minV = std::min(minV, c->versatz); maxE = std::max(maxE, c->versatz + (std::int64_t)c->durMin * 60); }
    if (minV != 0) {   // Start auf das frueheste Mitglied, Versaetze nachziehen
        g->start += minV; for (const Event* c : k) { Event* w = s.finde(c->id); if (w) { w->versatz -= minV; s.geaendert(*w, jetzt); } }
        maxE -= minV;
    }
    const int d = (int)((maxE + 59) / 60); if (g->durMin != d) g->durMin = d;
    s.geaendert(*g, jetzt);
}
std::uint64_t GruppeBilden(const std::vector<std::uint64_t>& ids, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; if (ids.size() < 2) return 0;
    std::int64_t fruehester = 0; bool erst = true;
    for (std::uint64_t id : ids) { const Event* e = s.finde(id); if (!e) return 0; const std::int64_t a = e->eltern ? AbsoluterStart(id) : e->start; if (erst || a < fruehester) { fruehester = a; erst = false; } }
    Event& g = s.anlegen(jetzt); g.start = fruehester; g.titel = std::string("Gruppe");
    zusatzIntSetzen(s, g.id, "gruppe", 1, jetzt);
    const std::uint64_t gid = g.id;
    for (std::uint64_t id : ids) if (!Einhaengen(id, gid, jetzt)) return 0;
    GruppeGroesseAnpassen(gid, jetzt);
    return gid;
}
bool Ungruppieren(std::uint64_t gruppe, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; if (!IstGruppe(gruppe)) return false;
    std::vector<const Event*> k = s.kinder(gruppe); std::vector<timeline::Id> ids; for (const Event* c : k) ids.push_back(c->id);
    for (timeline::Id id : ids) Einhaengen(id, 0, jetzt);
    s.loeschen(gruppe, jetzt); return true;
}
std::uint64_t Duplizieren(std::uint64_t id, std::int64_t start, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; const Event* q = s.finde(id); if (!q) return 0;
    Event& n = s.anlegen(jetzt);
    n.start = start; n.durMin = q->durMin; n.allDay = q->allDay; n.art = q->art; n.regel = q->regel;
    n.titel = timeline::wTitel(s, *q); n.notizen = timeline::wNotizen(s, *q);
    if (q->farbe.gesetzt) n.farbe = q->farbe;
    if (q->erinnernMin.gesetzt) n.erinnernMin = q->erinnernMin;
    if (q->aktion.gesetzt) n.aktion = q->aktion;
    n.zusatz = q->zusatz; n.vorlage = q->vorlage;
    const std::uint64_t nid = n.id;
    std::map<timeline::Id, timeline::Id> altNeu; timeline::teilbaumKopieren(s, id, nid, jetzt, altNeu);
    s.geaendert(*s.finde(nid), jetzt); return nid;
}


// ---- Ausnahmen einer Serie (fuer die Oberflaeche) ----
std::vector<std::int64_t> Ausnahmen(std::uint64_t serie) {
    std::vector<std::int64_t> v; const Event* e = Z().s.finde(serie); if (!e) return v;
    for (const auto& a : e->ausnahmen) v.push_back(a.start);
    std::sort(v.begin(), v.end()); return v;
}
bool AusnahmeAufheben(std::uint64_t serie, std::int64_t start, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; Event* e = s.finde(serie); if (!e) return false;
    for (auto it = e->ausnahmen.begin(); it != e->ausnahmen.end(); ++it) if (it->start == start) {
        if (it->ersetztDurch) s.loeschen(it->ersetztDurch, jetzt);   // das abgeloeste Einzel-Event verschwindet mit
        e->ausnahmen.erase(it); s.geaendert(*e, jetzt); return true; }
    return false;
}


// ---- Queue-Vorlagen ----
std::vector<QueueVorlage> QueueVorlagen() {
    std::vector<QueueVorlage> v; const timeline::Speicher& s = Z().s;
    for (const auto& kv : s.events) {
        const Event& e = kv.second; if (!e.istVorlage || e.geloescht || e.eltern || e.zusatz.empty()) continue;
        json z = json::parse(e.zusatz, nullptr, false); if (!z.is_object() || !z.contains("queue")) continue;
        QueueVorlage q; q.id = e.id; q.name = timeline::wTitel(s, e); q.json = z["queue"].dump(); v.push_back(q);
    }
    std::sort(v.begin(), v.end(), [](const QueueVorlage& a, const QueueVorlage& b) { return a.name < b.name; });
    return v;
}
std::uint64_t QueueAnlegen(const std::string& name, const std::string& qjson, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; Event& e = s.anlegen(jetzt); e.istVorlage = true; e.titel = name; e.start = jetzt; e.durMin = 0;
    json z = json::object(); z["queue"] = json::parse(qjson, nullptr, false); if (z["queue"].is_discarded()) z["queue"] = json::object();
    e.zusatz = z.dump(); s.geaendert(e, jetzt); return e.id;
}
bool QueueSpeichern(std::uint64_t id, const std::string& name, const std::string& qjson, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; Event* e = s.finde(id); if (!e) return false;
    json z = e->zusatz.empty() ? json::object() : json::parse(e->zusatz, nullptr, false); if (!z.is_object()) z = json::object();
    json q = json::parse(qjson, nullptr, false); if (q.is_discarded()) return false;
    if (z.contains("queue") && z["queue"] == q && timeline::wTitel(s, *e) == name) return true;   // nichts geaendert
    z["queue"] = q; e->zusatz = z.dump(); e->titel = name; s.geaendert(*e, jetzt); return true;
}
bool QueueLoeschen(std::uint64_t id, std::int64_t jetzt) { timeline::Speicher& s = Z().s; if (!s.finde(id)) return false; s.loeschen(id, jetzt); return true; }


// ---- Papierkorb ----
std::vector<PapierkorbEintrag> Papierkorb() {
    std::vector<PapierkorbEintrag> v; const timeline::Speicher& s = Z().s;
    for (const auto& kv : s.events) {
        const Event& e = kv.second; if (!e.geloescht || e.eltern || e.istVorlage) continue;
        if (!e.zusatz.empty() && e.zusatz.find("\"queue\"") != std::string::npos) continue;
        PapierkorbEintrag p; p.id = e.id; p.titel = timeline::wTitel(s, e); p.start = e.start; p.geloeschtAm = e.stempel.modified; v.push_back(p);
    }
    std::sort(v.begin(), v.end(), [](const PapierkorbEintrag& a, const PapierkorbEintrag& b) { return a.geloeschtAm > b.geloeschtAm; });
    return v;
}
static void wiederherstellenRek(timeline::Speicher& s, timeline::Id id, std::int64_t jetzt, int tiefe) {
    Event* e = s.finde(id); if (!e || tiefe > 64) return;
    e->geloescht = false; s.geaendert(*e, jetzt);
    for (timeline::Id k : std::vector<timeline::Id>(e->kinder)) wiederherstellenRek(s, k, jetzt, tiefe + 1);
}
bool Wiederherstellen(std::uint64_t id, std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; Event* e = s.finde(id); if (!e || !e->geloescht) return false;
    wiederherstellenRek(s, id, jetzt, 0); return true;
}
int PapierkorbLeeren(std::int64_t jetzt) {
    timeline::Speicher& s = Z().s; int n = 0; std::vector<timeline::Id> weg;
    for (const auto& kv : s.events) if (kv.second.geloescht) weg.push_back(kv.first);
    for (timeline::Id id : weg) { s.events.erase(id); ++n; }
    (void)jetzt; return n;
}

} // namespace xbm_tl
