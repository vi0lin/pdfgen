#pragma once
// ui_files.h -- SICHERE Datei-Ein-/Ausgabe fuer die App.
//
// HINTERGRUND (Absturz "FORTIFY: fputs: null FILE*"):
// fopen() liefert bei Misserfolg NULL. Bionic (Androids libc) prueft das
// in fputs/fprintf/fgets nicht hoeflich, sondern bricht den Prozess per
// abort() ab. Ein ungeprueftes
//     FILE* f = fopen("bewerbung.txt", "w");
//     fputs(text, f);                       // <- f ist NULL -> SIGABRT
// ist auf Android also ein sofortiger Absturz statt eines stillen
// Fehlschlags.
//
// ZWEITER, WICHTIGERER PUNKT: Ein RELATIVER Pfad zeigt bei einer
// Android-App auf das aktuelle Arbeitsverzeichnis -- das ist "/" und
// dort darf niemand schreiben. Deshalb schlaegt fopen ueberhaupt erst
// fehl. Schreibbar ist nur internalDataPath
// (/data/user/0/<paket>/files). UiFilePath() setzt ihn davor.
//
// BENUTZUNG:
//     UiFilesSetBaseDir(app->activity->internalDataPath);   // einmalig
//     std::string txt;
//     if (UiReadFile("bewerbung.txt", txt)) { ... }
//     if (!UiWriteFile("bewerbung.txt", txt)) { /* Fehler melden */ }
#include <cstdio>
#include <string>
#include <vector>
#include <algorithm>
#if defined(_WIN32)
  #include <windows.h>
#else
  #include <dirent.h>
  #include <sys/stat.h>
#endif

// Basisverzeichnis (Android: internalDataPath; Desktop: leer = relativ).
inline std::string& UiFilesBaseDir() {
    static std::string d;
    return d;
}
inline void UiFilesSetBaseDir(const char* dir) {
    UiFilesBaseDir() = dir ? dir : "";
}
// Absoluter Pfad? Dann unveraendert lassen, sonst Basis davorsetzen.
inline std::string UiFilePath(const char* name) {
    if (!name || !*name) return std::string();
    if (name[0] == '/')  return std::string(name);
    if (std::string(name).substr(0,2) == "./") return UiFilesBaseDir()+"/"+std::string(name).substr(2,-1);
    const std::string& b = UiFilesBaseDir();
    if (b.empty())       return std::string(name);
    return b + "/" + name;
}
// overload
inline std::string UiFilePath(const std::string& name) {
  return UiFilePath(name.c_str());
}

// Liest die GANZE Datei. Rueckgabe false = nicht lesbar (out bleibt leer).
// Es wird NICHTS abgebrochen -- der Aufrufer entscheidet.
inline bool UiReadFile(const char* name, std::string& out) {
    out.clear();
    FILE* f = fopen(UiFilePath(name).c_str(), "rb");
    if (!f) return false;                       // <- die fehlende Pruefung
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) out.append(buf, n);
    fclose(f);
    return true;
}
// overload
inline bool UiReadFile(const std::string& name, std::string& out) {
  return UiReadFile(name.c_str(), out);
}

// Bequemer Rueckgabewert (leer, wenn nicht lesbar).
inline std::string UiReadFileOr(const char* name, const char* fallback = "") {
    std::string s;
    if (UiReadFile(name, s)) return s;
    return std::string(fallback ? fallback : "");
}
// Schreibt die Datei. Rueckgabe false = nicht schreibbar.
inline bool UiWriteFile(const char* name, const std::string& data) {
    FILE* f = fopen(UiFilePath(name).c_str(), "wb");
    if (!f) return false;                       // <- die fehlende Pruefung
    size_t w = data.empty()
             ? 0 : fwrite(data.data(), 1, data.size(), f);
    bool ok = (w == data.size());
    if (fclose(f) != 0) ok = false;             // Fehler beim Leeren
    return ok;
}
// overload
inline bool UiWriteFile(const std::string& name, const std::string& data) {
  return UiWriteFile(name.c_str(), data);
}
// Listet Dateien des Stammverzeichnisses (nicht rekursiv). Mit 'ext'
// gefiltert (z.B. ".txt"); leeres ext = alle. Ordner bleiben aussen vor.
inline std::vector<std::string> UiListFiles(const char* ext = "") {
    std::vector<std::string> out;
    std::string base = UiFilesBaseDir();
    if (base.empty()) base = ".";
    std::string e = ext ? ext : "";
#if defined(_WIN32)
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA((base + "\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return out;
    do {
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
        out.push_back(fd.cFileName);
    } while (FindNextFileA(h, &fd));
    FindClose(h);
#else
    DIR* d = opendir(base.c_str());
    if (!d) return out;                       // nicht lesbar: leere Liste
    while (struct dirent* de = readdir(d)) {
        std::string n = de->d_name;
        if (n == "." || n == "..") continue;
        struct stat st;
        if (stat((base + "/" + n).c_str(), &st) == 0 && S_ISDIR(st.st_mode))
            continue;                         // Ordner ueberspringen
        out.push_back(n);
    }
    closedir(d);
#endif
    if (!e.empty()) {
        std::vector<std::string> f;
        for (auto& n : out)
            if (n.size() >= e.size()
                && n.compare(n.size() - e.size(), e.size(), e) == 0)
                f.push_back(n);
        out.swap(f);
    }
    std::sort(out.begin(), out.end());
    return out;
}

// Loescht eine Datei. false = ging nicht (fehlt, keine Rechte).
inline bool UiDeleteFile(const char* name) {
    if (!name || !*name) return false;
    return remove(UiFilePath(name).c_str()) == 0;
}

inline bool UiFileExists(const char* name) {
    FILE* f = fopen(UiFilePath(name).c_str(), "rb");
    if (!f) return false;
    fclose(f);
    return true;
}
