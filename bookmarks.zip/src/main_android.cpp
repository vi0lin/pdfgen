// main_android.cpp
//
// Android-Einstiegspunkt (android_main) via NDK native_app_glue.
// GLFW existiert auf Android nicht -- stattdessen: EGL-Kontext von Hand
// plus Dear ImGuis offizielles Android-Backend (imgui_impl_android) und
// das OpenGL3-Backend im GLES3-Modus.
//
// Schritt 1: lauffaehige APK mit ImGui-UI. Die Bookmark-Manager-Logik
// (gui() aus main.cpp) wird im naechsten Schritt in eine gemeinsame
// Datei extrahiert und hier eingebunden.

#ifdef __ANDROID__

#include <android_native_app_glue.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <string>

#include "imgui.h"
#include "backends/imgui_impl_android.h"
#include "backends/imgui_impl_opengl3.h"
#include "effects_gl.h"
#include "bookmark_window.h"
#include "ui_helpers.h"
#include "ui_pages.h"
#include "ui_networking.h"
#include "xbm_alarm.h"
#include "ui_form.h"   // Tab "Netzwerk": Geraete, Befehle, Abgleich
#include "ui_jobs.h"   // Tab "Jobs": Queues (jobflow)
#include "ui_media.h"  // Tab "Media": Audio, Scrubber, Schnitt
#include "platform_manager.h" // Reddit, Facebook (X bleibt hier bei seiner eigenen Anbindung)
static PlatformManager& AndroidPmReddit()   { static PlatformManager m(MakeRedditSource());   return m; }
static PlatformManager& AndroidPmFacebook() { static PlatformManager m(MakeFacebookSource()); return m; }
#include "xbm_paths.h"
#include "xbm_crash.h"
#include "xbm_net_udp.h"
#include "ui_scrub.h"
#include "ui_windoctor.h"
#include "ui_clickthru.h"
#include "ui_titlebar.h"   // auf Android bewusst AUS (Systemleiste vorhanden)
#include "xbm_sched.h"
#include "xbm_update.h"    // Update-Check -- zeigt ggf. einen Alert (ui_alerts.h)
#include "xbm_audio.h"
#include "ui_calendar.h"
#include "android_clipboard.h"
#include "android_insets.h"
#include "app_settings.h"
#include "ui_files.h"
#include "x_client.h"
#include "thumbnails.h"
#include <nlohmann/json.hpp>
#include <vector>
#include <unordered_set>
#include <memory>
#include <mutex>
#include <atomic>
#include <thread>
#include <fstream>
#include <filesystem>

#include "bewerben.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  "XBookmarks", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "XBookmarks", __VA_ARGS__)

// ---------------------------------------------------------------------------
// Bildschirmtastatur via JNI
// NativeActivity-Apps ohne Java-Code oeffnen die Soft-Tastatur NIE von
// selbst -- das muss die Activity ueber den InputMethodManager tun. Wir
// rufen die Java-Seite per JNI auf (toggleSoftInput zum Oeffnen -- der
// robuste Weg fuer NativeActivity, showSoftInput scheitert dort oft am
// fehlenden View-Fokus -- und hideSoftInputFromWindow zum Schliessen).
// Zeichen kommen anschliessend als Key-Events an, die imgui_impl_android
// inkl. Unicode-Aufloesung bereits verarbeitet.
// ---------------------------------------------------------------------------
static android_app* g_app = nullptr;

// XBM_MBEDTLS_SELFTEST: direkter mbedTLS-Aufruf, loggt die EXAKTE Fehlernummer.
#include <mbedtls/ssl.h>
#include <mbedtls/version.h>
static void MbedtlsSelfTest() {
    char ver[32]; mbedtls_version_get_string_full(ver);
    LOGI("mbedTLS selftest: version=%s", ver);
    mbedtls_ssl_config conf;
    mbedtls_ssl_config_init(&conf);
    int r = mbedtls_ssl_config_defaults(&conf, MBEDTLS_SSL_IS_CLIENT,
                MBEDTLS_SSL_TRANSPORT_STREAM, MBEDTLS_SSL_PRESET_DEFAULT);
    LOGI("mbedTLS selftest: config_defaults -> -0x%04X", (unsigned)(-r));
    mbedtls_ssl_context ssl;
    mbedtls_ssl_init(&ssl);
    int s2 = mbedtls_ssl_setup(&ssl, &conf);
    LOGI("mbedTLS selftest: ssl_setup -> -0x%04X %s",
         (unsigned)(-s2), s2 == 0 ? "(OK)" : "(FEHLER)");
    mbedtls_ssl_free(&ssl);
    mbedtls_ssl_config_free(&conf);
}

// Zeichen aus Key-Events aufloesen: imgui_impl_android liefert bewusst
// KEINE Textzeichen (io.AddInputCharacter) -- das offizielle ImGui-Android-
// Beispiel macht das ueber eine Java-Seite. Ohne Java: pro Tastendruck via
// JNI android.view.KeyEvent(action, code).getUnicodeChar(metaState) fragen.
static int JniGetUnicodeChar(int action, int keyCode, int metaState) {
    if (!g_app || !g_app->activity) return 0;
    JavaVM* vm = g_app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return 0;
    int result = 0;
    jclass keCls = env->FindClass("android/view/KeyEvent");
    if (keCls) {
        jmethodID ctor = env->GetMethodID(keCls, "<init>", "(II)V");
        jmethodID getUni = env->GetMethodID(keCls, "getUnicodeChar", "(I)I");
        if (ctor && getUni) {
            jobject ke = env->NewObject(keCls, ctor, action, keyCode);
            if (ke) result = env->CallIntMethod(ke, getUni, metaState);
        }
    }
    if (env->ExceptionCheck()) { env->ExceptionClear(); result = 0; }
    vm->DetachCurrentThread();
    return result;
}

// ---------------------------------------------------------------------------
// MIKROFONBERECHTIGUNG (RECORD_AUDIO)
//
// Die App ist eine reine NativeActivity mit android:hasCode="false" -- es
// gibt also keine Java-Klasse, in der man onRequestPermissionsResult
// ueberschreiben koennte. Beides laesst sich trotzdem rein ueber JNI
// erledigen:
//   * pruefen  : Context.checkSelfPermission(String) (API 23+)
//   * anfragen : Activity.requestPermissions(String[], int)
// Das Ergebnis holen wir NICHT ueber den Rueckruf, sondern indem wir beim
// naechsten Aufnahmeversuch erneut pruefen -- das ist bei einer
// Native-Activity der einzige verlaessliche Weg und voellig ausreichend:
// der Nutzer drueckt den Memo-Knopf ohnehin ein zweites Mal, nachdem er
// den Systemdialog beantwortet hat.
// ---------------------------------------------------------------------------
bool XbmAndroid_HasMicPermission() {
    if (!g_app || !g_app->activity) return false;
    JavaVM* vm = g_app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return false;
    bool granted = false;
    do {
        jobject activity = g_app->activity->clazz;
        jclass  actCls   = env->GetObjectClass(activity);
        jmethodID check  = env->GetMethodID(actCls, "checkSelfPermission",
                                            "(Ljava/lang/String;)I");
        if (!check) break;                       // API < 23: im Manifest gewaehrt
        jstring perm = env->NewStringUTF("android.permission.RECORD_AUDIO");
        const jint r = env->CallIntMethod(activity, check, perm);
        env->DeleteLocalRef(perm);
        granted = (r == 0);                      // PackageManager.PERMISSION_GRANTED
    } while (false);
    if (env->ExceptionCheck()) { env->ExceptionClear(); granted = false; }
    vm->DetachCurrentThread();
    return granted;
}

void XbmAndroid_RequestMicPermission() {
    if (!g_app || !g_app->activity) return;
    // Nur EINMAL pro Programmlauf fragen: wiederholtes requestPermissions
    // nach einer Ablehnung oeffnet keinen Dialog mehr und flackert nur.
    static bool asked = false;
    if (asked) return;
    asked = true;

    JavaVM* vm = g_app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return;
    do {
        jobject activity = g_app->activity->clazz;
        jclass  actCls   = env->GetObjectClass(activity);
        jmethodID req = env->GetMethodID(actCls, "requestPermissions",
                                         "([Ljava/lang/String;I)V");
        if (!req) break;                         // API < 23
        jclass strCls = env->FindClass("java/lang/String");
        jobjectArray arr = env->NewObjectArray(1, strCls, nullptr);
        jstring perm = env->NewStringUTF("android.permission.RECORD_AUDIO");
        env->SetObjectArrayElement(arr, 0, perm);
        env->CallVoidMethod(activity, req, arr, (jint)4711);
        env->DeleteLocalRef(perm);
        env->DeleteLocalRef(arr);
        LOGI("RECORD_AUDIO angefragt");
    } while (false);
    if (env->ExceptionCheck()) env->ExceptionClear();
    vm->DetachCurrentThread();
}

// Android-Zwischenablage schreiben (fuer "Kopieren" und ImGuis interne
// Copy-Operationen).
static void JniSetClipboardText(const char* text) {
    if (!g_app || !g_app->activity || !text) return;
    JavaVM* vm = g_app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return;
    do {
        jobject activity = g_app->activity->clazz;
        jclass  actCls   = env->GetObjectClass(activity);
        jmethodID getSvc = env->GetMethodID(actCls, "getSystemService",
            "(Ljava/lang/String;)Ljava/lang/Object;");
        jstring name = env->NewStringUTF("clipboard");
        jobject cm = env->CallObjectMethod(activity, getSvc, name);
        env->DeleteLocalRef(name);
        if (!cm) break;
        jclass cdCls = env->FindClass("android/content/ClipData");
        jmethodID newPlain = env->GetStaticMethodID(cdCls, "newPlainText",
            "(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;");
        jstring label = env->NewStringUTF("text");
        jstring value = env->NewStringUTF(text);
        jobject clip = env->CallStaticObjectMethod(cdCls, newPlain, label, value);
        jclass cmCls = env->GetObjectClass(cm);
        jmethodID setClip = env->GetMethodID(cmCls, "setPrimaryClip",
            "(Landroid/content/ClipData;)V");
        if (clip && setClip) env->CallVoidMethod(cm, setClip, clip);
    } while (false);
    if (env->ExceptionCheck()) env->ExceptionClear();
    vm->DetachCurrentThread();
}

// Android-Zwischenablage lesen (fuer die "Einfuegen"-Buttons).
static std::string JniGetClipboardText() {
    std::string out;
    if (!g_app || !g_app->activity) return out;
    JavaVM* vm = g_app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return out;
    do {
        jobject activity = g_app->activity->clazz;
        jclass  actCls   = env->GetObjectClass(activity);
        jmethodID getSvc = env->GetMethodID(actCls, "getSystemService",
            "(Ljava/lang/String;)Ljava/lang/Object;");
        jstring name = env->NewStringUTF("clipboard");
        jobject cm = env->CallObjectMethod(activity, getSvc, name);
        env->DeleteLocalRef(name);
        if (!cm) break;
        jclass cmCls = env->GetObjectClass(cm);
        jmethodID getClip = env->GetMethodID(cmCls, "getPrimaryClip",
            "()Landroid/content/ClipData;");
        jobject clip = env->CallObjectMethod(cm, getClip);
        if (!clip) break;
        jclass clipCls = env->GetObjectClass(clip);
        jmethodID getItem = env->GetMethodID(clipCls, "getItemAt",
            "(I)Landroid/content/ClipData$Item;");
        jobject item = env->CallObjectMethod(clip, getItem, 0);
        if (!item) break;
        jclass itemCls = env->GetObjectClass(item);
        jmethodID coerce = env->GetMethodID(itemCls, "coerceToText",
            "(Landroid/content/Context;)Ljava/lang/CharSequence;");
        jobject cs = env->CallObjectMethod(item, coerce, activity);
        if (!cs) break;
        jclass csCls = env->GetObjectClass(cs);
        jmethodID toStr = env->GetMethodID(csCls, "toString", "()Ljava/lang/String;");
        jstring jstr = (jstring)env->CallObjectMethod(cs, toStr);
        if (!jstr) break;
        const char* utf = env->GetStringUTFChars(jstr, nullptr);
        if (utf) { out = utf; env->ReleaseStringUTFChars(jstr, utf); }
    } while (false);
    if (env->ExceptionCheck()) { env->ExceptionClear(); out.clear(); }
    vm->DetachCurrentThread();
    return out;
}


// ---- System-Zwischenablage (JNI) ---------------------------------------
// Gboards Zwischenablage-Leiste fuegt Text ueber die InputConnection ein --
// die stellt eine NativeActivity NICHT bereit, deshalb kam beim Tippen auf
// einen Clip nie etwas an. Loesung: direkter Zugriff auf den System-
// Clipboard (ClipboardManager) und Verdrahtung mit ImGuis Clipboard-
// Schnittstelle, sodass Strg+V und der Einfuegen-Knopf funktionieren.
static std::string AndroidClipboardGet() {
    std::string out;
    if (!g_app || !g_app->activity) return out;
    JavaVM* vm = g_app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return out;
    jobject activity = g_app->activity->clazz;
    jclass  actCls   = env->GetObjectClass(activity);
    jmethodID getSvc = env->GetMethodID(actCls, "getSystemService",
        "(Ljava/lang/String;)Ljava/lang/Object;");
    jstring svcName = env->NewStringUTF("clipboard");
    jobject cm = env->CallObjectMethod(activity, getSvc, svcName);
    env->DeleteLocalRef(svcName);
    if (cm) {
        jclass cmCls = env->GetObjectClass(cm);
        jmethodID getClip = env->GetMethodID(cmCls, "getPrimaryClip",
            "()Landroid/content/ClipData;");
        jobject clip = getClip ? env->CallObjectMethod(cm, getClip) : nullptr;
        if (clip) {
            jclass clCls = env->GetObjectClass(clip);
            jmethodID cnt = env->GetMethodID(clCls, "getItemCount", "()I");
            jmethodID at  = env->GetMethodID(clCls, "getItemAt",
                "(I)Landroid/content/ClipData$Item;");
            jint n = cnt ? env->CallIntMethod(clip, cnt) : 0;
            if (n > 0 && at) {
                jobject item = env->CallObjectMethod(clip, at, 0);
                if (item) {
                    jclass itCls = env->GetObjectClass(item);
                    jmethodID coerce = env->GetMethodID(itCls,
                        "coerceToText",
                        "(Landroid/content/Context;)Ljava/lang/CharSequence;");
                    jobject cs = coerce
                        ? env->CallObjectMethod(item, coerce, activity)
                        : nullptr;
                    if (cs) {
                        jclass csCls = env->GetObjectClass(cs);
                        jmethodID toStr = env->GetMethodID(csCls, "toString",
                            "()Ljava/lang/String;");
                        jstring js = toStr
                            ? (jstring)env->CallObjectMethod(cs, toStr)
                            : nullptr;
                        if (js) {
                            const char* c = env->GetStringUTFChars(js, nullptr);
                            if (c) { out = c; env->ReleaseStringUTFChars(js, c); }
                            env->DeleteLocalRef(js);
                        }
                        env->DeleteLocalRef(cs);
                    }
                    env->DeleteLocalRef(item);
                }
            }
            env->DeleteLocalRef(clip);
        }
        env->DeleteLocalRef(cm);
    }
    return out;
}

static void AndroidClipboardSet(const char* text) {
    if (!g_app || !g_app->activity || !text) return;
    JavaVM* vm = g_app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return;
    jobject activity = g_app->activity->clazz;
    jclass  actCls   = env->GetObjectClass(activity);
    jmethodID getSvc = env->GetMethodID(actCls, "getSystemService",
        "(Ljava/lang/String;)Ljava/lang/Object;");
    jstring svcName = env->NewStringUTF("clipboard");
    jobject cm = env->CallObjectMethod(activity, getSvc, svcName);
    env->DeleteLocalRef(svcName);
    if (!cm) return;
    jclass cdCls = env->FindClass("android/content/ClipData");
    jmethodID newPlain = cdCls ? env->GetStaticMethodID(cdCls, "newPlainText",
        "(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)"
        "Landroid/content/ClipData;") : nullptr;
    if (newPlain) {
        jstring lbl = env->NewStringUTF("xbm");
        jstring val = env->NewStringUTF(text);
        jobject clip = env->CallStaticObjectMethod(cdCls, newPlain, lbl, val);
        if (clip) {
            jclass cmCls = env->GetObjectClass(cm);
            jmethodID setClip = env->GetMethodID(cmCls, "setPrimaryClip",
                "(Landroid/content/ClipData;)V");
            if (setClip) env->CallVoidMethod(cm, setClip, clip);
            env->DeleteLocalRef(clip);
        }
        env->DeleteLocalRef(lbl); env->DeleteLocalRef(val);
    }
    env->DeleteLocalRef(cm);
}

// ImGui-Anbindung: Strg+V/Strg+C und Kontextmenue nutzen ab jetzt den
// echten System-Clipboard.
static const char* XbmClipGet(void*) {
    static std::string buf;
    buf = AndroidClipboardGet();
    return buf.c_str();
}
static void XbmClipSet(void*, const char* text) { AndroidClipboardSet(text); }

// Einfuegen-Knopf fuer ein Textfeld: holt den AKTUELLEN Clip und haengt
// ihn an (bzw. ersetzt bei leerem Feld). So ist Gboards Multi-Clipboard
// nutzbar: Clip antippen (er wird primaerer Clip), dann hier einfuegen.
static void ClipPasteButton(const char* id, char* buf, size_t cap) {
    ImGui::PushID(id);
    ImGui::SameLine();
    if (ImGui::SmallButton("Einfuegen")) {
        std::string c = AndroidClipboardGet();
        if (!c.empty()) {
            snprintf(buf, cap, "%s", c.c_str());
        }
    }
    ImGui::PopID();
}


// ---- IME-Text von XbmActivity abholen -----------------------------------
// Die Java-Seite sammelt alles ein, was der IME liefert (Tippen, Swipe,
// Autokorrektur UND Einfuegen aus Gboards Zwischenablage). Hier wird der
// Puffer pro Frame geleert und an ImGui weitergereicht.
// Aktuelle Tastaturhoehe (weich nachgefuehrt) -- die App wird NICHT mehr
// vom System umskaliert (adjustNothing); stattdessen zieht die Oberflaeche
// ihren nutzbaren Bereich selbst und gleichmaessig nach.
float g_imeH = 0.0f;

static int QueryImeHeight() {
    if (!g_app || !g_app->activity) return 0;
    JavaVM* vm = g_app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return 0;
    jobject a = g_app->activity->clazz;
    jclass  c = env->GetObjectClass(a);
    jmethodID m = env->GetMethodID(c, "xbmImeHeight", "()I");
    if (!m) { env->ExceptionClear(); return 0; }
    return (int)env->CallIntMethod(a, m);
}

// True, sobald xbmPollText gefunden wurde: Dann liefert die JAVA-Pumpe
// ALLE Zeichen (Soft-Tastatur, Swipe, Autokorrektur UND physische
// Bluetooth-Tastatur, denn das unsichtbare EditText hat den Fokus und
// bekommt auch Hardware-Tasten). Die native AKeyEvent-Erfassung ist dann
// ein ZWEITER Weg fuer dieselben Zeichen -> jeder Anschlag kam doppelt an.
static bool g_imeJavaPump = false;

// Holt Steuertasten (Cursor/Loeschen) aus der Java-Bruecke und speist sie
// als echte ImGui-Tastendruecke ein. Damit funktioniert Gboards Wisch
// ueber die LEERTASTE zur Cursorbewegung -- der schickt naemlich keinen
// Text, sondern DPAD-Tastendruecke, die das unsichtbare EditText sonst
// verschluckt (der native AKeyEvent-Weg ist ja abgeschaltet, weil er
// jeden Anschlag verdoppelte).
// Prueft, ob ImGuis eigene GPU-Objekte (v.a. der ZEICHENSATZ-ATLAS)
// noch gueltig sind, und baut sie sonst neu auf.
//
// SYMPTOM, das dahinter steckt: Nach einem Kontextverlust sind alle
// Fenster SCHWARZ, waehrend Hintergrund-Shader und Sinuswelle normal
// laufen. Grund: ImGui faerbt Flaechen, indem es das WEISSE PIXEL des
// Atlas abtastet. Ist dessen Textur ungueltig, liefert die Abtastung
// Schwarz -- Fensterflaechen und Text werden schwarz, waehrend die
// Effekte ihre EIGENEN Texturen benutzen und daher weiter stimmen.
//
// Die Pruefung laeuft jeden Frame (ein glIsTexture pro Textur) und
// nicht nur bei APP_CMD_INIT_WINDOW: Der Kontext kann auch verloren
// gehen, ohne dass die Surface neu erzeugt wird -- genau der Fall beim
// Zurueckwechseln aus dem Multitasking.
// Vorwaerts deklariert, damit der Aufruf weiter unten in der Datei
// unabhaengig von der Reihenfolge uebersetzt. (Die Definition folgt
// weiter unten; 'static' = nur in dieser Uebersetzungseinheit.)
static void ValidateImGuiGpu();

static void ValidateImGuiGpu() {
    bool bad = false;
    for (ImTextureData* tex : ImGui::GetPlatformIO().Textures) {
        if (!tex || tex->Status != ImTextureStatus_OK) continue;
        GLuint id = (GLuint)(intptr_t)tex->TexID;
        if (id != 0 && glIsTexture(id) == GL_FALSE) { bad = true; break; }
    }
    if (!bad) return;
    XBM_LOG("GL-Kontext verloren -> ImGui-Texturen werden neu erzeugt");
    ImGui_ImplOpenGL3_DestroyDeviceObjects();   // setzt Status zurueck
    ImGui_ImplOpenGL3_CreateDeviceObjects();    // Atlas kommt im Frame
}

static void PollImeKeys() {
    if (!g_imeJavaPump) return;                 // Java-Teil nicht aktiv
    if (!g_app || !g_app->activity) return;
    // Denselben Weg nehmen wie PollImeText -- GetJniEnv() gibt es hier
    // nicht; der JNIEnv wird pro Thread ueber die JavaVM geholt.
    JavaVM* vm = g_app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return;
    jobject activity = g_app->activity->clazz;
    jclass  cls = env->GetObjectClass(activity);
    jmethodID mid = env->GetMethodID(cls, "xbmPollKey", "()I");
    if (!mid) {
        env->ExceptionClear();
        env->DeleteLocalRef(cls);
        return;                                 // aeltere XbmActivity
    }
    ImGuiIO& io = ImGui::GetIO();
    for (int guard = 0; guard < 64; ++guard) {  // Schleifenbremse
        jint k = env->CallIntMethod(activity, mid);
        if (env->ExceptionCheck()) { env->ExceptionClear(); break; }
        if (k == 0) break;
        ImGuiKey key = ImGuiKey_None;
        switch (k) {
            case 1: key = ImGuiKey_LeftArrow;  break;
            case 2: key = ImGuiKey_RightArrow; break;
            case 3: key = ImGuiKey_UpArrow;    break;
            case 4: key = ImGuiKey_DownArrow;  break;
            case 5: key = ImGuiKey_Backspace;  break;
            case 6: key = ImGuiKey_Delete;     break;
            case 7: key = ImGuiKey_Home;       break;
            case 8: key = ImGuiKey_End;        break;
            default: break;
        }
        if (key != ImGuiKey_None) {
            io.AddKeyEvent(key, true);
            io.AddKeyEvent(key, false);
        }
    }
    env->DeleteLocalRef(cls);
}

static void PollImeText() {
    if (!g_app || !g_app->activity) return;
    JavaVM* vm = g_app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return;
    jobject activity = g_app->activity->clazz;
    jclass  cls = env->GetObjectClass(activity);
    jmethodID mid = env->GetMethodID(cls, "xbmPollText",
                                     "()Ljava/lang/String;");
    if (!mid) {
        env->ExceptionClear();
        // DIAGNOSE: Fehlt die Methode, laeuft die App NICHT auf
        // XbmActivity -- dann ist entweder classes.dex nicht im APK oder
        // das Manifest zeigt noch auf android.app.NativeActivity.
        static bool warned = false;
        if (!warned) {
            warned = true;
            XBM_LOG("IME: xbmPollText FEHLT -> Java-Teil nicht aktiv "
                    "(Manifest auf .XbmActivity? classes.dex im APK?)");
        }
        return;
    }
    g_imeJavaPump = true;
    static bool okLogged = false;
    if (!okLogged) { okLogged = true; XBM_LOG("IME: XbmActivity aktiv"); }
    jstring js = (jstring)env->CallObjectMethod(activity, mid);
    if (!js) return;
    const char* c = env->GetStringUTFChars(js, nullptr);
    if (c && *c) {
        // ZEILENUMBRUECHE: Multiline-Felder nehmen '\n' DIREKT als
        // Zeichen (InputTextFilterCharacter laesst es durch). Nur ein
        // alleinstehendes "\n" -- der echte Enter-Druck -- wird als
        // Tastenereignis gemeldet, damit einzeilige Felder abschliessen.
        ImGuiIO& tio = ImGui::GetIO();
        const bool loneEnter = (c[0] == '\n' && c[1] == 0);
        const char* seg = c;
        for (const char* q = c; ; ++q) {
            if (*q == '\n' || *q == '\r' || *q == '\0') {
                if (q > seg) {
                    std::string part(seg, (size_t)(q - seg));
                    tio.AddInputCharactersUTF8(part.c_str());
                }
                if (*q == '\0') break;
                if (*q == '\n') {          // \r\n zaehlt einmal
                    // NUR ein ALLEINSTEHENDES \n ist ein echter
                    // Enter-Druck der Tastatur -> Tastenereignis (damit
                    // einzeilige Felder wie gewohnt abschliessen).
                    // \n INNERHALB eines groesseren Blocks ist EINGEFUEGTER
                    // Text: ImGui nimmt '\n' in Multiline-Feldern direkt
                    // als Zeichen an (InputTextFilterCharacter). [Vorher
                    // wurde fuer JEDES \n ein Enter-Paar synthetisiert;
                    // ImGui verteilt gleiche Tasten-Paare aber auf
                    // aufeinanderfolgende Frames -- ein eingefuegter
                    // Block loeste so einen sekundenlangen Enter-Regen
                    // aus, waehrenddessen das Feld die Eingabe verlor.]
                    if (loneEnter) {
                        tio.AddKeyEvent(ImGuiKey_Enter, true);
                        tio.AddKeyEvent(ImGuiKey_Enter, false);
                    } else {
                        tio.AddInputCharacter('\n');
                    }
                }
                seg = q + 1;
            }
        }
    }
    if (c) env->ReleaseStringUTFChars(js, c);
    env->DeleteLocalRef(js);
}

// Tastatur ueber die Activity (setzt zugleich den Fokus auf das
// unsichtbare EditText -- ohne Fokus keine InputConnection).
static bool SetKeyboardViaActivity(bool show) {
    if (!g_app || !g_app->activity) return false;
    JavaVM* vm = g_app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return false;
    jobject activity = g_app->activity->clazz;
    jclass  cls = env->GetObjectClass(activity);
    jmethodID mid = env->GetMethodID(cls, "xbmSetKeyboard", "(Z)V");
    if (!mid) { env->ExceptionClear(); return false; }
    env->CallVoidMethod(activity, mid, (jboolean)show);
    return true;
}

// DATEI EXTERN OEFFNEN -- Hook fuer XbmPaths_OeffnenExtern (siehe
// XbmActivity.xbmOeffneDatei fuer das Warum der Kopie nach Downloads).
static bool OeffneDateiViaActivity(const std::string& pfad) {
    if (!g_app || !g_app->activity) return false;
    JavaVM* vm = g_app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return false;
    jobject activity = g_app->activity->clazz;
    jclass  cls = env->GetObjectClass(activity);
    jmethodID mid = env->GetMethodID(cls, "xbmOeffneDatei", "(Ljava/lang/String;)Z");
    bool ok = false;
    if (mid) {
        jstring js = env->NewStringUTF(pfad.c_str());
        ok = env->CallBooleanMethod(activity, mid, js) == JNI_TRUE;
        env->DeleteLocalRef(js);
    }
    if (env->ExceptionCheck()) { env->ExceptionClear(); ok = false; }
    return ok;
}

static void ShowSoftKeyboard(bool show) {
    // GLOBAL ABGESCHALTET: Einblenden wird ignoriert, Ausblenden nicht --
    // eine bereits offene Tastatur soll sich noch schliessen lassen.
    if (show && !UiKeyboardEnabled()) return;
    // "ANDROID-TASTATUR VERWENDEN" AUS: dieselbe Regel, eigener Schalter
    // -- links neben dem Einstellungen-Zahnrad umschaltbar, und
    // automatisch aus, sobald eine physische Tastatur erkannt wird.
    if (show && !UiAndroidTastaturVerwenden()) return;
    if (SetKeyboardViaActivity(show)) return;   // Java-Weg bevorzugt
    if (!g_app || !g_app->activity) return;
    JavaVM* vm = g_app->activity->vm;
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return;

    jobject activity = g_app->activity->clazz;
    jclass  actCls   = env->GetObjectClass(activity);

    jmethodID getSystemService = env->GetMethodID(actCls, "getSystemService",
        "(Ljava/lang/String;)Ljava/lang/Object;");
    jstring svcName = env->NewStringUTF("input_method");
    jobject imm = env->CallObjectMethod(activity, getSystemService, svcName);
    env->DeleteLocalRef(svcName);
    if (imm) {
        jclass immCls = env->GetObjectClass(imm);
        if (show) {
            // toggleSoftInput(SHOW_FORCED=2, 0)
            jmethodID toggle = env->GetMethodID(immCls, "toggleSoftInput", "(II)V");
            if (toggle) env->CallVoidMethod(imm, toggle, 2, 0);
        } else {
            // hideSoftInputFromWindow(decorView.getWindowToken(), 0)
            jmethodID getWindow = env->GetMethodID(actCls, "getWindow",
                "()Landroid/view/Window;");
            jobject window = env->CallObjectMethod(activity, getWindow);
            if (window) {
                jclass winCls = env->GetObjectClass(window);
                jmethodID getDecor = env->GetMethodID(winCls, "getDecorView",
                    "()Landroid/view/View;");
                jobject decor = env->CallObjectMethod(window, getDecor);
                if (decor) {
                    jclass viewCls = env->GetObjectClass(decor);
                    jmethodID getToken = env->GetMethodID(viewCls, "getWindowToken",
                        "()Landroid/os/IBinder;");
                    jobject token = env->CallObjectMethod(decor, getToken);
                    jmethodID hide = env->GetMethodID(immCls, "hideSoftInputFromWindow",
                        "(Landroid/os/IBinder;I)Z");
                    if (hide && token) env->CallBooleanMethod(imm, hide, token, 0);
                }
            }
        }
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    vm->DetachCurrentThread();
}

namespace {

struct EglState {
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    EGLConfig  config  = nullptr;   // gemerkt fuer Surface-Neuaufbau beim Resume
    int width = 0, height = 0;
};

bool egl_init(EglState& egl, ANativeWindow* window) {
    egl.display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (egl.display == EGL_NO_DISPLAY) { LOGE("eglGetDisplay failed"); return false; }
    if (!eglInitialize(egl.display, nullptr, nullptr)) { LOGE("eglInitialize failed"); return false; }

    const EGLint attribs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE,    EGL_WINDOW_BIT,
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 24,
        EGL_NONE
    };
    EGLConfig config; EGLint numConfigs = 0;
    if (!eglChooseConfig(egl.display, attribs, &config, 1, &numConfigs) || numConfigs < 1) {
        LOGE("eglChooseConfig failed"); return false;
    }
    egl.config = config;

    egl.surface = eglCreateWindowSurface(egl.display, config, window, nullptr);
    if (egl.surface == EGL_NO_SURFACE) { LOGE("eglCreateWindowSurface failed"); return false; }

    const EGLint ctxAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    egl.context = eglCreateContext(egl.display, config, EGL_NO_CONTEXT, ctxAttribs);
    if (egl.context == EGL_NO_CONTEXT) { LOGE("eglCreateContext failed"); return false; }

    if (!eglMakeCurrent(egl.display, egl.surface, egl.surface, egl.context)) {
        LOGE("eglMakeCurrent failed"); return false;
    }
    eglQuerySurface(egl.display, egl.surface, EGL_WIDTH,  &egl.width);
    eglQuerySurface(egl.display, egl.surface, EGL_HEIGHT, &egl.height);
    LOGI("EGL ready: %dx%d", egl.width, egl.height);
    return true;
}

// Resume-Pfad: NUR die Surface neu erzeugen, Kontext (und damit alle
// GPU-Ressourcen: ImGui-Fonttextur, Effekt-FBOs, Thumbnails) bleibt am
// Leben. Das ist das Standard-Muster von Android-GL-Apps (Aequivalent zu
// GLSurfaceView.setPreserveEGLContextOnPause(true)).
bool egl_recreate_surface(EglState& egl, ANativeWindow* window) {
    if (egl.display == EGL_NO_DISPLAY || egl.context == EGL_NO_CONTEXT) return false;
    if (egl.surface != EGL_NO_SURFACE) {
        eglDestroySurface(egl.display, egl.surface);
        egl.surface = EGL_NO_SURFACE;
    }
    egl.surface = eglCreateWindowSurface(egl.display, egl.config, window, nullptr);
    if (egl.surface == EGL_NO_SURFACE) { LOGE("resume: eglCreateWindowSurface failed"); return false; }
    if (!eglMakeCurrent(egl.display, egl.surface, egl.surface, egl.context)) {
        LOGE("resume: eglMakeCurrent failed"); return false;
    }
    eglQuerySurface(egl.display, egl.surface, EGL_WIDTH,  &egl.width);
    eglQuerySurface(egl.display, egl.surface, EGL_HEIGHT, &egl.height);
    LOGI("EGL surface recreated: %dx%d (context preserved)", egl.width, egl.height);
    return true;
}

// Nur-Surface-Abbau fuer den Hintergrund-Wechsel (Kontext bleibt!)
void egl_release_surface(EglState& egl) {
    if (egl.display == EGL_NO_DISPLAY) return;
    eglMakeCurrent(egl.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    if (egl.surface != EGL_NO_SURFACE) {
        eglDestroySurface(egl.display, egl.surface);
        egl.surface = EGL_NO_SURFACE;
    }
}

void egl_shutdown(EglState& egl) {
    if (egl.display != EGL_NO_DISPLAY) {
        eglMakeCurrent(egl.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (egl.context != EGL_NO_CONTEXT) eglDestroyContext(egl.display, egl.context);
        if (egl.surface != EGL_NO_SURFACE) eglDestroySurface(egl.display, egl.surface);
        eglTerminate(egl.display);
    }
    egl = EglState{};
}

struct AppCtx {
    EglState egl;
    bool     imguiReady = false;
    bool     canRender  = false;
};

// ---------------------------------------------------------------------------
// Netzwerk-Zustand (Android): XClient + Tweets + Status. Alle Dateipfade
// liegen unter internalDataPath (einziger beschreibbarer App-Pfad).
// ---------------------------------------------------------------------------
struct NetState {
    std::string dataPath;                 // internalDataPath
    std::unique_ptr<XClient> client;
    std::vector<Tweet> tweets;
    std::unordered_set<std::string> selected;
    std::mutex mtx;                       // schuetzt tweets/status (Fetch-Thread)
    std::string status = "Keine Cookies -- unten eingeben.";
    std::atomic<bool> loading{false};
    char inAuth[256] = {0};               // Eingabefelder Cookie-UI
    char inCt0[256]  = {0};
};
static NetState g_net;
static ThumbnailManager* g_thumbs = nullptr;  // nach EGL-Init erzeugt

static std::string CookiePath() { return g_net.dataPath + "/cookies.json"; }

static bool LoadCookiesAndroid(std::string& auth, std::string& ct0) {
    std::ifstream in(CookiePath());
    if (!in) return false;
    try {
        nlohmann::json j; in >> j;
        auth = j.value("auth_token", "");
        ct0  = j.value("ct0", "");
        return !auth.empty() && !ct0.empty();
    } catch (...) { return false; }
}

static void SaveCookiesAndroid(const std::string& auth, const std::string& ct0) {
    nlohmann::json j; j["auth_token"] = auth; j["ct0"] = ct0;
    std::ofstream out(CookiePath()); out << j.dump(2);
}

static void SetStatus(const std::string& s) {
    std::lock_guard<std::mutex> l(g_net.mtx); g_net.status = s;
}

// ---- BOOKMARK-CACHE (TSV unter internalDataPath) ----------------------
// Beim App-Start werden die zuletzt geladenen Bookmarks sofort wieder
// angezeigt; "Laden" ersetzt sie durch den frischen Server-Stand und
// schreibt den Cache neu. Loeschen aktualisiert den Cache ebenfalls.
static std::string BookmarksCachePath() {
    return g_net.dataPath + "/bookmarks.tsv";
}
static std::string TsvEsc(const std::string& in) {
    std::string o; o.reserve(in.size());
    for (char c : in) {
        if      (c == '\\') o += "\\\\";
        else if (c == '\t')  o += "\\t";
        else if (c == '\n')  o += "\\n";
        else if (c != '\r')  o += c;
    }
    return o;
}
static std::string TsvUnesc(const std::string& in) {
    std::string o; o.reserve(in.size());
    for (size_t i = 0; i < in.size(); ++i) {
        if (in[i] == '\\' && i + 1 < in.size()) {
            char n = in[++i];
            o += (n == 't') ? '\t' : (n == 'n') ? '\n' : n;
        } else o += in[i];
    }
    return o;
}
static void SaveBookmarksCacheLocked() {   // g_net.mtx muss gehalten sein
    if (g_net.dataPath.empty()) return;
    FILE* f = fopen(BookmarksCachePath().c_str(), "w");
    if (!f) return;
    for (const auto& t : g_net.tweets)
        fprintf(f, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
                TsvEsc(t.id).c_str(), TsvEsc(t.text).c_str(),
                TsvEsc(t.author_name).c_str(),
                TsvEsc(t.author_handle).c_str(),
                TsvEsc(t.created_at).c_str(),
                TsvEsc(t.thumb_url ? *t.thumb_url : "").c_str(),
                TsvEsc(t.media_type ? *t.media_type : "").c_str(),
                TsvEsc(t.url).c_str());
    fclose(f);
}
static int LoadBookmarksCache() {
    if (g_net.dataPath.empty()) return 0;
    FILE* f = fopen(BookmarksCachePath().c_str(), "r");
    if (!f) return 0;
    std::vector<Tweet> loaded;
    char line[16384];
    while (fgets(line, sizeof(line), f)) {
        std::string ln(line);
        while (!ln.empty() && (ln.back() == '\n' || ln.back() == '\r'))
            ln.pop_back();
        std::vector<std::string> col; std::string cur;
        for (char c : ln) {
            if (c == '\t') { col.push_back(cur); cur.clear(); }
            else cur += c;
        }
        col.push_back(cur);
        if (col.size() < 8) continue;      // kaputte Zeile ueberspringen
        Tweet t;
        t.id            = TsvUnesc(col[0]);
        t.text          = TsvUnesc(col[1]);
        t.author_name   = TsvUnesc(col[2]);
        t.author_handle = TsvUnesc(col[3]);
        t.created_at    = TsvUnesc(col[4]);
        if (!col[5].empty()) t.thumb_url  = TsvUnesc(col[5]);
        if (!col[6].empty()) t.media_type = TsvUnesc(col[6]);
        t.url           = TsvUnesc(col[7]);
        if (!t.id.empty()) loaded.push_back(std::move(t));
    }
    fclose(f);
    if (loaded.empty()) return 0;
    std::lock_guard<std::mutex> l(g_net.mtx);
    g_net.tweets = std::move(loaded);
    return (int)g_net.tweets.size();
}

static void StartLoading() {
    if (g_net.loading.exchange(true)) return;
    SetStatus("Lade Bookmarks...");
    std::thread([] {
        int count = 0;
        try {
            // FRISCH beginnen: Der Server-Stand ERSETZT die Liste.
            // [Vorher wurde nur angehaengt -- ein zweites "Laden" (und
            // erst recht "Laden" ueber dem Start-Cache) verdoppelte
            // saemtliche Eintraege.]
            { std::lock_guard<std::mutex> l(g_net.mtx);
              g_net.tweets.clear(); }
            g_net.client->fetch_all_bookmarks([&](const std::vector<Tweet>& page) {
                std::lock_guard<std::mutex> l(g_net.mtx);
                for (const auto& t : page) g_net.tweets.push_back(t);
                count += (int)page.size();
                g_net.status = "Geladen: " + std::to_string(count) + "...";
            });
            { std::lock_guard<std::mutex> l(g_net.mtx);
              SaveBookmarksCacheLocked(); }        // Cache aktualisieren
            SetStatus("Fertig: " + std::to_string(count) + " Bookmarks.");
        } catch (const std::exception& e) {
            SetStatus(std::string("Fehler: ") + e.what());
        }
        g_net.loading = false;
    }).detach();
}

void imgui_init(AppCtx& app, android_app* aapp) {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();

    // Dateipfade auf Android: Apps duerfen NUR in ihre eigenen Verzeichnisse
    // schreiben. Der korrekte, beschreibbare Pfad kommt zur Laufzeit aus der
    // NativeActivity: internalDataPath (z.B. /data/user/0/<paket>/files).
    // Hartkodierte Pfade wie "./" oder "/sdcard/..." scheitern an
    // Berechtigungen -- deshalb hier das imgui.ini dorthin legen und den
    // Pfad loggen. In Schritt 2 nutzen cookies.json und der Thumbnail-Cache
    // denselben Mechanismus.
    static std::string iniPath;
    if (aapp->activity && aapp->activity->internalDataPath) {
        iniPath = std::string(aapp->activity->internalDataPath) + "/imgui.ini";
        io.IniFilename = iniPath.c_str();
        LOGI("internalDataPath: %s", aapp->activity->internalDataPath);
        MbedtlsSelfTest();
        g_net.dataPath = aapp->activity->internalDataPath;
        // Basis fuer UiReadFile/UiWriteFile: der EINZIGE beschreibbare
        // Pfad der App. Ohne das zeigen relative Namen auf "/" und
        // fopen scheitert -> ungeprueftes fputs bricht den Prozess ab.
        UiFilesSetBaseDir(aapp->activity->internalDataPath);
        set_thumbnail_cache_dir(g_net.dataPath + "/thumb_cache");
        if (!g_thumbs) g_thumbs = new ThumbnailManager();
        std::string a, c;
        if (int nb = LoadBookmarksCache())
            SetStatus(std::to_string(nb) +
                      " Bookmarks aus dem Cache -- 'Laden' aktualisiert.");
        if (LoadCookiesAndroid(a, c)) {
            g_net.client = std::make_unique<XClient>(a, c);
            g_net.status = "Cookies geladen -- 'Laden' druecken.";
        }
    } else {
        io.IniFilename = nullptr; // Fallback: kein Schreiben
        LOGE("internalDataPath nicht verfuegbar -- ini deaktiviert");
    }

    // Touch-freundliche Skalierung: Android-Displays sind hochaufloesend.
    float scale = 3.0f;
    ImGui::GetStyle().ScaleAllSizes(scale);
    io.FontGlobalScale = scale;

    io.ConfigWindowsMoveFromTitleBarOnly = true;
    // Docking: Andock-Anker + Tab-Gruppierung beim Ziehen an der Titel-
    // leiste. War nur im Desktop-Pfad gesetzt -- daher auf Android bisher
    // keine Anker sichtbar.
    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
    AndroidClipboard::Install(aapp);   // GBoard-/System-Zwischenablage
    // EINE WAHRHEITSQUELLE: ImGuis eigene imgui.ini wird ABGESCHALTET.
    // Zwei parallele Persistenzsysteme (imgui.ini UND unsere xbm.ini-
    // Zustandsmaschine) haben sich wechselseitig Fensterzustaende
    // ueberschrieben -- die Wurzel der Inkonsistenzen. Ab jetzt verwaltet
    // AUSSCHLIESSLICH app_settings/ui_pages die Fensterdaten: Frei-
    // Position+Groesse pro Seite, komplette Kompakt-Baeume pro Seite,
    // Boot-Anwendung, Selbstheilung.
    ImGui::GetIO().IniFilename = nullptr;
    // Seiten registrieren (v1): eine Hauptseite mit allen App-Fenstern
    if (UiPages().empty()) {
        UiPages().push_back({"Haupt"});
        UiPages().push_back({"Effekte"});
        UiPages().push_back({"Bewerben"});
        // Modell pro Fenster: UiWinShared = ein Fenster ueberall (Daten
        // eins, Geometrie pro Seite); UiWinPerPage = eigene Instanz
        // "Name##Seite" mit komplett eigenem Zustand.
        UiPageAdd("Haupt",   "X Bookmark Manager",       UiWinShared);
        UiPageAdd("Haupt",   "Eingabe-Monitor",          UiWinShared);
        // WICHTIG: JEDES dockbare Fenster gehoert in eine Registry --
        // unregistrierte Fenster sind fuer die Zustandsmaschine Fremd-
        // koerper: manuell in einen Host gedockt, filtert die (korrekte)
        // Cross-Tab-Schutzlogik sie aus dem Seiten-Baum, und der naechste
        // Wiederaufbau wirft sie hinaus (der "Login dockt ab"-Effekt).
        UiPageAdd("Haupt",   "X Login (Cookies)",        UiWinShared);
        // Reddit und Facebook ueber den gemeinsamen Manager. X behaelt auf
        // Android seine eigene Anbindung (Cache, Login-Uebergabe) -- die ist
        // erprobt, und sie zu ersetzen waere hier ein eigenes Vorhaben.
        UiPageAdd("Haupt",   "Reddit Bookmark Manager",  UiWinShared);
        UiPageAdd("Haupt",   "Facebook Bookmark Manager",UiWinShared);
        AndroidPmReddit().LoadCookies(XbmPaths_UserData());
        AndroidPmFacebook().LoadCookies(XbmPaths_UserData());
        UiPageAdd("Effekte", "Rain",                     UiWinShared);
        UiPageAdd("Effekte", "Spin (ziehen = drehen)",   UiWinShared);
        UiPageAdd("Effekte", "Dreieck (normal)",         UiWinShared);
        // MODELL B (eigene Instanz je Seite): Ein GETEILTES Fenster kann
        // nur an EINER Stelle gedockt sein -- beim Seitenwechsel verlor
        // es daher seinen Platz. Mit "Shader-Canvas##Seite" haelt jede
        // Seite ihre eigene Dock-Position.
        UiPageAdd("Effekte", "Shader-Canvas",            UiWinPerPage);
        UiPageAdd("Haupt",   "Shader-Canvas",            UiWinPerPage);
        UiPageAdd("Bewerben","Prototype",                UiWinPerPage);
        UiPages().push_back({"Kalender"});
        UiPageAdd("Kalender", "Kalender",                UiWinShared);
        // NETZWERK: eigene Seite, wie auf dem Desktop. UiWinShared -- es
        // gibt nur EINEN Netzknoten, sein Zustand lebt in XbmNetNode.
        UiPages().push_back({"Netzwerk"});
        UiPageAdd("Netzwerk", "Netzwerk",                UiWinShared);
        // JOBS: Queues aus jobflow (Vorlagen, Jobbaum, Laeufe). UiWinShared.
        UiPages().push_back({"Jobs"});
        UiPageAdd("Jobs", "Jobs",                        UiWinShared);
        UiJobs_Init(UiCalendar_DataDir());
        // MEDIA: Audio (Video folgt): Dateien, Wellenform, Scrubber, Schnitt.
        UiPages().push_back({"Media"});
        UiPageAdd("Media", "Media",                      UiWinShared);
        UiMedia_Init(XbmPaths_UserData(), XbmPaths_DataRoot());
        UiNetworking_Start();
        // TEST-TABS zum Pruefen von Ueberlauf und Scrollen der Tab-Leiste.
        // [Wieder entfernen, wenn es sitzt -- oder XBM_TEST_TABS auf 0.]
        #ifndef XBM_TEST_TABS
        #define XBM_TEST_TABS 0
        #endif
        for (int ti = 1; ti <= XBM_TEST_TABS; ++ti) {
            std::string tn = "Test " + std::to_string(ti);
            UiPages().push_back({tn});
        }
        BewerbenInit();
        AppSettings::Load(std::string(
            AndroidClipboard::g_app->activity->internalDataPath)
            + "/xbm.ini");

        // -----------------------------------------------------------------
        // Zeitsteuerung, Mikrofon, Kalender -- identische Reihenfolge wie
        // auf dem Desktop (main.cpp): der Scheduler traegt die UI-Bruecke,
        // ueber die die Transkription ihr Ergebnis zurueckgibt.
        // -----------------------------------------------------------------
        {
            XbmSched_Start(/*poolThreads=*/2);
            // UPDATE-CHECK -- dieselbe URL wie auf dem Desktop (main.cpp),
            // release.json entscheidet ueber das Feld "android" selbst,
            // welches Plattform-Paket gilt.
            // Auto-Update-Schalter VOR der ersten Pruefung setzen -- sonst
            // wuerde eine beim Start erkannte Version nicht automatisch geladen.
            XbmUpdate_SetAuto(UiFlagGet("update.auto", false));
            XbmUpdate_PruefenAsync(
                "http://192.168.1.69:3000/releases/raw/branch/main/release.json");
            // APK-Installation: dieselbe Java-Methode wie "Datei oeffnen" --
            // sie kopiert nach Downloads und feuert ACTION_VIEW; fuer eine
            // .apk heisst das: der System-Installer geht auf.
            XbmUpdate_ApkInstallierenHook = OeffneDateiViaActivity;
            // Auf dem Handy KEIN Busy-Wait: Mikrosekunden sind hier nichts
            // wert, Akkulaufzeit dagegen sehr.
            XbmSched_SetSpinMargin(std::chrono::nanoseconds(0));

            const std::string base =
                AndroidClipboard::g_app->activity->internalDataPath;
            // Assets aus dem APK nach <internalDataPath>/data entpacken.
            // MUSS vor dem ersten Zugriff auf Vorlagen/Shader laufen.
            XbmPaths_InitAndroid(
                AndroidClipboard::g_app->activity->assetManager, base.c_str());
            XbmPaths_SetUserDir(base);
            XbmPaths_OeffnenExternHook = OeffneDateiViaActivity;
            XbmCrash_Init("android", UiTextGet("monitor.url"));
            XbmNet_Init();
            UiScrub_ClaimGesture = [] { UiDragHandledThisFrame() = true; };
            LOGI("%s", XbmPaths_Report().c_str());
            UiCalendar_Init(base + "/kalender");
            XbmStt_SetModelPath(base + "/ggml-base.bin");
            XbmStt_SetLanguage("de");

            UiCalendar_ClaimGesture = [] { UiDragHandledThisFrame() = true; };
            // Kanten-Navigation im Kalender richtet sich nach derselben
            // globalen Einstellung wie ueberall sonst in der App.
            UiCalendar_ScrollPinpoint = [] { return UiScrollPinpoint(); };
            // Sofort-Abgleich nach eigenen Aenderungen -- siehe main.cpp.
            UiCalendar_NetzAbgleichJetzt = [] { UiNetImpl::Node().AbgleichJetzt(); };
            // PINCH: Android liefert echte Mehrfingerpunkte ueber unsere
            // parallele Erfassungsschicht UiTouches() (handle_input).
            UiCalendar_GetTouches = [](float* xy, int maxPts) -> int {
                const auto& t = UiTouches();
                int n = (int)t.size();
                if (n > maxPts) n = maxPts;
                for (int i = 0; i < n; ++i) { xy[i*2] = t[i].x; xy[i*2+1] = t[i].y; }
                return n;
            };
            UiCalendar_SetReminderHandler([](const CalEntry& e) {
                LOGI("[erinnerung] %s um %s", e.title.c_str(),
                     XbmTime_Format(e.start, "%d.%m. %H:%M").c_str());
            });
        }
    } // Drag im Inhalt scrollt,
                                                  // bewegt NICHT das Fenster
    ImGui_ImplAndroid_Init(aapp->window);
    ImGui_ImplOpenGL3_Init("#version 300 es");

    // ImGui <-> Android-Zwischenablage: ImGuis interne Copy/Paste-Wege
    // (z.B. bei Hardware-Tastatur Ctrl+C/V, oder programmatisch) nutzen
    // damit die echte System-Zwischenablage.
    ImGuiPlatformIO& pio = ImGui::GetPlatformIO();
    pio.Platform_GetClipboardTextFn = [](ImGuiContext*) -> const char* {
        static std::string buf;
        buf = JniGetClipboardText();
        return buf.c_str();
    };
    pio.Platform_SetClipboardTextFn = [](ImGuiContext*, const char* text) {
        JniSetClipboardText(text);
    };

    app.imguiReady = true;
}

void imgui_shutdown(AppCtx& app) {
    if (!app.imguiReady) return;
    EffectsGl_Shutdown();  // GL-Objekte der Effekte freigeben
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    UiNetworking_Stop();   // Netz zuerst, geordnet -- nicht bei der statischen Zerstoerung
    ImGui::DestroyContext();
    app.imguiReady = false;
}


void frame(AppCtx& app) {
    // VOR dem Frame pruefen: Der Kontext muss hier aktuell sein, und
    // neu erzeugte Texturen stehen dann sofort fuer diesen Frame bereit.
    ValidateImGuiGpu();
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();
    UiLayoutLockNewFrame();   // Layout-Sperre VOR jedem Begin
    // Ergebnisse aus Hintergrundfaeden (Transkription, Erinnerungen) in den
    // UI-Thread holen -- VOR den Fenstern, damit sie in DIESEM Frame wirken.
    XbmSched_DrainUi();
    AndroidInsets::Apply();  // Safe-Areas: Status-/Navigationsleiste
    AppSettings::Periodic(); // gedrosseltes Speichern -- MUSS pro Frame
    // NETZWERK JEDEN FRAME BEDIENEN -- auch wenn der Tab nicht sichtbar
    // ist. [Sonst laufen Entdeckung und Abgleich nur, solange man
    //  hinsieht. Auf Android faellt das doppelt auf: die App liegt oft
    //  im Hintergrund, und genau dann soll der Abgleich weiterlaufen.]
    UiNetworking_Poll();
                             // laufen (lag faelschlich im Init-Block:
                             // Android speicherte deshalb NIE)
    // =====================================================================
    // PAGES ZUERST: Der DockSpace des Kompakt-Layouts muss VOR saemtlichen
    // Seitenfenstern submittet werden -- jedes davor gezeichnete Fenster
    // kann prinzipbedingt nicht andocken (Ursache des "Monitor snappt
    // rein, Rest fliegt raus"-Verhaltens: Rain/Spin/Dreieck standen im
    // gui() VOR dem Pages-Block). Neue Fenster IMMER unterhalb einfuegen.
    // =====================================================================
    // Docking-Checkbox anwenden (Punkt 1)
    if (EffectsGl_Settings().dockingEnabled)
        ImGui::GetIO().ConfigFlags |=  ImGuiConfigFlags_DockingEnable;
    else if (!(UiActivePage() && UiActivePage()->compact))
        // Docking-Flag NIE kappen, solange die aktive Seite kompakt ist:
        // ohne das Flag kehrt DockSpace() intern frueh zurueck, und
        // DockBuilderAddNode liefert NULL -> Null-Deref beim naechsten
        // Layout-Wiederaufbau (der gemeldete SIGSEGV). Die Checkbox
        // regelt Nutzer-Docking; das Kompakt-Fundament braucht das Flag.
        ImGui::GetIO().ConfigFlags &= ~ImGuiConfigFlags_DockingEnable;
    UiPagesFrame(/*touchMode=*/true);
    // (UiGlobalDragScroll ans Frame-Ende verlegt, s.u. vor ImGui::Render)
    // WICHTIG: Seitenfenster MUESSEN NACH UiPagesFrame submittet werden.
    // Ein Fenster, das VOR seinem DockSpace gezeichnet wird, kann in dem
    // Frame nicht andocken (ImGui setzt es floatend) -> der Monitor konnte
    // strukturell nie einrasten -> Dauer-Rebuild -> alle Fenster sprangen
    // im 0,3s-Takt aus dem Kompakt-Layout, inkl. weiss flackerndem
    // Uebergangs-Dock-Knoten als "zweitem" Monitor.
    static bool showInputDbg = true;
    if (UiPageWindow("Eingabe-Monitor"))
        UiShowInputDebugWindow(&showInputDbg);


    // Bildschirmtastatur automatisch oeffnen/schliessen, sobald ein
    // InputText den Fokus bekommt/verliert (io.WantTextInput-Flanke).
    // TASTATUR-STEUERUNG
    // - OEFFNEN: bei jeder frischen Aktivierung eines Textfeldes (neue
    //   ActiveId) ODER wenn der Nutzer erneut ins aktive Feld tippt.
    //   [Frueher haing das an der WantTextInput-FLANKE: hatte der Nutzer
    //   die Tastatur manuell geschlossen, blieb das Flag oben, es gab
    //   keine neue Flanke -- und sie liess sich nie wieder oeffnen.]
    // - SCHLIESSEN: unterdrueckt, solange eine Scroll-Geste laeuft
    //   (sonst verschwindet sie mitten im Wischen).
    {
        ImGuiIO& kio = ImGui::GetIO();
        ImGuiContext* kg = ImGui::GetCurrentContext();
        static bool     prevWant = false;
        static ImGuiID  prevAct  = 0;
        static double   keepUntil = 0.0;
        bool want = kio.WantTextInput;
        // Sofort schliessen, wenn der globale Schalter gerade aus ging.
        if (UiRequestHideKeyboard()) {
            UiRequestHideKeyboard() = false;
            ShowSoftKeyboard(false);
            want = false;
        }
        if (!UiKeyboardEnabled()) want = false;   // global abgeschaltet
        ImGuiID act = kg ? kg->ActiveId : 0;
        bool scrolling = UiScrollGestureActive() || kio.MouseDown[0];

        if (want && (act != prevAct || ImGui::IsMouseClicked(ImGuiMouseButton_Left)))
            ShowSoftKeyboard(true);          // Feld (neu) angetippt
        else if (want && !prevWant)
            ShowSoftKeyboard(true);

        // SCHLIESS-REGEL: Ein TAP auf eine Stelle ohne Textbedarf
        // faehrt die Tastatur ein. Wird aus DEMSELBEN Druck aber ein
        // PINPOINT (die globale Scroll-Geste greift), bleibt sie OFFEN
        // -- man scrollt nur kurz nach und tippt weiter. [Frueher galt
        // eine 0.8-s-Gnadenfrist NACH dem Scrollen; danach schloss sie
        // trotzdem.] Umsetzung als SCHARF/ENTSCHAERFT-Automat:
        //  * Textfokus verloren -> Schliessen SCHARF gestellt.
        //  * Greift waehrenddessen die Pinpoint-Geste -> entschaerft
        //    (Tastatur bleibt, bis ein spaeterer echter Tap kommt).
        //  * Finger geht ohne Geste hoch -> jetzt schliessen.
        static bool hideArmed = false;
        static bool wasDown   = false;
        static bool tapScroll = false;   // Geste im aktuellen Druck?
        static bool tapBar    = false;   // Druck auf einem Scrollbalken?
        if (ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
            tapScroll = false; tapBar = false;
            // SCROLLBALKEN-Ausnahme: Ein Griff am Balken ist Navigation,
            // kein "woanders hingetippt" -- die Tastatur bleibt offen.
            if (kg && kg->HoveredWindow) {
                ImGuiWindow* hw = kg->HoveredWindow;
                if (hw->ScrollbarY
                    && ImGui::GetWindowScrollbarRect(hw, ImGuiAxis_Y)
                           .Contains(kio.MousePos)) tapBar = true;
                if (hw->ScrollbarX
                    && ImGui::GetWindowScrollbarRect(hw, ImGuiAxis_X)
                           .Contains(kio.MousePos)) tapBar = true;
            }
        }
        if (kio.MouseDown[0] && UiScrollGestureActive()) tapScroll = true;
        if (!want && prevWant) hideArmed = true;
        if (want) hideArmed = false;             // Fokus zurueck
        if (hideArmed && UiScrollGestureActive())
            hideArmed = false;                   // Pinpoint: offen lassen
        // SCROLLBALKEN-Ausnahme: Wer am Balken zieht, scrollt nur --
        // die Tastatur bleibt offen (wie beim Pinpoint).
        if (hideArmed) {
            ImGuiContext* gk = ImGui::GetCurrentContext();
            if (gk && gk->ActiveId != 0 && gk->ActiveIdWindow) {
                ImGuiWindow* aw = gk->ActiveIdWindow;
                if (gk->ActiveId
                        == ImGui::GetWindowScrollbarID(aw, ImGuiAxis_X)
                 || gk->ActiveId
                        == ImGui::GetWindowScrollbarID(aw, ImGuiAxis_Y))
                    hideArmed = false;
            }
        }
        // TIPP INS LEERE schliesst die Tastatur: Loslassen ohne Text-
        // bedarf, ohne laufende Pinpoint-Geste und nicht auf einem
        // Scrollbalken -- unabhaengig davon, ob vorher ein Textfeld den
        // Fokus hatte (vorher blieb sie offen, solange kein Fokus-
        // WECHSEL stattfand).
        if (wasDown && !kio.MouseDown[0] && !want
            && !tapScroll && !tapBar && !UiScrollGestureActive()) {
            ShowSoftKeyboard(false);
            hideArmed = false;
        } else if (hideArmed && wasDown && !kio.MouseDown[0]) {
            ShowSoftKeyboard(false);             // sauberer Tap-Abschluss
            hideArmed = false;
        }
        wasDown = kio.MouseDown[0];
        (void)scrolling; (void)keepUntil;
        prevWant = want;
        prevAct  = act;
    }

    PollImeText();   // IME-Eingaben (inkl. Zwischenablage) einsammeln
    PollImeKeys();   // Cursortasten (Gboard-Leertastenwisch u.a.)
    float imeRaw = 0.0f;
    {   // Tastaturhoehe weich nachfuehren (kein Sprung, kein Ruckeln)
        float target = (float)QueryImeHeight();
        imeRaw = target;               // ROH fuer die Seiten-Anpassung
        float dt = ImGui::GetIO().DeltaTime;
        float k = 1.0f - expf(-12.0f * (dt > 0.001f ? dt : 0.016f));
        g_imeH += (target - g_imeH) * k;
        if (fabsf(target - g_imeH) < 0.5f) g_imeH = target;
    }
    {   // DockPage-Unterkante an die TASTATUR-Oberkante kleben: Die IME
        // wirkt wie eine zusaetzliche untere Systemleiste -- der
        // Arbeitsbereich schrumpft um die ROHE Hoehe und damit
        // UNVERZOEGERT (g_imeH ist absichtlich geglaettet und bleibt
        // fuer die weichen Nachfuehrungen anderer Stellen). Alle
        // WorkPos/WorkSize-Nutzer (Seiten-Host, dockH-Untergrenze,
        // Maximieren) enden dadurch exakt an der Tastatur.
        ImGuiViewport* vp = ImGui::GetMainViewport();
        // GEGLAETTET (g_imeH) statt roh: Die DockPage-Unterkante GLEITET
        // mit der Tastatur beim Ein- UND Ausblenden mit, statt zu
        // springen -- Android meldet naemlich sofort die ENDhoehe, nicht
        // die Animationszwischenwerte; unsere weiche Nachfuehrung ist
        // die Animation. Die Caret-Nagelung gleicht jede Zwischenlage
        // pro Frame exakt aus, der Inhalt steht dabei optisch still.
        // DOPPEL-ABZUG VERHINDERN: getSystemWindowInsetBottom (die
        // Quelle von AndroidInsets::g_bottom) ENTHAELT auf vielen
        // Geraeten die Tastatur bereits -- Apply() hatte den Bereich
        // dann schon (teilweise, bis 1 s verzoegert) verkleinert, und
        // unser g_imeH zog dieselbe Hoehe NOCHMAL ab: die Seite hing
        // je nach Poll-Timing zu hoch oder sprang nach. Wir merken uns
        // die GRUNDLINIE der unteren Leiste (kleinster je gesehener
        // Wert = Navigationsleiste ohne Tastatur) und ziehen nur den
        // Anteil ab, den die Insets NICHT schon abgedeckt haben.
        static float navBase = -1.0f;
        if (navBase < 0.0f
            || AndroidInsets::g_bottom < navBase - 0.5f)
            navBase = AndroidInsets::g_bottom;
        float insetIme = AndroidInsets::g_bottom - navBase;
        if (insetIme < 0.0f) insetIme = 0.0f;
        // EINE Glaettungsstelle statt zwei: vorher wurde g_imeH (12/s,
        // traege) MINUS die nur 4x/s springende insetIme verrechnet --
        // das gab Ruckler, und beim Ausblenden zog die Seite erst nach,
        // wenn die Tastatur laengst weg war. Jetzt wird direkt das
        // ROH-Ziel (imeRaw - insetIme) mit flotten 25/s angefahren:
        // fluessig UND praktisch verzoegerungsfrei in beide Richtungen.
        // Die Hoehe IST jetzt die laufende System-Animation (der
        // WindowInsetsAnimation-Callback in XbmActivity liefert die
        // Zwischenwerte pro Frame). Deshalb nur noch eine SEHR kurze
        // Glaettung gegen Messrauschen -- jede staerkere Filterung
        // wuerde die Oberflaeche wieder hinter der Tastatur herhinken
        // lassen. Sprung >0.5*Bildhoehe (Geraet gedreht, Poll-Wechsel)
        // wird hart uebernommen statt weggeglaettet.
        static float effIme = 0.0f;
        float effTarget = imeRaw - insetIme;
        if (effTarget < 0.0f) effTarget = 0.0f;
        {
            float dt = ImGui::GetIO().DeltaTime;
            float k = 1.0f - expf(-60.0f * (dt > 0.001f ? dt : 0.016f));
            if (fabsf(effTarget - effIme) > vp->WorkSize.y * 0.5f)
                effIme = effTarget;
            else effIme += (effTarget - effIme) * k;
            if (fabsf(effTarget - effIme) < 0.5f) effIme = effTarget;
        }
        if (effIme > 0.5f) {
            vp->WorkSize.y -= effIme;
            if (vp->WorkSize.y < 100.0f) vp->WorkSize.y = 100.0f;
        }
        // Sichtbaren Bereich veroeffentlichen: Fenster und Textflaechen
        // koennen sich so an den durch die Tastatur verkleinerten Platz
        // anpassen (kein Scrollbalken, Text bleibt sichtbar).
        UiVisTop()    = vp->WorkPos.y;
        UiVisBottom() = vp->WorkPos.y + vp->WorkSize.y;
        UiImeOpen()   = (effIme > 0.5f);
        UiImeAvoidance(effIme > 0.5f, vp->WorkPos.y,
                       vp->WorkPos.y + vp->WorkSize.y);
        // Rand-Automatik: am oberen/unteren Rand weiterscrollen,
        // solange eine Geste laeuft (Pinpoint oder Fenster-Zug).
        UiEdgeAutoScroll(vp->WorkPos.y, vp->WorkPos.y + vp->WorkSize.y);
        // Frei schwebende Fenster in den (durch die Tastatur
        // verkleinerten) sichtbaren Bereich holen -- und beim Einfahren
        // wieder zuruecksetzen.
        UiFitWindowsToKeyboard();
    }

    // ---- Effekte + Bookmark-Fenster ---------------------------------------
    // Rain & Spin: identischer Code wie auf dem Desktop (effects_gl.cpp),
    // gerendert in verschiebbare ImGui-Fenster -- der einzige Weg, der auf
    // Android funktioniert (transparente OS-Overlay-Fenster existieren dort
    // nicht) und gleichzeitig Desktop-kompatibel ist.
    static bool showRain = true, showSpin = true, showBookmarks = true;
    // Schliess-Wuensche der NACHGELIEFERTEN X-Knoepfe (Fenster ohne
    // open-Zeiger bekommen ihn vom Titel-Cluster) hier konsumieren.
    if (UiConsumeClose("Rain"))                 showRain      = false;
    if (UiConsumeClose("Spin (ziehen = drehen)")) showSpin    = false;
    if (UiConsumeClose("X Bookmark Manager"))   showBookmarks = false;
    // (Pages-Block an den gui()-Anfang verschoben, s.u.)

    EffectsGl_DrawBackground();  // 2.2: Shader hinter allen Fenstern
    EffectsGl_DrawOverlay();     // 2.3: Shader-Overlay ueber allem
    static bool showTriN = true, showTriOv = true;
    // GATES (die lange offene Restluecke): Seitenfenster duerfen NUR auf
    // ihrer Seite submittet werden. Ein Fenster, das auf einer fremden
    // Seite gezeichnet wird, waehrend sein DockSpace dort nicht submittet
    // ist, faellt bei ImGui auf Floating zurueck -- daher die konstanten
    // "Overlay"-Positionen ueber alle Tabs und das Herausfallen trotz
    // Andockung.
    if (UiPageWindow("Rain"))
        EffectsGl_ShowRainWindow(&showRain);
    if (UiPageWindow("Spin (ziehen = drehen)"))
        EffectsGl_ShowSpinWindow(&showSpin);
    if (UiPageWindow("Dreieck (normal)"))
        EffectsGl_ShowTriangleNormal(&showTriN);
    // BEWERBEN/PROTOTYPE: Der Aufruf fehlte auf Android komplett --
    // deshalb tauchte das Fenster nirgends auf. Der Titel MUSS von
    // UiPageWindow kommen: Er liefert den gescopten Namen
    // ("Prototype##Bewerben") und nullptr auf allen anderen Seiten --
    // genau das macht das Fenster seitenspezifisch UND speicherbar.
    {
        const char* tProto = UiPageWindow("Prototype");
        UiWinDoctor_NoteSubmit("Prototype", tProto);
        if (tProto) UiDrawBewerbenUI(tProto, nullptr);
    }
    {
        static bool showCal = true;
        const char* tCal = UiPageWindow("Kalender");
        UiWinDoctor_NoteSubmit("Kalender", tCal);
        if (tCal) UiCalendar_Draw(tCal, &showCal, UiWinFlags(tCal));
    }
    // Netzwerk -- ebenfalls NACH UiPagesFrame() submittet (Dock-Regel).
    {
        const char* tNet = UiPageWindow("Netzwerk");
        UiWinDoctor_NoteSubmit("Netzwerk", tNet);
        if (tNet) {
            bool offen = true;
            if (ImGui::Begin(tNet, &offen, UiWinFlags(tNet)))
                UiNetworking_Draw();
            ImGui::End();
        }
    }
    // Media -- NACH UiPagesFrame() submittet.
    {
        const char* tMed = UiPageWindow("Media");
        UiWinDoctor_NoteSubmit("Media", tMed);
        if (tMed) {
            bool offen = true;
            if (ImGui::Begin(tMed, &offen, UiWinFlags(tMed)))
                UiMedia_Draw();
            ImGui::End();
        }
    }
    // Jobs -- ebenfalls NACH UiPagesFrame() submittet.
    {
        UiJobs_Poll();
        const char* tJobs = UiPageWindow("Jobs");
        UiWinDoctor_NoteSubmit("Jobs", tJobs);
        if (tJobs) {
            bool offen = true;
            if (ImGui::Begin(tJobs, &offen, UiWinFlags(tJobs)))
                UiJobs_Draw();
            ImGui::End();
        }
    }
    // Das ORANGE, TRANSPARENTE Dreieck ist das Overlay-Fenster --
    // hier gehoert die Checkbox hin (das Gate sass zuvor faelschlich
    // auf "Dreieck (normal)", weshalb das Overlay unbeirrt weiterflog).
    if (EffectsGl_Settings().showTriangle)
        EffectsGl_ShowTriangleOverlay(&showTriOv);

    // Bookmark-Fenster mit ECHTEN Daten via XClient (curl+mbedTLS).
    if (g_thumbs) g_thumbs->poll();

    // PLATZ-UEBERGABE Login -> Bookmark-Manager: Beim erfolgreichen
    // "Speichern & verbinden" werden Position, GROESSE und DOCK-KNOTEN
    // des Login-Fensters eingefangen. Das Bookmark-Fenster uebernimmt
    // dann exakt dessen Platz: angedockt in DENSELBEN Knoten (gleiche
    // Stelle, gleiche Masse), freischwebend an exakt Position+Groesse.
    static bool    loginHandover     = false;
    // RUECKKEHR zum Login (Knopf neben Max im Bookmark-Fenster): das
    // LOGIN-Fenster uebernimmt dabei symmetrisch den Platz des
    // Bookmark-Fensters (Dock-Knoten bzw. Position; die Groesse regelt
    // AlwaysAutoResize selbst).
    static bool    backToLogin       = false;
    static bool    loginBackPending  = false;
    static ImVec2  loginBackPos      = ImVec2(0, 0);
    static ImGuiID loginBackDock     = 0;
    static ImVec2  loginHandoverPos  = ImVec2(0, 0);
    static ImVec2  loginHandoverSize = ImVec2(0, 0);
    static ImGuiID loginHandoverDock = 0;
    static int     loginHandoverTries = 0;

    // ERSTER Konsument des nachgelieferten Cluster-X: Das Login hat
    // kein open-Flag (Begin mit nullptr) -- unser X blendet es aus.
    // Wieder sichtbar wird es ueber den "Login"-Knopf im Bookmark-
    // Fenster (oder App-Neustart); unverbunden geschlossen bleibt der
    // Schirm bewusst leer statt unschliessbar.
    static bool loginClosed = false;
    if (UiConsumeClose("X Login (Cookies)"))
        loginClosed = true;
    if (backToLogin) loginClosed = false;
    if ((!g_net.client || backToLogin) && !loginClosed
        && UiPageWindow("X Login (Cookies)")) {
        if (loginBackPending) {
            if (loginBackDock != 0) {
                // Bookmark war angedockt: Login in DENSELBEN Knoten.
                ImGui::SetNextWindowDockID(loginBackDock,
                                           ImGuiCond_Always);
                ImGui::SetNextWindowFocus();
                for (auto& pgf : UiPages())
                    ui_pages_detail::UserFreeSet(
                        pgf.name, "X Login (Cookies)", false);
            } else {
                // Bookmark schwebte: Login exakt an seine Position --
                // und gegen den EINSAMMEL-Pass als befreit markieren.
                ImGui::SetNextWindowDockID(0, ImGuiCond_Always);
                ImGui::SetNextWindowPos(loginBackPos, ImGuiCond_Always);
                for (auto& pgf : UiPages())
                    ui_pages_detail::UserFreeSet(
                        pgf.name, "X Login (Cookies)", true);
            }
            loginBackPending = false;
        }
        // Gate wie bei allen Seitenfenstern: ungegated wuerde das Fenster
        // auf fremden Seiten submittet, dort in den Floating-Fallback
        // kippen und seine Position quer durch Seiten/Modi schleppen.
        // Cookie-Eingabe direkt in der App -- loest zugleich das Problem,
        // wie cookies.json auf das Geraet kommt (internalDataPath ist
        // app-privat, adb push geht dort nicht ohne weiteres hinein).
        ImGui::SetNextWindowPos(ImVec2(20, 60), ImGuiCond_FirstUseEver);
        ImGui::Begin("X Login (Cookies)", nullptr,
                     ImGuiWindowFlags_AlwaysAutoResize
                     | UiWinFlags("X Login (Cookies)"));
        // AutoSelectAll: Antippen markiert den gesamten Inhalt -- Tippen
        // ersetzt ihn, "Kopieren" greift ihn ab. Feinere Markierung: mit
        // dem Finger ueber den Text ziehen (ImGui-eigene Selektion),
        // Doppeltipp markiert ein Wort.
        UiFormInput("auth_token", g_net.inAuth, sizeof(g_net.inAuth),
                         ImGuiInputTextFlags_AutoSelectAll);
        ClipPasteButton("pa", g_net.inAuth, sizeof(g_net.inAuth));
        ImGui::SameLine();
        if (ImGui::Button("Einfuegen##a")) {
            std::string clip = JniGetClipboardText();
            snprintf(g_net.inAuth, sizeof(g_net.inAuth), "%s", clip.c_str());
        }
        ImGui::SameLine();
        if (ImGui::Button("Kopieren##a")) JniSetClipboardText(g_net.inAuth);

        UiFormInput("ct0", g_net.inCt0, sizeof(g_net.inCt0),
                         ImGuiInputTextFlags_AutoSelectAll);
        ClipPasteButton("pc", g_net.inCt0, sizeof(g_net.inCt0));
        ImGui::SameLine();
        if (ImGui::Button("Einfuegen##c")) {
            std::string clip = JniGetClipboardText();
            snprintf(g_net.inCt0, sizeof(g_net.inCt0), "%s", clip.c_str());
        }
        ImGui::SameLine();
        if (ImGui::Button("Kopieren##c")) JniSetClipboardText(g_net.inCt0);
        if (ImGui::Button("Speichern & verbinden")) {
            if (g_net.inAuth[0] && g_net.inCt0[0]) {
                SaveCookiesAndroid(g_net.inAuth, g_net.inCt0);
                g_net.client = std::make_unique<XClient>(g_net.inAuth, g_net.inCt0);
                SetStatus("Verbunden -- 'Laden' druecken.");
                // Wir sind hier INNERHALB des Login-Begin/End -- Lage,
                // Groesse und (falls angedockt) der Dock-Knoten sind
                // also exakt das, was der Bookmark-Manager erben soll.
                loginHandoverPos  = ImGui::GetWindowPos();
                loginHandoverSize = ImGui::GetWindowSize();
                loginHandoverDock = ImGui::IsWindowDocked()
                                  ? ImGui::GetWindowDockID() : 0;
                loginHandover     = true;
                loginHandoverTries = 0;
                backToLogin       = false;
            }
        }
        ImGui::TextWrapped("%s", g_net.status.c_str());
        ImGui::End();
    }
    // BEWUSST KEIN else: Im KLICK-Frame ist g_net.client bereits gesetzt,
    // waehrend das Login-Fenster in DIESEM Frame noch submittet wurde --
    // der Bookmark-Manager dockt also in einen Knoten, der GARANTIERT
    // noch lebt. (Mit else laege ein Frame dazwischen, in dem der leere
    // Login-Knoten von ImGui weggeraeumt wuerde -- SetNextWindowDockID
    // liefe dann auf eine tote ID und das Fenster fiele floatend heraus.)
    // REDDIT UND FACEBOOK -- UNABHAENGIG VOM X-LOGIN.
    // [Der Block stand vorher INNERHALB von  if (g_net.client && ...),
    //  also im X-Zweig: ohne angemeldetes X gab es die beiden Fenster
    //  nicht. Genau deshalb fehlten sie im APK.]
    {
        // Reddit und Facebook: Manager und Login je Plattform.
        {
            AndroidPmReddit().Drain(); AndroidPmFacebook().Drain();
            struct { PlatformManager* pm; const char* mgr; } fenster[] = {
                { &AndroidPmReddit(),   "Reddit Bookmark Manager"   },
                { &AndroidPmFacebook(), "Facebook Bookmark Manager" },
            };
            // EIN EINZIGER SCHALTER (siehe main.cpp).
            for (auto& f : fenster) {
                if (const char* t = UiPageWindow(f.mgr)) {
                    ImGui::SetNextWindowPos(ImVec2(20, 80), ImGuiCond_FirstUseEver);
                    f.pm->DrawManager(t, &UiWinOpen(f.mgr), UiWinFlags(t));
                }
            }
        }
    }

    if (g_net.client && !backToLogin) {
        std::vector<BookmarkItem> items;
        std::string status;
        {
            std::lock_guard<std::mutex> l(g_net.mtx);
            items.reserve(g_net.tweets.size());
            for (const auto& t : g_net.tweets) {
                if (g_thumbs) g_thumbs->request(t.id, t.thumb_url);
                items.push_back({t.id, "@" + t.author_handle, t.text});
            }
            status = g_net.status;
        }
        BookmarkCallbacks cb;
        cb.onLoad = [] { StartLoading(); };
        cb.onLogin = [] {
            // Laeuft INNERHALB des Bookmark-Begin: Geometrie ist die
            // des Bookmark-Fensters und wird ans Login uebergeben.
            loginBackDock = ImGui::IsWindowDocked()
                          ? ImGui::GetWindowDockID() : 0;
            loginBackPos  = ImGui::GetWindowPos();
            loginBackPending = true;
            backToLogin      = true;
        };
        cb.getTexture = [](const std::string& id) -> unsigned int {
            return g_thumbs ? g_thumbs->get_texture(id) : 0;
        };
        cb.onDelete = [](const std::vector<std::string>& ids) {
            std::thread([ids] {
                int ok = 0;
                for (const auto& id : ids) {
                    if (g_net.client->delete_bookmark(id)) {
                        ok++;
                        std::lock_guard<std::mutex> l(g_net.mtx);
                        for (size_t i = 0; i < g_net.tweets.size(); ++i)
                            if (g_net.tweets[i].id == id) {
                                g_net.tweets.erase(g_net.tweets.begin() + i);
                                break;
                            }
                        g_net.selected.erase(id);
                    }
                }
                { std::lock_guard<std::mutex> l(g_net.mtx);
                  SaveBookmarksCacheLocked(); }    // Cache nachziehen
                SetStatus("Entfernt: " + std::to_string(ok) + "/" +
                          std::to_string(ids.size()));
            }).detach();
        };
        if (UiPageWindow("X Bookmark Manager")) {
            // Gate (letzte ungegatete Registrierung): auf fremden Seiten
            // fiel das Fenster in den Floating-Fallback, DockIsActive war
            // falsch, und der Maximiert-Zweig setzte es JEDEN Frame auf
            // WorkPos -- exakt VOR die Tab-Leiste.
            ImGui::SetNextWindowPos(ImVec2(20, 60), ImGuiCond_FirstUseEver);
            if (loginHandover) {
                // WIEDERHOLT anwenden, bis es SITZT (max ~45 Frames):
                // Der Einmal-Schuss verlor gegen Einsammel-Pass, Layout-
                // Builder und ini-Wiederherstellung -- das Fenster
                // "schwebte in der Luft". DockBuilderDockWindow wirkt
                // zusaetzlich ueber die Settings, auch bevor das
                // Fenster existiert.
                ImGuiWindow* exw =
                    ImGui::FindWindowByName("X Bookmark Manager");
                bool sitzt = false;
                if (loginHandoverDock != 0) {
                    // Login war ANGEDOCKT: in DENSELBEN Knoten -- gleiche
                    // Stelle, gleiche Masse (die bestimmt der Knoten, der
                    // seine Groesse behaelt). SetNextWindowFocus macht den
                    // Bookmark-Tab sofort aktiv; im Klick-Frame teilen
                    // sich beide Fenster den Knoten fuer genau einen
                    // Frame, danach verschwindet der Login-Tab.
                    ImGui::DockBuilderDockWindow("X Bookmark Manager",
                                                 loginHandoverDock);
                    ImGui::SetNextWindowDockID(loginHandoverDock,
                                               ImGuiCond_Always);
                    if (loginHandoverTries == 0) ImGui::SetNextWindowFocus();
                    // Wieder normal einsammelbar (falls frueher befreit).
                    for (auto& pgf : UiPages())
                        ui_pages_detail::UserFreeSet(
                            pgf.name, "X Bookmark Manager", false);
                    sitzt = exw && exw->DockNode
                         && exw->DockNode->ID == loginHandoverDock;
                } else {
                    // Login war FREISCHWEBEND: exakt an dessen Position
                    // und exakt in dessen Groesse -- ein eventuell noch
                    // angedockter Bookmark-Manager wird dafuer bewusst
                    // ausgedockt (DockID 0). Die GROESSE laeuft NICHT
                    // ueber SetNextWindowSize: DrawBookmarkWindow ruft
                    // selbst SetNextWindowSize(FirstUseEver) und
                    // UEBERSCHREIBT damit die NextWindow-Daten -- der
                    // Wunsch ginge verloren. Deshalb direkt am Fenster-
                    // objekt setzen; existiert es noch nicht (aller-
                    // erstes Erscheinen), bleibt der Handover stehen
                    // und greift im naechsten Frame.
                    ImGui::SetNextWindowDockID(0, ImGuiCond_Always);
                    ImGui::SetNextWindowPos(loginHandoverPos,
                                            ImGuiCond_Always);
                    // OHNE DIES KEINE UEBERNAHME: Der EINSAMMEL-Pass der
                    // Seite dockt jedes registrierte Fenster, das
                    // ausserhalb des Seiten-Baums schwebt, im naechsten
                    // Frame zurueck in den Stapel -- er frass die frisch
                    // gesetzte Login-Position sofort wieder auf. Die
                    // "vom Nutzer befreit"-Markierung nimmt das Fenster
                    // vom Einsammeln aus (derselbe Mechanismus wie beim
                    // manuellen Herausziehen).
                    for (auto& pgf : UiPages())
                        ui_pages_detail::UserFreeSet(
                            pgf.name, "X Bookmark Manager", true);
                    if (exw) {
                        ImGui::SetWindowPos(exw, loginHandoverPos,
                                            ImGuiCond_Always);
                        ImGui::SetWindowSize(exw, loginHandoverSize,
                                             ImGuiCond_Always);
                        sitzt = !exw->DockIsActive
                             && fabsf(exw->Pos.x - loginHandoverPos.x) < 2.0f
                             && fabsf(exw->Pos.y - loginHandoverPos.y) < 2.0f;
                    }
                }
                if (sitzt || ++loginHandoverTries > 45)
                    loginHandover = false;
            }
            DrawBookmarkWindow("X Bookmark Manager", items, g_net.selected,
                               cb, status, &showBookmarks);
        }
    }
    // -----------------------------------------------------------------------

    // Globaler Drag-Scroll-Standard: MUSS NACH allen Fenstern laufen,
    // damit die "behandelt"-Flags lokaler Logik im SELBEN Frame wirken.
    // Vorher lief er vor den Fenstern -> lokale Handler und der globale
    // scrollten abwechselnd DOPPELT (Vorframe-Flag) = ruckeliger,
    // bruchhafter Scroll z.B. im Eingabe-Monitor.
    UiLayoutLockEnforce();    // globale Sperre zuerst
    UiFixedHeightEnforce();   // letztes Wort ueber fixierte Hoehen
    UiGlobalDragScroll(/*touchMode=*/true);
    // Frei-Fenster-Push bewusst AUS: "Resize Affects Neighbors" wirkt
    // nur im Kompakt-Layout (Splitter-Kaskade); freie Fenster druecken
    // sich nicht gegenseitig weg.
    if (UiPagesFrameNurWarm()) { ImGui::EndFrame(); return; }   // Warmlauf: nicht praesentieren
    ImGui::Render();
    glViewport(0, 0, app.egl.width, app.egl.height);
    glClearColor(0.06f, 0.06f, 0.08f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(app.egl.display, app.egl.surface);
}

void handle_cmd(android_app* aapp, int32_t cmd) {
    auto* app = static_cast<AppCtx*>(aapp->userData);
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (aapp->window) {
                if (app->egl.context != EGL_NO_CONTEXT) {
                    // RESUME: Kontext lebt noch -- nur neue Surface anbinden.
                    // Alle GPU-Ressourcen (ImGui-Fonts, Effekte, Thumbnails)
                    // sind erhalten; nichts muss neu erzeugt werden.
                    if (egl_recreate_surface(app->egl, aapp->window)) {
                        // Das Android-Input-Backend haelt den ANativeWindow*
                        // -- auf das NEUE Fenster umziehen (kein GL beteiligt).
                        ImGui_ImplAndroid_Shutdown();
                        ImGui_ImplAndroid_Init(aapp->window);
                        // GPU-OBJEKTE PRUEFEN: Der Kontext SOLL zwar
                        // ueberleben, Android darf ihn aber jederzeit
                        // wegwerfen. Dann zeigen die alten Nummern ins
                        // Leere und der Treiber zeichnet mit der zuletzt
                        // gebundenen Textur weiter -- daher die riesigen
                        // verzerrten Buchstaben und die schwarzen
                        // Effektfenster nach dem Zurueckwechseln.
                        ImGui_ImplOpenGL3_DestroyDeviceObjects();
                        ImGui_ImplOpenGL3_CreateDeviceObjects();
                        EffectsGl_ValidateGpu();
                        app->canRender = true;
                    }
                } else if (egl_init(app->egl, aapp->window)) {
                    // ERSTSTART: kompletter Aufbau
                    if (!app->imguiReady) imgui_init(*app, aapp);
                    app->canRender = true;
                }
            }
            break;
        case APP_CMD_TERM_WINDOW:
            // Hintergrund: NUR Surface freigeben, Kontext behalten -- sonst
            // sterben alle GPU-Ressourcen und beim Zurueckkehren zeichnet
            // ImGui mit toten Objekt-IDs ins Leere ("Fenster verschwinden").
            app->canRender = false;
            egl_release_surface(app->egl);
            break;
        case APP_CMD_GAINED_FOCUS:
            app->canRender = (app->egl.display != EGL_NO_DISPLAY);
            break;
        case APP_CMD_LOST_FOCUS:
            app->canRender = false;
            break;
        default: break;
    }
}

int32_t handle_input(android_app* aapp, AInputEvent* event) {
    int32_t handled = ImGui_ImplAndroid_HandleInputEvent(event);
    // Multitouch-Erfassung: ALLE Finger mit Koordinaten (fuer den
    // Eingabe-Monitor und eigene Widgets). ImGui selbst ist Single-
    // Pointer -- das hier ist unsere parallele Erfassungsschicht.
    if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_MOTION) {
        auto& touches = UiTouches();
        touches.clear();
        int32_t action = AMotionEvent_getAction(event) & AMOTION_EVENT_ACTION_MASK;
        if (action != AMOTION_EVENT_ACTION_UP &&
            action != AMOTION_EVENT_ACTION_CANCEL) {
            size_t n = AMotionEvent_getPointerCount(event);
            for (size_t i = 0; i < n; ++i) {
                touches.push_back({
                    (int)AMotionEvent_getPointerId(event, i),
                    AMotionEvent_getX(event, i),
                    AMotionEvent_getY(event, i)});
            }
        }
    }
    // Textzeichen ergaenzen: nur bei Key-Down, nur druckbare Zeichen
    // (>= 32; Enter/Backspace laufen als Keys ueber das Backend), und
    // Combining-Accents (0x80000000-Flag) ueberspringen.
    if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_KEY &&
        AKeyEvent_getAction(event) == AKEY_EVENT_ACTION_DOWN) {
        // PHYSISCHE TASTATUR ERKANNT -- "Android-Tastatur verwenden"
        // automatisch abschalten. [Wer eine Bluetooth-/USB-Tastatur
        //  ansteckt, braucht die Bildschirmtastatur nicht mehr -- sie
        //  wuerde nur den halben Bildschirm wegnehmen.]
        //
        // DREI BEDINGUNGEN, sonst schaltet es zu frueh ab:
        //  (1) Die Quelle muss eine TASTATUR sein. Ohne diese Pruefung
        //      zaehlten auch Ereignisse von Steuerkreuz, Fernbedienung
        //      oder Kopfhoerertasten als "Tastatur".
        //  (2) Die Geraetekennung muss > 0 sein. Android vergibt fuer
        //      die VIRTUELLE Tastatur die Kennung 0 bzw. -1
        //      (KeyCharacterMap.VIRTUAL_KEYBOARD) -- ohne diese Pruefung
        //      schaltete sich die Bildschirmtastatur beim ersten eigenen
        //      Tastendruck SELBST ab.
        //  (3) Systemtasten zaehlen nicht: Zurueck, Lautstaerke, Home,
        //      Ein/Aus und Menue kommen auch ohne jede Tastatur -- die
        //      Lautstaerkewippe haette die Einstellung sonst jedes Mal
        //      umgelegt.
        const int32_t quelle   = AInputEvent_getSource(event);
        const int32_t geraet   = AInputEvent_getDeviceId(event);
        const int32_t code     = AKeyEvent_getKeyCode(event);
        const bool istTastatur = (quelle & AINPUT_SOURCE_KEYBOARD) != 0;
        const bool istSystemtaste =
               code == AKEYCODE_BACK        || code == AKEYCODE_HOME
            || code == AKEYCODE_MENU        || code == AKEYCODE_POWER
            || code == AKEYCODE_VOLUME_UP   || code == AKEYCODE_VOLUME_DOWN
            || code == AKEYCODE_VOLUME_MUTE || code == AKEYCODE_APP_SWITCH;
        if (istTastatur && geraet > 0 && !istSystemtaste
            && UiAndroidTastaturVerwenden()) {
            UiAndroidTastaturVerwenden() = false;
            // SOFORT einfahren, nicht erst beim naechsten Fokuswechsel.
            // [Sonst bliebe die Bildschirmtastatur stehen, obwohl die
            //  Einstellung schon aus ist -- genau der Platz, den man
            //  zurueckgewinnen wollte, bliebe belegt.]
            UiRequestHideKeyboard() = true;
        }
        int uni = JniGetUnicodeChar(AKEY_EVENT_ACTION_DOWN,
                                    AKeyEvent_getKeyCode(event),
                                    AKeyEvent_getMetaState(event));
        // NUR wenn die Java-Pumpe NICHT laeuft. Sonst kaeme jedes
        // Zeichen zweimal an (physische Tastatur: EditText + NativeActivity).
        if (!g_imeJavaPump && (uni & 0x80000000) == 0 && uni >= 32) {
            ImGui::GetIO().AddInputCharacter((unsigned int)uni);
        }
    }
    return handled;
}

} // namespace

void android_main(android_app* aapp) {
    g_app = aapp;
    // Dem Alarm-Modul die Activity bekanntgeben (siehe xbm_alarm.h).
    // [Erst  XbmAlarm_SetApp(app)  geschrieben -- der Parameter heisst
    //  hier aber aapp, und "app" ist ein paar Zeilen weiter eine GANZ
    //  ANDERE Variable (AppCtx app). Haette es sie zu diesem Zeitpunkt
    //  schon gegeben, waere es ohne Fehlermeldung das Falsche gewesen.
    //  Steht jetzt NACH g_app = aapp, damit die Reihenfolge stimmt.]
    XbmAlarm_SetApp(aapp);
    AppCtx app;
    aapp->userData     = &app;
    aapp->onAppCmd     = handle_cmd;
    aapp->onInputEvent = handle_input;

    while (true) {
        int events = 0;
        android_poll_source* source = nullptr;
        // Bei canRender: nicht blockieren (Timeout 0), sonst auf Events warten.
        // ALooper_pollOnce statt ALooper_pollAll: pollAll ist ab NDK r29 als
        // 'unavailable' markiert (konnte Looper-Wakes verschlucken). pollOnce
        // hat dieselbe Signatur, kehrt nur nach jedem Dispatch zurueck --
        // unsere while-Schleife pollt weiter, das Verhalten bleibt gleich.
        while (ALooper_pollOnce(app.canRender ? 0 : -1, nullptr, &events,
                                reinterpret_cast<void**>(&source)) >= 0) {
            if (source) source->process(aapp, source);
            if (aapp->destroyRequested) {
                UiCalendar_Shutdown();   // ungespeicherte Termine sichern
                XbmNet_Shutdown();
                XbmStt_Shutdown();
                XbmAudio_Shutdown();
                XbmSched_Shutdown();
                imgui_shutdown(app);
                egl_shutdown(app.egl);
                return;
            }
        }
        if (app.canRender && app.imguiReady) frame(app);
    }
}

#endif // __ANDROID__
