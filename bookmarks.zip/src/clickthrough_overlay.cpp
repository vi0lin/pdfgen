#include "clickthrough_overlay.h"
#include "imgui_internal.h"
#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>
// NOTE: as of the Win32-transparency debugging in this project's history,
// main.cpp's Windows branch no longer calls into this file's Windows
// (_WIN32) code path at all -- it uses win32_window.cpp's manual Win32+WGL
// window creation and Win32Window::UpdateClickThroughRegionHwnd instead,
// because GLFW_TRANSPARENT_FRAMEBUFFER is confirmed broken on Windows
// (glfw/glfw#2731, #1237) and no amount of DWM API calls applied to a
// GLFW-created window fixed it. The _WIN32 branch below is kept compiling
// (harmless dead code on Windows) for reference, but is dead on that
// platform. Linux (__linux__) and macOS (__APPLE__) branches are still
// fully active and unchanged.
#if defined(_WIN32)
    #define GLFW_EXPOSE_NATIVE_WIN32
    #include <GLFW/glfw3native.h>
    #include <windows.h>
    #include <dwmapi.h>
#elif defined(__linux__)
    #define GLFW_EXPOSE_NATIVE_X11
    #include <GLFW/glfw3native.h>
    #include <X11/Xlib.h>
    #include <X11/extensions/shape.h>
#elif defined(__APPLE__)
    #define GLFW_EXPOSE_NATIVE_COCOA
    #include <GLFW/glfw3native.h>
    // Objective-C++ bridge declared below, implemented in clickthrough_overlay_mac.mm
    extern "C" void macos_InitClickThroughWindow(void* nsWindowHandle);
    extern "C" void macos_UpdateClickThroughRegion(void* nsWindowHandle,
                                                     const float* rectsXYWH,
                                                     int rectCount);
#endif
namespace ClickThroughOverlay {
void SetupWindowHintsForTransparency() {
    glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, GLFW_TRUE);
    glfwWindowHint(GLFW_DECORATED, GLFW_FALSE); // borderless; remove if you want OS decorations
    glfwWindowHint(GLFW_FLOATING, GLFW_FALSE);  // set TRUE if you want always-on-top
}
void InitPlatformWindow(GLFWwindow* window) {
#if defined(_WIN32)
    HWND hwnd = glfwGetWin32Window(window);

    // IMPORTANT, READ BEFORE TOUCHING THIS BLOCK AGAIN:
    //
    // GLFW_TRANSPARENT_FRAMEBUFFER alone does NOT work reliably on Windows
    // as of GLFW 3.4 -- this is a confirmed, currently-unfixed upstream bug
    // (glfw/glfw#2731, glfw/glfw#1237 and others): the window's DWM
    // redirection surface is never properly cleared to zero alpha, so DWM
    // composites the window as opaque regardless of what alpha values
    // glClearColor/glClear write into the GL backbuffer. This matches
    // exactly what we observed: glfwGetWindowAttrib reports the hint as
    // active (1), a glClearColor test with alpha=0.5 visibly reached the
    // screen (proving the render/clear/viewport path is correct), and yet
    // the result was still fully opaque.
    //
    // The documented working fix (see e.g. github.com/jeweg/win32-window-
    // transparency) is to handle this manually at the Win32 level instead
    // of relying on GLFW's broken internal path:
    //   1) Set the window CLASS background brush to BLACK_BRUSH. On
    //      WM_ERASEBKGND, Windows fills the DWM redirection surface with
    //      this brush -- BLACK_BRUSH specifically writes RGBA(0,0,0,0),
    //      i.e. zero alpha, which is what actually makes the surface
    //      transparent. (NULL, which we used previously to fix the
    //      unrelated focus-flash cosmetic issue, does NOT write zero alpha
    //      the same way and does not fix this.)
    //   2) Call DwmEnableBlurBehindWindow with bEnable=TRUE and an empty
    //      blur region. This tells DWM to actually use the redirection
    //      surface's alpha channel for per-pixel compositing -- without
    //      this call, DWM treats the window as opaque no matter what the
    //      surface's alpha values are.
    SetClassLongPtr(hwnd, GCLP_HBRBACKGROUND, (LONG_PTR)GetStockObject(BLACK_BRUSH));

    BOOL compositionEnabled = FALSE;
    HRESULT hrComp = DwmIsCompositionEnabled(&compositionEnabled);
    fprintf(stderr, "DwmIsCompositionEnabled: hr=0x%08lx enabled=%d\n", hrComp, compositionEnabled);

    DWM_BLURBEHIND bb = {};
    bb.dwFlags = DWM_BB_ENABLE;
    bb.fEnable = TRUE;
    bb.hRgnBlur = NULL; // NULL region = blur/transparency applies to the whole client area
    HRESULT hrBlur = DwmEnableBlurBehindWindow(hwnd, &bb);
    fprintf(stderr, "DwmEnableBlurBehindWindow: hr=0x%08lx (S_OK=0x%08lx)\n", hrBlur, S_OK);
#elif defined(__linux__)
    // Nothing extra needed at init time beyond what GLFW hints already did.
    // X11 Shape extension calls happen per-frame in UpdateClickThroughRegion.
    (void)window;
#elif defined(__APPLE__)
    void* nsWindow = (void*)glfwGetCocoaWindow(window);
    macos_InitClickThroughWindow(nsWindow);
#endif
}
void UpdateClickThroughRegion(GLFWwindow* window, const std::vector<ImRect>& rects) {
#if defined(_WIN32)
    HWND hwnd = glfwGetWin32Window(window);
    if (rects.empty()) {
        // Fully click-through: zero-size region means "no input anywhere"
        HRGN empty = CreateRectRgn(0, 0, 0, 0);
        SetWindowRgn(hwnd, empty, TRUE); // hwnd takes ownership, do not delete
        return;
    }
    HRGN combined = CreateRectRgn(0, 0, 0, 0);
    for (const ImRect& r : rects) {
        HRGN part = CreateRectRgn(
            (int)r.Min.x, (int)r.Min.y,
            (int)r.Max.x, (int)r.Max.y);
        CombineRgn(combined, combined, part, RGN_OR);
        DeleteObject(part);
    }
    SetWindowRgn(hwnd, combined, TRUE); // hwnd takes ownership of 'combined'
#elif defined(__linux__)
    Display* dpy = glfwGetX11Display();
    Window win = glfwGetX11Window(window);
    if (rects.empty()) {
        XShapeCombineRectangles(dpy, win, ShapeInput, 0, 0,
                                 nullptr, 0, ShapeSet, 0);
        XFlush(dpy);
        return;
    }
    std::vector<XRectangle> xr;
    xr.reserve(rects.size());
    for (const ImRect& r : rects) {
        XRectangle rect;
        rect.x = (short)r.Min.x;
        rect.y = (short)r.Min.y;
        rect.width  = (unsigned short)(r.Max.x - r.Min.x);
        rect.height = (unsigned short)(r.Max.y - r.Min.y);
        xr.push_back(rect);
    }
    XShapeCombineRectangles(dpy, win, ShapeInput, 0, 0,
                             xr.data(), (int)xr.size(), ShapeSet, 0);
    XFlush(dpy);
#elif defined(__APPLE__)
    void* nsWindow = (void*)glfwGetCocoaWindow(window);
    std::vector<float> flat;
    flat.reserve(rects.size() * 4);
    for (const ImRect& r : rects) {
        flat.push_back(r.Min.x);
        flat.push_back(r.Min.y);
        flat.push_back(r.Max.x - r.Min.x);
        flat.push_back(r.Max.y - r.Min.y);
    }
    macos_UpdateClickThroughRegion(nsWindow, flat.data(), (int)rects.size());
#endif
}
} // namespace ClickThroughOverlay
