#include "xbm_alarm.h"

#if defined(__ANDROID__)
#include <android/log.h>
// [Erst <game-activity/native_app_glue/...> geschrieben -- das ist der
//  Pfad der GameActivity. Dieses Projekt benutzt das klassische
//  native_app_glue, wie main_android.cpp Zeile 14 zeigt:
//      #include <android_native_app_glue.h>
//  Falscher Pfad = "fatal error: file not found".]
#include <android_native_app_glue.h>
#include <jni.h>

// DIE ACTIVITY WIRD ANGEMELDET, NICHT AUSGELESEN.
// [Erst  extern android_app* g_app;  geschrieben -- aber in
//  main_android.cpp Zeile 72 steht
//      static android_app* g_app = nullptr;
//  und "static" heisst: ausserhalb dieser Datei nicht erreichbar. Das
//  waere ein Fehler beim Binden gewesen ("undefined reference").
//
//  Statt deine Datei umzubauen, meldet sie ihre Activity hier an --
//  eine Zeile in android_main:
//      XbmAlarm_SetApp(app);
//  Fehlt sie, tut das Modul nichts und stuerzt nicht ab.]
static android_app* g_alarmApp = nullptr;
void XbmAlarm_SetApp(void* app) { g_alarmApp = (android_app*)app; }
#define g_app g_alarmApp

namespace {

// [Ein Helfer statt fuenf Mal derselbe Block. Anhaengen und Abloesen des
//  Fadens gehoert dazu: der Aufruf kommt aus dem UI-Faden, der bei der
//  JVM nicht dauerhaft angemeldet ist.]
struct JniHalter {
    JNIEnv* env = nullptr;
    bool    selbstAngehaengt = false;
    JavaVM* vm = nullptr;
    JniHalter() {
        if (!g_app || !g_app->activity) return;
        vm = g_app->activity->vm;
        if (!vm) return;
        if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
            if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK) { env = nullptr; return; }
            selbstAngehaengt = true;
        }
    }
    ~JniHalter() { if (selbstAngehaengt && vm) vm->DetachCurrentThread(); }
    bool ok() const { return env != nullptr; }
    // [Bei GameActivity heisst das Feld javaGameActivity, beim
    //  klassischen native_app_glue "clazz" -- das ist die Activity.]
    jobject ctx() const { return g_app && g_app->activity ? g_app->activity->clazz
                                                          : nullptr; }
};

jclass AlarmKlasse(JNIEnv* env) {
    return env->FindClass("com/mrtn/xbookmarkmanager/XbmAlarm");
}

} // namespace

bool XbmAlarm_Verfuegbar() { return true; }

bool XbmAlarm_ExakteErlaubt() {
    JniHalter j;
    if (!j.ok() || !j.ctx()) return false;
    // AlarmManager.canScheduleExactAlarms() gibt es erst ab API 31 --
    // darunter ist es immer erlaubt.
    jclass build = j.env->FindClass("android/os/Build$VERSION");
    if (!build) { j.env->ExceptionClear(); return true; }
    jfieldID fid = j.env->GetStaticFieldID(build, "SDK_INT", "I");
    jint sdk = fid ? j.env->GetStaticIntField(build, fid) : 0;
    if (sdk < 31) return true;

    jclass ctxCls = j.env->GetObjectClass(j.ctx());
    jmethodID gss = j.env->GetMethodID(ctxCls, "getSystemService",
                                       "(Ljava/lang/String;)Ljava/lang/Object;");
    if (!gss) { j.env->ExceptionClear(); return false; }
    jstring nm = j.env->NewStringUTF("alarm");
    jobject am = j.env->CallObjectMethod(j.ctx(), gss, nm);
    j.env->DeleteLocalRef(nm);
    if (!am) { j.env->ExceptionClear(); return false; }
    jclass amCls = j.env->GetObjectClass(am);
    jmethodID can = j.env->GetMethodID(amCls, "canScheduleExactAlarms", "()Z");
    bool erlaubt = can ? (j.env->CallBooleanMethod(am, can) == JNI_TRUE) : false;
    if (j.env->ExceptionCheck()) { j.env->ExceptionClear(); erlaubt = false; }
    return erlaubt;
}

void XbmAlarm_RechteOeffnen() {
    JniHalter j;
    if (!j.ok() || !j.ctx()) return;
    jclass intentCls = j.env->FindClass("android/content/Intent");
    if (!intentCls) { j.env->ExceptionClear(); return; }
    jmethodID ctor = j.env->GetMethodID(intentCls, "<init>", "(Ljava/lang/String;)V");
    jstring act = j.env->NewStringUTF("android.settings.REQUEST_SCHEDULE_EXACT_ALARM");
    jobject in = j.env->NewObject(intentCls, ctor, act);
    j.env->DeleteLocalRef(act);
    if (!in) { j.env->ExceptionClear(); return; }
    jclass ctxCls = j.env->GetObjectClass(j.ctx());
    jmethodID start = j.env->GetMethodID(ctxCls, "startActivity",
                                         "(Landroid/content/Intent;)V");
    if (start) j.env->CallVoidMethod(j.ctx(), start, in);
    if (j.env->ExceptionCheck()) j.env->ExceptionClear();
}

void XbmAlarm_Planen(std::uint64_t id, std::int64_t zeitUnix,
                     const std::string& titel, const std::string& audioPfad) {
    JniHalter j;
    if (!j.ok() || !j.ctx()) return;
    jclass cls = AlarmKlasse(j.env);
    if (!cls) { j.env->ExceptionClear(); return; }
    jmethodID m = j.env->GetStaticMethodID(cls, "plan",
        "(Landroid/content/Context;JJLjava/lang/String;Ljava/lang/String;)V");
    if (!m) { j.env->ExceptionClear(); return; }
    jstring jt = j.env->NewStringUTF(titel.c_str());
    jstring ja = j.env->NewStringUTF(audioPfad.c_str());
    j.env->CallStaticVoidMethod(cls, m, j.ctx(), (jlong)id,
                                (jlong)zeitUnix * 1000LL, jt, ja);
    j.env->DeleteLocalRef(jt); j.env->DeleteLocalRef(ja);
    if (j.env->ExceptionCheck()) j.env->ExceptionClear();
}

void XbmAlarm_Loeschen(std::uint64_t id) {
    JniHalter j;
    if (!j.ok() || !j.ctx()) return;
    jclass cls = AlarmKlasse(j.env);
    if (!cls) { j.env->ExceptionClear(); return; }
    jmethodID m = j.env->GetStaticMethodID(cls, "loeschen",
        "(Landroid/content/Context;J)V");
    if (m) j.env->CallStaticVoidMethod(cls, m, j.ctx(), (jlong)id);
    if (j.env->ExceptionCheck()) j.env->ExceptionClear();
}

void XbmAlarm_TonStoppen() {
    JniHalter j;
    if (!j.ok()) return;
    jclass cls = AlarmKlasse(j.env);
    if (!cls) { j.env->ExceptionClear(); return; }
    jmethodID m = j.env->GetStaticMethodID(cls, "tonStoppen", "()V");
    if (m) j.env->CallStaticVoidMethod(cls, m);
    if (j.env->ExceptionCheck()) j.env->ExceptionClear();
}

#else   // ------------------------------------------------------------------

// [Auf Linux und Windows gibt es keinen Weg, die App bei geschlossenem
//  Programm zu wecken -- das leistet nur ein Dienst des Systems
//  (systemd-Timer, Aufgabenplanung). Hier wird deshalb NICHTS
//  vorgetaeuscht: Verfuegbar() meldet false, und die Oberflaeche kann
//  sagen "Erinnerungen nur, solange die App laeuft".]
void XbmAlarm_SetApp(void*)    {}   // auf dem Schreibtisch ohne Wirkung
bool XbmAlarm_Verfuegbar()     { return false; }
bool XbmAlarm_ExakteErlaubt()  { return false; }
void XbmAlarm_RechteOeffnen()  {}
void XbmAlarm_Planen(std::uint64_t, std::int64_t, const std::string&,
                     const std::string&) {}
void XbmAlarm_Loeschen(std::uint64_t) {}
void XbmAlarm_TonStoppen()     {}

#endif
