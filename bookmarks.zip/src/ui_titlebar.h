#pragma once
// ---------------------------------------------------------------------------
// ui_titlebar.h -- EIGENE Kopfzeile statt der des Fenstersystems.
//
// WARUM NICHT DIE NATIVE:
// Die App ist auf BEIDEN Desktop-Plattformen absichtlich randlos (Linux:
// GLFW_DECORATED=false + transparenter Framebuffer, Windows: WS_POPUP +
// DWM-Durchsichtigkeit). Eine native Leiste nachtraeglich einzublenden
// heisst, mit jeder Fensterverwaltung einzeln zu ringen:
//   * X11: der Dekorations-Wechsel laeuft ueber _MOTIF_WM_HINTS, und ob
//     eine Fensterverwaltung das an einem bereits gemappten Fenster
//     ueberhaupt auswertet, ist ihr ueberlassen. Marco/MATE tut es oft
//     nicht -- deshalb "erscheint die Kopfzeile ueberhaupt nicht".
//   * Windows: WS_OVERLAPPEDWINDOW zusammen mit WS_EX_LAYERED und
//     DWM-Blur-Behind macht die nichtklientische Flaeche unzuverlaessig
//     treffbar.
// Eine selbst gezeichnete Leiste umgeht beides, sieht ueberall gleich aus
// und laesst sich hier auch testen.
//
// Die drei Knoepfe rechts: Minimieren, Vollbild/Fenster, Schliessen.
// Ziehen an der Leiste verschiebt das Fenster, Doppelklick schaltet
// Vollbild um -- so, wie man es von einer Titelleiste erwartet.
// ---------------------------------------------------------------------------
#include "imgui.h"
#include <string>

struct UiTitleBarHooks {
    // Alle optional; ist ein Haken nicht gesetzt, entfaellt der Knopf.
    void (*minimize)()                 = nullptr;
    void (*close)()                    = nullptr;
    // Fenster verschieben: dx/dy in Bildschirmpunkten, relativ.
    void (*moveBy)(int dx, int dy)     = nullptr;
    // Aktuellen Vollbildzustand lesen/setzen.
    bool (*isFullscreen)()             = nullptr;
    void (*setFullscreen)(bool on)     = nullptr;
};

void UiTitleBar_SetHooks(const UiTitleBarHooks& h);
const UiTitleBarHooks& UiTitleBar_Hooks();

// An-/Abschalten (auf Android sinnlos -- dort gibt es die Systemleiste).
void UiTitleBar_SetEnabled(bool on);
bool UiTitleBar_Enabled();

// Hoehe, die die Leiste belegt (0 wenn aus). Fuer die Layoutrechnung:
// der Seiten-Host muss um diesen Betrag nach unten ruecken.
float UiTitleBar_Height();

// Einmal pro Frame ganz am ANFANG zeichnen (vor allen anderen Fenstern),
// damit sie oben liegt und der Rest darunter Platz bekommt.
// Liefert true, wenn gerade an der Leiste gezogen wird.
bool UiTitleBar_Draw(const char* appName);

// Gestenordnung der App (wie bei Kalender und Scrubber).
extern void (*UiTitleBar_ClaimGesture)();
