#pragma once
// ---------------------------------------------------------------------------
// ui_scrub.h -- Positionsregler mit VARIABLER PRAEZISION.
//
// DIE GESTE (so wie du sie beschrieben hast):
// Finger auf dem Regler, waagrecht ziehen -> die volle Breite entspricht der
// ganzen Laufzeit. Bleibt der Finger unten und wandert nach OBEN weg, wird
// die Uebersetzung feiner: dieselbe Fingerbewegung bewegt die Position nur
// noch ein Zehntel, ein Hundertstel, ein Tausendstel weit. Zurueck zum
// Regler -> wieder ganze Laufzeit. Die Position springt dabei NIE.
//
// WARUM SIE NICHT SPRINGT -- der Kern der Sache:
// Ein gewoehnlicher Regler rechnet ABSOLUT: Position = f(Finger-x). Sobald
// man die Uebersetzung umschaltet, ergibt dieselbe Finger-x eine andere
// Position und das Bild springt. Deshalb rechnet dieser Regler
// INKREMENTELL: er summiert nur (Delta-x * Faktor) auf. Ein Umschalten des
// Faktors aendert dann nur, wie weit die NAECHSTE Bewegung traegt -- der
// aktuelle Stand bleibt stehen. Genau das macht die Geste brauchbar.
//
// Das Ganze braucht KEINE Videowiedergabe: es ist ein reiner Zahlenregler.
// Wenn das Mediengeruest steht, haengt man es an derselben Stelle an.
// ---------------------------------------------------------------------------
#include "imgui.h"
#include <string>
#include <vector>

struct XbmScrubStep {
    float  distancePx;   // ab dieser Entfernung vom Regler ...
    double rate;         // ... gilt dieser Faktor (1.0 = ganze Laufzeit)
    const char* label;   // Anzeige, z.B. "1:10"
};

struct XbmScrubOptions {
    float  height        = 34.0f;   // Hoehe des Reglers
    double fps           = 25.0;    // fuer die Einzelbildschritte
    bool   showTime      = true;    // 00:01:23.400 im Regler
    bool   showRate      = true;    // Faktor einblenden, sobald < 1
    bool   snapToFrame   = true;    // Ergebnis auf Bildraster runden
    // Verfeinerungsstufen, von grob nach fein. Die Voreinstellung ist an
    // das Verhalten gaengiger Videoprogramme angelehnt.
    std::vector<XbmScrubStep> steps = {
        {   0.0f, 1.0,     "ganze Laufzeit" },
        {  45.0f, 0.25,    "1:4"  },
        { 100.0f, 0.05,    "1:20" },
        { 170.0f, 0.01,    "1:100"},
        { 250.0f, 0.002,   "1:500"},
    };
};

struct XbmScrubInfo {
    bool   scrubbing = false;   // Finger/Maus liegt gerade am Regler
    bool   began     = false;   // in diesem Frame begonnen
    bool   ended     = false;   // in diesem Frame losgelassen
    double rate      = 1.0;     // aktuelle Uebersetzung
    const char* rateLabel = "";
    float  offsetPx  = 0.0f;    // senkrechter Abstand vom Regler
};

// Der Regler. value in Sekunden (oder was du willst), zwischen min und max.
// Liefert true, wenn sich value in diesem Frame geaendert hat.
//
// WICHTIG fuer die App: waehrend gescrubbt wird, meldet der Regler die
// Geste ueber UiScrub_ClaimGesture an -- sonst reisst der globale
// Drag-Scroll sie an sich (dasselbe Muster wie beim Kalender).
bool UiScrubber(const char* id, double* value, double min, double max,
                const XbmScrubOptions& opt = XbmScrubOptions(),
                XbmScrubInfo* info = nullptr);

// Einzelbild vor/zurueck -- als Knopfleiste mit ⏮ ◀ ▶ ⏭ und Sprungweiten.
// Liefert true, wenn value veraendert wurde.
bool UiScrubTransport(const char* id, double* value, double min, double max,
                      double fps, bool* playing = nullptr);

// Sekunden -> "01:23.400" bzw. "1:01:23.400"
std::string UiScrub_FormatTime(double seconds, bool withMillis = true);

// Einhaengepunkt in die Gestenordnung der App (wie beim Kalender).
extern void (*UiScrub_ClaimGesture)();
