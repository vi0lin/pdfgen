#pragma once
// app_settings.h -- Persistenz eigener App-Zustaende (Key=Value-Datei):
// Effekt-Einstellungen, Kompakt-Flag pro Seite, aktiver Tab. Fenster-
// positionen und Dock-Layouts persistiert ImGui selbst via imgui.ini --
// auf Android muss dafuer io.IniFilename auf den App-Datenpfad zeigen!
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <cstdlib>
#include "effects_gl.h"
#include "ui_pages.h"
#include "ui_navi.h"
#include "ui_helpers.h"     // UiScrollPinpoint (seit Runde 9 dort)
#include "xbm_ui_flags.h"   // UiSheetCloseOnTab -- DIESE ZEILE FEHLTE BEI DIR
#if defined(__ANDROID__)
#include <android/log.h>
#define XBM_LOG(...) __android_log_print(ANDROID_LOG_INFO, "xbm", __VA_ARGS__)
#else
#define XBM_LOG(...) do { printf("[xbm] " __VA_ARGS__); printf("\n"); } while(0)
#endif

namespace AppSettings {
inline std::string g_path;
inline void Save();   // Vorwaertsdeklaration (Load setzt den Persist-Hook)

inline void Load(const std::string& path) {
    g_path = path;
    FILE* f = fopen(path.c_str(), "r");
    if (!f) return;
    char line[512];
    EffectsSettings& fx = EffectsGl_Settings();
    while (fgets(line, sizeof(line), f)) {
        // Positions-/Dock-Records: "F\tSeite\tFenster\tx y w h" bzw.
        // "D\tSeite\tFenster\tid" (Tab-getrennt -- Fensternamen duerfen
        // '=' und Leerzeichen enthalten, z.B. "Spin (ziehen = drehen)").
        if (line[0] == 'P' && line[1] == '\t') {
            char* wn = strtok(line + 2, "\t");
            char* fv = strtok(nullptr, "\t\n");
            char* hv = strtok(nullptr, "\n");
            (void)hv;   // Alt-Format mit Hoehenfeld: tolerant ignorieren
            if (wn && fv)
                // NORMALISIERT laden: aeltere xbm.ini enthalten teils
                // "Titel##Seite"-Schluessel -- ohne UiPropsKey wuerden
                // daraus tote Doppel-Eintraege, und der echte Basisnamen-
                // Eintrag bliebe beim Start unbefuellt.
                {   // Format: P <name> <fix> [<sizeMode> <minH>]
                    ui_pages_detail::UiWinProps& wpL =
                        ui_pages_detail::UiPropsFor(wn);
                    wpL.fixHeight = atoi(fv) != 0;
                    wpL.sizeMode  = wpL.fixHeight ? 1 : 0;
                    char* sm = strtok(nullptr, "\t");
                    if (sm) wpL.sizeMode = atoi(sm);
                    char* mh = strtok(nullptr, "\t");
                    if (mh) wpL.minH = (float)atof(mh);
                    char* fs = strtok(nullptr, "\t");
                    if (fs) wpL.fullscreen = atoi(fs) != 0;
                }
            continue;
        }
        if (line[0] == 'S' && line[1] == '\t') {
            UiDockStickAll() = atoi(line + 2) != 0;
            continue;
        }
        if (line[0] == 'V' && line[1] == '\t') {     // Navi-Zustand
            char* side   = strtok(line + 2, "\t");
            char* open   = strtok(nullptr, "\t");
            char* folded = strtok(nullptr, "\t");
            char* saved  = strtok(nullptr, "\t");
            if (side) {
                UiNavi::EdgeState& es = (side[0] == 'R')
                    ? UiNavi::Right() : UiNavi::Left();
                if (!es.panels.empty())
                    UiNavi::DeserializeEdge(es, open, folded, saved);
            }
            continue;
        }
        if (line[0] == 'W' && line[1] == '\t') {
            UiAppFullscreen() = atoi(line + 2) != 0;   // Vollbild/Fenster
            continue;
        }
        if (line[0] == 'K' && line[1] == '\t') {
            UiKeyboardEnabled() = atoi(line + 2) != 0;   // Tastatur an/aus
            continue;
        }
        if (line[0] == 'T' && line[1] == '\t') {
            // TEXTFELD: T <schluessel> <maskierter text>
            char* k = strtok(line + 2, "\t");
            char* v = strtok(nullptr, "\n");
            if (k) {
                std::string out;
                for (const char* q = v ? v : ""; *q; ++q) {
                    if (*q == '\\' && q[1]) {
                        ++q;
                        if      (*q == 'n') out.push_back('\n');
                        else if (*q == 't') out.push_back('\t');
                        else                out.push_back(*q);
                    } else out.push_back(*q);
                }
                size_t cap = out.size() + 1024;
                if (cap < 4096) cap = 4096;
                UiTextSet(k, out.c_str(), cap);
            }
            continue;
        }
        if (line[0] == 'L' && line[1] == '\t') {
            char* pgN = strtok(line + 2, "\t");
            char* dat = strtok(nullptr, "\n");
            if (pgN && dat) {
                std::vector<ui_pages_detail::LayoutNode> recs;
                char* saveN = nullptr;
                for (char* nd = strtok_r(dat, "\x1e", &saveN); nd;
                     nd = strtok_r(nullptr, "\x1e", &saveN)) {
                    ui_pages_detail::LayoutNode r;
                    char* saveF = nullptr;
                    char* f1 = strtok_r(nd, "\x1f", &saveF);
                    char* f2 = strtok_r(nullptr, "\x1f", &saveF);
                    char* f3 = strtok_r(nullptr, "\x1f", &saveF);
                    char* f4 = strtok_r(nullptr, "\x1f", &saveF);
                    if (!f1 || !f2 || !f3) continue;
                    r.parent = atoi(f1); r.axis = atoi(f2);
                    r.ratio = (float)atof(f3);
                    if (f4) {
                        char* saveW = nullptr;
                        for (char* w = strtok_r(f4, "\x1d", &saveW); w;
                             w = strtok_r(nullptr, "\x1d", &saveW))
                            r.windows.push_back(w);
                    }
                    recs.push_back(std::move(r));
                }
                if (!recs.empty())
                    ui_pages_detail::g_layout[pgN] = std::move(recs);
            }
            continue;
        }
        if (line[0] == 'F' || line[0] == 'D') {
            char typ = line[0];
            char* pgN = strtok(line + 2, "\t");
            char* win = strtok(nullptr, "\t");
            char* dat = strtok(nullptr, "\t\n");
            if (pgN && win && dat) {
                if (typ == 'F') {
                    ui_pages_detail::Snap sn{};
                    if (sscanf(dat, "%f %f %f %f", &sn.pos.x, &sn.pos.y,
                               &sn.size.x, &sn.size.y) == 4)
                        ui_pages_detail::g_free[pgN][win] = sn;
                } else {
                    unsigned int id = 0;
                    if (sscanf(dat, "%u", &id) == 1)
                        ui_pages_detail::g_dock[pgN][win] = (ImGuiID)id;
                }
            }
            continue;
        }
        char key[64]; float v = 0;
        if (sscanf(line, "%63[^=]=%f", key, &v) != 2) continue;
        if      (!strcmp(key, "bgVisible"))      fx.bgVisible      = v != 0;
        else if (!strcmp(key, "bgOpacity"))      fx.bgOpacity      = v;
        else if (!strcmp(key, "ovVisible"))      fx.ovVisible      = v != 0;
        else if (!strcmp(key, "ovOpacity"))      fx.ovOpacity      = v;
        else if (!strcmp(key, "bgWindowed"))     fx.bgWindowed     = v != 0;
        else if (!strcmp(key, "clickThrough"))   fx.clickThrough   = v != 0;
        else if (!strcmp(key, "respectTaskbar")) fx.respectTaskbar = v != 0;
        else if (!strcmp(key, "sheetAlignDock")) UiNavi::AppSheetAlignDock() = v != 0;
        else if (!strcmp(key, "canvasMode"))     fx.canvasMode     = (int)v;
        else if (!strcmp(key, "dockingEnabled")) fx.dockingEnabled = v != 0;
        else if (!strcmp(key, "showTriangle"))   fx.showTriangle   = v != 0;
        else if (!strcmp(key, "lockLayout"))     fx.lockLayout     = v != 0;
        else if (!strcmp(key, "scrollPinpoint")) UiScrollPinpoint() = v != 0;
        else if (!strcmp(key, "androidTastatur")) UiAndroidTastaturVerwenden() = v != 0;
        else if (!strcmp(key, "sheetCloseOnTab")) UiSheetCloseOnTab() = v != 0;
        else if (!strcmp(key, "oneTapDockspace")) UiOneTapDockspace() = v != 0;
        else if (!strcmp(key, "holdSeconds"))     UiHoldSeconds() = (float)v / 1000.0f;
        else if (!strcmp(key, "resizeNeighbors"))
            fx.resizeAffectsNeighbors = v != 0;
        else if (!strcmp(key, "multiViewports")) fx.multiViewports = v != 0;
        else if (!strcmp(key, "activePage"))
            ui_pages_detail::g_active = (int)v;
        else if (!strncmp(key, "stickL_", 7)) {
            for (auto& pg : UiPages())
                if (pg.name == key + 7) pg.stickL = v != 0;
        }
        else if (!strncmp(key, "stickR_", 7)) {
            for (auto& pg : UiPages())
                if (pg.name == key + 7) pg.stickR = v != 0;
        }
        else if (!strncmp(key, "compact_", 8)) {
            // KOMPAKT IST NICHT MEHR ABSCHALTBAR (Nutzerwunsch).
            // Der Wert wird weiterhin gelesen, damit alte xbm.ini-Dateien
            // keine Warnung ausloesen -- aber ein gespeichertes 0 wird
            // VERWORFEN. Ohne das startete eine Seite, die frueher einmal
            // auf "frei" stand, weiterhin ohne Kompakt-Layout, und der
            // Nutzer haette keine Moeglichkeit mehr, das zu aendern.
            (void)v;
            for (auto& pg : UiPages())
                if (pg.name == key + 8) { pg.compact = true;
                                          pg.needRebuild = true; }
        }
    }
    fclose(f);
    ui_pages_detail::g_lastActive = ui_pages_detail::g_active;
    // Kompakt-Seiten mit gespeichertem Layout-Baum: exakten Wiederaufbau
    // anfordern (schlaegt den einfachen Grundstapel).
    for (auto& pg : UiPages())
        if (pg.compact && !ui_pages_detail::g_layout[pg.name].empty())
            { pg.needLayout = true; pg.needRebuild = false; }
    int nf = 0, nd = 0;
    for (auto& [k, m] : ui_pages_detail::g_free) nf += (int)m.size();
    for (auto& [k, m] : ui_pages_detail::g_dock) nd += (int)m.size();
    XBM_LOG("Load %s: %d Frei-Records, %d Dock-Records, %d Layout-Baeume, "
            "Seite=%d", path.c_str(), nf, nd,
            (int)ui_pages_detail::g_layout.size(),
            ui_pages_detail::g_active);
    UiPagesBootApply();   // gespeicherten Zustand AKTIV anwenden (autoritativ)
    ui_pages_detail::UiPagesPersistHook = &Save;  // Sofort-Persistenz
    UiTextPersistHookPtr() = &Save;               // Textfelder ebenso
}

inline void Save() {
    if (g_path.empty()) return;
    FILE* f = fopen(g_path.c_str(), "w");
    if (!f) return;
    EffectsSettings& fx = EffectsGl_Settings();
    fprintf(f, "bgVisible=%d\nbgOpacity=%f\novVisible=%d\novOpacity=%f\n"
               "bgWindowed=%d\nclickThrough=%d\ncanvasMode=%d\n"
               "dockingEnabled=%d\nmultiViewports=%d\nrespectTaskbar=%d\n"
               "sheetAlignDock=%d\n"
               "activePage=%d\n",
        fx.bgVisible ? 1 : 0, fx.bgOpacity, fx.ovVisible ? 1 : 0,
        fx.ovOpacity, fx.bgWindowed ? 1 : 0, fx.clickThrough ? 1 : 0,
        fx.canvasMode, fx.dockingEnabled ? 1 : 0, fx.multiViewports ? 1 : 0,
        fx.respectTaskbar ? 1 : 0,
        UiNavi::AppSheetAlignDock() ? 1 : 0,
        ui_pages_detail::g_active);
    fprintf(f, "resizeNeighbors=%d\n",
            fx.resizeAffectsNeighbors ? 1 : 0);
    fprintf(f, "showTriangle=%d\n", fx.showTriangle ? 1 : 0);
    fprintf(f, "lockLayout=%d\n", fx.lockLayout ? 1 : 0);
    fprintf(f, "scrollPinpoint=%d\n", UiScrollPinpoint() ? 1 : 0);
    fprintf(f, "androidTastatur=%d\n", UiAndroidTastaturVerwenden() ? 1 : 0);
    fprintf(f, "sheetCloseOnTab=%d\n", UiSheetCloseOnTab() ? 1 : 0);
    fprintf(f, "oneTapDockspace=%d\n", UiOneTapDockspace() ? 1 : 0);
    fprintf(f, "holdSeconds=%d\n", (int)(UiHoldSeconds() * 1000.0f));
    for (auto& pg : UiPages()) {
        // Immer 1: die Einstellung ist nicht mehr abschaltbar.
        fprintf(f, "compact_%s=1\n", pg.name.c_str());
        fprintf(f, "stickL_%s=%d\n", pg.name.c_str(), pg.stickL ? 1 : 0);
        fprintf(f, "stickR_%s=%d\n", pg.name.c_str(), pg.stickR ? 1 : 0);
    }
    for (auto& [pgN, m] : ui_pages_detail::g_free)
        for (auto& [win, sn] : m)
            fprintf(f, "F\t%s\t%s\t%f %f %f %f\n", pgN.c_str(),
                    win.c_str(), sn.pos.x, sn.pos.y, sn.size.x, sn.size.y);
    for (auto& [pgN, m] : ui_pages_detail::g_dock)
        for (auto& [win, id] : m)
            fprintf(f, "D\t%s\t%s\t%u\n", pgN.c_str(), win.c_str(),
                    (unsigned int)id);
    // Standard ist jetzt STATISCH -> beide Zustaende explizit sichern,
    // damit ein bewusst abgehaktes Fenster nach Neustart abgehakt bleibt.
    for (auto& [wn, wp] : ui_pages_detail::g_winProps)
        fprintf(f, "P\t%s\t%d\t%d\t%.0f\t%d\n", wn.c_str(),
                wp.fixHeight ? 1 : 0, wp.sizeMode, wp.minH,
                wp.fullscreen ? 1 : 0);
    fprintf(f, "K\t%d\n", UiKeyboardEnabled() ? 1 : 0);
    fprintf(f, "W\t%d\n", UiAppFullscreen() ? 1 : 0);
    fprintf(f, "S\t%d\n", UiDockStickAll() ? 1 : 0);
    fprintf(f, "V\tL\t%s\n",
            UiNavi::SerializeEdge(UiNavi::Left()).c_str());
    fprintf(f, "V\tR\t%s\n",
            UiNavi::SerializeEdge(UiNavi::Right()).c_str());
    // TEXTFELDER (UiInputText/UiInputTextMultiline): Zeilenumbrueche und
    // Tabs werden maskiert, damit eine ini-Zeile eine ini-Zeile bleibt.
    for (auto& [k, b] : UiTextAll()) {
        if (b.data.empty() || b.data[0] == '\0') continue;
        fprintf(f, "T\t%s\t", k.c_str());
        for (const char* q = b.data.data(); *q; ++q) {
            if      (*q == '\\') fputs("\\\\", f);
            else if (*q == '\n') fputs("\\n", f);
            else if (*q == '\r') { }
            else if (*q == '\t') fputs("\\t", f);
            else fputc(*q, f);
        }
        fputc('\n', f);
    }
    for (auto& [pgN, recs] : ui_pages_detail::g_layout) {
        if (recs.empty()) continue;
        fprintf(f, "L\t%s\t", pgN.c_str());
        for (size_t i = 0; i < recs.size(); ++i) {
            const auto& r = recs[i];
            fprintf(f, "%d\x1f%d\x1f%f\x1f", r.parent, r.axis, r.ratio);
            for (size_t w = 0; w < r.windows.size(); ++w)
                fprintf(f, "%s%s", w ? "\x1d" : "", r.windows[w].c_str());
            if (i + 1 < recs.size()) fputc('\x1e', f);
        }
        fputc('\n', f);
    }
    fclose(f);
    // Diagnose: Layout-Baeume kompakt ins Log (Blatt -> Fensterliste),
    // damit Fehlrekonstruktionen SICHTBAR werden statt geraten.
    // Standard ist jetzt STATISCH -> beide Zustaende explizit sichern,
    // damit ein bewusst abgehaktes Fenster nach Neustart abgehakt bleibt.
    for (auto& [wn, wp] : ui_pages_detail::g_winProps)
        fprintf(f, "P\t%s\t%d\t%d\t%.0f\t%d\n", wn.c_str(),
                wp.fixHeight ? 1 : 0, wp.sizeMode, wp.minH,
                wp.fullscreen ? 1 : 0);
    for (auto& [pgN, recs] : ui_pages_detail::g_layout) {
        std::string line;
        for (auto& r : recs) {
            if (r.axis != -1) continue;
            line += "[";
            for (size_t i = 0; i < r.windows.size(); ++i)
                line += (i ? "+" : "") + r.windows[i];
            line += "]";
        }
        if (!line.empty())
            XBM_LOG("Baum %s: %s", pgN.c_str(), line.c_str());
    }
    static int nSaves = 0;
    if ((++nSaves % 10) == 1) {           // jede 10. Sicherung loggen
        int nf = 0, nd = 0;
        for (auto& [k, m] : ui_pages_detail::g_free) nf += (int)m.size();
        for (auto& [k, m] : ui_pages_detail::g_dock) nd += (int)m.size();
        XBM_LOG("Save #%d: %d Frei-Records, %d Dock-Records", nSaves, nf, nd);
    }
}

// Jeden Frame aufrufen: speichert gedrosselt (alle 3 s), dadurch ueberlebt
// der Zustand auch hartes Beenden (Android kennt kein sauberes Exit).
inline void Periodic() {
    static double last = 0;
    double now = ImGui::GetTime();
    if (now - last > 3.0) { last = now; Save(); }
}
} // namespace AppSettings
