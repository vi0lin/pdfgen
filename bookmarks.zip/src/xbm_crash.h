#pragma once
// ---------------------------------------------------------------------------
// xbm_crash.h -- ABSTURZBERICHTE UND LOG, AUTOMATISCH AN EINEN MONITOR.
//
// WOZU
// "double free or corruption -- Aborted" sagt nur, DASS es geknallt hat,
// nicht WO. Dieses Modul faengt SIGSEGV/SIGABRT/SIGBUS/SIGFPE (POSIX) bzw.
// unbehandelte Ausnahmen (Windows) ab und schreibt, noch im sterbenden
// Prozess, einen Bericht mit der AUFRUFKETTE und den letzten Logzeilen
// in <UserData>/logs/. Beim naechsten Start werden ungesendete Berichte
// an den Monitor geschickt (POST, siehe monitor_server.py) und dort
// abgelegt -- so sieht man von einem Rechner aus, was auf allen Geraeten
// passiert.
//
// WAS IM SIGNALHANDLER ERLAUBT IST
// Fast nichts: kein malloc, kein printf, kein C++-Stream. Deshalb nur
// write(2), backtrace_symbols_fd (schreibt direkt in den Descriptor) und
// vorab reservierte Puffer. Der Pfad des Berichts wird BEIM START
// festgelegt, nicht im Handler.
//
// AUFRUFKETTE LESBAR MACHEN
// Ohne Debugsymbole stehen im Bericht nur Adressen/Offsets. Mit
//     addr2line -e x_bookmark_manager -f -C -i <offset>
// werden daraus Funktion und Zeile. Am einfachsten: Release mit -g bauen
// (-O2 -g kostet keine Laufzeit) und -rdynamic linken, dann stehen die
// Funktionsnamen direkt im Bericht.
// ---------------------------------------------------------------------------
#include <string>
#include <vector>

// Einmal beim Start, nach XbmPaths_SetUserDir/InitAndroid.
// <monitorUrl>: z.B. "http://192.168.1.69:3010/bericht" -- leer = nur lokal
// speichern. <geraeteName>: erscheint im Monitor als Absender.
void XbmCrash_Init(const std::string& geraeteName, const std::string& monitorUrl);

// Logzeile in den Ringpuffer (letzte ~200 Zeilen landen im Bericht) und
// in <UserData>/logs/app.log. Thread-sicher.
void XbmCrash_Log(const std::string& zeile);

// Fehlerbericht OHNE Absturz -- fuer abgefangene Fehler, die man trotzdem
// im Monitor sehen will (z.B. "Update fehlgeschlagen", "Sync-Konflikt").
void XbmCrash_Melden(const std::string& titel, const std::string& details);

// Ungesendete Berichte jetzt hochladen (laeuft sonst automatisch beim
// Start im Hintergrund). Liefert die Zahl der uebertragenen.
int  XbmCrash_Senden();

// Fuer die Einstellungsseite.
std::string XbmCrash_MonitorUrl();
void        XbmCrash_SetMonitorUrl(const std::string& url);
std::vector<std::string> XbmCrash_Berichte();       // Dateinamen, neueste zuerst
std::string XbmCrash_LogOrdner();
