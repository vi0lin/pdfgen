#pragma once
// ---------------------------------------------------------------------------
// xbm_projekt_push.h -- BEARBEITETE BENUTZERDATEN ZURUECK INS PROJEKT.
//
// WOZU
// Die App arbeitet in XbmPaths_UserData() (bestaendig, ausserhalb des
// Bauordners). Was man dort aendert -- pdfgen-Vorlagen, Netzwerk-Scripts --
// soll auf Knopfdruck zur STANDARDVORLAGE fuer alle kuenftigen Bauten auf
// allen Geraeten werden. Der Weg dorthin ist das Quell-Git:
//     UserData/<ordner>  ->  <Projekt>/data/shared/<ordner>  ->  git push
// Beim naechsten Bau kopiert CMake data/shared in die Vorlagen, und der
// naechste Start ergaenzt sie auf frischen Geraeten in die Benutzerdaten.
//
// NUR AUF KNOPFDRUCK -- nie automatisch. [Die Benutzerdaten sind der
//  Arbeitsplatz; das Projekt ist der Ort fuer bewusst freigegebene
//  Staende. Waere jede Aenderung sofort ein Commit, waere die Historie
//  wertlos und ein Tippfehler laege binnen Sekunden auf allen Geraeten.]
//
// ANDROID: kein Git vorhanden. Der Weg dort: Netzabgleich zu einem
// Desktop-Client (der Abgleich sieht jetzt XbmPaths_UserData) und den
// Push von dort ausloesen. XbmProjektPush_Moeglich() sagt der Oberflaeche,
// ob der Knopf hier Sinn hat.
// ---------------------------------------------------------------------------
#include <cstdlib>
#include <functional>
#include <string>
#include <vector>

#include "xbm_paths.h"
#include "xbm_sched.h"

struct XbmProjektPushErgebnis {
    bool ok = false;
    int  kopiert = 0;
    std::string meldung;     // fuer den Alert
};

inline bool XbmProjektPush_Moeglich() {
#if defined(__ANDROID__)
    return false;
#else
    return !XbmPaths_ProjektRoot().empty();
#endif
}

namespace xbm_projekt_push_detail {

// UserData/<rel> nach Projekt/data/shared/<rel>, rekursiv, ueberschreibt.
inline int KopiereBaum(const std::string& von, const std::string& nach) {
    int n = 0;
    for (const std::string& d : XbmPaths_ListDirs(von))
        n += KopiereBaum(von + "/" + d, nach + "/" + d);
    for (const std::string& f : XbmPaths_ListFiles(von))
        if (XbmPaths_KopiereDatei(von + "/" + f, nach + "/" + f)) ++n;
    return n;
}

inline std::string Anfuehrungszeichen(const std::string& s) {
    std::string r = "\"";
    for (char c : s) { if (c == '"' || c == '\\') r += '\\'; r += c; }
    return r + "\"";
}

}  // namespace xbm_projekt_push_detail

// Synchron -- im Hintergrund-Pool aufrufen, NICHT im UI-Thread (git push
// kann Sekunden dauern). <ordner>: welche Unterordner der Benutzerdaten,
// z.B. {"pdfgen", "scripts"}.
inline XbmProjektPushErgebnis XbmProjektPush_Ausfuehren(
        const std::vector<std::string>& ordner,
        const std::string& nachricht) {
    using namespace xbm_projekt_push_detail;
    XbmProjektPushErgebnis e;
#if defined(__ANDROID__)
    (void)ordner; (void)nachricht;
    e.meldung = "Auf Android gibt es kein Git -- bitte per Netzabgleich zum Desktop "
                "und dort 'Push' druecken.";
    return e;
#else
    const std::string root = XbmPaths_ProjektRoot();
    if (root.empty()) {
        e.meldung = "Kein Projektordner gefunden (die App laeuft nicht aus einem "
                    "Bauordner mit .git und data/shared).";
        return e;
    }
    for (const std::string& o : ordner) {
        const std::string von  = XbmPaths_UserData() + "/" + o;
        const std::string nach = root + "/data/shared/" + o;
        if (!XbmPaths_IsDir(von)) continue;
        e.kopiert += KopiereBaum(von, nach);
    }
    if (e.kopiert == 0) {
        e.meldung = "Nichts zu uebertragen.";
        return e;
    }
    // git add/commit/push -- alles im Projektordner. Ein "nichts zu
    // committen" (Rueckgabe 1 von git commit) ist KEIN Fehler.
    const std::string q = Anfuehrungszeichen(root);
    auto git = [&](const std::string& args) {
        return std::system(("git -C " + q + " " + args + " >/dev/null 2>&1").c_str());
    };
    if (git("add -A data/shared") != 0) {
        e.meldung = "git add fehlgeschlagen im Projektordner " + root;
        return e;
    }
    const int rcCommit = git("commit -q -m " + Anfuehrungszeichen(nachricht));
    if (rcCommit != 0) {
        // Nichts geaendert gegenueber dem letzten Commit -- die Dateien
        // waren schon so im Projekt. Kein Push noetig, kein Fehler.
        e.ok = true;
        e.meldung = std::to_string(e.kopiert) + " Datei(en) ins Projekt kopiert -- "
                    "keine Aenderung gegenueber Git, nichts zu pushen.";
        return e;
    }
    // "push origin HEAD" statt blossem "push": Letzteres braucht einen
    // eingerichteten Tracking-Zweig -- fehlt er (frisch geklont, oder nur
    // "git push origin main" ohne -u), scheitert es still. HEAD zum
    // gleichnamigen Zweig auf origin funktioniert immer.
    if (git("push -q origin HEAD") != 0) {
        e.meldung = "Commit angelegt, aber git push fehlgeschlagen (Server erreichbar?). "
                    "Von Hand: git -C " + root + " push origin HEAD";
        return e;
    }
    e.ok = true;
    e.meldung = std::to_string(e.kopiert) + " Datei(en) ins Projekt uebernommen, "
                "committet und gepusht.";
    return e;
#endif
}

// Bequem: im Hintergrund ausfuehren, Ergebnis im UI-Thread abliefern.
inline void XbmProjektPush_Async(const std::vector<std::string>& ordner,
                                 const std::string& nachricht,
                                 std::function<void(const XbmProjektPushErgebnis&)> fertig) {
    XbmSched_After(std::chrono::milliseconds(0), [ordner, nachricht, fertig]() {
        XbmProjektPushErgebnis e = XbmProjektPush_Ausfuehren(ordner, nachricht);
        XbmSched_PostUi([e, fertig]() { if (fertig) fertig(e); });
    }, XbmRun::Pool);
}
