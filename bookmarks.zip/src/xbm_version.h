#pragma once
// ---------------------------------------------------------------------------
// xbm_version.h -- EINE fortlaufende Ganzzahl, bei jedem Release von Hand
// erhoeht. Grundlage des Update-Checks (xbm_update.h): eine hoehere Zahl
// in release.json bedeutet "neuere Version verfuegbar".
//
// [Bewusst KEINE Semver-Zerlegung (Major.Minor.Patch) -- die braucht eine
//  Vergleichsregel, die man erst einmal richtig hinschreiben muss (ist
//  1.10 neuer als 1.9? ja, aber als STRING verglichen waere es das
//  nicht). Eine einzelne Ganzzahl ist immer eindeutig ">".
//  Bewusst auch NICHT aus dem Baustempel (xbm_buildinfo) abgeleitet: der
//  aendert sich bei JEDEM Bau, ein Update soll aber nur bei einem
//  bewussten RELEASE angeboten werden.]
// ---------------------------------------------------------------------------
// Wert kommt aus CMake (Commit-Zeitstempel, siehe CMakeLists.txt). Ohne
// die erzeugte Datei -- z.B. beim Bau ausserhalb von CMake -- bleibt 1.
#if __has_include("xbm_version_gen.h")
  #include "xbm_version_gen.h"
  constexpr int XBM_APP_VERSION = XBM_APP_VERSION_GEN;
#else
  constexpr int XBM_APP_VERSION = 1;
#endif
