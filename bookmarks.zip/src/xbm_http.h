#pragma once
// ---------------------------------------------------------------------------
// xbm_http.h -- ein GET/POST mit Cookies und Kopfzeilen, fuer alle Quellen.
// [XClient hat seine HTTP-Aufrufe privat und auf X zugeschnitten. Statt
//  sie zu kopieren, gibt es hier EINE kleine Funktion, die Reddit und
//  Facebook benutzen. Aufgebaut wie XClient::http_get -- gleiche
//  Zeitgrenzen, gleicher Android-CA-Pfad, gleiche Fehlerbehandlung.]
// ---------------------------------------------------------------------------
#include <map>
#include <string>
#include <vector>

struct XbmHttpAntwort {
    long        status = 0;
    std::string body;
    std::string fehler;            // leer = kein Transportfehler
    std::string endgueltigeUrl;    // nach Weiterleitungen
};

// method: "GET" oder "POST". body nur bei POST.
XbmHttpAntwort XbmHttp(const std::string& method,
                       const std::string& url,
                       const std::map<std::string, std::string>& cookies,
                       const std::vector<std::string>& kopfzeilen,
                       const std::string& body = "",
                       bool weiterleitungenFolgen = true);

std::string XbmUrlEncode(const std::string& s);
