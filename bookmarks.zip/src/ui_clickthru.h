#pragma once
// ---------------------------------------------------------------------------
// ui_clickthru.h -- Entscheidet, ob der Zeiger ueber BEDIENBARER Flaeche
// steht oder ueber freier, durch die der Klick zum Desktop fallen soll.
//
// WARUM NICHT MEHR UEBER EINE RECHTECKLISTE
// Bisher sammelte die App die Rechtecke aller sichtbaren Fenster ein und
// pruefte den Zeiger dagegen. Diese Liste ist eine ZWEITE, von Hand
// gefuehrte Wahrheit neben der von ImGui -- und sie war wiederholt anders
// als das, was auf dem Schirm stand: gedockte Fenster tragen intern das
// Kindfenster-Kennzeichen und fielen heraus, der Vollbild-Seitenhost musste
// von Hand ausgenommen werden, Popups und Menues standen nie drin, und die
// Stapelreihenfolge blieb ganz unberuecksichtigt.
//
// ImGui beantwortet dieselbe Frage bereits selbst und richtig: g.HoveredWindow
// beruecksichtigt Stapelreihenfolge, Kindfenster, Popups, Menues, Docking und
// NoInputs. Genau das wird hier benutzt. Damit kann die Entscheidung nicht
// mehr von der Darstellung abweichen.
//
// DIE EINE AUSNAHME, die es braucht:
// Der Seiten-Host "##page_host_*" ist ein Vollbildfenster. Sein Hintergrund
// und die leeren Bereiche des DockSpace darin sind fuer den Nutzer FREIE
// FLAECHE, obwohl ImGui dort ein Fenster meldet. Gedockte Fenster IN diesem
// Host fangen dagegen normal.
//
// WICHTIG -- ZEIGERPOSITION EINSPEISEN:
// Sobald das Fenster durchlaessig ist, bekommt es keine Mausereignisse mehr;
// ImGuis Zeigerposition friert ein und HoveredWindow bliebe fuer immer leer.
// Deshalb MUSS die App die per Betriebssystem abgefragte Position jeden
// Frame mit UiClickThru_FeedCursor() nachreichen, bevor NewFrame laeuft.
// ---------------------------------------------------------------------------
#include "imgui.h"

// Vor ImGui::NewFrame() aufrufen, mit der echten Zeigerposition in
// FENSTERKOORDINATEN (Linux: XQueryPointer, Windows: GetCursorPos +
// ScreenToClient). valid=false, wenn sie sich nicht ermitteln liess.
void UiClickThru_FeedCursor(float x, float y, bool valid);

// Nach gui() aufrufen. true = Zeiger steht ueber bedienbarer Flaeche,
// das Fenster muss Klicks FANGEN.
bool UiClickThru_OverUi();

// Sichtprobe: faerbt bedienbare Flaechen ein, damit man sieht, was das
// Programm fuer belegt haelt. Nach gui() aufrufen.
void UiClickThru_DrawDebugOverlay();
void UiClickThru_SetDebug(bool on);
bool UiClickThru_Debug();

// Was zuletzt entschieden wurde -- fuer Anzeige und Protokoll.
const char* UiClickThru_LastReason();
