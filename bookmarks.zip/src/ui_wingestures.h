#pragma once
// ---------------------------------------------------------------------------
// ui_wingestures.h -- Fenster per Mehrfinger-Geste bedienen.
//
// [Ersetzt die selbstgezeichnete Knopfleiste (Move, drei Punkte, Zahnrad,
//  X). Gesten brauchen keinen Platz, treffen immer, und es gibt nur EINEN
//  Weg fuer alle Fenster.]
//
// ZWEI FINGER (alles bezieht sich auf das Fenster unter den Fingern):
//   1x tippen                 -> Aktionen-Overlay auf/zu
//   2x tippen                 -> Einstellungen-Overlay
//   3x tippen                 -> Hoehenmodus umschalten:
//                                "inhaltsbasiert" <-> "frei skalierbar"
//   ziehen                    -> Fenster ABDOCKEN und verschieben
//   2x tippen, dann ziehen    -> HOEHE aendern (in Zugrichtung)
//   Ein einmal begonnener Zug laeuft weiter, solange noch IRGENDEIN Finger
//   auf dem Bildschirm ist -- auch wenn einer der beiden losgelassen wird.
//
// DREI FINGER (bleibt erhalten):
//   tippen                    -> Einstellungen-Overlay
//   ziehen                    -> Fenster verschieben
//
// MAUS (Desktop-Ersatz): Rechtsklick = Aktionen, Shift+Rechtsklick =
//   Einstellungen, Strg+Klick = zwei Finger, Alt+Klick = drei Finger.
//
// ZIEL DER GESTE: das Fenster unter dem ERSTEN Finger. Trifft der Finger
// die Tab-Leiste eines Dock-Knotens, gehoert der Punkt dem Seiten-Host
// -- dann wird der Dock-Knoten gesucht und sein sichtbares Fenster
// genommen. [Vorher landete so ein Tipp beim Host selbst: "Aktionen fuer:
//  ##page_host_haupt".] Seiten-Hosts sind nie ein Ziel.
// ---------------------------------------------------------------------------
#include "imgui.h"
#include "imgui_internal.h"
#include "ui_helpers.h"
#include <cstring>
#include <string>
#include <vector>

enum class UiWinGesture {
    Keine,
    AktionenUmschalten,    // 2 Finger 1x
    Einstellungen,         // 2 Finger 2x, 3 Finger 1x, Shift+Rechtsklick
    ModusUmschalten,       // 2 Finger 3x
    HoeheAendern,          // 2 Finger 2x + ziehen: delta = Bewegung seit letztem Frame
};

struct UiWinGestureErgebnis {
    UiWinGesture art = UiWinGesture::Keine;
    std::string  fenster;         // Name des getroffenen Fensters
    float        delta = 0.0f;    // nur HoeheAendern: Pixel, + = nach unten
};

namespace ui_wingest {

struct Zustand {
    // laufende Beruehrung
    bool         aktiv      = false;    // im vorigen Frame war ein Finger da
    int          fingerMax  = 0;        // hoechste Fingerzahl dieser Beruehrung
    double       startT     = 0.0;
    ImVec2       startP     = ImVec2(0, 0);
    std::string  ziel;                  // Fenster unter dem ersten Finger
    ImGuiWindow* zielFenster = nullptr;
    bool         bewegt     = false;    // ueber die Tippschwelle hinaus
    bool         zieht      = false;    // Verschiebe-Zug laeuft
    bool         hoehe      = false;    // Hoehen-Zug laeuft
    ImVec2       letzte     = ImVec2(0, 0);
    // Tipp-Folge (nur zwei Finger)
    int          tipps      = 0;        // abgeschlossene Tipps in Folge
    double       letzterTippT = 0.0;
    std::string  tippZiel;              // Fenster der Tipp-Folge
};
inline Zustand& Z() { static Zustand z; return z; }

inline bool IstSeitenHost(const ImGuiWindow* w) {
    return w && std::strncmp(w->Name, "##page_host", 11) == 0;
}

// Sichtbares Fenster des Dock-Knotens unter <pt>, dessen Host <host> ist.
inline ImGuiWindow* FensterImDockKnoten(ImGuiWindow* host, ImVec2 pt) {
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g) return nullptr;
    for (int i = 0; i < g->DockContext.Nodes.Data.Size; ++i) {
        ImGuiDockNode* n = (ImGuiDockNode*)g->DockContext.Nodes.Data[i].val_p;
        if (!n || !n->IsLeafNode() || n->HostWindow != host) continue;
        if (!n->Rect().Contains(pt)) continue;      // Rect() schliesst die Tab-Leiste ein
        if (n->VisibleWindow) return n->VisibleWindow;
        if (n->Windows.Size > 0) return n->Windows[0];
    }
    return nullptr;
}

inline ImGuiWindow* FensterAn(ImVec2 pt) {
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g) return nullptr;
    for (int i = g->Windows.Size - 1; i >= 0; --i) {
        ImGuiWindow* w = g->Windows[i];
        if (!w->WasActive || w->Hidden) continue;
        if (w->Flags & (ImGuiWindowFlags_Tooltip | ImGuiWindowFlags_Popup
                        | ImGuiWindowFlags_ChildWindow)) continue;
        if (!w->Rect().Contains(pt)) continue;
        if (w->DockNodeAsHost && w->DockNodeAsHost->VisibleWindow)
            return w->DockNodeAsHost->VisibleWindow;
        if (IstSeitenHost(w)) {
            // Tab-Leiste eines Knotens getroffen -> dessen Fenster.
            if (ImGuiWindow* d = FensterImDockKnoten(w, pt)) return d;
            return nullptr;                         // leerer Host: kein Ziel
        }
        return w;
    }
    return nullptr;
}

// Verschieben ueber ImGuis eigene Maschinerie (zeigt Andockziele).
// undock = true: angedocktes Fenster erst loesen (Zwei-Finger-Zug).
inline void ZugStarten(ImGuiWindow* w, bool undock) {
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g || !w) return;
    ImGuiWindow* mv = w;
    if (mv->DockIsActive && mv->DockNode && mv->DockNode->HostWindow)
        mv = mv->DockNode->HostWindow;
    while (mv->ParentWindow) mv = mv->ParentWindow;
    if (g->MovingWindow == mv || g->MovingWindow == w) return;
    ImGui::ClearActiveID();
    if (w->DockNode && !w->DockNode->IsFloatingNode())
        ImGui::StartMouseMovingWindowOrNode(w, w->DockNode, undock);
    else
        ImGui::StartMouseMovingWindow(mv);
}

} // namespace ui_wingest

inline UiWinGestureErgebnis UiWinGesturesFrame() {
    using namespace ui_wingest;
    UiWinGestureErgebnis erg;
    ImGuiIO& io = ImGui::GetIO();
    Zustand& z = Z();
    const double jetzt = ImGui::GetTime();

    int finger = (int)UiTouches().size();
    if (finger == 0 && io.MouseDown[0])
        finger = io.KeyAlt ? 3 : (io.KeyCtrl ? 2 : 1);

    const float  kTippWeg    = 14.0f;   // darueber ist es kein Tipp mehr
    const double kTippZeit   = 0.45;    // laenger gehalten: kein Tipp
    const double kFolgePause = 0.32;    // Pause, nach der eine Tipp-Folge endet

    // ---- Maus-Ersatz --------------------------------------------------
    if (ImGui::IsMouseClicked(ImGuiMouseButton_Right)) {
        if (ImGuiWindow* w = FensterAn(io.MousePos)) {
            erg.art = io.KeyShift ? UiWinGesture::Einstellungen
                                  : UiWinGesture::AktionenUmschalten;
            erg.fenster = w->Name;
            z = Zustand();
            return erg;
        }
    }

    // ---- Kein Finger: Beruehrung beenden / Tipp-Folge auswerten ---------
    if (finger == 0) {
        if (z.aktiv) {
            if (z.zieht || z.hoehe) {           // Zug zu Ende, Folge verfaellt
                z = Zustand();
                return erg;
            }
            const bool tipp = !z.bewegt && (jetzt - z.startT) <= kTippZeit
                              && !z.ziel.empty();
            if (tipp && z.fingerMax >= 3) {
                erg.art = UiWinGesture::Einstellungen; erg.fenster = z.ziel;
                z = Zustand();
                return erg;
            }
            if (tipp && z.fingerMax == 2) {
                if (z.tippZiel != z.ziel) z.tipps = 0;   // anderes Fenster: neue Folge
                z.tippZiel = z.ziel;
                z.tipps++;
                z.letzterTippT = jetzt;
                if (z.tipps >= 3) {
                    erg.art = UiWinGesture::ModusUmschalten; erg.fenster = z.tippZiel;
                    z = Zustand();
                    return erg;
                }
            } else {
                z.tipps = 0; z.tippZiel.clear();
            }
            // Beruehrung abschliessen, Tipp-Folge behalten.
            const int tipps = z.tipps; const std::string tz = z.tippZiel;
            const double lt = z.letzterTippT;
            z = Zustand(); z.tipps = tipps; z.tippZiel = tz; z.letzterTippT = lt;
            return erg;
        }
        // Tipp-Folge nach Pause auswerten. [1x und 2x muessen warten, ob
        //  noch ein Tipp folgt -- sonst waere jeder Doppeltipp erst ein
        //  Aktionen-Overlay und dann Einstellungen.]
        if (z.tipps > 0 && jetzt - z.letzterTippT > kFolgePause) {
            erg.art = (z.tipps == 1) ? UiWinGesture::AktionenUmschalten
                                     : UiWinGesture::Einstellungen;
            erg.fenster = z.tippZiel;
            z = Zustand();
        }
        return erg;
    }

    // ---- Finger da: Beruehrung beginnen oder fortsetzen ----------------
    if (!z.aktiv) {
        z.aktiv  = true;
        z.startT = jetzt;
        z.startP = io.MousePos;
        z.letzte = io.MousePos;
        z.fingerMax = 0;
        z.bewegt = z.zieht = z.hoehe = false;
        ImGuiWindow* w = FensterAn(io.MousePos);
        z.ziel = w ? std::string(w->Name) : std::string();
        z.zielFenster = w;
        // Folge nur fortsetzen, wenn der neue Tipp rechtzeitig kommt.
        if (z.tipps > 0 && jetzt - z.letzterTippT > kFolgePause) {
            z.tipps = 0; z.tippZiel.clear();
        }
    }
    if (finger > z.fingerMax) z.fingerMax = finger;

    const float dx = io.MousePos.x - z.startP.x, dy = io.MousePos.y - z.startP.y;
    if (!z.bewegt && dx * dx + dy * dy > kTippWeg * kTippWeg) z.bewegt = true;

    // Zug beginnen -- welcher, haengt von der Vorgeschichte ab.
    if (z.bewegt && !z.zieht && !z.hoehe && z.fingerMax >= 2 && z.zielFenster
        && !IstSeitenHost(z.zielFenster)) {
        if (z.fingerMax == 2 && z.tipps == 1 && z.tippZiel == z.ziel) {
            z.hoehe = true;          // 2x getippt, dann gezogen: Hoehe
        } else {
            z.zieht = true;          // sonst: verschieben (2 Finger: abdocken)
            ZugStarten(z.zielFenster, /*undock=*/ z.fingerMax == 2);
        }
        z.tipps = 0; z.tippZiel.clear();
    }

    if (z.hoehe) {
        erg.art = UiWinGesture::HoeheAendern;
        erg.fenster = z.ziel;
        erg.delta = io.MousePos.y - z.letzte.y;
        UiDragHandledThisFrame() = true;    // kein Scrollen waehrend des Zugs
    } else if (z.zieht) {
        UiDragHandledThisFrame() = true;
    }
    z.letzte = io.MousePos;
    return erg;
}
