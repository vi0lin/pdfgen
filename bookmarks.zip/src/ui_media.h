#pragma once
// ---------------------------------------------------------------------------
// ui_media -- Seite "Media": Audiodateien aus <Nutzerordner>/media (und
// data/shared/media), Wellenform, Wiedergabe mit dem praezisen Scrubber
// (Finger nach oben = feiner), Schnittpunkte A/B, Schleife A-B, Export des
// Ausschnitts als WAV nach media/export. Video folgt mit demselben
// Transport, sobald ein Decoder (ffmpeg) eingebunden ist.
// ---------------------------------------------------------------------------
#include <string>
void UiMedia_Init(const std::string& userDir, const std::string& dataDir);
void UiMedia_Draw();
