#include "ui_media.h"
#include "imgui.h"
#include "xbm_audio.h"
#include "ui_scrub.h"
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <vector>

namespace {
namespace fs = std::filesystem;
struct Datei { std::string pfad, name; std::uintmax_t groesse = 0; };
struct Z {
    std::string userDir, dataDir, exportDir;
    std::vector<Datei> dateien; double letzteListe = 0;
    int gewaehlt = -1; XbmClip clip; std::string clipName;
    std::vector<float> welle;                // Spitzenwerte je Pixel-Bucket (neu bei Breitenwechsel)
    int welleBreite = 0;
    double pos = 0.0; bool spielt = false;
    double a = -1.0, b = -1.0; bool schleife = false;
    std::string meldung;
    bool init = false;
};
Z& z() { static Z s; return s; }

bool istAudio(const std::string& n) {
    static const char* ext[] = { ".wav", ".mp3", ".flac", ".ogg", ".aiff", ".aif" };
    std::string l = n; std::transform(l.begin(), l.end(), l.begin(), ::tolower);
    for (const char* e : ext) if (l.size() > std::strlen(e) && l.compare(l.size() - std::strlen(e), std::strlen(e), e) == 0) return true;
    return false;
}
void listen() {
    Z& s = z(); s.dateien.clear();
    for (const std::string& dir : { s.userDir + "/media", s.dataDir + "/media", s.exportDir }) {
        std::error_code ec; if (!fs::is_directory(dir, ec)) continue;
        for (const auto& e : fs::directory_iterator(dir, ec)) {
            if (!e.is_regular_file(ec)) continue;
            const std::string n = e.path().filename().string();
            if (!istAudio(n)) continue;
            bool da = false; for (auto& d : s.dateien) if (d.pfad == e.path().string()) da = true;
            if (!da) s.dateien.push_back({ e.path().string(), n, e.file_size(ec) });
        }
    }
    std::sort(s.dateien.begin(), s.dateien.end(), [](const Datei& x, const Datei& y) { return x.name < y.name; });
    s.letzteListe = ImGui::GetTime();
}
void laden(int idx) {
    Z& s = z(); if (idx < 0 || idx >= (int)s.dateien.size()) return;
    XbmClip c;
    if (!XbmAudio_ReadAny(s.dateien[idx].pfad, c)) { s.meldung = XbmAudio_LastError(); return; }
    XbmAudio_PlayStop();
    s.clip = std::move(c); s.clipName = s.dateien[idx].name; s.gewaehlt = idx;
    s.welle.clear(); s.welleBreite = 0; s.pos = 0; s.spielt = false; s.a = s.b = -1.0; s.meldung.clear();
}
void welleBauen(int breite) {
    Z& s = z(); if (breite <= 0 || s.clip.empty()) return;
    s.welle.assign((std::size_t)breite, 0.0f); s.welleBreite = breite;
    const std::size_t n = s.clip.pcm.size();
    for (int x = 0; x < breite; ++x) {
        const std::size_t i0 = n * (std::size_t)x / (std::size_t)breite, i1 = std::min(n, n * (std::size_t)(x + 1) / (std::size_t)breite + 1);
        float m = 0; for (std::size_t i = i0; i < i1; ++i) m = std::max(m, std::fabs(s.clip.pcm[i]));
        s.welle[(std::size_t)x] = m;
    }
}
std::string zeit(double sek) { char b[32]; const int m = (int)(sek / 60); std::snprintf(b, sizeof(b), "%d:%06.3f", m, sek - m * 60); return b; }

void exportieren() {
    Z& s = z(); if (s.clip.empty()) return;
    const double von = s.a >= 0 ? s.a : 0.0, bis = s.b > von ? s.b : s.clip.seconds();
    XbmClip aus; aus.sampleRate = s.clip.sampleRate;
    const std::size_t i0 = (std::size_t)(von * s.clip.sampleRate), i1 = std::min(s.clip.pcm.size(), (std::size_t)(bis * s.clip.sampleRate));
    if (i1 <= i0) { s.meldung = "Ausschnitt leer"; return; }
    aus.pcm.assign(s.clip.pcm.begin() + (std::ptrdiff_t)i0, s.clip.pcm.begin() + (std::ptrdiff_t)i1);
    std::error_code ec; fs::create_directories(s.exportDir, ec);
    std::string basis = s.clipName; const auto p = basis.find_last_of('.'); if (p != std::string::npos) basis = basis.substr(0, p);
    char name[256]; std::snprintf(name, sizeof(name), "%s/%s_%s-%s.wav", s.exportDir.c_str(), basis.c_str(), zeit(von).c_str(), zeit(bis).c_str());
    for (char* c = name + s.exportDir.size() + 1; *c; ++c) if (*c == ':') *c = '.';
    if (XbmAudio_WriteWav(name, aus)) { s.meldung = std::string("exportiert: ") + name; listen(); } else s.meldung = XbmAudio_LastError();
}
} // namespace

void UiMedia_Init(const std::string& userDir, const std::string& dataDir) {
    Z& s = z(); s.userDir = userDir; s.dataDir = dataDir; s.exportDir = userDir + "/media/export";
    std::error_code ec; fs::create_directories(userDir + "/media", ec);
    s.init = true; listen();
}

void UiMedia_Draw() {
    Z& s = z(); if (!s.init) { ImGui::TextDisabled("Media: nicht initialisiert"); return; }
    if (ImGui::GetTime() - s.letzteListe > 5.0) listen();
    // ---- links: Dateien ---------------------------------------------------
    ImGui::BeginChild("##media_links", ImVec2(ImGui::GetFontSize() * 14.0f, 0), true);
    ImGui::TextDisabled("Dateien (media/)");
    if (s.dateien.empty()) ImGui::TextWrapped("Keine Audiodateien. Ablegen in:\n%s/media", s.userDir.c_str());
    for (int i = 0; i < (int)s.dateien.size(); ++i) {
        ImGui::PushID(i);
        if (ImGui::Selectable(s.dateien[i].name.c_str(), i == s.gewaehlt)) laden(i);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s\n%.1f kB", s.dateien[i].pfad.c_str(), s.dateien[i].groesse / 1024.0);
        ImGui::PopID();
    }
    ImGui::EndChild();
    ImGui::SameLine();
    // ---- rechts: Wellenform, Transport, Schnitt --------------------------
    ImGui::BeginChild("##media_rechts", ImVec2(0, 0), false);
    if (s.clip.empty()) { ImGui::TextDisabled("Links eine Datei waehlen."); if (!s.meldung.empty()) ImGui::TextWrapped("%s", s.meldung.c_str()); ImGui::EndChild(); return; }
    ImGui::TextUnformatted(s.clipName.c_str()); ImGui::SameLine(); ImGui::TextDisabled("%s  %d Hz", zeit(s.clip.seconds()).c_str(), s.clip.sampleRate);
    // Wiedergabeposition verfolgen
    if (s.spielt) {
        s.pos = XbmAudio_PlayPos();
        if (s.schleife && s.b > s.a && s.a >= 0 && s.pos >= s.b) { XbmAudio_PlaySeek(s.a); s.pos = s.a; }
        if (!XbmAudio_IsPlaying() && s.pos >= s.clip.seconds() - 0.05) { s.spielt = false; }
    }
    // Wellenform mit Marken
    {
        const float breite = ImGui::GetContentRegionAvail().x, hoehe = ImGui::GetFontSize() * 5.0f;
        if ((int)breite != s.welleBreite) welleBauen((int)breite);
        ImDrawList* dl = ImGui::GetWindowDrawList(); const ImVec2 p0 = ImGui::GetCursorScreenPos();
        dl->AddRectFilled(p0, ImVec2(p0.x + breite, p0.y + hoehe), IM_COL32(24, 26, 32, 255), 4.0f);
        const float mitte = p0.y + hoehe * 0.5f;
        const double dauer = s.clip.seconds();
        auto xVon = [&](double t) { return p0.x + (float)(t / dauer) * breite; };
        if (s.a >= 0 && s.b > s.a) dl->AddRectFilled(ImVec2(xVon(s.a), p0.y), ImVec2(xVon(s.b), p0.y + hoehe), IM_COL32(90, 140, 220, 50));
        for (int x = 0; x < (int)s.welle.size(); ++x) { const float h = s.welle[(std::size_t)x] * hoehe * 0.48f; dl->AddLine(ImVec2(p0.x + x, mitte - h), ImVec2(p0.x + x, mitte + h), IM_COL32(120, 190, 240, 220), 1.0f); }
        if (s.a >= 0) dl->AddLine(ImVec2(xVon(s.a), p0.y), ImVec2(xVon(s.a), p0.y + hoehe), IM_COL32(120, 230, 140, 255), 2.0f);
        if (s.b >= 0) dl->AddLine(ImVec2(xVon(s.b), p0.y), ImVec2(xVon(s.b), p0.y + hoehe), IM_COL32(240, 150, 100, 255), 2.0f);
        dl->AddLine(ImVec2(xVon(s.pos), p0.y), ImVec2(xVon(s.pos), p0.y + hoehe), IM_COL32(255, 255, 255, 230), 2.0f);
        ImGui::InvisibleButton("##welle", ImVec2(breite, hoehe));
        if (ImGui::IsItemClicked()) { s.pos = (ImGui::GetIO().MousePos.x - p0.x) / breite * dauer; if (s.spielt) XbmAudio_PlaySeek(s.pos); }
    }
    // Scrubber (praezise Geste) und Transport
    {
        double v = s.pos; bool spielt = s.spielt;
        if (UiScrubTransport("##media_scrub", &v, 0.0, s.clip.seconds(), 0.0, &spielt)) {
            s.pos = v;
            if (s.spielt) XbmAudio_PlaySeek(s.pos);
        }
        if (spielt != s.spielt) {
            s.spielt = spielt;
            if (s.spielt) { XbmAudio_PlayClip(s.clip); XbmAudio_PlaySeek(s.pos); } else XbmAudio_PlayPause();
        }
    }
    // Schnittpunkte
    if (ImGui::Button("A setzen")) s.a = s.pos;
    ImGui::SameLine(); if (ImGui::Button("B setzen")) s.b = s.pos;
    ImGui::SameLine(); ImGui::Checkbox("Schleife A-B", &s.schleife);
    ImGui::SameLine(); if (ImGui::Button("zu A")) { s.pos = s.a >= 0 ? s.a : 0; if (s.spielt) XbmAudio_PlaySeek(s.pos); }
    ImGui::SameLine(); if (ImGui::Button("loeschen")) { s.a = s.b = -1; }
    ImGui::TextDisabled("A %s   B %s   Ausschnitt %s", s.a >= 0 ? zeit(s.a).c_str() : "-", s.b >= 0 ? zeit(s.b).c_str() : "-", (s.a >= 0 && s.b > s.a) ? zeit(s.b - s.a).c_str() : "-");
    if (ImGui::Button("Ausschnitt als WAV exportieren")) exportieren();
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("nach %s", s.exportDir.c_str());
    if (!s.meldung.empty()) ImGui::TextWrapped("%s", s.meldung.c_str());
    ImGui::Separator();
    ImGui::TextDisabled("Video: folgt mit ffmpeg (derselbe Transport und Scrubber).");
    ImGui::EndChild();
}
