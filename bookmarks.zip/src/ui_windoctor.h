#pragma once
// ---------------------------------------------------------------------------
// ui_windoctor.h -- WARUM ist das Fenster weg?
//
// Ein Fenster kann aus SEHR verschiedenen Gruenden unsichtbar sein, und von
// aussen sehen sie alle gleich aus:
//   1. Es wird gar nicht erst submittet (UiPageWindow lieferte nullptr,
//      weil die aktive Seite eine andere ist).
//   2. Es wird submittet, ImGui setzt aber Hidden (Collapsed, SkipItems,
//      erster Frame, Groesse 0).
//   3. Es liegt HINTER einem deckenden Vollbildfenster (Seiten-Host).
//   4. Es liegt ausserhalb des Canvas (Pos jenseits der Arbeitsflaeche).
//   5. Es hat einen eigenen OS-Viewport, der nie gerendert wird.
//   6. Sein Dock-Knoten ist verschwunden und es haengt an einem toten Tab.
//
// Dieses Werkzeug meldet den Zustand pro Frame -- aber NUR wenn er sich
// aendert. Damit steht nach einem einzigen Abdocken in der Konsole, welcher
// der sechs Faelle vorliegt, statt dass man weiter Hypothesen abklappert.
//
// Kosten: eine Namenssuche je beobachtetem Fenster und Frame. Vernachlaessig-
// bar, und der Beobachter ist standardmaessig AUS.
// ---------------------------------------------------------------------------
#include "imgui.h"
#include <string>
#include <vector>

// Fenster zur Beobachtung anmelden. base = der UNGESCOPTE Name, so wie er
// bei UiPageAdd steht (z.B. "Prototype"); der Doktor findet die gescopte
// Fassung selbst.
void UiWinDoctor_Watch(const char* base);
void UiWinDoctor_Unwatch(const char* base);
void UiWinDoctor_SetEnabled(bool on);
bool UiWinDoctor_Enabled();

// Einmal pro Frame NACH allen Begin/End aufrufen.
// submittedTitle: was UiPageWindow fuer dieses Fenster geliefert hat
// (nullptr = nicht submittet). Wird ueber UiWinDoctor_NoteSubmit gemeldet.
void UiWinDoctor_NoteSubmit(const char* base, const char* titleOrNull);
void UiWinDoctor_Frame();

// Letzte Meldungen (fuer eine Anzeige im Eingabe-Monitor).
const std::vector<std::string>& UiWinDoctor_Log();
void UiWinDoctor_ClearLog();
