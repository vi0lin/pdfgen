#pragma once
// ui_sftp.h -- SFTP ueber curl+libssh2: Verzeichnis auflisten, Dateien
// und ganze Verzeichnisse laden bzw. hochladen.
//
// VORAUSSETZUNG: curl MUSS mit libssh2 gebaut sein und HTTP_ONLY muss
// AUS sein -- sonst kennt curl das Protokoll nicht und meldet
// "Unsupported protocol". Die noetigen CMake-Aenderungen stehen in
// cmake/net_deps.cmake. UiSftpAvailable() prueft das zur Laufzeit.
//
// ALLES IM HINTERGRUND: Netzverkehr blockiert; der UI-Thread darf das
// nie tun (Android quittiert es mit ANR). Der Fortschritt wird ueber
// dieselbe atomare Struktur wie in ui_net.h gemeldet.
//
// BENUTZUNG:
//     UiSftpAuth a; a.host = "example.org"; a.user = "martin";
//     a.password = "...";            // ODER a.keyFile = "id_ed25519"
//     UiSftpGetDir(a, "/remote/ordner", "lokal/ordner");
#include "ui_net.h"
#include "ui_files.h"
#include <string>
#include <vector>
#include <thread>
#include <cstring>
#include <curl/curl.h>

struct UiSftpAuth {
    std::string host;                 // "example.org" oder "10.0.0.5"
    int         port = 22;
    std::string user;
    std::string password;             // leer, wenn Schluessel benutzt wird
    std::string keyFile;              // privater Schluessel (Pfad)
    std::string keyPass;              // dessen Passwort (optional)
    // Fingerabdruck des Servers, Format wie in known_hosts (base64).
    // LEER heisst: KEINE Pruefung -- dann ist die Verbindung zwar
    // verschluesselt, aber gegen einen Man-in-the-Middle ungeschuetzt.
    std::string hostPubKeySha256;
};

// Kennt dieses curl ueberhaupt SFTP?
inline bool UiSftpAvailable() {
    curl_version_info_data* v = curl_version_info(CURLVERSION_NOW);
    if (!v || !v->protocols) return false;
    for (const char* const* p = v->protocols; *p; ++p)
        if (strcmp(*p, "sftp") == 0) return true;
    return false;
}

namespace ui_sftp_detail {

inline std::string Url(const UiSftpAuth& a, const std::string& remotePath) {
    std::string u = "sftp://" + a.host;
    if (a.port != 22) u += ":" + std::to_string(a.port);
    if (remotePath.empty() || remotePath[0] != '/') u += "/";
    u += remotePath;
    return u;
}

inline void ApplyAuth(CURL* c, const UiSftpAuth& a) {
    if (!a.user.empty())     curl_easy_setopt(c, CURLOPT_USERNAME, a.user.c_str());
    if (!a.password.empty()) curl_easy_setopt(c, CURLOPT_PASSWORD, a.password.c_str());
    if (!a.keyFile.empty()) {
        std::string priv = UiFilePath(a.keyFile.c_str());
        std::string pub  = priv + ".pub";
        curl_easy_setopt(c, CURLOPT_SSH_PRIVATE_KEYFILE, priv.c_str());
        curl_easy_setopt(c, CURLOPT_SSH_PUBLIC_KEYFILE, pub.c_str());
        if (!a.keyPass.empty())
            curl_easy_setopt(c, CURLOPT_KEYPASSWD, a.keyPass.c_str());
        curl_easy_setopt(c, CURLOPT_SSH_AUTH_TYPES,
                         CURLSSH_AUTH_PUBLICKEY | CURLSSH_AUTH_PASSWORD);
    }
    if (!a.hostPubKeySha256.empty())
        curl_easy_setopt(c, CURLOPT_SSH_HOST_PUBLIC_KEY_SHA256,
                         a.hostPubKeySha256.c_str());
    curl_easy_setopt(c, CURLOPT_CONNECTTIMEOUT, 20L);
}

inline size_t StrCb(char* p, size_t sz, size_t nm, void* ud) {
    ((std::string*)ud)->append(p, sz * nm);
    return sz * nm;
}
inline size_t ReadCb(char* buf, size_t sz, size_t nm, void* ud) {
    return fread(buf, sz, nm, (FILE*)ud);
}

} // namespace ui_sftp_detail

// Verzeichnis auflisten. Rueckgabe: Eintragsnamen (ohne Pfad).
// 'err' bleibt leer, wenn es geklappt hat. BLOCKIERT -- im Thread rufen!
inline std::vector<std::string> UiSftpList(const UiSftpAuth& a,
                                           const std::string& remoteDir,
                                           std::string* err = nullptr) {
    using namespace ui_sftp_detail;
    std::vector<std::string> out;
    CURL* c = curl_easy_init();
    if (!c) { if (err) *err = "curl_easy_init fehlgeschlagen"; return out; }
    std::string data;
    char errbuf[CURL_ERROR_SIZE] = {0};
    std::string url = Url(a, remoteDir);
    if (url.back() != '/') url += "/";        // Slash = Verzeichnis!
    curl_easy_setopt(c, CURLOPT_URL, url.c_str());
    curl_easy_setopt(c, CURLOPT_DIRLISTONLY, 1L);   // nur Namen
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, &StrCb);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, (void*)&data);
    curl_easy_setopt(c, CURLOPT_ERRORBUFFER, errbuf);
    ApplyAuth(c, a);
    CURLcode rc = curl_easy_perform(c);
    curl_easy_cleanup(c);
    if (rc != CURLE_OK) {
        if (err) *err = errbuf[0] ? errbuf : curl_easy_strerror(rc);
        return out;
    }
    std::string cur;
    for (char ch : data) {
        if (ch == '\n' || ch == '\r') {
            if (!cur.empty() && cur != "." && cur != "..") out.push_back(cur);
            cur.clear();
        } else cur.push_back(ch);
    }
    if (!cur.empty() && cur != "." && cur != "..") out.push_back(cur);
    return out;
}

// Eine Datei holen. BLOCKIERT.
inline std::string UiSftpGetFile(const UiSftpAuth& a,
                                 const std::string& remotePath,
                                 const std::string& destName) {
    using namespace ui_sftp_detail;
    std::string path = UiFilePath(destName.c_str());
    std::string tmp  = path + ".part";
    FILE* f = fopen(tmp.c_str(), "wb");
    if (!f) return "Kann nicht schreiben: " + tmp;
    CURL* c = curl_easy_init();
    if (!c) { fclose(f); remove(tmp.c_str()); return "curl_easy_init fehlgeschlagen"; }
    char errbuf[CURL_ERROR_SIZE] = {0};
    curl_easy_setopt(c, CURLOPT_URL, Url(a, remotePath).c_str());
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, &ui_net_detail::WriteCb);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, (void*)f);
    curl_easy_setopt(c, CURLOPT_NOPROGRESS, 0L);
    curl_easy_setopt(c, CURLOPT_XFERINFOFUNCTION, &ui_net_detail::ProgressCb);
    curl_easy_setopt(c, CURLOPT_ERRORBUFFER, errbuf);
    ApplyAuth(c, a);
    CURLcode rc = curl_easy_perform(c);
    curl_easy_cleanup(c);
    fclose(f);
    if (rc != CURLE_OK) {
        remove(tmp.c_str());
        std::string m = errbuf[0] ? errbuf : curl_easy_strerror(rc);
        return (rc == CURLE_ABORTED_BY_CALLBACK) ? "abgebrochen" : m;
    }
    remove(path.c_str());
    if (rename(tmp.c_str(), path.c_str()) != 0) {
        remove(tmp.c_str());
        return "Umbenennen fehlgeschlagen: " + destName;
    }
    return std::string();
}

// Eine Datei hochladen. BLOCKIERT.
inline std::string UiSftpPutFile(const UiSftpAuth& a,
                                 const std::string& localName,
                                 const std::string& remotePath) {
    using namespace ui_sftp_detail;
    std::string path = UiFilePath(localName.c_str());
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) return "Nicht lesbar: " + path;
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    CURL* c = curl_easy_init();
    if (!c) { fclose(f); return "curl_easy_init fehlgeschlagen"; }
    char errbuf[CURL_ERROR_SIZE] = {0};
    curl_easy_setopt(c, CURLOPT_URL, Url(a, remotePath).c_str());
    curl_easy_setopt(c, CURLOPT_UPLOAD, 1L);
    curl_easy_setopt(c, CURLOPT_READFUNCTION, &ReadCb);
    curl_easy_setopt(c, CURLOPT_READDATA, (void*)f);
    curl_easy_setopt(c, CURLOPT_INFILESIZE_LARGE, (curl_off_t)size);
    // Fehlende Zwischenverzeichnisse anlegen -- sonst scheitert der
    // erste Upload in einen neuen Ordner.
    curl_easy_setopt(c, CURLOPT_FTP_CREATE_MISSING_DIRS, 1L);
    curl_easy_setopt(c, CURLOPT_ERRORBUFFER, errbuf);
    ApplyAuth(c, a);
    CURLcode rc = curl_easy_perform(c);
    curl_easy_cleanup(c);
    fclose(f);
    if (rc != CURLE_OK)
        return errbuf[0] ? errbuf : curl_easy_strerror(rc);
    return std::string();
}

namespace ui_sftp_detail {

// Rekursiv: Unterverzeichnisse erkennt man daran, dass sich sich
// auflisten lassen. (SFTP-DIRLISTONLY liefert keine Typinformation --
// deshalb dieser Umweg statt eines Flags.)
inline void GetDirRec(const UiSftpAuth& a, const std::string& remoteDir,
                      const std::string& localDir, std::string& err,
                      int depth) {
    if (depth > 16 || !err.empty()) return;
    UiNetJob& j = UiNetStatus();
    if (j.cancel.load()) { err = "abgebrochen"; return; }

    std::string e;
    std::vector<std::string> names = UiSftpList(a, remoteDir, &e);
    if (!e.empty()) { err = e; return; }

    for (const std::string& n : names) {
        if (j.cancel.load()) { err = "abgebrochen"; return; }
        std::string rp = remoteDir + "/" + n;
        std::string lp = localDir.empty() ? n : localDir + "/" + n;
        std::string sub;
        std::vector<std::string> probe = UiSftpList(a, rp, &sub);
        if (sub.empty()) {                       // liess sich auflisten
            GetDirRec(a, rp, lp, err, depth + 1);
            if (!err.empty()) return;
        } else {                                 // also eine Datei
            j.lastFile = lp;
            j.done.store(0); j.total.store(0);
            std::string fe = UiSftpGetFile(a, rp, lp);
            if (!fe.empty()) { err = fe; return; }
            j.filesDone.fetch_add(1);
        }
    }
}

} // namespace ui_sftp_detail

// Ganzes Verzeichnis rekursiv holen -- im Hintergrund.
// false = es laeuft bereits ein Auftrag.
inline bool UiSftpGetDir(UiSftpAuth a, std::string remoteDir,
                         std::string localDir) {
    UiNetJob& j = UiNetStatus();
    bool expected = false;
    if (!j.running.compare_exchange_strong(expected, true)) return false;
    j.cancel.store(false);
    j.lastError.clear();
    j.filesDone.store(0);
    j.filesTotal.store(0);        // unbekannt: Fortschritt pro Datei
    std::thread([a, remoteDir, localDir]() {
        std::string err;
        ui_sftp_detail::GetDirRec(a, remoteDir, localDir, err, 0);
        UiNetJob& jj = UiNetStatus();
        jj.lastError = err;
        jj.running.store(false);
    }).detach();
    return true;
}
