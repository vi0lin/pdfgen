#pragma once
// ---------------------------------------------------------------------------
// xbm_ui_flags.h -- Schalter der Oberflaeche, die NACH Runde 9 dazukamen.
//
// [Warum nicht alle Schalter hier? Weil UiScrollPinpoint() seit Runde 9
//  in ui_helpers.h steht -- in jedem Stand, den du hast. Wuerde es hier
//  NOCH EINMAL definiert, gaebe es "redefinition", sobald ein aelteres
//  ui_helpers.h daneben liegt. Diese Datei enthaelt deshalb nur, was
//  ui_helpers.h in KEINEM Stand hat. So passt sie zu jedem ui_helpers.h
//  seit Runde 9, und app_settings.h braucht nur diese eine Zeile:
//      #include "xbm_ui_flags.h"
//
//  Neue Schalter kommen HIER dazu, nirgendwo sonst.]
// ---------------------------------------------------------------------------
#define XBM_UI_FLAGS_H_GELADEN 1

// Formularbausteine gleich mit -- diese Datei wird frueh und ueberall
// eingebunden, damit UiFormInput auch in ui_helpers.h bekannt ist.
#include "ui_form.h"

// Einstellungsblaetter schliessen, wenn ein Tab-Symbol geklickt wird.
inline bool& UiSheetCloseOnTab() { static bool b = true; return b; }
