#pragma once
// ui_helpers.h -- gemeinsame UI-Bausteine fuer alle drei Plattformen.
#include "imgui.h"
#include "imgui_internal.h"
#include <map>   // Fensterliste fuer UiGatherAllWindows
#include <vector>

// ---------------------------------------------------------------------------
// Maximieren/Wiederherstellen fuer ImGui-Fenster.
// Nutzung:  static UiMaxState ms;  UiBeginMaximizable("Titel", ms, &open);
//           ... Inhalt ...        ImGui::End();
// Zeichnet oben rechts einen [Max]/[Wieder]-Button. Maximiert = Fenster
// fuellt den gesamten Viewport, NoMove/NoResize.
// ---------------------------------------------------------------------------
struct UiMaxState { bool maximized = false; ImVec2 savedPos{}, savedSize{}; };

// EINGEKLAPPTE FENSTER.
// [Angedockt kann ImGui nicht einklappen -- ein Dock-Knoten hat feste
//  Groesse, und der Titelbalken gehoert der Tab-Leiste. Wir merken den
//  Zustand deshalb je KNOTEN (alle Fenster derselben Tab-Leiste teilen
//  ihn, wie gewuenscht) und zeichnen den Inhalt einfach nicht. Die
//  Knotenhoehe zieht ui_pages nach; bis dahin bleibt der Knoten stehen,
//  aber leer -- und ein zweiter Klick holt alles zurueck.]
inline std::map<unsigned int, bool>& UiCollapsedNodes() {
    static std::map<unsigned int, bool> m; return m;
}
// Gemerkte Knotengroesse vor dem Einklappen.
inline std::map<unsigned int, ImVec2>& UiCollapsedSizes() {
    static std::map<unsigned int, ImVec2> m; return m;
}
inline bool UiNodeCollapsed(ImGuiWindow* w) {
    if (!w) return false;
    if (w->DockNode) {
        auto& m = UiCollapsedNodes();
        auto it = m.find((unsigned int)w->DockNode->ID);
        return it != m.end() && it->second;
    }
    return w->Collapsed;
}

inline bool UiBeginMaximizable(const char* title, UiMaxState& st, bool* open,
                               ImGuiWindowFlags extra = 0,
                               const char* extraBtn = nullptr,
                               bool* extraClicked = nullptr) {
    ImGuiWindowFlags flags = extra;
    if (st.maximized) {
        ImGuiViewport* vp = ImGui::GetMainViewport();
        // DOCK-BEWUSST: Ist das Fenster gerade angedockt (Kompakt-
        // Layout!), darf der Maximiert-Zustand KEINE Position erzwingen --
        // bedingungsloses SetNextWindowPos rippt es sonst in JEDEM Frame
        // aus dem Dock und zwingt es auf die Vollbild-Position ("andere
        // Position" nach jedem Uebergang). Das Dock hat Vorrang.
        {
            ImGuiWindow* existing = ImGui::FindWindowByName(title);
            if (!(existing && existing->DockIsActive)) {
                ImGui::SetNextWindowPos(vp->WorkPos);
                ImGui::SetNextWindowSize(vp->WorkSize);
            }
        }
        flags |= ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize
               | ImGuiWindowFlags_NoCollapse;
    }
    bool vis = ImGui::Begin(title, open, flags);
    if (vis) {
        // Buttons rechts oben in der Inhaltszeile; optional ein
        // ZUSATZ-Knopf (z.B. "Login" im Bookmark-Fenster) LINKS von Max.
        ImGuiWindow* selfw = ImGui::GetCurrentWindow();
        bool eingeklappt = UiNodeCollapsed(selfw);
        const char* mx = st.maximized ? "Wieder" : "Max";
        const char* cl = eingeklappt ? "v" : "^";      // Ein-/Ausklappen
        auto bw = [](const char* t) {
            return ImGui::CalcTextSize(t).x + ImGui::GetStyle().FramePadding.x * 2
                 + ImGui::GetStyle().ItemSpacing.x;
        };
        // Platz fuer: [extra] [^] [Max] [X]
        float w = bw(mx) + bw(cl) + bw("X");
        if (extraBtn) w += bw(extraBtn);
        ImGui::SameLine(ImGui::GetContentRegionAvail().x - w
                        + ImGui::GetCursorPosX());
        if (extraBtn) {
            if (ImGui::SmallButton(extraBtn) && extraClicked)
                *extraClicked = true;
            ImGui::SameLine();
        }
        // EIN-/AUSKLAPPEN -- angedockt wie freischwebend.
        if (ImGui::SmallButton(cl)) {
            if (selfw && selfw->DockNode)
                UiCollapsedNodes()[(unsigned int)selfw->DockNode->ID] = !eingeklappt;
            else
                ImGui::SetWindowCollapsed(!eingeklappt);
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip(eingeklappt ? "Ausklappen" : "Einklappen");
        ImGui::SameLine();
        if (ImGui::SmallButton(mx)) {
            if (!st.maximized) { st.savedPos = ImGui::GetWindowPos();
                                 st.savedSize = ImGui::GetWindowSize(); }
            st.maximized = !st.maximized;
            if (!st.maximized) {
                if (!ImGui::IsWindowDocked()) {   // Dock hat Vorrang
                    ImGui::SetWindowPos(st.savedPos);
                    ImGui::SetWindowSize(st.savedSize);
                }
            }
        }
        // SCHLIESSEN -- IMMER, auch freischwebend.
        // [ImGui zeichnet sein eigenes X nur in der Titelleiste. Die ist
        //  bei euren Fenstern per Flags weg (und angedockt gehoert sie der
        //  Tab-Leiste) -- deshalb gab es freischwebend gar keinen Weg zu
        //  schliessen. Dieser Knopf steht in der Inhaltszeile und wirkt
        //  in beiden Faellen.]
        ImGui::SameLine();
        if (ImGui::SmallButton("X") && open) *open = false;
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Fenster schliessen");
        ImGui::NewLine();
        // Eingeklappt: Inhalt nicht zeichnen. Der Aufrufer sieht false und
        // ruft trotzdem ImGui::End() -- wie bei einem unsichtbaren Fenster.
        if (eingeklappt) return false;
    }
    return vis;
}

// ---------------------------------------------------------------------------
// Umbruch-Button: wie ImGui::Button, bricht aber automatisch in die
// naechste Zeile um, wenn er nicht mehr in die Fensterbreite passt.
// Vor JEDEM Button ausser dem ersten aufrufen: UiWrapSameLine(label).
// ---------------------------------------------------------------------------
inline void UiWrapSameLine(const char* next_label) {
    float need = ImGui::CalcTextSize(next_label).x
               + ImGui::GetStyle().FramePadding.x * 2
               + ImGui::GetStyle().ItemSpacing.x;
    float avail = ImGui::GetContentRegionAvail().x;
    ImGui::SameLine();
    if (need > ImGui::GetContentRegionAvail().x + 0.01f || avail <= 0) {
        ImGui::NewLine();
    }
}

// ---------------------------------------------------------------------------
// Multitouch-Erfassung (Android fuellt das aus; Desktop: Maus = Punkt 0).
// ---------------------------------------------------------------------------
// Frame-Profiling: Abschnitte werden von main gefuellt (Millisekunden)
struct UiFrameProf { float poll = 0, newf = 0, gui = 0, effects = 0, render = 0, swap = 0; };
// UiWinFlags wird in ui_pages.h definiert, das hier NACH ui_helpers.h
// eingebunden wird -- daher Vorwaertsdeklaration (Definition folgt
// inline in derselben Uebersetzungseinheit).
ImGuiWindowFlags UiWinFlags(const char* title);

// Laeuft gerade eine Drag-Scroll-Geste? (Von UiGlobalDragScroll gesetzt,
// u.a. fuer die Tastatur-Gnadenfrist auf Android.)
inline bool& UiScrollGestureActive() { static bool v = false; return v; }

// Laeuft irgendwo ein Edge-Auto-Scroll (Liste oder Fenster)? Dann darf
// die App/der Kompakt-Host NICHT zusaetzlich scrollen -- sonst bewegen
// sich zwei Ebenen gleichzeitig. Wird beim Loslassen zurueckgesetzt.
inline bool& UiEdgeAutoActive() { static bool v = false; return v; }

// SICHTBARER BEREICH (Bildschirm MINUS eingeblendeter Tastatur). Wird in
// main_android jeden Frame gesetzt; auf dem Desktop bleibt es der volle
// Viewport. Fenster/Widgets koennen sich damit an den verkleinerten
// Platz anpassen, statt einen Scrollbalken zu bekommen.
inline float& UiVisTop()    { static float v = 0.0f; return v; }
inline float& UiVisBottom() { static float v = 0.0f; return v; }
inline bool&  UiImeOpen()   { static bool  v = false; return v; }

// GLOBALER SCHALTER: Android-Tastatur komplett abschalten. Ist er aus,
// wird die Bildschirmtastatur nie eingeblendet (nuetzlich mit einer
// Bluetooth-Tastatur -- dann bleibt der volle Bildschirm nutzbar).
// Wird in der xbm.ini gesichert.
inline bool& UiKeyboardEnabled() { static bool v = true; return v; }

// APP-DARSTELLUNG auf dem Desktop: true = randloses Vollbild (wie
// bisher), false = normales, verschiebbares Fenster mit Rahmen.
// Persistiert; Voreinstellung Vollbild.
inline bool& UiAppFullscreen() { static bool v = true; return v; }

// GLOBAL: DockSpace-Kanten ALLER Seiten an die Navis kleben --
// ueberstimmt die beiden Pro-Seite-Schalter, wenn gesetzt.
inline bool& UiDockStickAll() { static bool v = false; return v; }
// Wird gesetzt, wenn die Tastatur SOFORT verschwinden soll (z.B. beim
// Abschalten des Schalters); main_android setzt es nach dem Schliessen
// wieder zurueck.
inline bool& UiRequestHideKeyboard() { static bool v = false; return v; }
inline float  UiVisHeight() {
    float h = UiVisBottom() - UiVisTop();
    return h > 1.0f ? h : 1.0f;
}

// X-MODULATOR: Die horizontale Fingerposition regelt das Tempo des
// Edge-Auto-Scrolls -- links langsam (0.25x), Mitte normal (1x), rechts
// schnell (3x). So laesst sich in der Zone zweidimensional dosieren:
// vertikal die Richtung/Grundstaerke, horizontal die Feinabstimmung.
inline float UiEdgeSpeedMul(float mx, float left, float right) {
    float w = right - left;
    if (w < 1.0f) return 1.0f;
    float t = (mx - left) / w;          // 0 = links, 1 = rechts
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;
    return (t < 0.5f) ? (0.25f + t * 1.5f)          // 0.25 .. 1.0
                      : (1.0f + (t - 0.5f) * 4.0f); // 1.0  .. 3.0
}


inline UiFrameProf& UiProf() { static UiFrameProf p; return p; }

struct UiTouchPoint { int id; float x, y; };
inline std::vector<UiTouchPoint>& UiTouches() {
    static std::vector<UiTouchPoint> t;
    return t;
}

// ---------------------------------------------------------------------------
// Alle Fenster in den sichtbaren Canvas-Bereich zurueckholen. Noetig, weil
// das Canvas seine Groesse aendern kann (Primaermonitor vs. alle Monitore):
// in der imgui.ini gespeicherte Positionen jenseits der aktuellen Breite
// liegen AUSSERHALB des OS-Fensters -> Fenster unsichtbar.
// ---------------------------------------------------------------------------
// Punkt 3: Drag-Scroll fuer beliebige scrollbare Fenster. Am ENDE des
// Fensterinhalts (vor ImGui::End) aufrufen: Ziehen auf freier Flaeche
// scrollt vertikal, Widgets behalten Vorrang (kein Scroll waehrend ein
// Element aktiv ist).
// Unterdrueckung fuer den globalen Handler: Fenster mit EIGENER Drag-
// Behandlung (Auswahl-Modi, lokales UiDragScroll) setzen das Flag und
// haben Vorrang -- der globale Standard greift nur, wo niemand lokal
// behandelt hat. Wird jeden Frame automatisch zurueckgesetzt.
// Persistenter Zustand: eine Fenstergrenze (Dock-Splitter) wird gerade
// gezogen. Gesetzt beim Greifen, geloescht beim Loslassen -- als HARTER
// Waechter im globalen Drag-Scroll, damit waehrend des Grenzziehens
// niemals ein Scroll-Event in die Hierarchie gelangt (das Ein-Frame-
// "behandelt"-Flag allein hat Ordnungs-Fallen zwischen den Aufrufern).
inline bool& UiSplitterGrabActive() {
    static bool b = false;
    return b;
}

inline bool& UiDragHandledThisFrame() { static bool b = false; return b; }

// Anzeigename eines Fensters fuer Einblendungen: letzte Pfadkomponente,
// ohne "##"-Anteil und ohne die angehaengte "_XXXXXXXX"-ID von Childs.
inline void UiCleanWinName(const char* nm, char* out, int cap) {
    for (const char* p = nm; *p; ++p) if (*p == '/') nm = p + 1;
    int ci = 0;
    for (const char* p = nm; *p && ci < cap - 1; ++p) {
        if (p[0] == '#' && p[1] == '#') break;
        if (p[0] == '_') {               // "_XXXXXXXX" am Ende?
            int hex = 0; const char* q = p + 1;
            while (q[hex] && ((q[hex] >= '0' && q[hex] <= '9')
                   || (q[hex] >= 'A' && q[hex] <= 'F')
                   || (q[hex] >= 'a' && q[hex] <= 'f'))) ++hex;
            if (hex == 8 && q[8] == '\0') break;
        }
        out[ci++] = *p;
    }
    out[ci] = '\0';
    if (!out[0]) {                       // Notnagel: Rohname
        int i = 0;
        for (const char* p = nm; *p && i < cap - 1; ++p) out[i++] = *p;
        out[i] = '\0';
    }
}

// Ist das Fenster ein Dock-/Seiten-HOST (traegt einen DockSpace)?
// Solche Fenster sind als Merk-Ziel fuer den Doppeltipp-Wiedereintritt
// tabu: ein Zwischenscroll, der auf dem Host landet, darf das zuletzt
// gemerkte ECHTE Fenster (z.B. eine Liste) nicht verdraengen.
// STRUKTURELL geprueft (DockNodeAsHost) statt nur ueber Namen -- der
// Kompakt-Host heisst z.B. "##page_host_<Seite>" und rutschte am
// reinen Namensfilter vorbei. Die Namens-Checks bleiben als Gurt:
// das DockSpace-Childfenster ("...DockSpace...") und schwebende
// Node-Hosts ("##DockNode...") tragen selbst keinen DockNodeAsHost.
inline bool UiIsDockHostWindow(ImGuiWindow* w) {
    if (!w || !w->Name) return true;
    if (w->DockNodeAsHost) return true;
    if (strstr(w->Name, "DockSpace") != nullptr) return true;
    if (strncmp(w->Name, "##DockNode", 10) == 0) return true;
    if (strncmp(w->Name, "##page_host_", 12) == 0) return true;
    return false;
}

// Opt-out fuer den DOPPELTIPP-WIEDEREINTRITT der Pinpoint-Geste:
// Fenster, in denen der Doppeltipp eine EIGENE Bedeutung hat (z.B. der
// Auswahl-Modus des Bookmark-Fensters), melden ihr Rechteck pro Frame
// hier an -- innerhalb dieser Bereiche loest der Doppeltipp keinen
// Wiedereintritt aus. Die Liste wird von UiGlobalDragScroll pro Frame
// uebernommen und geleert.
inline std::vector<ImRect>& UiDblTapReentryOptOut() {
    static std::vector<ImRect> v;
    return v;
}

// GLOBALER STANDARD: freier Drag scrollt das naechstgelegene scrollbare
// Fenster in der Hierarchie. Suchreihenfolge ab dem Fenster unter dem
// Finger: (1) das Fenster selbst, wenn es scrollen kann, (2) bei
// gedockten Fenstern der Dock-Host (z.B. das Kompakt-Seitenfenster),
// (3) das Elternfenster (Childs), usw. Titelleisten-Drags (Fenster
// verschieben) und aktive Widgets bleiben unberuehrt.
// Einmal pro Frame NACH allen Fenstern aufrufen.
// SCROLLMODUS -- GLOBAL, IN DEN EINSTELLUNGEN UMSCHALTBAR.
// [true  = Pinpoint (Trackpoint-Modell): Auslenkung vom Aufsetzpunkt
//          bestimmt Richtung und Geschwindigkeit.
//  false = Normal: der Inhalt folgt dem Finger.
//  Beide teilen sich die Zielwahl, die Achsenaufteilung und die
//  Grenzen -- unterschieden wird nur die eine Groesse, die den Weg je
//  Frame bestimmt. So bleibt der Rest der Gestensteuerung unberuehrt.]
inline bool& UiScrollPinpoint() { static bool b = true; return b; }

// ANDROID-TASTATUR VERWENDEN. [Schaltet die Bildschirmtastatur (den
// Java-IME-Weg) ein/aus -- per Knopf links neben dem Einstellungen-
// Zahnrad, UND automatisch, sobald mit einer PHYSISCHEN Tastatur
// geschrieben wird (siehe main_android.cpp, wo ein echtes Tasten-
// Ereignis diese Einstellung selbststaendig abschaltet).]
//
// DERSELBE SCHALTER WIE UiKeyboardEnabled() -- nicht nur gleich
// beschriftet, sondern dieselbe Variable.
// [Hier stand vorher eine EIGENE Variable. Die globale Einstellung
//  "Android-Tastatur verwenden" (effects_gl.cpp) schaltete aber
//  UiKeyboardEnabled(), der Knopf in der Tab-Leiste, der "Tast."-
//  Umschalter und die Automatik dagegen DIESE hier. Zwei Schalter mit
//  derselben Beschriftung, die nichts voneinander wussten: die
//  Einstellungsseite zeigte "an", waehrend der Knopf "aus" zeigte, und
//  umgekehrt. Statt jede Aufrufstelle einzeln umzustellen (und dabei
//  womoeglich eine zu uebersehen), verweist dieser Name jetzt einfach
//  auf dieselbe Variable -- damit sind alle Stellen zwangslaeufig im
//  Gleichklang. Gespeichert wird weiterhin ueber UiKeyboardEnabled.]
inline bool& UiAndroidTastaturVerwenden() { return UiKeyboardEnabled(); }
// EIN Tipp scrollt immer die Seite (DockSpace); Fenster nur per
// Doppeltipp oder nach Halten. Vorgabe AN.
inline bool& UiOneTapDockspace() { static bool b = true; return b; }
// Wie lange halten, bis das Fenster unter dem Finger Ziel wird.
inline float& UiHoldSeconds() { static float f = 1.0f; return f; }
// Ebenenwechsel per Viertelkreis: abgeschaltet.
static constexpr bool kViertelkreisAktiv = false;

// Erstes scrollbares Fenster in der Kette nach oben -- wahlweise nur
// Dock-Hosts (die Seite), nicht die Fenster darin.
// nurSeite = das OBERSTE scrollbare Fenster der Kette (die Seite selbst),
// sonst das erste (das Fenster unter dem Finger).
// [Vorher wurde "die Seite" am Namen erkannt ("DockSpace"). Traegt das
//  scrollende Seitenfenster den Namen nicht, oder ist die Seite gerade
//  nicht scrollbar, kam nullptr zurueck -- und ein Rueckfall nahm dann
//  doch die Liste. Das oberste scrollbare Fenster ist immer die Seite,
//  ohne Namensraten.]
inline ImGuiWindow* UiFindScrollTarget(ImGuiWindow* hw, bool nurSeite) {
    ImGuiWindow* oberstes = nullptr;
    int gd = 0;
    while (hw && gd++ < 16) {
        bool scrollbar = (hw->ScrollMax.y > 0.5f || hw->ScrollMax.x > 0.5f);
        // "Die Seite" ist ein Fenster, das einen Dock-Knoten BEHERBERGT --
        // oder das DockSpace-Fenster selbst. Eine Liste, ein Kindfenster,
        // ein einzelnes Werkzeugfenster ist es nie, egal wie weit oben.
        // [Vorher galt "das oberste scrollbare" -- und wenn nur die Liste
        //  scrollbar war, war das oberste scrollbare eben die Liste.]
        bool istSeite = (hw->DockNodeAsHost != nullptr) || UiIsDockHostWindow(hw);
        if (scrollbar) {
            if (!nurSeite) return hw;
            if (istSeite) oberstes = hw;
        }
        if (hw->DockNode && hw->DockNode->HostWindow
            && hw->DockNode->HostWindow != hw)
            { hw = hw->DockNode->HostWindow; continue; }
        if (hw->ParentWindow) { hw = hw->ParentWindow; continue; }
        break;
    }
    return oberstes;
}

inline void UiGlobalDragScroll(bool touchMode) {
    static ImGuiWindow* pressHovered     = nullptr;   // Fenster beim Druck
    static double       pressT           = 0.0;
    static bool         holdApplied      = false;
    static bool         pressIsSecondTap = false;
    bool handled = UiDragHandledThisFrame();
    UiDragHandledThisFrame() = false;          // Reset fuer naechsten Frame
    // Opt-out-Rechtecke DIESES Frames uebernehmen und die Sammelliste
    // leeren -- zwingend VOR jedem fruehen Ausstieg, sonst wuechse die
    // Liste ueber Frames hinweg unbegrenzt.
    static std::vector<ImRect> dblTapOptOut;
    dblTapOptOut.swap(UiDblTapReentryOptOut());
    UiDblTapReentryOptOut().clear();
    if (!touchMode || handled) return;
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g) return;
    ImGuiIO& io = g->IO;

    // Zustand der aktuellen Beruehrung
    static bool   scrolling = false;
    static ImVec2 pressPos  = ImVec2(0, 0);
    // Grenz-Hysterese: Ueberschuss am Rand des inneren Fensters sammelt
    // sich erst als "Widerstand"; erst ab kHandoffBuf uebernimmt die
    // Eltern-Ebene -- und symmetrisch zurueck.
    static float  overAccum = 0.0f;   // gesammelter Rand-Ueberschuss
    static float  backAccum = 0.0f;   // Rueckweg-Distanz im Handoff
    static int    handoff   = 0;      // 0=innen, +1=untere Kante, -1=obere
    // GESTEN-ZIEL: das innerste scrollbare Fenster wird beim DRUCKBEGINN
    // eingefangen und fuer die GESAMTE Geste gehalten. Vorher wurde es
    // pro Frame aus dem Fenster unter dem Finger abgeleitet -- verlaesst
    // der Finger bei einer laengeren Wischgeste die Grenzen eines kleinen
    // Fensters (z.B. Effekt-Einstellungen), wurde ploetzlich der Host
    // dahinter zum Ziel: Scroll "sprang auf halber Hoehe hoch" und
    // ruckelte an jeder Fensterkante.
    static ImGuiWindow* gestureInner = nullptr;
    // VIERTELKREIS-GESTE (Ebenenwechsel mit dem Pinpoint-Finger selbst):
    // Zustand der Bahn-Auswertung, siehe Auswertungsblock weiter unten.
    static ImVec2 arcLastP   = ImVec2(0, 0);  // letzter Abtastpunkt
    static float  arcHeading = 0.0f;          // letzte Bewegungsrichtung (rad)
    static bool   arcHasHead = false;         // Richtung schon gueltig?
    static float  arcAccum   = 0.0f;          // aufsummierte Drehung (rad)
    static double arcStartT  = 0.0;           // Beginn der laufenden Drehung
    static double arcLockT   = 0.0;           // Sperre nach Ausloesung
    // VOLLKREIS (>=300 Grad am Stueck) = QUER-ACHSE schalten: im
    // Uhrzeigersinn AN, gegen den Uhrzeigersinn AUS. Laeuft PARALLEL
    // zum Viertelkreis: arcTotal summiert die GANZE ununterbrochene
    // Rotation (auch durch die Ausloese-Sperren hindurch), waehrend
    // arcAccum nach jedem Viertelkreis-Feuer neu beginnt. Erreicht die
    // Rotation den Vollkreis, werden die unterwegs gefeuerten
    // Ebenenwechsel ZURUECKGENOMMEN (Ziel vom Rotationsbeginn) -- der
    // Kreis war dann erkennbar als Schalter gemeint, nicht als Treppe.
    static float  arcTotal    = 0.0f;
    static double arcStepT    = 0.0;          // letzter Abtastschritt
    static ImGuiWindow* arcPreTarget = nullptr;
    static bool   arcPreValid = false;
    static bool   arcCircleLatch = false;
    // Kurze Einblendung nach einem Ebenenwechsel (Feedback, sonst wirkt
    // der Wechsel "unsichtbar" und die Geste unzuverlaessig).
    static double toastT = -10.0;
    static char   toastMsg[160] = "";
    // Doppeltipp-Zustand (horizontale Achse + Wiedereintritt). Die
    // TIPP-REGISTRIERUNG passiert im IsMouseClicked-Block unten, also
    // exakt EINMAL pro Aufsetzen und VOR allen Scroll-Schwellen --
    // damit zaehlen auch kurze, voellig ruhige Tipps.
    static bool   hArmed   = false;
    static double lastTapT = 0.0;   // ueberdauert Gesten (Doppeltipp!)
    static ImVec2 lastTapP = ImVec2(0, 0);
    // Erzwungenes Gesten-Ziel (Zweit-Finger-Tipp / Viertelkreis) --
    // ebenfalls hochgezogen, gleicher Grund: der Verfall beim Loslassen
    // war toter Code, das Ziel der VORIGEN Geste ueberlebte und
    // uebersteuerte beim naechsten Aufsetzen das Element unterm Finger.
    static ImGuiWindow* forcedTarget  = nullptr;
    static ImVec2       originShift   = ImVec2(0, 0);
    // Ziel der VORIGEN Geste -- ueberdauert bewusst Aufsetzen UND
    // Loslassen (im Gegensatz zu forcedTarget): Grundlage fuer den
    // Doppeltipp-Wiedereintritt weiter unten.
    static ImGuiWindow* lastGestureTarget = nullptr;
    // ZUSATZ-FINGER: Jeder weitere Finger (2., 3., 4., ...) kann einen
    // EIGENEN, vollwertigen Pinpoint auf dem Fenster unter sich starten
    // (beide Achsen) -- Zustand pro Finger in Slots, per Touch-ID
    // verfolgt. S. Multitouch-Block weiter unten.
    struct UiExtraPin {
        int          id     = -1;             // Touch-ID (-1 = frei)
        double       downT  = 0.0;            // Aufsetzzeit
        ImVec2       downP  = ImVec2(0, 0);   // Aufsetzpunkt = Nullpunkt
        ImVec2       pos    = ImVec2(0, 0);   // aktuelle Position
        bool         pin    = false;          // Halten -> Pinpoint aktiv
        bool         useMain = false;         // Doppeltipp: steuert das
                                              // Fenster des ERSTEN Fingers
        ImGuiWindow* target = nullptr;        // Treffer-Fenster (Anker)
    };
    static UiExtraPin extraPins[6];
    static double s_lastExtraUpT = -10.0;   // Loslassen des letzten
    static ImVec2 s_lastExtraUpP = ImVec2(0, 0);   // Zusatzfingers
    if (ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
        scrolling = false;
        pressPos = io.MousePos;
        overAccum = backAccum = 0.0f;
        handoff = 0;
        gestureInner = nullptr;
        arcLastP = io.MousePos; arcHasHead = false;
        arcAccum = 0.0f; arcStartT = ImGui::GetTime();
        arcTotal = 0.0f; arcCircleLatch = false; arcPreValid = false;
        // NEUES AUFSETZEN = NEUE GESTE: erzwungenes Ziel der vorigen
        // Geste verwerfen -- Ausgangspunkt ist wieder das Element, AUF
        // dem der Finger aufgesetzt hat. (Guertel+Hosentraeger zum
        // Loslass-Reset unten: greift auch, wenn der Loslass-Frame mal
        // nicht verarbeitet wurde, z.B. App-Pause.)
        forcedTarget  = nullptr;
        originShift   = ImVec2(0, 0);
        for (auto& ep : extraPins)
            { ep.id = -1; ep.pin = false; ep.useMain = false;
              ep.target = nullptr; }
        // ZIELWAHL -- drei Wege, eine Regel:
        //   EIN Tipp        -> der DockSpace (die Seite selbst)
        //   ZWEI Tipps      -> das Fenster unter dem Finger, sofort
        //   Halten ~1 s     -> das Fenster unter dem Finger
        // [Vorher galt: das erste scrollbare Fenster unter dem Finger.
        //  Auf einer Seite voller Listen traf ein Wisch dann fast immer
        //  eine Liste statt der Seite. Mit UiOneTapDockspace (Vorgabe
        //  AN) ist ein einfacher Wisch verlaesslich die Seite; wer eine
        //  Liste meint, tippt doppelt oder haelt kurz.]
        pressHovered = g->HoveredWindow;
        pressT       = ImGui::GetTime();
        holdApplied  = false;
        {
            double nowT0 = ImGui::GetTime();
            float ddx0 = io.MousePos.x - lastTapP.x, ddy0 = io.MousePos.y - lastTapP.y;
            pressIsSecondTap = (nowT0 - lastTapT < 0.35)
                             && (ddx0*ddx0 + ddy0*ddy0) < 60.0f*60.0f;
        }
        // EIN Finger -> die Seite. ZWEI Finger -> nur das Fenster.
        // [Zwei Finger sind die ausdrueckliche Ansage "ich meine DIESES
        //  Element". Vorher entschied nur pressIsSecondTap (zwei Tipps
        //  hintereinander); die Fingerzahl selbst blieb ungenutzt.]
        int fingerJetzt = (int)UiTouches().size();
        bool zweiFinger = fingerJetzt >= 2;
        bool nurDock = UiOneTapDockspace() && !pressIsSecondTap && !zweiFinger;
        gestureInner = UiFindScrollTarget(g->HoveredWindow, nurDock);
        if (zweiFinger && !gestureInner)
            gestureInner = UiFindScrollTarget(g->HoveredWindow, false);
        // TIPP-REGISTRIERUNG DIREKT BEIM AUFSETZEN. Frueher sass sie
        // HINTER der Scroll-Schwelle -- ein kurzer, RUHIGER Tipp kehrte
        // dort vorher um ("noch ein Klick"/Stillstand) und zaehlte NIE
        // als Tipp. Folge: Der Doppeltipp (zwei ruhige Tipps!) wurde auf
        // echten Geraeten praktisch nie erkannt; weder die horizontale
        // Achse noch der Wiedereintritt feuerten, und die normale Ziel-
        // suche landete stattdessen z.B. auf dem DockSpace.
        {
            double nowT = ImGui::GetTime();
            float ddx = io.MousePos.x - lastTapP.x;
            float ddy = io.MousePos.y - lastTapP.y;
            bool nearTap = (ddx * ddx + ddy * ddy) < 60.0f * 60.0f;
            hArmed = (nowT - lastTapT < 0.35 && nearTap);
            lastTapT = nowT; lastTapP = io.MousePos;
            // DOPPELTIPP = WIEDEREINTRITT: Ziel der vorigen Geste wird
            // wieder zum Pinpoint-Ziel -- ausser in Opt-out-Bereichen
            // (eigene Doppeltipp-Bedeutung, z.B. Bookmark-Auswahl) und
            // wenn es ohnehin das Fenster unter dem Finger ist.
            bool reentryBlocked = false;
            for (const ImRect& r : dblTapOptOut)
                if (r.Contains(io.MousePos)) { reentryBlocked = true; break; }
            // WIEDEREINTRITT ENTFERNT.
            // [Der Doppeltipp holte frueher das ZULETZT gescrollte Fenster
            //  zurueck -- auch eines, das gar nicht unter dem Finger lag.
            //  Das war schwer vorhersehbar. Der Doppeltipp bedeutet jetzt
            //  nur noch: das Fenster UNTER dem Finger, sofort.]
            (void)reentryBlocked;
        }
    }
    if (!io.MouseDown[0]) {
        // LOSLASSEN: der EINZIGE erreichbare Reset-Punkt (alles nach
        // diesem return ist im Loslass-Frame unerreichbar). Hier muss
        // daher ALLES Gestenhafte enden -- inkl. UiEdgeAutoActive, das
        // sonst dauerhaft true blieb und anderswo Scrolls unterdrueckte.
        scrolling     = false;
        hArmed        = false;
        forcedTarget  = nullptr;
        originShift   = ImVec2(0, 0);
        for (auto& ep : extraPins)
            { ep.id = -1; ep.pin = false; ep.useMain = false;
              ep.target = nullptr; }
        UiEdgeAutoActive() = false;
        return;
    }
    // (Ziel-Herleitung + Multitouch stehen bewusst VOR den folgenden
    // Verschiebe-/Drag-Guards: ZUSATZFINGER-Pinpoints funktionieren so
    // auch, waehrend Finger 1 ein Fenster verschiebt, ein Drag&Drop
    // haelt oder ein Widget bedient -- z.B. Fenster ziehen und mit dem
    // zweiten Finger schon zum Ablageziel scrollen. Der HAUPT-Pinpoint
    // bleibt durch die Guards weiter sauber gesperrt.)
    // Ziel der GESTE (beim Druck eingefangen); Fallback: Ableitung jetzt
    ImGuiWindow* inner = gestureInner;
    // KEIN RUECKFALL AUF DIE LISTE, wenn "Ein Tipp = Seite" gilt.
    // [Sonst landete ein Tipp auf einer Liste ohne scrollbare Seite doch
    //  in der Liste. Ist die Seite nicht scrollbar, gibt es bei Ein-Tipp
    //  schlicht nichts zu scrollen -- bis Halten oder Doppeltipp das
    //  Fenster zum Ziel machen.]
    bool einTippSeite = UiOneTapDockspace() && !pressIsSecondTap && !holdApplied;
    if (!inner && einTippSeite) return;
    if (!inner) {
        ImGuiWindow* w = g->HoveredWindow;
        int guard = 0;
        while (w && guard++ < 16) {
            if (w->ScrollMax.y > 0.5f || w->ScrollMax.x > 0.5f) {
                inner = w; break;
            }
            if (w->DockNode && w->DockNode->HostWindow
                && w->DockNode->HostWindow != w)
                { w = w->DockNode->HostWindow; continue; }
            if (w->ParentWindow) { w = w->ParentWindow; continue; }
            break;
        }
    }
    auto parentOf = [&](ImGuiWindow* c) -> ImGuiWindow* {
        if (!c) return nullptr;
        if (c->DockNode && c->DockNode->HostWindow
            && c->DockNode->HostWindow != c) return c->DockNode->HostWindow;
        return c->ParentWindow;
    };
    // Auslenkung -> Geschwindigkeit (px/s), progressiv, mit Totzone.
    // HIER OBEN definiert, weil sie ausser dem Haupt-Pinpoint unten auch
    // der QUER-PINPOINT des zweiten Fingers braucht.
    // KURVE v2: Der alte Verlauf (320*t + 3400*t^3) war am Anfang
    // TRAEGE -- der kubische Anteil traegt bei kleinen Auslenkungen
    // praktisch nichts bei, und 320 px/s linear sind zu wenig
    // ("zu lange geschieht keine Beschleunigung"). Jetzt DREI
    // Anteile: kraeftiger LINEARER Sockel (sofort spuerbar),
    // QUADRATISCHER Mittelbau (zuegiges Anziehen im Alltagsbereich)
    // und KUBISCHE Spitze (lange Listen). Bei 50 px Auslenkung ist
    // das ~3x so schnell wie vorher, die Spitze bleibt vergleichbar.
    // Sehr kleine Totzone (5px): sofortige Reaktion auf den Finger.
    auto vel = [](float d) -> float {
        const float dead = 5.0f;
        float m = fabsf(d) - dead;
        if (m <= 0.0f) return 0.0f;
        float t = m / 520.0f;           // laengerer Regelweg
        if (t > 1.3f) t = 1.3f;
        return (d < 0.0f ? -1.0f : 1.0f)
             * (t * 850.0f + t * t * 2200.0f + t * t * t * 3000.0f);
    };
    // KEIN scrollbares Ziel gefunden? NICHT abbrechen: Das Fenster unter
    // dem Finger dient als HIERARCHIE-ANKER, damit (a) die Viertelkreis-
    // Geste auch aus scroll-losen Fenstern heraus funktioniert (vorher:
    // Sackgasse -- die Geste wurde nie ausgewertet) und (b) die Achsen-
    // Aufteilung unten scrollbare ELTERN trotzdem findet. Nur auf voellig
    // freiem Canvas (kein Fenster) gibt es nichts zu tun.
    if (!inner) inner = g->HoveredWindow;
    if (!inner) return;

    // ====== MULTITOUCH: JEDER WEITERE FINGER = EIGENER PINPOINT =======
    // WICHTIG: Dieser Block laeuft VOR der Bewegungs-Schwelle von
    // Finger 1. Frueher lag er DAHINTER -- solange Finger 1 STILL auf
    // dem Schirm lag ("noch ein Klick"/Stillstand), kehrte die Funktion
    // vorher um und Zusatzfinger wurden nie ausgewertet: der zweite
    // Finger konnte dann keinen Pinpoint starten.
    // FUNKTION PRO ZUSATZFINGER (2., 3., 4., ...):
    //  * TIPP (kurz & ruhig, <=0.30s, <20px Bewegung): EBENENWECHSEL
    //    wie gehabt -- Tipp auf ein anderes scrollbares Fenster geht
    //    dort hinein, Tipp auf das aktuelle Ziel bricht nach oben aus.
    //  * HALTEN/BEWEGEN: ein EIGENER, vollwertiger Pinpoint auf dem
    //    Fenster unter dem Finger -- BEIDE Achsen (fehlende Achsen
    //    steigen wie beim Hauptfinger zur Eltern-Ebene hinauf), gleiche
    //    vel-Kurve, Nullpunkt = Aufsetzpunkt. NUR fuer Fenster, die
    //    nicht schon einen Pinpoint haben (weder das Hauptziel noch das
    //    eines anderen Fingers). Der MERKER (lastGestureTarget) bleibt
    //    unberuehrt -- Zusatzfinger sind fluechtige Scroller.
    {
        const auto& tl = UiTouches();
        double nowT = ImGui::GetTime();
        // Primaerfinger = Touchpunkt am ImGui-Zeiger; alle anderen mit
        // deutlichem Abstand (>40px, gegen Handballen, Doppelmeldungen
        // desselben Fingers und Geisterkontakte) sind Zusatzfinger.
        int primary = -1; float bestD = 1.0e9f;
        for (size_t i = 0; i < tl.size(); ++i) {
            float dd = fabsf(tl[i].x - io.MousePos.x)
                     + fabsf(tl[i].y - io.MousePos.y);
            if (dd < bestD) { bestD = dd; primary = (int)i; }
        }
        bool seen[6] = { false, false, false, false, false, false };
        for (size_t i = 0; i < tl.size(); ++i) {
            if ((int)i == primary) continue;
            float dOff = fabsf(tl[i].x - io.MousePos.x)
                       + fabsf(tl[i].y - io.MousePos.y);
            ImVec2 tp(tl[i].x, tl[i].y);
            int slot = -1, freeSlot = -1;
            for (int k = 0; k < 6; ++k) {
                if (extraPins[k].id == tl[i].id) { slot = k; break; }
                if (extraPins[k].id < 0 && freeSlot < 0) freeSlot = k;
            }
            if (slot < 0) {
                if (dOff <= 40.0f || freeSlot < 0) continue; // Geist/voll
                slot = freeSlot;
                UiExtraPin& np = extraPins[slot];
                // DOPPELTIPP-Erkennung des ZWEITEN Fingers: kam an
                // nahezu derselben Stelle innerhalb von 0.35 s schon
                // ein Zusatzfinger hoch, gilt dieser Druck als zweiter
                // Tipp -- dann steuert er das Fenster des ERSTEN
                // Fingers statt des Fensters unter sich.
                np.useMain = (nowT - s_lastExtraUpT <= 0.35)
                          && (fabsf(tp.x - s_lastExtraUpP.x)
                              + fabsf(tp.y - s_lastExtraUpP.y) < 60.0f);
                np.id = tl[i].id; np.downT = nowT;
                np.downP = tp; np.pin = false; np.target = nullptr;
                for (int wi = g->Windows.Size - 1; wi >= 0; --wi) {
                    ImGuiWindow* w2 = g->Windows[wi];
                    if (!w2->WasActive || w2->Hidden) continue;
                    if (!w2->Rect().Contains(tp)) continue;
                    np.target = w2; break;   // oberstes Fenster darunter
                }
            }
            UiExtraPin& ep = extraPins[slot];
            ep.pos = tp; seen[slot] = true;
            float mv = fabsf(tp.x - ep.downP.x)
                     + fabsf(tp.y - ep.downP.y);
            if (!ep.pin && (mv > 20.0f || nowT - ep.downT > 0.30)) {
                // AKTIVIEREN. SONDERFALL GLEICHES FENSTER: Liegt der
                // Zusatzfinger auf dem Ziel des HAUPTfingers, ist das
                // KEIN Konflikt, sondern der Quer-Scroll-Griff -- der
                // Hauptfinger behaelt die vertikale Achse, der Zusatz-
                // finger pinpointet dort NUR horizontal (links/rechts).
                // Blockiert wird nur, was schon ein ANDERER Zusatz-
                // finger pinpointet.
                // ZIEL-WAHL nach Tipp-Art (neue Regelung):
                //  * EINFACHER Tipp+Halten -> das Fenster UNTER DEM
                //    ZWEITEN Finger, BEIDE Achsen.
                //  * DOPPELTIPP -> das Fenster unter dem ERSTEN Finger
                //    (Hauptziel), ebenfalls BEIDE Achsen. So scrollt
                //    man ein entferntes Fenster bequem von hier aus.
                if (ep.useMain && inner) ep.target = inner;
                bool taken = (ep.target == nullptr);
                for (int k = 0; k < 6 && !taken; ++k)
                    if (k != slot && extraPins[k].id >= 0
                        && extraPins[k].pin
                        && extraPins[k].target == ep.target)
                        taken = true;
                if (ep.useMain) taken = false;   // Hauptziel teilen: ok
                if (!taken) {
                    ep.pin = true;
                    ImGuiWindow* an = ep.target; int gu = 0;
                    while (an && an->ScrollMax.y <= 0.5f
                           && an->ScrollMax.x <= 0.5f && gu++ < 16)
                        an = parentOf(an);
                    char clean[96];
                    UiCleanWinName(an ? an->Name : ep.target->Name,
                                   clean, sizeof(clean));
                    ImFormatString(toastMsg, sizeof(toastMsg),
                                   ep.useMain
                                       ? "\xe2\x86\x95\xe2\x86\x94 %s (Hauptziel)"
                                       : "\xe2\x86\x95\xe2\x86\x94 %s",
                                   clean);
                    toastT = nowT;
                }
            }
            if (ep.pin && ep.target) {
                // BEIDE ACHSEN anwenden, mit Achsen-Aufstieg wie beim
                // Hauptfinger (fehlt dem Ziel eine Achse, scrollt der
                // naechste Vorfahre, der sie besitzt).
                float dtE = io.DeltaTime > 0.0f ? io.DeltaTime : 0.016f;
                ImGuiWindow* tY = ep.target; int gy = 0;
                while (tY && tY->ScrollMax.y <= 0.5f && gy++ < 16)
                    tY = parentOf(tY);
                ImGuiWindow* tX = ep.target; int gx = 0;
                while (tX && tX->ScrollMax.x <= 0.5f && gx++ < 16)
                    tX = parentOf(tX);
                float vyE = vel(tp.y - ep.downP.y) * dtE;
                float vxE = vel(tp.x - ep.downP.x) * dtE;
                if (tY && (vyE < -0.01f || vyE > 0.01f)) {
                    float cur = tY->Scroll.y, ns = cur + vyE;
                    if (ns < 0.0f)            ns = 0.0f;
                    if (ns > tY->ScrollMax.y) ns = tY->ScrollMax.y;
                    if (ns != cur) ImGui::SetScrollY(tY, ns);
                }
                if (tX && (vxE < -0.01f || vxE > 0.01f)) {
                    float cur = tX->Scroll.x, ns = cur + vxE;
                    if (ns < 0.0f)            ns = 0.0f;
                    if (ns > tX->ScrollMax.x) ns = tX->ScrollMax.x;
                    if (ns != cur) ImGui::SetScrollX(tX, ns);
                }
                UiScrollGestureActive() = true;
            }
        }
        // LOSLASSEN: Slots, deren Touch-ID verschwunden ist, abwickeln.
        for (int k = 0; k < 6; ++k) {
            UiExtraPin& ep = extraPins[k];
            if (ep.id < 0 || seen[k]) continue;
            if (!ep.pin && nowT - ep.downT <= 0.30 && inner) {
                // TIPP -> Ebenenwechsel (Logik wie gehabt, am Tippunkt).
                ImGuiWindow* hit = nullptr;
                for (int wi = g->Windows.Size - 1; wi >= 0; --wi) {
                    ImGuiWindow* w2 = g->Windows[wi];
                    if (!w2->WasActive || w2->Hidden) continue;
                    if (!w2->Rect().Contains(ep.downP)) continue;
                    if (w2->ScrollMax.y <= 0.5f
                        && w2->ScrollMax.x <= 0.5f) continue;
                    hit = w2; break;
                }
                if (hit && hit != inner) {
                    forcedTarget = hit;              // hineingehen
                } else {
                    ImGuiWindow* up = parentOf(inner); int gu = 0;
                    while (up && gu++ < 16) {
                        if (up->ScrollMax.y > 0.5f
                            || up->ScrollMax.x > 0.5f) break;
                        up = parentOf(up);
                    }
                    if (up) forcedTarget = up;       // ausbrechen
                }
                // Nullpunkt nachziehen: kein Geschwindigkeitssprung.
                originShift = ImVec2(io.MousePos.x - pressPos.x,
                                     io.MousePos.y - pressPos.y);
            }
            // Loslass-Zeitpunkt/-Ort merken: naechster Druck kurz
            // darauf zaehlt als DOPPELTIPP (steuert dann das Fenster
            // des ersten Fingers).
            s_lastExtraUpT = nowT;
            s_lastExtraUpP = ep.pos;
            ep.id = -1; ep.pin = false; ep.useMain = false;
            ep.target = nullptr;
        }
    }

    if (g->MovingWindow) return;               // Titelleisten-Drag = Fenster bewegen
    if (g->DragDropActive) { scrolling = false; return; }  // Tab-Herausloesen u.ae.
    if (UiSplitterGrabActive()) { scrolling = false; return; }  // Grenzziehen

    // TABU-ZONEN: Steuert die Geste bereits ein anderes Element, darf sie
    // NIE in die Scroll-Hierarchie gelangen.
    //  * Slider/Drag-Widgets: sobald ein Wert auch nur minimal editiert
    //    wurde, setzt ImGui ActiveIdHasBeenEditedBefore -- das geschieht
    //    lange vor unserer Uebernahme-Schwelle und schuetzt sie sicher.
    //  * Scrollbalken: eigener ActiveId-Vergleich ueber die Scrollbar-IDs
    //    des aktiven Fensters (sonst wuerde der Balken-Drag gestohlen ->
    //    "buggy" wirkende Scrollbalken).
    if (UiSplitterGrabActive()) return;    // Grenz-Griff: nie stehlen
    if (g->ActiveId != 0) {
        if (g->ActiveIdHasBeenEditedBefore) return;
        if (ImGuiWindow* aw = g->ActiveIdWindow) {
            if (g->ActiveId == ImGui::GetWindowScrollbarID(aw, ImGuiAxis_X)
             || g->ActiveId == ImGui::GetWindowScrollbarID(aw, ImGuiAxis_Y))
                return;
            // RESIZE-GRIFFE: der Ecken-Griff liegt INNERHALB der
            // InnerClipRect -- der Chrome-Schutz griff dort nicht, und
            // die 12-px-Uebernahme stahl den Resize per ClearActiveID
            // ("hoert nach wenigen Millimetern auf"). Border- und
            // Ecken-IDs sind daher explizit tabu.
            for (int d = 0; d < 4; ++d)
                if (g->ActiveId ==
                    ImGui::GetWindowResizeBorderID(aw, (ImGuiDir)d))
                    return;
            for (int n = 0; n < 4; ++n)
                if (g->ActiveId == ImGui::GetWindowResizeCornerID(aw, n))
                    return;
        }
    }

    // MOBILE-SEMANTIK: Ein Druck AUF einem Widget bleibt ein Klick,
    // solange der Finger ruhig ist. Ueberschreitet die vertikale
    // Bewegung die Schwelle, uebernimmt der SCROLL: das Widget wird
    // sauber losgelassen (ClearActiveID) und ab da scrollt die Kette.
    // (Die fruehere pauschale IsAnyItemActive-Sperre liess Drags, die
    // auf Widgets beginnen -- auf Touch fast alle -- nie scrollen.)
    const float kThreshold = 6.0f;   // frueher 12 -- Pinpoint soll
                                     // sofort ansprechen
    // ZWEITER FINGER MITTEN IN DER GESTE: aufs Fenster umstellen.
    // [So kann man mit einem Finger die Seite scrollen und, ohne
    //  loszulassen, mit dem zweiten in die Liste wechseln.]
    if (!holdApplied && (int)UiTouches().size() >= 2) {
        if (ImGuiWindow* w2 = UiFindScrollTarget(pressHovered, false)) {
            if (w2 != gestureInner) { gestureInner = w2; holdApplied = true; }
        }
    }

    // HALTEN: nach ~1 s ohne Scrollbeginn wird das Fenster unter dem
    // Finger zum Ziel -- so scrollt man eine Liste, ohne doppelt zu tippen.
    if (!scrolling && !holdApplied && UiOneTapDockspace()
        && ImGui::GetTime() - pressT >= UiHoldSeconds()) {
        holdApplied = true;
        if (ImGuiWindow* w = UiFindScrollTarget(pressHovered, false))
            gestureInner = w;
    }
    if (!scrolling) {
        float moved = fabsf(io.MousePos.y - pressPos.y);
        if (ImGui::IsAnyItemActive()) {
            // CHROME-SCHUTZ: Uebernahme NUR, wenn der Druck im INHALTS-
            // Bereich des aktiven Fensters begann (InnerClipRect). Resize-
            // Griffe/-Raender, Titelleiste und TABS liegen ausserhalb --
            // dort gehoert die Geste kompromisslos ImGui: Resizen bleibt
            // fluessig, Tab-Herausloesen funktioniert (beides brach die
            // fruehere pauschale ClearActiveID-Uebernahme).
            ImGuiWindow* aw = g->ActiveIdWindow;
            if (!aw || !aw->InnerClipRect.Contains(pressPos)) return;
            if (moved < kThreshold) return;    // (noch) ein Klick
            ImGui::ClearActiveID();            // Scroll uebernimmt
            scrolling = true;
        } else {
            // ZITTERN IST KEIN SCROLLEN.
            // [Vorher begann das Scrollen ab 1 px. Ein Finger auf Glas
            //  zittert -- damit startete es fast immer VOR Ablauf der
            //  Haltezeit, und der Halte-Zweig (verlangt !scrolling) kam
            //  nie zum Zug. Dieselbe Schwelle wie bei Widgets.]
            if (moved < kThreshold) return;
            scrolling = true;
        }
    }
    // KEIN Ausstieg bei Stillstand mehr: Genau dann (Finger haelt an der
    // Kante) soll das Edge-Auto-Scroll arbeiten.
    // ============ PIN-POINT-SCROLLEN (Trackpoint-Modell) ============
    // Kein "Inhalt folgt dem Finger" mehr: Der AUFSETZPUNKT ist der
    // Nullpunkt, die AUSLENKUNG bestimmt Richtung UND Geschwindigkeit --
    // wie der rote Stick einer ThinkPad-Tastatur. Weiter weg = schneller,
    // zurueck zur Mitte = langsamer, loslassen = Stopp. Damit entfallen
    // Wischen, Randzonen und Auto-Scroll als getrennte Mechanismen: Es
    // gibt nur noch EINE Regelung.
    // NULLPUNKT = pressPos (wird ganz oben beim Druck erfasst). Ein
    // eigener, spaeter gesetzter Nullpunkt funktionierte NICHT: Auf
    // Touch beginnt fast jeder Druck auf einem Widget, und dort steigt
    // die Funktion im Klick-Frame vorher aus -- der Nullpunkt entstand
    // nie und es wurde gar nicht mehr gescrollt.
    ImVec2 origin = pressPos;
    // (Doppeltipp-Registrierung und -Wiedereintritt passieren jetzt
    // DIREKT beim Aufsetzen im IsMouseClicked-Block oben -- vor allen
    // Schwellen, damit auch ruhige Tipps zaehlen.)

    UiScrollGestureActive() = true;


    // ============ ZWEIT-FINGER-TIPP: EBENE WECHSELN ============
    // Ein kurzer Tipp mit dem ZWEITEN Finger, waehrend der Pinpoint-
    // Finger liegt, wechselt die Ebene:
    //   * Tipp auf ein ANDERES scrollbares Fenster -> dort HINEIN.
    //   * Tipp auf das AKTUELLE Ziel               -> nach OBEN ausbrechen.
    // Der Nullpunkt wird dabei auf die aktuelle Position des Pinpoint-
    // Fingers gesetzt, damit die Geschwindigkeit nicht springt.
    // (Nutzt die parallele Multitouch-Erfassung -- ImGui selbst kennt
    // nur EINEN Zeiger. forcedTarget/originShift sind oben bei den
    // uebrigen Gesten-Statics deklariert und werden beim Aufsetzen wie
    // beim Loslassen zurueckgesetzt.)
    // Ziel muss weiterhin EXISTIEREN -- ein totes Fenster verfaellt.
    // Fehlender Scroll ist dagegen KEIN Verfallsgrund mehr: Das Ziel
    // bleibt als Hierarchie-Anker gueltig (z.B. Inhalt passt gerade
    // rein), und die Achsen-Aufteilung unten scrollt ersatzweise die
    // naechste faehige Eltern-Ebene. [Frueher verfiel es -- und sprang
    // damit unsichtbar auf ein anderes Ziel zurueck.]
    if (forcedTarget && !forcedTarget->WasActive)
        forcedTarget = nullptr;
    if (forcedTarget) inner = forcedTarget;

    // ============ VIERTELKREIS: EBENE WECHSELN (EIN FINGER) ============
    // Der Pinpoint-Finger selbst zeichnet einen Viertelkreis:
    //   * GEGEN den Uhrzeigersinn -> eine Ebene HINAUF (naechstes
    //     scrollbares Elternfenster des aktuellen Ziels).
    //   * IM Uhrzeigersinn        -> in das scrollbare Element HINEIN,
    //     das gerade unter dem Finger liegt (tiefster Treffer;
    //     bevorzugt echte Nachfahren des aktuellen Ziels).
    // ERKENNUNG: Die Fingerbahn wird in ~8-px-Schritten abgetastet und
    // die VORZEICHENBEHAFTETEN Richtungsaenderungen zwischen den
    // Schritten aufsummiert. Erreicht die Summe +/-80 Grad (Toleranz
    // zum idealen 90-Grad-Bogen) innerhalb von 0.9 s, loest die Geste
    // aus. Bildschirm-Koordinaten (y nach UNTEN): IM Uhrzeigersinn =
    // POSITIVE Winkelsumme. Robustheit:
    //   * Gegendrehung >25 Grad startet die Summe neu (Zickzack beim
    //     normalen Dosieren loest nie aus -- gerade Zuege haben ~0 Grad
    //     Drehung, Richtungsumkehr ist ~180 Grad und faellt unter den
    //     Knick-Reset).
    //   * Harte Knicke (>100 Grad in EINEM Schritt) setzen zurueck.
    //   * Nach dem Ausloesen 0.35 s Sperre, sonst feuert ein weiter-
    //     gezogener Kreis mehrfach pro Umlauf.
    // Nach dem Wechsel wird der NULLPUNKT auf die aktuelle Finger-
    // position gezogen (originShift wie beim Zweit-Finger-Tipp), damit
    // die beim Zeichnen entstandene Auslenkung nicht als ploetzlicher
    // Scroll-Sprung im neuen Ziel weiterwirkt.
    //
    // ABGESCHALTET (Wunsch): der Ebenenwechsel per Viertelkreis loeste zu
    // oft ungewollt aus. Der Code bleibt, weil er sauber abgegrenzt ist --
    // ein  if (false)  davor, statt 80 Zeilen zu entfernen.
    if (kViertelkreisAktiv) {
        double now = ImGui::GetTime();
        const float kPi = 3.14159265f;
        float dxs = io.MousePos.x - arcLastP.x;
        float dys = io.MousePos.y - arcLastP.y;
        const float kStep = 8.0f;               // Abtastschritt (px)
        if (dxs * dxs + dys * dys >= kStep * kStep) {
            float head = atan2f(dys, dxs);
            if (arcHasHead) {
                float d = head - arcHeading;
                while (d >  kPi) d -= 2.0f * kPi;
                while (d < -kPi) d += 2.0f * kPi;
                const float kKink = 100.0f * kPi / 180.0f;
                const float kFlip =  25.0f * kPi / 180.0f;
                if (fabsf(d) > kKink) {                    // harter Knick
                    arcAccum = 0.0f; arcStartT = now;
                    arcTotal = 0.0f; arcCircleLatch = false;
                    arcPreValid = false;
                } else if (arcAccum != 0.0f
                           && ((arcAccum > 0.0f) != (d > 0.0f))
                           && fabsf(d) > kFlip) {          // Gegendrehung
                    arcAccum = d; arcStartT = now;
                    arcTotal = d; arcCircleLatch = false;
                    arcPreTarget = forcedTarget; arcPreValid = true;
                } else {
                    if (arcAccum == 0.0f) arcStartT = now;
                    arcAccum += d;
                    if (arcTotal == 0.0f) {   // Rotationsbeginn: Ziel
                        arcPreTarget = forcedTarget;   // sichern
                        arcPreValid  = true;
                    }
                    arcTotal += d;
                }
                arcStepT = now;
            }
            arcHeading = head; arcHasHead = true;
            arcLastP = io.MousePos;
        }
        if (now - arcStartT > 0.9) { arcAccum = 0.0f; arcStartT = now; }
        // Vollkreis-Zaehler hat eine EIGENE, mildere Pause-Grenze: ein
        // langsamer ganzer Kreis dauert laenger als 0.9 s insgesamt --
        // nur >0.6 s OHNE Schritt beendet die Rotation.
        if (arcTotal != 0.0f && now - arcStepT > 0.6)
            { arcTotal = 0.0f; arcCircleLatch = false; arcPreValid = false; }
        const float kCircle = 300.0f * kPi / 180.0f;   // Toleranz: 300
        if (!arcCircleLatch && fabsf(arcTotal) >= kCircle) {
            arcCircleLatch = true;                     // 1x pro Rotation
            bool cw = (arcTotal > 0.0f);
            // Unterwegs gefeuerte Viertelkreis-Ebenenwechsel dieser
            // Rotation zuruecknehmen.
            if (arcPreValid) {
                forcedTarget = arcPreTarget;
                if (arcPreTarget) inner = arcPreTarget;
            }
            hArmed = cw;               // CW = Quer-Achse AN, CCW = AUS
            originShift = ImVec2(io.MousePos.x - pressPos.x,
                                 io.MousePos.y - pressPos.y);
            arcAccum = 0.0f; arcStartT = now;
            arcLockT = now + 0.5;      // keine sofortige Viertel-Salve
            ImFormatString(toastMsg, sizeof(toastMsg),
                           cw ? "\xe2\x86\x94 quer AN"
                              : "\xe2\x86\x94 quer AUS");
            toastT = now;
        }
        // Waehrend der Sperre NICHT weiter aufsummieren: sonst liegt die
        // Summe bei einem durchgezogenen Kreis nach Sperr-Ende sofort
        // wieder ueber der Schwelle und es feuert im Sperr-Takt statt
        // pro frischem Bogen. So gilt: JE weiterer 80-Grad-Bogen NACH
        // Ablauf der Sperre = EIN weiterer Ebenenwechsel (Weiterkreisen
        // steigt also gezielt mehrere Ebenen, ~2 pro Sekunde).
        if (now < arcLockT) { arcAccum = 0.0f; arcStartT = now; }

        const float kTrig = 80.0f * kPi / 180.0f;   // Toleranz: 80 Grad
        if (now >= arcLockT && fabsf(arcAccum) >= kTrig) {
            bool cw = (arcAccum > 0.0f);   // y nach unten: CW = positiv
            ImGuiWindow* next = nullptr;
            if (cw) {
                // HINEIN: von vorn nach hinten das oberste scrollbare
                // Fenster unter dem Finger suchen, das nicht das
                // aktuelle Ziel ist. NACHFAHREN des Ziels gewinnen
                // sofort (echtes "Eindringen"); andere Fenster nur als
                // Fallback -- VORFAHREN sind tabu, sonst ginge die
                // Im-Uhrzeigersinn-Geste faktisch nach OBEN.
                ImGuiWindow* fallback = nullptr;
                for (int i = g->Windows.Size - 1; i >= 0; --i) {
                    ImGuiWindow* w2 = g->Windows[i];
                    if (!w2->WasActive || w2->Hidden) continue;
                    if (w2 == inner) continue;
                    if (!w2->Rect().Contains(io.MousePos)) continue;
                    if (w2->ScrollMax.y <= 0.5f
                        && w2->ScrollMax.x <= 0.5f) continue;
                    bool desc = false, anc = false;
                    { ImGuiWindow* a = w2; int gu = 0;   // inner Vorfahre von w2?
                      while ((a = parentOf(a)) && gu++ < 16)
                          if (a == inner) { desc = true; break; } }
                    { ImGuiWindow* a = inner; int gu = 0; // w2 Vorfahre von inner?
                      while ((a = parentOf(a)) && gu++ < 16)
                          if (a == w2) { anc = true; break; } }
                    if (desc) { next = w2; break; }
                    if (!anc && !fallback) fallback = w2;
                }
                if (!next) next = fallback;
            } else {
                // HINAUF: naechstes scrollbares Elternfenster.
                ImGuiWindow* up = parentOf(inner); int gu = 0;
                while (up && gu++ < 16) {
                    if (up->ScrollMax.y > 0.5f || up->ScrollMax.x > 0.5f)
                        break;
                    up = parentOf(up);
                }
                next = up;
            }
            if (next) {
                forcedTarget = next;
                inner = next;
                originShift = ImVec2(io.MousePos.x - pressPos.x,
                                     io.MousePos.y - pressPos.y);
                char clean[96];
                UiCleanWinName(next->Name, clean, sizeof(clean));
                ImFormatString(toastMsg, sizeof(toastMsg), "%s %s",
                               cw ? "\xe2\x96\xbc Hinein:"
                                  : "\xe2\x96\xb2 Hinauf:",
                               clean);
                toastT = now;
            } else {
                ImFormatString(toastMsg, sizeof(toastMsg), "%s",
                               cw ? "\xe2\x96\xbc kein inneres Ziel"
                                  : "\xe2\x96\xb2 schon zuoberst");
                toastT = now;
            }
            arcAccum = 0.0f; arcStartT = now;
            arcLockT = now + 0.35;
        }

        // Einblendung zeichnen (ueber allem, kurz, mit Ausblenden).
        double age = now - toastT;
        if (age < 1.0) {
            float a = (age < 0.7) ? 1.0f : (float)(1.0 - (age - 0.7) / 0.3);
            ImVec2 ts = ImGui::CalcTextSize(toastMsg);
            ImVec2 tp(io.MousePos.x - ts.x * 0.5f,
                      io.MousePos.y - 64.0f - ts.y);
            ImDrawList* dl = ImGui::GetForegroundDrawList();
            dl->AddRectFilled(ImVec2(tp.x - 8, tp.y - 5),
                              ImVec2(tp.x + ts.x + 8, tp.y + ts.y + 5),
                              IM_COL32(20, 20, 20, (int)(200 * a)), 6.0f);
            dl->AddText(tp, IM_COL32(255, 255, 255, (int)(255 * a)),
                        toastMsg);
        }
    }

    // EIN ZIEL PRO GESTE: Wo der Finger aufgesetzt hat, wird gescrollt --
    // und NUR dort. Kein Wechsel zu Nachbarn oder zur App, auch nicht am
    // Anschlag. [Die Weitergabe passte zum Wischen, beim Pinpoint fuehrt
    // sie dazu, dass es nach dem Fensterende rasant in der App
    // weiterlaeuft -- man verliert die Uebersicht. Ausserdem war der
    // Zielwechsel mitten im Zug eine Ruckelquelle.]

    // (vel ist weiter oben definiert -- gemeinsam genutzt mit dem
    // Quer-Pinpoint des zweiten Fingers.)
    float dt = ImGui::GetIO().DeltaTime;
    if (dt <= 0.0f) dt = 0.016f;
    origin.x += originShift.x; origin.y += originShift.y;
    float vy, vx;
    if (UiScrollPinpoint()) {
        vy = vel(io.MousePos.y - origin.y) * dt;
        vx = hArmed ? vel(io.MousePos.x - origin.x) * dt : 0.0f;
    } else {
        // NORMALER SCROLL: der Inhalt folgt dem Finger -- also genau die
        // Bewegung dieses Frames, mit umgekehrtem Vorzeichen.
        vy = -io.MouseDelta.y;
        vx = hArmed ? -io.MouseDelta.x : 0.0f;
    }

    // ACHSEN-AUFTEILUNG: Angewendet wird primaer auf das Ziel -- fehlt
    // dem Ziel aber eine Achse (ScrollMax == 0, z.B. horizontaler
    // Thumbnail-Streifen ohne vertikalen Scroll, oder Inhalt passt
    // gerade rein), steigt GENAU DIESE Achse automatisch zur naechsten
    // Eltern-Ebene hinauf, die sie besitzt. Damit ist die Auslenkung
    // nie "tot": vertikal ziehen in einem rein horizontalen Kind
    // scrollt die Liste dahinter -- wie verschachtelte Scroll-Container.
    // [Das relativiert "EIN ZIEL PRO GESTE" bewusst nur fuer Achsen,
    // die das Ziel GAR NICHT hat -- ein Ziel am ANSCHLAG seiner
    // vorhandenen Achse gibt weiterhin NICHTS weiter.]
    ImGuiWindow* tgtY = inner;
    { int gu = 0; while (tgtY && tgtY->ScrollMax.y <= 0.5f && gu++ < 16)
          tgtY = parentOf(tgtY); }
    ImGuiWindow* tgtX = inner;
    { int gu = 0; while (tgtX && tgtX->ScrollMax.x <= 0.5f && gu++ < 16)
          tgtX = parentOf(tgtX); }
    if (tgtY && (vy < -0.01f || vy > 0.01f)) {
        float cur = tgtY->Scroll.y, ns = cur + vy;
        if (ns < 0.0f)              ns = 0.0f;
        if (ns > tgtY->ScrollMax.y) ns = tgtY->ScrollMax.y;
        if (ns != cur) { ImGui::SetScrollY(tgtY, ns);
                         UiEdgeAutoActive() = true; }
    }
    if (tgtX && (vx < -0.01f || vx > 0.01f)) {
        float cur = tgtX->Scroll.x, ns = cur + vx;
        if (ns < 0.0f)              ns = 0.0f;
        if (ns > tgtX->ScrollMax.x) ns = tgtX->ScrollMax.x;
        if (ns != cur) ImGui::SetScrollX(tgtX, ns);
    }

    // Effektives Ziel dieser Geste festhalten (fuer den Doppeltipp-
    // Wiedereintritt der NAECHSTEN Geste). inner ist hier das Ziel
    // inklusive aller Ebenenwechsel (Zweitfinger/Viertelkreis).
    // NIE gespeichert werden:
    //  * DOCK-/SEITEN-HOSTS (UiIsDockHostWindow) -- ein Zwischenscroll
    //    auf dem DockSpace laesst den Merker unangetastet.
    //  * Fenster, die AUSSCHLIESSLICH horizontal scrollbar sind
    //    (ScrollMax.x > 0 bei ScrollMax.y == 0) -- reine Quer-Streifen
    //    sind Zwischenziele (Finger 2!) und verdraengen den Merker
    //    nicht. Fenster MIT vertikaler Achse duerfen dagegen hinein,
    //    auch wenn sie zusaetzlich horizontal koennen: Wer sie mit dem
    //    ERSTEN Finger aktiv gescrollt hat, will sie per Doppeltipp
    //    von woanders weiterscrollen.
    if (inner && !UiIsDockHostWindow(inner)
        && !(inner->ScrollMax.x > 0.5f && inner->ScrollMax.y <= 0.5f))
        lastGestureTarget = inner;
}

inline void UiDragScroll(bool touchOnly = true) {
#if !defined(__ANDROID__)
    if (touchOnly) return;   // Desktop: Mausrad scrollt; Drag waehlt/zieht
#endif
    ImGuiIO& io = ImGui::GetIO();
    if (ImGui::IsWindowHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem)
        && io.MouseDown[0] && !ImGui::IsAnyItemActive()
        && fabsf(io.MouseDelta.y) > 0.0f) {
        ImGui::SetScrollY(ImGui::GetScrollY() - io.MouseDelta.y);
        UiDragHandledThisFrame() = true;
    }
}

inline void UiGatherAllWindows() {
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g) return;
    ImGuiViewport* vp = ImGui::GetMainViewport();
    const float mrg = 40.0f;
    for (ImGuiWindow* w : g->Windows) {
        if (!w->WasActive) continue;
        if (w->DockNode != nullptr) continue;  // gedockt: verwaltet das Layout
        if (w->Flags & (ImGuiWindowFlags_ChildWindow | ImGuiWindowFlags_Tooltip
                        | ImGuiWindowFlags_Popup)) continue;
        ImVec2 p = w->Pos;
        float maxX = vp->WorkPos.x + vp->WorkSize.x - mrg;
        float maxY = vp->WorkPos.y + vp->WorkSize.y - mrg;
        if (p.x > maxX) p.x = maxX - 200.0f;
        if (p.y > maxY) p.y = maxY - 100.0f;
        if (p.x + w->Size.x < vp->WorkPos.x + mrg) p.x = vp->WorkPos.x + 20.0f;
        if (p.y < vp->WorkPos.y)                   p.y = vp->WorkPos.y + 20.0f;
        if (p.x != w->Pos.x || p.y != w->Pos.y)
            ImGui::SetWindowPos(w, p, ImGuiCond_Always);
    }
}

// ---------------------------------------------------------------------------
// Eingabe-Debug-Fenster: Mausposition, alle Touch-Punkte, Framerate.
// Holt sich SELBST in den sichtbaren Bereich zurueck, falls es (durch
// Canvas-Verkleinerung oder alte ini-Positionen) ausserhalb liegt.
// ---------------------------------------------------------------------------
inline void UiShowInputDebugWindow(bool* open) {
    if (open && !*open) return;
    // Feste Startposition: nach einem imgui.ini-Reset platziert ImGui
    // Fenster ohne definierte Position in einer Kaskade, die je nach
    // Fensterreihenfolge auch unguenstig/verdeckt landen kann. Oben rechts
    // unterhalb des Overlay-Streifens ist immer frei sichtbar.
    {
        ImGuiViewport* vp = ImGui::GetMainViewport();
        ImGui::SetNextWindowPos(
            ImVec2(vp->WorkPos.x + vp->WorkSize.x - 320.0f,
                   vp->WorkPos.y + vp->WorkSize.y * 0.15f),
            ImGuiCond_FirstUseEver);
    }
    ImGui::SetNextWindowSize(ImVec2(300, 260), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowCollapsed(false, ImGuiCond_FirstUseEver);
    if (ImGui::Begin("Eingabe-Monitor", open,
                     UiWinFlags("Eingabe-Monitor"))) {
        // Selbst-Rettung: liegt das Fenster ausserhalb des Canvas, zurueck
        // in den sichtbaren Bereich (jede ini-Altlast wird damit egal).
        // NIEMALS bei gedocktem Fenster: SetWindowPos dockt aus -> im
        // Kompakt-Modus entstand daraus eine Endlosschleife (ausdocken ->
        // Rebuild -> eindocken -> ausdocken), sichtbar als Flackern und
        // scheinbares Doppel-Fenster.
        if (!ImGui::IsWindowDocked()) {
            ImGuiViewport* vp = ImGui::GetMainViewport();
            ImVec2 p = ImGui::GetWindowPos();
            bool out = p.x > vp->WorkPos.x + vp->WorkSize.x - 40.0f
                    || p.y > vp->WorkPos.y + vp->WorkSize.y - 40.0f
                    || p.x + ImGui::GetWindowWidth() < vp->WorkPos.x + 40.0f
                    || p.y < vp->WorkPos.y;
            if (out)
                ImGui::SetWindowPos(ImVec2(
                    vp->WorkPos.x + vp->WorkSize.x - 320.0f,
                    vp->WorkPos.y + vp->WorkSize.y * 0.15f), ImGuiCond_Always);
        }
        ImGuiIO& io = ImGui::GetIO();
        // Build-Stempel: identifiziert die laufende Version zweifelsfrei --
        // beendet jede "alter Build?"-Diskussion auf einen Blick.
        //
        // [HIER lag die ganze Zeit der eigentliche Fehler -- nicht dort,
        //  wo ich zuvor gesucht hatte. __DATE__/__TIME__ werden vom
        //  PRAEPROZESSOR beim Uebersetzen DIESER Uebersetzungseinheit
        //  eingesetzt -- aber ccache behandelt genau diese beiden Makros
        //  ABSICHTLICH als "aendert den Hash nicht" (die sogenannte
        //  "time_macros"-Nachsicht, eine dokumentierte, ueberall verbreitete
        //  ccache-Voreinstellung: ohne sie wuerde JEDE Datei, die
        //  __DATE__/__TIME__ benutzt, bei JEDEM Bau neu uebersetzt werden
        //  muessen, was Caching fuer sie sinnlos machen wuerde). Ergebnis:
        //  ccache konnte hier ein ALTES Objekt wiederverwenden, obwohl der
        //  Rest des Baus laengst frisch war -- unabhaengig davon, wie
        //  zuverlaessig xbm_buildinfo.cpp selbst erzeugt wird (das hatte
        //  ich zuvor repariert, aber es wurde bisher NIRGENDS ANGEZEIGT --
        //  diese Zeile hier las __DATE__/__TIME__ direkt, nie
        //  XBM_BUILD_ZEIT).
        //  Jetzt zeigt genau diese Zeile XBM_BUILD_ZEIT an -- dieselbe
        //  Zeichenkette, die in einer EIGENEN, von ccache ausdruecklich
        //  ausgenommenen Uebersetzungseinheit entsteht (siehe
        //  cmake/xbm_buildinfo.cmake, xbm_buildinfo_obj-Ziel). Sie ist
        //  garantiert bei jedem Bau frisch, unabhaengig von ccache.]
        extern const char* const XBM_BUILD_ZEIT;
        ImGui::TextDisabled("Build: %s", XBM_BUILD_ZEIT);
        ImGui::Text("FPS: %.1f (%.2f ms)", io.Framerate,
                    1000.0f / (io.Framerate > 0 ? io.Framerate : 1));
        UiFrameProf& pf = UiProf();
        ImGui::Text("poll %.1f | newf %.1f | gui %.1f | render %.1f | swap %.1f ms",
                    pf.poll, pf.newf, pf.gui, pf.render, pf.swap);
        {   // Render-Instanzen zuerst (vor den Eingabedaten)
            extern void EffectsGl_AppendInstanceInfo();
            EffectsGl_AppendInstanceInfo();
        }
        ImGui::Separator();
        ImGui::Text("Maus/Primaer: %.0f / %.0f", io.MousePos.x, io.MousePos.y);
        ImGui::Text("Buttons: L=%d R=%d", io.MouseDown[0], io.MouseDown[1]);
        ImGui::Separator();
        auto& touches = UiTouches();
        ImGui::Text("Aktive Touch-Punkte: %d", (int)touches.size());
        for (const auto& t : touches)
            ImGui::Text("  Finger %d: %.0f / %.0f", t.id, t.x, t.y);
    }
    ImGui::End();
}
