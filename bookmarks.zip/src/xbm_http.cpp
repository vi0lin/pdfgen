#include "xbm_http.h"
#include "curl_android_ca.h"

#include <curl/curl.h>
#include <cstring>

namespace {
size_t xbm_http_write(char* ptr, size_t size, size_t nmemb, void* userdata) {
    auto* s = static_cast<std::string*>(userdata);
    s->append(ptr, size * nmemb);
    return size * nmemb;
}
}

std::string XbmUrlEncode(const std::string& s) {
    CURL* c = curl_easy_init();
    if (!c) return s;
    char* e = curl_easy_escape(c, s.c_str(), (int)s.size());
    std::string out = e ? e : s;
    if (e) curl_free(e);
    curl_easy_cleanup(c);
    return out;
}

XbmHttpAntwort XbmHttp(const std::string& method,
                       const std::string& url,
                       const std::map<std::string, std::string>& cookies,
                       const std::vector<std::string>& kopfzeilen,
                       const std::string& body,
                       bool weiterleitungenFolgen) {
    XbmHttpAntwort a;
    CURL* curl = curl_easy_init();
    if (!curl) { a.fehler = "curl_easy_init fehlgeschlagen"; return a; }
    ApplyAndroidCaPath(curl);

    // Cookies zu EINER Kopfzeile zusammensetzen.
    std::string cookie;
    for (auto& kv : cookies) {
        if (!cookie.empty()) cookie += "; ";
        cookie += kv.first + "=" + kv.second;
    }
    struct curl_slist* hdr = nullptr;
    if (!cookie.empty()) hdr = curl_slist_append(hdr, ("Cookie: " + cookie).c_str());
    for (auto& h : kopfzeilen) hdr = curl_slist_append(hdr, h.c_str());
    // Ohne User-Agent antworten Reddit und Facebook mit 429/403.
    bool hatUa = false;
    for (auto& h : kopfzeilen)
        if (h.size() > 11 && strncasecmp(h.c_str(), "user-agent:", 11) == 0) hatUa = true;
    if (!hatUa)
        hdr = curl_slist_append(hdr,
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36");

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, hdr);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, xbm_http_write);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &a.body);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 25L);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, weiterleitungenFolgen ? 1L : 0L);
    curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "");   // gzip usw. annehmen
    if (method == "POST") {
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, (long)body.size());
    }
    char errbuf[CURL_ERROR_SIZE] = {0};
    curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, errbuf);

    CURLcode rc = curl_easy_perform(curl);
    if (rc != CURLE_OK) {
        a.fehler = errbuf[0] ? errbuf : curl_easy_strerror(rc);
    } else {
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &a.status);
        char* eff = nullptr;
        if (curl_easy_getinfo(curl, CURLINFO_EFFECTIVE_URL, &eff) == CURLE_OK && eff)
            a.endgueltigeUrl = eff;
    }
    curl_slist_free_all(hdr);
    curl_easy_cleanup(curl);
    return a;
}
