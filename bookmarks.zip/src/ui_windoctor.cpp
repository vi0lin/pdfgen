// ---------------------------------------------------------------------------
// ui_windoctor.cpp -- siehe ui_windoctor.h.
// ---------------------------------------------------------------------------
#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif
#include "ui_windoctor.h"
#include "imgui_internal.h"

#include <cstdio>
#include <cstring>
#include <map>

namespace {

struct Snapshot {
    bool  submitted   = false;
    bool  found       = false;
    bool  wasActive   = false;
    bool  hidden      = false;
    bool  collapsed   = false;
    bool  docked      = false;
    bool  ownViewport = false;
    bool  offCanvas   = false;
    bool  behindHost  = false;
    int   displayIdx  = -1;   // Platz in der Zeichenreihenfolge
    ImVec2 pos{0, 0}, size{0, 0};
    std::string scoped;

    bool operator==(const Snapshot& o) const {
        return submitted == o.submitted && found == o.found
            && wasActive == o.wasActive && hidden == o.hidden
            && collapsed == o.collapsed && docked == o.docked
            && ownViewport == o.ownViewport && offCanvas == o.offCanvas
            && behindHost == o.behindHost
            && (int)pos.x == (int)o.pos.x && (int)pos.y == (int)o.pos.y
            && (int)size.x == (int)o.size.x && (int)size.y == (int)o.size.y;
    }
};

struct Doc {
    bool enabled = false;
    std::map<std::string, Snapshot> last;
    std::map<std::string, const char*> submitted;   // je Frame gesetzt
    std::vector<std::string> log;
};
Doc& D() { static Doc d; return d; }

void Emit(const std::string& s) {
    std::fprintf(stderr, "[doktor] %s\n", s.c_str());
    D().log.push_back(s);
    if (D().log.size() > 200) D().log.erase(D().log.begin());
}

// Findet das Fenster unabhaengig davon, ob der Name gescopt ist.
ImGuiWindow* FindAny(const std::string& base, std::string& scopedOut) {
    ImGuiContext& g = *ImGui::GetCurrentContext();
    ImGuiWindow* best = nullptr;
    for (ImGuiWindow* w : g.Windows) {
        const char* n = w->Name;
        if (base == n) { scopedOut = n; return w; }
        // "Prototype##Bewerben" oder "Prototype###id"
        if (std::strncmp(n, base.c_str(), base.size()) == 0 &&
            n[base.size()] == '#') {
            best = w; scopedOut = n;
        }
    }
    return best;
}

}  // namespace

void UiWinDoctor_Watch(const char* base) {
    if (!base) return;
    D().last[base];               // Eintrag anlegen
}
void UiWinDoctor_Unwatch(const char* base) { if (base) D().last.erase(base); }
void UiWinDoctor_SetEnabled(bool on) { D().enabled = on; }
bool UiWinDoctor_Enabled() { return D().enabled; }
const std::vector<std::string>& UiWinDoctor_Log() { return D().log; }
void UiWinDoctor_ClearLog() { D().log.clear(); }

void UiWinDoctor_NoteSubmit(const char* base, const char* titleOrNull) {
    if (!D().enabled || !base) return;
    D().submitted[base] = titleOrNull;
}

void UiWinDoctor_Frame() {
    if (!D().enabled) return;
    ImGuiContext* ctx = ImGui::GetCurrentContext();
    if (!ctx) return;
    ImGuiViewport* mvp = ImGui::GetMainViewport();

    // Zeichenreihenfolge: Position in ctx->Windows ist die Reihenfolge, in
    // der ImGui zeichnet -- weiter hinten = weiter vorne auf dem Schirm.
    std::map<ImGuiWindow*, int> order;
    for (int i = 0; i < ctx->Windows.Size; ++i) order[ctx->Windows[i]] = i;

    // Deckende Vollbild-Hosts einsammeln (Kandidaten fuer "liegt dahinter").
    std::vector<std::pair<ImRect, int>> hosts;
    for (int i = 0; i < ctx->Windows.Size; ++i) {
        ImGuiWindow* w = ctx->Windows[i];
        if (!w->WasActive || w->Hidden) continue;
        if (std::strncmp(w->Name, "##page_host_", 12) != 0) continue;
        hosts.push_back({ ImRect(w->Pos, ImVec2(w->Pos.x + w->Size.x,
                                                w->Pos.y + w->Size.y)), i });
    }

    for (auto& kv : D().last) {
        const std::string& base = kv.first;
        Snapshot s;
        auto itSub = D().submitted.find(base);
        s.submitted = (itSub != D().submitted.end() && itSub->second != nullptr);

        ImGuiWindow* w = FindAny(base, s.scoped);
        if (w) {
            s.found       = true;
            s.wasActive   = w->WasActive;
            s.hidden      = w->Hidden;
            s.collapsed   = w->Collapsed;
            s.docked      = w->DockIsActive;
            s.pos = w->Pos; s.size = w->Size;
            s.ownViewport = (w->Viewport && mvp && w->Viewport->ID != mvp->ID);
            if (mvp) {
                const ImRect canvas(mvp->Pos,
                    ImVec2(mvp->Pos.x + mvp->Size.x, mvp->Pos.y + mvp->Size.y));
                s.offCanvas = w->Pos.x >= canvas.Max.x || w->Pos.y >= canvas.Max.y
                           || w->Pos.x + w->Size.x <= canvas.Min.x
                           || w->Pos.y + w->Size.y <= canvas.Min.y;
            }
            auto io = order.find(w);
            s.displayIdx = (io != order.end()) ? io->second : -1;
            // Liegt ein deckender Host WEITER VORNE und ueberdeckt uns?
            for (const auto& h : hosts) {
                if (h.second <= s.displayIdx) continue;
                const ImRect r(w->Pos, ImVec2(w->Pos.x + w->Size.x,
                                              w->Pos.y + w->Size.y));
                if (h.first.Contains(r)) { s.behindHost = true; break; }
            }
        }

        Snapshot& prev = kv.second;
        if (s == prev) continue;               // nichts Neues zu melden
        prev = s;

        char buf[512];
        std::snprintf(buf, sizeof(buf),
            "'%s' submittet=%d gefunden=%d aktiv=%d versteckt=%d eingeklappt=%d "
            "gedockt=%d eigenerViewport=%d ausserhalb=%d hinterHost=%d "
            "zOrder=%d pos=(%.0f,%.0f) groesse=(%.0f,%.0f) name='%s'",
            base.c_str(), (int)s.submitted, (int)s.found, (int)s.wasActive,
            (int)s.hidden, (int)s.collapsed, (int)s.docked,
            (int)s.ownViewport, (int)s.offCanvas, (int)s.behindHost,
            s.displayIdx, s.pos.x, s.pos.y, s.size.x, s.size.y,
            s.scoped.c_str());
        Emit(buf);

        // Klartext-Befund, damit man die Zahlen nicht deuten muss.
        const char* verdict = nullptr;
        if (!s.submitted)        verdict = "URSACHE: wird gar nicht submittet "
                                           "(UiPageWindow lieferte nullptr -- "
                                           "falsche Seite aktiv?)";
        else if (!s.found)       verdict = "URSACHE: ImGui kennt kein Fenster "
                                           "dieses Namens";
        else if (!s.wasActive)   verdict = "URSACHE: nicht aktiv (Begin lief "
                                           "nicht oder gab false)";
        else if (s.collapsed)    verdict = "URSACHE: eingeklappt";
        else if (s.ownViewport)  verdict = "URSACHE: eigener OS-Viewport -- "
                                           "wird nur von RenderPlatformWindows"
                                           "Default() gezeichnet";
        else if (s.offCanvas)    verdict = "URSACHE: liegt ausserhalb der "
                                           "Arbeitsflaeche";
        else if (s.behindHost)   verdict = "URSACHE: liegt HINTER dem deckenden "
                                           "Seiten-Host";
        else if (s.hidden)       verdict = "URSACHE: Hidden gesetzt (Groesse 0 "
                                           "oder erster Frame)";
        if (verdict) Emit(std::string("  -> ") + verdict);
    }
    D().submitted.clear();
}
