#pragma once
// android_clipboard.h -- verbindet ImGuis Clipboard-Callbacks mit dem
// Android-ClipboardManager (JNI). Damit funktioniert "Einfuegen" aus
// GBoard/System-Zwischenablage in ImGui-Eingabefeldern (z.B. X-Login).
#if defined(__ANDROID__)
#include <android_native_app_glue.h>
#include <jni.h>
#include <string>
#include "imgui.h"

namespace AndroidClipboard {
inline android_app* g_app = nullptr;
inline std::string  g_text;

struct JniEnvGuard {
    JNIEnv* env = nullptr; bool attached = false;
    JniEnvGuard() {
        JavaVM* vm = g_app->activity->vm;
        if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
            vm->AttachCurrentThread(&env, nullptr); attached = true;
        }
    }
    ~JniEnvGuard() { if (attached) g_app->activity->vm->DetachCurrentThread(); }
};

inline jobject GetClipboardManager(JNIEnv* e) {
    jobject act = g_app->activity->clazz;
    jclass cAct = e->GetObjectClass(act);
    jmethodID mGss = e->GetMethodID(cAct, "getSystemService",
        "(Ljava/lang/String;)Ljava/lang/Object;");
    jstring svc = e->NewStringUTF("clipboard");
    jobject mgr = e->CallObjectMethod(act, mGss, svc);
    e->DeleteLocalRef(svc); e->DeleteLocalRef(cAct);
    return mgr;
}

inline const char* GetTextFn(ImGuiContext*) {
    JniEnvGuard j; JNIEnv* e = j.env;
    g_text.clear();
    jobject mgr = GetClipboardManager(e);
    if (!mgr) return "";
    jclass cMgr = e->GetObjectClass(mgr);
    jmethodID mClip = e->GetMethodID(cMgr, "getPrimaryClip",
        "()Landroid/content/ClipData;");
    jobject clip = e->CallObjectMethod(mgr, mClip);
    if (clip) {
        jclass cClip = e->GetObjectClass(clip);
        jmethodID mCnt = e->GetMethodID(cClip, "getItemCount", "()I");
        if (e->CallIntMethod(clip, mCnt) > 0) {
            jmethodID mAt = e->GetMethodID(cClip, "getItemAt",
                "(I)Landroid/content/ClipData$Item;");
            jobject item = e->CallObjectMethod(clip, mAt, 0);
            jclass cItem = e->GetObjectClass(item);
            jmethodID mTxt = e->GetMethodID(cItem, "coerceToText",
                "(Landroid/content/Context;)Ljava/lang/CharSequence;");
            jobject cs = e->CallObjectMethod(item, mTxt, g_app->activity->clazz);
            if (cs) {
                jclass cCs = e->GetObjectClass(cs);
                jmethodID mStr = e->GetMethodID(cCs, "toString",
                    "()Ljava/lang/String;");
                jstring js = (jstring)e->CallObjectMethod(cs, mStr);
                const char* u = e->GetStringUTFChars(js, nullptr);
                if (u) { g_text = u; e->ReleaseStringUTFChars(js, u); }
            }
        }
    }
    return g_text.c_str();
}

inline void SetTextFn(ImGuiContext*, const char* text) {
    JniEnvGuard j; JNIEnv* e = j.env;
    jobject mgr = GetClipboardManager(e);
    if (!mgr) return;
    jclass cCd = e->FindClass("android/content/ClipData");
    jmethodID mNew = e->GetStaticMethodID(cCd, "newPlainText",
        "(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;");
    jstring lbl = e->NewStringUTF("xbm"); jstring val = e->NewStringUTF(text);
    jobject clip = e->CallStaticObjectMethod(cCd, mNew, lbl, val);
    jclass cMgr = e->GetObjectClass(mgr);
    jmethodID mSet = e->GetMethodID(cMgr, "setPrimaryClip",
        "(Landroid/content/ClipData;)V");
    e->CallVoidMethod(mgr, mSet, clip);
}

inline void Install(android_app* app) {
    g_app = app;
    ImGuiPlatformIO& pio = ImGui::GetPlatformIO();
    pio.Platform_GetClipboardTextFn = GetTextFn;
    pio.Platform_SetClipboardTextFn = SetTextFn;
}
} // namespace AndroidClipboard
#endif
