// ---------------------------------------------------------------------------
// bookmark_sources.cpp -- X, Reddit, Facebook hinter EINER Schnittstelle.
// ---------------------------------------------------------------------------
#include "bookmark_source.h"
#include "x_client.h"
#include "xbm_http.h"

#include <nlohmann/json.hpp>
#include <cstring>
#include <stdexcept>

using json = nlohmann::json;

// ===========================================================================
// X -- Adapter ueber den vorhandenen XClient. Kein neuer Code fuer X.
// ===========================================================================
namespace {
class XSource : public BookmarkSource {
    std::unique_ptr<XClient> cli_;
public:
    const char* Name() const override { return "X"; }
    const char* Slug() const override { return "x"; }
    std::vector<LoginField> LoginFields() const override {
        return { {"auth_token", "auth_token", true}, {"ct0", "ct0", true} };
    }
    bool Login(const std::map<std::string, std::string>& w, std::string& fehler) override {
        auto a = w.find("auth_token"), c = w.find("ct0");
        if (a == w.end() || c == w.end() || a->second.empty() || c->second.empty()) {
            fehler = "auth_token und ct0 werden gebraucht"; return false;
        }
        auto cli = std::make_unique<XClient>(a->second, c->second);
        if (!cli->verify_credentials()) { fehler = "Cookies gelten nicht (kein 200)"; return false; }
        cli_ = std::move(cli);
        return true;
    }
    bool LoggedIn() const override { return (bool)cli_; }
    void Logout() override { cli_.reset(); }
    void FetchAll(const std::function<void(const std::vector<BookmarkEntry>&)>& on_page,
                  const std::function<bool()>& should_stop) override {
        if (!cli_) throw std::runtime_error("nicht angemeldet");
        cli_->fetch_all_bookmarks([&](const std::vector<Tweet>& seite) {
            std::vector<BookmarkEntry> aus;
            aus.reserve(seite.size());
            for (auto& t : seite)
                aus.push_back({t.id, "@" + t.author_handle, t.text, t.url, t.created_at});
            on_page(aus);
        }, should_stop);
    }
    bool Remove(const std::string& id) override {
        return cli_ && cli_->delete_bookmark(id);
    }
};
} // namespace
std::unique_ptr<BookmarkSource> MakeXSource() { return std::make_unique<XSource>(); }

// ===========================================================================
// REDDIT -- gespeicherte Beitraege ueber die JSON-Endpunkte der Webseite.
// [Braucht nur das Cookie reddit_session. /api/me.json liefert Name und
//  "modhash" (das CSRF-Token fuer Schreibzugriffe). Gespeichertes liegt
//  unter /user/<name>/saved.json, seitenweise ueber "after". Entfernen
//  per POST /api/unsave mit id und uh=modhash.]
// ===========================================================================
namespace {
class RedditSource : public BookmarkSource {
    std::map<std::string, std::string> cookies_;
    std::string name_, modhash_;
    std::string basis_ = "https://www.reddit.com";   // der Host, der ging
    std::string uaName_;                             // fuer den User-Agent
    bool an_ = false;

    // Referer passend zum GERADE benutzten Host -- Reddit prueft das.
    // [Beim Probieren mehrerer Hosts muss der Referer mitwandern; sonst
    //  schickt man old.reddit.com eine Anfrage mit www-Referer, und das
    //  ist genau die Unstimmigkeit, auf die Reddit mit 403 reagiert.]
    std::vector<std::string> kopf(const std::string& host = "") const {
        const std::string h = host.empty() ? basis_ : host;
        // EIGENER, BESCHREIBENDER USER-AGENT.
        // [Das war die Ursache des 403 auf BEIDEN Hosts. Reddit verlangt
        //  von Nicht-Browser-Clients ausdruecklich einen eigenen UA; ein
        //  nachgeahmter Chrome-UA ist dort die schlechteste Wahl, weil
        //  die uebrigen Browser-Merkmale fehlen und Reddit das erkennt.
        //  Form laut Reddit: <platform>:<app>:<version> (by /u/<name>)]
        std::string ua = "User-Agent: xbm:x_bookmark_manager:1.0";
        if (!uaName_.empty()) ua += " (by /u/" + uaName_ + ")";
        return { ua, "Accept: application/json", "Referer: " + h + "/",
                 "Accept-Language: en-US,en;q=0.9" };
    }
public:
    const char* Name() const override { return "Reddit"; }
    const char* Slug() const override { return "reddit"; }
    const char* Hint() const override {
        return "Cookies aus dem Browser: F12 > Application > Cookies > "
               "reddit.com (reddit_session, token_v2). Den Reddit-Namen "
               "eintragen -- Reddit verlangt einen eigenen User-Agent und "
               "antwortet sonst mit 403.";
    }
    std::vector<LoginField> LoginFields() const override {
        // [reddit_session allein genuegt nicht mehr -- Reddit antwortet
        //  dann mit 403. token_v2 ist das Sitzungstoken der neuen
        //  Oberflaeche; loid/edgebucket sind harmlose Kennungen, die
        //  Reddit aber bei "unbekannten" Anfragen vermisst. Alle ausser
        //  reddit_session sind optional -- leere Felder werden nicht
        //  mitgeschickt.]
        return { {"reddit_session", "reddit_session", true},
                 {"token_v2",       "token_v2", true},
                 {"user",           "Reddit-Name (fuer den User-Agent)", false},
                 {"loid",           "loid (optional)", false},
                 {"edgebucket",     "edgebucket (optional)", false} };
    }
    bool Login(const std::map<std::string, std::string>& w, std::string& fehler) override {
        auto s = w.find("reddit_session");
        if (s == w.end() || s->second.empty()) {
            fehler = "reddit_session wird gebraucht"; return false;
        }
        cookies_.clear();
        cookies_["reddit_session"] = s->second;
        // Optionale Cookies nur, wenn gefuellt.
        for (const char* k : { "token_v2", "loid", "edgebucket" }) {
            auto it = w.find(k);
            if (it != w.end() && !it->second.empty()) cookies_[k] = it->second;
        }
        { auto it = w.find("user"); uaName_ = (it != w.end()) ? it->second : ""; }

        // MEHRERE WEGE DER REIHE NACH.
        // [old.reddit.com filtert deutlich weniger als www -- dort
        //  funktioniert derselbe Endpunkt oft, wenn www mit 403
        //  antwortet. Wir probieren beide und melden am Ende, WAS jeder
        //  gesagt hat, statt nur "403".]
        const char* hosts[] = { "https://www.reddit.com",
                                "https://old.reddit.com" };
        std::string berichte;
        for (const char* h : hosts) {
            auto a = XbmHttp("GET", std::string(h) + "/api/me.json",
                             cookies_, kopf(h));
            if (!a.fehler.empty()) {
                berichte += std::string(h) + ": Netz " + a.fehler + "\n";
                continue;
            }
            if (a.status == 200) {
                try {
                    auto j = json::parse(a.body);
                    if (!j.contains("data") || !j["data"].contains("name")) {
                        berichte += std::string(h) + ": 200, aber nicht angemeldet\n";
                        continue;
                    }
                    name_    = j["data"]["name"].get<std::string>();
                    modhash_ = j["data"].value("modhash", "");
                    basis_   = h;          // diesen Host weiter benutzen
                    an_ = true;
                    return true;
                } catch (const std::exception& e) {
                    berichte += std::string(h) + ": Antwort unlesbar ("
                              + e.what() + ")\n";
                    continue;
                }
            }
            // DEN ANTWORTKOERPER MITZEIGEN -- Reddit schreibt dort meist
            // selbst hinein, was los ist ("Blocked", CDN-Sperrseite).
            std::string aus = a.body.substr(0, 160);
            for (auto& c : aus) if (c == '\n' || c == '\r') c = ' ';
            berichte += std::string(h) + ": HTTP " + std::to_string(a.status);
            if (!aus.empty()) berichte += "  [" + aus + "]";
            berichte += "\n";
        }
        // GRUND NENNEN, nicht nur die Zahl.
        fehler = berichte;
        if (berichte.find("403") != std::string::npos) {
            fehler += "403: Reddit verlangt einen EIGENEN User-Agent. Trag "
                      "deinen Reddit-Namen in das Feld \"Reddit-Name\" ein "
                      "-- der UA lautet dann xbm:x_bookmark_manager:1.0 "
                      "(by /u/<name>). Bleibt es bei 403, sagt der Text in "
                      "eckigen Klammern oben, was Reddit blockiert.";
        } else if (berichte.find("HTTP 401") != std::string::npos) {
            fehler += "401: das Cookie ist abgelaufen -- im Browser neu kopieren.";
        } else if (berichte.find("429") != std::string::npos) {
            fehler += "429: zu viele Anfragen. Ein paar Minuten warten.";
        }
        return false;
    }
    bool LoggedIn() const override { return an_; }
    void Logout() override {
        an_ = false; cookies_.clear(); name_.clear(); modhash_.clear();
        basis_ = "https://www.reddit.com";
    }

    void FetchAll(const std::function<void(const std::vector<BookmarkEntry>&)>& on_page,
                  const std::function<bool()>& should_stop) override {
        if (!an_) throw std::runtime_error("nicht angemeldet");
        std::string after;
        for (int seite = 0; seite < 200; ++seite) {
            if (should_stop()) return;
            std::string url = basis_ + "/user/" + name_ +
                              "/saved.json?limit=100&raw_json=1";
            if (!after.empty()) url += "&after=" + after;
            auto a = XbmHttp("GET", url, cookies_, kopf());
            if (!a.fehler.empty()) throw std::runtime_error("Netz: " + a.fehler);
            if (a.status != 200) throw std::runtime_error("HTTP " + std::to_string(a.status));
            auto j = json::parse(a.body);
            std::vector<BookmarkEntry> aus;
            for (auto& kind : j["data"]["children"]) {
                auto& d = kind["data"];
                BookmarkEntry e;
                e.id = d.value("name", "");                    // "t3_xxx" / "t1_xxx"
                e.author = "u/" + d.value("author", "?");
                // Beitrag: Titel; Kommentar: Text
                if (d.contains("title")) e.text = d["title"].get<std::string>();
                else                     e.text = d.value("body", "");
                std::string sub = d.value("subreddit_name_prefixed", "");
                if (!sub.empty()) e.text = "[" + sub + "] " + e.text;
                e.url = "https://www.reddit.com" + d.value("permalink", "/");
                e.created = std::to_string((long long)d.value("created_utc", 0.0));
                if (!e.id.empty()) aus.push_back(e);
            }
            on_page(aus);
            // "after" ist auf der LETZTEN Seite null, kein leerer String --
            // value("after","") wirft dann type_error. Erst pruefen.
            const auto& na = j["data"]["after"];
            after = na.is_string() ? na.get<std::string>() : std::string();
            if (after.empty() || aus.empty()) break;
        }
    }
    bool Remove(const std::string& id) override {
        if (!an_) return false;
        std::string body = "id=" + XbmUrlEncode(id) + "&uh=" + XbmUrlEncode(modhash_);
        auto k = kopf();
        k.push_back("Content-Type: application/x-www-form-urlencoded");
        if (!modhash_.empty()) k.push_back("X-Modhash: " + modhash_);
        auto a = XbmHttp("POST", basis_ + "/api/unsave", cookies_, k, body);
        return a.fehler.empty() && a.status == 200;
    }
};
} // namespace
std::unique_ptr<BookmarkSource> MakeRedditSource() { return std::make_unique<RedditSource>(); }

// ===========================================================================
// FACEBOOK -- EXPERIMENTELL.
// [Facebook hat keine oeffentliche Schnittstelle fuer gespeicherte
//  Beitraege. Der Weg fuehrt ueber die interne GraphQL-Schnittstelle der
//  Webseite: Cookies c_user + xs, dazu das Token fb_dtsg aus dem HTML.
//  Die Abfrage-Kennung (doc_id) fuer "gespeicherte Beitraege" aendert
//  Facebook regelmaessig -- deshalb ist sie hier einstellbar statt fest.
//  Login und Pruefung sind solide; das Holen der Liste haengt an dieser
//  Kennung und kann brechen, sobald Facebook seine Seite umbaut.]
// ===========================================================================
namespace {
// Sucht fb_dtsg in allen Schreibweisen, die Facebook benutzt.
static std::string fbTokenSuchen(const std::string& html) {
    struct Muster { const char* anker; const char* schluessel; };
    static const Muster m[] = {
        { "\"DTSGInitialData\"", "\"token\":\"" },
        { "\"DTSGInitData\"",    "\"token\":\"" },   // ohne "ial"
        { "\"dtsg\":",            "\"token\":\"" },
        { "\"async_get_token\"", "\"async_get_token\":\"" },
    };
    for (auto& x : m) {
        auto pos = html.find(x.anker);
        if (pos == std::string::npos) continue;
        auto t = html.find(x.schluessel, pos);
        if (t == std::string::npos) continue;
        t += std::strlen(x.schluessel);
        auto e = html.find('"', t);
        if (e != std::string::npos && e > t) return html.substr(t, e - t);
    }
    // Altes Formularfeld.
    auto t = html.find("name=\"fb_dtsg\" value=\"");
    if (t != std::string::npos) {
        t += 22; auto e = html.find('"', t);
        if (e != std::string::npos) return html.substr(t, e - t);
    }
    return std::string();
}

class FacebookSource : public BookmarkSource {
    std::map<std::string, std::string> cookies_;
    std::string dtsg_, docId_;
    bool an_ = false;
public:
    const char* Name() const override { return "Facebook"; }
    const char* Slug() const override { return "facebook"; }
    const char* Hint() const override {
        return "experimentell: Login funktioniert; das Holen der Liste haengt an der "
               "GraphQL-Kennung (doc_id), die Facebook regelmaessig aendert.";
    }
    std::vector<LoginField> LoginFields() const override {
        return { {"c_user", "c_user", false}, {"xs", "xs", true},
                 {"fb_dtsg", "fb_dtsg (falls nicht gefunden)", true},
                 {"doc_id", "doc_id (GraphQL)", false} };
    }
    bool Login(const std::map<std::string, std::string>& w, std::string& fehler) override {
        auto c = w.find("c_user"), x = w.find("xs");
        if (c == w.end() || x == w.end() || c->second.empty() || x->second.empty()) {
            fehler = "c_user und xs werden gebraucht"; return false;
        }
        cookies_ = { {"c_user", c->second}, {"xs", x->second} };
        auto d = w.find("doc_id"); if (d != w.end()) docId_ = d->second;
        // Pruefen: /me ohne Weiterleitung zum Login, und fb_dtsg einsammeln.
        auto a = XbmHttp("GET", "https://www.facebook.com/me", cookies_,
                         { "Accept: text/html", "Accept-Language: en-US,en;q=0.9" });
        if (!a.fehler.empty()) { fehler = "Netz: " + a.fehler; return false; }
        // ANGEMELDET heisst: keine Weiterleitung zur Login-Seite.
        // [Vorher wurde zusaetzlich nach "c_user" oder "fb_dtsg" im HTML
        //  gesucht. Das Token steht aber unter "DTSGInitialData" -- die
        //  Suche nach dem Wort "fb_dtsg" ging ins Leere, und ein gueltiger
        //  Login wurde als abgelaufen gemeldet. Die Weiterleitung ist das
        //  verlaessliche Kennzeichen; das Token wird darunter ohnehin
        //  gesucht, und fehlt es, gibt es eine eigene Meldung.]
        if (a.endgueltigeUrl.find("/login") != std::string::npos ||
            a.endgueltigeUrl.find("login.php") != std::string::npos) {
            fehler = "nicht angemeldet (Cookies abgelaufen?)"; return false;
        }
        // fb_dtsg AUS MEHREREN SCHREIBWEISEN LESEN.
        // [Ich hatte nur zwei geprueft: "DTSGInitialData" und das alte
        //  Formularfeld. Facebook benutzt aber auch "DTSGInitData" (ohne
        //  "ial"!), "dtsg":{"token":...} und async_get_token. Genau
        //  deshalb kam "fb_dtsg nicht gefunden" -- nicht weil das Token
        //  fehlt, sondern weil es anders heisst.]
        dtsg_ = fbTokenSuchen(a.body);
        if (dtsg_.empty()) {
            // Von Hand eingetragen? Dann das nehmen.
            auto it = w.find("fb_dtsg");
            if (it != w.end() && !it->second.empty()) dtsg_ = it->second;
        }
        if (dtsg_.empty()) {
            fehler = "fb_dtsg nicht gefunden. Die Seite kam an ("
                   + std::to_string(a.body.size()) + " Bytes";
            if (a.body.find("login") != std::string::npos)
                fehler += ", enthaelt aber \"login\" -- Cookies pruefen";
            fehler += "). Trag fb_dtsg von Hand ein: im Browser auf "
                      "facebook.com F12 > Console > "
                      "require(\"DTSGInitialData\").token";
            return false;
        }
        an_ = true;
        return true;
    }
    bool LoggedIn() const override { return an_; }
    void Logout() override { an_ = false; cookies_.clear(); dtsg_.clear(); }

    void FetchAll(const std::function<void(const std::vector<BookmarkEntry>&)>& on_page,
                  const std::function<bool()>& should_stop) override {
        if (!an_) throw std::runtime_error("nicht angemeldet");
        if (docId_.empty())
            throw std::runtime_error("keine doc_id eingetragen -- siehe Hinweis im Login-Fenster");
        std::string cursor;
        for (int seite = 0; seite < 100; ++seite) {
            if (should_stop()) return;
            json vars = { {"count", 20}, {"scale", 1} };
            if (!cursor.empty()) vars["cursor"] = cursor;
            std::string body = "fb_dtsg=" + XbmUrlEncode(dtsg_) +
                               "&doc_id=" + XbmUrlEncode(docId_) +
                               "&variables=" + XbmUrlEncode(vars.dump()) +
                               "&server_timestamps=true";
            auto a = XbmHttp("POST", "https://www.facebook.com/api/graphql/", cookies_,
                             { "Content-Type: application/x-www-form-urlencoded",
                               "X-FB-Friendly-Name: SavedDashboardQuery" }, body);
            if (!a.fehler.empty()) throw std::runtime_error("Netz: " + a.fehler);
            if (a.status != 200) throw std::runtime_error("HTTP " + std::to_string(a.status));
            json j;
            try { j = json::parse(a.body); }
            catch (...) { throw std::runtime_error("Antwort ist kein JSON -- doc_id veraltet?"); }
            if (j.contains("errors")) throw std::runtime_error("GraphQL-Fehler: " + j["errors"].dump().substr(0, 200));
            // Die Form der Antwort haengt an der doc_id. Wir suchen
            // tolerant nach Knoten mit id + (title|message) + url.
            std::vector<BookmarkEntry> aus;
            std::function<void(const json&)> suche = [&](const json& n) {
                if (n.is_object()) {
                    if (n.contains("id") && (n.contains("title") || n.contains("message")) ) {
                        BookmarkEntry e;
                        e.id = n["id"].is_string() ? n["id"].get<std::string>() : n["id"].dump();
                        if (n.contains("title") && n["title"].is_object() && n["title"].contains("text"))
                            e.text = n["title"]["text"].get<std::string>();
                        else if (n.contains("title") && n["title"].is_string())
                            e.text = n["title"].get<std::string>();
                        else if (n.contains("message") && n["message"].is_object() && n["message"].contains("text"))
                            e.text = n["message"]["text"].get<std::string>();
                        if (n.contains("url") && n["url"].is_string()) e.url = n["url"].get<std::string>();
                        if (n.contains("owner") && n["owner"].is_object() && n["owner"].contains("name"))
                            e.author = n["owner"]["name"].get<std::string>();
                        if (!e.text.empty()) aus.push_back(e);
                    }
                    for (auto& kv : n.items()) suche(kv.value());
                } else if (n.is_array()) {
                    for (auto& v : n) suche(v);
                }
            };
            suche(j);
            on_page(aus);
            // Cursor tolerant suchen.
            std::string neu;
            std::function<void(const json&)> cur = [&](const json& n) {
                if (!neu.empty()) return;
                if (n.is_object()) {
                    if (n.contains("page_info") && n["page_info"].is_object()) {
                        auto& p = n["page_info"];
                        if (p.value("has_next_page", false) && p.contains("end_cursor") && p["end_cursor"].is_string())
                            neu = p["end_cursor"].get<std::string>();
                    }
                    for (auto& kv : n.items()) cur(kv.value());
                } else if (n.is_array()) for (auto& v : n) cur(v);
            };
            cur(j);
            if (neu.empty() || neu == cursor || aus.empty()) break;
            cursor = neu;
        }
    }
    bool Remove(const std::string& id) override {
        // Entfernen braucht eine weitere, ebenfalls wechselnde doc_id.
        // Ehrlicher, es nicht vorzutaeuschen.
        (void)id;
        return false;
    }
};
} // namespace
std::unique_ptr<BookmarkSource> MakeFacebookSource() { return std::make_unique<FacebookSource>(); }
