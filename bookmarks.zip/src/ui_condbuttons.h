#pragma once
// ---------------------------------------------------------------------------
// ui_condbuttons.h -- Knoepfe, die nur unter einer Bedingung erscheinen.
//
// Bisher war jeder Knopf fest dort verdrahtet, wo er gezeichnet wird. Wollte
// man einen Knopf nur zeigen, wenn ein bestimmtes Fenster sichtbar ist,
// musste die Leiste dieses Fenster kennen. Das skaliert nicht und ist der
// Grund, warum der Memo-Knopf in der Kalender-Werkzeugleiste festhing statt
// in der Leiste zu stehen, in die er gehoert.
//
// Hier meldet sich stattdessen jeder Knopf SELBST an und bringt seine
// Bedingung mit. Die Leiste zeichnet nur noch, was gerade zutrifft, und
// muss von den Knoepfen nichts wissen.
//
// DREI BEDINGUNGSARTEN (wie gewuenscht):
//   OnPage       -- die genannte Seite ist aktiv
//   WindowShown  -- das genannte Fenster ist auf der aktiven Seite sichtbar
//   WindowActive -- das genannte Fenster hat den Fokus
//   AlwaysShown  -- immer
//   Custom       -- beliebiges Praedikat
//
// Fenster werden ueber ihren UNGESCOPTEN Namen angegeben ("Kalender").
// Das Seitensystem haengt intern "##<Seite>" oder "###<id>" an; darum
// kuemmert sich dieses Modul.
// ---------------------------------------------------------------------------
#include "imgui.h"
#include "imgui_internal.h"

#include <cstdio>
#include <cstring>

#include <functional>
#include <string>
#include <vector>

// Gestenordnung (wie bei Kalender, Scrubber, Kopfzeile).
// INLINE-VARIABLE (C++17): existiert genau einmal, egal wie oft der
// Header eingebunden wird -- ohne eigene .cpp.
inline void (*UiCondButtons_ClaimGesture)() = nullptr;

// ACHTUNG BEI NAMEN IN DIESER AUFZAEHLUNG:
// Der erste Eintrag hiess "Always" -- und genau das ist auf Linux ein
// X11-MAKRO:  /usr/include/X11/X.h:441:  #define Always 2
// Ueber glfw3native.h (GLFW_EXPOSE_NATIVE_X11) landet X.h in main.cpp,
// und der Praeprozessor machte aus der Aufzaehlung
//     enum class UiCondKind { 2, OnPage, ... };
//   -> "expected identifier before numeric constant"
// Auf Android und Windows gibt es kein X11, deshalb fiel es dort nicht
// auf. Weitere heikle X11-Namen, die man hier NICHT verwenden darf:
// None, Success, Above, Below, Complex, Convex, Bool, Status, Window,
// Display, Screen, Cursor, Font, KeyPress, KeyRelease.
enum class UiCondKind { AlwaysShown, OnPage, WindowShown, WindowActive, Custom };

struct UiCondButton {
    std::string id;                 // eindeutig, z.B. "kalender.memo"
    std::string tooltip;
    UiCondKind  kind   = UiCondKind::AlwaysShown;
    std::string target;             // Seiten- bzw. Fenstername
    std::function<bool()> custom;   // nur bei Custom

    // Zeichnet das Symbol in das Quadrat (a..b). Bewusst selbst zeichnen
    // statt Zeichensatz-Symbole: die App laedt je nach Plattform
    // unterschiedliche Schriften, ein Symbolzeichen waere mal da und mal
    // ein Kaestchen.
    std::function<void(ImDrawList*, ImVec2 a, ImVec2 b, ImU32 col)> icon;

    // Genau EINES von beiden:
    std::function<void()> onClick;  // normaler Knopf
    // Halte-Knopf: laeuft, solange gedrueckt. Fuer Aufnahmen gedacht.
    std::function<void(bool held)> onHold;

    // Optional: true faerbt den Knopf als "aktiv" ein (z.B. Aufnahme laeuft).
    std::function<bool()> lit;
};

// Anmelden bzw. ersetzen (gleiche id ueberschreibt).
// ---------------------------------------------------------------------------
// AB HIER DIE IMPLEMENTIERUNG -- das Modul ist HEADER-ONLY.
//
// Es gab hier einmal eine ui_condbuttons.cpp. Die musste in die
// Quellenliste der CMakeLists eingetragen werden, und genau das ging
// schief: Linux und Windows brachen beim Linken ab
//     undefined reference to `UiCondButtons_Register(UiCondButton const&)'
// und Android linkte die .so KLAGLOS und stuerzte erst beim Start:
//     dlopen failed: cannot locate symbol "UiCondButtons_ClaimGesture"
// (gemeinsame Bibliotheken duerfen offene Symbole enthalten -- der Fehler
//  faellt dort erst zur Laufzeit auf).
//
// Header-only nimmt diese Fehlerquelle ganz weg: Datei einbinden genuegt,
// nichts ist am Buildsystem zu aendern. Der Umfang rechtfertigt keine
// eigene Uebersetzungseinheit.
//
// Alles ist inline; Zustand liegt in Funktions-statics bzw. als inline-
// Variable (C++17), damit es bei mehrfacher Einbindung genau EINMAL
// existiert.
// ---------------------------------------------------------------------------


// EIGENER, BENANNTER Namensraum -- NICHT anonym.
// [Hier stand "namespace { ... }". In einer .cpp ist das richtig, in
//  einem Header ist es fatal: ein anonymer Namensraum hat INTERNE
//  Bindung, jede Uebersetzungseinheit bekommt also ihre EIGENE Liste und
//  ihre eigene aktive Seite. Ein in ui_pages.cpp angemeldeter Knopf war
//  in ui_navi.h schlicht nicht vorhanden -- der Mikrofon-Knopf waere nie
//  erschienen, ohne dass irgendetwas gemeldet haette. Genau das hat der
//  Zwei-Einheiten-Test gezeigt: "sichtbar: 0" statt 1.]
namespace xbm_condbtn_detail {

// Zustand in Funktions-statics: bei inline-Funktionen fasst der Linker
// die zusammen, es gibt also GENAU EINE Liste im ganzen Programm.
inline std::vector<UiCondButton>& List() {
    static std::vector<UiCondButton> v; return v;
}
inline std::string& ActivePage() { static std::string s; return s; }

inline void Claim() { if (UiCondButtons_ClaimGesture) UiCondButtons_ClaimGesture(); }

// Fenster anhand des UNGESCOPTEN Namens finden.
// Das Seitensystem haengt "##<Seite>" bzw. "###<id>" an; ein einfacher
// Namensvergleich ginge deshalb ins Leere.
inline ImGuiWindow* FindByBase(const std::string& base) {
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g || base.empty()) return nullptr;
    // Zusaetzlich gesucht: "###" + base IRGENDWO im Namen (nicht nur am
    // Anfang). [Der Kalender setzt seinen Fenstertitel dynamisch auf
    // die aktuelle Datumsbeschriftung ("12.09. - 18.09.###Kalender")
    // -- die ID-tragende Kennung "###Kalender" steht dort NICHT mehr am
    // ANFANG des Namens, sondern dahinter. Der reine Praefix-Vergleich
    // unten fand das Fenster dadurch nicht mehr, und die davon
    // abhaengigen Knoepfe (Notiz+, Mikrofon, Stift) verschwanden
    // komplett aus der rechten Leiste.]
    const std::string suffix = "###" + base;
    for (ImGuiWindow* w : g->Windows) {
        const char* n = w->Name;
        if (base == n) return w;
        if (std::strncmp(n, base.c_str(), base.size()) == 0
            && n[base.size()] == '#')
            return w;
        const size_t nLen = std::strlen(n);
        if (nLen >= suffix.size()
            && std::strcmp(n + (nLen - suffix.size()), suffix.c_str()) == 0)
            return w;
    }
    return nullptr;
}

inline bool Matches(const UiCondButton& b) {
    switch (b.kind) {
        case UiCondKind::AlwaysShown: return true;
        case UiCondKind::OnPage: return xbm_condbtn_detail::ActivePage() == b.target;
        case UiCondKind::WindowShown: {
            ImGuiWindow* w = FindByBase(b.target);
            // WasActive + !Hidden ist der ehrliche Sichtbarkeitsbegriff:
            // Begin() lief UND das Fenster wurde nicht verworfen (nicht
            // eingeklappt, nicht auf einem inaktiven Tab).
            return w && w->WasActive && !w->Hidden;
        }
        case UiCondKind::WindowActive: {
            ImGuiContext* g = ImGui::GetCurrentContext();
            ImGuiWindow* w = FindByBase(b.target);
            if (!g || !w || !g->NavWindow) return false;
            // Ueber den Dock-Baum vergleichen: ein angedocktes Fenster
            // gilt als aktiv, wenn sein Komplex den Fokus hat.
            return g->NavWindow->RootWindowDockTree == w->RootWindowDockTree;
        }
        case UiCondKind::Custom: return b.custom && b.custom();
    }
    return false;
}

// Ein Knopf. Liefert true bei Klick (bei Halte-Knoepfen immer false --
// die melden ueber onHold).
inline bool Draw(const UiCondButton& b, ImVec2 a, float box) {
    const ImVec2 bb(a.x + box, a.y + box);
    ImGui::SetCursorScreenPos(a);
    ImGui::PushID(b.id.c_str());
    ImGui::InvisibleButton("##cb", ImVec2(box, box));
    const bool hov = ImGui::IsItemHovered();
    const bool act = ImGui::IsItemActive();
    const bool clk = ImGui::IsItemDeactivated() && hov && !b.onHold;
    if (act) Claim();

    ImDrawList* dl = ImGui::GetWindowDrawList();
    const bool on = b.lit && b.lit();
    ImU32 bg = IM_COL32(0, 0, 0, 0);
    if (on)        bg = IM_COL32(200, 50, 50, 235);
    else if (act)  bg = ImGui::GetColorU32(ImGuiCol_ButtonActive);
    else if (hov)  bg = ImGui::GetColorU32(ImGuiCol_ButtonHovered);
    if (bg) dl->AddRectFilled(a, bb, bg, box * 0.18f);

    const ImU32 col = on ? IM_COL32(255, 255, 255, 255)
                         : ImGui::GetColorU32(ImGuiCol_Text);
    if (b.icon) b.icon(dl, a, bb, col);

    if (hov && !b.tooltip.empty()) ImGui::SetTooltip("%s", b.tooltip.c_str());
    if (b.onHold) b.onHold(act);
    ImGui::PopID();
    return clk;
}

}  // namespace xbm_condbtn_detail

inline void UiCondButtons_Register(const UiCondButton& b) {
    for (auto& e : xbm_condbtn_detail::List()) if (e.id == b.id) { e = b; return; }
    xbm_condbtn_detail::List().push_back(b);
}
inline void UiCondButtons_Remove(const std::string& id) {
    for (auto it = xbm_condbtn_detail::List().begin(); it != xbm_condbtn_detail::List().end(); ++it)
        if (it->id == id) { xbm_condbtn_detail::List().erase(it); return; }
}
inline void UiCondButtons_Clear() { xbm_condbtn_detail::List().clear(); }
inline void UiCondButtons_SetActivePage(const std::string& p) { xbm_condbtn_detail::ActivePage() = p; }

inline int UiCondButtons_VisibleCount() {
    int n = 0;
    for (const auto& b : xbm_condbtn_detail::List()) if (xbm_condbtn_detail::Matches(b)) ++n;
    return n;
}

inline float UiCondButtons_DrawColumn(ImVec2 topRight, float box) {
    float y = topRight.y;
    for (const auto& b : xbm_condbtn_detail::List()) {
        if (!xbm_condbtn_detail::Matches(b)) continue;
        if (xbm_condbtn_detail::Draw(b, ImVec2(topRight.x - box, y), box) && b.onClick) b.onClick();
        y += box + 2.0f;
    }
    return y - topRight.y;
}

inline float UiCondButtons_DrawRow(ImVec2 topRight, float box) {
    float x = topRight.x;
    for (const auto& b : xbm_condbtn_detail::List()) {
        if (!xbm_condbtn_detail::Matches(b)) continue;
        x -= box;
        if (xbm_condbtn_detail::Draw(b, ImVec2(x, topRight.y), box) && b.onClick) b.onClick();
        x -= 2.0f;
    }
    return topRight.x - x;
}

// ---------------------------------------------------------------------------
inline void UiCondIcon_Note(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col) {
    // Ein Blatt mit zwei Linien -- "einfache Notiz", bewusst schlichter
    // als das Mikrofon-Symbol, damit man beide auf einen Blick trennt.
    const float w = b.x - a.x;
    const float pad = w * 0.22f;
    ImVec2 p0(a.x + pad, a.y + pad * 0.7f), p1(b.x - pad, b.y - pad * 0.7f);
    dl->AddRect(p0, p1, col, w * 0.06f, 0, ImMax(1.5f, w * 0.07f));
    const float lineY1 = p0.y + (p1.y - p0.y) * 0.40f;
    const float lineY2 = p0.y + (p1.y - p0.y) * 0.62f;
    dl->AddLine(ImVec2(p0.x + pad * 0.3f, lineY1), ImVec2(p1.x - pad * 0.3f, lineY1),
               col, ImMax(1.2f, w * 0.05f));
    dl->AddLine(ImVec2(p0.x + pad * 0.3f, lineY2), ImVec2(p1.x - pad * 0.55f, lineY2),
               col, ImMax(1.2f, w * 0.05f));
    // "+" oben rechts -- Anlegen statt nur Anzeigen.
    const float pr = w * 0.16f;
    ImVec2 pc(p1.x - pr * 0.2f, p0.y - pr * 0.3f);
    dl->AddLine(ImVec2(pc.x - pr, pc.y), ImVec2(pc.x + pr, pc.y), col, ImMax(1.5f, w * 0.07f));
    dl->AddLine(ImVec2(pc.x, pc.y - pr), ImVec2(pc.x, pc.y + pr), col, ImMax(1.5f, w * 0.07f));
}

inline void UiCondIcon_ClearSel(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col) {
    // Ein Kreis (die "Auswahl") mit einem durchstreichenden Schraeg-
    // strich -- lesbar als "diese Auswahl aufheben".
    const float w = b.x - a.x, h = b.y - a.y;
    const ImVec2 c(a.x + w * 0.5f, a.y + h * 0.5f);
    const float r = w * 0.30f;
    dl->AddCircle(c, r, col, 20, ImMax(1.5f, w * 0.07f));
    dl->AddLine(ImVec2(c.x - r * 0.85f, c.y + r * 0.85f),
               ImVec2(c.x + r * 0.85f, c.y - r * 0.85f), col, ImMax(1.5f, w * 0.08f));
}

inline void UiCondIcon_Pen(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col) {
    // Stift diagonal, Spitze unten links -- das Zeichenwerkzeug fuer den
    // Bulk-Modus im Kalender.
    const float w = b.x - a.x, h = b.y - a.y;
    ImVec2 tip(a.x + w * 0.22f, b.y - h * 0.18f);
    ImVec2 tail(b.x - w * 0.18f, a.y + h * 0.22f);
    dl->AddLine(tip, tail, col, ImMax(2.0f, w * 0.16f));
    // kleine Spitze
    dl->AddTriangleFilled(tip,
                          ImVec2(tip.x + w * 0.10f, tip.y - h * 0.02f),
                          ImVec2(tip.x + w * 0.02f, tip.y - h * 0.10f), col);
}

// ---------------------------------------------------------------------------
inline void UiCondIcon_Mic(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 col) {
    const float w = b.x - a.x, h = b.y - a.y;
    const ImVec2 c(a.x + w * 0.5f, a.y + h * 0.5f);
    const float capW = w * 0.20f, capH = h * 0.26f;
    // Kapsel
    dl->AddRectFilled(ImVec2(c.x - capW, c.y - capH - h * 0.06f),
                      ImVec2(c.x + capW, c.y + capH * 0.35f),
                      col, capW);
    // Buegel
    dl->PathArcTo(ImVec2(c.x, c.y + capH * 0.10f), w * 0.30f,
                  0.0f, 3.14159265f, 16);
    dl->PathStroke(col, 0, ImMax(1.5f, w * 0.07f));
    // Fuss
    dl->AddLine(ImVec2(c.x, c.y + capH * 0.10f + w * 0.30f),
                ImVec2(c.x, b.y - h * 0.16f), col, ImMax(1.5f, w * 0.07f));
    dl->AddLine(ImVec2(c.x - w * 0.16f, b.y - h * 0.16f),
                ImVec2(c.x + w * 0.16f, b.y - h * 0.16f),
                col, ImMax(1.5f, w * 0.07f));
}
