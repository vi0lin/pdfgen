// vk_scenario_spin.cpp
// Scenario 2: 3D cube rotating at constant speed around Z.

#include "vk_scenario_spin.h"
#include "vk_base.h"

#include "spv/spin_vert_spv.h"
#include "spv/spin_frag_spv.h"

#include <chrono>
#include <cstdio>
#include <cmath>
#include <stdexcept>

static constexpr float kDefaultRotSpeed = 1.0f; // radians per second

GLFWwindow* ScenarioSpin::CreateOverlayWindow(int x, int y, int w, int h) {
    glfwWindowHint(GLFW_CLIENT_API,              GLFW_NO_API);
    glfwWindowHint(GLFW_DECORATED,               GLFW_FALSE);
    glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, GLFW_TRUE);
    glfwWindowHint(GLFW_VISIBLE,                 GLFW_TRUE);
    glfwWindowHint(GLFW_FLOATING,                GLFW_FALSE);
    GLFWwindow* win = glfwCreateWindow(w, h, "ScenarioSpin", nullptr, nullptr);
    if (win) glfwSetWindowPos(win, x, y);
    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_API);
    return win;
}

void ScenarioSpin::Start(GLFWwindow* window) {
    if (running_.exchange(true)) return;
    thread_ = std::thread(&ScenarioSpin::RenderLoop, this, window);
}

void ScenarioSpin::Stop() {
    running_.store(false);
    if (thread_.joinable()) thread_.join();
}

void ScenarioSpin::RenderLoop(GLFWwindow* win) {
    VkBase vk;
    vk.window = win;
    int w, h;
    glfwGetFramebufferSize(win, &w, &h);
    vk.winW = w; vk.winH = h;
    vk.transparent = true;

    VkPipelineLayout layout   = VK_NULL_HANDLE;
    VkPipeline       pipeline = VK_NULL_HANDLE;

    try {
        vk.InitVulkan();

        VkPushConstantRange pc = {};
        pc.stageFlags = VK_SHADER_STAGE_VERTEX_BIT;
        pc.offset     = 0;
        pc.size       = sizeof(float) * 3;

        SpvCode vertSpv{ spin_vert_spv, sizeof(spin_vert_spv) };
        SpvCode fragSpv{ spin_frag_spv, sizeof(spin_frag_spv) };
        vk.CreateSimplePipeline(vertSpv, fragSpv, layout, pipeline,
                                VK_NULL_HANDLE, &pc, 1);

        auto startTime = std::chrono::steady_clock::now();
        float angle    = 0.0f;

        while (running_.load()) {
            if (glfwWindowShouldClose(vk.window)) break;

            float elapsed = std::chrono::duration<float>(
                std::chrono::steady_clock::now() - startTime).count();
            angle = elapsed * kDefaultRotSpeed;

            uint32_t imageIndex = 0;
            if (!vk.BeginFrame(imageIndex)) continue;

            VkCommandBuffer cmd = vk.cmdBuffers[imageIndex];
            vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline);

            struct { float angle; float time; float aspect; } pushData;
            pushData.angle  = angle;
            pushData.time   = elapsed;
            pushData.aspect = (float)vk.swapExtent.height / (float)vk.swapExtent.width;
            vkCmdPushConstants(cmd, layout, VK_SHADER_STAGE_VERTEX_BIT,
                               0, sizeof(pushData), &pushData);

            vkCmdDraw(cmd, 36, 1, 0, 0);
            vk.EndFrame(imageIndex);
        }
    } catch (const std::exception& e) {
        fprintf(stderr, "ScenarioSpin: exception: %s\n", e.what());
    }

    if (pipeline != VK_NULL_HANDLE) vkDestroyPipeline(vk.device, pipeline, nullptr);
    if (layout   != VK_NULL_HANDLE) vkDestroyPipelineLayout(vk.device, layout, nullptr);
    vk.window = nullptr;
    vk.Destroy();
}
