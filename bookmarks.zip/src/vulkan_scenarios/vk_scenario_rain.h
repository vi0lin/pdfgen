#pragma once
// vk_scenario_rain.h

#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>
#include <thread>
#include <atomic>

class ScenarioRain {
public:
    // MAIN THREAD: create the GLFW window (renamed from CreateWindow to avoid
    // clashing with the Win32 CreateWindow macro on Windows).
    GLFWwindow* CreateOverlayWindow(int x, int y, int w, int h);

    // MAIN THREAD: launch the render thread with the pre-created window.
    void Start(GLFWwindow* window);
    void Stop();
    ~ScenarioRain() { Stop(); }

private:
    void RenderLoop(GLFWwindow* window);
    std::thread      thread_;
    std::atomic_bool running_{false};
};
