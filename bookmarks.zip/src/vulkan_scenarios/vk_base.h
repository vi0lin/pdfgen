#pragma once
// vk_base.h
//
// Shared Vulkan boilerplate for all three overlay scenarios.
// Each scenario owns its own VkBase instance -- no shared Vulkan state
// with the bookmark manager's OpenGL context, no shared state between
// scenarios. Every scenario runs on its own thread with its own
// VkInstance / VkDevice / VkSwapchainKHR.
//
// THREADING RULES (GLFW requires this on X11/macOS):
//   CreateWindow() -- MUST be called from the MAIN thread.
//   InitVulkan()   -- can be called from the render thread.
//   glfwPollEvents() inside the render loop -- also must be main thread
//                     on macOS; on Linux/Windows it is fine on any thread.

#include <vulkan/vulkan.h>
#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>

#include <vector>
#include <string>
#include <stdexcept>
#include <functional>
#include <cstring>

// SPIR-V bytes, loaded from embedded arrays at compile time.
struct SpvCode {
    const uint32_t* data;
    size_t          sizeBytes;
};

struct VkBase {
    // Vulkan handles -- filled by InitVulkan()
    VkInstance               instance       = VK_NULL_HANDLE;
    VkPhysicalDevice         physDevice     = VK_NULL_HANDLE;
    VkDevice                 device         = VK_NULL_HANDLE;
    VkQueue                  graphicsQueue  = VK_NULL_HANDLE;
    VkQueue                  presentQueue   = VK_NULL_HANDLE;
    VkSurfaceKHR             surface        = VK_NULL_HANDLE;
    VkSwapchainKHR           swapchain      = VK_NULL_HANDLE;
    VkFormat                 swapFormat     = VK_FORMAT_UNDEFINED;
    VkExtent2D               swapExtent     = {};
    std::vector<VkImage>     swapImages;
    std::vector<VkImageView> swapViews;
    VkRenderPass             renderPass     = VK_NULL_HANDLE;
    std::vector<VkFramebuffer> framebuffers;
    VkCommandPool            cmdPool        = VK_NULL_HANDLE;
    std::vector<VkCommandBuffer> cmdBuffers;

    // Per-frame sync (double-buffered)
    static constexpr int kMaxFramesInFlight = 2;
    VkSemaphore imageAvailable[kMaxFramesInFlight] = {};
    VkSemaphore renderFinished[kMaxFramesInFlight] = {};
    VkFence     inFlightFences[kMaxFramesInFlight] = {};
    int         currentFrame = 0;

    uint32_t graphicsFamily = 0;
    uint32_t presentFamily  = 0;

    // Set by the scenario before calling InitVulkan()
    GLFWwindow* window      = nullptr;
    int         winW        = 0;
    int         winH        = 0;
    bool        transparent = true;

    // -----------------------------------------------------------------------
    // Call this from the RENDER THREAD after the window is created on the
    // main thread and assigned to this->window / winW / winH / transparent.
    // -----------------------------------------------------------------------
    void InitVulkan();

    // Build a simple graphics pipeline from SPIR-V code.
    void CreateSimplePipeline(
        SpvCode                              vertSpv,
        SpvCode                              fragSpv,
        VkPipelineLayout&                    outLayout,
        VkPipeline&                          outPipeline,
        VkDescriptorSetLayout                descSetLayout = VK_NULL_HANDLE,
        const VkPushConstantRange*           pushConstants = nullptr,
        uint32_t                             pushConstCount = 0
    );

    // Begin a frame: acquire swapchain image, wait for fence, begin render pass.
    // Returns false if swapchain is out of date (skip frame, call RecreateSwapchain).
    bool BeginFrame(uint32_t& outImageIndex);

    // End the frame: end render pass, submit, present.
    void EndFrame(uint32_t imageIndex);

    // Recreate the swapchain after a resize.
    void RecreateSwapchain();

    // Destroy all Vulkan objects and the GLFW window.
    void Destroy();

private:
    void CreateInstance();
    void CreateSurface();
    void PickPhysicalDevice();
    void CreateLogicalDevice();
    void CreateSwapchain();
    void CreateImageViews();
    void CreateRenderPass();
    void CreateFramebuffers();
    void CreateCommandPoolAndBuffers();
    void CreateSyncObjects();
    void CleanupSwapchain();
    VkShaderModule CreateShaderModule(SpvCode spv);
};

