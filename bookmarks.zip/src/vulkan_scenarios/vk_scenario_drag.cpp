// vk_scenario_drag.cpp
// Scenario 3: 3D cube whose rotation speed is set by mouse drag delta.
//
// Architecture:
//   - The Vulkan render loop runs on its own thread.
//   - GLFW's cursor-pos and mouse-button callbacks run on the main thread
//     (GLFW requires all window/event calls from the thread that created
//     the window, but since we call glfwPollEvents on the render thread
//     here, callbacks also fire there -- see note below).
//   - rotSpeed_ is a std::atomic<float>: written by the callback, read
//     by the render loop. No mutex needed.
//
// NOTE: GLFW's documentation says glfwPollEvents() must be called from the
// main thread on most platforms (particularly macOS). To keep this cross-
// platform, the render loop calls glfwPollEvents -- meaning the callbacks
// fire on the render thread, which is fine here since the only shared state
// is the atomic rotSpeed_. On macOS, you may need to move glfwPollEvents
// back to the main thread and use a mutex or queue for the window handle.

#include "vk_scenario_drag.h"
#include "vk_base.h"

#include "spv/spin_vert_spv.h"  // reuse the same shader as scenario 2
#include "spv/spin_frag_spv.h"

#include <chrono>
#include <cstdio>
#include <cmath>
#include <stdexcept>

// Sensitivity: how many radians/sec per pixel of drag
static constexpr float kDragSensitivity = 0.05f;

GLFWwindow* ScenarioDrag::CreateOverlayWindow(int x, int y, int w, int h) {
    glfwWindowHint(GLFW_CLIENT_API,              GLFW_NO_API);
    glfwWindowHint(GLFW_DECORATED,               GLFW_FALSE);
    glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, GLFW_TRUE);
    glfwWindowHint(GLFW_VISIBLE,                 GLFW_TRUE);
    glfwWindowHint(GLFW_FLOATING,                GLFW_FALSE);
    GLFWwindow* win = glfwCreateWindow(w, h, "ScenarioDrag", nullptr, nullptr);
    if (win) glfwSetWindowPos(win, x, y);
    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_API);
    return win;
}

void ScenarioDrag::Start(GLFWwindow* window) {
    if (running_.exchange(true)) return;
    thread_ = std::thread(&ScenarioDrag::RenderLoop, this, window);
}

void ScenarioDrag::Stop() {
    running_.store(false);
    if (thread_.joinable()) thread_.join();
}

void ScenarioDrag::SetDragDelta(float deltaX) {
    float current = rotSpeed_.load();
    rotSpeed_.store(current + deltaX * kDragSensitivity);
}

void ScenarioDrag::GlfwCursorPosCallback(GLFWwindow* win, double xpos, double ypos) {
    auto* self = static_cast<ScenarioDrag*>(glfwGetWindowUserPointer(win));
    if (!self || !self->dragging_) return;
    float deltaX = (float)(xpos - self->lastMouseX_);
    self->lastMouseX_ = xpos;
    deltaX = std::clamp(deltaX, -80.0f, 80.0f);
    self->SetDragDelta(deltaX);
}

void ScenarioDrag::GlfwMouseButtonCallback(GLFWwindow* win, int btn, int action, int mods) {
    (void)mods;
    if (btn != GLFW_MOUSE_BUTTON_LEFT) return;
    auto* self = static_cast<ScenarioDrag*>(glfwGetWindowUserPointer(win));
    if (!self) return;
    if (action == GLFW_PRESS) {
        self->dragging_ = true;
        double xpos, ypos;
        glfwGetCursorPos(win, &xpos, &ypos);
        self->lastMouseX_ = xpos;
    } else if (action == GLFW_RELEASE) {
        self->dragging_ = false;
    }
}

void ScenarioDrag::RenderLoop(GLFWwindow* win) {
    VkBase vk;
    vk.window = win;
    int w, h;
    glfwGetFramebufferSize(win, &w, &h);
    vk.winW = w; vk.winH = h;
    vk.transparent = true;

    glfwSetWindowUserPointer(win, this);
    glfwSetCursorPosCallback(win,   GlfwCursorPosCallback);
    glfwSetMouseButtonCallback(win, GlfwMouseButtonCallback);
    vkWindow_.store(win);

    VkPipelineLayout layout   = VK_NULL_HANDLE;
    VkPipeline       pipeline = VK_NULL_HANDLE;

    try {
        vk.InitVulkan();

        VkPushConstantRange pc = {};
        pc.stageFlags = VK_SHADER_STAGE_VERTEX_BIT;
        pc.offset     = 0;
        pc.size       = sizeof(float) * 3;

        SpvCode vertSpv{ spin_vert_spv, sizeof(spin_vert_spv) };
        SpvCode fragSpv{ spin_frag_spv, sizeof(spin_frag_spv) };
        vk.CreateSimplePipeline(vertSpv, fragSpv, layout, pipeline,
                                VK_NULL_HANDLE, &pc, 1);

        auto   startTime = std::chrono::steady_clock::now();
        auto   lastTime  = startTime;
        float  angle     = 0.0f;

        while (running_.load()) {
            if (glfwWindowShouldClose(vk.window)) break;

            auto  now     = std::chrono::steady_clock::now();
            float elapsed = std::chrono::duration<float>(now - startTime).count();
            float dt      = std::chrono::duration<float>(now - lastTime).count();
            lastTime      = now;

            float speed = rotSpeed_.load();
            angle += speed * dt;

            float damped = speed * (1.0f - 0.5f * dt);
            if (std::abs(damped) < 0.5f) damped = std::copysign(0.5f, damped);
            rotSpeed_.store(damped);

            uint32_t imageIndex = 0;
            if (!vk.BeginFrame(imageIndex)) continue;

            VkCommandBuffer cmd = vk.cmdBuffers[imageIndex];
            vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline);

            struct { float angle; float time; float aspect; } pushData;
            pushData.angle  = angle;
            pushData.time   = elapsed;
            pushData.aspect = (float)vk.swapExtent.height / (float)vk.swapExtent.width;
            vkCmdPushConstants(cmd, layout, VK_SHADER_STAGE_VERTEX_BIT,
                               0, sizeof(pushData), &pushData);

            vkCmdDraw(cmd, 36, 1, 0, 0);
            vk.EndFrame(imageIndex);
        }
    } catch (const std::exception& e) {
        fprintf(stderr, "ScenarioDrag: exception: %s\n", e.what());
    }

    if (pipeline != VK_NULL_HANDLE) vkDestroyPipeline(vk.device, pipeline, nullptr);
    if (layout   != VK_NULL_HANDLE) vkDestroyPipelineLayout(vk.device, layout, nullptr);
    vk.window = nullptr;
    vk.Destroy();
}
