#pragma once
// vk_scenario_drag.h

#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>
#include <thread>
#include <atomic>

class ScenarioDrag {
public:
    GLFWwindow* CreateOverlayWindow(int x, int y, int w, int h);
    void Start(GLFWwindow* window);
    void Stop();
    ~ScenarioDrag() { Stop(); }

    void SetDragDelta(float deltaX);

private:
    void RenderLoop(GLFWwindow* window);
    static void GlfwCursorPosCallback(GLFWwindow* win, double xpos, double ypos);
    static void GlfwMouseButtonCallback(GLFWwindow* win, int btn, int action, int mods);

    std::thread        thread_;
    std::atomic_bool   running_{false};
    std::atomic<float> rotSpeed_{1.0f};
    bool               dragging_   = false;
    double             lastMouseX_ = 0.0;
    std::atomic<GLFWwindow*> vkWindow_{nullptr};
};
