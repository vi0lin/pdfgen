#pragma once
// vk_scenario_spin.h

#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>
#include <thread>
#include <atomic>

class ScenarioSpin {
public:
    GLFWwindow* CreateOverlayWindow(int x, int y, int w, int h);
    void Start(GLFWwindow* window);
    void Stop();
    ~ScenarioSpin() { Stop(); }

private:
    void RenderLoop(GLFWwindow* window);
    std::thread      thread_;
    std::atomic_bool running_{false};
};
