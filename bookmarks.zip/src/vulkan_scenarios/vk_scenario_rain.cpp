// vk_scenario_rain.cpp
#include "vk_scenario_rain.h"
#include "vk_base.h"
#include "spv/rain_vert_spv.h"
#include "spv/rain_frag_spv.h"
#include <chrono>
#include <cstdio>
#include <stdexcept>

GLFWwindow* ScenarioRain::CreateOverlayWindow(int x, int y, int w, int h) {
    // Called on the MAIN THREAD. Just creates the GLFW window with the right
    // hints for a Vulkan transparent overlay. No Vulkan init here.
    glfwWindowHint(GLFW_CLIENT_API,              GLFW_NO_API);
    glfwWindowHint(GLFW_DECORATED,               GLFW_FALSE);
    glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, GLFW_TRUE);
    glfwWindowHint(GLFW_VISIBLE,                 GLFW_TRUE);
    glfwWindowHint(GLFW_FLOATING,                GLFW_FALSE);
    GLFWwindow* win = glfwCreateWindow(w, h, "ScenarioRain", nullptr, nullptr);
    if (win) glfwSetWindowPos(win, x, y);
    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_API); // reset for next window
    return win;
}

void ScenarioRain::Start(GLFWwindow* window) {
    if (running_.exchange(true)) return;
    thread_ = std::thread(&ScenarioRain::RenderLoop, this, window);
}

void ScenarioRain::Stop() {
    running_.store(false);
    if (thread_.joinable()) thread_.join();
}

void ScenarioRain::RenderLoop(GLFWwindow* win) {
    VkBase vk;
    // Window was already created on the main thread -- just assign it.
    vk.window = win;
    int w, h;
    glfwGetFramebufferSize(win, &w, &h);
    vk.winW = w; vk.winH = h;
    vk.transparent = true;

    VkPipelineLayout layout   = VK_NULL_HANDLE;
    VkPipeline       pipeline = VK_NULL_HANDLE;

    try {
        vk.InitVulkan();

        VkPushConstantRange pc = {};
        pc.stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
        pc.offset     = 0;
        pc.size       = sizeof(float) * 2;

        SpvCode vertSpv{ rain_vert_spv, sizeof(rain_vert_spv) };
        SpvCode fragSpv{ rain_frag_spv, sizeof(rain_frag_spv) };
        vk.CreateSimplePipeline(vertSpv, fragSpv, layout, pipeline,
                                VK_NULL_HANDLE, &pc, 1);

        auto startTime = std::chrono::steady_clock::now();

        while (running_.load()) {
            if (glfwWindowShouldClose(vk.window)) break;

            float elapsed = std::chrono::duration<float>(
                std::chrono::steady_clock::now() - startTime).count();

            uint32_t imageIndex = 0;
            if (!vk.BeginFrame(imageIndex)) continue;

            VkCommandBuffer cmd = vk.cmdBuffers[imageIndex];
            vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline);

            struct { float time; float aspect; } pushData;
            pushData.time   = elapsed;
            pushData.aspect = (float)vk.swapExtent.width / (float)vk.swapExtent.height;
            vkCmdPushConstants(cmd, layout, VK_SHADER_STAGE_FRAGMENT_BIT,
                               0, sizeof(pushData), &pushData);

            vkCmdDraw(cmd, 6, 1, 0, 0);
            vk.EndFrame(imageIndex);
        }
    } catch (const std::exception& e) {
        fprintf(stderr, "ScenarioRain: exception: %s\n", e.what());
    }

    if (pipeline != VK_NULL_HANDLE) vkDestroyPipeline(vk.device, pipeline, nullptr);
    if (layout   != VK_NULL_HANDLE) vkDestroyPipelineLayout(vk.device, layout, nullptr);
    // Don't destroy vk.window here -- main thread owns it
    vk.window = nullptr;
    vk.Destroy();
}
