// vk_base.cpp
#include "vk_base.h"

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <set>

#ifdef _WIN32
#define GLFW_EXPOSE_NATIVE_WIN32
#include <GLFW/glfw3native.h>
#include <dwmapi.h>
#pragma comment(lib, "dwmapi.lib")
#elif defined(__linux__)
#define GLFW_EXPOSE_NATIVE_X11
#include <GLFW/glfw3native.h>
#include <X11/extensions/shape.h>
#endif

// ---------------------------------------------------------------------------
// Validation layers (debug builds only)
// ---------------------------------------------------------------------------
#ifdef NDEBUG
static constexpr bool kEnableValidation = false;
#else
static constexpr bool kEnableValidation = true;
#endif

static const char* kValidationLayer = "VK_LAYER_KHRONOS_validation";
static const char* kDeviceExts[]    = { VK_KHR_SWAPCHAIN_EXTENSION_NAME };

// ---------------------------------------------------------------------------
// InitVulkan -- called from the RENDER THREAD after the scenario has
// created the GLFWwindow on the main thread and set this->window/winW/winH
// ---------------------------------------------------------------------------
void VkBase::InitVulkan() {
    CreateInstance();
    CreateSurface();
    PickPhysicalDevice();
    CreateLogicalDevice();
    CreateSwapchain();
    CreateImageViews();
    CreateRenderPass();
    CreateFramebuffers();
    CreateCommandPoolAndBuffers();
    CreateSyncObjects();

#ifdef _WIN32
    if (transparent) {
        HWND hwnd = glfwGetWin32Window(window);
        BOOL compositionEnabled = FALSE;
        DwmIsCompositionEnabled(&compositionEnabled);
        if (compositionEnabled) {
            HRGN region = CreateRectRgn(0, 0, -1, -1);
            DWM_BLURBEHIND bb = {};
            bb.dwFlags = DWM_BB_ENABLE | DWM_BB_BLURREGION;
            bb.hRgnBlur = region;
            bb.fEnable = TRUE;
            DwmEnableBlurBehindWindow(hwnd, &bb);
            DeleteObject(region);
        }
    }
#endif
}

// ---------------------------------------------------------------------------
// CreateInstance
// ---------------------------------------------------------------------------
void VkBase::CreateInstance() {
    bool isTransparent = this->transparent;
    VkApplicationInfo appInfo  = {};
    appInfo.sType              = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    appInfo.pApplicationName   = "XBookmarkOverlay";
    appInfo.applicationVersion = VK_MAKE_VERSION(1,0,0);
    appInfo.pEngineName        = "No Engine";
    appInfo.engineVersion      = VK_MAKE_VERSION(1,0,0);
    appInfo.apiVersion         = VK_API_VERSION_1_0;

    uint32_t glfwExtCount = 0;
    const char** glfwExts = glfwGetRequiredInstanceExtensions(&glfwExtCount);
    std::vector<const char*> exts(glfwExts, glfwExts + glfwExtCount);
    if (kEnableValidation) exts.push_back(VK_EXT_DEBUG_UTILS_EXTENSION_NAME);

    VkInstanceCreateInfo ci = {};
    ci.sType                   = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    ci.pApplicationInfo        = &appInfo;
    ci.enabledExtensionCount   = (uint32_t)exts.size();
    ci.ppEnabledExtensionNames = exts.data();

    if (kEnableValidation) {
        ci.enabledLayerCount   = 1;
        ci.ppEnabledLayerNames = &kValidationLayer;
    }

    if (vkCreateInstance(&ci, nullptr, &instance) != VK_SUCCESS)
        throw std::runtime_error("VkBase: vkCreateInstance failed");
}

// ---------------------------------------------------------------------------
// CreateSurface
// ---------------------------------------------------------------------------
void VkBase::CreateSurface() {
    if (glfwCreateWindowSurface(instance, window, nullptr, &surface) != VK_SUCCESS)
        throw std::runtime_error("VkBase: glfwCreateWindowSurface failed");
}

// ---------------------------------------------------------------------------
// PickPhysicalDevice
// ---------------------------------------------------------------------------
void VkBase::PickPhysicalDevice() {
    uint32_t count = 0;
    vkEnumeratePhysicalDevices(instance, &count, nullptr);
    if (!count) throw std::runtime_error("VkBase: no Vulkan physical devices found");
    std::vector<VkPhysicalDevice> devices(count);
    vkEnumeratePhysicalDevices(instance, &count, devices.data());

    // Pick the first device that has the queues and swapchain extension we need.
    for (auto pd : devices) {
        uint32_t qCount = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(pd, &qCount, nullptr);
        std::vector<VkQueueFamilyProperties> qProps(qCount);
        vkGetPhysicalDeviceQueueFamilyProperties(pd, &qCount, qProps.data());

        int gfx = -1, pres = -1;
        for (uint32_t i = 0; i < qCount; ++i) {
            if (qProps[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) gfx = (int)i;
            VkBool32 supported = VK_FALSE;
            vkGetPhysicalDeviceSurfaceSupportKHR(pd, i, surface, &supported);
            if (supported) pres = (int)i;
        }

        // Check swapchain extension
        uint32_t extCount = 0;
        vkEnumerateDeviceExtensionProperties(pd, nullptr, &extCount, nullptr);
        std::vector<VkExtensionProperties> extProps(extCount);
        vkEnumerateDeviceExtensionProperties(pd, nullptr, &extCount, extProps.data());
        bool hasSwapchain = false;
        for (auto& ep : extProps)
            if (strcmp(ep.extensionName, VK_KHR_SWAPCHAIN_EXTENSION_NAME) == 0) hasSwapchain = true;

        if (gfx >= 0 && pres >= 0 && hasSwapchain) {
            physDevice     = pd;
            graphicsFamily = (uint32_t)gfx;
            presentFamily  = (uint32_t)pres;
            return;
        }
    }
    throw std::runtime_error("VkBase: no suitable Vulkan physical device found");
}

// ---------------------------------------------------------------------------
// CreateLogicalDevice
// ---------------------------------------------------------------------------
void VkBase::CreateLogicalDevice() {
    std::set<uint32_t> uniqueQueueFamilies = { graphicsFamily, presentFamily };
    std::vector<VkDeviceQueueCreateInfo> queueCIs;
    float priority = 1.0f;
    for (uint32_t qf : uniqueQueueFamilies) {
        VkDeviceQueueCreateInfo qi = {};
        qi.sType            = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
        qi.queueFamilyIndex = qf;
        qi.queueCount       = 1;
        qi.pQueuePriorities = &priority;
        queueCIs.push_back(qi);
    }

    VkPhysicalDeviceFeatures features = {};
    VkDeviceCreateInfo ci = {};
    ci.sType                   = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
    ci.pQueueCreateInfos       = queueCIs.data();
    ci.queueCreateInfoCount    = (uint32_t)queueCIs.size();
    ci.pEnabledFeatures        = &features;
    ci.enabledExtensionCount   = 1;
    ci.ppEnabledExtensionNames = kDeviceExts;
    if (kEnableValidation) {
        ci.enabledLayerCount   = 1;
        ci.ppEnabledLayerNames = &kValidationLayer;
    }

    if (vkCreateDevice(physDevice, &ci, nullptr, &device) != VK_SUCCESS)
        throw std::runtime_error("VkBase: vkCreateDevice failed");

    vkGetDeviceQueue(device, graphicsFamily, 0, &graphicsQueue);
    vkGetDeviceQueue(device, presentFamily,  0, &presentQueue);
}

// ---------------------------------------------------------------------------
// CreateSwapchain
// ---------------------------------------------------------------------------
void VkBase::CreateSwapchain() {
    // Surface format: prefer BGRA8_UNORM with an alpha channel (for transparency)
    uint32_t fmtCount = 0;
    vkGetPhysicalDeviceSurfaceFormatsKHR(physDevice, surface, &fmtCount, nullptr);
    std::vector<VkSurfaceFormatKHR> formats(fmtCount);
    vkGetPhysicalDeviceSurfaceFormatsKHR(physDevice, surface, &fmtCount, formats.data());

    VkSurfaceFormatKHR chosen = formats[0];
    for (auto& f : formats) {
        if (f.format == VK_FORMAT_B8G8R8A8_UNORM &&
            f.colorSpace == VK_COLOR_SPACE_SRGB_NONLINEAR_KHR) {
            chosen = f;
            break;
        }
    }
    swapFormat = chosen.format;

    // Present mode: prefer mailbox (lowest latency triple-buffer), fall back to FIFO
    uint32_t pmCount = 0;
    vkGetPhysicalDeviceSurfacePresentModesKHR(physDevice, surface, &pmCount, nullptr);
    std::vector<VkPresentModeKHR> presentModes(pmCount);
    vkGetPhysicalDeviceSurfacePresentModesKHR(physDevice, surface, &pmCount, presentModes.data());
    VkPresentModeKHR presentMode = VK_PRESENT_MODE_FIFO_KHR;
    for (auto pm : presentModes)
        if (pm == VK_PRESENT_MODE_MAILBOX_KHR) { presentMode = pm; break; }

    VkSurfaceCapabilitiesKHR caps;
    vkGetPhysicalDeviceSurfaceCapabilitiesKHR(physDevice, surface, &caps);

    swapExtent = caps.currentExtent;
    if (swapExtent.width == UINT32_MAX) {
        swapExtent.width  = std::clamp((uint32_t)winW, caps.minImageExtent.width,  caps.maxImageExtent.width);
        swapExtent.height = std::clamp((uint32_t)winH, caps.minImageExtent.height, caps.maxImageExtent.height);
    }

    uint32_t imageCount = caps.minImageCount + 1;
    if (caps.maxImageCount > 0) imageCount = std::min(imageCount, caps.maxImageCount);

    VkSwapchainCreateInfoKHR sci = {};
    sci.sType                 = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;
    sci.surface               = surface;
    sci.minImageCount         = imageCount;
    sci.imageFormat           = chosen.format;
    sci.imageColorSpace       = chosen.colorSpace;
    sci.imageExtent           = swapExtent;
    sci.imageArrayLayers      = 1;
    sci.imageUsage            = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
    sci.compositeAlpha        = VK_COMPOSITE_ALPHA_PRE_MULTIPLIED_BIT_KHR; // transparency compositing
    sci.presentMode           = presentMode;
    sci.clipped               = VK_TRUE;

    // Check if PRE_MULTIPLIED is supported; fall back to POST_MULTIPLIED then INHERIT
    if (!(caps.supportedCompositeAlpha & VK_COMPOSITE_ALPHA_PRE_MULTIPLIED_BIT_KHR)) {
        if (caps.supportedCompositeAlpha & VK_COMPOSITE_ALPHA_POST_MULTIPLIED_BIT_KHR)
            sci.compositeAlpha = VK_COMPOSITE_ALPHA_POST_MULTIPLIED_BIT_KHR;
        else if (caps.supportedCompositeAlpha & VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR)
            sci.compositeAlpha = VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR;
        else
            sci.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
    }

    uint32_t qfIndices[] = { graphicsFamily, presentFamily };
    if (graphicsFamily != presentFamily) {
        sci.imageSharingMode      = VK_SHARING_MODE_CONCURRENT;
        sci.queueFamilyIndexCount = 2;
        sci.pQueueFamilyIndices   = qfIndices;
    } else {
        sci.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
    }
    sci.preTransform = caps.currentTransform;

    if (vkCreateSwapchainKHR(device, &sci, nullptr, &swapchain) != VK_SUCCESS)
        throw std::runtime_error("VkBase: vkCreateSwapchainKHR failed");

    uint32_t imgCount = 0;
    vkGetSwapchainImagesKHR(device, swapchain, &imgCount, nullptr);
    swapImages.resize(imgCount);
    vkGetSwapchainImagesKHR(device, swapchain, &imgCount, swapImages.data());
}

// ---------------------------------------------------------------------------
// CreateImageViews
// ---------------------------------------------------------------------------
void VkBase::CreateImageViews() {
    swapViews.resize(swapImages.size());
    for (size_t i = 0; i < swapImages.size(); ++i) {
        VkImageViewCreateInfo ci = {};
        ci.sType                         = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
        ci.image                         = swapImages[i];
        ci.viewType                      = VK_IMAGE_VIEW_TYPE_2D;
        ci.format                        = swapFormat;
        ci.components                    = { VK_COMPONENT_SWIZZLE_IDENTITY,
                                             VK_COMPONENT_SWIZZLE_IDENTITY,
                                             VK_COMPONENT_SWIZZLE_IDENTITY,
                                             VK_COMPONENT_SWIZZLE_IDENTITY };
        ci.subresourceRange.aspectMask   = VK_IMAGE_ASPECT_COLOR_BIT;
        ci.subresourceRange.baseMipLevel = 0;
        ci.subresourceRange.levelCount   = 1;
        ci.subresourceRange.baseArrayLayer = 0;
        ci.subresourceRange.layerCount   = 1;
        if (vkCreateImageView(device, &ci, nullptr, &swapViews[i]) != VK_SUCCESS)
            throw std::runtime_error("VkBase: vkCreateImageView failed");
    }
}

// ---------------------------------------------------------------------------
// CreateRenderPass
// ---------------------------------------------------------------------------
void VkBase::CreateRenderPass() {
    bool transparent = this->transparent;
    VkAttachmentDescription colorAttachment = {};
    colorAttachment.format         = swapFormat;
    colorAttachment.samples        = VK_SAMPLE_COUNT_1_BIT;
    colorAttachment.loadOp         = VK_ATTACHMENT_LOAD_OP_CLEAR;
    colorAttachment.storeOp        = VK_ATTACHMENT_STORE_OP_STORE;
    colorAttachment.stencilLoadOp  = VK_ATTACHMENT_LOAD_OP_DONT_CARE;
    colorAttachment.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    colorAttachment.initialLayout  = VK_IMAGE_LAYOUT_UNDEFINED;
    colorAttachment.finalLayout    = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;

    VkAttachmentReference colorRef = {};
    colorRef.attachment = 0;
    colorRef.layout     = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;

    VkSubpassDescription subpass = {};
    subpass.pipelineBindPoint    = VK_PIPELINE_BIND_POINT_GRAPHICS;
    subpass.colorAttachmentCount = 1;
    subpass.pColorAttachments    = &colorRef;

    VkSubpassDependency dep = {};
    dep.srcSubpass    = VK_SUBPASS_EXTERNAL;
    dep.dstSubpass    = 0;
    dep.srcStageMask  = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    dep.srcAccessMask = 0;
    dep.dstStageMask  = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    dep.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;

    VkRenderPassCreateInfo ci = {};
    ci.sType           = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;
    ci.attachmentCount = 1;
    ci.pAttachments    = &colorAttachment;
    ci.subpassCount    = 1;
    ci.pSubpasses      = &subpass;
    ci.dependencyCount = 1;
    ci.pDependencies   = &dep;

    if (vkCreateRenderPass(device, &ci, nullptr, &renderPass) != VK_SUCCESS)
        throw std::runtime_error("VkBase: vkCreateRenderPass failed");

    (void)transparent; // future: could use VK_IMAGE_LAYOUT_GENERAL for some transparent paths
}

// ---------------------------------------------------------------------------
// CreateFramebuffers
// ---------------------------------------------------------------------------
void VkBase::CreateFramebuffers() {
    framebuffers.resize(swapViews.size());
    for (size_t i = 0; i < swapViews.size(); ++i) {
        VkFramebufferCreateInfo ci = {};
        ci.sType           = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;
        ci.renderPass      = renderPass;
        ci.attachmentCount = 1;
        ci.pAttachments    = &swapViews[i];
        ci.width           = swapExtent.width;
        ci.height          = swapExtent.height;
        ci.layers          = 1;
        if (vkCreateFramebuffer(device, &ci, nullptr, &framebuffers[i]) != VK_SUCCESS)
            throw std::runtime_error("VkBase: vkCreateFramebuffer failed");
    }
}

// ---------------------------------------------------------------------------
// CreateCommandPoolAndBuffers
// ---------------------------------------------------------------------------
void VkBase::CreateCommandPoolAndBuffers() {
    VkCommandPoolCreateInfo ci = {};
    ci.sType            = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
    ci.queueFamilyIndex = graphicsFamily;
    ci.flags            = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    if (vkCreateCommandPool(device, &ci, nullptr, &cmdPool) != VK_SUCCESS)
        throw std::runtime_error("VkBase: vkCreateCommandPool failed");

    cmdBuffers.resize(framebuffers.size());
    VkCommandBufferAllocateInfo alloc = {};
    alloc.sType              = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
    alloc.commandPool        = cmdPool;
    alloc.level              = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    alloc.commandBufferCount = (uint32_t)cmdBuffers.size();
    if (vkAllocateCommandBuffers(device, &alloc, cmdBuffers.data()) != VK_SUCCESS)
        throw std::runtime_error("VkBase: vkAllocateCommandBuffers failed");
}

// ---------------------------------------------------------------------------
// CreateSyncObjects
// ---------------------------------------------------------------------------
void VkBase::CreateSyncObjects() {
    VkSemaphoreCreateInfo si = {};
    si.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
    VkFenceCreateInfo fi = {};
    fi.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;
    fi.flags = VK_FENCE_CREATE_SIGNALED_BIT;
    for (int i = 0; i < kMaxFramesInFlight; ++i) {
        vkCreateSemaphore(device, &si, nullptr, &imageAvailable[i]);
        vkCreateSemaphore(device, &si, nullptr, &renderFinished[i]);
        vkCreateFence(device, &fi, nullptr, &inFlightFences[i]);
    }
}

// ---------------------------------------------------------------------------
// BeginFrame
// ---------------------------------------------------------------------------
bool VkBase::BeginFrame(uint32_t& outImageIndex) {
    vkWaitForFences(device, 1, &inFlightFences[currentFrame], VK_TRUE, UINT64_MAX);

    VkResult result = vkAcquireNextImageKHR(device, swapchain, UINT64_MAX,
        imageAvailable[currentFrame], VK_NULL_HANDLE, &outImageIndex);
    if (result == VK_ERROR_OUT_OF_DATE_KHR) {
        RecreateSwapchain();
        return false;
    }

    vkResetFences(device, 1, &inFlightFences[currentFrame]);

    VkCommandBuffer cmd = cmdBuffers[outImageIndex];
    vkResetCommandBuffer(cmd, 0);

    VkCommandBufferBeginInfo bi = {};
    bi.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
    vkBeginCommandBuffer(cmd, &bi);

    VkClearValue clearColor = {};
    clearColor.color = {{ 0.0f, 0.0f, 0.0f, 0.0f }}; // fully transparent clear

    VkRenderPassBeginInfo rbi = {};
    rbi.sType             = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
    rbi.renderPass        = renderPass;
    rbi.framebuffer       = framebuffers[outImageIndex];
    rbi.renderArea.offset = {0, 0};
    rbi.renderArea.extent = swapExtent;
    rbi.clearValueCount   = 1;
    rbi.pClearValues      = &clearColor;
    vkCmdBeginRenderPass(cmd, &rbi, VK_SUBPASS_CONTENTS_INLINE);

    VkViewport viewport = {};
    viewport.x        = 0.0f;
    viewport.y        = 0.0f;
    viewport.width    = (float)swapExtent.width;
    viewport.height   = (float)swapExtent.height;
    viewport.minDepth = 0.0f;
    viewport.maxDepth = 1.0f;
    vkCmdSetViewport(cmd, 0, 1, &viewport);

    VkRect2D scissor = {};
    scissor.offset = {0, 0};
    scissor.extent = swapExtent;
    vkCmdSetScissor(cmd, 0, 1, &scissor);

    return true;
}

// ---------------------------------------------------------------------------
// EndFrame
// ---------------------------------------------------------------------------
void VkBase::EndFrame(uint32_t imageIndex) {
    VkCommandBuffer cmd = cmdBuffers[imageIndex];
    vkCmdEndRenderPass(cmd);
    vkEndCommandBuffer(cmd);

    VkPipelineStageFlags waitStage = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    VkSubmitInfo si = {};
    si.sType                = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    si.waitSemaphoreCount   = 1;
    si.pWaitSemaphores      = &imageAvailable[currentFrame];
    si.pWaitDstStageMask    = &waitStage;
    si.commandBufferCount   = 1;
    si.pCommandBuffers      = &cmd;
    si.signalSemaphoreCount = 1;
    si.pSignalSemaphores    = &renderFinished[currentFrame];
    vkQueueSubmit(graphicsQueue, 1, &si, inFlightFences[currentFrame]);

    VkPresentInfoKHR pi = {};
    pi.sType              = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;
    pi.waitSemaphoreCount = 1;
    pi.pWaitSemaphores    = &renderFinished[currentFrame];
    pi.swapchainCount     = 1;
    pi.pSwapchains        = &swapchain;
    pi.pImageIndices      = &imageIndex;
    vkQueuePresentKHR(presentQueue, &pi);

    currentFrame = (currentFrame + 1) % kMaxFramesInFlight;
}

// ---------------------------------------------------------------------------
// RecreateSwapchain
// ---------------------------------------------------------------------------
void VkBase::RecreateSwapchain() {
    vkDeviceWaitIdle(device);
    CleanupSwapchain();
    CreateSwapchain();
    CreateImageViews();
    CreateFramebuffers();
    vkFreeCommandBuffers(device, cmdPool, (uint32_t)cmdBuffers.size(), cmdBuffers.data());
    CreateCommandPoolAndBuffers();
}

// ---------------------------------------------------------------------------
// CleanupSwapchain (without destroying device/instance)
// ---------------------------------------------------------------------------
void VkBase::CleanupSwapchain() {
    for (auto fb : framebuffers) vkDestroyFramebuffer(device, fb, nullptr);
    framebuffers.clear();
    for (auto iv : swapViews) vkDestroyImageView(device, iv, nullptr);
    swapViews.clear();
    vkDestroySwapchainKHR(device, swapchain, nullptr);
    swapchain = VK_NULL_HANDLE;
}

// ---------------------------------------------------------------------------
// CreateShaderModule
// ---------------------------------------------------------------------------
VkShaderModule VkBase::CreateShaderModule(SpvCode spv) {
    VkShaderModuleCreateInfo ci = {};
    ci.sType    = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
    ci.codeSize = spv.sizeBytes;
    ci.pCode    = spv.data;
    VkShaderModule mod;
    if (vkCreateShaderModule(device, &ci, nullptr, &mod) != VK_SUCCESS)
        throw std::runtime_error("VkBase: vkCreateShaderModule failed");
    return mod;
}

// ---------------------------------------------------------------------------
// CreateSimplePipeline
// ---------------------------------------------------------------------------
void VkBase::CreateSimplePipeline(
    SpvCode vertSpv, SpvCode fragSpv,
    VkPipelineLayout& outLayout, VkPipeline& outPipeline,
    VkDescriptorSetLayout descSetLayout,
    const VkPushConstantRange* pushConstants, uint32_t pushConstCount)
{
    VkShaderModule vertMod = CreateShaderModule(vertSpv);
    VkShaderModule fragMod = CreateShaderModule(fragSpv);

    VkPipelineShaderStageCreateInfo stages[2] = {};
    stages[0].sType  = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    stages[0].stage  = VK_SHADER_STAGE_VERTEX_BIT;
    stages[0].module = vertMod;
    stages[0].pName  = "main";
    stages[1].sType  = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    stages[1].stage  = VK_SHADER_STAGE_FRAGMENT_BIT;
    stages[1].module = fragMod;
    stages[1].pName  = "main";

    // No vertex input -- all geometry is generated in the vertex shader
    VkPipelineVertexInputStateCreateInfo vi = {};
    vi.sType = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO;

    VkPipelineInputAssemblyStateCreateInfo ia = {};
    ia.sType    = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO;
    ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;

    VkPipelineViewportStateCreateInfo vps = {};
    vps.sType         = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO;
    vps.viewportCount = 1;
    vps.scissorCount  = 1;

    VkPipelineRasterizationStateCreateInfo raster = {};
    raster.sType       = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO;
    raster.polygonMode = VK_POLYGON_MODE_FILL;
    raster.cullMode    = VK_CULL_MODE_NONE;
    raster.frontFace   = VK_FRONT_FACE_COUNTER_CLOCKWISE;
    raster.lineWidth   = 1.0f;

    VkPipelineMultisampleStateCreateInfo ms = {};
    ms.sType                = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO;
    ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;

    // Alpha blending: src * srcAlpha + dst * (1 - srcAlpha)
    VkPipelineColorBlendAttachmentState blendAttach = {};
    blendAttach.blendEnable         = VK_TRUE;
    blendAttach.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA;
    blendAttach.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
    blendAttach.colorBlendOp        = VK_BLEND_OP_ADD;
    blendAttach.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE;
    blendAttach.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO;
    blendAttach.alphaBlendOp        = VK_BLEND_OP_ADD;
    blendAttach.colorWriteMask      = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT |
                                      VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;

    VkPipelineColorBlendStateCreateInfo blend = {};
    blend.sType           = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO;
    blend.attachmentCount = 1;
    blend.pAttachments    = &blendAttach;

    // Dynamic viewport and scissor so we don't have to recreate the pipeline on resize
    VkDynamicState dynStates[] = { VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR };
    VkPipelineDynamicStateCreateInfo dyn = {};
    dyn.sType             = VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO;
    dyn.dynamicStateCount = 2;
    dyn.pDynamicStates    = dynStates;

    VkPipelineLayoutCreateInfo layoutCI = {};
    layoutCI.sType                  = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
    layoutCI.setLayoutCount         = descSetLayout != VK_NULL_HANDLE ? 1 : 0;
    layoutCI.pSetLayouts            = descSetLayout != VK_NULL_HANDLE ? &descSetLayout : nullptr;
    layoutCI.pushConstantRangeCount = pushConstCount;
    layoutCI.pPushConstantRanges    = pushConstants;
    vkCreatePipelineLayout(device, &layoutCI, nullptr, &outLayout);

    VkGraphicsPipelineCreateInfo pipeCI = {};
    pipeCI.sType               = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO;
    pipeCI.stageCount          = 2;
    pipeCI.pStages             = stages;
    pipeCI.pVertexInputState   = &vi;
    pipeCI.pInputAssemblyState = &ia;
    pipeCI.pViewportState      = &vps;
    pipeCI.pRasterizationState = &raster;
    pipeCI.pMultisampleState   = &ms;
    pipeCI.pColorBlendState    = &blend;
    pipeCI.pDynamicState       = &dyn;
    pipeCI.layout              = outLayout;
    pipeCI.renderPass          = renderPass;
    pipeCI.subpass             = 0;

    if (vkCreateGraphicsPipelines(device, VK_NULL_HANDLE, 1, &pipeCI, nullptr, &outPipeline) != VK_SUCCESS)
        throw std::runtime_error("VkBase: vkCreateGraphicsPipelines failed");

    vkDestroyShaderModule(device, vertMod, nullptr);
    vkDestroyShaderModule(device, fragMod, nullptr);
}

// ---------------------------------------------------------------------------
// Destroy
// ---------------------------------------------------------------------------
void VkBase::Destroy() {
    vkDeviceWaitIdle(device);
    for (int i = 0; i < kMaxFramesInFlight; ++i) {
        vkDestroySemaphore(device, imageAvailable[i], nullptr);
        vkDestroySemaphore(device, renderFinished[i], nullptr);
        vkDestroyFence(device, inFlightFences[i], nullptr);
    }
    vkDestroyCommandPool(device, cmdPool, nullptr);
    CleanupSwapchain();
    vkDestroyRenderPass(device, renderPass, nullptr);
    vkDestroySurfaceKHR(instance, surface, nullptr);
    vkDestroyDevice(device, nullptr);
    vkDestroyInstance(instance, nullptr);
    if (window) glfwDestroyWindow(window);
}
