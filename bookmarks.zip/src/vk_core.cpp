// vk_core.cpp -- siehe vk_core.h
#include "vk_core.h"
// volk laedt die Vulkan-Laufzeitbibliothek des GPU-Treibers per dlopen --
// kein Link gegen einen Loader, keine Dev-Pakete. volk.h zieht vulkan.h
// (aus den gefetchten Vulkan-Headers) mit VK_NO_PROTOTYPES selbst herein.
#include <volk.h>
#include <vector>
#include <cstring>
#include <cstdio>
#if defined(__ANDROID__)
  #include <android/log.h>
  #define VKLOG(...) __android_log_print(ANDROID_LOG_INFO, "XBookmarks", __VA_ARGS__)
#else
  #define VKLOG(...) do { printf(__VA_ARGS__); printf("\n"); } while (0)
#endif

namespace {
VkInstance       g_instance = VK_NULL_HANDLE;
VkPhysicalDevice g_phys     = VK_NULL_HANDLE;
VkDevice         g_device   = VK_NULL_HANDLE;
uint32_t         g_gfxQueueFamily = ~0u;
VkQueue          g_gfxQueue = VK_NULL_HANDLE;
VkCoreInfo       g_info;
}

VkCoreInfo VkCore_Init(bool validation) {
    if (g_info.ok) return g_info;

    // Laufzeitbibliothek des Treibers laden (libvulkan.so.1 / vulkan-1.dll).
    static bool volkReady = false;
    if (!volkReady) {
        if (volkInitialize() != VK_SUCCESS) {
            VKLOG("VkCore: keine Vulkan-Laufzeitbibliothek gefunden "
                  "(GPU-Treiber ohne Vulkan?)");
            return g_info;
        }
        volkReady = true;
    }

    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName = "x_bookmark_manager";
    app.apiVersion = VK_API_VERSION_1_1;

    std::vector<const char*> layers;
    if (validation) {
        uint32_t n = 0; vkEnumerateInstanceLayerProperties(&n, nullptr);
        std::vector<VkLayerProperties> props(n);
        vkEnumerateInstanceLayerProperties(&n, props.data());
        for (auto& p : props)
            if (!strcmp(p.layerName, "VK_LAYER_KHRONOS_validation"))
                layers.push_back("VK_LAYER_KHRONOS_validation");
    }

    VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ici.pApplicationInfo = &app;
    ici.enabledLayerCount = (uint32_t)layers.size();
    ici.ppEnabledLayerNames = layers.data();
    if (vkCreateInstance(&ici, nullptr, &g_instance) != VK_SUCCESS) {
        VKLOG("VkCore: vkCreateInstance FEHLGESCHLAGEN");
        return g_info;
    }
    volkLoadInstance(g_instance);  // Instanz-/Device-Funktionen nachladen

    uint32_t n = 0; vkEnumeratePhysicalDevices(g_instance, &n, nullptr);
    if (!n) { VKLOG("VkCore: keine Vulkan-GPU gefunden"); return g_info; }
    std::vector<VkPhysicalDevice> devs(n);
    vkEnumeratePhysicalDevices(g_instance, &n, devs.data());
    // Auswahl: erste diskrete GPU, sonst erste ueberhaupt
    g_phys = devs[0];
    for (auto d : devs) {
        VkPhysicalDeviceProperties p; vkGetPhysicalDeviceProperties(d, &p);
        if (p.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU) { g_phys = d; break; }
    }
    VkPhysicalDeviceProperties props;
    vkGetPhysicalDeviceProperties(g_phys, &props);

    uint32_t qn = 0;
    vkGetPhysicalDeviceQueueFamilyProperties(g_phys, &qn, nullptr);
    std::vector<VkQueueFamilyProperties> qf(qn);
    vkGetPhysicalDeviceQueueFamilyProperties(g_phys, &qn, qf.data());
    for (uint32_t i = 0; i < qn; ++i)
        if (qf[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) { g_gfxQueueFamily = i; break; }
    if (g_gfxQueueFamily == ~0u) { VKLOG("VkCore: keine Graphics-Queue"); return g_info; }

    float prio = 1.0f;
    VkDeviceQueueCreateInfo qci{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
    qci.queueFamilyIndex = g_gfxQueueFamily;
    qci.queueCount = 1; qci.pQueuePriorities = &prio;
    VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    dci.queueCreateInfoCount = 1; dci.pQueueCreateInfos = &qci;
    if (vkCreateDevice(g_phys, &dci, nullptr, &g_device) != VK_SUCCESS) {
        VKLOG("VkCore: vkCreateDevice FEHLGESCHLAGEN"); return g_info;
    }
    vkGetDeviceQueue(g_device, g_gfxQueueFamily, 0, &g_gfxQueue);

    g_info.gpuName = props.deviceName;
    g_info.apiVersion = props.apiVersion;
    g_info.ok = true;
    return g_info;
}

void VkCore_Shutdown() {
    if (g_device)   vkDestroyDevice(g_device, nullptr);
    if (g_instance) vkDestroyInstance(g_instance, nullptr);
    g_device = VK_NULL_HANDLE; g_instance = VK_NULL_HANDLE;
    g_info = VkCoreInfo{};
}

void VkCore_SelftestLog() {
    VkCoreInfo info = VkCore_Init(false);
    if (info.ok)
        VKLOG("VkCore OK: GPU='%s' API=%u.%u.%u",
              info.gpuName.c_str(),
              VK_VERSION_MAJOR(info.apiVersion),
              VK_VERSION_MINOR(info.apiVersion),
              VK_VERSION_PATCH(info.apiVersion));
    else
        VKLOG("VkCore: Initialisierung fehlgeschlagen -- Details oben");
}
