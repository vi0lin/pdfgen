// win32_window.cpp
//
// See win32_window.h for the full rationale. This intentionally bypasses
// GLFW entirely on Windows so we can isolate and verify each step of
// window/context/transparency setup ourselves.

#ifdef _WIN32

#include "win32_window.h"
#include <cstdio>   // fprintf/stderr

#include <dwmapi.h>
#include <GL/gl.h>
#include <vector>
#include "imgui.h"

// ImGui_ImplWin32_WndProcHandler is intentionally left commented out in
// imgui_impl_win32.h (to avoid forcing <windows.h> on every consumer of
// that header) -- the header's own comment instructs copying this forward
// declaration into our .cpp, which is what this line does.
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// Other Win32 backend functions ARE declared normally in the header.
#include "imgui_impl_win32.h"


namespace {

bool g_shouldClose = false;
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

const wchar_t* kClassName = L"XBookmarkManagerOverlayWindowClass";

} // namespace

namespace Win32Window {

bool Create(HWND& outHwnd, HDC& outHdc, HGLRC& outGlrc, int& outWidth, int& outHeight) {
    HINSTANCE hInstance = GetModuleHandle(nullptr);

    WNDCLASSEXW wc = {};
    wc.cbSize = sizeof(WNDCLASSEXW);
    wc.style = CS_OWNDC; // required for a window that owns its own GL-capable DC
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = kClassName;
    // IMPORTANT: BLACK_BRUSH here, not the default/NULL. This is the same
    // technique we tried on the GLFW-created window (writes zero-alpha into
    // the DWM redirection surface on WM_ERASEBKGND) -- but this time applied
    // at class REGISTRATION time, before any window of this class exists,
    // rather than patched onto an already-created GLFW window after the fact.
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);

    if (!RegisterClassExW(&wc)) {
        fprintf(stderr, "Win32Window::Create: RegisterClassExW failed, error=%lu\n", GetLastError());
        return false;
    }

    int screenW = GetSystemMetrics(SM_CXSCREEN);
    int screenH = GetSystemMetrics(SM_CYSCREEN);

    // IMPORTANT: do NOT make the window exactly screenW x screenH at (0,0).
    //
    // We confirmed by direct test that an exact-monitor-size WS_POPUP window
    // renders fully OPAQUE despite every transparency API (pixel format
    // alpha bits, DwmIsCompositionEnabled, DwmEnableBlurBehindWindow/
    // ImGui_ImplWin32_EnableAlphaCompositing) reporting success -- while the
    // exact same window, resized+repositioned to NOT match the screen
    // dimensions exactly, composited transparently with no other code
    // changes at all. This matches a known Windows/DWM behavior: borderless
    // windows that exactly match a monitor's resolution can be detected as
    // "fullscreen" by DWM's fullscreen-optimization heuristics (the same
    // path that gives games exclusive-fullscreen-like behavior), which
    // bypasses normal alpha-blended desktop composition entirely.
    //
    // The fix is simply to never let the window's actual size exactly equal
    // the monitor's pixel dimensions. We grow it by 1px in height and shift
    // it up by 1px, which is visually imperceptible but reliably avoids the
    // heuristic. (An alternative fix is calling
    // SetWindowDisplayAffinity / DWMWA_DISALLOW_PEEK or the newer
    // DWM "disable fullscreen optimizations" app compat flag, but the
    // simple size-mismatch trick is the most portable and doesn't depend
    // on Windows version-specific APIs.)
    int windowW = screenW;
    int windowH = screenH + 1;
    int windowX = 0;
    int windowY = -1;

    // WS_POPUP: borderless, no title bar/decorations (equivalent to
    // GLFW_DECORATED=FALSE). WS_EX_TOPMOST is NOT set here -- add it back
    // if you want GLFW_FLOATING=TRUE-equivalent always-on-top behavior.
    //
    // Deliberately NOT setting WS_EX_LAYERED (see clickthrough_overlay.cpp
    // notes from earlier in this debugging session: WS_EX_LAYERED assumes
    // the legacy UpdateLayeredWindow bitmap model, which we never use, and
    // leaves the surface undefined/black). We rely purely on
    // DwmEnableBlurBehindWindow + the BLACK_BRUSH class background instead.
    HWND hwnd = CreateWindowExW(
        WS_EX_LAYERED |
        0,
        kClassName,
        L"Overlay",
        // WS_VISIBLE bewusst NICHT gesetzt: das Fenster wird erst nach dem
        // ersten praesentierten Frame eingeblendet (Win32Window::ShowAfter-
        // FirstFrame aus der Renderschleife). Ein sofort sichtbares rand-
        // loses Vollbildfenster zeigt sonst fuer einen Moment SCHWARZ
        // (Backbuffer noch leer) -- der beobachtete Display-Blackout beim
        // Start. WS_EX_LAYERED direkt bei der Erzeugung (statt spaeter per
        // SetWindowLong) vermeidet zusaetzlich den DWM-Surface-Neuaufbau,
        // der ebenfalls flackert; Alpha wird gleich auf 255 gesetzt.
        WS_POPUP,
        windowX, windowY, windowW, windowH,
        nullptr, nullptr, hInstance, nullptr);

    if (hwnd) SetLayeredWindowAttributes(hwnd, 0, 255, LWA_ALPHA);
    if (!hwnd) {
        fprintf(stderr, "Win32Window::Create: CreateWindowExW failed, error=%lu\n", GetLastError());
        return false;
    }

    HDC hdc = GetDC(hwnd);
    if (!hdc) {
        fprintf(stderr, "Win32Window::Create: GetDC failed\n");
        return false;
    }

    PIXELFORMATDESCRIPTOR pfd = {};
    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 32;
    pfd.cAlphaBits = 8; // EXPLICITLY request an alpha channel in the pixel format
    pfd.cDepthBits = 24;
    pfd.iLayerType = PFD_MAIN_PLANE;

    int pixelFormat = ChoosePixelFormat(hdc, &pfd);
    if (pixelFormat == 0) {
        fprintf(stderr, "Win32Window::Create: ChoosePixelFormat failed, error=%lu\n", GetLastError());
        return false;
    }
    if (!SetPixelFormat(hdc, pixelFormat, &pfd)) {
        fprintf(stderr, "Win32Window::Create: SetPixelFormat failed, error=%lu\n", GetLastError());
        return false;
    }

    HGLRC hglrc = wglCreateContext(hdc);
    if (!hglrc) {
        fprintf(stderr, "Win32Window::Create: wglCreateContext failed, error=%lu\n", GetLastError());
        return false;
    }
    if (!wglMakeCurrent(hdc, hglrc)) {
        fprintf(stderr, "Win32Window::Create: wglMakeCurrent failed, error=%lu\n", GetLastError());
        return false;
    }

    // Confirm the pixel format we actually got has a real alpha channel --
    // ChoosePixelFormat can silently hand back something close-but-not-exact
    // to what we asked for.
    PIXELFORMATDESCRIPTOR actualPfd = {};
    DescribePixelFormat(hdc, pixelFormat, sizeof(actualPfd), &actualPfd);
    fprintf(stderr, "Win32Window: pixel format alpha bits = %d\n", actualPfd.cAlphaBits);

    // The actual transparency setup: BLACK_BRUSH was already set at class
    // registration above. Now tell DWM to use the redirection surface's
    // alpha channel for compositing, using Dear ImGui's own maintained
    // helper for this exact purpose (imgui_impl_win32.cpp,
    // ImGui_ImplWin32_EnableAlphaCompositing) rather than hand-duplicating
    // its DwmEnableBlurBehindWindow logic ourselves. This also includes
    // ImGui's own Windows-version guards (Vista+/8+ checks) that our first
    // hand-written attempt didn't have.
    BOOL compositionEnabled = FALSE;
    HRESULT hrComp = DwmIsCompositionEnabled(&compositionEnabled);
    fprintf(stderr, "Win32Window: DwmIsCompositionEnabled hr=0x%08lx enabled=%d\n", hrComp, compositionEnabled);

    ImGui_ImplWin32_EnableAlphaCompositing((void*)hwnd);
    fprintf(stderr, "Win32Window: called ImGui_ImplWin32_EnableAlphaCompositing\n");

    outHwnd = hwnd;
    outHdc = hdc;
    outGlrc = hglrc;
    outWidth = screenW;
    outHeight = screenH;
    return true;
}

bool PollEvents() {
    MSG msg;
    while (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE)) {
        if (msg.message == WM_QUIT) {
            g_shouldClose = true;
        }
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return !g_shouldClose;
}

void SwapBuffers(HDC hdc) {
    ::SwapBuffers(hdc);
}

namespace {
    std::vector<RECT> g_lastRects;
    bool g_regionCacheValid = false;

    bool RectsEqual(const RECT& a, const RECT& b) {
        return a.left == b.left && a.top == b.top && a.right == b.right && a.bottom == b.bottom;
    }

    bool RectListsEqual(const RECT* a, int aCount, const std::vector<RECT>& b) {
        if (aCount != (int)b.size()) return false;
        for (int i = 0; i < aCount; ++i) {
            if (!RectsEqual(a[i], b[i])) return false;
        }
        return true;
    }
}

void UpdateClickThroughRegionHwnd(HWND hwnd, const RECT* rects, int rectCount) {
    // IMPORTANT: SetWindowRgn forces Windows to recompute the window's
    // shape and triggers a DWM re-composition pass every time it's called.
    // Calling it unconditionally every frame (60+ times/sec) -- even when
    // panels haven't moved, which is the overwhelmingly common case -- is a
    // well-documented cause of compositor instability/flicker. This was
    // very likely the actual root cause of the flicker observed earlier in
    // this project's history (which was initially, incorrectly, attributed
    // to the 1px fullscreen-size-mismatch workaround in Create() below --
    // that workaround is in fact the standard, documented technique for
    // avoiding DWM's fullscreen-optimization heuristic, and is not itself
    // the problem).
    //
    // Fix: only call SetWindowRgn when the region actually changed since
    // the last frame.
    if (g_regionCacheValid && RectListsEqual(rects, rectCount, g_lastRects)) {
        return;
    }
    g_lastRects.assign(rects, rects + rectCount);
    g_regionCacheValid = true;

    if (rectCount == 0) {
        HRGN empty = CreateRectRgn(0, 0, 0, 0);
        SetWindowRgn(hwnd, empty, TRUE); // hwnd takes ownership
        return;
    }
    HRGN combined = CreateRectRgn(0, 0, 0, 0);
    for (int i = 0; i < rectCount; ++i) {
        const RECT& r = rects[i];
        HRGN part = CreateRectRgn(r.left, r.top, r.right, r.bottom);
        CombineRgn(combined, combined, part, RGN_OR);
        DeleteObject(part);
    }
    SetWindowRgn(hwnd, combined, TRUE); // hwnd takes ownership
}

void Destroy(HWND hwnd, HDC hdc, HGLRC hglrc) {
    wglMakeCurrent(nullptr, nullptr);
    wglDeleteContext(hglrc);
    ReleaseDC(hwnd, hdc);
    DestroyWindow(hwnd);
    UnregisterClassW(kClassName, GetModuleHandle(nullptr));
}

bool ShouldClose() {
    return g_shouldClose;
}

} // namespace Win32Window

namespace {

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    // Forward to ImGui's Win32 backend first so it can process mouse/
    // keyboard input -- mirrors what imgui_impl_glfw's callbacks did.
    if (ImGui_ImplWin32_WndProcHandler(hwnd, msg, wParam, lParam)) {
        return true;
    }

    switch (msg) {
        case WM_CLOSE:
        case WM_DESTROY:
            g_shouldClose = true;
            PostQuitMessage(0);
            return 0;
        // Deliberately NOT handling WM_ERASEBKGND here -- letting the
        // default window proc run it is what actually applies our
        // BLACK_BRUSH class background and writes zero alpha. If you find
        // yourself tempted to "optimize" this by returning 1 here to skip
        // erasing, DON'T -- that was tried earlier in this debugging
        // session (on the GLFW path) as a focus-flash fix and intercepting
        // WM_ERASEBKGND entirely would remove the actual mechanism this
        // whole rewrite depends on.
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

} // namespace

#endif // _WIN32

namespace Win32Window {
void InvalidateRegionCache() {
    g_regionCacheValid = false;
}
} // namespace Win32Window

namespace Win32Window {
// Einmalig nach dem ersten SwapBuffers aufrufen: blendet das (versteckt
// erzeugte) Fenster ein, wenn der Backbuffer bereits Inhalt hat -- kein
// schwarzer Vollbild-Moment mehr beim Start.
void ShowAfterFirstFrame(HWND hwnd) {
    static bool shown = false;
    if (!shown && hwnd) { ShowWindow(hwnd, SW_SHOW); shown = true; }
}
} // namespace Win32Window
