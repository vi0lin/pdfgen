#pragma once
// win32_window.h
//
// Manual Win32 + WGL window/context creation, used ONLY on Windows, as a
// replacement for glfwCreateWindow/glfwMakeContextCurrent/glfwSwapBuffers.
//
// WHY THIS EXISTS: GLFW_TRANSPARENT_FRAMEBUFFER is confirmed broken on
// Windows as of GLFW 3.4 (glfw/glfw#2731, #1237 -- DWM never gets a
// correctly-cleared zero-alpha redirection surface, so the window renders
// opaque regardless of glClearColor). We tried the documented manual
// workaround (BLACK_BRUSH class background + DwmEnableBlurBehindWindow) on
// a GLFW-created window and it had zero effect, even though every
// diagnostic (DwmIsCompositionEnabled, DwmEnableBlurBehindWindow's HRESULT)
// reported success. That means something inside GLFW's own window-creation
// path is forcing opacity in a way we can't see or override from outside.
//
// This module creates the HWND ourselves, so every step is visible and
// controllable: window class registration, CreateWindowExW flags, pixel
// format selection, and WGL context creation -- with the SAME transparency
// technique applied directly to a window WE fully control.
//
// This intentionally does NOT use GLFW at all on Windows. ImGui's Win32
// backend (imgui_impl_win32, not imgui_impl_glfw) is used for input instead.

#ifdef _WIN32

#include <windows.h>

namespace Win32Window {

// Creates a fullscreen, borderless, transparent, click-through-capable
// window with a current WGL OpenGL context. Returns true on success.
// On success, fills outHwnd and outHdc; outWidth/outHeight receive the
// monitor's pixel dimensions actually used.
bool Create(HWND& outHwnd, HDC& outHdc, HGLRC& outGlrc, int& outWidth, int& outHeight);

// Call once per frame, BEFORE rendering: pumps the Win32 message queue.
// Returns false if the window received WM_QUIT / should close.
bool PollEvents();

// Call once per frame, AFTER ImGui_ImplOpenGL3_RenderDrawData: presents
// the frame (wraps SwapBuffers on the window's HDC).
void SwapBuffers(HDC hdc);

// Same click-through region update as ClickThroughOverlay::UpdateClickThroughRegion,
// but taking a raw HWND instead of a GLFWwindow* (since there is no GLFWwindow*
// in this path). Implemented here to avoid a circular include with
// clickthrough_overlay.h/.cpp; clickthrough_overlay.cpp's existing Win32
// branch logic is duplicated here in raw-HWND form.
void UpdateClickThroughRegionHwnd(HWND hwnd, const RECT* rects, int rectCount);
// Cache der zuletzt gesetzten Region verwerfen. NOETIG nach jedem externen
// SetWindowRgn (z.B. SetWindowRgn(hwnd, NULL) beim Vollbild-Hintergrund):
// sonst ueberspringt UpdateClickThroughRegionHwnd den naechsten Aufruf,
// wenn die Rechtecke zufaellig denen vor dem Moduswechsel gleichen --
// die Region (inkl. Overlay-Streifen) wird dann nie neu angewendet.
void InvalidateRegionCache();
// Nach dem ersten praesentierten Frame aufrufen (blendet das versteckt
// erzeugte Fenster ein -- verhindert den Schwarz-Blitz beim Start).
void ShowAfterFirstFrame(HWND hwnd);

// Cleans up the GL context, releases the DC, destroys the window, and
// unregisters the window class. Call once at shutdown.
void Destroy(HWND hwnd, HDC hdc, HGLRC hglrc);

// True once WM_CLOSE/WM_DESTROY/WM_QUIT has been observed by the window
// procedure. Checked by PollEvents()'s return value; exposed here too in
// case main.cpp wants to check it directly.
bool ShouldClose();

} // namespace Win32Window

#endif // _WIN32
