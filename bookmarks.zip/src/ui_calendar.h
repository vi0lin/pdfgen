#pragma once
// ---------------------------------------------------------------------------
// ui_calendar.h -- Kalenderfenster mit Tages-/3-Tages-/Wochen-/Monats-/
// Jahresansicht, Zeit-Zoom (Pinch bzw. Strg+Rad), Scrollen und
// Halten-und-Ziehen von Eintraegen.
//
// ABSICHTLICH OHNE PROJEKT-HEADER: dieses Modul kennt nur ImGui, den
// Scheduler und das Audiomodul. Alles, was es aus der App braucht, kommt
// ueber die Einhaengepunkte weiter unten. Dadurch ist es einzeln
// uebersetzbar und testbar -- und es kann auf Desktop und Android
// identisch laufen.
//
// ZEITMODELL: gespeichert wird IMMER Unix-UTC in Sekunden. Angezeigt und
// gerechnet wird in LOKALER Zeit ueber XbmTime_* (siehe xbm_sched.h), damit
// Sommerzeitwechsel keine Termine verschieben.
// ---------------------------------------------------------------------------
#include "imgui.h"

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

enum class CalView { Day, ThreeDay, Week, Month, Year };

// EINE Sprachnotiz. [Bisher hatte ein Eintrag GENAU EINE: das Feld
//  CalEntry::audio. Du willst mehrere je Event, jede einzeln abspielbar
//  und einzeln transkribierbar -- also eine Liste, und das Transkript
//  gehoert zur Memo, nicht zum Eintrag.]
struct CalMemo {
    std::string   audio;           // Dateiname der WAV im Kalenderordner
    std::string   transkript;      // Text dieser einen Memo
    std::int64_t  aufgenommen = 0; // Unix-Sekunden
    std::int32_t  dauerMs = 0;     // 0 = unbekannt
};

// WIE OFT WIEDERHOLT SICH EIN EINTRAG?
// [Wie im Google-Kalender: nie, taeglich, wochentaeglich, woechentlich,
//  monatlich, jaehrlich. "interval" erlaubt "jede 2. Woche".]
enum class CalWiederholung : int {
    Nie = 0, Taeglich, Wochentags, Woechentlich, Monatlich, Jaehrlich
};

// EINE AKTION AN EINEM EVENT -- Erinnerung, Alarm, spaeter mehr.
// [Du hast beschrieben: mehrere Erinnerungen je Event, im Kalender als
//  halbdurchsichtige Balken in der Eventfarbe, einzeln auswaehlbar und
//  verschiebbar, mit eigenem Alarmton, und mit Start UND Ende (fuer
//  "spiele in diesem Zeitraum eine Playlist"). Und allgemeiner: Actions,
//  die auch etwas TUN (PDF erzeugen, Mail senden).
//
//  Deshalb EIN Typ fuer beides statt zweier fast gleicher. Eine
//  Erinnerung ist eine Action mit art = Alarm. Das erspart uns spaeter,
//  Auswahl, Verschieben und Zeichnen zweimal zu bauen.]
enum class CalActionArt : int {
    Alarm = 0,      // Ton + Meldung (das, was du "Erinnerung" nennst)
    Ton,            // nur Ton, ohne Meldung
    Audio,          // Datei/Playlist ueber einen Zeitraum abspielen
    Pdf,            // PDF erzeugen
    Mail,           // Mail senden
    Befehl          // frei: Befehl ausfuehren
};

struct CalAction {
    std::uint64_t id     = 0;       // eigene Kennung (fuer den Alarm)
    CalActionArt  art    = CalActionArt::Alarm;
    std::int64_t  start  = 0;       // Unix-Sekunden, ABSOLUT
    std::int32_t  durMin = 0;       // 0 = Zeitpunkt, >0 = Zeitraum
    std::string   ton;              // Dateiname; leer = Standard-Alarmton
    std::string   text;             // Meldungstext; leer = Eventtitel
    std::string   ziel;             // Mailadresse, Pfad, Befehl ...
    bool          aktiv  = true;
    bool          getan  = false;   // einmalig und schon erledigt
    // STATISCH: bleibt an ihrer Uhrzeit stehen, wenn das Mutter-Event
    // verschoben wird -- sonst wandert sie standardmaessig RELATIV zum
    // Event mit (derselbe Abstand bleibt erhalten).
    bool          statisch = false;

    std::int64_t end() const { return start + (std::int64_t)durMin * 60; }
};

struct CalEntry {
    std::uint64_t id     = 0;
    bool          gruppe = false;  // Gruppen-Container (Mitglieder sind seine Unter-Termine)
    std::int64_t  start  = 0;      // Unix-UTC-Sekunden
    std::int32_t  durMin = 30;
    std::string   title;
    std::string   notes;           // freie Notiz (NICHT mehr das Transkript)
    std::string   audio;           // ALT: eine WAV -- nur noch fuer das
                                   // Lesen alter Dateien, siehe memos
    std::vector<CalMemo> memos;    // NEU: beliebig viele Sprachnotizen
    std::uint32_t color  = 0;      // 0 = automatisch aus der id
    bool          allDay = false;
    std::int32_t  remindMin = -1;  // Minuten vorher; <0 = keine Erinnerung
    bool          remindOn  = false;  // Erinnerung ueberhaupt aktiv?
    // MEHRERE Erinnerungen/Actions je Event. remindMin/remindOn oben
    // bleiben als EINFACHER Weg ("15 min vorher") bestehen -- sie werden
    // beim Laden in eine Action umgewandelt, wenn keine Liste da ist.
    std::vector<CalAction> actions;
    // Wiederholung
    CalWiederholung wdh      = CalWiederholung::Nie;
    std::int32_t    wdhJede  = 1;     // jede N-te Einheit
    std::int64_t    wdhBis   = 0;     // 0 = ohne Ende
    std::uint8_t    wdhTage  = 0;     // Woechentlich: Bit 0 = Mo ... Bit 6 = So (0 = Wochentag des Starts)
    std::int32_t    wdhAnzahl = 0;    // 0 = unbegrenzt, sonst so viele Vorkommen
    std::int64_t  created  = 0;
    std::int64_t  modified = 0;
    // Frei belegbar fuer spaetere Auswertung ("Events tracken"):
    // Herkunft des Eintrags, z.B. "memo", "sensor:schritte", "manuell".
    std::string   source;

    std::int64_t end() const {
        return start + (std::int64_t)(allDay ? 86400 : durMin * 60);
    }
};

// --- Lebenszyklus ---------------------------------------------------------
// dataDir = beschreibbarer Ordner; dort entstehen calendar.json und memos/.
void UiCalendar_Init(const std::string& dataDir);
void UiCalendar_Save();                 // sofort schreiben
void UiCalendar_SaveIfDirty();          // einmal pro Frame billig aufrufbar
void UiCalendar_Shutdown();
std::string UiCalendar_DataDir();

// --- Zeichnen -------------------------------------------------------------
// title: vollstaendiger ImGui-Titel (die App liefert den seitengescopten).
void UiCalendar_Draw(const char* title, bool* open, ImGuiWindowFlags flags = 0);

// --- Datenzugriff (auch fuer Sensoren, Gesten, Skripte) -------------------
std::vector<CalEntry>&  UiCalendar_All();
CalEntry*               UiCalendar_Find(std::uint64_t id);
std::uint64_t           UiCalendar_Add(CalEntry e);
// Editor fuer einen Eintrag oeffnen (0 = schliessen). Bisher liess sich
// das nur durch Antippen im Raster ausloesen -- fuer Tests und fuer
// Aufrufe von aussen (etwa aus einer Suche) fehlte der Weg.
void                    UiCalendar_Edit(std::uint64_t id);
bool                    UiCalendar_Remove(std::uint64_t id);
void                    UiCalendar_Touch(std::uint64_t id);   // modified + dirty
std::vector<CalEntry*>  UiCalendar_Range(std::int64_t fromUtc, std::int64_t toUtc);

// Bequemer Einzeiler fuer programmatische Quellen.
std::uint64_t UiCalendar_QuickAdd(const std::string& title,
                                  std::int64_t whenUtc,
                                  int durMin = 15,
                                  const std::string& source = "programm");

// --- Ansicht steuern (z.B. "springe zum heutigen Tag" aus dem Menue) ------
void     UiCalendar_SetView(CalView v);
CalView  UiCalendar_GetView();
void     UiCalendar_GoTo(std::int64_t utc);   // Datum in den Blick holen
void     UiCalendar_GoToday();

// --- Sprachmemo -----------------------------------------------------------
// Der Knopf im Kalenderfenster nutzt genau diese beiden Funktionen; damit
// laesst sich ein Memo auch per Geste, Sensor oder Fernsteuerung ausloesen.
// Beginn merkt sich Datum+Uhrzeit SOFORT -- der Eintrag traegt also die
// Zeit des Knopfdrucks, nicht die des Loslassens.
void UiCalendar_MemoBegin();
// Beendet die Aufnahme, legt den Eintrag an, schreibt die WAV und reicht
// den Ton zur Transkription weiter. Liefert die id des neuen Eintrags
// (0, wenn nichts aufgenommen wurde).
std::uint64_t UiCalendar_MemoEnd();
bool UiCalendar_MemoActive();

// War das Kalenderfenster im ZULETZT gezeichneten Frame sichtbar?
// Damit kann die rechte Knopfleiste der App einen Mikrofon-Knopf nur dann
// einblenden, wenn der Kalender ueberhaupt zu sehen ist. Sichtbarkeit
// genuegt hier -- der Knopf soll auch bedienbar sein, wenn der Fokus
// woanders liegt.
bool UiCalendar_IsVisible();

// --- Einfaches Event (ohne Memo) -------------------------------------------
// Legt SOFORT einen leeren Eintrag an -- an der gelben Zeitauswahl, sonst
// zur aktuellen Sekunde -- und oeffnet ihn zum Bearbeiten (Titel/Notiz).
// Liefert die id des neuen Eintrags.
std::uint64_t UiCalendar_QuickAdd();

// --- Gelbe Zeitauswahl -------------------------------------------------
// Setzt den Marker zurueck: kein Tag/keine Uhrzeit mehr ausgewaehlt.
// Danach entstehen neue Eintraege wieder zur AKTUELLEN Sekunde, bis man
// erneut in den Kalender tippt.
void UiCalendar_ClearSelectedTime();
bool UiCalendar_HasSelectedTime();

// --- Tastatur-Sofortanlage --------------------------------------------
// Ein Tastendruck IRGENDWO im Kalenderfenster (ausserhalb eines bereits
// offenen Editors) soll sofort einen neuen Eintrag anlegen und das erste
// Zeichen ins Titelfeld schreiben. Der Aufrufer (ui_calendar.cpp selbst,
// beim Zeichnen) ruft das mit dem ersten eingegebenen Zeichen; true =
// es wurde ein Eintrag angelegt und das Zeichen verbraucht.
bool UiCalendar_TypeToCreate(unsigned int codepoint);
// Weitere Zeichen DESSELBEN Frames an die Sofortanlage nachtragen.
// [Nur direkt nach einem erfolgreichen UiCalendar_TypeToCreate sinnvoll:
//  wer schnell tippt, erzeugt mehrere Zeichen pro Frame, und die wuerden
//  sonst verloren gehen, weil das Titelfeld erst im naechsten Frame
//  aktiv wird.]
void UiCalendar_AppendPendingChar(unsigned int codepoint);

// --- Stiftwerkzeug / Bulk-Edit -----------------------------------------
// Mehrere Eintraege gemeinsam auswaehlen und gemeinsam bearbeiten
// (Zeit verschieben, Farbe, Loeschen). Aktivierung ueber den Stift-Knopf
// in der rechten Leiste; Esc waehlt ab.
void UiCalendar_PenToolSet(bool aktiv);
bool UiCalendar_PenToolActive();
// RADIERER (Navi 0): Wischen ueber Terminkoepfe loescht in den Papierkorb.
void UiCalendar_EraserSet(bool aktiv);
// "SOFORT VERSCHIEBEN" (Navi 0): Termine ohne vorherige Auswahl verschieben.
void UiCalendar_SofortVerschiebenSet(bool an);
bool UiCalendar_SofortVerschieben();
bool UiCalendar_EraserActive();
// PAPIERKORB-Inhalt fuer Navi 1 (dritter Abschnitt).
void UiCalendar_PapierkorbNavi();
// Im Zeichenmodus: Eintrag der Auswahl hinzufuegen/entfernen (Klick).
void UiCalendar_PenToggle(std::uint64_t id);
bool UiCalendar_PenIsSelected(std::uint64_t id);
int  UiCalendar_PenSelectedCount();
// Alle ausgewaehlten Eintraege um deltaSekunden verschieben (Bulk-Move).
void UiCalendar_PenShiftSelected(std::int64_t deltaSekunden);
// Alle ausgewaehlten Eintraege loeschen.
void UiCalendar_PenDeleteSelected();
// Auswahl leeren, Werkzeug bleibt aktiv oder wird abgewaehlt (esc=true).
void UiCalendar_PenClearSelection(bool auchDeaktivieren);


// --- Erinnerungen ---------------------------------------------------------
// Plant alle zukuenftigen Eintraege mit remindMin >= 0 im Scheduler ein.
// Wird nach jedem Speichern automatisch neu aufgebaut. Der Rueckruf laeuft
// im UI-Thread.
void UiCalendar_SetReminderHandler(std::function<void(const CalEntry&)> fn);

// ALLE ERINNERUNGEN BEIM SYSTEM ANMELDEN (Android: AlarmManager).
// [Der Handler oben laeuft nur, solange die App zeichnet. Das hier
//  wirkt auch bei geschlossener App -- siehe xbm_alarm.h. Nach jedem
//  Speichern und beim Start aufrufen.]
void UiCalendar_AlarmeNeuSetzen();

// Naechster Zeitpunkt eines (auch wiederkehrenden) Eintrags ab "ab";
// 0 = kein weiterer.
std::int64_t UiCalendar_NaechsterTermin(const CalEntry& e, std::int64_t ab);

// --- Farbpalette ----------------------------------------------------------
// Gemerkte Farben; die Oberflaeche zeigt sie zur Auswahl an.
std::vector<std::uint32_t>& UiCalendar_Palette();
void UiCalendar_PaletteMerken(std::uint32_t farbe);

// --- Actions / Erinnerungen ----------------------------------------------
// Neue Action an einem Event anlegen; liefert ihre id.
std::uint64_t UiCalendar_ActionNeu(std::uint64_t eventId, CalActionArt art,
                                   std::int64_t start, std::int32_t durMin = 0);
void UiCalendar_ActionLoeschen(std::uint64_t eventId, std::uint64_t actionId);
CalAction* UiCalendar_ActionFinden(std::uint64_t eventId, std::uint64_t actionId);

// ---------------------------------------------------------------------------
// EINHAENGEPUNKTE -- von der App gesetzt (main.cpp / main_android.cpp).
// Beide duerfen null bleiben; dann faellt das Modul auf Standardverhalten
// zurueck und funktioniert weiterhin, nur ohne App-Integration.
// ---------------------------------------------------------------------------
// Meldet der App-Gestenordnung "diese Zieh-Geste gehoert mir" (im Projekt:
// UiDragHandledThisFrame() = true). Ohne das stiehlt der globale
// Drag-Scroll das Ziehen von Eintraegen.
extern void (*UiCalendar_ClaimGesture)();
// Liefert bis zu maxPoints aktuelle Beruehrpunkte als x,y-Paare und gibt
// die Anzahl zurueck (im Projekt: UiTouches()). Fuer Pinch-Zoom. Auf dem
// Desktop schlicht null lassen -- dort zoomt Strg+Mausrad.
extern int (*UiCalendar_GetTouches)(float* xyOut, int maxPoints);

// Liefert die globale Einstellung UiScrollPinpoint() (ui_helpers.h) --
// true = Pinpoint (Kante antippen blaettert um), false = Wischen
// (waagerecht ziehen blaettert um). Aus demselben Grund verdrahtet wie
// die beiden Funktionen oben: ui_calendar bindet ui_helpers.h nicht
// direkt ein. Bleibt der Zeiger null, gilt "wischen" als Vorgabe.
extern bool (*UiCalendar_ScrollPinpoint)();

// Wird nach JEDER lokalen Aenderung aufgerufen (UiCalendar_Save()), die
// bei anderen Geraeten so schnell wie moeglich ankommen soll. Ruft --
// wenn verdrahtet -- XbmNetNode::AbgleichJetzt() auf, statt bis zu
// autoSyncMs (Vorgabe 3 s) auf den naechsten automatischen Blick zu
// warten. Bleibt der Zeiger null (Netzwerk nicht gestartet/eingebunden),
// passiert einfach nichts -- der normale periodische Abgleich bleibt
// die Rueckfallebene.
extern void (*UiCalendar_NetzAbgleichJetzt)();
// Eintraege neu aus timeline projizieren (nach einem Abgleich ueber das Netz).
void UiCalendar_TimelineNeuLaden();
// Inhalt von Navi 1: die Vorlagen (Tippen legt einen Termin daraus an).
void UiCalendar_VorlagenNavi();
// GRUPPEN / MEHRFACHAUSWAHL (Shift+Tipp) -- fuer die rechte Leiste.
int  UiCalendar_AuswahlAnzahl();          // Stift-/Shift-Auswahl plus Einzelauswahl
bool UiCalendar_GruppeAusgewaehlt();      // ausgewaehlter Termin ist eine Gruppe (oder Mitglied)
void UiCalendar_Gruppieren();
void UiCalendar_Ungruppieren();
void UiCalendar_Duplizieren();            // Auswahl kopieren, einen Tag spaeter (bzw. an die gelbe Zeitauswahl)
