// ---------------------------------------------------------------------------
// xbm_crash.cpp -- siehe xbm_crash.h.
// ---------------------------------------------------------------------------
#include "xbm_crash.h"
#include "xbm_paths.h"
#include "xbm_http.h"
#include "xbm_sched.h"
#include "xbm_version.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <deque>
#include <mutex>

#if defined(_WIN32)
  #ifndef WIN32_LEAN_AND_MEAN
  #define WIN32_LEAN_AND_MEAN
  #endif
  #include <windows.h>
  #include <io.h>
  #define XBM_WRITE(fd, p, n) _write(fd, p, (unsigned)(n))
  #define XBM_OPEN(path) _open(path, _O_WRONLY | _O_CREAT | _O_APPEND, 0644)
  #include <fcntl.h>
#else
  #include <fcntl.h>
  #include <signal.h>
  #include <unistd.h>
  #define XBM_WRITE(fd, p, n) ::write(fd, p, n)
  #define XBM_OPEN(path) ::open(path, O_WRONLY | O_CREAT | O_APPEND, 0644)
  #if defined(__ANDROID__)
    #include <unwind.h>
    #include <dlfcn.h>
    #include <android/log.h>
  #else
    #include <execinfo.h>
  #endif
#endif

namespace {

struct Zustand {
    std::string geraet;
    std::string monitorUrl;
    std::string logOrdner;
    std::string appLog;
    // VORAB festgelegter Berichtspfad -- im Handler darf nichts mehr
    // zusammengesetzt werden (kein malloc).
    char berichtPfad[1024] = {0};
    // Ringpuffer der letzten Logzeilen. [Im Handler wird er nur gelesen;
    //  das Schreiben ist mutex-geschuetzt. Ein Absturz WAEHREND des
    //  Schreibens koennte eine halbe Zeile zeigen -- verschmerzbar.]
    std::mutex m;
    std::deque<std::string> ring;
    std::atomic<bool> bereit{false};
};
Zustand& Z() { static Zustand z; return z; }

void schreib(int fd, const char* s) { XBM_WRITE(fd, s, std::strlen(s)); }
void schreibZahl(int fd, long long v) {
    char b[32]; int n = 0; bool neg = v < 0; if (neg) v = -v;
    char t[32]; int k = 0; do { t[k++] = (char)('0' + v % 10); v /= 10; } while (v);
    if (neg) b[n++] = '-';
    while (k) b[n++] = t[--k];
    b[n] = 0; schreib(fd, b);
}

#if defined(__ANDROID__)
struct UnwindZustand { void** puffer; int max; int n; };
_Unwind_Reason_Code unwindCb(struct _Unwind_Context* ctx, void* arg) {
    auto* st = (UnwindZustand*)arg;
    uintptr_t pc = _Unwind_GetIP(ctx);
    if (pc && st->n < st->max) st->puffer[st->n++] = (void*)pc;
    return st->n >= st->max ? _URC_END_OF_STACK : _URC_NO_REASON;
}
#endif

// Aufrufkette in den Descriptor -- async-signal-safe (kein malloc).
void aufrufketteSchreiben(int fd) {
#if defined(_WIN32)
    // Ohne DbgHelp keine Symbole; der Ausnahme-Filter unten schreibt
    // Code und Adresse, das reicht fuer ein erstes Eingrenzen.
    schreib(fd, "(Aufrufkette unter Windows: siehe Ausnahmeadresse oben)\n");
#elif defined(__ANDROID__)
    void* puffer[64]; UnwindZustand st{puffer, 64, 0};
    _Unwind_Backtrace(unwindCb, &st);
    for (int i = 0; i < st.n; ++i) {
        Dl_info info{};
        schreib(fd, "  #"); schreibZahl(fd, i); schreib(fd, "  ");
        if (dladdr(puffer[i], &info) && info.dli_fname) {
            schreib(fd, info.dli_fname); schreib(fd, " +0x");
            char hx[24]; std::snprintf(hx, sizeof(hx), "%lx",
                (unsigned long)((char*)puffer[i] - (char*)info.dli_fbase));
            schreib(fd, hx);
            if (info.dli_sname) { schreib(fd, "  "); schreib(fd, info.dli_sname); }
        } else {
            schreib(fd, "?");
        }
        schreib(fd, "\n");
    }
#else
    void* puffer[64];
    int n = backtrace(puffer, 64);
    backtrace_symbols_fd(puffer, n, fd);   // ausdruecklich signal-safe
#endif
}

void kopfSchreiben(int fd, const char* art, long long code) {
    schreib(fd, "=== XBM ABSTURZBERICHT ===\n");
    schreib(fd, "geraet: ");  schreib(fd, Z().geraet.c_str()); schreib(fd, "\n");
    schreib(fd, "version: "); schreibZahl(fd, XBM_APP_VERSION);  schreib(fd, "\n");
    schreib(fd, "plattform: ");
#if defined(_WIN32)
    schreib(fd, "windows");
#elif defined(__ANDROID__)
    schreib(fd, "android");
#else
    schreib(fd, "linux");
#endif
    schreib(fd, "\nart: "); schreib(fd, art); schreib(fd, " ("); schreibZahl(fd, code); schreib(fd, ")\n");
    schreib(fd, "zeit: "); schreibZahl(fd, (long long)std::time(nullptr)); schreib(fd, "\n");
}

void logzeilenSchreiben(int fd) {
    schreib(fd, "\n--- letzte Logzeilen ---\n");
    // Bewusst OHNE Sperre: im Handler nicht blockieren (der Absturz kann
    // im Logger selbst passiert sein, die Sperre haengt dann).
    for (auto& z : Z().ring) { schreib(fd, z.c_str()); schreib(fd, "\n"); }
}

#if !defined(_WIN32)
void signalHandler(int sig) {
    if (!Z().bereit.load()) _exit(128 + sig);
    int fd = XBM_OPEN(Z().berichtPfad);
    if (fd >= 0) {
        const char* name = sig == SIGSEGV ? "SIGSEGV" : sig == SIGABRT ? "SIGABRT"
                         : sig == SIGBUS ? "SIGBUS"  : sig == SIGFPE  ? "SIGFPE" : "SIGNAL";
        kopfSchreiben(fd, name, sig);
        schreib(fd, "\n--- Aufrufkette ---\n");
        aufrufketteSchreiben(fd);
        logzeilenSchreiben(fd);
        ::close(fd);
    }
    // Standardverhalten wiederherstellen und erneut ausloesen, damit
    // Coredump/Abbruch wie gewohnt passieren.
    signal(sig, SIG_DFL);
    raise(sig);
}
#else
LONG WINAPI ausnahmeFilter(EXCEPTION_POINTERS* ep) {
    if (!Z().bereit.load()) return EXCEPTION_CONTINUE_SEARCH;
    int fd = XBM_OPEN(Z().berichtPfad);
    if (fd >= 0) {
        kopfSchreiben(fd, "EXCEPTION", (long long)ep->ExceptionRecord->ExceptionCode);
        schreib(fd, "adresse: 0x");
        char hx[24]; std::snprintf(hx, sizeof(hx), "%p", ep->ExceptionRecord->ExceptionAddress);
        schreib(fd, hx); schreib(fd, "\n");
        HMODULE hm = GetModuleHandleA(nullptr);
        std::snprintf(hx, sizeof(hx), "%p", (void*)hm);
        schreib(fd, "modulbasis: 0x"); schreib(fd, hx);
        schreib(fd, "   (Offset = adresse - modulbasis; mit addr2line/objdump aufloesen)\n");
        schreib(fd, "\n--- Aufrufkette ---\n");
        aufrufketteSchreiben(fd);
        logzeilenSchreiben(fd);
        _close(fd);
    }
    return EXCEPTION_CONTINUE_SEARCH;
}
#endif

std::string gesendetOrdner() { return Z().logOrdner + "/gesendet"; }

void neuenBerichtspfadFestlegen() {
    // Eindeutig je Start: absturz-<zeit>-<pid>.txt. Wird nur beschrieben,
    // wenn es wirklich kracht.
    std::snprintf(Z().berichtPfad, sizeof(Z().berichtPfad), "%s/absturz-%lld-%ld.txt",
                  Z().logOrdner.c_str(), (long long)std::time(nullptr),
#if defined(_WIN32)
                  (long)GetCurrentProcessId());
#else
                  (long)getpid());
#endif
}

}  // namespace

// ---------------------------------------------------------------------------
void XbmCrash_Init(const std::string& geraeteName, const std::string& monitorUrl) {
    Z().geraet     = geraeteName.empty() ? "unbenannt" : geraeteName;
    Z().monitorUrl = monitorUrl;
    Z().logOrdner  = XbmPaths_Sub("logs");
    XbmPaths_MakeDirs(Z().logOrdner);
    XbmPaths_MakeDirs(gesendetOrdner());
    Z().appLog = Z().logOrdner + "/app.log";
    neuenBerichtspfadFestlegen();
#if defined(_WIN32)
    SetUnhandledExceptionFilter(ausnahmeFilter);
#else
    signal(SIGSEGV, signalHandler);
    signal(SIGABRT, signalHandler);
    signal(SIGBUS,  signalHandler);
    signal(SIGFPE,  signalHandler);
    signal(SIGILL,  signalHandler);
#endif
    Z().bereit = true;
    XbmCrash_Log("Start, Version " + std::to_string(XBM_APP_VERSION));
    // Liegengebliebene Berichte im Hintergrund hochladen.
    if (!monitorUrl.empty())
        XbmSched_After(std::chrono::seconds(3), []() { XbmCrash_Senden(); }, XbmRun::Pool);
}

void XbmCrash_Log(const std::string& zeile) {
    char ts[32]; std::time_t t = std::time(nullptr); std::tm tmv{};
#if defined(_WIN32)
    localtime_s(&tmv, &t);
#else
    localtime_r(&t, &tmv);
#endif
    std::strftime(ts, sizeof(ts), "%H:%M:%S ", &tmv);
    const std::string z = ts + zeile;
    {
        std::lock_guard<std::mutex> g(Z().m);
        Z().ring.push_back(z);
        if (Z().ring.size() > 200) Z().ring.pop_front();
    }
    if (!Z().appLog.empty())
        if (std::FILE* f = std::fopen(Z().appLog.c_str(), "ab")) {
            std::fputs(z.c_str(), f); std::fputc('\n', f); std::fclose(f);
        }
#if defined(__ANDROID__)
    __android_log_print(ANDROID_LOG_INFO, "xbm", "%s", zeile.c_str());
#endif
}

void XbmCrash_Melden(const std::string& titel, const std::string& details) {
    if (Z().logOrdner.empty()) return;
    char pfad[1024];
    std::snprintf(pfad, sizeof(pfad), "%s/fehler-%lld.txt", Z().logOrdner.c_str(),
                  (long long)std::time(nullptr));
    if (std::FILE* f = std::fopen(pfad, "wb")) {
        std::fprintf(f, "=== XBM FEHLERBERICHT ===\ngeraet: %s\nversion: %d\ntitel: %s\nzeit: %lld\n\n%s\n",
                     Z().geraet.c_str(), XBM_APP_VERSION, titel.c_str(),
                     (long long)std::time(nullptr), details.c_str());
        std::fprintf(f, "\n--- letzte Logzeilen ---\n");
        std::lock_guard<std::mutex> g(Z().m);
        for (auto& z : Z().ring) std::fprintf(f, "%s\n", z.c_str());
        std::fclose(f);
    }
    XbmCrash_Log("FEHLER: " + titel);
    if (!Z().monitorUrl.empty())
        XbmSched_After(std::chrono::seconds(0), []() { XbmCrash_Senden(); }, XbmRun::Pool);
}

int XbmCrash_Senden() {
    if (Z().monitorUrl.empty() || Z().logOrdner.empty()) return 0;
    int n = 0;
    for (const std::string& name : XbmPaths_ListFiles(Z().logOrdner, ".txt")) {
        if (name.rfind("absturz-", 0) != 0 && name.rfind("fehler-", 0) != 0) continue;
        const std::string pfad = Z().logOrdner + "/" + name;
        // Eigenen, noch offenen Bericht dieses Laufs NICHT anfassen.
        if (pfad == Z().berichtPfad) continue;
        std::string inhalt;
        if (std::FILE* f = std::fopen(pfad.c_str(), "rb")) {
            char b[4096]; std::size_t r;
            while ((r = std::fread(b, 1, sizeof(b), f)) > 0) inhalt.append(b, r);
            std::fclose(f);
        }
        if (inhalt.empty()) continue;
        XbmHttpAntwort a = XbmHttp("POST", Z().monitorUrl, {},
                                   {"Content-Type: text/plain; charset=utf-8",
                                    "X-Xbm-Geraet: " + Z().geraet,
                                    "X-Xbm-Datei: " + name},
                                   inhalt);
        if (a.fehler.empty() && a.status >= 200 && a.status < 300) {
            XbmPaths_KopiereDatei(pfad, gesendetOrdner() + "/" + name);
            std::remove(pfad.c_str());
            ++n;
        } else {
            break;   // Monitor nicht erreichbar -- beim naechsten Mal wieder
        }
    }
    if (n) XbmCrash_Log(std::to_string(n) + " Bericht(e) an den Monitor gesendet");
    return n;
}

std::string XbmCrash_MonitorUrl() { return Z().monitorUrl; }
void XbmCrash_SetMonitorUrl(const std::string& url) { Z().monitorUrl = url; }
std::string XbmCrash_LogOrdner() { return Z().logOrdner; }
std::vector<std::string> XbmCrash_Berichte() {
    auto v = XbmPaths_ListFiles(Z().logOrdner, ".txt");
    std::sort(v.rbegin(), v.rend());
    return v;
}
