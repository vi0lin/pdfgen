// effects_gl.cpp -- siehe effects_gl.h
//
// Desktop-GL-Loading: KEIN glad! Der Desktop-Pfad dieser App initialisiert
// glad nie (kein HelloImGui-Runner, nur die ImGui-Backends mit eigenem
// Mini-Loader). glad-Funktionszeiger waeren daher NULL -> Segfault beim
// ersten glCreateShader (genau der Linux-Segfault / Windows-Crash nach
// "Win32Window::Create OK"). Stattdessen laedt dieses Modul seine ~23
// benoetigten GL-Funktionen selbst: Linux via glfwGetProcAddress,
// Windows via wglGetProcAddress + opengl32.dll-Fallback. GL-1.1-Funktionen
// (glGenTextures, glTexImage2D, ...) kommen direkt aus der gelinkten
// GL-Library. Schlaegt das Laden fehl, werden die Effekte deaktiviert
// statt zu crashen.

#include "effects_gl.h"
#include "ui_navi.h"
#include "ui_helpers.h"
#include "xbm_update.h"
#include "xbm_crash.h"
#include "xbm_paths.h"
#include "xbm_version.h"
#include "ui_pages.h"
#include "imgui.h"
#include <cstdio>
#include <cmath>
#include <cstdint>

#if defined(__ANDROID__)
  #include <GLES3/gl3.h>
  #define EFFECTS_GLSL_VERSION "#version 300 es\nprecision highp float;\n"
  static bool LoadGlFunctions() { return true; } // GLES3 direkt gelinkt
#else
  #define EFFECTS_GLSL_VERSION "#version 330 core\n"
  #if defined(_WIN32)
    #ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
    #endif
    #include <windows.h>
  #endif
  #include <GL/gl.h>            // Basistypen + GL-1.1-Funktionen
  #if !defined(_WIN32)
    #define GLFW_INCLUDE_NONE
    #include <GLFW/glfw3.h>     // glfwGetProcAddress (Linux/macOS)
  #endif

  // ---- fehlende Typen/Konstanten (gl.h ist nur GL 1.1) --------------------
  typedef char GLchar;
  #ifndef APIENTRYP
  #define APIENTRYP APIENTRY *
  #endif
  #ifndef GL_FRAGMENT_SHADER
  #define GL_FRAGMENT_SHADER      0x8B30
  #define GL_VERTEX_SHADER        0x8B31
  #define GL_COMPILE_STATUS       0x8B81
  #define GL_LINK_STATUS          0x8B82
  #endif
  #ifndef GL_FRAMEBUFFER
  #define GL_FRAMEBUFFER          0x8D40
  #define GL_COLOR_ATTACHMENT0    0x8CE0
  #define GL_FRAMEBUFFER_COMPLETE 0x8CD5
  #define GL_FRAMEBUFFER_BINDING  0x8CA6
  #endif
  #ifndef GL_CLAMP_TO_EDGE
  #define GL_CLAMP_TO_EDGE        0x812F
  #endif

  // ---- Funktionszeiger fuer alles jenseits von GL 1.1 ---------------------
  #define EFFECTS_GL_FUNCS(X) \
    X(GLuint, CreateShader, (GLenum)) \
    X(void,   ShaderSource, (GLuint, GLsizei, const GLchar* const*, const GLint*)) \
    X(void,   CompileShader, (GLuint)) \
    X(void,   GetShaderiv, (GLuint, GLenum, GLint*)) \
    X(void,   GetShaderInfoLog, (GLuint, GLsizei, GLsizei*, GLchar*)) \
    X(void,   DeleteShader, (GLuint)) \
    X(GLuint, CreateProgram, (void)) \
    X(void,   AttachShader, (GLuint, GLuint)) \
    X(void,   LinkProgram, (GLuint)) \
    X(void,   GetProgramiv, (GLuint, GLenum, GLint*)) \
    X(void,   GetProgramInfoLog, (GLuint, GLsizei, GLsizei*, GLchar*)) \
    X(void,   DeleteProgram, (GLuint)) \
    X(void,   UseProgram, (GLuint)) \
    X(GLint,  GetUniformLocation, (GLuint, const GLchar*)) \
    X(void,   Uniform1f, (GLint, GLfloat)) \
    X(void,   Uniform2fv, (GLint, GLsizei, const GLfloat*)) \
    X(void,   GenVertexArrays, (GLsizei, GLuint*)) \
    X(void,   BindVertexArray, (GLuint)) \
    X(void,   DeleteVertexArrays, (GLsizei, const GLuint*)) \
    X(void,   GenFramebuffers, (GLsizei, GLuint*)) \
    X(void,   BindFramebuffer, (GLenum, GLuint)) \
    X(void,   FramebufferTexture2D, (GLenum, GLenum, GLenum, GLuint, GLint)) \
    X(GLenum, CheckFramebufferStatus, (GLenum)) \
    X(void,   DeleteFramebuffers, (GLsizei, const GLuint*))

  #define DECLARE_PTR(ret, name, args) \
      typedef ret (APIENTRYP PFN_eff_##name) args; \
      static PFN_eff_##name eff_##name = nullptr;
  EFFECTS_GL_FUNCS(DECLARE_PTR)
  #undef DECLARE_PTR

  // Kurznamen auf die Zeiger mappen (nur fuer diese Datei)
  #define glCreateShader           eff_CreateShader
  #define glShaderSource           eff_ShaderSource
  #define glCompileShader          eff_CompileShader
  #define glGetShaderiv            eff_GetShaderiv
  #define glGetShaderInfoLog       eff_GetShaderInfoLog
  #define glDeleteShader           eff_DeleteShader
  #define glCreateProgram          eff_CreateProgram
  #define glAttachShader           eff_AttachShader
  #define glLinkProgram            eff_LinkProgram
  #define glGetProgramiv           eff_GetProgramiv
  #define glGetProgramInfoLog      eff_GetProgramInfoLog
  #define glDeleteProgram          eff_DeleteProgram
  #define glUseProgram             eff_UseProgram
  #define glGetUniformLocation     eff_GetUniformLocation
  #define glUniform1f              eff_Uniform1f
  #define glUniform2fv             eff_Uniform2fv
  #define glGenVertexArrays        eff_GenVertexArrays
  #define glBindVertexArray        eff_BindVertexArray
  #define glDeleteVertexArrays     eff_DeleteVertexArrays
  #define glGenFramebuffers        eff_GenFramebuffers
  #define glBindFramebuffer        eff_BindFramebuffer
  #define glFramebufferTexture2D   eff_FramebufferTexture2D
  #define glCheckFramebufferStatus eff_CheckFramebufferStatus
  #define glDeleteFramebuffers     eff_DeleteFramebuffers

  static void* GetGlProc(const char* name) {
  #if defined(_WIN32)
      void* p = (void*)wglGetProcAddress(name);
      // wglGetProcAddress liefert fuer manche Treiber 0/1/2/3/-1 als "Fehler"
      intptr_t v = (intptr_t)p;
      if (v == 0 || v == 1 || v == 2 || v == 3 || v == -1) {
          static HMODULE gl = LoadLibraryA("opengl32.dll");
          p = gl ? (void*)GetProcAddress(gl, name) : nullptr;
      }
      return p;
  #else
      return (void*)glfwGetProcAddress(name);
  #endif
  }

  static bool LoadGlFunctions() {
      static int state = 0; // 0=ungeprueft, 1=ok, -1=fehlgeschlagen
      if (state != 0) return state == 1;
      bool ok = true;
      char buf[64];
      #define LOAD_PTR(ret, name, args) \
          snprintf(buf, sizeof(buf), "gl%s", #name); \
          eff_##name = (PFN_eff_##name)GetGlProc(buf); \
          if (!eff_##name) { \
              fprintf(stderr, "[effects] GL-Funktion fehlt: %s\n", buf); \
              ok = false; \
          }
      EFFECTS_GL_FUNCS(LOAD_PTR)
      #undef LOAD_PTR
      state = ok ? 1 : -1;
      if (!ok) fprintf(stderr, "[effects] Effekte deaktiviert (GL-Loader unvollstaendig)\n");
      return ok;
  }
#endif // !__ANDROID__

namespace {

GLuint compile(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1024];
        glGetShaderInfoLog(s, sizeof(log), nullptr, log);
        fprintf(stderr, "[effects] shader compile error: %s\n", log);
        glDeleteShader(s);
        return 0;
    }
    return s;
}

GLuint linkProg(const char* vs_src, const char* fs_src) {
    GLuint vs = compile(GL_VERTEX_SHADER,   vs_src);
    GLuint fs = compile(GL_FRAGMENT_SHADER, fs_src);
    if (!vs || !fs) return 0;
    GLuint p = glCreateProgram();
    glAttachShader(p, vs);
    glAttachShader(p, fs);
    glLinkProgram(p);
    glDeleteShader(vs);
    glDeleteShader(fs);
    GLint ok = 0;
    glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[1024];
        glGetProgramInfoLog(p, sizeof(log), nullptr, log);
        fprintf(stderr, "[effects] program link error: %s\n", log);
        glDeleteProgram(p);
        return 0;
    }
    return p;
}

struct Effect {
    GLuint fbo = 0, tex = 0, vao = 0, prog = 0;
    int    w = 0, h = 0;
    GLint  uTime = -1, uAngle = -1, uAspect = -1, uMouse = -1;

    bool Init(int width, int height, const char* vs, const char* fs) {
        if (!LoadGlFunctions()) return false;
        w = width; h = height;
        prog = linkProg(vs, fs);
        if (!prog) return false;
        uTime   = glGetUniformLocation(prog, "uTime");
        uAngle  = glGetUniformLocation(prog, "uAngle");
        uAspect = glGetUniformLocation(prog, "uAspect");
        uMouse  = glGetUniformLocation(prog, "uMouse");

        glGenVertexArrays(1, &vao);

        glGenTextures(1, &tex);
        glBindTexture(GL_TEXTURE_2D, tex);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0,
                     GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

        glGenFramebuffers(1, &fbo);
        glBindFramebuffer(GL_FRAMEBUFFER, fbo);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                               GL_TEXTURE_2D, tex, 0);
        bool complete =
            glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        return complete;
    }

    void Render(float time, float angle, int vertexCount,
                float mx = 0.5f, float my = 0.5f) {
        GLint prevFbo = 0, prevVp[4];
        glGetIntegerv(GL_FRAMEBUFFER_BINDING, &prevFbo);
        glGetIntegerv(GL_VIEWPORT, prevVp);

        glBindFramebuffer(GL_FRAMEBUFFER, fbo);
        glViewport(0, 0, w, h);
        glClearColor(0, 0, 0, 0);
        glClear(GL_COLOR_BUFFER_BIT);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glUseProgram(prog);
        if (uTime   >= 0) glUniform1f(uTime, time);
        if (uAngle  >= 0) glUniform1f(uAngle, angle);
        if (uAspect >= 0) glUniform1f(uAspect, (float)w / (float)h);
        if (uMouse  >= 0) { GLfloat mv[2] = {mx, my};
                            glUniform2fv(uMouse, 1, mv); }
        glBindVertexArray(vao);
        glDrawArrays(GL_TRIANGLES, 0, vertexCount);
        glBindVertexArray(0);
        glUseProgram(0);

        glBindFramebuffer(GL_FRAMEBUFFER, (GLuint)prevFbo);
        glViewport(prevVp[0], prevVp[1], prevVp[2], prevVp[3]);
    }

    void Destroy() {
        if (prog) glDeleteProgram(prog);
        if (vao)  glDeleteVertexArrays(1, &vao);
        if (tex)  glDeleteTextures(1, &tex);
        if (fbo)  glDeleteFramebuffers(1, &fbo);
        *this = Effect{};
    }
};

const char* kFullscreenVs = EFFECTS_GLSL_VERSION R"(
out vec2 vUV;
void main() {
    vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);
    vUV = p;
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
})";

const char* kRainFs = EFFECTS_GLSL_VERSION R"(
in vec2 vUV;
out vec4 frag;
uniform float uTime;
float hash(float n) { return fract(sin(n * 127.1) * 43758.5453); }
void main() {
    float cols  = 42.0;
    float col   = floor(vUV.x * cols);
    float rnd   = hash(col);
    float speed = 0.55 + rnd * 0.9;
    float y     = fract(vUV.y + uTime * speed + rnd * 7.0);
    float xin   = fract(vUV.x * cols);
    float core  = smoothstep(0.42, 0.5, xin) * smoothstep(0.58, 0.5, xin);
    float drop  = smoothstep(0.0, 0.12, y) * smoothstep(0.28, 0.12, y);
    float a     = drop * core * (0.35 + 0.65 * rnd);
    frag = vec4(0.62, 0.78, 1.0, a);
})";

const char* kSpinVs = EFFECTS_GLSL_VERSION R"(
out vec3 vCol;
uniform float uAngle;
uniform float uAspect;
void main() {
    vec2 P[3] = vec2[3](vec2(0.0, 0.62), vec2(-0.55, -0.4), vec2(0.55, -0.4));
    vec3 C[3] = vec3[3](vec3(1.0,0.35,0.35), vec3(0.35,1.0,0.5), vec3(0.4,0.55,1.0));
    vec2 p = P[gl_VertexID];
    float s = sin(uAngle), c = cos(uAngle);
    p = mat2(c, -s, s, c) * p;
    p.x /= uAspect;
    vCol = C[gl_VertexID];
    gl_Position = vec4(p, 0.0, 1.0);
})";

const char* kSpinFs = EFFECTS_GLSL_VERSION R"(
in vec3 vCol;
out vec4 frag;
void main() { frag = vec4(vCol, 1.0); })";

// Hintergrund: fliessender Farbverlauf-Plasma, Glow folgt Maus/Touch
const char* kBgFs = EFFECTS_GLSL_VERSION R"(
in vec2 vUV; out vec4 frag;
uniform float uTime; uniform vec2 uMouse;
void main() {
    vec2 p = vUV * 2.0 - 1.0;
    float t = uTime * 0.25;
    float v = sin(p.x*3.0+t) + sin(p.y*2.5-t*1.3)
            + sin((p.x+p.y)*2.0+t*0.7);
    vec3 col = 0.5 + 0.5*cos(vec3(0.0,2.1,4.2) + v + t);
    // Glow um den Zeiger (uMouse in 0..1, y unten=0)
    float d = length(vUV - uMouse);
    col += vec3(0.25,0.35,0.6) * exp(-d*6.0);
    frag = vec4(col * 0.35, 1.0);   // gedimmt, damit UI lesbar bleibt
})";

// Overlay: animierte Scanline-Welle (kleiner Bildschirmteil)
const char* kOverlayFs = EFFECTS_GLSL_VERSION R"(
in vec2 vUV; out vec4 frag;
uniform float uTime;
void main() {
    float wave = sin(vUV.x*12.0 + uTime*3.0)*0.5+0.5;
    float band = smoothstep(0.06,0.0,abs(vUV.y-(0.5+0.35*sin(vUV.x*4.0+uTime))));
    vec3 col = mix(vec3(0.1,0.9,0.7), vec3(0.9,0.4,1.0), wave);
    frag = vec4(col, band*0.85);
})";

Effect g_bg, g_overlay;
int    g_bgState = 0, g_overlayState = 0;

Effect g_rain, g_spin;
int    g_rainState = 0, g_spinState = 0; // 0=neu, 1=ok, -1=fehlgeschlagen
float  g_spinAngle = 0.0f, g_spinSpeed = 1.2f;

} // namespace

void EffectsGl_ShowRainWindow(bool* open) {
    EffectsGl_ValidateGpu();
    if (open && !*open) return;
    if (g_rainState == 0)
        g_rainState = g_rain.Init(480, 300, kFullscreenVs, kRainFs) ? 1 : -1;
    if (g_rainState < 0) return;

    g_rain.Render((float)ImGui::GetTime(), 0.0f, 3);

    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.06f, 0.06f, 0.09f, 0.60f));
    // Standardhoehe ~20vh (ein Fuenftel der Arbeitsflaeche).
    ImGui::SetNextWindowSize(
        ImVec2(500, ImGui::GetMainViewport()->WorkSize.y * 0.20f),
        ImGuiCond_FirstUseEver);
    if (ImGui::Begin("Rain", open, UiWinFlags("Rain"))) {
        ImVec2 avail = ImGui::GetContentRegionAvail();
        // ZWEI FALLEN, die BEIDE beim Ein-/Ausfahren der Tastatur
        // zuschlagen (das Fenster wird dabei kurz winzig):
        //  1. tex == 0 -> ImGui zeichnet mit der ZULETZT gebundenen
        //     GL-Textur, und das ist der Zeichensatz-Atlas: er erscheint
        //     riesig und verzerrt ueber dem Hintergrund.
        //  2. negative/0-Groesse -> entartetes Rechteck (gespiegelt,
        //     bildschirmfuellend).
        if (avail.x < 1.0f) avail.x = 1.0f;
        if (avail.y < 1.0f) avail.y = 1.0f;
        if (g_rain.tex != 0)
            ImGui::Image((ImTextureID)(intptr_t)g_rain.tex, avail,
                         ImVec2(0, 1), ImVec2(1, 0));
        else
            ImGui::Dummy(avail);
    }
    ImGui::End();
    ImGui::PopStyleColor();
}

void EffectsGl_ShowSpinWindow(bool* open) {
    EffectsGl_ValidateGpu();
    if (open && !*open) return;
    if (g_spinState == 0)
        g_spinState = g_spin.Init(360, 360, kSpinVs, kSpinFs) ? 1 : -1;
    if (g_spinState < 0) return;

    float dt = ImGui::GetIO().DeltaTime;
    g_spinAngle += g_spinSpeed * dt;
    g_spinSpeed += (1.2f - g_spinSpeed) * 0.5f * dt;

    g_spin.Render(0.0f, g_spinAngle, 3);

    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.06f, 0.06f, 0.09f, 0.60f));
    ImGui::SetNextWindowSize(
        ImVec2(380, ImGui::GetMainViewport()->WorkSize.y * 0.20f),
        ImGuiCond_FirstUseEver);   // ~20vh
    if (ImGui::Begin("Spin (ziehen = drehen)", open,
                     UiWinFlags("Spin (ziehen = drehen)"))) {
        ImVec2 avail = ImGui::GetContentRegionAvail();
        // FLACKER-FIX: Die Slider-Hoehe wird bei der Kantenberechnung
        // RESERVIERT. Vorher: bei knapper Hoehe ragte Bild+Slider ueber
        // den Inhalt -> Scrollbalken erscheint -> Breite schrumpft ->
        // kleineres side -> passt wieder -> Balken weg -> Endlos-
        // Oszillation zwischen zwei Layouts ("doppelt versetzt
        // gezeichnet", flackernder Balken).
        float sliderH = ImGui::GetFrameHeightWithSpacing();
        float availY = avail.y - sliderH;
        float side = avail.x < availY ? avail.x : availY;
        if (side < 32.0f) side = 32.0f;
        if (g_spin.tex != 0)
            ImGui::Image((ImTextureID)(intptr_t)g_spin.tex,
                         ImVec2(side, side), ImVec2(0, 1), ImVec2(1, 0));
        else
            ImGui::Dummy(ImVec2(side, side));   // s. Rain: Atlas-Falle
        if (ImGui::IsItemActive()) {
            g_spinSpeed += ImGui::GetIO().MouseDelta.x * 0.05f;
        }
        ImGui::SliderFloat("Tempo", &g_spinSpeed, -12.0f, 12.0f, "%.1f");
    }
    ImGui::End();
    ImGui::PopStyleColor();
}

void EffectsGl_ValidateGpu() {
    // KONTEXTVERLUST: Wechselt man aus der App heraus, kann Android den
    // GL-Kontext wegwerfen. Die C++-seitigen GLuint-NUMMERN bleiben
    // dabei stehen, die Objekte dahinter sind aber weg. Zeichnet man
    // damit weiter, greift der Treiber auf irgendeine noch gebundene
    // Textur zurueck -- typischerweise den ZEICHENSATZ-ATLAS: verzerrte
    // weisse Buchstaben ueber dem Hintergrund, schwarze Effektfenster.
    //
    // glIsTexture() beantwortet genau diese Frage. Ist die Nummer
    // ungueltig, werden die Zustaende auf 0 zurueckgesetzt -- OHNE
    // glDelete* (die Namen existieren ja nicht mehr) -- und der naechste
    // Frame baut alles sauber neu auf.
    auto dead = [](GLuint t) { return t != 0 && glIsTexture(t) == GL_FALSE; };
    if (g_rainState == 1 && dead(g_rain.tex)) { g_rain = Effect{}; g_rainState = 0; }
    if (g_spinState == 1 && dead(g_spin.tex)) { g_spin = Effect{}; g_spinState = 0; }
    if (g_bgState == 1 && dead(g_bg.tex))     { g_bg = Effect{};   g_bgState = 0; }
    if (g_overlayState == 1 && dead(g_overlay.tex))
                                              { g_overlay = Effect{}; g_overlayState = 0; }
}

void EffectsGl_Shutdown() {
    if (g_rainState == 1) { g_rain.Destroy(); g_rainState = 0; }
    if (g_spinState == 1) { g_spin.Destroy(); g_spinState = 0; }
}

// ===========================================================================
// Dreiecks-Fenster (reines ImGui-DrawList-Rendering, kein GL noetig --
// dadurch garantiert identisch auf Linux, Windows und Android)
// ===========================================================================
namespace {
void DrawListTriangle(ImDrawList* dl, ImVec2 center, float r, ImU32 col) {
    ImVec2 a(center.x,            center.y - r);
    ImVec2 b(center.x - r * 0.9f, center.y + r * 0.7f);
    ImVec2 c(center.x + r * 0.9f, center.y + r * 0.7f);
    dl->AddTriangleFilled(a, b, c, col);
    dl->AddTriangle(a, b, c, IM_COL32(255, 255, 255, 160), 2.0f);
}
} // namespace

void EffectsGl_ShowTriangleNormal(bool* open) {
    if (open && !*open) return;
    ImGui::SetNextWindowSize(
        ImVec2(260, ImGui::GetMainViewport()->WorkSize.y * 0.20f),
        ImGuiCond_FirstUseEver);   // ~20vh
    // NoScrollbar: Das Fenster ist exakt so gross wie das Dreieck --
    // die (global gesetzte) horizontale Leiste hatte hier nichts zu
    // scrollen und stoerte nur optisch.
    if (ImGui::Begin("Dreieck (normal)", open,
                     (UiWinFlags("Dreieck (normal)")
                      & ~ImGuiWindowFlags_HorizontalScrollbar)
                     | ImGuiWindowFlags_NoScrollbar)) {
        ImVec2 p = ImGui::GetCursorScreenPos();
        ImVec2 avail = ImGui::GetContentRegionAvail();
        float r = (avail.x < avail.y ? avail.x : avail.y) * 0.4f;
        ImVec2 center(p.x + avail.x * 0.5f, p.y + avail.y * 0.5f);
        DrawListTriangle(ImGui::GetWindowDrawList(), center, r,
                         IM_COL32(90, 160, 255, 255));
        ImGui::Dummy(avail); // Platz belegen, normales Fensterverhalten
    }
    ImGui::End();
}

void EffectsGl_ShowTriangleOverlay(bool* open) {
    if (open && !*open) return;
    // Randlos, titellos, Hintergrund komplett transparent: sichtbar ist NUR
    // das Dreieck. Das Fenster ist exakt so gross wie das Dreieck; ziehen
    // auf dem Dreieck verschiebt es frei ueber den gesamten Viewport.
    // Ausserhalb dieses kleinen Fensters liegt nichts -> Klicks gehen dort
    // ganz normal an darunterliegende Fenster ("click-through ausser auf
    // dem Dreieck"). Auf dem Desktop-Overlay wirkt das wie ein frei
    // schwebendes Dreieck auf dem Bildschirm; in der APK identisch im
    // App-Viewport.
    const float kSize = 180.0f;
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration
                           | ImGuiWindowFlags_NoBackground
                           | ImGuiWindowFlags_AlwaysAutoResize
                           | ImGuiWindowFlags_NoFocusOnAppearing
                           | ImGuiWindowFlags_NoNav;
    ImGui::SetNextWindowPos(ImVec2(500, 200), ImGuiCond_FirstUseEver);
    if (ImGui::Begin("##triangle_overlay", open, flags)) {
        ImVec2 p = ImGui::GetCursorScreenPos();
        // Unsichtbarer Button in Dreiecksgroesse = Drag-Flaeche
        ImGui::InvisibleButton("tri_drag", ImVec2(kSize, kSize));
        bool active  = ImGui::IsItemActive();
        bool hovered = ImGui::IsItemHovered();
        // Drag-Vorfahrt anmelden: der globale Drag-Scroll (laeuft am
        // Frame-ENDE) respektiert das Flag im selben Frame und laesst
        // die Geste vollstaendig diesem Widget -- ohne das Flag stahl
        // die 12-px-Uebernahme den InvisibleButton (ClearActiveID) und
        // der Dreieck-Move stockte, waehrend die Hierarchie scrollte.
        // (Muster fuer JEDES kuenftige Custom-Drag-Widget.)
        if (active) UiDragHandledThisFrame() = true;
        if (active && ImGui::IsMouseDragging(ImGuiMouseButton_Left)) {
            ImVec2 d = ImGui::GetIO().MouseDelta;
            ImVec2 wp = ImGui::GetWindowPos();
            if (!ImGui::IsWindowDocked())   // gedockt: Layout hat Vorrang
                ImGui::SetWindowPos(ImVec2(wp.x + d.x, wp.y + d.y));
        }
        ImVec2 center(p.x + kSize * 0.5f, p.y + kSize * 0.5f);
        ImU32 col = active  ? IM_COL32(255, 210, 90, 255)
                  : hovered ? IM_COL32(255, 170, 70, 255)
                            : IM_COL32(240, 130, 60, 235);
        DrawListTriangle(ImGui::GetWindowDrawList(), center, kSize * 0.45f, col);
    }
    ImGui::End();
}


// ---------------------------------------------------------------------------
// 2.2  Vollbild-HINTERGRUND hinter allen ImGui-Fenstern.
//      Rendert in FBO und legt die Textur via BackgroundDrawList unter
//      die gesamte UI. Maus/Touch steuert den Glow (uMouse-Uniform).
// ---------------------------------------------------------------------------
static EffectsSettings g_fx;
EffectsSettings& EffectsGl_Settings() { return g_fx; }

// INHALT der frueheren "Effekt-Einstellungen" -- das eigene FENSTER ist
// abgeschafft; die App-Einstellungen (Navi 0, unten) zeigen diesen
// Inhalt. Bewusst OHNE die Fenster-Eigenschaften (UiDrawWindowPropsUI):
// die wohnen laengst am Zahnrad der einzelnen Fenster.
void EffectsGl_SettingsContent() {
    {   // ---- Eingabe -------------------------------------------------
        ImGui::TextUnformatted("Eingabe");
#if !defined(__ANDROID__)
        {   // Nur Desktop: Android ist immer Vollflaeche.
            bool fsA = UiAppFullscreen();
            if (ImGui::Checkbox("Vollbild (statt Fenster)", &fsA)) {
                UiAppFullscreen() = fsA;
                if (ui_pages_detail::UiPagesPersistHook)
                    ui_pages_detail::UiPagesPersistHook();
            }
        }
#endif
        {   // Dock-Kanten ALLER Seiten an die Navis (Override)
            bool st = UiDockStickAll();
            if (ImGui::Checkbox("Dock-Kanten an Navis (alle Seiten)", &st)) {
                UiDockStickAll() = st;
                if (ui_pages_detail::UiPagesPersistHook)
                    ui_pages_detail::UiPagesPersistHook();
            }
        }
        bool kb = UiKeyboardEnabled();
        if (ImGui::Checkbox("Android-Tastatur verwenden", &kb)) {
            UiKeyboardEnabled() = kb;
            if (!kb) UiRequestHideKeyboard() = true;  // sofort schliessen
            if (ui_pages_detail::UiPagesPersistHook)
                ui_pages_detail::UiPagesPersistHook();
        }
        ImGui::SameLine(); ImGui::TextDisabled("(?)");
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Aus: Die Bildschirmtastatur wird nie\n"
                              "eingeblendet. Eingaben ueber eine\n"
                              "Bluetooth-Tastatur funktionieren weiter.");
        ImGui::Separator();

        // ---- IN-APP-UPDATE -------------------------------------------------
        // [Ein Knopf, der das Update fuer DIESE Plattform anwendet -- xbm_update
        //  entscheidet selbst, was das heisst (Linux: Datei tauschen, Windows:
        //  Nachlauf-Script + Neustart, Android: System-Installer). Daneben
        //  die aktuelle Version und, falls vorhanden, die verfuegbare.]
        {
            ImGui::TextUnformatted("Update");
            const XbmUpdateInfo u = XbmUpdate_Verfuegbar();
            const bool busy = XbmUpdate_Beschaeftigt();
            const std::string installiert = XbmUpdate_VersionText(XBM_APP_VERSION);
            if (u.version > 0) {
                ImGui::Text("Installiert: %s", installiert.c_str());
                ImGui::TextColored(ImVec4(0.4f, 0.9f, 0.4f, 1.0f),
                                   "Verfuegbar:  %s", XbmUpdate_VersionText(u.version).c_str());
                if (!u.notes.empty()) ImGui::TextDisabled("%s", u.notes.c_str());
                ImGui::BeginDisabled(busy);
                if (ImGui::Button(busy ? "Update laeuft ..." : "Jetzt aktualisieren"))
                    XbmUpdate_Installieren();
                ImGui::EndDisabled();
            } else {
                ImGui::Text("Installiert: %s", installiert.c_str());
                ImGui::BeginDisabled(busy);
                if (ImGui::Button(busy ? "pruefe ..." : "Auf Updates pruefen"))
                    XbmUpdate_PruefenAsync(
                        "http://192.168.1.69:3000/releases/raw/branch/main/release.json",
                        /*sofort=*/true);
                ImGui::EndDisabled();
            }
            const std::string m = XbmUpdate_LetzteMeldung();
            if (!m.empty()) { ImGui::SameLine(); ImGui::TextDisabled("%s", m.c_str()); }

            // AUTO-UPDATE -- gespeichert, gilt ab dem naechsten Start sofort.
            bool autoAn = XbmUpdate_Auto();
            if (ImGui::Checkbox("Automatisch aktualisieren, sobald eine neue Version erkannt wird",
                                &autoAn)) {
                UiFlagSet("update.auto", autoAn);
                XbmUpdate_SetAuto(autoAn);
            }
            if (ImGui::IsItemHovered())
                ImGui::SetTooltip(
                    "Prueft beim Start und danach alle 30 Minuten.\n"
#if defined(__ANDROID__)
                    "Android: der System-Installer fragt trotzdem nach --\n"
                    "das laesst Android nicht anders zu."
#elif defined(_WIN32)
                    "Windows: die App startet dafuer kurz neu\n"
                    "(ungespeicherte Kalenderaenderungen werden vorher gesichert)."
#else
                    "Linux: die neue Fassung wirkt nach dem naechsten Neustart."
#endif
                );
        }
        ImGui::Separator();

        // ---- FEHLERBERICHTE / MONITOR ---------------------------------------
        // [Abstuerze und gemeldete Fehler landen als Bericht unter
        //  <UserData>/logs und gehen automatisch an den Monitor-Server
        //  (monitor_server.py). Die URL wird als Text "monitor.url"
        //  gespeichert und beim naechsten Start uebernommen.]
        {
            ImGui::TextUnformatted("Fehlerberichte");
            static char url[256]; static bool urlGeladen = false;
            if (!urlGeladen) {
                std::snprintf(url, sizeof(url), "%s", UiTextGet("monitor.url").c_str());
                urlGeladen = true;
            }
            ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x * 0.7f);
            if (ImGui::InputTextWithHint("##monitorurl", "http://192.168.1.69:3010/bericht",
                                         url, sizeof(url))) {
                UiTextSet("monitor.url", url);
                XbmCrash_SetMonitorUrl(url);
            }
            ImGui::SameLine();
            if (ImGui::SmallButton("jetzt senden")) {
                const int n = XbmCrash_Senden();
                XbmCrash_Log("Berichte von Hand gesendet: " + std::to_string(n));
            }
            const auto berichte = XbmCrash_Berichte();
            ImGui::TextDisabled("%zu Bericht(e) lokal in %s", berichte.size(),
                                XbmCrash_LogOrdner().c_str());
            if (!berichte.empty() && ImGui::TreeNode("Berichte anzeigen")) {
                for (const auto& b : berichte) {
                    ImGui::PushID(b.c_str());
                    ImGui::Bullet(); ImGui::SameLine(); ImGui::TextUnformatted(b.c_str());
                    ImGui::SameLine();
                    if (ImGui::SmallButton("oeffnen"))
                        XbmPaths_OeffnenExtern(XbmCrash_LogOrdner() + "/" + b);
                    ImGui::PopID();
                }
                ImGui::TreePop();
            }
            if (ImGui::SmallButton("Testbericht senden"))
                XbmCrash_Melden("Testbericht", "Von Hand aus den Einstellungen ausgeloest.");
        }
        ImGui::Separator();
    }
    {
        ImGui::TextUnformatted("Hintergrund-Shader");
        ImGui::Checkbox("sichtbar##bg", &g_fx.bgVisible);
        ImGui::SliderFloat("Deckkraft##bg", &g_fx.bgOpacity, 0.0f, 100.0f, "%.0f%%");
        ImGui::Checkbox("Fenster-Modus (statt Vollbild)", &g_fx.bgWindowed);
        ImGui::Separator();
        ImGui::TextUnformatted("Sinuswellen-Overlay");
        ImGui::Checkbox("sichtbar##ov", &g_fx.ovVisible);
        ImGui::SliderFloat("Deckkraft##ov", &g_fx.ovOpacity, 0.0f, 100.0f, "%.0f%%");
        ImGui::Separator();
        ImGui::Checkbox("Click-through (Desktop klickbar)", &g_fx.clickThrough);
        ImGui::SetItemTooltip(
            "Klicks auf FREIE Flaeche gehen an das Betriebssystem.\n"
            "Frei ist: der Seiten-Hintergrund und leere Bereiche des\n"
            "DockSpace. Fenster, Leisten und Knoepfe fangen weiterhin.");
        if (ImGui::Checkbox("Taskleiste beruecksichtigen",
                            &g_fx.respectTaskbar)) {
            // Wirkt beim naechsten Umschalten bzw. sofort ueber den
            // Geometrie-Abgleich in main.cpp.
            g_fx.taskbarDirty = true;
        }
        ImGui::SetItemTooltip(
            "AN:  Vollbild belegt nur den Arbeitsbereich (ohne Taskleiste),\n"
            "     normales Stapeln. Die obere Leiste bleibt sichtbar.\n"
            "AUS: Vollbild belegt den GANZEN Bildschirm und liegt ueber\n"
            "     allem, auch ueber der Taskleiste.");
        ImGui::Separator();
        ImGui::TextUnformatted("Canvas-Bereich (Desktop)");
        ImGui::RadioButton("Primaermonitor (schnell)", &g_fx.canvasMode, 0);
        ImGui::RadioButton("Alle Monitore", &g_fx.canvasMode, 1);
        ImGui::Checkbox("Docking (Andocken/Tabs)", &g_fx.dockingEnabled);
        if (ImGui::Checkbox("Layout sperren (Docking/Tabs/Resize aus)",
                            &g_fx.lockLayout))
            ui_pages_detail::UiPagesPersist();
        if (ImGui::Checkbox("Oranges Dreieck (transparent) anzeigen",
                            &g_fx.showTriangle))
            ui_pages_detail::UiPagesPersist();   // Sofort-Persistenz
        ImGui::Checkbox("Resize Affects Neighbors",
                        &g_fx.resizeAffectsNeighbors);
        ImGui::SetItemTooltip("Kompakt-Layout: beim Ziehen eines\n"
                              "Splitters verschieben sich dahinterliegende\n"
                              "Fenster kaskadierend mit (alle Richtungen),\n"
                              "statt an ihrer Mindestgroesse zu blockieren.");
        if (ImGui::Checkbox("Einstellungen buendig zum DockSpace",
                            &UiNavi::AppSheetAlignDock()))
            ui_pages_detail::UiPagesPersist();
        ImGui::SetItemTooltip(
            "AN:  Das Einstellungsblatt endet seitlich dort, wo der\n"
            "     DockSpace endet -- offene Navis bleiben frei.\n"
            "AUS: Es laeuft ueber die ganze Breite (bisheriges Verhalten).");
        ImGui::Checkbox("Multi-Viewport-Fenster (experimentell)", &g_fx.multiViewports);
        ImGui::Separator();
        if (ImGui::Button("Alle Fenster einsammeln"))
            UiGatherAllWindows();
        ImGui::SetItemTooltip("Holt Fenster zurueck, die ausserhalb des\n"
                              "sichtbaren Canvas-Bereichs liegen (z.B. nach\n"
                              "Umschalten Primaermonitor <-> alle Monitore).");
    }
}

void EffectsGl_AppendInstanceInfo() {
    ImGui::Separator();
    ImGui::TextUnformatted("Render-Instanzen:");
#if defined(__ANDROID__)
    const char* api = "GLES3";
#else
    const char* api = "GL3.3";
#endif
    ImGui::Text("  BG-Shader: %s FBO -> BackgroundDrawList%s", api,
                g_fx.bgWindowed ? " (Fenster-Modus)" : " (Vollbild)");
    ImGui::Text("  Overlay:   %s FBO -> ForegroundDrawList", api);
    ImGui::Text("  Rain/Spin: %s FBO -> ImGui-Fenster", api);
    ImGui::Text("  Dreiecke:  ImGui-DrawList (kein Shader)");
#if defined(XBM_RENDERER_VULKAN)
    ImGui::Text("  VkCore:    Vulkan-Instanz aktiv (P0, headless)");
#else
    ImGui::Text("  Vulkan:    inaktiv (RENDERER=GL)");
#endif
}

void EffectsGl_DrawBackground() {
    if (!g_fx.bgVisible) return;
    // JEDEN FRAME pruefen: Der GL-Kontext kann auch ohne ein
    // INIT_WINDOW-Ereignis verloren gehen (Speicherdruck, Treiber-
    // Reset). Die Pruefung ist ein einziger glIsTexture-Aufruf.
    EffectsGl_ValidateGpu();
    if (g_bgState == 0)
        g_bgState = g_bg.Init(640, 360, kFullscreenVs, kBgFs) ? 1 : -1;
    if (g_bgState < 0) return;
    ImGuiIO& io = ImGui::GetIO();
    ImGuiViewport* vp = ImGui::GetMainViewport();
    float mx = 0.5f, my = 0.5f;
    if (vp->Size.x > 0 && vp->Size.y > 0) {
        mx = (io.MousePos.x - vp->Pos.x) / vp->Size.x;
        my = 1.0f - (io.MousePos.y - vp->Pos.y) / vp->Size.y; // GL: y oben
    }
    g_bg.Render((float)ImGui::GetTime(), 0.0f, 3, mx, my);
    ImU32 tint = IM_COL32(255, 255, 255, (int)(g_fx.bgOpacity * 2.55f));
    // UiPageContains liefert fuer ein Fenster, das auf einer ANDEREN
    // Seite registriert ist, false -- nach der Gate-Umstellung blieb der
    // Shader dadurch im Hintergrund haengen. UiPageWindow ist das
    // richtige Gate: es registriert die Sichtbarkeit fuer die aktive
    // Seite und liefert true, sobald das Fenster hier gezeichnet werden
    // darf.
    const char* canvasTitle = UiPageWindow("Shader-Canvas");
    if (g_fx.bgWindowed && canvasTitle) {
        // Fenster-Modus: Shader als Hintergrund eines verschiebbaren
        // Fensters. Registriert + gegated: unregistriert wurde es beim
        // Andocken vom Seiten-Filter aus dem Schnappschuss entfernt und
        // vom Sofort-Wiederaufbau binnen Sekundenbruchteilen wieder
        // ausgeworfen ("kann nirgends andocken").
        ImGui::SetNextWindowSize(ImVec2(640, 400), ImGuiCond_FirstUseEver);
        // Titel vom Gate: Modell B liefert "Shader-Canvas##Seite".
        if (ImGui::Begin(canvasTitle, nullptr,
                         UiWinFlags(canvasTitle))) {
            ImVec2 p = ImGui::GetCursorScreenPos();
            ImVec2 a = ImGui::GetContentRegionAvail();
            // SELBSTBEZUG VERMEIDEN: Frueher fuellte der Canvas die
            // gesamte verfuegbare Hoehe (Dummy(a)) -- damit war die
            // Inhaltshoehe gleich der Fensterhoehe, die Auto-Fit-
            // Rechnung addierte jeden Frame das Chrome obendrauf und
            // das Fenster wuchs rasant. Jetzt folgt die Hoehe FEST der
            // BREITE (16:9): keine Rueckkopplung mehr.
            float ch = a.x * 9.0f / 16.0f;
            if (ch < 80.0f) ch = 80.0f;
            if (a.x < 1.0f) a.x = 1.0f;
            if (g_bg.tex != 0)
                ImGui::GetWindowDrawList()->AddImage(
                    (ImTextureID)(intptr_t)g_bg.tex, p,
                    ImVec2(p.x + a.x, p.y + ch),
                    ImVec2(0,1), ImVec2(1,0), tint);
            else            // ohne gueltige Textur NICHT zeichnen --
                ;           // sonst erscheint der Zeichensatz-Atlas
            ImGui::Dummy(ImVec2(a.x, ch));
        }
        ImGui::End();
    } else {
        ImGui::GetBackgroundDrawList()->AddImage(
            (ImTextureID)(intptr_t)g_bg.tex,
            vp->Pos, ImVec2(vp->Pos.x + vp->Size.x, vp->Pos.y + vp->Size.y),
            ImVec2(0, 1), ImVec2(1, 0), tint);
    }
}

// ---------------------------------------------------------------------------
// 2.3  OVERLAY ueber ALLEN Fenstern, nimmt nur einen Teil des Bildschirms
//      ein. ForegroundDrawList faengt KEINE Eingaben -- der gesamte
//      Bildschirm (auch unter dem Overlay) bleibt voll bedienbar.
// ---------------------------------------------------------------------------
void EffectsGl_DrawOverlay() {
    if (!g_fx.ovVisible) return;
    EffectsGl_ValidateGpu();
    if (g_overlayState == 0)
        g_overlayState = g_overlay.Init(420, 140, kFullscreenVs, kOverlayFs) ? 1 : -1;
    if (g_overlayState < 0) return;
    g_overlay.Render((float)ImGui::GetTime(), 0.0f, 3);
    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImVec2 sz(vp->Size.x * 0.35f, vp->Size.y * 0.12f);
    ImVec2 p0(vp->Pos.x + vp->Size.x - sz.x - 16.0f, vp->Pos.y + 16.0f);
    ImGui::GetForegroundDrawList()->AddImage(
        (ImTextureID)(intptr_t)g_overlay.tex,
        p0, ImVec2(p0.x + sz.x, p0.y + sz.y),
        ImVec2(0, 1), ImVec2(1, 0),
        IM_COL32(255, 255, 255, (int)(g_fx.ovOpacity * 2.55f)));
}


bool EffectsGl_GetOverlayRect(ImVec2* outMin, ImVec2* outMax) {
    if (!g_fx.ovVisible) return false;
    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImVec2 sz(vp->Size.x * 0.35f, vp->Size.y * 0.12f);
    ImVec2 p0(vp->Pos.x + vp->Size.x - sz.x - 16.0f, vp->Pos.y + 16.0f);
    if (outMin) *outMin = p0;
    if (outMax) *outMax = ImVec2(p0.x + sz.x, p0.y + sz.y);
    return true;
}
