#pragma once
// ui_pages.h -- Seiten-/Layout-System, konsolidierte Fassung.
//
// DATENMODELL (pro Seite ZWEI vollstaendige Layout-Zustaende):
//   * FREI:    Position + Groesse jedes Seitenfensters   (g_free[page])
//   * KOMPAKT: Dock-Knoten jedes Seitenfensters          (g_dock[page]);
//              die Knoten-Baeume selbst (Splits/Tab-Gruppen) haelt ImGui
//              im seiten-eigenen DockSpace und persistiert sie via
//              imgui.ini.
//
// UEBERGAENGE (einzige Stellen, die Zustaende anwenden/sichern):
//   1. Tab-Wechsel      -> SavePageState(alt) + ApplyPageState(neu)
//   2. Kompakt-Toggle   -> SavePageState(Seite, alterModus)
//                          + ApplyPageState(Seite, neuerModus)
//   3. App-Start (Load) -> ApplyPageState(aktive Seite)
//
// REGELN:
//   * Seitenfenster werden NACH UiPagesFrame() submittet (Dock-Regel).
//   * Gedockte Fenster verwaltet ausschliesslich das Layout.
#include "imgui.h"
#include "imgui_internal.h"
#include "ui_navi.h"
#include "effects_gl.h"   // resizeAffectsNeighbors
#include "ui_helpers.h"   // UiDragHandledThisFrame
#include <algorithm>
// #ifdef __ANDROID__
// #include <android/log.h>
// #include <string_view>
// #define UIP_LOGF(...) __android_log_print(ANDROID_LOG_INFO, "xbm", __VA_ARGS__)
// inline void UIP_LOGF(std::string_view msg) {
//   __android_log_print(ANDROID_LOG_INFO, "xbm", "%.*s", static_cast<int>(msg.size()), msg.data());
// }
// #else
// #include <cstdio>
// #define UIP_LOGF(...) do { printf("[xbm] " __VA_ARGS__); printf("\n"); } while (0)
// #endif
#include "Utils.h"
#include <cstring>
#include <functional>
#include <map>
#include <string>
#include <vector>
#include "ui_textstore.h"
#include "ui_files.h"
#include "ui_textsel.h"   // ziehbare Auswahlgriffe (Finger)

// #include <iostream>
#include <string_view>
#include "misc/cpp/imgui_stdlib.h" // Enabler for infinite std::string input

struct UiPage {
    std::string name;
    std::vector<std::string> windows;
    // ERSTSTART-STANDARD: Kompakt-Layout fuer alle Seiten aktiv.
    // Persistierte compact_<Seite>-Werte aus der xbm.ini ueberstimmen
    // dies ab dem zweiten Start (bewusste Nutzerwahl bleibt erhalten).
    bool compact = true;
    // DockSpace-Kanten an die Seiten-Navigationen KLEBEN: linker Rand an
    // die rechte Kante der linken Navi, rechter Rand an die linke Kante
    // der rechten Leiste. Pro Seite einstellbar; das globale Override
    // (UiDockStickAll) erzwingt beides fuer ALLE Seiten.
    bool stickL = false;
    // Dock-Kante rechts klebt VORGABEMAESSIG an der Leiste.
    bool stickR = true;
    bool needRebuild = false;   // Fallback: einfacher Grundstapel
    bool needLayout  = false;   // gespeicherten Layout-Baum wiedererrichten
    // EINSCHWINGEN: so viele Frames nach einem (Neu-)Aufbau werden die
    // Fenster dieser Seite UNSICHTBAR gezeichnet. [Beim Aufbau bekommen
    //  die Fenster erst gleiche Hoehen; die Wunschhoehen kennt das Layout
    //  erst, nachdem der Inhalt einmal vermessen wurde (Frame-Ende). Ohne
    //  Einschwingen sah man beides: zuerst die Gleichverteilung, dann den
    //  Sprung auf die richtigen Hoehen. Jetzt passiert das ungesehen.]
    int    settle = 0;
    double lastRebuild = 0.0;   // Drossel JE SEITE, nicht mehr global
};

// Bruecke zum ImGui-Dock-Guides-Patch: Oberkante der Arbeitsflaeche =
// Unterkante der Tab-Leiste. WICHTIG -- im Namespace ImGui definieren:
// die extern-Deklaration des Patches steht im Koerper der member-
// qualifizierten Funktion und lebt damit in ImGui-Scope; eine globale
// Definition ergab den dlopen-Crash "cannot locate symbol
// _ZN5ImGui20XbmDockClampTopInsetE" beim App-Start.
namespace ImGui { inline float XbmDockClampTopInset = 0.0f; }
// Bruecke zum Layout-Sperre-Patch (extern im Koerper von
// ImGui::StartMouseMovingWindowOrNode -- deshalb ZWINGEND im Namespace
// ImGui definieren, sonst dlopen-Fehler wie bei der Guide-Bruecke).
namespace ImGui { inline int XbmLayoutLocked = 0; }

namespace ui_pages_detail {
struct Snap { ImVec2 pos, size; };
inline std::map<std::string, std::map<std::string, Snap>>    g_free;
inline std::map<std::string, std::map<std::string, ImGuiID>> g_dock;
inline int    g_active = 0, g_lastActive = -1;
inline bool   g_drawer = false;
inline bool   g_pageSheet = false;   // Seiten-Einstellungen (von oben)
// Vom Nutzer per Bodengriff gesetzte DockSpace-Verlaengerung: Solange
// gesetzt, darf die Splitter-Bedarfsrechnung sie NICHT ueberschreiben
// (sonst sprang die Unterkante nach Sekunden auf den Rechenwert
// zurueck). Wird nur durch erneutes Ziehen veraendert.
inline std::map<std::string, float> g_pageExtraUser;
inline float  g_drawerT = 0.0f, g_tabsH = 40.0f;
inline float  g_gripW = 44.0f, g_barH = 44.0f;  // Leisten-Geometrie
inline double g_lastRebuild = -1.0;
inline bool   g_settleAlphaPushed = false;   // Alpha-Push aus UiPagesFrame() noch offen?
// WARMLAUF-FRAMES OHNE PRAESENTATION. [Beim Seitenwechsel und nach einem
//  Dock-Neuaufbau braucht ImGui ein bis zwei Frames, bis Groessen und
//  Hoehen gemessen und durchgesetzt sind. Diese Frames ganz normal rechnen,
//  aber NICHT auf den Bildschirm bringen (kein Swap) -- das alte Bild bleibt
//  stehen, und weder leere noch springende Frames sind je zu sehen. Das war
//  das "einmal kurz aufflackern".]
inline int    g_warmFrames = 0;
// Frei-Positionen, die noch angewendet werden muessen: SetWindowPos auf
// ein (noch) gedocktes Fenster wird von ImGui STILL IGNORIERT -- beim
// Toggle-Aus sind die Fenster im Moment des Aufrufs aber noch gedockt
// (Undock greift erst beim naechsten Begin). Deshalb: vormerken und in
// den Folgeframes anwenden, sobald das Fenster wirklich frei ist.
inline std::map<std::string, Snap> g_pendingFree;

// Serialisierter Kompakt-Layout-Baum: pro Knoten Eltern-Index, Split-Achse
// (-1 = Blatt), Groessenverhaeltnis des ersten Kindes und (bei Blaettern)
// die Fensternamen in Tab-Reihenfolge. Damit laesst sich die Gruppierung
// jederzeit EXAKT wiedererrichten -- unabhaengig von ImGuis Knoten-IDs,
// die beim Leeren des Layouts zerstoert werden.
struct LayoutNode {
    int parent = -1;
    int axis   = -1;            // -1=Blatt, 0=X(nebeneinander), 1=Y(uebereinander)
    float ratio = 0.5f;
    std::vector<std::string> windows;
};
inline std::map<std::string, std::vector<LayoutNode>> g_layout;

// PRO-FENSTER-EIGENSCHAFTEN (persistiert als P-Records in xbm.ini).
// fixHeight: Hoehe == EXAKTE Inhaltshoehe (plus Kopfzeile), IMMER --
// Elemente hinzu/weg -> Hoehe springt ABRUPT mit; leerer Inhalt -> nur
// Kopfzeile. Gegenueber dem NUTZER statisch: nirgendwo vergroesserbar
// (Rand entwaffnet, Splitter/Nachbarn werden am Frame-Ende ueber-
// schrieben, Kaskade behandelt es als inkompressibel).
struct UiWinProps {
    bool fixHeight = true;            // STANDARD: statisch
    // Laufzeit (nicht persistiert): Adaptiv-Erkennung. Fenster, deren
    // Inhalt sich der Fenstergroesse ANPASST (Canvas), melden als
    // Wunschhoehe stets Ist+Chrome -> Rueckkopplung ohne Fixpunkt
    // ("waechst und hoert nicht auf"). Nach 4 monotonen Wachstums-
    // Frames wird das Fenster als adaptiv erkannt und zaehlt als
    // flexibel.
    unsigned char growStreak = 0;
    bool adaptive = false;
    // EINFRIER-HOEHE fuer "statisch trotz adaptiv": Kippt ein Fenster in
    // den Adaptiv-Ausstieg (fuellender Inhalt/Kampf/Wachstum), wird hier
    // seine Hoehe im Kipp-Moment festgehalten. Ist fixHeight gesetzt,
    // pinnt die Durchsetzung fortan DIESE Hoehe -- "statisch" heisst
    // damit universell "Hoehe eingefroren" und die Checkbox hat IMMER
    // eine sichtbare Wirkung (der alte Zustand: adaptive Fenster
    // ignorierten fixHeight komplett -- die Checkbox war dort wirkungs-
    // los, was praktisch ALLE Canvas-/Listen-Fenster betraf).
    float lockedH = -1.0f;
    // GROESSEN-MODUS (loest das alte fixHeight-Ja/Nein ab):
    //  0 = frei, 1 = FESTE DIMENSIONEN (kein Vergroessern/Verkleinern;
    //      die Breite regelt im DockSpace weiterhin der Baum),
    //  2 = INHALTSGESTEUERTE HOEHE (waechst/schrumpft mit dem Inhalt).
    // minH gilt fuer Fenster, deren Inhalt sich in Wahrheit an der
    // FENSTERGROESSE orientiert (adaptive == true): dort gibt es keine
    // Inhaltshoehe, also greift diese optionale Untergrenze.
    int   sizeMode = 0;
    float minH     = 0.0f;
    // VOLLBILD-FENSTER: nimmt IMMER die volle Hoehe des Seiten-
    // DockSpace ein -- unabhaengig von Inhalt und davon, ob die
    // Android-Tastatur ausgefahren ist. Andere Fenster koennen
    // trotzdem daneben/darunter angedockt werden; dann teilt der
    // Dock-Baum den Platz wie gewohnt.
    bool  fullscreen = false;
    int   streakFrame = -1;   // Frame-Guard: Zaehler 1x pro Frame
    float baselineH  = -1.0f; // Hoehe vor dem Wachstumsschub
    float lastWant   = -1.0f; // Sollwert des Vorframes
    float goodWant   = -1.0f; // letzte GUELTIGE Messung (nicht gecullt)
    float lastWrite  = -1.0f; // zuletzt geschriebene Hoehe
    int   fightCount = 0;     // wie oft wurde sie zurueckgesetzt
    bool  hbarLatch  = false; // horizontaler Balken verrastet
    int   hbarOff    = 0;     // Frames ohne Ueberbreite
    bool testlauf = true;     // Der Emailversand geht an eine private E-Mail Adresse
};
inline std::map<std::string, UiWinProps> g_winProps;
// EIGENSCHAFTS-SCHLUESSEL: immer der BASISNAME (alles vor "##").
// Der Kernfehler der wirkungslosen Statik-Checkboxen: Die Einstellungs-
// UI schrieb unter dem REGISTRIERTEN Namen (teils "Titel##Seite"),
// waehrend UiWinFlags und die Durchsetzung unter dem tatsaechlichen
// Begin-Titel lasen (teils nur "Titel") -- zwei getrennte Eintraege,
// die einander nie sahen. Ab jetzt laufen ALLE Zugriffe durch diesen
// Normalisierer; per-Page-Instanzen teilen sich damit bewusst ihre
// Eigenschaften.
inline std::string UiPropsKey(const char* title) {
    if (!title) return std::string();
    const char* h = strstr(title, "##");
    return h ? std::string(title, (size_t)(h - title)) : std::string(title);
}
inline UiWinProps& UiPropsFor(const char* title) {
    return g_winProps[UiPropsKey(title)];
}
// Aktuelles Fenster zu einem Props-Schluessel (Basisname) -- der reale
// Begin-Titel kann ein "##Seite"-Suffix tragen, FindWindowByName mit dem
// Basisnamen griffe dann ins Leere.
inline ImGuiWindow* UiFindWindowByPropsKey(const std::string& key) {
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g || key.empty()) return nullptr;
    for (ImGuiWindow* w : g->Windows) {
        if (!w->WasActive) continue;
        if (w->Flags & (ImGuiWindowFlags_Tooltip
                        | ImGuiWindowFlags_Popup)) continue;
        // GEDOCKTE Fenster tragen ImGuis ChildWindow-Flag -- der alte
        // Pauschal-Filter warf sie raus, das Zahnrad-Panel schloss sich
        // fuer sie deshalb im selben Frame wieder ("oeffnet gar nicht").
        if ((w->Flags & ImGuiWindowFlags_ChildWindow)
            && !w->DockIsActive) continue;
        if (UiPropsKey(w->Name) == key) return w;
    }
    return nullptr;
}
// Statik-Hoehe im JETZT-Zustand einfrieren (Checkbox-Handler): gedockt
// zaehlt die Knotenhoehe (inkl. Tab-Leiste, wie UiLeafWantY), sonst die
// Fensterhoehe.
inline void UiCaptureLockedH(const std::string& key) {
    if (ImGuiWindow* w = UiFindWindowByPropsKey(key)) {
        g_winProps[key].lockedH =
            (w->DockIsActive && w->DockNode && !w->DockNode->ChildNodes[0])
                ? w->DockNode->Size.y : w->Size.y;
    }
}
// VOM NUTZER FREIGESTELLT: bewusst aus dem Kompakt-Baum gezogene
// Fenster. ALLE Aufbau-Pfade respektieren diesen Merker -- sonst
// sammelt der Rebuild nach dem Drop-Save wieder saemtliche
// Seitenfenster ein und das Fenster schnappt zurueck.
inline std::map<std::string, std::vector<std::string>> g_userFree;
inline bool UserFreed(const std::string& pg, const std::string& w) {
    auto it = g_userFree.find(pg);
    if (it == g_userFree.end()) return false;
    for (const auto& n : it->second) if (n == w) return true;
    return false;
}
inline void UserFreeSet(const std::string& pg, const std::string& w,
                        bool on) {
    auto& v = g_userFree[pg];
    v.erase(std::remove(v.begin(), v.end(), w), v.end());
    if (on) v.push_back(w);
}
// Fenster -> konkreter Blatt-Knoten aus dem ZULETZT errichteten Baum:
// Grundlage der zielgenauen Selbstheilung (Ausreisser kehren exakt in
// ihr Blatt zurueck, nicht pauschal ins erste).
inline std::map<std::string, std::map<std::string, ImGuiID>> g_liveLeaf;

// Beschneidet den serialisierten Baum: ein Split, dessen eine Seite in
// ihrem GESAMTEN Teilbaum keine Fenster traegt (z.B. nach dem Abdocken
// des einzigen rechts angedockten Fensters), kollabiert zum
// ueberlebenden Teilbaum -- die verbleibenden Fenster erhalten damit die
// volle Breite/Hoehe. Ohne diese Beschneidung konservierte der
// Schnappschuss die Luecke und jeder Wiederaufbau errichtete das leere
// Rechteck originalgetreu mit.
struct PruneNode {
    int axis = -1; float ratio = 0.5f;
    std::vector<std::string> windows;
    PruneNode* c0 = nullptr; PruneNode* c1 = nullptr;
    ~PruneNode() { delete c0; delete c1; }
    bool hasWindows() const {
        if (!windows.empty()) return true;
        if (c0 && c0->hasWindows()) return true;
        if (c1 && c1->hasWindows()) return true;
        return false;
    }
};
inline PruneNode* BuildPrune(const std::vector<LayoutNode>& recs,
                             int idx, int& next) {
    PruneNode* n = new PruneNode();
    n->axis = recs[idx].axis; n->ratio = recs[idx].ratio;
    n->windows = recs[idx].windows;
    next = idx + 1;
    if (n->axis != -1) {
        n->c0 = BuildPrune(recs, next, next);
        n->c1 = BuildPrune(recs, next, next);
    }
    return n;
}
inline PruneNode* Prune(PruneNode* n) {
    if (!n || n->axis == -1) return n;
    n->c0 = Prune(n->c0); n->c1 = Prune(n->c1);
    bool h0 = n->c0 && n->c0->hasWindows();
    bool h1 = n->c1 && n->c1->hasWindows();
    if (h0 && h1) return n;
    PruneNode* keep = h0 ? n->c0 : n->c1;   // Ueberlebenden uebernehmen
    if (h0) n->c0 = nullptr; else n->c1 = nullptr;
    delete n;
    return keep ? keep : new PruneNode();
}
inline void FlattenPrune(PruneNode* n, int parent,
                         std::vector<LayoutNode>& out) {
    LayoutNode r; r.parent = parent; r.axis = n->axis;
    r.ratio = n->ratio; r.windows = n->windows;
    int idx = (int)out.size();
    out.push_back(std::move(r));
    if (n->axis != -1) {
        FlattenPrune(n->c0, idx, out);
        FlattenPrune(n->c1, idx, out);
    }
}

// Ist das Fenster Teil des serialisierten Layout-Baums der Seite?
// (Nein => der Nutzer hat es bewusst abgedockt; es lebt dann als
//  floatendes Fenster mit eigenem Frei-Zustand -- auch im Kompakt-Modus.)
inline bool LayoutHasWindow(const std::string& page, const std::string& n) {
    auto it = g_layout.find(page);
    if (it == g_layout.end()) return false;
    for (const auto& r : it->second)
        for (const auto& w : r.windows)
            if (w == n) return true;
    return false;
}

// Sofort-Persistenz-Hook: von app_settings gesetzt; wird nach jeder
// bedeutsamen Aenderung (Drop, Transition) gerufen, damit der Stand die
// Platte erreicht BEVOR ein moeglicher App-Neustart kommt -- der reine
// 3-s-Timer verlor sonst frische Andockungen ("sofort neu gestartet ->
// Default-Position").
inline void (*UiPagesPersistHook)() = nullptr;
inline void UiPagesPersist() { if (UiPagesPersistHook) UiPagesPersistHook(); }

// TOP-DOWN-HOEHENVERTEILUNG (ersetzt den frueheren Bottom-up-Ansatz,
// der pro Blatt gegen ImGuis Ratio-Layout kaempfte und beim Andocken
// unter ein Fixfenster verlor): NeedY liefert die Wunschhoehe eines
// Teilbaums (statische Blaetter: exakte Inhaltshoehe; flexible: ihre
// aktuelle Groesse; Y-Split: Summe; X-Split: Maximum). AssignY verteilt
// eine gegebene Hoehe von oben: statische Blaetter bekommen EXAKT ihren
// Bedarf, flexible teilen den Rest, Ueberschuss geht an Flexible (sonst
// ans untere Kind).
inline bool UiLeafFixed(ImGuiDockNode* n) {
    for (int i = 0; i < n->Windows.Size; ++i) {
        UiWinProps& wp = UiPropsFor(n->Windows[i]->Name);
        // fixHeight zaehlt auch im Adaptiv-Zustand, sofern eine
        // Einfrier-Hoehe existiert -- "statisch" = Hoehe eingefroren.
        if (wp.fullscreen) return true;   // feste Hoehe = Viewport
        if (wp.fixHeight && (!wp.adaptive || wp.lockedH > 1.0f))
            return true;
    }
    return false;
}
// Hoehe, die der DockSpace in diesem Frame tatsaechlich bekommen hat.
// Das Vollbild-Blatt rechnet damit -- jede eigene Formel wich frueher
// um Randbetraege ab und liess die Seite scrollen.
// Nutzbare Hoehe des Seiten-Viewports (der Platz im Host-Fenster).
// Das ist die Hoehe, die ein VOLLBILD-Fenster einnimmt -- unabhaengig
// davon, wie hoch der DockSpace insgesamt ist.
inline float& UiPageViewportH() { static float v = 0.0f; return v; }

// Traegt IRGENDEIN Fenster dieser Seite die Vollbild-Eigenschaft?
inline bool UiPageHasFullscreen(const UiPage& pg) {
    for (const std::string& wn : pg.windows)
        if (UiPropsFor(wn.c_str()).fullscreen) return true;
    return false;
}

// [AUSGELAGERT nach ui_pages.cpp -- Build-Beschleunigung:
//  der Rumpf wird nur noch EINMAL uebersetzt statt in jeder
//  Datei, die ui_pages.h einbindet.]
float UiLeafWantY(ImGuiDockNode* n);
// Groesste Abweichung statischer Blaetter von ihrer Sollhoehe.
// EREIGNIS-GATE fuer den Baum-Pass: Ein DAUERSCHREIBER kaempft jeden
// Frame gegen ImGuis Layout-Konstanten (Separator, Rundung) -- die
// Differenz sammelt sich bei den Flexiblen als stetiges Wachstum.
// Im Ruhezustand schreibt deshalb NIEMAND (ImGui allein ist driftfrei);
// erst echte Abweichung (>3px: Inhaltsaenderung, Splitter-Angriff,
// frisches Andocken) loest EINEN Schnapp aus, danach wieder Stille.
inline float UiMaxRigidDev(ImGuiDockNode* n, bool treeHasFlex) {
    if (!n->ChildNodes[0]) {
        if (!UiLeafFixed(n)) return 0.0f;
        float want = UiLeafWantY(n);
        float dev  = want - n->Size.y;
        // GEPARKTER UEBERSCHUSS IST KEINE ABWEICHUNG: In einem komplett
        // statischen Stapel muss der Platz-Ueberschuss der Arbeits-
        // flaeche (Kompakt-Minimum) auf einem Blatt geparkt werden --
        // zaehlte seine Uebergroesse als Abweichung, stand das Gate
        // DAUERHAFT offen und unser Zuweisen wechselte sich jeden Frame
        // mit ImGuis Normalisierung ab (Doppler, Mikro-Drift, langsames
        // Zurueckfinden). Uebergroesse zaehlt daher nur, wenn ein
        // flexibles Fenster existiert, das sie aufnehmen koennte;
        // Untergroesse (echtes Quetschen) zaehlt immer.
        if (dev < 0.0f && !treeHasFlex) return 0.0f;
        return fabsf(dev);
    }
    float a = UiMaxRigidDev(n->ChildNodes[0], treeHasFlex);
    float b = UiMaxRigidDev(n->ChildNodes[1], treeHasFlex);
    return a > b ? a : b;
}
// Traegt der Teilbaum AUSSCHLIESSLICH statische Blaetter?
inline bool UiAllStatic(ImGuiDockNode* n) {
    if (!n) return false;
    if (!n->ChildNodes[0]) return UiLeafFixed(n);
    return UiAllStatic(n->ChildNodes[0]) && UiAllStatic(n->ChildNodes[1]);
}
// Splitter STILLLEGEN, wo beide Seiten statisch sind: ImGui bietet dort
// dann gar keinen Griff mehr an. Zuvor wurde der Zug erst NACH einem
// angewandten Frame abgebrochen -- der Rand zuckte sichtbar um ~1px und
// wirkte wie ein Fehler statt wie eine Regel.
inline void UiFreezeStaticSplitters(ImGuiDockNode* n) {
    if (!n || !n->ChildNodes[0]) return;
    ImGuiDockNodeFlags f = n->LocalFlags;
    // NUR Y-TRENNER (Hoehen!) einfrieren -- und zwar schon, wenn EINE
    // Seite komplett statisch ist: JEDER Zug an so einem Trenner wuerde
    // die statische Seite in der Hoehe aendern; die flexible Gegenseite
    // bekommt ihre Hoehe ohnehin aus der Verteilung. [Frueher: nur wenn
    // BEIDE Seiten statisch -- der Trenner zwischen statisch und
    // flexibel blieb greifbar und zog das statische Fenster sichtbar
    // mit, bevor die Frame-Ende-Durchsetzung es zurueckschnappte. DAS
    // war das "statische Fenster lassen sich doch ziehen".]
    // X-TRENNER bleiben IMMER frei: statisch betrifft nur die HOEHE,
    // Breiten sind Nutzersache (die alte Fassung fror auch sie ein).
    if (n->SplitAxis == ImGuiAxis_Y
        && (UiAllStatic(n->ChildNodes[0]) || UiAllStatic(n->ChildNodes[1])))
        f |= ImGuiDockNodeFlags_NoResize;
    else
        f &= ~ImGuiDockNodeFlags_NoResize;
    if (f != n->LocalFlags) n->SetLocalFlags(f);
    UiFreezeStaticSplitters(n->ChildNodes[0]);
    UiFreezeStaticSplitters(n->ChildNodes[1]);
}

inline bool UiHasFixed(ImGuiDockNode* n) {
    if (!n->ChildNodes[0]) return UiLeafFixed(n);
    return UiHasFixed(n->ChildNodes[0]) || UiHasFixed(n->ChildNodes[1]);
}
inline bool UiHasFlex(ImGuiDockNode* n) {
    if (!n->ChildNodes[0]) return !UiLeafFixed(n);
    return UiHasFlex(n->ChildNodes[0]) || UiHasFlex(n->ChildNodes[1]);
}
// rigidOnly=true: Container-Bedarf -- flexible Blaetter zaehlen nur mit
// ihrem MINIMUM. Mit Ist-Groesse entstand eine Aufwaertsspirale: der
// Verteiler gibt Flexiblen den Ueberschuss -> ihre Ist-Groesse waechst
// -> der "Bedarf" waechst -> dockH waechst -> mehr Ueberschuss ...
// (~konstantes Wachstum pro Frame, zeitproportional sichtbar).
// rigidOnly=false: Verteilungs-Gewichte -- Ist-Groessen sind hier
// richtig und stabil, sobald der Container steht.
inline float UiNeedY(ImGuiDockNode* n, bool rigidOnly) {
    if (!n->ChildNodes[0]) {
        if (UiLeafFixed(n)) return UiLeafWantY(n);
        float minY = ImGui::GetStyle().WindowMinSize.y;
        if (rigidOnly) {
            // CONTAINER WAECHST, STATT NACHBARN ZU QUETSCHEN: Frueher
            // zaehlten flexible Blaetter im Container-Bedarf nur mit
            // ihrem MINIMUM -- waechst ein statisches Fenster, wurde
            // erst der Platz der flexiblen aufgezehrt. Jetzt zaehlen sie
            // mit ihrer EINGESTELLTEN Groesse (SizeRef -- stabil, keine
            // Rueckkopplung), sodass der Bedarf und damit die Hoehe des
            // Kompakt-Layouts direkt mitwaechst.
            if (n->SizeRef.y > 1.0f) return n->SizeRef.y;
            return n->Size.y > 1.0f ? n->Size.y : minY;
        }
        // SIZE-REF statt Ist-Groesse: Die Ist-Groesse zurueckzulesen
        // baute eine RATSCHE -- jede transiente Abweichung (Rundung,
        // Separator) wurde im Folgeframe als "Bedarf" festgeschrieben;
        // unten klemmt das Minimum, also wanderte alles einseitig:
        // oben stetig groesser, die untersten kollabierten. SizeRef
        // aendert sich nur durch Nutzer oder Durchsetzung.
        if (n->SizeRef.y > 1.0f) return n->SizeRef.y;
        return n->Size.y > 1.0f ? n->Size.y : minY;
    }
    float a = UiNeedY(n->ChildNodes[0], rigidOnly);
    float b = UiNeedY(n->ChildNodes[1], rigidOnly);
    return (n->SplitAxis == ImGuiAxis_Y) ? a + b : (a > b ? a : b);
}
// [AUSGELAGERT nach ui_pages.cpp -- Build-Beschleunigung:
//  der Rumpf wird nur noch EINMAL uebersetzt statt in jeder
//  Datei, die ui_pages.h einbindet.]
void UiAssignY(ImGuiDockNode* n, float h);
inline std::map<std::string, float> g_pageNeed;   // Bedarf je Seite
inline ImGuiID g_activeDockId = 0;                // aktiver Seiten-Dock

inline UiWinProps& UiWinPropsOf(const std::string& n) {
    return g_winProps[UiPropsKey(n.c_str())];
}
// Traegt dieses Blatt ein hoehenfixiertes Fenster? (Kaskaden-Achse Y)
inline bool NodeHeightFixed(ImGuiDockNode* n) {
    if (!n || n->ChildNodes[0]) return false;
    for (int i = 0; i < n->Windows.Size; ++i)
        if (UiPropsFor(n->Windows[i]->Name).fixHeight) return true;
    return false;
}

inline void SerializeNode(ImGuiDockNode* n, int parent,
                          std::vector<LayoutNode>& out) {
    LayoutNode rec; rec.parent = parent;
    int idx = (int)out.size();
    if (n->ChildNodes[0] && n->ChildNodes[1]) {
        rec.axis = (n->SplitAxis == ImGuiAxis_X) ? 0 : 1;
        float total = (rec.axis == 0) ? n->Size.x : n->Size.y;
        float c0    = (rec.axis == 0) ? n->ChildNodes[0]->Size.x
                                      : n->ChildNodes[0]->Size.y;
        rec.ratio = (total > 1.0f) ? (c0 / total) : 0.5f;
        if (rec.ratio < 0.05f) rec.ratio = 0.05f;
        if (rec.ratio > 0.95f) rec.ratio = 0.95f;
        out.push_back(rec);
        SerializeNode(n->ChildNodes[0], idx, out);
        SerializeNode(n->ChildNodes[1], idx, out);
    } else {
        for (int i = 0; i < n->Windows.Size; ++i)
            rec.windows.push_back(n->Windows[i]->Name);
        out.push_back(rec);
    }
}

// [AUSGELAGERT nach ui_pages.cpp -- Build-Beschleunigung:
//  der Rumpf wird nur noch EINMAL uebersetzt statt in jeder
//  Datei, die ui_pages.h einbindet.]
void RebuildFromLayout(const std::string& pageName, ImGuiID dockId,
                              ImVec2 size,
                              const std::vector<std::string>& allowed);

inline bool TreeHasWindows(ImGuiDockNode* n) {
    if (!n) return false;
    if (n->Windows.Size > 0) return true;
    return TreeHasWindows(n->ChildNodes[0])
        || TreeHasWindows(n->ChildNodes[1]);
}
inline ImGuiDockNode* FirstLeaf(ImGuiDockNode* n) {
    while (n && n->ChildNodes[0]) n = n->ChildNodes[0];
    return n;
}
inline ImGuiID PageDockId(const UiPage& pg) {
    // STACK-UNABHAENGIG hashen! ImGui::GetID haengt vom ID-Stack ab:
    // im Host-Fenster (DockSpace-Erzeugung) ergab es eine ANDERE ID als
    // an der Transition-Stelle (Sichern/Anwenden, globaler Stack). Das
    // Sichern fragte dadurch einen nicht existierenden Knoten ab,
    // serialisierte still nie -- und jede Rueckkehr fiel auf den
    // Grundstapel (= registrierte Reihenfolge) zurueck.
    return ImHashStr((std::string("##page_dock_") + pg.name).c_str());
}
}

inline std::vector<UiPage>& UiPages() {
    static std::vector<UiPage> p; return p;
}
inline UiPage* UiActivePage() {
    auto& p = UiPages();
    if (p.empty()) return nullptr;
    if (ui_pages_detail::g_active >= (int)p.size())
        ui_pages_detail::g_active = 0;
    return &p[ui_pages_detail::g_active];
}
// MODELL B ("eigene Instanz pro Seite"): liefert den seiten-gebundenen
// Titel  "<Basis>##<AktiveSeite>". ImGui zeigt nur den Basisnamen an,
// die ID (und damit Fenster + saemtliche States in g_free/g_layout) ist
// aber pro Seite eigenstaendig. Verwendung:
//   Registry:  {"Haupt", {"Notizen##Haupt", ...}}, {"Effekte",
//              {"Notizen##Effekte", ...}}
//   gui():     if (UiPageContains(UiPageScopedTitle("Notizen")))
//                  ShowNotizen(UiPageScopedTitle("Notizen"));
// MODELL A ("geteilte Instanz"): einfach denselben Klartext-Titel in
// mehreren Seiten-Registries fuehren -- die Zustandsmaschine haelt die
// Geometrie ohnehin PRO SEITE, Inhalt/Daten bleiben eins.
// ---- Modell-Wahl pro Fenster ----
enum UiWinModel {
    UiWinShared,   // Modell A: EIN Fenster/Datensatz, Geometrie pro Seite
    UiWinPerPage   // Modell B: eigene Instanz "Name##Seite" pro Seite
};
inline void UiPageAdd(const char* page, const char* base, UiWinModel m) {
    // Eigenschafts-Eintrag SOFORT anlegen: Der Pfeil des Eigenschaften-
    // Menues erscheint damit ab dem ersten Frame an jedem registrierten
    // Fenster (frueher entstand der Eintrag erst lazy ueber UiWinFlags).
    ui_pages_detail::UiPropsFor(base);
    for (auto& pg : UiPages())
        if (pg.name == page) {
            pg.windows.push_back(m == UiWinPerPage
                ? std::string(base) + "##" + page : std::string(base));
            return;
        }
}
// Liefert fuer die AKTIVE Seite den effektiven Titel des Fensters
// (Klartext bei Modell A, "Name##Seite" bei Modell B) -- oder nullptr,
// wenn das Fenster auf dieser Seite nicht registriert ist (aber auf einer
// anderen). Unregistrierte Fenster: immer sichtbar, Klartext.
// NICHT MEHR VERWENDET (bewusst behalten als Warnschild):
// Der Aufruf aus UiPageWindow heraus war ein schwerer Fehler --
// SetNextWindowSize gilt fuer das NAECHSTE Begin. Lief ein Gate ohne
// folgendes Begin (z.B. Fenster per Checkbox aus), landete die Groesse
// am naechsten gezeichneten Fenster: Kompakt-Host und Tab-Leiste wurden
// verstellt, Fenster schwebten umher, die Navigation verschwand.
inline void UiPreSizeStatic(const char* title) {
    if (!title) return;
    auto it = ui_pages_detail::g_winProps.find(
                  ui_pages_detail::UiPropsKey(title));
    if (it == ui_pages_detail::g_winProps.end()) return;
    if (!it->second.fixHeight || it->second.adaptive) return;
    if (it->second.goodWant <= 1.0f) return;
    ImGuiWindow* w = ImGui::FindWindowByName(title);
    if (!w || w->DockIsActive) return;   // gedockt: Knoten bestimmt Hoehe
    ImGui::SetNextWindowSize(ImVec2(w->Size.x, it->second.goodWant),
                             ImGuiCond_Always);
}

// (Begin ohne open-Zeiger): unser nachgelieferter X traegt den Basis-
// namen hier ein; die Aufrufstelle konsumiert ihn und setzt ihr
// Sichtbarkeits-Flag. Unkonsumierte Wuensche (z.B. Login) verpuffen.
inline std::vector<std::string>& UiCloseRequests() {
    static std::vector<std::string> v;
    return v;
}
inline bool UiConsumeClose(const char* base) {
    auto& v = UiCloseRequests();
    for (size_t i = 0; i < v.size(); ++i)
        if (v[i] == base) { v.erase(v.begin() + (long)i); return true; }
    return false;
}

// OEFFNEN-WUNSCH -- das Gegenstueck zu UiCloseRequests.
// [Die Fensterpalette in navi1 kann ein Fenster nicht selbst oeffnen:
//  das Sichtbarkeits-Flag liegt bei der Zeichenstelle (main.cpp). Also
//  derselbe Weg wie beim Schliessen -- Wunsch eintragen, die
//  Zeichenstelle konsumiert ihn und setzt ihr Flag.]
inline std::vector<std::string>& UiOpenRequests() {
    static std::vector<std::string> v;
    return v;
}
// ALLGEMEINER SICHTBARKEITS-SCHALTER JE FENSTER.
// [Der Grund, warum sich "manche Fenster nicht schliessen liessen":
//  UiCloseRequests war ein WUNSCH, den jede Zeichenstelle selbst
//  konsumieren musste -- und das tat nur main_android.cpp, fuer genau
//  vier Fenster. Alle anderen Fenster warfen den Wunsch ins Leere.
//
//  Hier liegt der Schalter jetzt ZENTRAL: UiWinOpen(name) ist der
//  Zustand, UiWinVisible(name) fragt ihn ab. Eine Zeichenstelle braucht
//  nichts zu tun -- UiPageWindow() liefert einfach nullptr, solange das
//  Fenster geschlossen ist, und das Fenster wird nicht gezeichnet.]
inline std::map<std::string, bool>& UiWinOpenMap() {
    static std::map<std::string, bool> m; return m;
}
// ZUSAETZLICHE EINSTELLUNGEN JE SEITE. [Eine Seite kann sich hier mit
//  einer Zeichenfunktion eintragen, die im Blatt "Seiten-Einstellungen"
//  (Zahnrad) unter den Standard-Schaltern erscheint -- z.B. die
//  Mail-Absenderdaten der Seite "Bewerben":
//      UiPageSettingsExtras()["Bewerben"] = &MailAbsenderEinstellungen;
//  Schluessel = Seitenname (UiPage::name). Die Funktion zeichnet ImGui-
//  Elemente und wird nur gezeichnet, wenn das Blatt dieser Seite offen ist.]
using UiPageSettingsFn = std::function<void()>;
inline std::map<std::string, UiPageSettingsFn>& UiPageSettingsExtras() {
    static std::map<std::string, UiPageSettingsFn> m;
    return m;
}

inline bool& UiWinOpen(const std::string& name) {
    auto it = UiWinOpenMap().find(name);
    if (it == UiWinOpenMap().end())
        it = UiWinOpenMap().emplace(name, true).first;   // Vorgabe: offen
    return it->second;
}

inline bool UiConsumeOpen(const char* base) {
    auto& v = UiOpenRequests();
    for (size_t i = 0; i < v.size(); ++i)
        if (v[i] == base) { v.erase(v.begin() + (long)i); return true; }
    return false;
}


inline const char* UiPageWindow(const char* base) {
    // ROTIERENDE PUFFER statt eines einzigen. Mit nur einem Puffer
    // ueberschreibt jeder weitere Aufruf das Ergebnis des vorherigen --
    //     const char* a = UiPageWindow("A");
    //     const char* b = UiPageWindow("B");   // a zeigt jetzt auf "B"!
    // Solange jeder Aufruf sofort verbraucht wird, faellt das nicht auf;
    // sobald zwei Titel gleichzeitig leben (oder der Compiler die
    // Auswertungsreihenfolge der Argumente umstellt), zeichnet die App
    // stillschweigend das falsche Fenster. Acht Plaetze reichen weit.
    static char bufs[8][160];
    static int  slot = 0;
    char* buf = bufs[slot];
    slot = (slot + 1) % 8;
    // GESCHLOSSEN? Dann gar nicht zeichnen.
    // [Das ist der Kern: Schliessen wirkt jetzt fuer JEDES Fenster, ohne
    //  dass die Zeichenstelle einen Wunsch konsumieren muss. Sie ruft
    //  UiPageWindow und bekommt nullptr -- und zeichnet nichts.
    //  Wuensche, die noch irgendwo eingetragen werden, wandern hier in
    //  den Schalter, damit beide Wege dasselbe bewirken.]
    {
        auto& wl = UiCloseRequests();
        for (size_t i = 0; i < wl.size(); ) {
            if (wl[i] == base) { UiWinOpen(base) = false; wl.erase(wl.begin() + (long)i); }
            else ++i;
        }
        auto& ol = UiOpenRequests();
        for (size_t i = 0; i < ol.size(); ) {
            if (ol[i] == base) { UiWinOpen(base) = true; ol.erase(ol.begin() + (long)i); }
            else ++i;
        }
        if (!UiWinOpen(base)) return nullptr;
    }
    UiPage* pg = UiActivePage();
    if (!pg) return base;
    std::string scoped = std::string(base) + "##" + pg->name;
    for (const auto& n : pg->windows) {
        if (n == scoped) {
            snprintf(buf, sizeof(bufs[0]), "%s", scoped.c_str());
            return buf;
        }
        if (n == base) return base;
    }
    for (const auto& p2 : UiPages())
        for (const auto& n : p2.windows)
            if (n == base || n == std::string(base) + "##" + p2.name)
                return nullptr;      // anderswo registriert -> hier aus
    return base;                      // unregistriert -> immer sichtbar
}

// Zusatz-Flags fuer Inhalts-Fenster: Ist das Fenster STATISCH (Hoehe
// folgt dem Inhalt), wird der vertikale Scrollbalken unterdrueckt. Sonst
// blitzt er in dem einen Frame auf, in dem der Inhalt schon gewachsen,
// die Hoehe aber noch nicht nachgezogen ist (Durchsetzung laeuft am
// Frame-ENDE) -- sichtbar z.B. beim Eingabe-Monitor bei jedem Tap.
inline ImGuiWindowFlags UiWinFlags(const char* title) {
    // KEIN HORIZONTALER BALKEN, in keinem Fenster.
    // [Hier stand ImGuiWindowFlags_HorizontalScrollbar -- damit bekam JEDES
    //  Fenster einen Balken, sobald ein Element ein Pixel zu breit war.
    //  Das war die Quelle des "ueberall horizontal scrollen". Inhalte
    //  brechen jetzt um (ui_form.h); was dennoch zu breit ist, wird
    //  abgeschnitten statt gescrollt.]
    ImGuiWindowFlags f = ImGuiWindowFlags_None;
    // Eintrag anlegen (Standard = statisch): Der Latch-Zustand des
    // horizontalen Balkens muss speicherbar sein.
    std::string pkey = ui_pages_detail::UiPropsKey(title);
    auto it = ui_pages_detail::g_winProps.find(pkey);
    if (it == ui_pages_detail::g_winProps.end() && !pkey.empty())
        it = ui_pages_detail::g_winProps.emplace(
                 pkey, ui_pages_detail::UiWinProps()).first;
    bool stat = (it == ui_pages_detail::g_winProps.end())
              ? ui_pages_detail::UiWinProps().fixHeight
              : it->second.fixHeight;
    if (it != ui_pages_detail::g_winProps.end() && it->second.adaptive)
        stat = false;
    // HOEHEN-SPERRE fuer JEDES fixHeight-Fenster -- auch adaptive:
    // dort klemmt die EINFRIER-Hoehe (lockedH), sonst goodWant/Ist.
    // (Vorher hing die Sperre am "stat"-Flag, das der Adaptiv-Ausstieg
    // loeschte -- adaptive Fenster blieben frei in der Hoehe ziehbar.)
    if (it != ui_pages_detail::g_winProps.end()
        && it->second.fixHeight) {
        ImGuiWindow* wl = ImGui::FindWindowByName(title ? title : "");
        // ZIEHT der Nutzer GERADE am Rand DIESES Fensters, wird die
        // Hoehen-Sperre ausgesetzt und die neue Hoehe danach als
        // Einfrier-Hoehe uebernommen. [Sonst war jedes statische
        // Fenster -- Standard! -- am unteren Rand unskalierbar, z.B.
        // "Rain".]
        bool resizing = false;
        if (wl) {
            ImGuiContext* gc = ImGui::GetCurrentContext();
            if (gc && gc->ActiveId != 0 && gc->ActiveIdWindow == wl) {
                for (int ri = 0; ri < 4 && !resizing; ++ri)
                    if (gc->ActiveId ==
                        ImGui::GetWindowResizeCornerID(wl, ri))
                        resizing = true;
                for (int bi = 0; bi < 4 && !resizing; ++bi)
                    if (gc->ActiveId ==
                        ImGui::GetWindowResizeBorderID(wl, (ImGuiDir)bi))
                        resizing = true;
            }
            if (resizing) {
                it->second.lockedH  = wl->SizeFull.y;   // laufend
                it->second.goodWant = wl->SizeFull.y;   // nachfuehren
            }
        }
        if (wl && !resizing && !wl->DockIsActive
            && !(wl->Flags & ImGuiWindowFlags_AlwaysAutoResize)) {
            float hLock = -1.0f;
            if (it->second.adaptive)
                hLock = it->second.lockedH;
            else if (it->second.goodWant > 1.0f)
                hLock = it->second.goodWant;
            if (hLock <= 1.0f) hLock = wl->SizeFull.y;
            if (hLock > 1.0f)
                ImGui::SetNextWindowSizeConstraints(
                    ImVec2(0.0f, hLock), ImVec2(1.0e9f, hLock));
        }
    }
    // STATISCH: vertikalen Balken unterdruecken, horizontalen behalten.
    // ImGui prueft AlwaysHorizontalScrollbar VOR NoScrollbar -- die
    // Kombination ergibt daher exakt das Gewuenschte. Ob der horizontale
    // Balken noetig ist, verraet der Zustand des Vorframes (ScrollbarX);
    // ohne Ueberbreite bleibt es bei NoScrollbar, also ganz ohne Balken.
    if (stat) {
        f |= ImGuiWindowFlags_NoScrollbar;
        // HENNE-EI: ScrollbarX ist bei gesetztem NoScrollbar IMMER
        // false -- daraus haette der horizontale Balken nie entstehen
        // koennen. Deshalb direkt die Ueberbreite messen.
        ImGuiWindow* w = ImGui::FindWindowByName(title ? title : "");
        // Y-RESIZE AN DER WURZEL UNMOEGLICH MACHEN: Die bisherige Abwehr
        // (ClearActiveID am Frame-ENDE in UiFixedHeightEnforce) griff
        // erst, NACHDEM ImGui den Rand-Zug im Begin schon angewandt
        // hatte -- statische Fenster liessen sich daher weiterhin an
        // den Fenstergrenzen in der Hoehe ziehen. Ein Size-Constraint
        // wirkt dagegen IM Begin selbst: die Hoehe ist festgeklemmt
        // (Sollhoehe goodWant, sonst Ist-Hoehe), die BREITE bleibt frei.
        // Gedockte Fenster regelt der Dock-Baum; AlwaysAutoResize regelt
        // sich selbst -- beide bleiben unangetastet.
        if (w && it != ui_pages_detail::g_winProps.end()) {
            float avail = w->InnerRect.GetWidth();
            float need  = w->ContentSize.x > w->ContentSizeIdeal.x
                        ? w->ContentSize.x : w->ContentSizeIdeal.x;
            bool over = (avail > 1.0f && need > avail + 1.0f);
            // VERRASTEN: Waere die Entscheidung pro Frame neu, schaltete
            // der Balken bei wechselnd langen Zeilen staendig um -- und
            // JEDER Wechsel aendert die Inhaltshoehe um die Balkenhoehe.
            // Das war der Motor fuer das Ruckeln und den Doppler im
            // restlichen Layout. Einmal noetig -> bleibt; erst nach
            // laengerer Zeit ohne Ueberbreite (ca. 2s) faellt er weg.
            if (over) { it->second.hbarLatch = true; it->second.hbarOff = 0; }
            else if (it->second.hbarLatch && ++it->second.hbarOff > 120)
                it->second.hbarLatch = false;
            if (it->second.hbarLatch)
                f |= ImGuiWindowFlags_AlwaysHorizontalScrollbar;
        }
    }
    return f;
}

inline const char* UiPageScopedTitle(const char* base) {
    static char buf[160];
    UiPage* pg = UiActivePage();
    snprintf(buf, sizeof(buf), "%s##%s", base, pg ? pg->name.c_str() : "");
    return buf;
}

inline bool UiPageContains(const char* name) {
    UiPage* pg = UiActivePage();
    if (!pg) return true;
    for (const auto& n : pg->windows) if (n == name) return true;
    for (const auto& page : UiPages())
        for (const auto& n : page.windows)
            if (n == name) return false;   // anderswo registriert -> hier aus
    return true;                            // unregistriert -> immer sichtbar
}

// ---- Zustaende sichern/anwenden (die EINZIGEN Schreib-/Lesestellen) ----
// [AUSGELAGERT nach ui_pages.cpp -- Build-Beschleunigung:
//  der Rumpf wird nur noch EINMAL uebersetzt statt in jeder
//  Datei, die ui_pages.h einbindet.]
void SavePageState(UiPage& pg, bool force = false);
// [AUSGELAGERT nach ui_pages.cpp -- Build-Beschleunigung:
//  der Rumpf wird nur noch EINMAL uebersetzt statt in jeder
//  Datei, die ui_pages.h einbindet.]
void ApplyPageState(UiPage& pg);

// Nach AppSettings::Load aufrufen: wendet den gespeicherten Zustand der
// aktiven Seite AKTIV an. Der fruehere Boot-Guard verliess sich auf
// imgui.ini -- fehlt/greift die nicht (Android!), blieben alle Fenster
// auf Frischstart-Defaults "ganz oben". Jetzt gilt: gespeicherte Frei-
// Positionen werden via Pending gesetzt (wartet, bis Fenster existieren),
// Kompakt-Seiten errichten ihren Layout-Baum; Fenster OHNE Daten erhalten
// eine Mitte-Kaskade als Standard.
inline void UiPagesBootApply() {
    using namespace ui_pages_detail;
    UiPage* pg = UiActivePage();
    if (!pg) return;
    ImGuiViewport* vp = ImGui::GetMainViewport();
    if (pg->compact) {
        if (!g_layout[pg->name].empty())
            { pg->needLayout = true; pg->needRebuild = false; }
        else pg->needRebuild = true;
        // Bewusst floatende Seitenfenster: gespeicherte Frei-Position
        // anwenden (Pending wartet, bis das Fenster existiert und frei ist).
        {
            auto& fm = g_free[pg->name];
            for (const auto& n : pg->windows)
                if (!LayoutHasWindow(pg->name, n)) {
                    auto it = fm.find(n);
                    if (it != fm.end()) g_pendingFree[n] = it->second;
                }
        }
        return;
    }
    auto& fm = g_free[pg->name];
    int i = 0;
    for (const auto& n : pg->windows) {
        auto it = fm.find(n);
        if (it != fm.end()) {
            g_pendingFree[n] = it->second;
        } else {
            Snap sn;                       // Standard: Bildschirmmitte,
            sn.pos = ImVec2(               // leicht kaskadiert
                vp->WorkPos.x + vp->WorkSize.x * 0.5f - 210.0f + i * 28.0f,
                vp->WorkPos.y + vp->WorkSize.y * 0.35f + i * 28.0f);
            sn.size = ImVec2(0, 0);        // Groesse unangetastet
            g_pendingFree[n] = sn;
        }
        ++i;
    }
}

// "Resize/Move Affects Neighbors" fuer FREI arrangierte Fenster:
// TREIBER ist jedes aktiv gefuehrte freie Fenster, dessen Rechteck sich
// aendert -- per Titel-Drag (MovingWindow) ODER per Rand/Ecke (Resize-
// IDs). Aus der Rechteck-Differenz ergeben sich die bewegten Kanten;
// jede auswaerts bewegte Kante schiebt die dahinterliegenden Fenster
// mit, und die Geschobenen kaskadieren per Breitensuche weiter -- in
// alle vier Richtungen (beim Move drueckt automatisch nur die
// Bewegungsseite). Einwaerts (Schrumpfen/Wegbewegen) zieht nichts nach.
// Am Frame-ENDE aufrufen (nach allen Fenstern).
// [AUSGELAGERT nach ui_pages.cpp -- Build-Beschleunigung:
//  der Rumpf wird nur noch EINMAL uebersetzt statt in jeder
//  Datei, die ui_pages.h einbindet.]
void UiResizePushNeighbors(bool enabled);
#ifndef READ_WHOLE_FILE
#define READ_WHOLE_FILE
inline std::string read_whole_file(const std::string& filename) {
  std::string txt;
  UiReadFile(filename.c_str(), txt);
  return txt;
  // FILE* f = fopen(filename.c_str(), "rb");
  // if (!f) {
  //   f = fopen(filename.c_str(), "wb");
  //   return "";
  // }
  // std::fseek(f, 0, SEEK_END);
  // long size = std::ftell(f);
  // std::rewind(f);
  // std::string contents;
  // if (size > 0) {
  //   contents.resize(size);
  //   std::size_t bytesRead=std::fread(&contents[0], 1, size, f);
  //   contents.resize(bytesRead);
  // }
  // std::fclose(f);
  // return contents;
}

inline std::vector<std::string_view> split_by_comma_or_space(std::string_view text) {
    std::vector<std::string_view> tokens;
    std::string_view delimiters = ", ";
    
    size_t start = text.find_first_not_of(delimiters);
    while (start != std::string_view::npos) {
        size_t end = text.find_first_of(delimiters, start);
        
        // Add the substring slice without copying memory
        tokens.push_back(text.substr(start, end - start));
        
        start = text.find_first_not_of(delimiters, end);
    }
    return tokens;
}

#endif

// ui_pages.h, deutlich VOR der ersten Verwendung
inline std::function<bool(const std::vector<std::string_view>& sources,
                          const std::vector<std::string_view>& names,
                          int mode, bool test)>& UiMailSender() {
    static std::function<bool(const std::vector<std::string_view>&,
                              const std::vector<std::string_view>&,
                              int, bool)> fn;
    return fn;
}

// ===========================================================================
// FENSTER AN DIE TASTATUR ANPASSEN
// ---------------------------------------------------------------------------
// Faehrt die Android-Tastatur aus, schrumpft der sichtbare Bereich. Frei
// schwebende Fenster ragen dann unten heraus: Ihr Inhalt (und oft der
// Knopf, den man gerade braucht) liegt hinter der Tastatur. Diese
// Funktion holt sie in den sichtbaren Bereich zurueck -- erst durch
// VERKLEINERN, und wenn das nicht reicht, durch HOCHSCHIEBEN.
//
// Beim Einfahren der Tastatur wird der vorherige Zustand wieder
// hergestellt; deshalb werden Groesse UND Position gemerkt, sobald die
// Tastatur aufgeht. Angedockte Fenster bleiben unberuehrt -- die regelt
// der Dock-Knoten, der mit dem Viewport ohnehin mitschrumpft.
// ===========================================================================
// [AUSGELAGERT nach ui_pages.cpp -- Build-Beschleunigung:
//  der Rumpf wird nur noch EINMAL uebersetzt statt in jeder
//  Datei, die ui_pages.h einbindet.]
void UiFitWindowsToKeyboard();

// Dock-ID der AKTIVEN Seite -- damit sich Fenster beim ERSTEN Start
// selbst in den Seiten-DockSpace einhaengen koennen.
inline ImGuiID UiPageDockId() {
    using namespace ui_pages_detail;
    UiPage* pg = UiActivePage();
    return pg ? PageDockId(*pg) : 0;
}

// Gemessene Hoehe der Bedienelemente UNTER der Textflaeche (wird pro
// Frame nachgefuehrt; Startwert nur fuer den allerersten Frame).
inline float& UiChromeBelow() { static float v = 90.0f; return v; }

// Setzt fuer VOLLBILD-Fenster die noetigen Fensterflaggen: kein
// Aufblaehen durch Inhalt, keine eigene Groessenaenderung. Der Knoten
// gibt die Groesse vor, alles darin passt sich an.
inline ImGuiWindowFlags UiFullscreenFlags(const char* base) {
    ImGuiWindowFlags f = UiWinFlags(base);
    if (ui_pages_detail::UiPropsFor(base).fullscreen)
        f |= ImGuiWindowFlags_NoResize;
    return f;
}

// [AUSGELAGERT nach ui_pages.cpp -- Build-Beschleunigung:
//  der Rumpf wird nur noch EINMAL uebersetzt statt in jeder
//  Datei, die ui_pages.h einbindet.]
void UiDrawBewerbenUI(const char* t, bool* open);

// Sektion "Fenster-Eigenschaften" fuer das Einstellungsfenster: pro
// registriertem Fenster der aktiven Seite die Eigenschafts-Checkboxen.
inline void UiDrawWindowPropsUI() {
    using namespace ui_pages_detail;
    UiPage* pg = UiActivePage();
    if (!pg) return;
    if (!ImGui::CollapsingHeader("Fenster-Eigenschaften")) return;
    for (const auto& n : pg->windows) {
        ImGui::PushID(n.c_str());
        bool v = UiPropsFor(n.c_str()).fixHeight;
        // Anzeigename ohne ##-Suffix
        std::string label = n.substr(0, n.find("##"));
        if (ImGui::Checkbox(("Hoehe = Inhalt (statisch): " + label)
                                .c_str(), &v)) {
            UiWinProps& wpn = UiPropsFor(n.c_str());
            wpn.fixHeight = v;
            if (v) UiCaptureLockedH(UiPropsKey(n.c_str()));
            wpn.adaptive = false;      // Adaptiv-Ausstieg zuruecknehmen:
            wpn.growStreak = 0;        // die neue Einstellung soll eine
            wpn.streakFrame = -1;      // frische Chance bekommen
            wpn.baselineH = -1.0f;
            wpn.lastWant = -1.0f;
            UiPagesPersist();
        }
        ImGui::PopID();
    }
}

// FIXHOEHEN-DURCHSETZUNG -- am FRAME-ENDE aufrufen (nach allen Fenstern
// und dem DockSpace), damit sie das LETZTE Wort hat: die Hoehe ist damit
// auch WAEHREND eines Resize-Zugs festgenagelt, nicht erst per Snap-Back.
// Gedockt wird das GESCHWISTER im selben Zug kompensiert -- nur die
// eigene SizeRef anzuheben liess ImGuis Ratio-Layout die Differenz
// geometrisch anteilig anwenden: das sichtbare "langsame" Wachsen.
// GLOBALE LAYOUT-SPERRE: entwaffnet app-seitig alle vier Interaktions-
// arten (Fenster-/Tab-Bewegung, Resize-Raender, Dock-Splitter, Kaskade).
// BEWUSST NICHT ueber ImGuiConfigFlags_DockingEnable: das Kappen des
// Docking-Flags hat frueher einen Crash bei kompakter Seite erzeugt.
// ===========================================================================
// FENSTER-EIGENSCHAFTEN AM PFEIL OBEN LINKS. Jedes Fenster mit einem
// Eigenschafts-Eintrag bekommt oben links einen kleinen Pfeil; ein Tipp
// darauf oeffnet ein Panel mit den Eigenschaften DIESES Fensters (heute:
// die Statik-Checkbox samt Adaptiv-Status, spaeter beliebig erweiterbar).
// Damit wandern die Einstellungen vom zentralen Einstellungsfenster
// direkt an das Fenster, um das es geht.
//  * GEDOCKT: Der Pfeil sitzt auf der Tab-Leiste des Knotens; ImGuis
//    eigener Fenstermenue-Knopf wird dort unterdrueckt
//    (NoWindowMenuButton), damit nur EIN Pfeil existiert.
//  * FREISCHWEBEND: Der Pfeil sitzt auf der Titelzeile; das native
//    Einklappen uebernimmt diese Position (UiWinFlags setzt NoCollapse),
//    der Tipp gehoert also ganz dem Eigenschaften-Panel.
// AUFRUF: einmal pro Frame am FRAME-ENDE (aus UiFixedHeightEnforce),
// damit das Panel NACH allen Fenstern submittet wird und obenauf liegt.
// ===========================================================================
// ===========================================================================
// IME-VERMEIDUNG (Android-Tastatur). Aufruf pro Frame VOR den Fenstern,
// NACHDEM der Arbeitsbereich bereits um die Tastatur verkleinert wurde
// (visBottom = Tastatur-Oberkante). Verhalten:
//  * OEFFNUNGS-Moment: Liegt der Text-Caret (PlatformImeData) unter der
//    Tastatur oder ausserhalb, springt der Seiten-Scroll UNVERZOEGERT so,
//    dass der Caret in der MITTE des freien Restbereichs steht; ist er
//    sichtbar, wird er exakt dort FESTGENAGELT.
//  * DANACH: Verschiebt IRGENDETWAS (Relayout, dockH-Aenderung, ...) den
//    Caret, wird der Scroll um exakt die Differenz nachgezogen -- der
//    Caret bleibt optisch stehen, die App scrollt sichtbar NICHT hin und
//    her. Waehrend der Nutzer selbst scrollt, folgt der Nagel dem Nutzer.
//    Geraet der Nagel selbst in den verdeckten Bereich, rueckt er in die
//    Mitte des freien Teils nach.
// ===========================================================================
// IME-VERMEIDUNG (Android-Tastatur), Fassung 2. Garantien:
//  * Das AKTIVE Textfeld (Caret aus PlatformImeData) ist IMMER im
//    freien Rest-Viewport sichtbar -- notfalls wird pro Frame hart
//    nachkorrigiert (frueher konnte der Pin an ScrollMax scheitern und
//    das Feld rutschte aus dem Sichtbaren).
//  * Liegt das Feld beim Aufgehen bereits im freien Bereich, wird es
//    dort FESTGENAGELT: waehrend der gesamten Tastatur-Animation sieht
//    es aus, als haette sich nichts verschoben.
//  * Steckt das Feld in einem FREI schwebenden Fenster, wird das
//    FENSTER verschoben (Seiten-Scroll kann es nicht erreichen).
// ===========================================================================
// [AUSGELAGERT nach ui_pages.cpp -- Build-Beschleunigung:
//  der Rumpf wird nur noch EINMAL uebersetzt statt in jeder
//  Datei, die ui_pages.h einbindet.]
void UiImeAvoidance(bool imeVisible, float visTop, float visBottom);

// SCHLIESS-WUENSCHE fuer frei schwebende Fenster OHNE nativen X-Knopf

// PROGRAMMIERBARE Zusatzeintraege fuer das Drei-Punkte-Menue: einfach
// per UiWindowDotsExtras().push_back({"Mein Eintrag", &MeineFn}); die
// Funktion bekommt das Zielfenster. Eintraege gelten fuer ALLE Fenster;
// wer fensterspezifisch sein will, prueft im Callback den Namen.
struct UiDotsEntry {
    std::string label;
    void (*fn)(ImGuiWindow*);
};
inline std::vector<UiDotsEntry>& UiWindowDotsExtras() {
    static std::vector<UiDotsEntry> v;
    return v;
}

// ===========================================================================
// AUTO-EDGE-SCROLLING: Haelt der Finger waehrend einer laufenden Geste
// (Pinpoint-Scroll ODER Fenster-/Tab-Zug) in der Randzone des sicht-
// baren Bereichs, scrollt die Seite dort selbsttaetig weiter -- man
// erreicht so Inhalte ausserhalb des Schirms, ohne nachgreifen zu
// muessen. Geschwindigkeit waechst linear mit der Eintauchtiefe.
// ===========================================================================
inline void UiEdgeAutoScroll(float visTop, float visBottom) {
    using namespace ui_pages_detail;
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g) return;
    ImGuiIO& io = g->IO;
    bool gesture = UiScrollGestureActive() || UiEdgeAutoActive()
                || g->MovingWindow != nullptr || g->DragDropActive
                || UiSplitterGrabActive();   // Fenstergrenzen ziehen
    if (!gesture || !io.MouseDown[0]) return;
    ImGuiWindow* host = nullptr;
    for (ImGuiWindow* w : g->Windows)
        if (w->WasActive && !w->Hidden
            && strncmp(w->Name, "##page_host_", 12) == 0)
            { host = w; break; }
    if (!host || host->ScrollMax.y <= 0.5f) return;
    const float zone = 64.0f;        // Randzone
    const float vMax = 900.0f;       // px/s am aeussersten Rand
    float dy = 0.0f;
    float my = io.MousePos.y;
    if (my > visBottom - zone) dy =  (my - (visBottom - zone)) / zone;
    else if (my < visTop + zone) dy = (my - (visTop + zone)) / zone;
    if (dy > 1.0f) dy = 1.0f;
    if (dy < -1.0f) dy = -1.0f;
    if (dy == 0.0f) return;
    float dt = io.DeltaTime > 0.0f ? io.DeltaTime : 0.016f;
    float ns = host->Scroll.y + dy * vMax * dt;
    if (ns < 0.0f)              ns = 0.0f;
    if (ns > host->ScrollMax.y) ns = host->ScrollMax.y;
    if (ns != host->Scroll.y) ImGui::SetScrollY(host, ns);
}

// [AUSGELAGERT nach ui_pages.cpp -- Build-Beschleunigung:
//  der Rumpf wird nur noch EINMAL uebersetzt statt in jeder
//  Datei, die ui_pages.h einbindet.]
void UiWindowPropsMenuFrame();

inline void UiLayoutLockEnforce() {
    if (!EffectsGl_Settings().lockLayout) return;
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g) return;
    // Fenster-/Tab-Bewegung (Undocking, Umsortieren) unterbinden
    if (g->MovingWindow) {
        ImGui::ClearActiveID();
        g->MovingWindow = nullptr;
    }
    if (g->ActiveId == 0) return;
    ImGuiWindow* aw = g->ActiveIdWindow;
    if (!aw) return;
    // Resize-Raender und -Ecken jedes Fensters
    for (int d = 0; d < 4; ++d)
        if (g->ActiveId == ImGui::GetWindowResizeBorderID(aw,
                               (ImGuiDir)d)) {
            ImGui::ClearActiveID();
            return;
        }
    for (int c = 0; c < 4; ++c)
        if (g->ActiveId == ImGui::GetWindowResizeCornerID(aw, c)) {
            ImGui::ClearActiveID();
            return;
        }
    // Dock-Splitter (leben im DockSpace-Kindfenster)
    if (g->HoveredId == 0 && aw->Name
        && strstr(aw->Name, "DockSpace") != nullptr) {
        ImGui::ClearActiveID();
    }
}

// RUECKDOCK-NETZ: ImGui entdockt bereits im SELBEN Frame, in dem ein
// Tab-Zug beginnt -- eine Sperre am Frame-Ende kommt zu spaet. Entkommene
// Seitenfenster werden bei aktiver Sperre daher sofort an ihren
// gemerkten Knoten zurueckgeholt.
// DIREKT NACH ImGui::NewFrame() aufrufen -- VOR jedem Begin. Nur hier
// laesst sich der Tab-Zug toeten, BEVOR ImGui ihn beim Begin der
// Tab-Leiste in ein Undock verwandelt (Tab-Gruppen loesten sich sonst
// trotz Sperre und blieben als schwebende Fenster stehen).
inline void UiLayoutLockNewFrame() {
    if (!EffectsGl_Settings().lockLayout) return;
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g) return;
    // NUR die Bewegung selbst stoppen. [Die erste Fassung loeschte
    // zusaetzlich ActiveIds auf Dock-Hosts -- damit waren Checkboxen und
    // Buttons nicht mehr bedienbar.]
    if (g->MovingWindow) { g->MovingWindow = nullptr; ImGui::ClearActiveID(); }
    if (g->DragDropActive && g->DragDropPayload.IsDataType("_IMWINDOW"))
        ImGui::ClearDragDrop();
}

inline void UiLayoutLockRedock() {
    using namespace ui_pages_detail;   // g_dock, UiActivePage, ...
    if (!EffectsGl_Settings().lockLayout) return;
    // NUR nach dem Loslassen und GEDROSSELT: DockBuilderFinish ist ein
    // kompletter Layout-Neuaufbau. Pro Frame ausgefuehrt zerlegte er die
    // Interaktion (Checkboxen tot), liess Fenster springen und Groessen
    // eskalieren. Waehrend des Zugs passiert nichts -- beim Loslassen
    // kehrt das Fenster an seinen Platz zurueck.
    if (ImGui::GetIO().MouseDown[0]) return;
    static double lastRedock = -1.0;
    if (ImGui::GetTime() - lastRedock < 0.3) return;
    bool did = false;
    UiPage* pg = UiActivePage();
    if (!pg || !pg->compact) return;
    ImGuiID dockId = ImGui::GetID(("##page_dock_" + pg->name).c_str());
    if (!ImGui::DockBuilderGetNode(dockId)) return;
    for (const auto& nm : pg->windows) {
        ImGuiWindow* w = ImGui::FindWindowByName(nm.c_str());
        if (!w || !w->WasActive) continue;
        bool inTree = false;
        if (w->DockNode) {
            ImGuiDockNode* t = w->DockNode;
            while (t->ParentNode) t = t->ParentNode;
            inTree = (t->ID == dockId);
        }
        if (inTree) continue;
        ImGuiID tgt = 0;
        auto itD = g_dock[pg->name].find(nm);
        if (itD != g_dock[pg->name].end()) {
            ImGuiDockNode* tn = ImGui::DockBuilderGetNode(itD->second);
            // NUR verwenden, wenn der Knoten IM BAUM DIESER SEITE
            // haengt. [Die blosse Existenzpruefung reichte nicht: Die
            // gemerkte ID kann inzwischen zu einer ANDEREN (gerade nicht
            // sichtbaren) Seite gehoeren -- das Fenster wurde dorthin
            // gedockt und war "komplett verschwunden". Genau das
            // passierte auf Linux beim Abdocken mit Layout-Sperre.]
            if (tn) {
                ImGuiDockNode* r = tn;
                while (r->ParentNode) r = r->ParentNode;
                if (r->ID == dockId) tgt = itD->second;
            }
        }
        ImGui::DockBuilderDockWindow(nm.c_str(), tgt ? tgt : dockId);
        did = true;
    }
    if (did) {
        ImGui::DockBuilderFinish(dockId);   // EINMAL pro Sammelvorgang
        lastRedock = ImGui::GetTime();
    }
}

// VORAB-DURCHLAUF (Frame-ANFANG): Setzt fuer statische Fenster die
// zuletzt GEMESSENE Sollhoehe, bevor irgendein Fenster gezeichnet wird.
// Ohne ihn waechst der Inhalt (neue Monitorzeile) SOFORT, die Hoehe aber
// erst am Frame-ENDE -- in diesem einen Frame ist der Inhalt zu hoch:
// ImGui blendet den vertikalen Balken ein und das Fenster zuckt.
// Gemessen (und damit goodWant aktualisiert) wird weiterhin am Ende.
inline void UiFixedHeightPreFrame() {
    using namespace ui_pages_detail;
    ImGuiContext* g = ImGui::GetCurrentContext();
    if (!g) return;
    for (ImGuiWindow* w : g->Windows) {
        if (!w->WasActive) continue;
        if (w->Flags & (ImGuiWindowFlags_ChildWindow
                        | ImGuiWindowFlags_Tooltip
                        | ImGuiWindowFlags_Popup)) continue;
        auto it = g_winProps.find(UiPropsKey(w->Name));
        if (it == g_winProps.end()) continue;
        if (!it->second.fixHeight || it->second.adaptive) continue;
        float want = it->second.goodWant;
        if (want <= 1.0f) continue;
        if (w->DockIsActive && w->DockNode && !w->DockNode->ChildNodes[0]) {
            ImGuiDockNode* nd = w->DockNode;
            float dv = want - nd->Size.y;
            if (dv > 0.5f) {           // nur WACHSEN vorab anwenden
                UIP_LOGF("W[%s]: pre-node %.0f -> %.0f",
                        w->Name, nd->Size.y, want);
                nd->Size.y = want; nd->SizeRef.y = want;
            }
        } else if (!w->DockIsActive) {
            if (want > w->Size.y + 0.5f)
                ImGui::SetWindowSize(w, ImVec2(w->Size.x, want),
                                     ImGuiCond_Always);
        }
    }
}

// [AUSGELAGERT nach ui_pages.cpp -- Build-Beschleunigung:
//  der Rumpf wird nur noch EINMAL uebersetzt statt in jeder
//  Datei, die ui_pages.h einbindet.]
void UiFixedHeightEnforce();
// Vom Hauptprogramm am Frame-Ende statt ImGui::Render() + Swap zu rufen:
// true = diesen Frame nur beenden (EndFrame), NICHT praesentieren.
bool UiPagesFrameNurWarm();

// [AUSGELAGERT nach ui_pages.cpp -- Build-Beschleunigung:
//  der Rumpf wird nur noch EINMAL uebersetzt statt in jeder
//  Datei, die ui_pages.h einbindet.]
void UiPagesFrame(bool touchMode);

// Kompatibilitaets-Aliase (app_settings.h u.a.)
inline void UiPagesSnapshot(UiPage& pg) { SavePageState(pg); }
inline void UiPagesRestore (UiPage& pg) { ApplyPageState(pg); }
