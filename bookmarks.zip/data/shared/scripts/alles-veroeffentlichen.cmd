# Alle Ziele bauen + veroeffentlichen, dann APK aufs Handy (Windows).
cd ~/bookmarks && ./build.sh --publish deb@local exe@windows apk@buildserver --no-publish --run-only apk@windows
