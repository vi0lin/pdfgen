#!/bin/bash
cd /home/user/MRTN/m/c/bookmarks
./build.sh --publish deb@local exe@windows apk@buildserver --run-only apk@windows
