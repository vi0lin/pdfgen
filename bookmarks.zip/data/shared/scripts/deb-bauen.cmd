# Netzwerk-Script -- eine Befehlszeile. Kommentarzeilen beginnen mit #.
# Baut das Linux-Ziel auf dem Geraet, auf dem es ausgefuehrt wird.
cd ~/bookmarks && ./build.sh deb@local
