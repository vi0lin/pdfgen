#!/usr/bin/env python3
# ---------------------------------------------------------------------------
# monitor_server.py -- BERICHTE UND LOGS ALLER CLIENTS AN EINEM ORT.
#
# Nimmt Absturz-/Fehlerberichte per POST entgegen (xbm_crash.cpp schickt
# sie automatisch), legt sie je Geraet ab und zeigt sie als Webseite.
# Keine Abhaengigkeiten ausser Python 3.
#
#   python3 monitor_server.py                # Port 3010, Ordner ./berichte
#   python3 monitor_server.py 3010 /srv/xbm  # eigener Port/Ordner
#
# In der App (Einstellungen -> Monitor-URL):  http://<server>:3010/bericht
#
# Seiten:
#   /                 Uebersicht: Geraete, Anzahl Berichte, letzter Eingang
#   /geraet/<name>    alle Berichte eines Geraets
#   /bericht/<name>/<datei>   ein Bericht im Klartext
#   /api/liste        alles als JSON (fuer eigene Werkzeuge)
# ---------------------------------------------------------------------------
import http.server, json, os, sys, time, html, urllib.parse

PORT   = int(sys.argv[1]) if len(sys.argv) > 1 else 3010
WURZEL = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.getcwd(), "berichte")
os.makedirs(WURZEL, exist_ok=True)
INDEX  = os.path.join(WURZEL, "index.json")   # die "Datenbank": eine JSON-Zeilenliste

def index_laden():
    try:
        with open(INDEX, encoding="utf-8") as f: return json.load(f)
    except Exception: return []

def index_speichern(eintraege):
    tmp = INDEX + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f: json.dump(eintraege, f, ensure_ascii=False, indent=1)
    os.replace(tmp, INDEX)

def sicher(name):   # Dateiname/Geraet ohne Pfadtricks
    return "".join(c for c in name if c.isalnum() or c in "-_.")[:120] or "unbenannt"

def kopf_lesen(text):
    """Die 'schluessel: wert'-Zeilen am Anfang eines Berichts."""
    k = {}
    for z in text.splitlines()[:12]:
        if ":" in z and not z.startswith("==="):
            a, b = z.split(":", 1); k[a.strip()] = b.strip()
    return k

class H(http.server.BaseHTTPRequestHandler):
    def _antwort(self, code, body, typ="text/html; charset=utf-8"):
        b = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code); self.send_header("Content-Type", typ)
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

    def do_POST(self):
        if self.path != "/bericht": return self._antwort(404, "nicht gefunden", "text/plain")
        n = int(self.headers.get("Content-Length", "0") or 0)
        text = self.rfile.read(n).decode("utf-8", "replace")
        geraet = sicher(self.headers.get("X-Xbm-Geraet", "") or kopf_lesen(text).get("geraet", ""))
        datei  = sicher(self.headers.get("X-Xbm-Datei", "") or f"bericht-{int(time.time())}.txt")
        ordner = os.path.join(WURZEL, geraet); os.makedirs(ordner, exist_ok=True)
        with open(os.path.join(ordner, datei), "w", encoding="utf-8") as f: f.write(text)
        k = kopf_lesen(text)
        e = index_laden()
        e.append({"geraet": geraet, "datei": datei, "eingang": int(time.time()),
                  "art": k.get("art", k.get("titel", "?")), "version": k.get("version", "?"),
                  "plattform": k.get("plattform", "?")})
        index_speichern(e)
        print(f"[{time.strftime('%H:%M:%S')}] {geraet}: {datei} ({k.get('art', k.get('titel','?'))})")
        self._antwort(200, "ok", "text/plain")

    def do_GET(self):
        p = urllib.parse.unquote(self.path)
        e = index_laden()
        if p == "/api/liste": return self._antwort(200, json.dumps(e, ensure_ascii=False), "application/json")
        if p.startswith("/bericht/"):
            teile = p.split("/")
            if len(teile) == 4:
                pfad = os.path.join(WURZEL, sicher(teile[2]), sicher(teile[3]))
                if os.path.isfile(pfad):
                    with open(pfad, encoding="utf-8", errors="replace") as f: return self._antwort(200, f.read(), "text/plain; charset=utf-8")
            return self._antwort(404, "nicht gefunden", "text/plain")
        stil = "<style>body{font-family:sans-serif;margin:2em}table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:4px 10px;text-align:left}.a{color:#b00}</style>"
        if p.startswith("/geraet/"):
            g = sicher(p[8:]); zeilen = [x for x in reversed(e) if x["geraet"] == g]
            rows = "".join(f"<tr><td>{time.strftime('%d.%m.%Y %H:%M:%S', time.localtime(x['eingang']))}</td>"
                           f"<td class='{'a' if 'SIG' in x['art'] or 'EXC' in x['art'] else ''}'>{html.escape(x['art'])}</td>"
                           f"<td>{html.escape(str(x['version']))}</td>"
                           f"<td><a href='/bericht/{g}/{x['datei']}'>{html.escape(x['datei'])}</a></td></tr>" for x in zeilen)
            return self._antwort(200, f"<html><head><meta charset='utf-8'>{stil}</head><body><a href='/'>&larr; Uebersicht</a><h2>{html.escape(g)}</h2>"
                                      f"<table><tr><th>Eingang</th><th>Art</th><th>Version</th><th>Bericht</th></tr>{rows}</table></body></html>")
        # Uebersicht
        geraete = {}
        for x in e:
            g = geraete.setdefault(x["geraet"], {"n": 0, "abstuerze": 0, "letzter": 0, "plattform": x["plattform"]})
            g["n"] += 1; g["letzter"] = max(g["letzter"], x["eingang"])
            if "SIG" in x["art"] or "EXC" in x["art"]: g["abstuerze"] += 1
        rows = "".join(f"<tr><td><a href='/geraet/{g}'>{html.escape(g)}</a></td><td>{v['plattform']}</td><td>{v['n']}</td>"
                       f"<td class='a'>{v['abstuerze']}</td><td>{time.strftime('%d.%m.%Y %H:%M:%S', time.localtime(v['letzter']))}</td></tr>"
                       for g, v in sorted(geraete.items()))
        self._antwort(200, f"<html><head><meta charset='utf-8'><meta http-equiv='refresh' content='30'>{stil}</head><body><h2>XBM Monitor</h2>"
                           f"<p>{len(e)} Berichte von {len(geraete)} Geraet(en). Ordner: {html.escape(WURZEL)}</p>"
                           f"<table><tr><th>Geraet</th><th>Plattform</th><th>Berichte</th><th>Abstuerze</th><th>letzter Eingang</th></tr>{rows}</table>"
                           f"<p><a href='/api/liste'>JSON</a></p></body></html>")

    def log_message(self, *a): pass   # eigenes Log oben genuegt

if __name__ == "__main__":
    print(f"XBM Monitor auf Port {PORT}, Berichte in {WURZEL}  --  Bericht-URL fuer die App: http://<dieser-rechner>:{PORT}/bericht")
    http.server.ThreadingHTTPServer(("0.0.0.0", PORT), H).serve_forever()
