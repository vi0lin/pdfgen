package com.mrtn.xbookmarkmanager;

// XbmActivity -- echte IME-Anbindung fuer die native App.
//
// WARUM DIESE KLASSE EXISTIERT:
// Eine reine NativeActivity besitzt keine View mit Eingabefokus und damit
// keine InputConnection. Gboard fuegt Text aus seiner Zwischenablage aber
// GENAU darueber ein (ebenso Swipe-Typing, Autokorrektur, Wortvorschlaege)
// -- ohne InputConnection kommt schlicht nichts an. Hier haengt daher ein
// unsichtbares EditText in der Content-View, das den Fokus haelt: Der IME
// schreibt hinein, ein TextWatcher sammelt alles ein, und die native Seite
// holt es pro Frame ab (xbmPollText) und schiebt es in ImGui.

import android.app.NativeActivity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;

public class XbmActivity extends NativeActivity {

    private EditText mInput;
    private final StringBuilder mPending = new StringBuilder();
    private boolean mSelfEdit = false;   // eigene Aenderung ignorieren

    // NETZWERK-TAB: BROADCASTS EMPFANGEN.
    // [Die Berechtigung CHANGE_WIFI_MULTICAST_STATE im Manifest ist nur
    //  die ERLAUBNIS. Ohne dieses Lock filtert der WLAN-Chip eingehende
    //  Broadcasts weg, sobald das Geraet stromsparend arbeitet -- das
    //  Handy sendet dann noch, empfaengt aber nichts und findet niemanden.
    //  Genau das war der Befund: Windows sah Android, Android sah nichts.
    //  Das Lock kostet etwas Akku; es wird beim Beenden freigegeben.]
    private WifiManager.MulticastLock mMulticastLock;

    private void xbmAcquireMulticast() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext()
                                 .getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return;
            mMulticastLock = wm.createMulticastLock("xbm-discovery");
            mMulticastLock.setReferenceCounted(false);
            mMulticastLock.acquire();
        } catch (Throwable t) {
            // Kein WLAN, kein Recht, kein Dienst -- dann eben ohne. Die
            // App soll deswegen nicht sterben.
        }
    }

    private void xbmReleaseMulticast() {
        try {
            if (mMulticastLock != null && mMulticastLock.isHeld())
                mMulticastLock.release();
        } catch (Throwable t) { /* s.o. */ }
        mMulticastLock = null;
    }

    @Override
    protected void onDestroy() {
        xbmReleaseMulticast();
        super.onDestroy();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        xbmAcquireMulticast();
        runOnUiThread(new Runnable() {
            @Override public void run() {
                setupInput();
                xbmInstallImeAnimListener();   // Live-Tastaturhoehe
                xbmInstallKeyBridge();         // Cursortasten (Gboard)
            }
        });
    }

    private void setupInput() {
        FrameLayout root = new FrameLayout(this);
        mInput = new EditText(this);
        // Unsichtbar, aber fokussierbar: 1x1 Pixel, transparent, ohne
        // Cursor. GONE/INVISIBLE waere NICHT fokussierbar -- dann gaebe
        // es wieder keine InputConnection.
        // MULTI_LINE: Damit zeigt der IME eine ENTER-Taste statt "Fertig"
        // und liefert '\n' an den TextWatcher -- ohne dieses Flag gibt es
        // in InputTextMultiline keinen Zeilenumbruch.
        mInput.setInputType(InputType.TYPE_CLASS_TEXT
                          | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                          | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        mInput.setSingleLine(false);
        mInput.setImeOptions(
              android.view.inputmethod.EditorInfo.IME_FLAG_NO_FULLSCREEN
            | android.view.inputmethod.EditorInfo.IME_FLAG_NO_ENTER_ACTION
            | android.view.inputmethod.EditorInfo.IME_ACTION_NONE);
        mInput.setBackgroundColor(0x00000000);
        mInput.setTextColor(0x00000000);
        mInput.setCursorVisible(false);
        mInput.setSingleLine(true);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(1, 1);
        lp.gravity = Gravity.TOP | Gravity.START;
        root.addView(mInput, lp);
        addContentView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        mInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st,
                                                    int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st,
                                                int before, int count) {
                if (mSelfEdit) return;
                if (count > 0) {
                    synchronized (mPending) {
                        mPending.append(s.subSequence(st, st + count));
                    }
                }
            }
            @Override public void afterTextChanged(Editable e) {
                // Puffer leeren, damit der IME nicht endlos waechst und
                // jeder neue Text als frische Aenderung ankommt.
                if (mSelfEdit || e.length() == 0) return;
                mSelfEdit = true;
                e.clear();
                mSelfEdit = false;
            }
        });
    }

    // ---- Von nativer Seite aufgerufen (JNI) -------------------------------

    /** Sammelt seit dem letzten Aufruf eingegangenen Text ein. */
    public String xbmPollText() {
        synchronized (mPending) {
            if (mPending.length() == 0) return "";
            String s = mPending.toString();
            mPending.setLength(0);
            return s;
        }
    }

    /** Tastatur oeffnen/schliessen -- inklusive Fokus fuer die InputConnection. */
    public void xbmSetKeyboard(final boolean show) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (mInput == null) return;
                InputMethodManager imm = (InputMethodManager)
                        getSystemService(INPUT_METHOD_SERVICE);
                if (imm == null) return;
                if (show) {
                    mInput.setFocusableInTouchMode(true);
                    mInput.requestFocus();
                    imm.showSoftInput(mInput, InputMethodManager.SHOW_IMPLICIT);
                } else {
                    imm.hideSoftInputFromWindow(mInput.getWindowToken(), 0);
                    mInput.clearFocus();
                }
            }
        });
    }

    /** LIVE-Hoehe der Tastatur waehrend ihrer Animation (px).
     *  Wird vom WindowInsetsAnimation-Callback pro Animationsschritt
     *  gesetzt; -1 = kein Callback aktiv, dann gilt der Abfragewert. */
    private volatile int mImeAnimH = -1;

    /** Registriert den Animations-Callback (API 30+).
     *  GRUND: getRootWindowInsets() liefert waehrend der Tastatur-
     *  Animation NICHT die Zwischenwerte, sondern springt erst am
     *  ENDE der Animation auf den neuen Wert. Genau daher ruckelte
     *  die Oberflaeche und zog beim Ausblenden erst nach, wenn die
     *  Tastatur schon weg war. Der Callback dagegen feuert pro Frame
     *  mit der ECHTEN aktuellen Hoehe -- die App laeuft damit exakt
     *  synchron zur System-Animation. */
    private void xbmInstallImeAnimListener() {
        if (android.os.Build.VERSION.SDK_INT < 30) return;
        try {
            final View v = getWindow().getDecorView();
            v.setWindowInsetsAnimationCallback(
                new android.view.WindowInsetsAnimation.Callback(
                    android.view.WindowInsetsAnimation.Callback
                        .DISPATCH_MODE_CONTINUE_ON_SUBTREE) {
                    @Override
                    public android.view.WindowInsets onProgress(
                            android.view.WindowInsets insets,
                            java.util.List<
                                android.view.WindowInsetsAnimation> running) {
                        mImeAnimH = insets.getInsets(
                            android.view.WindowInsets.Type.ime()).bottom;
                        return insets;
                    }
                    @Override
                    public void onEnd(
                            android.view.WindowInsetsAnimation anim) {
                        mImeAnimH = -1;   // ab jetzt wieder Abfragewert
                    }
                });
        } catch (Throwable t) { /* ohne Callback: Abfragewert */ }
    }

    /** Hoehe der eingeblendeten Tastatur in Pixeln (0 = keine). */
    // DATEI MIT DEM STANDARDPROGRAMM OEFFNEN (PDF-Betrachter, Editor ...).
    // [Die Datei liegt im PRIVATEN App-Ordner (internalDataPath). Andere
    //  Apps duerfen dort nicht lesen -- ein direkter ACTION_VIEW darauf
    //  scheitert, seit Android 7 wirft ein file://-Intent ohnehin eine
    //  FileUriExposedException. Der uebliche Weg waere ein FileProvider;
    //  der braucht aber androidx.core (eine Bibliothek, die dieser Bau
    //  nicht einbindet) plus einen res/xml-Ordner (den aapt2 hier nicht
    //  compiliert). Deshalb der andere, abhaengigkeitsfreie Weg: die
    //  Datei per MediaStore nach Downloads/xbm kopieren. Das liefert eine
    //  content://-URI, die jede App lesen darf, ohne Berechtigungen
    //  (eigene Eintraege darf man seit Android 10 immer anlegen).
    //  Nebeneffekt, der eher nuetzlich ist: die PDF liegt danach auch in
    //  Downloads und laesst sich von dort teilen.]
    public boolean xbmOeffneDatei(final String pfad) {
        try {
            final java.io.File f = new java.io.File(pfad);
            if (!f.exists() || !f.isFile()) return false;
            final String name = f.getName();
            String mime = java.net.URLConnection.guessContentTypeFromName(name);
            if (mime == null) {
                final String n = name.toLowerCase();
                if (n.endsWith(".pdf")) mime = "application/pdf";
                else if (n.endsWith(".apk")) mime = "application/vnd.android.package-archive";
                else if (n.endsWith(".txt") || n.endsWith(".cmd")) mime = "text/plain";
                else mime = "*/*";
            }
            final boolean istApk = name.toLowerCase().endsWith(".apk");
            // APK INSTALLIEREN: seit Android 8 braucht die App die Erlaubnis
            // "Unbekannte Apps installieren". Fehlt sie, oeffnet der Installer
            // still gar nichts -- deshalb zuerst die Einstellung dieser App
            // aufrufen; die Aktualisierung wird danach noch einmal angestossen.
            if (istApk && Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        try {
                            Intent s = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                                  Uri.parse("package:" + getPackageName()));
                            s.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(s);
                        } catch (Exception e) { }
                    }
                });
                return false;
            }
            final Uri uri;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                      Environment.DIRECTORY_DOWNLOADS + "/xbm");
                uri = getContentResolver().insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return false;
                try (java.io.InputStream in = new java.io.FileInputStream(f);
                     java.io.OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) return false;
                    byte[] buf = new byte[65536]; int r;
                    while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                }
            } else {
                // API 26-28: kein MediaStore.Downloads. Nach getExternalFilesDir
                // kopieren und file:// verwenden -- StrictMode dafuer lockern.
                java.io.File ziel = new java.io.File(getExternalFilesDir(null), name);
                try (java.io.InputStream in = new java.io.FileInputStream(f);
                     java.io.OutputStream out = new java.io.FileOutputStream(ziel)) {
                    byte[] buf = new byte[65536]; int r;
                    while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                }
                android.os.StrictMode.setVmPolicy(
                        new android.os.StrictMode.VmPolicy.Builder().build());
                uri = Uri.fromFile(ziel);
            }
            final String mimeF = mime;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(uri, mimeF);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                             | Intent.FLAG_ACTIVITY_NEW_TASK);
                    // APK: direkt an den Paket-Installer, ohne Auswahldialog
                    // (der Installer erwartet den Typ package-archive und
                    // die Leserechte auf die content://-URI -- beides gesetzt).
                    try { startActivity(istApk ? i : Intent.createChooser(i, name)); }
                    catch (Exception e) { /* kein passendes Programm */ }
                }
            });
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public int xbmImeHeight() {
        try {
            int anim = mImeAnimH;
            if (anim >= 0) return anim;        // laufende Animation
            View v = getWindow().getDecorView();
            android.view.WindowInsets wi = v.getRootWindowInsets();
            if (wi == null) return 0;
            if (android.os.Build.VERSION.SDK_INT >= 30)
                return wi.getInsets(
                    android.view.WindowInsets.Type.ime()).bottom;
            return wi.getSystemWindowInsetBottom();
        } catch (Throwable t) { return 0; }
    }

    /** Steuertasten-Warteschlange (Cursor, Loeschen, Pos1/Ende).
     *  GRUND: Gboards Wisch ueber die LEERTASTE bewegt den Cursor und
     *  schickt dafuer KEINEN Text, sondern DPAD_LEFT/RIGHT-Tastendrucke
     *  an die InputConnection. Das unsichtbare EditText verschluckt sie,
     *  und der native AKeyEvent-Weg ist abgeschaltet (er hatte jeden
     *  Anschlag verdoppelt). Ohne diese Bruecke bewegt sich der Cursor
     *  in ImGui also nicht. */
    private final java.util.ArrayList<Integer> mKeys =
        new java.util.ArrayList<Integer>();

    private void xbmPushKey(int code) {
        synchronized (mKeys) {
            if (mKeys.size() < 256) mKeys.add(Integer.valueOf(code));
        }
    }

    /** Holt die naechste Steuertaste (0 = keine mehr).
     *  1=links 2=rechts 3=hoch 4=runter 5=Backspace 6=Entf
     *  7=Pos1  8=Ende */
    public int xbmPollKey() {
        synchronized (mKeys) {
            if (mKeys.isEmpty()) return 0;
            return mKeys.remove(0).intValue();
        }
    }

    private void xbmInstallKeyBridge() {
        if (mInput == null) return;
        mInput.setOnKeyListener(new View.OnKeyListener() {
            @Override public boolean onKey(View v, int keyCode, KeyEvent ev) {
                if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
                switch (keyCode) {
                    case KeyEvent.KEYCODE_DPAD_LEFT:  xbmPushKey(1); return true;
                    case KeyEvent.KEYCODE_DPAD_RIGHT: xbmPushKey(2); return true;
                    case KeyEvent.KEYCODE_DPAD_UP:    xbmPushKey(3); return true;
                    case KeyEvent.KEYCODE_DPAD_DOWN:  xbmPushKey(4); return true;
                    case KeyEvent.KEYCODE_DEL:        xbmPushKey(5); return true;
                    case KeyEvent.KEYCODE_FORWARD_DEL:xbmPushKey(6); return true;
                    case KeyEvent.KEYCODE_MOVE_HOME:  xbmPushKey(7); return true;
                    case KeyEvent.KEYCODE_MOVE_END:   xbmPushKey(8); return true;
                }
                return false;
            }
        });
    }

    /** True, wenn das Eingabefeld gerade den Fokus hat. */
    public boolean xbmHasFocus() {
        return mInput != null && mInput.hasFocus();
    }
}
