package com.mrtn.xbookmarkmanager;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.util.Log;

import java.io.File;

/**
 * XbmAlarm -- Erinnerungen, die auch bei GESCHLOSSENER App und im
 * Standby laeuten.
 *
 * [Warum das nicht in C++ geht: der bisherige Weg war
 *  UiCalendar_SetReminderHandler -- ein Rueckruf im UI-Thread. Der
 *  laeuft nur, solange die App zeichnet. Ist sie zu oder das Geraet im
 *  Doze-Schlaf, gibt es keinen Frame, also keine Erinnerung. Kein
 *  C++-Faden kann das leisten; nur Androids AlarmManager weckt das
 *  Geraet.]
 *
 * Aufruf aus C++ (JNI, siehe xbm_alarm.cpp):
 *     XbmAlarm.plan(ctx, id, zeitMillis, titel, audioPfad)
 *     XbmAlarm.loeschen(ctx, id)
 */
public class XbmAlarm extends BroadcastReceiver {

    public static final String KANAL = "xbm_erinnerung";
    private static MediaPlayer sPlayer;

    // ---- PLANEN -----------------------------------------------------------
    public static void plan(Context ctx, long id, long zeitMillis,
                            String titel, String audioPfad) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(ctx, XbmAlarm.class);
        i.setAction("com.mrtn.xbookmarkmanager.ERINNERUNG");
        i.putExtra("id", id);
        i.putExtra("titel", titel != null ? titel : "Erinnerung");
        i.putExtra("audio", audioPfad != null ? audioPfad : "");
        PendingIntent pi = PendingIntent.getBroadcast(
                ctx, (int) id, i,
                PendingIntent.FLAG_UPDATE_CURRENT
                        | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                // [Ab Android 12 muss der Nutzer "Alarme und Erinnerungen"
                //  erlauben. Ohne das Recht wuerde setExact eine
                //  SecurityException werfen -- also der ungenaue Weg, der
                //  immer erlaubt ist. Lieber ein paar Minuten spaeter als
                //  gar nicht.]
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, zeitMillis, pi);
                return;
            }
            if (Build.VERSION.SDK_INT >= 23) {
                // Weckt das Geraet AUCH aus dem Doze-Schlaf -- das ist der
                // entscheidende Aufruf.
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, zeitMillis, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, zeitMillis, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, zeitMillis, pi);
        }
    }

    public static void loeschen(Context ctx, long id) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(ctx, XbmAlarm.class);
        i.setAction("com.mrtn.xbookmarkmanager.ERINNERUNG");
        PendingIntent pi = PendingIntent.getBroadcast(
                ctx, (int) id, i,
                PendingIntent.FLAG_NO_CREATE
                        | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        if (pi != null) { am.cancel(pi); pi.cancel(); }
    }

    /** Laeuft der Alarm gerade? Dann Ton beenden (aus der App heraus). */
    public static void tonStoppen() {
        try {
            if (sPlayer != null) { sPlayer.stop(); sPlayer.release(); sPlayer = null; }
        } catch (Throwable t) { sPlayer = null; }
    }

    // ---- EMPFANGEN --------------------------------------------------------
    @Override
    public void onReceive(Context ctx, Intent intent) {
        // Nach einem Neustart sind alle Alarme weg -- die App muss sie neu
        // setzen. Wir merken das nur an; das Neusetzen passiert beim
        // naechsten Start (UiCalendar plant beim Laden alles ein).
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            ctx.getSharedPreferences("xbm", Context.MODE_PRIVATE)
               .edit().putBoolean("alarme_neu_setzen", true).apply();
            return;
        }

        String titel = intent.getStringExtra("titel");
        String audio = intent.getStringExtra("audio");
        if (titel == null || titel.isEmpty()) titel = "Erinnerung";

        // Bildschirm kurz wecken, damit die Meldung auch gesehen wird.
        try {
            PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                PowerManager.WakeLock wl = pm.newWakeLock(
                        PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP,
                        "xbm:erinnerung");
                // 60 s statt vorher 10 s. [10 s war knapp bemessen fuer
                // Laden+Vorbereiten+Abspielen einer laengeren Memo-
                // Aufnahme; lief die Zeit ab, WAEHREND noch geladen
                // wurde, konnte das Geraet zwischendurch wieder
                // einschlafen. Der WakeLock loest sich von selbst,
                // sobald er nicht mehr gebraucht wird -- laenger
                // bemessen kostet nichts, verhindert aber ein
                // abgeschnittenes Laden.]
                wl.acquire(60000);
            }
        } catch (Throwable t) { /* ohne Wecken weiter */ }

        meldungZeigen(ctx, titel);
        tonSpielen(ctx, audio);
    }

    private void meldungZeigen(Context ctx, String titel) {
        // OHNE androidx.
        // [Erst NotificationCompat.Builder benutzt -- das ist androidx,
        //  und dein Bau bindet es nicht ein:
        //      error: package androidx.core.app does not exist
        //  Der Plattform-Builder reicht hier vollstaendig; nur muss man
        //  die beiden Wege nach SDK-Stand trennen, weil der Konstruktor
        //  mit Kanal-Kennung erst ab API 26 existiert.]
        try {
            NotificationManager nm =
                (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            Intent auf = new Intent(ctx, XbmActivity.class);
            PendingIntent pi = PendingIntent.getActivity(ctx, 0, auf,
                    Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);

            Notification n;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel k = new NotificationChannel(
                        KANAL, "Erinnerungen", NotificationManager.IMPORTANCE_HIGH);
                k.setDescription("Kalender-Erinnerungen");
                // Ton spielen wir selbst (auch die Memo) -- sonst doppelt.
                k.setSound(null, null);
                nm.createNotificationChannel(k);
                Notification.Builder b = new Notification.Builder(ctx, KANAL)
                        .setContentTitle("Erinnerung")
                        .setContentText(titel)
                        .setSmallIcon(android.R.drawable.ic_popup_reminder)
                        .setCategory(Notification.CATEGORY_ALARM)
                        .setAutoCancel(true)
                        .setContentIntent(pi);
                n = b.build();
            } else {
                Notification.Builder b = new Notification.Builder(ctx)
                        .setContentTitle("Erinnerung")
                        .setContentText(titel)
                        .setSmallIcon(android.R.drawable.ic_popup_reminder)
                        .setPriority(Notification.PRIORITY_HIGH)
                        .setAutoCancel(true)
                        .setContentIntent(pi);
                n = b.build();
            }
            nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), n);
        } catch (Throwable t) { /* ohne Meldung weiter -- der Ton kommt */ }
    }

    private void tonSpielen(Context ctx, String audioPfad) {
        // BISHER: jeder Fehler verschwand stillschweigend
        //   catch (Throwable t) { sPlayer = null; }
        // -- ohne jede Zeile im Protokoll. Genau deshalb konnten wir aus
        // der Ferne nicht sagen, WARUM kein Ton kam: das Symptom "gar
        // kein Alarmton" kann ein Dutzend verschiedene Ursachen haben
        // (Datei nicht gefunden, keine Berechtigung, falscher Pfad,
        // MediaPlayer-Fehlercode ...), und ALLE sahen bisher gleich aus:
        // Stille. Jetzt steht jede Ursache in "adb logcat | grep -i xbm".
        try {
            tonStoppen();
            Uri quelle = null;
            String quelleBeschreibung;
            if (audioPfad != null && !audioPfad.isEmpty()) {
                File f = new File(audioPfad);
                if (f.exists() && f.length() > 0) {
                    quelle = Uri.fromFile(f);
                    quelleBeschreibung = "Memo: " + audioPfad;
                } else {
                    Log.w("XbmAlarm", "Memo-Ton nicht gefunden oder leer: "
                          + audioPfad + " (exists=" + f.exists()
                          + ", length=" + f.length() + ") -- falle auf Standardton zurueck");
                    quelleBeschreibung = "Standardton (Memo fehlte)";
                }
            } else {
                quelleBeschreibung = "Standardton (kein Memo hinterlegt)";
            }
            if (quelle == null) {
                quelle = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                if (quelle == null) {
                    Log.e("XbmAlarm", "Kein Standard-Alarmton verfuegbar -- "
                          + "RingtoneManager.getDefaultUri(TYPE_ALARM) liefert null. "
                          + "Kein Ton wird gespielt.");
                    return;
                }
            }
            Log.i("XbmAlarm", "Alarmton wird gestartet: " + quelleBeschreibung
                  + "  Uri=" + quelle);

            sPlayer = new MediaPlayer();
            if (Build.VERSION.SDK_INT >= 21) {
                sPlayer.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build());
            } else {
                sPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
            }
            sPlayer.setDataSource(ctx, quelle);
            sPlayer.setLooping(false);
            // ASYNCHRON VORBEREITEN statt blockierendem prepare().
            // [Ein BroadcastReceiver.onReceive() -- und genau darin laeuft
            //  dieser Code -- hat nur ein knappes Zeitfenster, bevor das
            //  System es als haengengeblieben behandelt; das ist bei
            //  setExactAndAllowWhileIdle()-Alarmen im Doze-Schlaf noch
            //  enger. Ein blockierendes prepare() (Datei von der Platte
            //  lesen, dekodieren anstossen) kann dieses Fenster sprengen
            //  -- der Prozess wird dann beendet, WAEHREND prepare() noch
            //  laeuft, und start() wird nie erreicht. Kein Fehler, keine
            //  Ausnahme -- der Ton kommt einfach nicht. prepareAsync()
            //  gibt die Kontrolle sofort zurueck; start() laeuft erst im
            //  Rueckruf, wenn die Datei wirklich bereit ist.]
            sPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override public void onPrepared(MediaPlayer mp) {
                    try {
                        mp.start();
                        Log.i("XbmAlarm", "Wiedergabe gestartet.");
                    } catch (Throwable t) {
                        Log.e("XbmAlarm", "start() nach prepareAsync() fehlgeschlagen", t);
                    }
                }
            });
            sPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override public boolean onError(MediaPlayer mp, int what, int extra) {
                    Log.e("XbmAlarm", "MediaPlayer-Fehler: what=" + what + " extra=" + extra);
                    tonStoppen();
                    return true;
                }
            });
            // Nach dem Ende aufraeumen, sonst bleibt der Player liegen.
            // [ANONYME KLASSE, KEIN LAMBDA -- dieser Android-Bau bindet
            //  java.lang.invoke.LambdaMetafactory nicht ein (siehe die
            //  fruehere Korrektur weiter oben in der Projekthistorie);
            //  ein Lambda haette hier denselben Bau-Fehler wieder
            //  ausgeloest. Anonyme Klassen brauchen das nicht.]
            sPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override public void onCompletion(MediaPlayer mp) { tonStoppen(); }
            });
            sPlayer.prepareAsync();
        } catch (Throwable t) {
            Log.e("XbmAlarm", "tonSpielen() fehlgeschlagen fuer Pfad: " + audioPfad, t);
            sPlayer = null;
        }
    }
}
