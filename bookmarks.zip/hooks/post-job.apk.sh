#!/bin/bash
## Vorher so:
# ./alert.sh lobby
# Signal nach einem apk-Auftrag -- nur, wenn es alert.sh gibt.
# [Hier stand nur "./alert.sh lobby". alert.sh ist mit dem Auslagern der
#  Bauskripte aus dem Projekt verschwunden. Der Hook scheiterte dadurch,
#  und ein gescheiterter post-job-Hook laesst in build.sh den GANZEN
#  Auftrag scheitern: apk@buildserver galt als fehlgeschlagen, obwohl die
#  APK gebaut war, und apk@windows wurde deshalb uebersprungen. Ein
#  fehlendes Signal ist kein Baufehler -- also nie mit Fehler enden.]
if command -v alert.sh >/dev/null 2>&1; then
  alert.sh lobby
elif [[ -x ./alert.sh ]]; then
  ./alert.sh lobby
fi
exit 0
