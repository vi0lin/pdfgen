#!/bin/bash
# VOR JEDEM BAU AUF DER ZIELMASCHINE: pdf-Quellen angleichen.
# [markup.cpp im pdf-Repo verlangt PDFGEN_MARKUP_API 14 (Token::align),
#  markup.h/project.cpp stehen dort auf 13. Jeder Abgleich setzt das Submodul
#  per "git reset --hard" zurueck, und die CMake-Angleichung laeuft nur beim
#  Konfigurieren -- das entfaellt, sobald ein Cache da ist. Deshalb HIER,
#  bei jedem Lauf, auf jedem Host, idempotent. Wird ueberfluessig, sobald das
#  pdf-Repository selbst richtiggestellt ist; dann tut der Hook nichts.]
# set -u
# d="${XBM_PROJECT_DIR:-.}/external/pdf/src"
# [[ -f $d/markup.h && -f $d/markup.cpp ]] || exit 0
# # statx() gibt es auf Android erst ab API 30 -- der Linux-Zweig darf dort nicht gelten
# if grep -q '^#ifdef __linux__$' "$d/markup.cpp" && grep -q 'statx(AT_FDCWD' "$d/markup.cpp"; then
#   sed -i.xbm 's/^#ifdef __linux__$/#if defined(__linux__) \&\& (!defined(__ANDROID__) || __ANDROID_API__ >= 30)/' "$d/markup.cpp" && rm -f "$d/markup.cpp.xbm"
#   echo "  pdf: markup.cpp -- statx() nur mit glibc/Bionic>=30 (Hook pre-action)"
# fi
# soll=$(grep -o 'PDFGEN_MARKUP_API != [0-9]*' "$d/markup.cpp" | grep -o '[0-9]*$' | head -1)
# ist=$(grep -o '#define PDFGEN_MARKUP_API [0-9]*' "$d/markup.h" | grep -o '[0-9]*$' | head -1)
# [[ ${soll:-} == 14 && ${ist:-} == 13 ]] || exit 0
# # Header: Version + Feld (nur, wenn es fehlt), CRLF-neutral
# sed -i.xbm 's/#define PDFGEN_MARKUP_API 13/#define PDFGEN_MARKUP_API 14/' "$d/markup.h"
# if ! grep -q 'int align = 0;' "$d/markup.h"; then
#   awk '{ print } /std::vector<int> aligns;/ && !getan { print "  int align = 0;                               // Image: 0 left, 1 center, 2 right (API 14)"; getan=1 }' "$d/markup.h" > "$d/markup.h.xbm2" && mv "$d/markup.h.xbm2" "$d/markup.h"
# fi
# rm -f "$d/markup.h.xbm"
# # Pinnungen der uebrigen Quellen
# for f in "$d"/*.cpp; do
#   grep -q '#elif PDFGEN_MARKUP_API != 13' "$f" 2>/dev/null && sed -i.xbm 's/#elif PDFGEN_MARKUP_API != 13/#elif PDFGEN_MARKUP_API != 14/' "$f" && rm -f "$f.xbm"
# done
# echo "  pdf: markup.h/project.cpp auf API 14 angeglichen (Hook pre-action; bitte pdf-Repo richtigstellen)"
# exit 0
