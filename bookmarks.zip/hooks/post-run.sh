#!/bin/bash
# post-run -- laeuft EINMAL, wenn ALLE Auftraege fertig sind.
#
# [Vorher bookmarks das in post-job.sh. post-job laeuft nach JEDEM Auftrag --
#  also packte der Hook bookmarks.zip, sobald der erste Bau fertig war, und
#  sammelte dabei die Logs der noch LAUFENDEN Auftraege ein. Genau
#  deshalb brachen die exe-Logs viermal hintereinander mitten im Bau ab
#  ("[24/32]", kein Fehler, kein Ende) -- es war keine Stoerung, sondern
#  eine Momentaufnahme.
#
#  post-run laeuft einmal am Ende. Damit sind alle Logs vollstaendig.]
#
## Vorher so:
# ( source build_wrapper.sh && zip_project && mv_to_laptop bookmarks.zip ) &
# ./alert.sh lobby
# [Hier bookmarks:
#      ( source build_wrapper.sh && zip_project && mv_to_laptop bookmarks.zip ) &
#      ./alert.sh lobby
#  build_wrapper.sh und alert.sh sind mit dem Auslagern von build.sh aus
#  dem Projekt verschwunden -- der Hook scheiterte daran bei jedem Lauf.
#  Jetzt kommt er ohne sie aus: bookmarks.zip packt er selbst, und statt
#  mv_to_laptop gibt es  build.sh --move-to <host> <datei>.]

# NUR AUF DEM STEUERNDEN RECHNER.
# [Bei einem entfernten Bau ruft build.sh sich auf dem Bauhost SELBST erneut
#  auf ("aufgerufen von buildserver") -- und dieser innere Lauf fuehrt
#  hooks/ aus seinem eigenen Checkout aus, also auch diesen Hook. Auf dem
#  FreeBSD-Buildserver endete das in "sshpass: command not found" und
#  "tar: Write error"; auf windows packte der Hook bookmarks.zip und schob
#  es sich selbst zu. Erkennungsmerkmal: die Datei .xbm-steuerrechner. Sie
#  steht in .gitignore und kommt deshalb nie per git auf einen Bauhost.
#  Einmalig auf dem Laptop anlegen:   touch .xbm-steuerrechner  ]
if [[ ! -f .xbm-steuerrechner ]]; then
  echo "  post-run: kein Steuerrechner (.xbm-steuerrechner fehlt) -- uebersprungen"
  exit 0
fi

# bookmarks.zip: alles, was im Repo steht, plus die Protokolle dieses Laufs.
bookmarks_packen() {
  source bookmarks.sh
  zip_my_projects
  return
  rm -f bookmarks.zip
  { git ls-files 2>/dev/null; find builds/logs -type f ! -name '*.lock' 2>/dev/null; } \
    | sort -u > .bookmarks-liste
  if command -v zip >/dev/null 2>&1; then
    zip -q bookmarks.zip -@ < .bookmarks-liste
  else
    python3 - .bookmarks-liste <<'PY'
import sys, zipfile, os
with zipfile.ZipFile('bookmarks.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for name in open(sys.argv[1]).read().split('\n'):
        if name and os.path.isfile(name):
            z.write(name)
PY
  fi
  local rc=$?
  rm -f .bookmarks-liste
  return $rc
}

( bookmarks_packen && build.sh --move-to windows bookmarks.zip ) &

# Signal, dass der Lauf fertig ist -- nur, wenn es alert.sh noch gibt.
if command -v alert.sh >/dev/null 2>&1; then
  alert.sh lobby
elif [[ -x ./alert.sh ]]; then
  ./alert.sh lobby
fi
exit 0
