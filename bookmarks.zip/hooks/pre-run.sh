#!/bin/bash
# VOR DEM LAUF: Git-Server erreichbar? [Die Bauhosts holen das Projekt von
#  dort. Lief er nicht, scheiterten exe@windows und apk@buildserver erst
#  nach Minuten mit "Could not connect" -- und deb@local baute derweil
#  umsonst. Hier faellt es sofort auf; auf Wunsch wird der Server gestartet.]
#
# Einstellung in build.sh.conf(.unreleased), Abschnitt [targets] (Bash):
#   XBM_GIT_SERVER_START='cd /pfad/zum/git_http_server && ./git_http_server 3000 /pfad/repos &'
# Ohne diese Variable wird nur geprueft.
# set -u
# url=$(awk -F'|' '/^\[hosts\]/{h=1;next} /^\[/{h=0} h && $6 ~ /http/ {gsub(/^[ \t]+|[ \t]+$/,"",$6); print $6; exit}' "${XBM_KONF_DATEI:-build.sh.conf.unreleased}" 2>/dev/null)
# [[ -z $url ]] && url=$(awk -F'|' '/^\[hosts\]/{h=1;next} /^\[/{h=0} h && $6 ~ /http/ {gsub(/^[ \t]+|[ \t]+$/,"",$6); print $6; exit}' build.sh.conf 2>/dev/null)
# [[ -z $url ]] && exit 0                     # keine HTTP-Git-URL -> nichts zu pruefen
# erreichbar() { curl -s -m 4 -o /dev/null -w '%{http_code}' "$url/info/refs?service=git-upload-pack" 2>/dev/null | grep -qE '^(200|401)$'; }
# if erreichbar; then exit 0; fi
# start=$(awk '/^\[targets\]/{t=1;next} /^\[/{t=0} t && /^XBM_GIT_SERVER_START=/' "${XBM_KONF_DATEI:-build.sh.conf.unreleased}" build.sh.conf 2>/dev/null | head -1)
# if [[ -n $start ]]; then
#   echo "  Git-Server $url nicht erreichbar -- starte ihn"
#   eval "$start"                            # die Zuweisung (Anfuehrungszeichen wie in Bash)
#   eval "${XBM_GIT_SERVER_START:-}" >/dev/null 2>&1
#   for i in 1 2 3 4 5 6 7 8; do sleep 1; erreichbar && { echo "  Git-Server laeuft"; exit 0; }; done
# fi
# echo "  Git-Server $url NICHT erreichbar -- die Bauhosts koennten das Projekt nicht holen." >&2
# echo "  Server starten (oder XBM_GIT_SERVER_START in build.sh.conf setzen) und erneut." >&2
# exit 1
