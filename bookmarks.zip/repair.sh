#!/bin/bash
# ===========================================================================
# repair.sh -- bookmarks lauffaehig machen: EIN Befehl fuer drei Repositories.
#
#   bash repair.sh            ausfuehren (fragt vor jedem Push)
#   bash repair.sh --ja       ohne Rueckfragen
#   bash repair.sh --pruefen  nur zeigen, was zu tun waere
#
# Was es tut (jeder Schritt einzeln prueft und uebersprungen wird, wenn er
# schon erledigt ist):
#   1. external/pdf         markup.h auf API 14 (Token::align) -- markup.cpp
#                           verlangt das; committen, pushen
#   2. external/general_c   .gitmodules: Vulkan-Gitlink bekommt "update = none",
#                           lokale /home/...-URLs werden zu Server-URLs;
#                           git submodule sync; committen, pushen
#   3. bookmarks            .gitmodules-Eintrag fuer general_c; Submodul-Zeiger
#                           (pdf, general_c) uebernehmen; committen, pushen
#   4. Probe                git clone --recursive in einen leeren Ordner: muss
#                           ohne "fatal" durchlaufen und netlink enthalten
# ===========================================================================
set -u
cd "$(dirname "$0")" || exit 1
JA=0; PRUEFEN=0
for a in "$@"; do case $a in --ja) JA=1;; --pruefen) PRUEFEN=1;; esac; done
rot()  { printf '\033[31m%s\033[0m\n' "$*"; }
gruen(){ printf '\033[32m%s\033[0m\n' "$*"; }
frage(){ (( JA )) && return 0; read -r -p "$1 [j/N] " x; [[ $x == j || $x == J ]]; }
fehler=0

[[ -d .git && -f .gitmodules ]] || { rot "Bitte im Projektordner bookmarks/ ausfuehren (hier fehlt .git/.gitmodules)"; exit 1; }
commit_push() {   # commit_push <ordner> <meldung> <dateien...>
    local d=$1 m=$2; shift 2
    if git -C "$d" diff --quiet -- "$@" && git -C "$d" diff --cached --quiet -- "$@"; then echo "   $d: nichts zu committen"; return 0; fi
    (( PRUEFEN )) && { echo "   [pruefen] wuerde in $d committen: $*"; return 0; }
    git -C "$d" add -- "$@" || return 1
    git -C "$d" -c user.name="${GIT_AUTHOR_NAME:-repair}" -c user.email="${GIT_AUTHOR_EMAIL:-repair@local}" commit -q -m "$m" || return 1
    local zweig; zweig=$(git -C "$d" symbolic-ref --short HEAD 2>/dev/null || echo main)
    if frage "   $d: '$m' nach origin/$zweig pushen?"; then
        git -C "$d" push origin "HEAD:refs/heads/$zweig" || { rot "   Push in $d fehlgeschlagen -- Server erreichbar? Rechte?"; return 1; }
        gruen "   gepusht: $d -> $zweig"
    else echo "   nicht gepusht (Commit liegt lokal)"; fi
}

echo "== 1. external/pdf: markup.h / project.cpp"
if [[ -f external/pdf/src/markup.h ]]; then
    (( PRUEFEN )) || python3 - << 'PY'
# Idempotent: Doppelte entfernen, Feld ergaenzen, Header auf 14, Pins auf 14.
import re
h='external/pdf/src/markup.h'; s=open(h,encoding='utf-8').read()
if s.startswith('/ markup.h'): s='/'+s                                    # verlorener Schraegstrich in Zeile 1
z='  int align = 0;                               // Image: 0 left, 1 center, 2 right (API 14)\n'
while s.count(z) > 1: s=s.replace(z+z, z)                                   # doppelt -> einmal
if 'int align' not in s:
    alt='  std::vector<int> aligns;                     // Table: 0 left, 1 center, 2 right'
    if alt in s: s=s.replace(alt, alt+'\n'+z.rstrip('\n'))
s=re.sub(r'#define PDFGEN_MARKUP_API \d+','#define PDFGEN_MARKUP_API 14',s)
open(h,'w',encoding='utf-8').write(s)
for c in ['external/pdf/src/project.cpp','external/pdf/src/markup.cpp']:
    try: t=open(c,encoding='utf-8').read()
    except FileNotFoundError: continue
    t2=re.sub(r'#elif PDFGEN_MARKUP_API != \d+','#elif PDFGEN_MARKUP_API != 14',t)
    if t2!=t: open(c,'w',encoding='utf-8').write(t2)
PY
    if g++ -std=gnu++17 -Iexternal/pdf/src -Iexternal/pdf/include -fsyntax-only external/pdf/src/markup.cpp 2>/dev/null \
       && g++ -std=gnu++17 -Iexternal/pdf/src -Iexternal/pdf/include -fsyntax-only external/pdf/src/project.cpp 2>/dev/null; then
        gruen "   markup.h API 14 (Token::align einmal), Pins in markup.cpp/project.cpp auf 14 -- uebersetzt"
    else
        (( PRUEFEN )) && echo "   [pruefen] wuerde markup.h/project.cpp angleichen" || { rot "   pdf-Quellen uebersetzen nicht -- bitte pdf-Repository von Hand pruefen"; fehler=1; }
    fi
    commit_push external/pdf "markup.h API 14 (Token::align); Pins in markup.cpp/project.cpp" src/markup.h src/project.cpp src/markup.cpp || fehler=1
else rot "   external/pdf ist leer: git submodule update --init external/pdf"; fehler=1; fi

echo "== 2. external/general_c: .gitmodules"
GM=external/general_c/.gitmodules
if [[ -f $GM ]]; then
    aend=0
    if grep -q '/home/' "$GM"; then
        # Server-URL: origin des Submoduls (wenn es vom Server kam), sonst der
        # Eintrag in bookmarks, sonst der bekannte Git-Server.
        srv=$(git -C external/general_c config --get remote.origin.url 2>/dev/null)
        [[ -z $srv || $srv == /* ]] && srv=$(git config -f .gitmodules --get submodule.external/general_c.url 2>/dev/null)
        [[ -z $srv || $srv == /* ]] && srv="http://192.168.1.69:3000/general_c.git"
        echo "   lokale URLs -> $srv"
        (( PRUEFEN )) || { sed -i "s|url = /home/[^ ]*general_c.git|url = $srv|" "$GM"; aend=1; }
    fi
    # Gitlinks ohne Eintrag -> "update = none"
    while read -r modus obj stufe pfad; do
        [[ $modus == 160000 ]] || continue
        git config -f "$GM" --get-regexp '\.path$' | grep -q " $pfad$" && continue
        echo "   Gitlink ohne Eintrag: $pfad -> wird uebersprungen (update = none)"
        (( PRUEFEN )) || { printf '[submodule "%s"]\n\tpath = %s\n\turl = https://example.invalid/unbenutzt.git\n\tupdate = none\n' "$pfad" "$pfad" >> "$GM"; aend=1; }
    done < <(git -C external/general_c ls-files -s)
    (( aend )) && git -C external/general_c submodule sync --recursive -q 2>/dev/null
    (( aend )) && gruen "   .gitmodules angepasst" || echo "   nichts zu tun"
    commit_push external/general_c "Submodul-URLs auf den Server; fremde Gitlinks uebersprungen" .gitmodules || fehler=1
else rot "   external/general_c ist leer: git submodule update --init external/general_c"; fehler=1; fi

echo "== 3. bookmarks: Eintrag und Zeiger"
if ! git config -f .gitmodules --get submodule.external/general_c.url >/dev/null; then
    (( PRUEFEN )) || printf '[submodule "external/general_c"]\n\tpath = external/general_c\n\turl = http://192.168.1.69:3000/general_c.git\n' >> .gitmodules
    gruen "   .gitmodules: general_c eingetragen"
fi
(( PRUEFEN )) || git submodule sync --recursive -q 2>/dev/null
commit_push . "Submodule richtig verkabelt: pdf API 14, general_c-URLs, Vulkan-Gitlink uebersprungen" .gitmodules external/pdf external/general_c || fehler=1

echo "== 4. Probe: frischer rekursiver Klon"
if (( ! PRUEFEN )) && (( ! fehler )); then
    url=$(git config --get remote.origin.url); tmp=$(mktemp -d)
    if git clone -q --recursive "$url" "$tmp/probe" 2>"$tmp/err" && [[ -f "$tmp/probe/external/general_c/external/netlink/src/xbm_netnode.h" ]]; then
        gruen "   OK: rekursiver Klon von $url enthaelt netlink -- die Bauhosts werden es auch bekommen"
    else rot "   Probe fehlgeschlagen:"; grep -i "fatal\|error" "$tmp/err" | head -5 | sed 's/^/     /'; fehler=1; fi
    rm -rf "$tmp"
fi

echo
if (( fehler )); then rot "Es bleibt etwas offen -- siehe oben."; exit 1; fi
gruen "Fertig. Jetzt:  build.sh --clean-deep --clean-only deb@local exe@windows apk@buildserver   und dann der normale Lauf."
hosts=$(sed -n '/^\[hosts\]/,/^\[/p' build.sh.conf.unreleased build.sh.conf 2>/dev/null | grep '|' | grep -v '^#' | cut -d'|' -f1 | tr -d ' ' | sort -u | tr '\n' ' ')
echo "   Bekannte Hosts laut build.sh.conf: $hosts  -- beim Aufruf genau so schreiben (nicht 'buldserver')."
