@echo off
REM WSL dauerhaft warm halten -- Aufruf ohne PowerShell-Kenntnisse.
REM   wsl-warmhalten.cmd              einrichten
REM   wsl-warmhalten.cmd entfernen    wieder abschalten
if /I "%~1"=="entfernen" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0wsl-warmhalten.ps1" -Entfernen
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0wsl-warmhalten.ps1"
)
pause
