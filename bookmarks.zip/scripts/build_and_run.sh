#!/bin/bash
git.sh --push-all -m "Updated" \
  --root \
  external/pdf=main:@origin/main \
  -r external/general_c=main:@origin/main
build.sh --publish apk@buildserver deb@local exe@windows \
--no-publish --run-only apk@windows
( source /home/user/MRTN/m/sh/build/bookmarks.sh && zip_my_projects ) 2>/dev/null &
