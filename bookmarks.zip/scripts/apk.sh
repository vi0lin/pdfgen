#!/bin/bash
build.sh --no-publish --run-only apk@windows
