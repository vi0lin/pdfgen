#!/bin/bash
build.sh --no-publish --run-only apk@windows
( source /home/user/MRTN/m/sh/build/bookmarks.sh && zip_my_projects ) 2>/dev/null &
