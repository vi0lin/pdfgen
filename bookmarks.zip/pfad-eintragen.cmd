@echo off
REM Dasselbe ohne PowerShell-Aufruf von Hand.
REM   pfad-eintragen.cmd C:\werkzeuge          (nur fuer dich)
REM   pfad-eintragen.cmd C:\werkzeuge Machine  (auch fuer Dienste, als Admin)
if "%~1"=="" ( echo Aufruf: %~n0 ^<ordner^> [User^|Machine] & exit /b 2 )
set "BEREICH=%~2"
if "%BEREICH%"=="" set "BEREICH=User"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0pfad-eintragen.ps1" "%~1" "%BEREICH%"
